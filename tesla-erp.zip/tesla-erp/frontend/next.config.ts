import type { NextConfig } from "next";

const backend = process.env.BACKEND_URL ?? "http://127.0.0.1:8000";

const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(self), geolocation=(self), microphone=()" },
];

// NEXT_OUTPUT=export builds plain static files for the on-premise Windows server, which serves them itself
// (same origin as the API, so no rewrites are needed). Otherwise: a standalone Node server for the cloud.
const staticExport = process.env.NEXT_OUTPUT === "export";

const nextConfig: NextConfig = staticExport
  ? { output: "export", trailingSlash: true, images: { unoptimized: true }, poweredByHeader: false }
  : {
  output: "standalone",
  poweredByHeader: false,
  // Same-origin API: the browser only ever talks to this host, so auth cookies stay SameSite=Strict
  // and no CORS is needed. In production the load balancer routes /api directly to the backend.
  async rewrites() {
    return [{ source: "/api/:path*", destination: `${backend}/api/:path*` }];
  },
  async headers() {
    return [{ source: "/:path*", headers: securityHeaders }];
  },
  };

export default nextConfig;
