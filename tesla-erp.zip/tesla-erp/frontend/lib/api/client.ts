/**
 * API client. The access token lives only in memory; the refresh token is an HttpOnly cookie the
 * browser sends to /api/v1/auth only. On a 401 the client refreshes once and retries.
 */

export type ApiErrorBody = {
  code: string;
  message: string;
  details?: unknown;
  request_id?: string;
};

export class ApiError extends Error {
  status: number;
  code: string;
  details: unknown;
  constructor(status: number, body: ApiErrorBody) {
    super(body.message);
    this.status = status;
    this.code = body.code;
    this.details = body.details;
  }
  /** Field-level validation messages, keyed by field name. */
  fieldErrors(): Record<string, string> {
    if (!Array.isArray(this.details)) return {};
    const out: Record<string, string> = {};
    for (const d of this.details as { field?: string; message?: string }[]) {
      if (d.field && d.message && !out[d.field]) out[d.field] = d.message.replace(/^Value error, /, "");
    }
    return out;
  }
}

export type Page<T> = { data: T[]; meta: { page: number; page_size: number; total: number } };

let accessToken: string | null = null;
let refreshing: Promise<string | null> | null = null;
let onSessionEnd: (() => void) | null = null;

export function setAccessToken(t: string | null) {
  accessToken = t;
}
export function onSessionExpired(cb: () => void) {
  onSessionEnd = cb;
}

function csrfToken(): string {
  if (typeof document === "undefined") return "";
  const m = document.cookie.match(/(?:^|; )tce_csrf=([^;]+)/);
  return m ? decodeURIComponent(m[1]) : "";
}

export async function refreshSession(): Promise<any | null> {
  if (!csrfToken()) return null; // never signed in on this browser — nothing to refresh
  const r = await fetch("/api/v1/auth/refresh", {
    method: "POST",
    headers: { "X-CSRF-Token": csrfToken() },
    credentials: "same-origin",
  });
  if (!r.ok) {
    accessToken = null;
    return null;
  }
  const body = await r.json();
  accessToken = body.data.access_token;
  return body.data;
}

async function refreshOnce(): Promise<string | null> {
  if (!refreshing) {
    refreshing = refreshSession()
      .then((d) => (d ? d.access_token : null))
      .finally(() => {
        setTimeout(() => (refreshing = null), 0);
      });
  }
  return refreshing;
}

type Opts = {
  method?: string;
  body?: unknown;
  params?: Record<string, string | number | boolean | null | undefined>;
  form?: FormData;
  raw?: boolean;
};

export function buildQuery(params?: Opts["params"]): string {
  if (!params) return "";
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
  }
  const s = q.toString();
  return s ? `?${s}` : "";
}

export async function api<T = any>(path: string, opts: Opts = {}, retried = false): Promise<T> {
  const headers: Record<string, string> = {};
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  let body: BodyInit | undefined;
  if (opts.form) body = opts.form;
  else if (opts.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(opts.body);
  }
  const res = await fetch(`/api/v1${path}${buildQuery(opts.params)}`, {
    method: opts.method ?? (body ? "POST" : "GET"),
    headers,
    body,
    credentials: "same-origin",
  });
  if (res.status === 401 && !retried && !path.startsWith("/auth/")) {
    const t = await refreshOnce();
    if (t) return api<T>(path, opts, true);
    onSessionEnd?.();
  }
  if (!res.ok) {
    let err: ApiErrorBody = { code: "HTTP_" + res.status, message: res.statusText || "Request failed" };
    try {
      err = (await res.json()).error ?? err;
    } catch {
      /* non-JSON error */
    }
    throw new ApiError(res.status, err);
  }
  if (opts.raw) return res as unknown as T;
  if (res.status === 204) return undefined as T;
  return res.json();
}

/** Download a file from an authenticated endpoint (Excel exports, documents). */
export async function download(path: string, fallbackName: string, params?: Opts["params"]) {
  const res = await api<Response>(path, { raw: true, params });
  const blob = await res.blob();
  const cd = res.headers.get("content-disposition") ?? "";
  const name = /filename="([^"]+)"/.exec(cd)?.[1] ?? fallbackName;
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

/** Fetch an authenticated image/file and return an object URL for <img src>. */
export async function objectUrl(path: string): Promise<string> {
  const res = await api<Response>(path, { raw: true });
  return URL.createObjectURL(await res.blob());
}

/** POST a multipart form with upload progress (0–1). Used for chat photos and files on slow mobile data. */
export function uploadWithProgress<T = any>(path: string, form: FormData, onProgress?: (fraction: number) => void,
  retried = false): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `/api/v1${path}`);
    xhr.withCredentials = true;
    if (accessToken) xhr.setRequestHeader("Authorization", `Bearer ${accessToken}`);
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress?.(e.loaded / e.total); };
    xhr.onerror = () => reject(new ApiError(0, { code: "NETWORK", message: "Upload failed — check the connection and try again." }));
    xhr.onload = async () => {
      if (xhr.status === 401 && !retried) {
        const t = await refreshOnce();
        if (t) return uploadWithProgress<T>(path, form, onProgress, true).then(resolve, reject);
        onSessionEnd?.();
      }
      let body: any = null;
      try { body = JSON.parse(xhr.responseText); } catch { /* non-JSON */ }
      if (xhr.status >= 200 && xhr.status < 300) resolve(body as T);
      else reject(new ApiError(xhr.status, body?.error ?? { code: "HTTP_" + xhr.status, message: xhr.status === 413 ? "The file is too large." : "Upload failed." }));
    };
    xhr.send(form);
  });
}
