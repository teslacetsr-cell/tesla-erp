"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { api, onSessionExpired, refreshSession, setAccessToken } from "@/lib/api/client";

export type Me = {
  id: string;
  username: string;
  email: string;
  full_name: string;
  must_change_password: boolean;
  roles: string[];
  permissions: Record<string, "own" | "team" | "division" | "all">;
};

type AuthState = {
  me: Me | null;
  loading: boolean;
  can: (code: string) => boolean;
  login: (login: string, password: string) => Promise<Me>;
  logout: () => Promise<void>;
  setSession: (data: { access_token: string; user: Me }) => void;
};

const Ctx = createContext<AuthState | null>(null);

function csrf() {
  const m = document.cookie.match(/(?:^|; )tce_csrf=([^;]+)/);
  return m ? decodeURIComponent(m[1]) : "";
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  const setSession = useCallback((data: { access_token: string; user: Me }) => {
    setAccessToken(data.access_token);
    setMe(data.user);
  }, []);

  // Restore the session from the HttpOnly refresh cookie on page load.
  useEffect(() => {
    refreshSession()
      .then((d) => d && setSession(d))
      .finally(() => setLoading(false));
    onSessionExpired(() => {
      setAccessToken(null);
      setMe(null);
      router.replace("/login?expired=1");
    });
  }, [router, setSession]);

  // Keep the short-lived access token fresh while the tab is open.
  useEffect(() => {
    if (!me) return;
    const t = setInterval(() => refreshSession().then((d) => d && setSession(d)), 12 * 60 * 1000);
    return () => clearInterval(t);
  }, [me, setSession]);

  const value = useMemo<AuthState>(
    () => ({
      me,
      loading,
      can: (code) => !!me?.permissions[code],
      setSession,
      login: async (login, password) => {
        const r = await api<{ data: { access_token: string; user: Me } }>("/auth/login", {
          body: { login, password },
        });
        setSession(r.data);
        return r.data.user;
      },
      logout: async () => {
        await fetch("/api/v1/auth/logout", { method: "POST", headers: { "X-CSRF-Token": csrf() } });
        setAccessToken(null);
        setMe(null);
        router.replace("/login");
      },
    }),
    [me, loading, router, setSession],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth outside AuthProvider");
  return v;
}
