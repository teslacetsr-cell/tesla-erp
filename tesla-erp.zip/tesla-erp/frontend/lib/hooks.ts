"use client";

import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { api, ApiError, type Page } from "@/lib/api/client";
import { useToast } from "@/components/ui";

/** Paginated, searchable, sortable list backed by a standard list endpoint. */
export function useList<T>(path: string, initial: { sort?: string; filters?: Record<string, string> } = {}) {
  const [page, setPage] = useState(1);
  const [q, setQ] = useState("");
  const [debouncedQ, setDebouncedQ] = useState("");
  const [sort, setSort] = useState(initial.sort ?? "");
  const [filters, setFilters] = useState<Record<string, string>>(initial.filters ?? {});
  useEffect(() => {
    const t = setTimeout(() => {
      setDebouncedQ(q.trim());
      setPage(1);
    }, 250);
    return () => clearTimeout(t);
  }, [q]);
  const query = useQuery({
    queryKey: [path, page, debouncedQ, sort, filters],
    queryFn: () => api<Page<T>>(path, { params: { page, page_size: 25, q: debouncedQ, sort, ...filters } }),
    placeholderData: keepPreviousData,
  });
  return {
    ...query,
    rows: query.data?.data ?? [],
    meta: query.data?.meta,
    page,
    setPage,
    q,
    setQ,
    sort,
    setSort: (s: string) => {
      setSort(s);
      setPage(1);
    },
    filters,
    setFilter: (k: string, v: string) => {
      setFilters((f) => ({ ...f, [k]: v }));
      setPage(1);
    },
  };
}

/** Options for <select> from a master list. */
export function useOptions(path: string, enabled = true) {
  return useQuery({
    queryKey: [path, "options"],
    queryFn: () => api<Page<any>>(path, { params: { page_size: 200, is_active: true } }),
    enabled,
    staleTime: 5 * 60_000,
    select: (r) => r.data,
  });
}

/** Mutation with toast on success/failure and cache invalidation. */
export function useSave<TVars = any>(fn: (v: TVars) => Promise<any>, opts: { success?: string; invalidate?: string[]; onSuccess?: (r: any) => void } = {}) {
  const qc = useQueryClient();
  const toast = useToast();
  return useMutation({
    mutationFn: fn,
    onSuccess: (r) => {
      opts.invalidate?.forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
      if (opts.success) toast(opts.success);
      opts.onSuccess?.(r);
    },
    onError: (e) => {
      toast(e.message, "error");
    },
  });
}

export function fieldErrors(err: unknown): Record<string, string> {
  return err instanceof ApiError ? err.fieldErrors() : {};
}
