"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button, ErrorNote, Field, Input } from "@/components/ui";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";

export default function ChangePasswordPage() {
  const { me, loading, setSession, logout } = useAuth();
  const router = useRouter();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  useEffect(() => {
    if (!loading && !me) router.replace("/login");
  }, [loading, me, router]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (next !== confirm) return setError(new Error("The new passwords do not match."));
    setBusy(true);
    setError(null);
    try {
      const r = await api("/auth/change-password", { body: { current_password: current, new_password: next } });
      setSession(r.data);
      router.replace("/dashboard");
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="flex min-h-dvh items-center justify-center bg-ink-50 px-4">
      <form onSubmit={submit} className="w-full max-w-md space-y-4 rounded-xl border border-ink-200 bg-white p-6 shadow-sm">
        <div className="flex items-center gap-3">
          <img src="/brand/tce-logo-64.png" alt="" className="size-10" />
          <div>
            <h1 className="text-lg font-semibold">Set a new password</h1>
            <p className="text-sm text-ink-500">
              {me?.must_change_password ? "You must choose your own password before continuing." : "Change your password."}
            </p>
          </div>
        </div>
        <ErrorNote error={error} />
        <Field label="Current password">
          <Input type="password" autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} required />
        </Field>
        <Field label="New password" hint="At least 10 characters. Avoid common words and your username.">
          <Input type="password" autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} required />
        </Field>
        <Field label="Confirm new password">
          <Input type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required />
        </Field>
        <div className="flex items-center justify-between pt-2">
          <Button type="button" variant="ghost" onClick={logout}>Sign out</Button>
          <Button type="submit" loading={busy}>Save password</Button>
        </div>
      </form>
    </main>
  );
}
