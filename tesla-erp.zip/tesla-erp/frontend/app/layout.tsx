import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Providers } from "./providers";

export const metadata: Metadata = {
  title: { default: "TCE ERP", template: "%s · TCE ERP" },
  description: "Tesla Consulting Engineers — ERP",
  icons: { icon: "/favicon.ico", apple: "/brand/tce-logo-192.png" },
  manifest: "/manifest.webmanifest",
};

export const viewport: Viewport = { themeColor: "#d90000", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-IN">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
