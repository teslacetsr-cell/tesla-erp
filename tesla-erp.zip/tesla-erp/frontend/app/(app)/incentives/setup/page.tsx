"use client";

import { useState } from "react";
import { Pencil, Plus, RotateCcw, Trash2, X } from "lucide-react";
import { Badge, Button, Card, Checkbox, ErrorNote, Field, Input, Modal, PageHeader, Select, Spinner, useConfirm } from "@/components/ui";
import { rateText, useAct, useInc } from "@/components/incentives/common";
import { api } from "@/lib/api/client";
import { useOptions } from "@/lib/hooks";
import { date } from "@/lib/format";

const TRI: Record<string, string> = { any: "Any", yes: "Yes", no: "No" };
const blankRule = (roleId: string) => ({ role_id: roleId, label: "", categories: ["*"], govt: "any", tender: "any", requires_ei_kseb: false, trigger: "billPaid", basis: "pct", value: "", is_active: true });

export default function Setup() {
  const q = useInc<any>("/incentives/setup");
  const { run, busy } = useAct();
  const confirm = useConfirm();
  const employees = useOptions("/employees");
  const [rule, setRule] = useState<any>(null);
  const [welfare, setWelfare] = useState<string | null>(null);
  const [months, setMonths] = useState<string | null>(null);
  const [newCat, setNewCat] = useState("");
  const [newRole, setNewRole] = useState("");
  const [add, setAdd] = useState<Record<string, string>>({});
  const d = q.data;
  const edit = d?.can_edit;
  const today = new Date().toISOString().slice(0, 10);
  const catName = (c: string) => (c === "*" ? "All categories" : d?.categories.find((x: any) => x.code === c)?.name ?? c);

  async function saveRule() {
    const body = { ...rule, value: rule.value || "0" };
    const ok = await run("rule", () => rule.id ? api(`/incentives/rules/${rule.id}`, { method: "PUT", body }) : api("/incentives/rules", { body }), "Rule saved");
    if (ok) setRule(null);
  }
  async function restore() {
    if (!(await confirm({ title: "Restore standard rates?", body: "The rules of the seven standard roles go back to the standard scheme and the welfare fund to 0.5%. Employee assignments, custom roles and custom categories are kept. Locked months are not affected.", confirmLabel: "Restore", danger: true }))) return;
    run("restore", () => api("/incentives/restore-standard", { method: "POST" }), "Standard rates restored");
  }

  return (
    <>
      <PageHeader title="Incentive setup" subtitle="Roles, who is in each role, the rates, project categories and the welfare fund."
        actions={edit && <Button variant="danger" icon={<RotateCcw className="size-4" />} loading={busy === "restore"} onClick={restore}>Restore standard rates</Button>} />
      {q.error ? <ErrorNote error={q.error} /> : !d ? <Spinner /> : (
        <div className="grid gap-4 xl:grid-cols-[1fr_320px]">
          <div className="space-y-4">
            {d.roles.map((r: any) => (
              <Card key={r.id} title={<>{r.name} {!r.is_active && <Badge>Inactive</Badge>}</>}
                actions={edit && <div className="flex gap-1">
                  <Button size="sm" variant="ghost" onClick={() => run(r.id, () => api(`/incentives/roles/${r.id}`, { method: "PUT", body: { name: r.name, is_active: !r.is_active } }))}>{r.is_active ? "Deactivate" : "Activate"}</Button>
                  <Button size="sm" variant="secondary" icon={<Plus className="size-3.5" />} onClick={() => setRule(blankRule(r.id))}>Rule</Button>
                </div>}>
                <div className="mb-3 flex flex-wrap items-center gap-1.5">
                  <span className="mr-1 text-xs text-ink-500">People:</span>
                  {r.members.length === 0 && <span className="text-xs text-ink-400">nobody yet</span>}
                  {r.members.map((m: any) => (
                    <span key={m.id} className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs ${m.is_active && m.employee_active ? "border-ink-200" : "border-dashed border-ink-200 text-ink-400"}`}>
                      {m.name}
                      {!m.joined ? <span className="text-amber-700" title="No date of joining in HR — treated as eligible">· no joining date</span>
                        : m.eligible_from > today ? <span className="text-amber-700" title={`Joined ${date(m.joined)}`}>· earns from {date(m.eligible_from)}</span> : null}
                      {edit && <button title={m.is_active ? "Mark inactive (keeps history)" : "Mark active"} className="text-ink-400 hover:text-ink-700" onClick={() => run(m.id, () => api(`/incentives/roles/${r.id}/members`, { body: { employee_id: m.employee_id, is_active: !m.is_active } }))}>{m.is_active ? "●" : "○"}</button>}
                      {edit && <button title="Remove" className="text-ink-400 hover:text-brand-700" onClick={() => run(m.id, () => api(`/incentives/members/${m.id}`, { method: "DELETE" }))}><X className="size-3" /></button>}
                    </span>
                  ))}
                  {edit && (
                    <span className="inline-flex items-center gap-1">
                      <Select className="h-7 py-0 text-xs" value={add[r.id] ?? ""} onChange={(e) => setAdd({ ...add, [r.id]: e.target.value })}>
                        <option value="">Add person…</option>
                        {(employees.data ?? []).filter((o: any) => !r.members.some((m: any) => m.employee_id === o.id)).map((o: any) => <option key={o.id} value={o.id}>{o.full_name} ({o.employee_code})</option>)}
                      </Select>
                      {add[r.id] && <Button size="sm" onClick={async () => { await run(r.id, () => api(`/incentives/roles/${r.id}/members`, { body: { employee_id: add[r.id], is_active: true } })); setAdd({ ...add, [r.id]: "" }); }}>Add</Button>}
                    </span>
                  )}
                </div>
                {r.rules.length === 0 ? <p className="text-xs text-ink-400">No rules.</p> : (
                  <table className="w-full text-xs">
                    <thead className="text-left text-ink-500"><tr><th className="py-1 pr-2">Rule</th><th className="py-1 pr-2">Categories</th><th className="py-1 pr-2">Conditions</th><th className="py-1 pr-2">When</th><th className="py-1 pr-2 text-right">Rate</th><th /></tr></thead>
                    <tbody>
                      {r.rules.map((x: any) => (
                        <tr key={x.id} className={`border-t border-ink-100 ${x.is_active ? "" : "text-ink-400"}`}>
                          <td className="py-1.5 pr-2 font-medium">{x.label}</td>
                          <td className="py-1.5 pr-2">{x.categories.map(catName).join(", ")}</td>
                          <td className="py-1.5 pr-2">{[x.govt !== "any" && `Govt: ${TRI[x.govt]}`, x.tender !== "any" && `Tender: ${TRI[x.tender]}`, x.requires_ei_kseb && "EI & KSEB"].filter(Boolean).join(" · ") || "—"}</td>
                          <td className="py-1.5 pr-2">{d.triggers[x.trigger]}</td>
                          <td className="num py-1.5 pr-2 text-right">{rateText(x.basis, x.value)}</td>
                          <td className="whitespace-nowrap py-1.5 text-right">{edit && <>
                            <button className="p-1 text-ink-400 hover:text-ink-700" title="Edit" onClick={() => setRule({ ...x })}><Pencil className="size-3.5" /></button>
                            <button className="p-1 text-ink-400 hover:text-brand-700" title="Delete" onClick={async () => (await confirm({ title: `Delete “${x.label}”?`, body: "Locked months keep their figures.", confirmLabel: "Delete", danger: true })) && run(x.id, () => api(`/incentives/rules/${x.id}`, { method: "DELETE" }), "Rule deleted")}><Trash2 className="size-3.5" /></button>
                          </>}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </Card>
            ))}
            {edit && (
              <Card title="Add a role">
                <div className="flex gap-2"><Input value={newRole} onChange={(e) => setNewRole(e.target.value)} placeholder="e.g. Service engineer" />
                  <Button disabled={newRole.trim().length < 2} loading={busy === "role"} onClick={async () => { if (await run("role", () => api("/incentives/roles", { body: { name: newRole } }), "Role added")) setNewRole(""); }}>Add</Button></div>
              </Card>
            )}
          </div>

          <div className="space-y-4">
            <Card title="Eligibility">
              <p className="mb-2 text-sm text-ink-600">New employees earn incentives only on bills paid and milestones reached this many months after their date of joining (from HR).</p>
              <div className="flex items-end gap-2">
                <Field label="Months after joining"><Input inputMode="numeric" disabled={!edit} value={months ?? String(d.eligible_after_months)} onChange={(e) => setMonths(e.target.value.replace(/\D/g, ""))} /></Field>
                {edit && months !== null && months !== "" && Number(months) !== d.eligible_after_months && <Button loading={busy === "elig"} onClick={async () => { if (await run("elig", () => api("/incentives/eligibility", { method: "PUT", body: { months: Number(months) } }), "Eligibility updated")) setMonths(null); }}>Save</Button>}
              </div>
              <p className="mt-2 text-xs text-ink-500">Until then, they are left out of “All in role” shares; where they are the one person named on a project, that amount is not paid. Approved months don't change.</p>
            </Card>
            <Card title="Employee welfare fund">
              <p className="mb-2 text-sm text-ink-600">Set aside each month as a % of billing before GST (by bill date).</p>
              <div className="flex items-end gap-2">
                <Field label="Percent of billing"><Input inputMode="decimal" disabled={!edit} value={welfare ?? d.welfare_pct} onChange={(e) => setWelfare(e.target.value)} /></Field>
                {edit && welfare !== null && welfare !== d.welfare_pct && <Button loading={busy === "wf"} onClick={async () => { if (await run("wf", () => api("/incentives/welfare", { method: "PUT", body: { welfare_pct: welfare } }), "Welfare fund updated")) setWelfare(null); }}>Save</Button>}
              </div>
            </Card>
            <Card title="Project categories" padded={false}>
              <ul>
                {d.categories.map((c: any) => (
                  <li key={c.id} className={`flex items-center justify-between border-b border-ink-100 px-4 py-2 text-sm ${c.is_active ? "" : "text-ink-400"}`}>
                    <span>{c.name} <span className="text-xs text-ink-400">{c.code}</span></span>
                    {edit && <button className="text-xs text-ink-500 hover:underline" onClick={() => run(c.id, () => api(`/incentives/categories/${c.id}`, { method: "PUT", body: { name: c.name, is_active: !c.is_active } }))}>{c.is_active ? "Hide" : "Show"}</button>}
                  </li>
                ))}
              </ul>
              {edit && <div className="flex gap-2 p-3"><Input value={newCat} onChange={(e) => setNewCat(e.target.value)} placeholder="New category" />
                <Button disabled={newCat.trim().length < 2} loading={busy === "cat"} onClick={async () => { if (await run("cat", () => api("/incentives/categories", { body: { name: newCat } }), "Category added")) setNewCat(""); }}>Add</Button></div>}
            </Card>
          </div>
        </div>
      )}

      <Modal open={!!rule} wide onClose={() => setRule(null)} title={rule?.id ? "Edit rule" : "New rule"}
        footer={<><Button variant="secondary" onClick={() => setRule(null)}>Cancel</Button><Button loading={busy === "rule"} disabled={!rule?.label || rule?.value === ""} onClick={saveRule}>Save</Button></>}>
        {rule && d && (
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Name" className="sm:col-span-2"><Input value={rule.label} onChange={(e) => setRule({ ...rule, label: e.target.value })} placeholder="e.g. Solar projects" /></Field>
            <Field label="Role"><Select value={rule.role_id} onChange={(e) => setRule({ ...rule, role_id: e.target.value })}>{d.roles.map((r: any) => <option key={r.id} value={r.id}>{r.name}</option>)}</Select></Field>
            <Field label="When it is earned"><Select value={rule.trigger} onChange={(e) => setRule({ ...rule, trigger: e.target.value })}>{Object.entries(d.triggers).map(([k, v]) => <option key={k} value={k}>{v as string}</option>)}</Select></Field>
            <Field label="Calculated as"><Select value={rule.basis} onChange={(e) => setRule({ ...rule, basis: e.target.value })}><option value="pct">% of value before GST</option><option value="fixed">Fixed ₹ amount</option></Select></Field>
            <Field label={rule.basis === "pct" ? "Percent" : "Amount (₹)"}><Input inputMode="decimal" value={rule.value} onChange={(e) => setRule({ ...rule, value: e.target.value })} /></Field>
            <Field label="Government client"><Select value={rule.govt} onChange={(e) => setRule({ ...rule, govt: e.target.value })}>{Object.entries(TRI).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
            <Field label="From a tender"><Select value={rule.tender} onChange={(e) => setRule({ ...rule, tender: e.target.value })}>{Object.entries(TRI).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
            <div className="sm:col-span-2">
              <p className="mb-1 text-xs font-medium text-ink-700">Project categories</p>
              <div className="flex flex-wrap gap-x-4 gap-y-1">
                <Checkbox label="All categories" checked={rule.categories.includes("*")} onChange={(e) => setRule({ ...rule, categories: e.target.checked ? ["*"] : [] })} />
                {d.categories.filter((c: any) => c.is_active).map((c: any) => (
                  <Checkbox key={c.code} label={c.name} disabled={rule.categories.includes("*")} checked={rule.categories.includes(c.code)}
                    onChange={(e) => setRule({ ...rule, categories: e.target.checked ? [...rule.categories, c.code] : rule.categories.filter((x: string) => x !== c.code) })} />
                ))}
              </div>
            </div>
            <Checkbox label="Only when EI & KSEB documentation is in our scope" checked={rule.requires_ei_kseb} onChange={(e) => setRule({ ...rule, requires_ei_kseb: e.target.checked })} />
            <Checkbox label="Active" checked={rule.is_active} onChange={(e) => setRule({ ...rule, is_active: e.target.checked })} />
          </div>
        )}
      </Modal>
    </>
  );
}
