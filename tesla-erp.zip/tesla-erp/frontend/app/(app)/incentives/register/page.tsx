"use client";

import { Fragment, useState } from "react";
import { ChevronDown, ChevronRight, Download, FileText, Lock, Unlock } from "lucide-react";
import { Badge, Button, Card, Checkbox, EmptyState, ErrorNote, Field, Input, Modal, PageHeader, Spinner, useConfirm } from "@/components/ui";
import { MonthPicker, monthLabel, rateText, thisMonth, useAct, useInc } from "@/components/incentives/common";
import { api, download, objectUrl } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";

const TRIGGER: Record<string, string> = { billPaid: "Bill paid", finalPaid: "Final bill paid", subsidy: "Subsidy done", monthly: "Monthly" };

export default function Register() {
  const { can } = useAuth();
  const confirm = useConfirm();
  const [ym, setYm] = useState(thisMonth());
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [pay, setPay] = useState<any>(null);
  const [payForm, setPayForm] = useState({ paid_on: new Date().toISOString().slice(0, 10), note: "" });
  const q = useInc<any>("/incentives/register", { ym });
  const { run, busy } = useAct();
  const r = q.data;
  const locked = r?.status === "locked";

  async function lock() {
    if (!(await confirm({ title: `Approve & lock ${monthLabel(ym)}?`, body: "The figures are saved as they are now. Later changes to bills, projects or rates will not change this month unless an administrator unlocks it.", confirmLabel: "Approve & lock" }))) return;
    run("lock", () => api(`/incentives/months/${ym}/lock`, { method: "POST" }), "Month approved and locked");
  }
  async function unlock() {
    if (!(await confirm({ title: `Unlock ${monthLabel(ym)}?`, body: "The saved snapshot is deleted and the month is recalculated from live data.", confirmLabel: "Unlock", danger: true }))) return;
    run("unlock", () => api(`/incentives/months/${ym}/unlock`, { method: "POST" }), "Month unlocked");
  }
  async function statement(empId: string) {
    const url = await objectUrl(`/incentives/statement/${empId}.pdf?ym=${ym}`);
    window.open(url, "_blank");
  }
  async function savePay() {
    const ok = await run("pay", () => api(`/incentives/months/${ym}/paid`, { body: { employee_id: pay.employee_id, ...payForm, note: payForm.note || null } }), "Marked paid out");
    if (ok) setPay(null);
  }

  return (
    <>
      <PageHeader title="Incentive register" subtitle="Every employee's incentive for the month, line by line. Amounts on bill values before GST."
        actions={<>
          <MonthPicker value={ym} onChange={setYm} />
          {can("incentive.export") && <>
            <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/incentives/register/export", `incentives-${ym}.xlsx`, { ym })}>Excel</Button>
            <Button variant="secondary" onClick={() => download("/incentives/register/export", `incentives-${ym}.csv`, { ym, fmt: "csv" })}>CSV</Button>
          </>}
        </>} />
      {q.error ? <ErrorNote error={q.error} /> : !r ? <Spinner /> : (
        <>
          <Card className="mb-4">
            <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
              <div><p className="text-xs text-ink-500">Status</p>{locked ? <Badge tone="green">Approved & locked {r.locked_at && date(r.locked_at)}</Badge> : <Badge tone="amber">Draft — updates live</Badge>}</div>
              <div><p className="text-xs text-ink-500">Total incentives</p><p className="num text-lg font-semibold">{inr(r.total)}</p></div>
              <div><p className="text-xs text-ink-500">Billed (before GST)</p><p className="num">{inr(r.billed, 0)}</p></div>
              <div><p className="text-xs text-ink-500">Welfare fund ({r.welfare_pct}%)</p><p className="num">{inr(r.welfare)}</p></div>
              {r.has_monthly_rule && (
                <div className="min-w-[14rem]">
                  <Checkbox label="All account statements are proper this month" checked={r.accounts_proper} disabled={locked || !r.can.accounts || busy === "acc"}
                    onChange={(e) => run("acc", () => api(`/incentives/months/${ym}/accounts`, { method: "PUT", body: { accounts_proper: e.target.checked } }))} />
                  <p className="text-xs text-ink-500">Needed for the accountant's monthly incentive.</p>
                </div>
              )}
              <div className="ml-auto flex gap-2">
                {!locked && r.can.approve && <Button icon={<Lock className="size-4" />} loading={busy === "lock"} onClick={lock}>Approve & lock</Button>}
                {locked && r.can.unlock && <Button variant="danger" icon={<Unlock className="size-4" />} loading={busy === "unlock"} onClick={unlock}>Unlock</Button>}
              </div>
            </div>
          </Card>

          <Card padded={false}>
            {r.employees.length === 0 ? <EmptyState title="No incentives this month" body="Incentives appear when bills are paid in full, final bills are settled or subsidy milestones are reached." /> : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-ink-50 text-left text-xs text-ink-500"><tr><th className="px-3 py-2">Employee</th><th className="px-3 py-2">Lines</th><th className="px-3 py-2 text-right">Amount</th><th className="px-3 py-2">Paid out</th><th className="px-3 py-2" /></tr></thead>
                  <tbody>
                    {r.employees.map((g: any) => (
                      <Fragment key={g.employee_id}>
                        <tr className="cursor-pointer border-t border-ink-100 hover:bg-ink-50" onClick={() => setOpen({ ...open, [g.employee_id]: !open[g.employee_id] })}>
                          <td className="px-3 py-2"><div className="flex items-center gap-1.5">{open[g.employee_id] ? <ChevronDown className="size-4 text-ink-400" /> : <ChevronRight className="size-4 text-ink-400" />}<div><p className="font-medium">{g.name}</p><p className="text-xs text-ink-500">{g.roles.join(", ")}</p></div></div></td>
                          <td className="px-3 py-2 text-ink-600">{g.lines.length}</td>
                          <td className="num px-3 py-2 text-right font-semibold">{inr(g.total)}</td>
                          <td className="px-3 py-2">{g.paid ? <Badge tone="green">Paid {date(g.paid.paid_on)}</Badge> : locked ? <Badge>Not yet</Badge> : <span className="text-xs text-ink-400">after locking</span>}</td>
                          <td className="whitespace-nowrap px-3 py-2 text-right" onClick={(e) => e.stopPropagation()}>
                            <div className="flex justify-end gap-1">
                              <Button size="sm" variant="ghost" icon={<FileText className="size-3.5" />} onClick={() => statement(g.employee_id)}>Statement</Button>
                              {locked && r.can.approve && !g.paid && <Button size="sm" variant="secondary" onClick={() => setPay(g)}>Mark paid</Button>}
                              {locked && r.can.approve && g.paid && <Button size="sm" variant="ghost" loading={busy === g.employee_id} onClick={() => run(g.employee_id, () => api(`/incentives/months/${ym}/paid/${g.employee_id}`, { method: "DELETE" }), "Paid-out mark removed")}>Undo paid</Button>}
                            </div>
                          </td>
                        </tr>
                        {open[g.employee_id] && (
                          <tr className="bg-ink-50/60"><td colSpan={5} className="px-3 pb-3 pt-1">
                            <table className="w-full text-xs">
                              <thead className="text-left text-ink-500"><tr><th className="py-1 pr-2">Project / client</th><th className="py-1 pr-2">Basis</th><th className="py-1 pr-2">Scheme</th><th className="py-1 pr-2 text-right">Base</th><th className="py-1 pr-2 text-right">Rate</th><th className="py-1 pr-2 text-right">Split</th><th className="py-1 text-right">Amount</th></tr></thead>
                              <tbody>
                                {g.lines.map((ln: any, i: number) => (
                                  <tr key={i} className="border-t border-ink-100">
                                    <td className="py-1 pr-2"><p>{ln.project}</p><p className="text-ink-500">{ln.client}</p></td>
                                    <td className="py-1 pr-2">{ln.ref}<p className="text-ink-500">{TRIGGER[ln.trigger]}{ln.date && ` · ${date(ln.date)}`}</p></td>
                                    <td className="py-1 pr-2">{ln.rule}<p className="text-ink-500">{ln.role_name}</p></td>
                                    <td className="num py-1 pr-2 text-right">{Number(ln.base) ? inr(ln.base, 0) : "—"}</td>
                                    <td className="num py-1 pr-2 text-right">{rateText(ln.basis, ln.rate)}</td>
                                    <td className="num py-1 pr-2 text-right">{ln.split > 1 ? `÷${ln.split}` : ""}</td>
                                    <td className="num py-1 text-right font-medium">{inr(ln.amount)}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </td></tr>
                        )}
                      </Fragment>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </>
      )}
      <Modal open={!!pay} onClose={() => setPay(null)} title={`Mark paid out — ${pay?.name ?? ""}`}
        footer={<><Button variant="secondary" onClick={() => setPay(null)}>Cancel</Button><Button loading={busy === "pay"} onClick={savePay}>Save</Button></>}>
        <div className="space-y-3">
          <p className="text-sm text-ink-600">{monthLabel(ym)} incentive of <b className="num">{pay && inr(pay.total)}</b>. This records the date only; pay it through payroll or Accounts as usual.</p>
          <Field label="Paid on"><Input type="date" value={payForm.paid_on} onChange={(e) => setPayForm({ ...payForm, paid_on: e.target.value })} /></Field>
          <Field label="Note"><Input value={payForm.note} onChange={(e) => setPayForm({ ...payForm, note: e.target.value })} placeholder="e.g. with November salary" /></Field>
        </div>
      </Modal>
    </>
  );
}
