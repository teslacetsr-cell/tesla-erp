"use client";

import { useState } from "react";
import { Badge, Card, ErrorNote, PageHeader, Select, Spinner } from "@/components/ui";
import { monthLabel, useInc } from "@/components/incentives/common";
import { inr } from "@/lib/format";

function currentFy() {
  const d = new Date();
  return d.getMonth() >= 3 ? d.getFullYear() : d.getFullYear() - 1;
}

function Grid({ title, months, rows, total }: { title: string; months: string[]; rows: [string, string[]][]; total: string[] }) {
  const sum = (xs: string[]) => xs.reduce((a, x) => a + Number(x || 0), 0);
  return (
    <Card title={title} padded={false} className="mb-4">
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead className="bg-ink-50 text-ink-500"><tr><th className="px-3 py-2 text-left">Category</th>{months.map((m) => <th key={m} className="px-2 py-2 text-right">{monthLabel(m, true)}</th>)}<th className="px-3 py-2 text-right">Year</th></tr></thead>
          <tbody>
            {rows.filter(([, v]) => sum(v) > 0).map(([name, v]) => (
              <tr key={name} className="border-t border-ink-100"><td className="px-3 py-1.5">{name}</td>{v.map((x, i) => <td key={i} className="num px-2 py-1.5 text-right">{Number(x) ? inr(x, 0) : ""}</td>)}<td className="num px-3 py-1.5 text-right font-medium">{inr(sum(v), 0)}</td></tr>
            ))}
            <tr className="border-t border-ink-200 bg-ink-50 font-semibold"><td className="px-3 py-1.5">Total</td>{total.map((x, i) => <td key={i} className="num px-2 py-1.5 text-right">{Number(x) ? inr(x, 0) : ""}</td>)}<td className="num px-3 py-1.5 text-right">{inr(sum(total), 0)}</td></tr>
          </tbody>
        </table>
      </div>
    </Card>
  );
}

export default function Reports() {
  const [fy, setFy] = useState(currentFy());
  const q = useInc<any>("/incentives/reports", { fy });
  const d = q.data;
  const byCat = (series: any[]) => (d.categories as any[]).map((c) => [c.name, series.map((m) => m.by[c.code] ?? "0")] as [string, string[]]);
  return (
    <>
      <PageHeader title="Monthly reports" subtitle="Billing, collections, incentives and welfare fund across the financial year (April–March), before GST."
        actions={<Select value={fy} onChange={(e) => setFy(Number(e.target.value))}>{Array.from({ length: 6 }, (_, i) => currentFy() - i).map((y) => <option key={y} value={y}>FY {y}-{String(y + 1).slice(2)}</option>)}</Select>} />
      {q.error ? <ErrorNote error={q.error} /> : !d ? <Spinner /> : (
        <>
          <Grid title="Billing by category (bill date)" months={d.months} rows={byCat(d.billing)} total={d.billing.map((m: any) => m.total)} />
          <Grid title="Collections by category (bills paid in full, by payment date)" months={d.months} rows={byCat(d.collections)} total={d.collections.map((m: any) => m.total)} />
          <Card title="Incentives and welfare fund" padded={false}>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-ink-50 text-ink-500"><tr><th className="px-3 py-2 text-left" />{d.months.map((m: string) => <th key={m} className="px-2 py-2 text-right">{monthLabel(m, true)}</th>)}<th className="px-3 py-2 text-right">Year</th></tr></thead>
                <tbody>
                  {([["Incentives", d.incentives], [`Welfare fund`, d.welfare]] as [string, string[]][]).map(([name, v]) => (
                    <tr key={name} className="border-t border-ink-100"><td className="px-3 py-1.5 font-medium">{name}</td>{v.map((x, i) => <td key={i} className="num px-2 py-1.5 text-right">{Number(x) ? inr(x, 0) : ""}</td>)}<td className="num px-3 py-1.5 text-right font-semibold">{inr(v.reduce((a, x) => a + Number(x), 0), 0)}</td></tr>
                  ))}
                  <tr className="border-t border-ink-100"><td className="px-3 py-1.5 text-ink-500">Status</td>{d.status.map((s: string, i: number) => <td key={i} className="px-2 py-1.5 text-right">{s === "locked" ? <Badge tone="green">Locked</Badge> : ""}</td>)}<td /></tr>
                </tbody>
              </table>
            </div>
          </Card>
        </>
      )}
    </>
  );
}
