"use client";

import Link from "next/link";
import { useState } from "react";
import { Badge, Button, Card, EmptyState, ErrorNote, Field, Input, Modal, PageHeader, Spinner } from "@/components/ui";
import { useAct, useInc } from "@/components/incentives/common";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";

const today = () => new Date().toISOString().slice(0, 10);

export default function FollowUp() {
  const { can } = useAuth();
  const q = useInc<any>("/incentives/followup");
  const { run, busy } = useAct();
  const [dlg, setDlg] = useState<{ kind: "paid" | "part"; bill: any } | null>(null);
  const [form, setForm] = useState({ date: today(), amount: "", note: "" });
  const d = q.data;

  function open(kind: "paid" | "part", bill: any) {
    setForm({ date: today(), amount: kind === "part" ? "" : bill.total, note: "" });
    setDlg({ kind, bill });
  }
  async function save() {
    if (!dlg) return;
    const id = dlg.bill.invoice_id;
    const body = dlg.kind === "paid"
      ? { paid_date: form.date, amount: form.amount || null, note: form.note || null }
      : { on: form.date, amount: form.amount, note: form.note || null };
    const r = await run("dlg", () => api(`/incentives/followup/${id}/${dlg.kind}`, { body }), dlg.kind === "paid" ? "Confirmed paid in full" : "Part payment noted");
    if (r) setDlg(null);
  }

  return (
    <>
      <PageHeader title="Payment follow-up" subtitle="Bills not yet paid in full, oldest first. Enter the receipt in Accounts when money arrives; use “Paid in full” only to confirm a payment Accounts has not entered yet." />
      {q.error ? <ErrorNote error={q.error} /> : !d ? <Spinner /> : (
        <div className="space-y-4">
          <Card title={`Open bills (${d.bills.length})`} padded={false}>
            {d.bills.length === 0 ? <EmptyState title="Every bill is paid in full" /> : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-ink-50 text-left text-xs text-ink-500">
                    <tr><th className="px-3 py-2">Bill</th><th className="px-3 py-2">Project / client</th><th className="px-3 py-2 text-right">Before GST</th><th className="px-3 py-2 text-right">Total · balance</th><th className="px-3 py-2">Age</th><th className="px-3 py-2">Status</th><th className="px-3 py-2" /></tr>
                  </thead>
                  <tbody>
                    {d.bills.map((b: any) => (
                      <tr key={b.invoice_id} className={`border-t border-ink-100 ${b.age_days > 60 ? "bg-brand-50/50" : ""}`}>
                        <td className="px-3 py-2"><Link className="font-medium text-brand-700 hover:underline" href={`/sales/invoices/view?id=${b.invoice_id}`}>{b.invoice_number}</Link><p className="text-xs text-ink-500">{date(b.bill_date)}{b.final && " · final bill"}</p></td>
                        <td className="px-3 py-2"><p>{b.project ?? <span className="text-ink-400">No project</span>}</p><p className="text-xs text-ink-500">{b.client}{b.category && ` · ${b.category}`}{b.is_govt && " · Govt"}</p></td>
                        <td className="num px-3 py-2 text-right">{inr(b.amount, 0)}</td>
                        <td className="num px-3 py-2 text-right">{inr(b.total, 0)}<p className="text-xs text-ink-500">due {inr(b.balance, 0)}</p></td>
                        <td className={`px-3 py-2 ${b.age_days > 60 ? "font-medium text-brand-700" : ""}`}>{b.age_days} days</td>
                        <td className="px-3 py-2">
                          {b.state === "partial" ? <Badge tone="amber">Part paid {b.part_amount && inr(b.part_amount, 0)}</Badge> : <Badge>Not yet</Badge>}
                          {b.last_checked && <p className="text-xs text-ink-500">checked {date(b.last_checked)}</p>}
                          {b.note && <p className="max-w-[16rem] truncate text-xs text-ink-500" title={b.note}>{b.note}</p>}
                        </td>
                        <td className="whitespace-nowrap px-3 py-2 text-right">
                          <div className="flex justify-end gap-1">
                            {can("receipt.create") && <Link href={`/finance/receipts/new?customer_id=${b.customer_id}`}><Button size="sm" variant="secondary">Enter receipt</Button></Link>}
                            <Button size="sm" variant="secondary" onClick={() => open("paid", b)}>Paid in full</Button>
                            <Button size="sm" variant="ghost" onClick={() => open("part", b)}>Part paid</Button>
                            <Button size="sm" variant="ghost" loading={busy === b.invoice_id} onClick={() => run(b.invoice_id, () => api(`/incentives/followup/${b.invoice_id}/not-yet`, { body: {} }), "Marked as checked")}>Not yet</Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          <Card title={`Solar subsidy & final documents pending (${d.subsidy.length})`} padded={false}>
            {d.subsidy.length === 0 ? <p className="px-4 py-4 text-sm text-ink-500">Nothing pending.</p> : (
              <table className="w-full text-sm"><tbody>
                {d.subsidy.map((s: any) => (
                  <tr key={s.project_id} className="border-t border-ink-100 first:border-0">
                    <td className="px-4 py-2"><Link className="font-medium hover:underline" href={`/projects/view?id=${s.project_id}`}>{s.project}</Link><p className="text-xs text-ink-500">{s.client}</p></td>
                    <td className="num px-4 py-2 text-right">{inr(s.value, 0)}</td>
                    <td className="px-4 py-2 text-right"><Button size="sm" variant="secondary" loading={busy === s.project_id} onClick={() => run(s.project_id, () => api(`/incentives/projects/${s.project_id}/subsidy`, { body: {} }), "Subsidy milestone recorded")}>Yes, done</Button></td>
                  </tr>
                ))}
              </tbody></table>
            )}
          </Card>

          {d.manually_confirmed.length > 0 && (
            <Card title="Confirmed paid by hand (no receipt entered yet)" padded={false}>
              <table className="w-full text-sm"><tbody>
                {d.manually_confirmed.map((m: any) => (
                  <tr key={m.invoice_id} className="border-t border-ink-100 first:border-0">
                    <td className="px-4 py-2 font-medium">{m.invoice_number}</td>
                    <td className="px-4 py-2">paid {date(m.paid_date)}</td>
                    <td className="num px-4 py-2 text-right">{m.amount && inr(m.amount, 0)}</td>
                    <td className="px-4 py-2 text-right"><Button size="sm" variant="ghost" loading={busy === m.invoice_id} onClick={() => run(m.invoice_id, () => api(`/incentives/followup/${m.invoice_id}/reopen`, { body: {} }), "Confirmation removed")}>Undo</Button></td>
                  </tr>
                ))}
              </tbody></table>
            </Card>
          )}
        </div>
      )}

      <Modal open={!!dlg} onClose={() => setDlg(null)} title={dlg?.kind === "paid" ? `Paid in full — ${dlg?.bill.invoice_number}` : `Part paid — ${dlg?.bill.invoice_number}`}
        footer={<><Button variant="secondary" onClick={() => setDlg(null)}>Cancel</Button><Button loading={busy === "dlg"} onClick={save}>Save</Button></>}>
        <div className="space-y-3">
          {dlg?.kind === "paid" && <p className="text-sm text-ink-600">Incentives on this bill will count in the month of this date. Accounts should still enter the receipt.</p>}
          <Field label={dlg?.kind === "paid" ? "Date paid in full" : "Date"}><Input type="date" value={form.date} max={today()} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Field>
          <Field label={dlg?.kind === "paid" ? "Amount received (incl. GST)" : "Amount received so far"}><Input inputMode="decimal" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></Field>
          <Field label="Note"><Input value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} placeholder="e.g. client confirmed NEFT" /></Field>
        </div>
      </Modal>
    </>
  );
}
