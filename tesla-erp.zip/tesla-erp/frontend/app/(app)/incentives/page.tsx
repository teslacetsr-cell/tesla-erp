"use client";

import Link from "next/link";
import { useState } from "react";
import { Badge, Card, ErrorNote, PageHeader, Spinner } from "@/components/ui";
import { Kpi, MonthPicker, monthLabel, thisMonth, useInc } from "@/components/incentives/common";
import { inr } from "@/lib/format";

export default function IncentiveDashboard() {
  const [ym, setYm] = useState(thisMonth());
  const q = useInc<any>("/incentives/dashboard", { ym });
  const d = q.data;
  const max = d ? Math.max(1, ...d.categories.map((c: any) => Math.max(Number(c.billed), Number(c.collected)))) : 1;
  return (
    <>
      <PageHeader title="Incentives" subtitle="Billing, collections and incentives for the month — all amounts before GST."
        actions={<MonthPicker value={ym} onChange={setYm} />} />
      {q.error ? <ErrorNote error={q.error} /> : !d ? <Spinner /> : (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Kpi label={`Billed in ${monthLabel(ym)}`} value={inr(d.billed, 0)} sub={`${d.billed_count} bill${d.billed_count === 1 ? "" : "s"}`} />
            <Kpi label="Collected (bills paid in full)" value={inr(d.collected, 0)} sub={`${d.collected_count} bill${d.collected_count === 1 ? "" : "s"}`} />
            <Kpi label="Incentives this month" value={inr(d.incentives, 0)} sub={d.status === "locked" ? <Badge tone="green">Approved & locked</Badge> : <Badge tone="amber">Draft</Badge>} />
            <Kpi label={`Welfare fund (${d.welfare_pct}% of billing)`} value={inr(d.welfare, 0)} sub={`${inr(d.welfare_fy, 0)} so far this financial year`} />
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3 lg:grid-cols-3">
            <Link href="/incentives/followup"><Kpi label="Outstanding (before GST)" value={inr(d.outstanding, 0)} sub={`${d.open_bills} bills not yet paid in full →`} tone={d.open_bills ? "amber" : undefined} /></Link>
            <Link href="/incentives/followup"><Kpi label="Solar subsidy pending" value={d.pending_subsidy} sub="projects awaiting subsidy / final docs →" tone={d.pending_subsidy ? "amber" : undefined} /></Link>
            <Link href="/incentives/register" className="col-span-2 lg:col-span-1"><Kpi label="Register" value={d.status === "locked" ? "Locked" : "Open"} sub="Review, approve & lock, mark paid →" /></Link>
          </div>
          <div className="mt-4 grid gap-4 lg:grid-cols-2">
            <Card title="By project category">
              {d.categories.length === 0 ? <p className="text-sm text-ink-500">No billing this month.</p> : (
                <ul className="space-y-3">
                  {d.categories.map((c: any) => (
                    <li key={c.code ?? "none"}>
                      <div className="flex justify-between text-sm"><span>{c.name}</span><span className="num text-ink-600">{inr(c.billed, 0)} billed · {inr(c.collected, 0)} collected</span></div>
                      <div className="mt-1 h-2 rounded bg-ink-100"><div className="h-2 rounded bg-ink-300" style={{ width: `${(Number(c.billed) / max) * 100}%` }} /></div>
                      <div className="mt-0.5 h-2 rounded bg-ink-100"><div className="h-2 rounded bg-brand-600" style={{ width: `${(Number(c.collected) / max) * 100}%` }} /></div>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
            <Card title="Incentive by employee" padded={false}>
              <table className="w-full text-sm">
                <tbody>
                  {d.employees.length === 0 && <tr><td className="px-4 py-6 text-center text-ink-500">Nobody is assigned to an incentive role yet — see Setup.</td></tr>}
                  {d.employees.map((e: any) => (
                    <tr key={e.employee_id} className="border-b border-ink-100 last:border-0">
                      <td className="px-4 py-2"><p className="font-medium">{e.name}</p><p className="text-xs text-ink-500">{e.roles.join(", ")}</p></td>
                      <td className="num px-4 py-2 text-right font-medium">{inr(e.amount, 0)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          </div>
        </>
      )}
    </>
  );
}
