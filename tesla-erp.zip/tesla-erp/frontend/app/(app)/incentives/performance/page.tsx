"use client";

import { useState } from "react";
import { Badge, Card, EmptyState, ErrorNote, Input, PageHeader, Select, Spinner } from "@/components/ui";
import { CRITERIA_LABEL, MonthPicker, thisMonth, useAct, useInc } from "@/components/incentives/common";
import { api } from "@/lib/api/client";
import { inr } from "@/lib/format";

const BAND_TONE: Record<string, "green" | "blue" | "grey" | "red"> = { Outstanding: "green", Strong: "blue", "Meets expectations": "grey", "Needs improvement": "red" };

export default function Performance() {
  const [ym, setYm] = useState(thisMonth());
  const q = useInc<any>("/incentives/performance", { ym });
  const { run } = useAct();
  const d = q.data;

  function save(e: any, patch: Record<string, any>) {
    const body = { ...e.ratings, remarks: e.remarks, ...patch };
    run(e.employee_id, () => api(`/incentives/performance/${ym}/${e.employee_id}`, { method: "PUT", body }));
  }

  return (
    <>
      <PageHeader title="Performance" subtitle="Monthly ratings from 1 (poor) to 5 (excellent) alongside each person's work and incentive."
        actions={<MonthPicker value={ym} onChange={setYm} />} />
      {q.error ? <ErrorNote error={q.error} /> : !d ? <Spinner /> : (
        <Card padded={false}>
          {d.employees.length === 0 ? <EmptyState title="Nobody to rate yet" body="Assign employees to incentive roles in Setup." /> : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-ink-50 text-left text-xs text-ink-500">
                  <tr><th className="px-3 py-2">Employee</th><th className="px-3 py-2 text-right">Projects · value</th><th className="px-3 py-2 text-right">Incentive (month · FY)</th>
                    {d.criteria.map((c: string) => <th key={c} className="px-2 py-2 text-center">{CRITERIA_LABEL[c]}</th>)}
                    <th className="px-3 py-2">Average</th><th className="px-3 py-2">Remarks</th></tr>
                </thead>
                <tbody>
                  {d.employees.map((e: any) => (
                    <tr key={e.employee_id} className="border-t border-ink-100">
                      <td className="px-3 py-2"><p className="font-medium">{e.name}</p><p className="text-xs text-ink-500">{e.roles.join(", ")}</p></td>
                      <td className="num px-3 py-2 text-right">{e.projects}<p className="text-xs text-ink-500">{inr(e.value, 0)}</p></td>
                      <td className="num px-3 py-2 text-right">{inr(e.incentive, 0)}<p className="text-xs text-ink-500">{inr(e.incentive_fy, 0)}</p></td>
                      {d.criteria.map((c: string) => (
                        <td key={c} className="px-1 py-2 text-center">
                          {d.can_rate ? (
                            <Select className="w-16" value={e.ratings[c] ?? ""} onChange={(ev) => save(e, { [c]: ev.target.value ? Number(ev.target.value) : null })}>
                              <option value="">–</option>{[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{n}</option>)}
                            </Select>
                          ) : <span className="num">{e.ratings[c] ?? "–"}</span>}
                        </td>
                      ))}
                      <td className="px-3 py-2">{e.average ? <><b className="num">{e.average}</b> <Badge tone={BAND_TONE[e.band]}>{e.band}</Badge></> : <span className="text-xs text-ink-400">rate all five</span>}</td>
                      <td className="px-3 py-2">
                        {d.can_rate ? <Input className="min-w-[12rem]" defaultValue={e.remarks ?? ""} key={`${ym}-${e.employee_id}-${e.remarks ?? ""}`} onBlur={(ev) => ev.target.value !== (e.remarks ?? "") && save(e, { remarks: ev.target.value || null })} placeholder="Remarks" />
                          : <span className="text-ink-600">{e.remarks}</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      )}
      <p className="mt-3 text-xs text-ink-500">Bands: 4.5 and above Outstanding · 3.5 Strong · 2.5 Meets expectations · below 2.5 Needs improvement.</p>
    </>
  );
}
