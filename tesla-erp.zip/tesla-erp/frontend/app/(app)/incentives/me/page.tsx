"use client";

import { useState } from "react";
import { FileText } from "lucide-react";
import { Badge, Button, Card, EmptyState, ErrorNote, PageHeader, Spinner } from "@/components/ui";
import { MonthPicker, monthLabel, rateText, thisMonth, useInc } from "@/components/incentives/common";
import { objectUrl } from "@/lib/api/client";
import { date, inr } from "@/lib/format";

export default function MyIncentive() {
  const [ym, setYm] = useState(thisMonth());
  const q = useInc<any>("/incentives/me", { ym });
  const d = q.data;
  async function pdf() {
    window.open(await objectUrl(`/incentives/statement/${d.employee.id}.pdf?ym=${ym}`), "_blank");
  }
  return (
    <>
      <PageHeader title="My incentive" subtitle="Your incentive statement. Draft months can still change until they are approved."
        actions={<><MonthPicker value={ym} onChange={setYm} />{d?.employee && <Button variant="secondary" icon={<FileText className="size-4" />} onClick={pdf}>Print statement</Button>}</>} />
      {q.error ? <ErrorNote error={q.error} /> : !d ? <Spinner /> : !d.employee ? <EmptyState title="No employee record" body="Your login is not linked to an employee record. Ask HR." /> : (
        <div className="grid gap-4 lg:grid-cols-[1fr_300px]">
          <Card title={<>{monthLabel(ym)} · <span className="num">{inr(d.total)}</span> {d.status === "locked" ? <Badge tone="green">Approved</Badge> : <Badge tone="amber">Draft</Badge>}</>} padded={false}>
            {d.lines.length === 0 ? <EmptyState title="No incentive this month" /> : (
              <table className="w-full text-sm">
                <thead className="bg-ink-50 text-left text-xs text-ink-500"><tr><th className="px-3 py-2">Project</th><th className="px-3 py-2">Basis</th><th className="px-3 py-2 text-right">Base</th><th className="px-3 py-2 text-right">Rate</th><th className="px-3 py-2 text-right">Amount</th></tr></thead>
                <tbody>
                  {d.lines.map((ln: any, i: number) => (
                    <tr key={i} className="border-t border-ink-100">
                      <td className="px-3 py-2"><p>{ln.project}</p><p className="text-xs text-ink-500">{ln.rule}</p></td>
                      <td className="px-3 py-2">{ln.ref}{ln.date && <p className="text-xs text-ink-500">{date(ln.date)}</p>}</td>
                      <td className="num px-3 py-2 text-right">{Number(ln.base) ? inr(ln.base, 0) : "—"}</td>
                      <td className="num px-3 py-2 text-right">{rateText(ln.basis, ln.rate)}{ln.split > 1 && <p className="text-xs text-ink-500">shared ÷{ln.split}</p>}</td>
                      <td className="num px-3 py-2 text-right font-medium">{inr(ln.amount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </Card>
          <Card title="This financial year" padded={false}>
            <table className="w-full text-sm"><tbody>
              {d.fy.map((m: any) => (
                <tr key={m.ym} className={`border-t border-ink-100 first:border-0 ${m.ym === ym ? "bg-ink-50" : ""}`}>
                  <td className="px-3 py-1.5"><button className="hover:underline" onClick={() => setYm(m.ym)}>{monthLabel(m.ym, true)}</button></td>
                  <td className="num px-3 py-1.5 text-right">{Number(m.amount) ? inr(m.amount, 0) : "—"}</td>
                  <td className="px-3 py-1.5 text-right">{m.paid_on ? <Badge tone="green">Paid</Badge> : m.status === "locked" ? <Badge>Approved</Badge> : null}</td>
                </tr>
              ))}
            </tbody></table>
          </Card>
          {d.roles.length > 0 && <p className="text-xs text-ink-500 lg:col-span-2">Your incentive roles: {d.roles.join(", ")}.</p>}
        </div>
      )}
    </>
  );
}
