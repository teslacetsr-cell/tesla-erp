"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, CalendarPlus, Lock, Pencil, Plus, SlidersHorizontal } from "lucide-react";
import { Badge, Button, Card, Detail, ErrorNote, Field, Input, Modal, PageHeader, Select, Spinner, StatusBadge, Textarea, useToast } from "@/components/ui";
import { RecordForm } from "@/components/record-form";
import { useEmployeeFields } from "@/components/hr/employee-fields";
import { AdjustDialog, ApplyLeaveDialog, BalancesTable, Totals } from "@/components/hr/common";
import { HistoryPanel } from "@/components/record-panels";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";

const DAYS: [string, string][] = [["mon", "Monday"], ["tue", "Tuesday"], ["wed", "Wednesday"], ["thu", "Thursday"], ["fri", "Friday"], ["sat", "Saturday"], ["sun", "Sunday"]];
const EMP_TYPES: [string, string][] = [["permanent", "Permanent"], ["probation", "Probation"], ["contract", "Contract"], ["trainee", "Trainee / intern"], ["consultant", "Consultant"]];

function EmployeeProfile() {
  const id = useSearchParams().get("id") ?? "";
  const qc = useQueryClient();
  const toast = useToast();
  const [editing, setEditing] = useState(false);
  const [privateEdit, setPrivateEdit] = useState(false);
  const [adjusting, setAdjusting] = useState(false);
  const [addSalary, setAddSalary] = useState(false);
  const auth = useAuth();
  const canAudit = auth.can("audit.read");
  const hrLeave = auth.me?.permissions["leave_request.update"] === "all";
  const [applying, setApplying] = useState(false);
  const key = ["/employees", id, "profile"];
  const { data: e, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api<any>(`/employees/${id}/profile`), select: (r) => r.data });
  const salary = useQuery({ queryKey: ["/employees", id, "salary"], queryFn: () => api<any>(`/employees/${id}/salary`), select: (r) => r.data as any[], enabled: !!e?.can.salary });
  const types = useQuery({ queryKey: ["/leave-types", "options"], queryFn: () => api<any>("/leave-types", { params: { page_size: 100 } }), select: (r) => r.data as any[], enabled: !!e?.can.adjust_leave || hrLeave });
  const fields = useEmployeeFields(id);
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/employees"] }); };
  if (isLoading) return <Spinner />;
  if (error || !e) return <ErrorNote error={error} />;
  const p = e.private;
  return (
    <>
      <PageHeader back={<Link href="/hr/employees" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Employees</Link>}
        title={<span className="flex items-center gap-2">{e.full_name} <StatusBadge status={e.is_active} /></span>}
        subtitle={[e.employee_code, e.designation, e.department, e.division].filter(Boolean).join(" · ")}
        actions={e.can.edit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>} />
      <div className="grid gap-4 lg:grid-cols-[1fr_380px]">
        <div className="space-y-4">
          <Card title="Employment">
            <Detail cols={3} items={[
              ["Reports to", e.reports_to ?? <span className="text-amber-700">Not set — leave goes to Managers</span>], ["Joined", date(e.date_of_joining)],
              ["Work email", e.email], ["Phone", e.phone],
              ...(p ? [["Type", EMP_TYPES.find(([k]) => k === p.employment_type)?.[1] ?? p.employment_type], ["Confirmed", date(p.confirmation_date)],
                ["Work location", p.work_location], ["Weekly off", (p.weekly_off ?? "sun").split(",").map((d: string) => DAYS.find(([k]) => k === d)?.[1]).join(", ")],
                ...(p.exit_date ? [["Left", `${date(p.exit_date)}${p.exit_reason ? ` · ${p.exit_reason}` : ""}`]] : [])] as [string, any][] : []),
            ]} />
            {e.team.length > 0 && <p className="mt-3 border-t border-ink-100 pt-3 text-sm"><span className="text-ink-500">Team: </span>{e.team.map((t: any, i: number) => <span key={t.id}>{i ? ", " : ""}<Link href={`/hr/employees/view?id=${t.id}`} className="text-brand-700 hover:underline">{t.name}</Link></span>)}</p>}
            {e.projects.length > 0 && <p className="mt-2 text-sm"><span className="text-ink-500">Open projects: </span>{e.projects.map((x: any, i: number) => <span key={x.id}>{i ? ", " : ""}<Link href={`/projects/view?id=${x.id}`} className="text-brand-700 hover:underline">{x.number}</Link></span>)}</p>}
          </Card>
          {p ? (
            <Card title={<span className="flex items-center gap-2"><Lock className="size-3.5 text-ink-400" /> Personal & bank details</span>}
              actions={e.can.private && <Button size="sm" variant="ghost" icon={<Pencil className="size-3.5" />} onClick={() => setPrivateEdit(true)}>Edit</Button>}>
              <Detail cols={3} items={[
                ["Date of birth", date(p.date_of_birth)], ["Gender", p.gender], ["Blood group", p.blood_group], ["Marital status", p.marital_status],
                ["Personal email", p.personal_email], ["Emergency contact", [p.emergency_contact_name, p.emergency_contact_relation, p.emergency_contact_phone].filter(Boolean).join(" · ")],
                ["Current address", p.current_address], ["Permanent address", p.permanent_address], ["PAN", p.pan],
                ["Bank", [p.bank_name, p.bank_ifsc].filter(Boolean).join(" · ")], ["Account name", p.bank_account_name], ["Account no.", p.bank_account_number],
              ]} />
              <p className="mt-2 text-xs text-ink-500">Visible only to HR, Directors and the employee. PAN and bank account are stored encrypted.</p>
            </Card>
          ) : null}
          {e.can.salary && (
            <Card title={<span className="flex items-center gap-2"><Lock className="size-3.5 text-ink-400" /> Salary (confidential)</span>} padded={false}
              actions={e.can.salary_add && <Button size="sm" icon={<Plus className="size-3.5" />} onClick={() => setAddSalary(true)}>New salary record</Button>}>
              {salary.isLoading ? <Spinner /> : !salary.data?.length ? <p className="p-4 text-sm text-ink-500">No salary record yet. Labour cost to projects needs one.</p> : (
                <table className="w-full text-sm">
                  <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500"><th className="px-3 py-2">From</th><th className="px-3 py-2 text-right">Gross / month</th><th className="px-3 py-2 text-right">Net</th><th className="px-3 py-2 text-right">CTC / month</th><th className="px-3 py-2 text-right">Site day rate</th></tr></thead>
                  <tbody>{salary.data.map((s, i) => (
                    <tr key={s.id} className={`border-b border-ink-100 ${i ? "text-ink-500" : ""}`}>
                      <td className="px-3 py-2">{date(s.effective_from)} {i === 0 && <Badge tone="green">current</Badge>}{s.remarks && <p className="text-xs text-ink-500">{s.remarks}</p>}</td>
                      <td className="num px-3 py-2 text-right">{inr(s.gross, 0)}</td><td className="num px-3 py-2 text-right">{inr(s.net, 0)}</td>
                      <td className="num px-3 py-2 text-right">{inr(s.ctc_monthly, 0)}</td>
                      <td className="num px-3 py-2 text-right">{Number(s.components.labour_day_rate) ? inr(s.components.labour_day_rate, 0) : <span className="text-xs">from CTC</span>}</td>
                    </tr>))}</tbody>
                </table>
              )}
              <p className="px-3 py-2 text-xs text-ink-500">Stored encrypted; amounts never appear in the audit log or on project pages. A change is a new record from a date — earlier ones stay as history.</p>
            </Card>
          )}
          {canAudit && <HistoryPanel entityType="employee" entityId={id} />}
        </div>
        <div className="space-y-4">
          {e.attendance_month && <Card title="Attendance this month" actions={<Link href="/hr/attendance" className="text-sm text-brand-700 hover:underline">Register</Link>}><Totals t={e.attendance_month} /></Card>}
          {e.balances && (
            <Card title={`Leave ${new Date().getFullYear()}`} actions={<div className="flex gap-1">
              {hrLeave && types.data && <Button size="sm" variant="ghost" icon={<CalendarPlus className="size-3.5" />} onClick={() => setApplying(true)}>Apply</Button>}
              {e.can.adjust_leave && <Button size="sm" variant="ghost" icon={<SlidersHorizontal className="size-3.5" />} onClick={() => setAdjusting(true)}>Adjust</Button>}</div>}>
              <BalancesTable balances={e.balances} />
            </Card>
          )}
        </div>
      </div>
      <RecordForm open={editing} title="Edit employee" fields={fields} initial={e} onClose={() => setEditing(false)}
        onSave={async (v) => { await api(`/employees/${id}`, { method: "PUT", body: { ...v, row_version: e.row_version } }); toast("Employee saved"); setEditing(false); refresh(); }} />
      {privateEdit && p && <PrivateDialog id={id} initial={p} rowVersion={e.row_version} onClose={() => setPrivateEdit(false)} onSaved={() => { toast("Saved"); refresh(); }} />}
      {adjusting && types.data && <AdjustDialog emp={{ employee_id: id, name: e.full_name }} year={new Date().getFullYear()} types={types.data.filter((t) => t.is_active)} onClose={() => setAdjusting(false)} onSaved={() => { toast("Balance adjusted"); refresh(); }} />}
      {applying && types.data && <ApplyLeaveDialog employeeId={id} types={types.data.filter((t) => t.is_active)} onClose={() => setApplying(false)} onSaved={(r) => { toast(`${r.days} day(s) applied for ${e.full_name} — sent for approval`); refresh(); }} />}
      {addSalary && <SalaryDialog id={id} onClose={() => setAddSalary(false)} onSaved={() => { toast("Salary record added"); qc.invalidateQueries({ queryKey: ["/employees", id, "salary"] }); }} />}
    </>
  );
}

const PRIV_TEXT: [string, string, boolean?][] = [
  ["date_of_birth", "Date of birth (YYYY-MM-DD)"], ["blood_group", "Blood group"], ["personal_email", "Personal email"],
  ["emergency_contact_name", "Emergency contact"], ["emergency_contact_relation", "Relation"], ["emergency_contact_phone", "Emergency phone"],
  ["pan", "PAN"], ["bank_name", "Bank"], ["bank_ifsc", "IFSC"], ["bank_account_name", "Account name"], ["bank_account_number", "Account number"],
  ["confirmation_date", "Confirmation date (YYYY-MM-DD)"], ["work_location", "Work location"], ["exit_date", "Exit date (YYYY-MM-DD)"], ["exit_reason", "Exit reason"],
  ["current_address", "Current address", true], ["permanent_address", "Permanent address", true],
];

function PrivateDialog({ id, initial, rowVersion, onClose, onSaved }: { id: string; initial: any; rowVersion: number; onClose: () => void; onSaved: () => void }) {
  const [v, setV] = useState<Record<string, string>>(() => Object.fromEntries(Object.entries(initial).map(([k, x]) => [k, (x as string) ?? ""])));
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  const sel = (k: string, label: string, opts: [string, string][], blank = true) => (
    <Field label={label}><Select value={v[k] ?? ""} onChange={(e) => setV({ ...v, [k]: e.target.value })}>{blank && <option value="">—</option>}{opts.map(([a, b]) => <option key={a} value={a}>{b}</option>)}</Select></Field>
  );
  return (
    <Modal open onClose={onClose} title="Personal, bank & employment details" wide
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setError(null); setBusy(true);
        try {
          const body: Record<string, any> = Object.fromEntries(Object.entries(v).map(([k, x]) => [k, typeof x === "string" ? x.trim() || null : x]));
          body.pan = body.pan?.toUpperCase() ?? null; body.bank_ifsc = body.bank_ifsc?.toUpperCase() ?? null; body.weekly_off = body.weekly_off ?? "sun"; body.employment_type = body.employment_type ?? "permanent";
          await api(`/employees/${id}/private`, { method: "PUT", body: { ...body, row_version: rowVersion } }); onSaved(); onClose();
        } catch (e) { setError(e); } finally { setBusy(false); }
      }}>Save</Button></>}>
      <ErrorNote error={error} />
      <div className="grid gap-3 sm:grid-cols-3">
        {sel("gender", "Gender", [["male", "Male"], ["female", "Female"], ["other", "Other"]])}
        {sel("marital_status", "Marital status", [["single", "Single"], ["married", "Married"], ["other", "Other"]])}
        {sel("employment_type", "Employment type", EMP_TYPES, false)}
        {sel("weekly_off", "Weekly off", [["sun", "Sunday"], ["sat,sun", "Saturday & Sunday"], ["fri", "Friday"], ["mon", "Monday"]], false)}
        {PRIV_TEXT.map(([k, label, area]) => (
          <Field key={k} label={label} className={area ? "sm:col-span-3" : ""}>{area ? <Textarea rows={2} value={v[k] ?? ""} onChange={(e) => setV({ ...v, [k]: e.target.value })} /> : <Input value={v[k] ?? ""} onChange={(e) => setV({ ...v, [k]: e.target.value })} />}</Field>
        ))}
      </div>
    </Modal>
  );
}

const SAL: [string, string][][] = [
  [["basic", "Basic"], ["hra", "HRA"], ["conveyance", "Conveyance"], ["special_allowance", "Special allowance"], ["other_allowance", "Other allowance"]],
  [["employee_pf", "Employee PF"], ["employee_esi", "Employee ESI"], ["professional_tax", "Professional tax"], ["tds", "TDS"], ["other_deduction", "Other deduction"]],
  [["employer_pf", "Employer PF"], ["employer_esi", "Employer ESI"], ["gratuity", "Gratuity"], ["other_employer", "Other employer cost"]],
];

function SalaryDialog({ id, onClose, onSaved }: { id: string; onClose: () => void; onSaved: () => void }) {
  const [v, setV] = useState<Record<string, string>>({ effective_from: new Date().toISOString().slice(0, 8) + "01", remarks: "", labour_day_rate: "" });
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  const n = (k: string) => Number(v[k] || 0);
  const gross = SAL[0].reduce((s, [k]) => s + n(k), 0);
  const ded = SAL[1].reduce((s, [k]) => s + n(k), 0);
  const emp = SAL[2].reduce((s, [k]) => s + n(k), 0);
  const inp = (k: string, label: string) => <Field key={k} label={label}><Input inputMode="decimal" className="num" value={v[k] ?? ""} onChange={(e) => setV({ ...v, [k]: e.target.value })} /></Field>;
  return (
    <Modal open onClose={onClose} title="New salary record (monthly)" wide
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setError(null); setBusy(true);
        try { await api(`/employees/${id}/salary`, { body: Object.fromEntries(Object.entries(v).filter(([, x]) => x !== "").map(([k, x]) => [k, x.trim()])) }); onSaved(); onClose(); }
        catch (e) { setError(e); } finally { setBusy(false); }
      }}>Save</Button></>}>
      <ErrorNote error={error} />
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Effective from" required><Input type="date" value={v.effective_from} onChange={(e) => setV({ ...v, effective_from: e.target.value })} /></Field>
        <Field label="Remarks"><Input value={v.remarks} onChange={(e) => setV({ ...v, remarks: e.target.value })} placeholder="Annual increment" /></Field>
      </div>
      {["Earnings", "Deductions", "Employer contributions"].map((t, i) => (
        <div key={t} className="mt-4"><p className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-500">{t}</p><div className="grid gap-3 sm:grid-cols-5">{SAL[i].map(([k, l]) => inp(k, l))}</div></div>
      ))}
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <Field label="Site labour day rate (₹)" hint="Optional. Used for project labour cost; blank = monthly CTC ÷ working days.">
          <Input inputMode="decimal" className="num" value={v.labour_day_rate} onChange={(e) => setV({ ...v, labour_day_rate: e.target.value })} /></Field>
        <div className="rounded-md bg-ink-50 p-3 text-sm"><p>Gross <b className="num">{inr(gross, 0)}</b> · Net <b className="num">{inr(gross - ded, 0)}</b></p><p>CTC <b className="num">{inr(gross + emp, 0)}</b> / month · <b className="num">{inr((gross + emp) * 12, 0)}</b> / year</p></div>
      </div>
    </Modal>
  );
}

export default function Page() {
  return <Suspense><EmployeeProfile /></Suspense>;
}
