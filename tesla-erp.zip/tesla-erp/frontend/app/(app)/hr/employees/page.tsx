"use client";

import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, UserSquare2 } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Spinner, StatusBadge, useToast } from "@/components/ui";
import { RecordForm } from "@/components/record-form";
import { useEmployeeFields } from "@/components/hr/employee-fields";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function EmployeesPage() {
  const { can } = useAuth();
  const list = useList<any>("/employees");
  const [editing, setEditing] = useState<any | "new" | null>(null);
  const qc = useQueryClient();
  const toast = useToast();
  const router = useRouter();
  const fields = useEmployeeFields(editing && editing !== "new" ? editing.id : undefined);
  return (
    <>
      <PageHeader title="Employees" subtitle="Employee records, reporting lines, personal and bank details, leave and salary. Open a person to see their profile."
        actions={can("employee.create") && <Button icon={<Plus className="size-4" />} onClick={() => setEditing("new")}>New employee</Button>} />
      <Card padded={false}>
        <div className="border-b border-ink-100 p-3"><Input placeholder="Search name, code, email, phone…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" /></div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/hr/employees/view?id=${r.id}`)}
            empty={<EmptyState icon={<UserSquare2 className="size-8" />} title="No employees found" />}
            columns={[
              { key: "n", header: "Employee", sortKey: "full_name", cell: (r) => <div><p className="font-medium">{r.full_name}</p><p className="text-xs text-ink-500">{r.employee_code}</p></div> },
              { key: "d", header: "Department", cell: (r) => r.department ?? "—" },
              { key: "g", header: "Designation", hideOnMobile: true, cell: (r) => r.designation ?? "—" },
              { key: "v", header: "Division", hideOnMobile: true, cell: (r) => r.division ?? "—" },
              { key: "j", header: "Joined", sortKey: "date_of_joining", hideOnMobile: true, cell: (r) => date(r.date_of_joining) },
              { key: "s", header: "Status", cell: (r) => <StatusBadge status={r.is_active} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
      <RecordForm open={editing !== null} title={editing === "new" ? "New employee" : "Edit employee"} fields={fields} initial={editing === "new" ? null : editing}
        onClose={() => setEditing(null)}
        onSave={async (v) => {
          if (editing === "new") await api("/employees", { body: v });
          else await api(`/employees/${editing.id}`, { method: "PUT", body: { ...v, row_version: editing.row_version } });
          toast("Employee saved");
          setEditing(null);
          qc.invalidateQueries({ queryKey: ["/employees"] });
        }} />
    </>
  );
}
