"use client";

import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, UserSquare2 } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Spinner, StatusBadge, useToast } from "@/components/ui";
import { RecordForm, type FieldDef } from "@/components/record-form";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date } from "@/lib/format";
import { useList, useOptions } from "@/lib/hooks";

export default function EmployeesPage() {
  const { can } = useAuth();
  const list = useList<any>("/employees");
  const depts = useOptions("/departments");
  const desigs = useOptions("/designations");
  const divs = useOptions("/divisions");
  const users = useOptions("/users", can("user.read"));
  const [editing, setEditing] = useState<any | "new" | null>(null);
  const qc = useQueryClient();
  const toast = useToast();
  const opt = (rows: any[] | undefined, label: (r: any) => string): [string, string][] => [["", "—"], ...(rows ?? []).map((r) => [r.id, label(r)] as [string, string])];
  const fields: FieldDef[] = [
    { name: "full_name", label: "Full name", required: true, span: 2 },
    { name: "employee_code", label: "Employee code", hint: "Leave blank to auto-number", upper: true },
    { name: "date_of_joining", label: "Date of joining (YYYY-MM-DD)" },
    { name: "email", label: "Work email" }, { name: "phone", label: "Phone" },
    { name: "department_id", label: "Department", type: "select", options: opt(depts.data, (d) => d.name) },
    { name: "designation_id", label: "Designation", type: "select", options: opt(desigs.data, (d) => d.name) },
    { name: "division_id", label: "Division", type: "select", options: opt(divs.data, (d) => d.name) },
    ...(can("user.read") ? [{ name: "user_id", label: "ERP user login", type: "select" as const, options: opt(users.data, (u) => `${u.full_name} (${u.username})`) }] : []),
    { name: "is_active", label: "Active", type: "checkbox" },
  ];
  return (
    <>
      <PageHeader title="Employees" subtitle="Basic employee records. Attendance, leave, salary and documents arrive in Phase 8."
        actions={can("employee.create") && <Button icon={<Plus className="size-4" />} onClick={() => setEditing("new")}>New employee</Button>} />
      <Card padded={false}>
        <div className="border-b border-ink-100 p-3"><Input placeholder="Search name, code, email, phone…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" /></div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={can("employee.update") ? (r) => setEditing(r) : undefined}
            empty={<EmptyState icon={<UserSquare2 className="size-8" />} title="No employees found" />}
            columns={[
              { key: "n", header: "Employee", sortKey: "full_name", cell: (r) => <div><p className="font-medium">{r.full_name}</p><p className="text-xs text-ink-500">{r.employee_code}</p></div> },
              { key: "d", header: "Department", cell: (r) => r.department ?? "—" },
              { key: "g", header: "Designation", hideOnMobile: true, cell: (r) => r.designation ?? "—" },
              { key: "j", header: "Joined", sortKey: "date_of_joining", hideOnMobile: true, cell: (r) => date(r.date_of_joining) },
              { key: "s", header: "Status", cell: (r) => <StatusBadge status={r.is_active} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
      <RecordForm open={editing !== null} title={editing === "new" ? "New employee" : "Edit employee"} fields={fields} initial={editing === "new" ? null : editing}
        onClose={() => setEditing(null)}
        onSave={async (v) => {
          if (editing === "new") await api("/employees", { body: v });
          else await api(`/employees/${editing.id}`, { method: "PUT", body: { ...v, row_version: editing.row_version } });
          toast("Employee saved");
          setEditing(null);
          qc.invalidateQueries({ queryKey: ["/employees"] });
        }} />
    </>
  );
}
