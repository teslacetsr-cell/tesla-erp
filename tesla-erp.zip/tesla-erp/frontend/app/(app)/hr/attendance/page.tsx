"use client";

import Link from "next/link";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, HardHat } from "lucide-react";
import { Button, Card, ErrorNote, Field, Input, Modal, PageHeader, Select, Spinner, Textarea, useToast } from "@/components/ui";
import { ATT_STATUSES, ATT_STYLE, attLabel, MonthPicker, thisMonth, time } from "@/components/hr/common";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";

export default function AttendancePage() {
  const { can, me } = useAuth();
  const all = me?.permissions["attendance.read"] === "all";
  const canMark = me?.permissions["attendance.update"] === "all";
  const [month, setMonth] = useState(thisMonth());
  const [marking, setMarking] = useState<{ row: any; cell: any } | null>(null);
  const qc = useQueryClient();
  const toast = useToast();
  const reg = useQuery({ queryKey: ["/attendance/register", month], queryFn: () => api<any>("/attendance/register", { params: { month } }), select: (r) => r.data });
  const today = useQuery({ queryKey: ["/attendance/today"], queryFn: () => api<any>("/attendance/today"), select: (r) => r.data, enabled: all });
  return (
    <>
      <PageHeader title="Attendance" subtitle={all ? "Everyone's month at a glance. Staff check in from their phone (My attendance & leave); HR marks and corrects here." : "Your month. Check in and out from My attendance & leave."}
        actions={<>
          <Link href="/hr/me"><Button variant="secondary">My attendance & leave</Button></Link>
          {all && can("attendance.export") && <Button variant="ghost" icon={<Download className="size-4" />} onClick={() => download("/attendance/register/export", `attendance-${month}.xlsx`, { month })}>Export</Button>}
        </>} />
      {today.data && (
        <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-5">
          {[["Employees", today.data.employees], ["Present today", today.data.present], ["Half day", today.data.half_day], ["On leave", today.data.on_leave], ["Not marked yet", today.data.not_marked]].map(([l, v]) => (
            <Card key={l as string}><p className="text-xs text-ink-500">{l}</p><p className="num mt-1 text-xl font-semibold">{v}</p></Card>
          ))}
          {today.data.on_leave_today?.length > 0 && <p className="col-span-full -mt-1 text-xs text-ink-500">On leave today: {today.data.on_leave_today.map((x: any) => `${x.name} (${x.type}, till ${date(x.until)})`).join(" · ")}</p>}
        </div>
      )}
      <Card padded={false} title="Register" actions={<MonthPicker value={month} onChange={setMonth} />}>
        {reg.isLoading || !reg.data ? <Spinner /> : reg.error ? <ErrorNote error={reg.error} /> : (
          <div className="overflow-x-auto">
            <table className="text-xs">
              <thead><tr className="border-b border-ink-200 text-ink-500">
                <th className="sticky left-0 z-10 bg-white px-2 py-1.5 text-left">Employee</th>
                {reg.data.dates.map((d: string) => { const wd = new Date(`${d}T00:00:00`).getDay(); return <th key={d} className={`w-7 px-0.5 py-1.5 text-center font-normal ${wd === 0 ? "text-brand-700" : ""}`} title={reg.data.holidays[d] ?? ""}>{Number(d.slice(8))}</th>; })}
                <th className="px-2 py-1.5 text-right">P</th><th className="px-2 py-1.5 text-right">L</th><th className="px-2 py-1.5 text-right">A</th><th className="px-2 py-1.5 text-right" title="Not marked">?</th>
              </tr></thead>
              <tbody>{reg.data.rows.map((r: any) => (
                <tr key={r.employee_id} className="border-b border-ink-100">
                  <td className="sticky left-0 z-10 whitespace-nowrap bg-white px-2 py-1">{all ? <Link href={`/hr/employees/view?id=${r.employee_id}`} className="hover:underline">{r.name}</Link> : r.name}</td>
                  {r.days.map((c: any) => {
                    const future = c.date > new Date().toISOString().slice(0, 10);
                    const cls = c.status ? ATT_STYLE[c.status] : "";
                    const title = `${r.name} · ${date(c.date)}: ${attLabel(c.status)}${c.in ? ` · in ${time(c.in)}` : ""}${c.out ? ` · out ${time(c.out)}` : ""}${c.hours ? ` · ${c.hours} h` : ""}${c.project ? ` · ${c.project}` : ""}${c.located ? " · location captured" : ""}`;
                    return (
                      <td key={c.date} className="p-0.5 text-center">
                        {canMark && !future ? (
                          <button type="button" title={title} onClick={() => setMarking({ row: r, cell: c })} className={`h-6 w-6 rounded ${cls || "text-ink-300 hover:bg-ink-100"}`}>{c.code || "·"}</button>
                        ) : <span title={title} className={`inline-flex h-6 w-6 items-center justify-center rounded ${cls}`}>{c.code}</span>}
                      </td>
                    );
                  })}
                  <td className="num px-2 text-right font-medium">{r.totals.present}</td><td className="num px-2 text-right">{r.totals.leave}</td>
                  <td className="num px-2 text-right">{r.totals.absent}</td><td className={`num px-2 text-right ${r.totals.unmarked ? "text-amber-700" : ""}`}>{r.totals.unmarked}</td>
                </tr>))}</tbody>
            </table>
          </div>
        )}
        <p className="px-3 py-2 text-xs text-ink-500">P present · ½ half day · L leave · OD on duty · A absent · H holiday · WO weekly off.{canMark ? " Click a day to mark or correct it." : ""}</p>
      </Card>
      {can("labour_cost.create") && <LabourCost month={month} />}
      {marking && <MarkDialog row={marking.row} cell={marking.cell} onClose={() => setMarking(null)} onSaved={() => { toast("Attendance saved"); qc.invalidateQueries({ queryKey: ["/attendance/register"] }); qc.invalidateQueries({ queryKey: ["/attendance/today"] }); }} />}
    </>
  );
}

function MarkDialog({ row, cell, onClose, onSaved }: { row: any; cell: any; onClose: () => void; onSaved: () => void }) {
  const projects = useQuery({ queryKey: ["/attendance/projects"], queryFn: () => api<any>("/attendance/projects"), select: (r) => r.data as any[], staleTime: 60_000 });
  const [v, setV] = useState({ status: cell.status && !["holiday", "weekly_off"].includes(cell.status) ? cell.status : "present", project_id: cell.project_id ?? "", remarks: "" });
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  return (
    <Modal open onClose={onClose} title={`${row.name} · ${date(cell.date)}`}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setError(null); setBusy(true);
        try { await api("/attendance/mark", { body: { employee_id: row.employee_id, att_date: cell.date, status: v.status, project_id: v.project_id || null, remarks: v.remarks.trim() || null } }); onSaved(); onClose(); }
        catch (e) { setError(e); } finally { setBusy(false); }
      }}>Save</Button></>}>
      <ErrorNote error={error} />
      {cell.in && <p className="mb-3 text-sm text-ink-600">Checked in {time(cell.in)}{cell.out ? `, out ${time(cell.out)}` : ""}{cell.hours ? ` (${cell.hours} h)` : ""}{cell.located ? " · location captured" : ""}. Check-in times are kept.</p>}
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Status"><Select value={v.status} onChange={(e) => setV({ ...v, status: e.target.value })}>{ATT_STATUSES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
        <Field label="Project site" hint="Days at a site are charged to the project as labour."><Select value={v.project_id} onChange={(e) => setV({ ...v, project_id: e.target.value })}>
          <option value="">None (office)</option>{(projects.data ?? []).map((p: any) => <option key={p.id} value={p.id}>{p.project_number} · {p.name}</option>)}</Select></Field>
        <Field label="Remarks" className="sm:col-span-2"><Textarea rows={2} value={v.remarks} onChange={(e) => setV({ ...v, remarks: e.target.value })} /></Field>
      </div>
    </Modal>
  );
}

function LabourCost({ month }: { month: string }) {
  const qc = useQueryClient();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const q = useQuery({ queryKey: ["/hr/labour-cost", month], queryFn: () => api<any>("/hr/labour-cost", { params: { month } }), select: (r) => r.data });
  return (
    <Card className="mt-4" padded={false} title={<span className="flex items-center gap-2"><HardHat className="size-4" /> Staff labour cost to projects · {month}</span>}
      actions={q.data?.rows.length > 0 && <Button size="sm" loading={busy} onClick={async () => {
        setBusy(true);
        try { const r = await api<any>("/hr/labour-cost/post", { body: { month } }); toast(`Posted ${inr(r.data.total, 0)} to ${r.data.rows.length} project(s)`); qc.invalidateQueries({ queryKey: ["/projects"] }); }
        catch (e: any) { toast(e.message, "error"); } finally { setBusy(false); }
      }}>Post to projects</Button>}>
      {q.isLoading || !q.data ? <Spinner /> : q.data.rows.length === 0 ? <p className="p-4 text-sm text-ink-500">No site days this month. Days count when staff check in at a project, or HR marks a day with a project.</p> : (
        <table className="w-full text-sm">
          <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500"><th className="px-3 py-2">Project</th><th className="px-3 py-2 text-right">People</th><th className="px-3 py-2 text-right">Man-days</th><th className="px-3 py-2 text-right">Cost</th></tr></thead>
          <tbody>{q.data.rows.map((r: any) => <tr key={r.project_id} className="border-b border-ink-100"><td className="px-3 py-2"><Link className="text-brand-700 hover:underline" href={`/projects/view?id=${r.project_id}&tab=costs`}>{r.project_number}</Link></td><td className="num px-3 py-2 text-right">{r.people}</td><td className="num px-3 py-2 text-right">{r.man_days}</td><td className="num px-3 py-2 text-right">{inr(r.amount, 0)}</td></tr>)}
            <tr><td className="px-3 py-2 font-medium" colSpan={3}>Total</td><td className="num px-3 py-2 text-right font-semibold">{inr(q.data.total, 0)}</td></tr></tbody>
        </table>
      )}
      <p className="px-3 py-2 text-xs text-ink-500">Each person&apos;s day rate comes from their salary record (labour day rate, else monthly CTC ÷ working days). Only the project totals are shown. Posting again replaces the month&apos;s figure — it never doubles.{q.data?.without_salary?.length ? ` No salary record yet for: ${q.data.without_salary.join(", ")}.` : ""}</p>
    </Card>
  );
}
