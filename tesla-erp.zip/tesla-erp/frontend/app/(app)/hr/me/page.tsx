"use client";

import Link from "next/link";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { CalendarPlus, LogIn, LogOut, MapPin, Pencil } from "lucide-react";
import { Button, Card, Checkbox, EmptyState, ErrorNote, Field, Input, Modal, PageHeader, Select, Spinner, Textarea, useToast } from "@/components/ui";
import { ApplyLeaveDialog, AttendanceCalendar, attLabel, BalancesTable, LeaveStatus, MonthPicker, thisMonth, time, Totals } from "@/components/hr/common";
import { api } from "@/lib/api/client";
import { date } from "@/lib/format";

type Geo = { lat?: string; lng?: string; accuracy_m?: number; note?: string };

function locate(enabled: boolean): Promise<Geo> {
  if (!enabled || typeof navigator === "undefined" || !navigator.geolocation) return Promise.resolve({ note: "no location" });
  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({ lat: p.coords.latitude.toFixed(6), lng: p.coords.longitude.toFixed(6), accuracy_m: Math.round(p.coords.accuracy) }),
      () => resolve({ note: "location not allowed" }),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 },
    );
  });
}

export default function MyHrPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [month, setMonth] = useState(thisMonth());
  const [busy, setBusy] = useState<string | null>(null);
  const [applying, setApplying] = useState(false);
  const [editing, setEditing] = useState(false);
  const [checkin, setCheckin] = useState({ project_id: "", on_duty: false, remarks: "" });
  const me = useQuery({ queryKey: ["/hr/me"], queryFn: () => api<any>("/hr/me"), select: (r) => r.data });
  const cal = useQuery({ queryKey: ["/hr/me/attendance", month], queryFn: () => api<any>("/hr/me/attendance", { params: { month } }), select: (r) => r.data.rows[0], enabled: !!me.data?.employee });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/hr/me"] }); qc.invalidateQueries({ queryKey: ["/hr/me/attendance"] }); };
  if (me.isLoading) return <Spinner />;
  if (me.error) return <ErrorNote error={me.error} />;
  const d = me.data;
  if (!d.employee) return <><PageHeader title="My attendance & leave" /><Card><EmptyState title="Your login is not linked to an employee record" body="Ask HR to link your user to your employee record." /></Card></>;
  const t = d.today;

  async function punch(kind: "in" | "out") {
    setBusy(kind);
    try {
      const g = await locate(d.gps);
      const body = { lat: g.lat ?? null, lng: g.lng ?? null, accuracy_m: g.accuracy_m ?? null,
        ...(kind === "in" ? { project_id: checkin.project_id || null, on_duty: checkin.on_duty, remarks: checkin.remarks.trim() || null } : {}) };
      const r = await api<any>(`/hr/me/check-${kind}`, { body });
      toast(`${kind === "in" ? "Checked in" : "Checked out"} at ${time(r.data[kind === "in" ? "check_in_at" : "check_out_at"])}${g.note ? ` (${g.note})` : ""}`);
      refresh();
    } catch (e: any) { toast(e.message, "error"); } finally { setBusy(null); }
  }

  return (
    <>
      <PageHeader title={`Hello, ${d.employee.full_name.split(" ")[0]}`} subtitle={`${d.employee.employee_code}${d.employee.designation ? ` · ${d.employee.designation}` : ""}${d.employee.department ? ` · ${d.employee.department}` : ""}`}
        actions={d.can.apply_leave && <Button icon={<CalendarPlus className="size-4" />} onClick={() => setApplying(true)}>Apply leave</Button>} />
      <div className="grid gap-4 lg:grid-cols-[1fr_380px]">
        <div className="space-y-4">
          <Card title={`Today · ${date(new Date().toISOString())}`}>
            {d.is_holiday || d.is_weekly_off ? <p className="mb-3 text-sm text-ink-600">{d.is_holiday ? "Today is a holiday." : "Today is your weekly off."} You can still check in if you are working.</p> : null}
            {t?.status === "on_leave" ? <p className="text-sm">You are on approved leave today.</p> : !t?.check_in_at ? (
              d.can.check_in && (
                <div className="space-y-3">
                  <div className="grid gap-3 sm:grid-cols-2">
                    <Field label="Working at (optional)" hint="Pick the project site to charge your day to it.">
                      <Select value={checkin.project_id} onChange={(e) => setCheckin({ ...checkin, project_id: e.target.value })}>
                        <option value="">Office / no project</option>{d.projects.map((p: any) => <option key={p.id} value={p.id}>{p.number} · {p.name}</option>)}
                      </Select>
                    </Field>
                    <Field label="Note"><Input value={checkin.remarks} onChange={(e) => setCheckin({ ...checkin, remarks: e.target.value })} /></Field>
                  </div>
                  <Checkbox label="On duty away from office (client visit, travel)" checked={checkin.on_duty} onChange={(e) => setCheckin({ ...checkin, on_duty: e.target.checked })} />
                  <Button className="h-11 w-full px-6 text-base sm:w-auto" icon={<LogIn className="size-5" />} loading={busy === "in"} onClick={() => punch("in")}>Check in</Button>
                  {d.gps && <p className="flex items-center gap-1 text-xs text-ink-500"><MapPin className="size-3.5" /> Your phone&apos;s location is recorded with the check-in when you allow it.</p>}
                </div>
              )
            ) : (
              <div className="flex flex-wrap items-center gap-6">
                <div><p className="text-xs text-ink-500">Checked in</p><p className="num text-xl font-semibold">{time(t.check_in_at)}</p>{t.located && <p className="text-xs text-emerald-700">location captured</p>}</div>
                <div><p className="text-xs text-ink-500">Checked out</p><p className="num text-xl font-semibold">{time(t.check_out_at)}</p></div>
                {t.work_hours && <div><p className="text-xs text-ink-500">Hours</p><p className="num text-xl font-semibold">{t.work_hours}</p></div>}
                <div><p className="text-xs text-ink-500">Status</p><p className="font-medium">{attLabel(t.status)}</p></div>
                {!t.check_out_at && <Button className="h-11 px-6 text-base" variant="secondary" icon={<LogOut className="size-5" />} loading={busy === "out"} onClick={() => punch("out")}>Check out</Button>}
              </div>
            )}
          </Card>
          <Card title="My attendance" actions={<MonthPicker value={month} onChange={setMonth} />}>
            {cal.isLoading || !cal.data ? <Spinner /> : <><AttendanceCalendar row={cal.data} /><div className="mt-3 border-t border-ink-100 pt-3"><Totals t={cal.data.totals} /></div></>}
            <p className="mt-2 text-xs text-ink-500">P present · ½ half day · L leave · OD on duty · A absent · H holiday · WO weekly off · ⦿ location captured. If a day is wrong, ask HR to correct it.</p>
          </Card>
        </div>
        <div className="space-y-4">
          <Card title={`Leave balance ${new Date().getFullYear()}`}><BalancesTable balances={d.balances} /></Card>
          <Card title="My leave requests" padded={false} actions={<Link href="/hr/leave" className="text-sm text-brand-700 hover:underline">All</Link>}>
            {d.leave.length === 0 ? <p className="p-4 text-sm text-ink-500">None yet.</p> : (
              <ul className="divide-y divide-ink-100">{d.leave.map((l: any) => (
                <li key={l.id}><Link href={`/hr/leave/view?id=${l.id}`} className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-ink-50">
                  <span><b>{l.leave_type_code}</b> {date(l.from_date)}{l.to_date !== l.from_date ? ` – ${date(l.to_date)}` : ""} <span className="text-ink-500">· {l.days} day(s)</span></span>
                  <span className="ml-auto"><LeaveStatus status={l.status} /></span></Link></li>))}</ul>
            )}
          </Card>
          <Card title="Upcoming holidays">
            {d.holidays.length === 0 ? <p className="text-sm text-ink-500">None in the next 90 days.</p> : (
              <ul className="space-y-1 text-sm">{d.holidays.map((h: any) => <li key={h.date} className="flex justify-between"><span>{h.name}{h.optional ? <span className="text-xs text-ink-500"> (optional)</span> : ""}</span><span className="text-ink-500">{date(h.date)}</span></li>)}</ul>
            )}
          </Card>
          <Card title="My contact details" actions={<Button size="sm" variant="ghost" icon={<Pencil className="size-3.5" />} onClick={() => setEditing(true)}>Edit</Button>}>
            <dl className="space-y-1 text-sm">
              {[["Personal email", d.private.personal_email], ["Blood group", d.private.blood_group], ["Emergency contact", [d.private.emergency_contact_name, d.private.emergency_contact_relation, d.private.emergency_contact_phone].filter(Boolean).join(" · ")], ["Current address", d.private.current_address]].map(([k, v]) => (
                <div key={k as string} className="flex gap-2"><dt className="w-36 shrink-0 text-ink-500">{k}</dt><dd className="whitespace-pre-line">{v || "—"}</dd></div>
              ))}
            </dl>
            <p className="mt-2 text-xs text-ink-500">Bank, PAN and other details are kept by HR.</p>
          </Card>
        </div>
      </div>
      {applying && <ApplyLeaveDialog types={d.leave_types} onClose={() => setApplying(false)} onSaved={(r) => { toast(`${r.days} day(s) applied — sent for approval`); refresh(); }} />}
      {editing && <ContactDialog initial={d.private} onClose={() => setEditing(false)} onSaved={() => { toast("Saved"); refresh(); }} />}
    </>
  );
}

const CONTACT = ["personal_email", "blood_group", "emergency_contact_name", "emergency_contact_relation", "emergency_contact_phone", "current_address", "permanent_address"] as const;

function ContactDialog({ initial, onClose, onSaved }: { initial: any; onClose: () => void; onSaved: () => void }) {
  const [v, setV] = useState<Record<string, string>>(() => Object.fromEntries(CONTACT.map((k) => [k, initial[k] ?? ""])));
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  const f = (k: string, label: string, area = false) => (
    <Field label={label} className={area ? "sm:col-span-2" : ""}>{area ? <Textarea rows={2} value={v[k]} onChange={(e) => setV({ ...v, [k]: e.target.value })} /> : <Input value={v[k]} onChange={(e) => setV({ ...v, [k]: e.target.value })} />}</Field>
  );
  return (
    <Modal open onClose={onClose} title="My contact details" wide
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setError(null); setBusy(true);
        try { await api("/hr/me/profile", { method: "PUT", body: Object.fromEntries(Object.entries(v).map(([k, x]) => [k, x.trim() || null])) }); onSaved(); onClose(); }
        catch (e) { setError(e); } finally { setBusy(false); }
      }}>Save</Button></>}>
      <ErrorNote error={error} />
      <div className="grid gap-3 sm:grid-cols-2">
        {f("personal_email", "Personal email")}{f("blood_group", "Blood group")}
        {f("emergency_contact_name", "Emergency contact name")}{f("emergency_contact_relation", "Relation")}
        {f("emergency_contact_phone", "Emergency contact phone")}<span />
        {f("current_address", "Current address", true)}{f("permanent_address", "Permanent address", true)}
      </div>
    </Modal>
  );
}
