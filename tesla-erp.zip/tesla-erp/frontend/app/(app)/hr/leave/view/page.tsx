"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, XCircle } from "lucide-react";
import { Button, Card, Detail, ErrorNote, PageHeader, Spinner, useToast } from "@/components/ui";
import { BalancesTable, LeaveStatus } from "@/components/hr/common";
import { ApprovalCard, ApprovalHistory, ReasonDialog } from "@/components/purchase/common";
import { api } from "@/lib/api/client";
import { date, dateTime } from "@/lib/format";

function LeaveDetail() {
  const id = useSearchParams().get("id") ?? "";
  const qc = useQueryClient();
  const toast = useToast();
  const [cancelling, setCancelling] = useState(false);
  const { data: l, isLoading, error } = useQuery({ queryKey: ["/leave-requests", id], queryFn: () => api<any>(`/leave-requests/${id}`), select: (r) => r.data });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/leave-requests"] }); qc.invalidateQueries({ queryKey: ["/hr/me"] }); qc.invalidateQueries({ queryKey: ["/approvals/inbox"] }); };
  if (isLoading) return <Spinner />;
  if (error || !l) return <ErrorNote error={error} />;
  return (
    <>
      <PageHeader back={<Link href="/hr/leave" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Leave</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{l.leave_type} · {l.employee} <LeaveStatus status={l.status} /></span>}
        subtitle={`${date(l.from_date)}${l.to_date !== l.from_date ? ` – ${date(l.to_date)}` : ""} · ${l.days} working day(s)${l.half_day !== "none" ? ` · ${l.half_day} half` : ""}`}
        actions={l.can.cancel && <Button variant="ghost" icon={<XCircle className="size-4" />} onClick={() => setCancelling(true)}>Cancel leave</Button>} />
      <ApprovalCard approval={l.approval} onDone={refresh} />
      {l.status_reason && <p className="mb-4 rounded-md border border-ink-200 bg-ink-50 px-3 py-2 text-sm"><b>{l.status === "rejected" ? "Rejected" : "Note"}:</b> {l.status_reason}</p>}
      <div className="grid gap-4 lg:grid-cols-[1fr_380px]">
        <div className="space-y-4">
          <Card><Detail cols={3} items={[["Employee", l.employee], ["Leave type", `${l.leave_type} (${l.leave_type_code})`], ["Days", l.days], ["From", date(l.from_date)], ["To", date(l.to_date)], ["Applied", dateTime(l.created_at)]]} />
            <p className="mt-3 border-t border-ink-100 pt-3 text-sm">{l.reason}</p></Card>
          <ApprovalHistory approvals={l.approvals} />
        </div>
        {l.balances && <Card title={`Balance ${l.from_date.slice(0, 4)}`}><BalancesTable balances={l.balances} /></Card>}
      </div>
      <ReasonDialog open={cancelling} title="Cancel this leave?" label="Reason" confirmLabel="Cancel leave" onClose={() => setCancelling(false)}
        onSubmit={async (reason) => { await api(`/leave-requests/${id}/cancel`, { body: { reason: reason || null } }); toast("Leave cancelled"); refresh(); }} />
    </>
  );
}

export default function Page() {
  return <Suspense><LeaveDetail /></Suspense>;
}
