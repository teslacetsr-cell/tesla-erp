"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { CalendarDays, CalendarPlus, Download, SlidersHorizontal } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner, Tabs, useToast } from "@/components/ui";
import { AdjustDialog, ApplyLeaveDialog, LEAVE_STATUSES, LeaveStatus } from "@/components/hr/common";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function LeavePage() {
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const { can, me: user } = useAuth();
  const all = user?.permissions["leave_request.read"] === "all";
  const hrMaster = can("hr_master.read");
  const [tab, setTab] = useState<"requests" | "balances">("requests");
  const [applying, setApplying] = useState(false);
  const list = useList<any>("/leave-requests", { filters: { status: all ? "pending" : "" } });
  const me = useQuery({ queryKey: ["/hr/me"], queryFn: () => api<any>("/hr/me"), select: (r) => r.data });
  return (
    <>
      <PageHeader title="Leave" subtitle={all ? "Everyone's leave requests. Approvals go to each person's reporting manager (Approvals inbox)." : "Your leave requests. They go to your reporting manager for approval."}
        actions={<>
          {can("leave_request.create") && me.data?.employee && <Button icon={<CalendarPlus className="size-4" />} onClick={() => setApplying(true)}>Apply leave</Button>}
        </>} />
      {hrMaster && <Tabs value={tab} onChange={setTab} tabs={[{ id: "requests", label: "Requests" }, { id: "balances", label: "Balances" }]} />}
      {tab === "requests" ? (
        <Card padded={false}>
          <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
            {all && <Input placeholder="Search employee or reason…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />}
            <Select value={list.filters.status ?? ""} onChange={(e) => list.setFilter("status", e.target.value)} className="sm:w-56" aria-label="Status">
              <option value="">All statuses</option>{LEAVE_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </Select>
          </div>
          {list.isLoading ? <Spinner /> : (
            <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/hr/leave/view?id=${r.id}`)}
              empty={<EmptyState icon={<CalendarDays className="size-8" />} title="No leave requests" />}
              columns={[
                ...(all ? [{ key: "e", header: "Employee", cell: (r: any) => r.employee }] : []),
                { key: "t", header: "Leave", cell: (r) => <div><p className="font-medium">{r.leave_type}</p><p className="text-xs text-ink-500">{r.reason}</p></div> },
                { key: "d", header: "Dates", sortKey: "from_date", cell: (r) => `${date(r.from_date)}${r.to_date !== r.from_date ? ` – ${date(r.to_date)}` : ""}${r.half_day !== "none" ? ` (${r.half_day} half)` : ""}` },
                { key: "n", header: "Days", cell: (r) => <span className="num">{r.days}</span> },
                { key: "s", header: "Status", cell: (r) => <LeaveStatus status={r.status} /> },
              ]} />
          )}
          {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
        </Card>
      ) : <BalanceReport canAdjust={can("hr_master.create")} />}
      {applying && me.data && <ApplyLeaveDialog types={me.data.leave_types} onClose={() => setApplying(false)}
        onSaved={(r) => { toast(`${r.days} day(s) applied — sent for approval`); qc.invalidateQueries({ queryKey: ["/leave-requests"] }); qc.invalidateQueries({ queryKey: ["/hr/me"] }); }} />}
    </>
  );
}

function BalanceReport({ canAdjust }: { canAdjust: boolean }) {
  const qc = useQueryClient();
  const toast = useToast();
  const [year, setYear] = useState(new Date().getFullYear());
  const [adjusting, setAdjusting] = useState<any | null>(null);
  const q = useQuery({ queryKey: ["/leave/balances/report", year], queryFn: () => api<any>("/leave/balances/report", { params: { year } }), select: (r) => r.data });
  const types = useQuery({ queryKey: ["/leave-types", "options"], queryFn: () => api<any>("/leave-types", { params: { page_size: 100 } }), select: (r) => r.data as any[] });
  if (q.isLoading || !q.data) return <Spinner />;
  return (
    <Card padded={false} title={`Leave balances ${year}`} actions={<div className="flex gap-2">
      <Select value={year} onChange={(e) => setYear(Number(e.target.value))} className="w-28" aria-label="Year">{[0, -1, 1].map((d) => new Date().getFullYear() + d).sort().map((y) => <option key={y} value={y}>{y}</option>)}</Select>
      <Button size="sm" variant="ghost" icon={<Download className="size-4" />} onClick={() => download("/leave/balances/export", `leave-balances-${year}.xlsx`, { year })}>Export</Button>
    </div>}>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500"><th className="px-3 py-2">Employee</th>
            {q.data.types.map((t: string) => <th key={t} className="px-3 py-2 text-right">{t} <span className="normal-case">taken / left</span></th>)}{canAdjust && <th />}</tr></thead>
          <tbody>{q.data.rows.map((r: any) => (
            <tr key={r.employee_id} className="border-b border-ink-100">
              <td className="px-3 py-2">{r.name} <span className="text-xs text-ink-500">{r.employee_code}</span></td>
              {q.data.types.map((t: string) => { const b = r.balances[t]; return <td key={t} className="num px-3 py-2 text-right">{Number(b.taken)}{Number(b.pending) ? <span className="text-amber-700"> +{Number(b.pending)}</span> : ""} / <b>{b.available != null ? Number(b.available) : "∞"}</b></td>; })}
              {canAdjust && <td className="px-3 py-2 text-right"><Button size="sm" variant="ghost" icon={<SlidersHorizontal className="size-3.5" />} onClick={() => setAdjusting(r)}>Adjust</Button></td>}
            </tr>))}</tbody>
        </table>
      </div>
      <p className="px-3 py-2 text-xs text-ink-500">Amber figures are waiting for approval. Use Adjust for opening balances, carry forward from last year or encashment.</p>
      {adjusting && types.data && <AdjustDialog emp={adjusting} year={year} types={types.data.filter((t) => t.is_active)} onClose={() => setAdjusting(null)}
        onSaved={() => { toast("Balance adjusted"); qc.invalidateQueries({ queryKey: ["/leave/balances/report"] }); }} />}
    </Card>
  );
}
