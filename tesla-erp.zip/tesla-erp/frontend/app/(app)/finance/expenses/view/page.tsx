"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, IndianRupee, Pencil, Send, Trash2, Undo2, XCircle } from "lucide-react";
import { Button, Card, Detail, ErrorNote, Field, Input, Modal, PageHeader, Select, Spinner, Tabs, useConfirm, useToast } from "@/components/ui";
import { ExpenseStatus, MODES } from "@/components/finance/common";
import { ExpenseForm } from "@/components/finance/expense-form";
import { ApprovalCard, ApprovalHistory, ReasonDialog } from "@/components/purchase/common";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api } from "@/lib/api/client";
import { date, inr } from "@/lib/format";

type Tab = "bill" | "approvals" | "history";

function PayDialog({ e, onClose, onDone }: { e: any; onClose: () => void; onDone: () => void }) {
  const [v, setV] = useState({ paid_at: new Date(Date.now() + 5.5 * 3600_000).toISOString().slice(0, 10), payment_mode: "neft", payment_reference: "" });
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  return (
    <Modal open onClose={onClose} title={`Pay ${inr(e.amount)} to ${e.employee}`} footer={<><Button variant="secondary" onClick={onClose}>Back</Button><Button loading={busy} onClick={async () => {
      setBusy(true);
      try { await api(`/expenses/${e.id}/pay`, { body: { ...v, payment_reference: v.payment_reference.trim() || null, row_version: e.row_version } }); onDone(); onClose(); }
      catch (err) { setError(err); } finally { setBusy(false); }
    }}>Mark as paid</Button></>}>
      <div className="space-y-4">
        <ErrorNote error={error} />
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Paid on"><Input type="date" value={v.paid_at} onChange={(x) => setV({ ...v, paid_at: x.target.value })} /></Field>
          <Field label="Mode"><Select value={v.payment_mode} onChange={(x) => setV({ ...v, payment_mode: x.target.value })}>{MODES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          <Field label="Reference"><Input value={v.payment_reference} onChange={(x) => setV({ ...v, payment_reference: x.target.value })} /></Field>
        </div>
      </div>
    </Modal>
  );
}

function ExpenseDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [tab, setTab] = useState<Tab>("bill");
  const [editing, setEditing] = useState(false);
  const [dialog, setDialog] = useState<"pay" | "cancel" | null>(null);
  const { data: e, isLoading, error } = useQuery({ queryKey: ["/expenses", id], queryFn: () => api<any>(`/expenses/${id}`), select: (r) => r.data });
  const refresh = () => { ["/expenses", "/expenses/summary", "/approvals/inbox", "/finance/dashboard"].forEach((k) => qc.invalidateQueries({ queryKey: [k] })); };
  if (isLoading) return <Spinner />;
  if (error || !e) return <ErrorNote error={error} />;
  const can = e.can;
  const act = async (path: string, msg: string) => {
    try { await api(`/expenses/${id}/${path}`, { body: { row_version: e.row_version } }); toast(msg); refresh(); } catch (x: any) { toast(x.message, "error"); }
  };
  if (editing)
    return (
      <div className="mx-auto max-w-3xl">
        <PageHeader title="Edit claim" />
        <ExpenseForm initial={e} submitLabel="Save" onCancel={() => setEditing(false)} onSubmit={async (body) => {
          await api(`/expenses/${id}`, { method: "PUT", body: { ...body, row_version: e.row_version } }); toast("Saved"); setEditing(false); refresh();
        }} />
      </div>
    );
  return (
    <>
      <PageHeader back={<Link href="/finance/expenses" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Expense claims</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{inr(e.amount)} · {e.category} <ExpenseStatus status={e.status} /></span>}
        subtitle={`${e.expense_number ?? "Draft"} · ${e.employee} · ${date(e.expense_date)}`}
        actions={<>
          {can.submit && <Button icon={<Send className="size-4" />} onClick={() => act("submit", "Submitted for approval")}>Submit</Button>}
          {can.pay && <Button icon={<IndianRupee className="size-4" />} onClick={() => setDialog("pay")}>Pay</Button>}
          {can.edit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {can.withdraw && <Button variant="secondary" icon={<Undo2 className="size-4" />} onClick={() => act("withdraw", "Withdrawn — back to draft")}>Withdraw</Button>}
          {can.cancel && e.expense_number && <Button variant="ghost" icon={<XCircle className="size-4" />} onClick={() => setDialog("cancel")}>Cancel</Button>}
          {can.delete && <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Delete this draft claim?", body: "It was never submitted.", confirmLabel: "Delete" }))) return;
            await api(`/expenses/${id}`, { method: "DELETE" }); refresh(); router.push("/finance/expenses");
          }}>Delete</Button>}
        </>} />
      <ApprovalCard approval={e.approval} onDone={refresh} />
      {e.last_rejection && e.status === "draft" && <p className="mb-4 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900"><b>Returned by the approver:</b> {e.last_rejection}</p>}
      {e.status === "cancelled" && <p className="mb-4 rounded-md bg-ink-100 px-3 py-2 text-sm"><b>Cancelled:</b> {e.status_reason}</p>}
      {e.status === "draft" && e.needs_receipt && !e.has_receipt && <p className="mb-4 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900">Attach a photo or PDF of the bill below, then submit.</p>}
      <Card className="mb-4">
        <Detail cols={4} items={[
          ["Employee", e.employee], ["Category", e.category], ["Date", date(e.expense_date)], ["Amount", inr(e.amount)],
          ["Project", e.project_id ? <Link key="p" href={`/projects/view?id=${e.project_id}`} className="text-brand-700 hover:underline">{e.project}</Link> : "—"],
          ["Bill no.", e.bill_reference], ["Description", e.description],
          ...(e.status === "paid" ? [["Paid", `${date(e.paid_at)} · ${e.payment_mode?.toUpperCase()}${e.payment_reference ? ` ${e.payment_reference}` : ""}${e.paid_by ? ` · by ${e.paid_by}` : ""}`] as [string, any]] : []),
        ]} />
      </Card>
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[{ id: "bill", label: "Bill / receipt" }, { id: "approvals", label: "Approvals", count: e.approvals.length }, { id: "history", label: "History" }]} />
      {tab === "bill" && <DocumentsPanel entityType="expense" entityId={id} canEdit={can.attach} defaultCategory="receipt" />}
      {tab === "approvals" && <ApprovalHistory approvals={e.approvals} />}
      {tab === "history" && <HistoryPanel entityType="expense" entityId={id} />}
      {dialog === "pay" && <PayDialog e={e} onClose={() => setDialog(null)} onDone={() => { toast("Marked as paid"); refresh(); }} />}
      <ReasonDialog open={dialog === "cancel"} title="Cancel this claim?" label="Reason" required confirmLabel="Cancel claim"
        onClose={() => setDialog(null)} onSubmit={async (reason) => { await api(`/expenses/${id}/cancel`, { body: { reason, row_version: e.row_version } }); toast("Claim cancelled"); refresh(); }} />
    </>
  );
}

export default function Page() {
  return <Suspense><ExpenseDetail /></Suspense>;
}
