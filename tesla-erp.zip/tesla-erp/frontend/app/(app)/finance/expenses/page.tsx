"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Download, Plus, Receipt } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { MiniStat } from "@/components/crm/common";
import { EXPENSE_STATUSES, ExpenseStatus } from "@/components/finance/common";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function ExpensesPage() {
  const router = useRouter();
  const { can, me } = useAuth();
  const all = me?.permissions["expense.read"] === "all";
  const list = useList<any>("/expenses");
  const s = useQuery({ queryKey: ["/expenses/summary"], queryFn: () => api<any>("/expenses/summary"), select: (r) => r.data }).data ?? {};
  const st = list.filters.status ?? "";
  return (
    <>
      <PageHeader title={all ? "Expense claims" : "My expense claims"} subtitle="Employee → Manager → Accounts → Paid. Attach the bill, submit, and Accounts pays once it is approved."
        actions={<>
          {can("expense.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/expenses/export", "expenses.xlsx", { q: list.q, status: st, mine: list.filters.mine })}>Expense report</Button>}
          {can("expense.create") && <Link href="/finance/expenses/new"><Button icon={<Plus className="size-4" />}>New claim</Button></Link>}
        </>} />
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <MiniStat label="Drafts" value={s.draft?.count ?? 0} onClick={() => list.setFilter("status", "draft")} active={st === "draft"} />
        <MiniStat label="Waiting for approval" value={s.submitted ? inr(s.submitted.amount, 0) : 0} tone="amber" onClick={() => list.setFilter("status", "submitted")} active={st === "submitted"} />
        <MiniStat label="Approved, to pay" value={s.approved ? inr(s.approved.amount, 0) : 0} tone="red" onClick={() => list.setFilter("status", "approved")} active={st === "approved"} />
        <MiniStat label="Paid" value={s.paid ? inr(s.paid.amount, 0) : 0} onClick={() => list.setFilter("status", "paid")} active={st === "paid"} />
      </div>
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search claim no., description, employee…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={st} onChange={(e) => list.setFilter("status", e.target.value)} className="sm:w-52" aria-label="Status">
            <option value="">All statuses</option>{EXPENSE_STATUSES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
          </Select>
          {all && <Select value={list.filters.mine ?? ""} onChange={(e) => list.setFilter("mine", e.target.value)} className="sm:w-40" aria-label="Whose"><option value="">Everyone</option><option value="true">Only mine</option></Select>}
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/finance/expenses/view?id=${r.id}`)}
            empty={<EmptyState icon={<Receipt className="size-8" />} title="No expense claims here" body="Claim travel, site and other expenses here — with a photo of the bill." />}
            columns={[
              { key: "n", header: "Claim", cell: (r) => <div><p className="font-medium text-ink-900">{r.description}</p><p className="text-xs text-ink-500">{[r.expense_number ?? "Draft", r.category, r.project].filter(Boolean).join(" · ")}</p></div> },
              ...(all ? [{ key: "e", header: "Employee", hideOnMobile: true, cell: (r: any) => r.employee }] : []),
              { key: "d", header: "Date", sortKey: "expense_date", hideOnMobile: true, cell: (r) => date(r.expense_date) },
              { key: "a", header: "Amount", sortKey: "amount", className: "text-right", cell: (r) => <span className="num">{inr(r.amount)}</span> },
              { key: "s", header: "Status", sortKey: "status", cell: (r) => <ExpenseStatus status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
