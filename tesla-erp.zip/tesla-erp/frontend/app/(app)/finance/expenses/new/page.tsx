"use client";

import { useRouter } from "next/navigation";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader, useToast } from "@/components/ui";
import { ExpenseForm } from "@/components/finance/expense-form";
import { api } from "@/lib/api/client";

export default function NewExpense() {
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title="New expense claim" subtitle="Save it, attach the bill, then submit for approval." />
      <ExpenseForm submitLabel="Save and attach bill" onCancel={() => router.back()} onSubmit={async (body) => {
        const r = await api<any>("/expenses", { body });
        toast("Claim saved — attach the bill and submit");
        qc.invalidateQueries({ queryKey: ["/expenses"] });
        router.push(`/finance/expenses/view?id=${r.data.id}`);
      }} />
    </div>
  );
}
