"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader, useToast } from "@/components/ui";
import { BillForm } from "@/components/finance/bill-form";
import { api } from "@/lib/api/client";

function NewBill() {
  const poId = useSearchParams().get("po");
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title="Enter supplier bill" subtitle="Save as draft, then post. A bill that differs from the PO or GRN goes for approval first." />
      <BillForm poId={poId} submitLabel="Save draft" onCancel={() => router.back()} onSubmit={async (body) => {
        const r = await api<any>("/supplier-invoices", { body });
        toast(r.data.mismatch ? "Draft saved — it differs from the PO/GRN and will need approval" : "Draft saved");
        qc.invalidateQueries({ queryKey: ["/supplier-invoices"] });
        router.push(`/finance/bills/view?id=${r.data.id}`);
      }} />
    </div>
  );
}

export default function Page() {
  return <Suspense><NewBill /></Suspense>;
}
