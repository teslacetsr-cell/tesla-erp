"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Download, FileStack, Plus } from "lucide-react";
import { Badge, Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { MiniStat } from "@/components/crm/common";
import { BillStatus, PayStatus, useDashboard } from "@/components/finance/common";
import { download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function BillsPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/supplier-invoices");
  const d = useDashboard(can("payable.read")).data;
  const f = list.filters;
  const view = f.overdue === "true" ? "overdue" : f.outstanding === "true" ? "outstanding" : f.status ?? "";
  const setView = (v: string) => {
    list.setFilter("overdue", v === "overdue" ? "true" : "");
    list.setFilter("outstanding", v === "outstanding" ? "true" : "");
    list.setFilter("status", ["draft", "pending_approval", "posted", "cancelled"].includes(v) ? v : "");
  };
  return (
    <>
      <PageHeader title="Supplier bills" subtitle="Suppliers' invoices, matched to the purchase order and what was received (3-way match)."
        actions={<>
          {can("supplier_invoice.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/supplier-invoices/export", "purchase-register.xlsx", { q: list.q, status: f.status })}>Purchase register</Button>}
          {can("supplier_invoice.create") && <Link href="/finance/bills/new"><Button icon={<Plus className="size-4" />}>Enter bill</Button></Link>}
        </>} />
      {d && "payable" in d && (
        <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <MiniStat label="Payable" value={inr(d.payable, 0)} onClick={() => setView("outstanding")} active={view === "outstanding"} />
          <MiniStat label="Overdue" value={inr(d.payable_overdue, 0)} tone="red" onClick={() => setView("overdue")} active={view === "overdue"} />
          <MiniStat label="Waiting for approval" value={d.bills_pending_approval} tone="amber" onClick={() => setView("pending_approval")} active={view === "pending_approval"} />
          <MiniStat label="Paid this month" value={inr(d.paid_month, 0)} />
        </div>
      )}
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search bill no., supplier invoice, supplier…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={view} onChange={(e) => setView(e.target.value)} className="sm:w-52" aria-label="Show">
            <option value="">All bills</option><option value="outstanding">Unpaid</option><option value="overdue">Overdue</option>
            <option value="draft">Drafts</option><option value="pending_approval">Waiting for approval</option><option value="posted">Posted</option><option value="cancelled">Cancelled</option>
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/finance/bills/view?id=${r.id}`)}
            empty={<EmptyState icon={<FileStack className="size-8" />} title="No bills here" body="Enter a supplier's invoice from its purchase order, or directly." />}
            columns={[
              { key: "n", header: "Bill", sortKey: "bill_number", cell: (r) => <div><p className="font-medium text-ink-900">{r.supplier}</p><p className="text-xs text-ink-500">Invoice {r.supplier_invoice_no}{r.bill_number ? ` · ${r.bill_number}` : ""}</p></div> },
              { key: "d", header: "Date", sortKey: "supplier_invoice_date", hideOnMobile: true, cell: (r) => date(r.supplier_invoice_date) },
              { key: "due", header: "Due", sortKey: "due_date", hideOnMobile: true, cell: (r) => <span className={r.overdue ? "text-brand-700" : ""}>{date(r.due_date)}</span> },
              { key: "t", header: "Total", sortKey: "grand_total", className: "text-right", cell: (r) => <span className="num">{inr(r.grand_total, 0)}</span> },
              { key: "b", header: "Balance", className: "text-right", hideOnMobile: true, cell: (r) => <span className="num">{r.status === "posted" ? inr(r.balance, 0) : "—"}</span> },
              { key: "s", header: "Status", cell: (r) => <span className="flex flex-wrap gap-1">{r.status === "posted" ? <PayStatus status={r.payment_status} /> : <BillStatus status={r.status} />}{r.overdue && <Badge tone="red">Overdue</Badge>}{r.mismatch && r.status !== "cancelled" && <Badge tone="amber">Differs from PO</Badge>}</span> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
