"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, ArrowLeft, IndianRupee, Pencil, Send, Trash2, XCircle } from "lucide-react";
import { Badge, Button, Card, Detail, ErrorNote, PageHeader, Spinner, Tabs, useConfirm, useToast } from "@/components/ui";
import { LinesTable, TotalsBox } from "@/components/lines-editor";
import { BillForm } from "@/components/finance/bill-form";
import { BillStatus, PayStatus } from "@/components/finance/common";
import { ApprovalCard, ApprovalHistory, ReasonDialog } from "@/components/purchase/common";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { TallyBadge } from "@/components/finance/tally-badge";
import { api } from "@/lib/api/client";
import { date, inr } from "@/lib/format";

type Tab = "bill" | "payments" | "approvals" | "documents" | "history";

function BillDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [tab, setTab] = useState<Tab>("bill");
  const [editing, setEditing] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const { data: b, isLoading, error } = useQuery({ queryKey: ["/supplier-invoices", id], queryFn: () => api<any>(`/supplier-invoices/${id}`), select: (r) => r.data });
  const refresh = () => { ["/supplier-invoices", "/finance/dashboard", "/approvals/inbox"].forEach((k) => qc.invalidateQueries({ queryKey: [k] })); };
  if (isLoading) return <Spinner />;
  if (error || !b) return <ErrorNote error={error} />;
  const can = b.can;
  if (editing)
    return (
      <div className="mx-auto max-w-6xl">
        <PageHeader title="Edit draft bill" />
        <BillForm initial={b} submitLabel="Save draft" onCancel={() => setEditing(false)} onSubmit={async (body) => {
          await api(`/supplier-invoices/${id}`, { method: "PUT", body: { ...body, row_version: b.row_version } });
          toast("Saved"); setEditing(false); refresh();
        }} />
      </div>
    );
  return (
    <>
      <PageHeader back={<Link href="/finance/bills" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Supplier bills</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{b.supplier} · {b.supplier_invoice_no} {b.status === "posted" ? <PayStatus status={b.payment_status} /> : <BillStatus status={b.status} />} <TallyBadge entityType="supplier_invoice" entityId={b.bill_number ? id : null} /></span>}
        subtitle={`${b.bill_number ?? "Not yet posted"} · ${date(b.supplier_invoice_date)}${b.purchase_order ? ` · ${b.purchase_order.po_number}` : ""}`}
        actions={<>
          {can.submit && <Button icon={<Send className="size-4" />} onClick={async () => {
            try { const r = await api<any>(`/supplier-invoices/${id}/submit`, { body: { row_version: b.row_version } }); toast(r.data.status === "posted" ? `Posted as ${r.data.bill_number}` : `${r.data.bill_number} sent for approval`); refresh(); }
            catch (e: any) { toast(e.message, "error"); }
          }}>{b.mismatch ? "Send for approval" : "Post bill"}</Button>}
          {can.pay && <Link href={`/finance/payments/new?supplier=${b.supplier_id}&bill=${b.id}`}><Button icon={<IndianRupee className="size-4" />}>Pay</Button></Link>}
          {can.edit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {can.cancel && <Button variant="ghost" icon={<XCircle className="size-4" />} onClick={() => setCancelling(true)}>Cancel bill</Button>}
          {can.delete && <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Discard this draft?", body: "It was never posted.", confirmLabel: "Discard" }))) return;
            await api(`/supplier-invoices/${id}`, { method: "DELETE" }); refresh(); router.push("/finance/bills");
          }}>Discard</Button>}
        </>} />
      <ApprovalCard approval={b.approval} onDone={refresh} />
      {b.last_rejection && b.status === "draft" && <p className="mb-4 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900"><b>Returned by the approver:</b> {b.last_rejection}</p>}
      {b.status === "cancelled" && <p className="mb-4 rounded-md bg-ink-100 px-3 py-2 text-sm"><b>Cancelled:</b> {b.status_reason}</p>}
      {b.mismatches.length > 0 && b.status !== "cancelled" && (
        <Card className="mb-4 border-amber-300" title={<span className="flex items-center gap-2"><AlertTriangle className="size-4 text-amber-600" /> Differs from the purchase order / goods received</span>}>
          <ul className="list-disc space-y-1 pl-5 text-sm">{b.mismatches.map((m: any, i: number) => <li key={i}>{m.message}</li>)}</ul>
        </Card>
      )}
      <div className="mb-4 grid gap-4 lg:grid-cols-[1fr_320px]">
        <Card>
          <Detail cols={4} items={[
            ["Supplier", <Link key="s" href={`/suppliers/view?id=${b.supplier_id}`} className="text-brand-700 hover:underline">{b.supplier}</Link>],
            ["Supplier invoice", `${b.supplier_invoice_no} · ${date(b.supplier_invoice_date)}`], ["Due", date(b.due_date)],
            ["Purchase order", b.purchase_order ? <Link key="p" href={`/purchase/orders/view?id=${b.purchase_order.id}`} className="text-brand-700 hover:underline">{b.purchase_order.po_number}</Link> : "—"],
            ["Booked to", b.account?.name], ["Project", b.project ? <Link key="j" href={`/projects/view?id=${b.project.id}`} className="text-brand-700 hover:underline">{b.project.number}</Link> : "—"],
            ["GST", b.inter_state ? "IGST (inter-state)" : "CGST + SGST"], ["Notes", b.notes],
          ]} />
        </Card>
        <Card>
          <p className="text-xs uppercase tracking-wide text-ink-500">{b.status === "posted" ? "Balance to pay" : "Bill total"}</p>
          <p className="num mt-1 text-3xl font-semibold text-ink-900">{inr(b.status === "posted" ? b.balance : b.grand_total)}</p>
          <p className="mt-1 text-sm text-ink-500">of {inr(b.grand_total)} · {inr(b.taxable)} before GST</p>
          {Number(b.paid) > 0 && <p className="mt-2"><Badge tone="green">Paid {inr(b.paid)}</Badge></p>}
        </Card>
      </div>
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[{ id: "bill", label: "Bill" }, { id: "payments", label: "Payments", count: b.payments.length },
        { id: "approvals", label: "Approvals", count: b.approvals.length }, { id: "documents", label: "Documents" }, { id: "history", label: "History" }]} />
      {tab === "bill" && (
        <Card padded={false}>
          <LinesTable items={b.items} />
          <div className="border-t border-ink-100 p-4"><TotalsBox interState={b.inter_state} t={{ gross: b.gross, lineDiscount: b.line_discount, special: b.special_discount, taxable: b.taxable, cgst: b.cgst, sgst: b.sgst, igst: b.igst, roundOff: b.round_off, grand: b.grand_total }} /></div>
        </Card>
      )}
      {tab === "payments" && (
        <Card padded={false}>
          {b.payments.length === 0 ? <p className="p-4 text-sm text-ink-500">Not paid yet.</p> : (
            <ul className="divide-y divide-ink-100">{b.payments.map((p: any) => (
              <li key={p.id} className="flex items-center gap-3 px-4 py-3 text-sm">
                <Link href={`/finance/payments/view?id=${p.id}`} className="font-medium text-brand-700 hover:underline">{p.payment_number}</Link>
                <span className="text-ink-500">{date(p.payment_date)}</span>
                <span className="num ml-auto">{inr(p.amount)}{Number(p.tds) ? <span className="text-ink-500"> + TDS {inr(p.tds)}</span> : null}</span>
              </li>))}</ul>
          )}
        </Card>
      )}
      {tab === "approvals" && <ApprovalHistory approvals={b.approvals} />}
      {tab === "documents" && <DocumentsPanel entityType="supplier_invoice" entityId={id} canEdit={can.edit || can.submit || can.pay} defaultCategory="bill" />}
      {tab === "history" && <HistoryPanel entityType="supplier_invoice" entityId={id} />}
      <ReasonDialog open={cancelling} title="Cancel this bill?" label="Reason. A posted bill's journal entry is reversed; the bill stays on record." required confirmLabel="Cancel bill"
        onClose={() => setCancelling(false)} onSubmit={async (reason) => { await api(`/supplier-invoices/${id}/cancel`, { body: { reason, row_version: b.row_version } }); toast("Bill cancelled"); refresh(); }} />
    </>
  );
}

export default function Page() {
  return <Suspense><BillDetail /></Suspense>;
}
