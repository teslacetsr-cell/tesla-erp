"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Banknote, Download, Plus } from "lucide-react";
import { Badge, Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function PaymentsPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/supplier-payments");
  return (
    <>
      <PageHeader title="Supplier payments" subtitle="Payments to suppliers, with TDS deducted, allocated to their bills. Unallocated money is an advance to the supplier."
        actions={<>
          {can("supplier_payment.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/supplier-payments/export", "supplier-payments.xlsx", { q: list.q })}>Export</Button>}
          {can("supplier_payment.create") && <Link href="/finance/payments/new"><Button icon={<Plus className="size-4" />}>Record payment</Button></Link>}
        </>} />
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search payment no., UTR / cheque, supplier…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={list.filters.status ?? ""} onChange={(e) => list.setFilter("status", e.target.value)} className="sm:w-44" aria-label="Status">
            <option value="">All payments</option><option value="posted">Posted</option><option value="cancelled">Cancelled</option>
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/finance/payments/view?id=${r.id}`)}
            empty={<EmptyState icon={<Banknote className="size-8" />} title="No payments here" />}
            columns={[
              { key: "n", header: "Payment", sortKey: "payment_number", cell: (r) => <div><p className="font-medium text-ink-900">{r.supplier}</p><p className="text-xs text-ink-500">{r.payment_number} · {r.mode.toUpperCase()}{r.reference_no ? ` ${r.reference_no}` : ""}</p></div> },
              { key: "d", header: "Date", sortKey: "payment_date", hideOnMobile: true, cell: (r) => date(r.payment_date) },
              { key: "a", header: "Paid", sortKey: "amount", className: "text-right", cell: (r) => <span className="num">{inr(r.amount)}</span> },
              { key: "t", header: "TDS", className: "text-right", hideOnMobile: true, cell: (r) => <span className="num text-ink-500">{Number(r.tds_amount) ? inr(r.tds_amount) : ""}</span> },
              { key: "u", header: "Advance", className: "text-right", hideOnMobile: true, cell: (r) => <span className="num">{Number(r.unallocated) ? inr(r.unallocated) : ""}</span> },
              { key: "s", header: "", cell: (r) => r.status === "cancelled" ? <Badge tone="grey">Cancelled</Badge> : null },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
