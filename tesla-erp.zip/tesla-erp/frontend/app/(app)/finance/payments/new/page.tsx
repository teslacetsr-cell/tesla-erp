"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader, useToast } from "@/components/ui";
import { MoneyForm } from "@/components/finance/money-form";
import { api } from "@/lib/api/client";

function NewPayment() {
  const sp = useSearchParams();
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Record supplier payment" subtitle="Money paid to a supplier and the TDS deducted from it." />
      <MoneyForm kind="payment" partyId={sp.get("supplier")} docId={sp.get("bill")} onCancel={() => router.back()} onSubmit={async (body) => {
        const r = await api<any>("/supplier-payments", { body });
        toast(`Payment ${r.data.payment_number} saved`);
        qc.invalidateQueries({ queryKey: ["/supplier-payments"] }); qc.invalidateQueries({ queryKey: ["/supplier-invoices"] }); qc.invalidateQueries({ queryKey: ["/finance/dashboard"] });
        router.push(`/finance/payments/view?id=${r.data.id}`);
      }} />
    </div>
  );
}

export default function Page() {
  return <Suspense><NewPayment /></Suspense>;
}
