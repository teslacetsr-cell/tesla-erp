"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Link2, Unlink, XCircle } from "lucide-react";
import { Badge, Button, Card, Detail, ErrorNote, Modal, PageHeader, Spinner, Tabs, useConfirm, useToast } from "@/components/ui";
import { AllocateDialogBody } from "@/components/finance/money-form";
import { ReasonDialog } from "@/components/purchase/common";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api } from "@/lib/api/client";
import { date, inr } from "@/lib/format";

type Tab = "allocations" | "documents" | "history";

function PaymentDetail() {
  const id = useSearchParams().get("id") ?? "";
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [tab, setTab] = useState<Tab>("allocations");
  const [dialog, setDialog] = useState<"cancel" | "allocate" | null>(null);
  const { data: p, isLoading, error } = useQuery({ queryKey: ["/supplier-payments", id], queryFn: () => api<any>(`/supplier-payments/${id}`), select: (x) => x.data });
  const refresh = () => { ["/supplier-payments", "/supplier-invoices", "/finance/dashboard"].forEach((k) => qc.invalidateQueries({ queryKey: [k] })); };
  if (isLoading) return <Spinner />;
  if (error || !p) return <ErrorNote error={error} />;
  const tdsUsed = p.allocations.filter((a: any) => a.is_active).reduce((s: number, a: any) => s + Number(a.tds), 0);
  return (
    <>
      <PageHeader back={<Link href="/finance/payments" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Supplier payments</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{p.payment_number} {p.status === "cancelled" && <Badge tone="grey">Cancelled</Badge>}</span>}
        subtitle={`${p.supplier} · ${date(p.payment_date)} · ${p.mode.toUpperCase()}${p.reference_no ? ` ${p.reference_no}` : ""}`}
        actions={<>
          {p.can.allocate && <Button icon={<Link2 className="size-4" />} onClick={() => setDialog("allocate")}>Allocate to bills</Button>}
          {p.can.cancel && <Button variant="ghost" icon={<XCircle className="size-4" />} onClick={() => setDialog("cancel")}>Cancel payment</Button>}
        </>} />
      {p.status === "cancelled" && <p className="mb-4 rounded-md bg-ink-100 px-3 py-2 text-sm"><b>Cancelled:</b> {p.status_reason}</p>}
      <div className="mb-4 grid gap-4 lg:grid-cols-[1fr_320px]">
        <Card><Detail cols={3} items={[
          ["Supplier", <Link key="s" href={`/suppliers/view?id=${p.supplier_id}`} className="text-brand-700 hover:underline">{p.supplier}</Link>],
          ["Date", date(p.payment_date)], ["Mode", p.mode.toUpperCase()], ["Reference", p.reference_no], ["Bank", p.bank_name], ["Notes", p.notes],
        ]} /></Card>
        <Card>
          <p className="text-xs uppercase tracking-wide text-ink-500">Paid</p>
          <p className="num mt-1 text-3xl font-semibold text-ink-900">{inr(p.amount)}</p>
          {Number(p.tds_amount) > 0 && <p className="text-sm text-ink-600">+ TDS deducted {inr(p.tds_amount)}</p>}
          {Number(p.unallocated) > 0 && <p className="mt-2"><Badge tone="amber">Advance {inr(p.unallocated)}</Badge></p>}
        </Card>
      </div>
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[{ id: "allocations", label: "Bills paid", count: p.allocations.filter((a: any) => a.is_active).length }, { id: "documents", label: "Documents" }, { id: "history", label: "History" }]} />
      {tab === "allocations" && (
        <Card padded={false}>
          {p.allocations.length === 0 ? <p className="p-4 text-sm text-ink-500">Not allocated — the whole amount is an advance to the supplier.</p> : (
            <ul className="divide-y divide-ink-100">{p.allocations.map((a: any) => (
              <li key={a.id} className={`flex flex-wrap items-center gap-3 px-4 py-3 text-sm ${a.is_active ? "" : "opacity-50"}`}>
                <Link href={`/finance/bills/view?id=${a.supplier_invoice_id}`} className="font-medium text-brand-700 hover:underline">{a.bill_number}</Link>
                <span className="text-xs text-ink-500">Invoice {a.supplier_invoice_no}</span>{!a.is_active && <Badge tone="grey">Released</Badge>}
                <span className="num ml-auto">{inr(a.amount)}{Number(a.tds) ? <span className="text-ink-500"> + TDS {inr(a.tds)}</span> : null}</span>
                {a.is_active && p.can.unallocate && <Button size="sm" variant="ghost" icon={<Unlink className="size-3.5" />} onClick={async () => {
                  if (!(await confirm({ title: `Take this off ${a.bill_number}?`, body: "The bill becomes unpaid by this amount; the money stays on the payment as an advance.", confirmLabel: "Take off" }))) return;
                  try { await api(`/supplier-payments/${id}/allocations/${a.id}/remove`, { method: "POST" }); toast("Allocation removed"); refresh(); } catch (e: any) { toast(e.message, "error"); }
                }}>Take off</Button>}
              </li>))}</ul>
          )}
        </Card>
      )}
      {tab === "documents" && <DocumentsPanel entityType="supplier_payment" entityId={id} canEdit={p.can.allocate || p.can.cancel} defaultCategory="other" />}
      {tab === "history" && <HistoryPanel entityType="supplier_payment" entityId={id} />}
      <ReasonDialog open={dialog === "cancel"} title="Cancel this payment?" label="Reason. Bills it paid become unpaid again and the books are reversed." required confirmLabel="Cancel payment"
        onClose={() => setDialog(null)} onSubmit={async (reason) => { await api(`/supplier-payments/${id}/cancel`, { body: { reason, row_version: p.row_version } }); toast("Payment cancelled"); refresh(); }} />
      <Modal open={dialog === "allocate"} onClose={() => setDialog(null)} title="Allocate to bills" wide>
        {dialog === "allocate" && <AllocateDialogBody kind="supplier" partyId={p.supplier_id} free={Number(p.unallocated)} tdsFree={Math.max(Number(p.tds_amount) - tdsUsed, 0)} onCancel={() => setDialog(null)}
          onSubmit={async (allocations) => { await api(`/supplier-payments/${id}/allocate`, { body: { allocations, row_version: p.row_version } }); toast("Allocated"); refresh(); setDialog(null); }} />}
      </Modal>
    </>
  );
}

export default function Page() {
  return <Suspense><PaymentDetail /></Suspense>;
}
