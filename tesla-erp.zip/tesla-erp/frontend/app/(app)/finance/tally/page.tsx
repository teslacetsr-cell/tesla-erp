"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useMemo, useState, type ReactNode } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, CheckCircle2, Copy, KeyRound, ListRestart, RefreshCw, Scale, Send, XCircle } from "lucide-react";
import {
  Badge, Button, Card, Checkbox, DataTable, Detail, EmptyState, ErrorNote, Field, Input, Modal, PageHeader, Pagination, Select,
  Spinner, Tabs, useConfirm, useToast, type Column,
} from "@/components/ui";
import { ReasonDialog } from "@/components/purchase/common";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, dateTime, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

type Tab = "status" | "mapping" | "queue" | "check";
const TABS: Tab[] = ["status", "mapping", "queue", "check"];

const JOB_LOOK: Record<string, { tone: "green" | "amber" | "red" | "grey" | "blue"; text: string }> = {
  pending: { tone: "blue", text: "Waiting" },
  leased: { tone: "amber", text: "Sending" },
  done: { tone: "green", text: "In Tally" },
  failed: { tone: "red", text: "Not accepted" },
  cancelled: { tone: "grey", text: "Not sent" },
};

function drcr(v: string | null | undefined) {
  if (v === null || v === undefined) return "—";
  const n = Number(v);
  if (n === 0) return inr(0);
  return `${inr(Math.abs(n))} ${n > 0 ? "Dr" : "Cr"}`;
}

// ============================================================================================ status & settings
function StatusTab({ st, canEdit }: { st: any; canEdit: boolean }) {
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [newKey, setNewKey] = useState<{ open: boolean; name: string; key?: string; busy?: boolean; error?: string }>({ open: false, name: "Accounts PC" });
  const [form, setForm] = useState<any>(st.settings);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<unknown>(null);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => setForm(st.settings), [st.settings.row_version]);
  const refresh = () => ["/tally/status", "/tally/jobs", "/tally/mapping"].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
  const c = st.connector;
  const companyMismatch = c?.tally_company && st.settings.tally_company && c.tally_company.toLowerCase() !== st.settings.tally_company.toLowerCase();
  const pushed = Object.values(form.voucher_types ?? {}).some((v) => v === "erp");

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card title="Connector on the Tally PC">
        {!c ? (
          <p className="text-sm text-ink-600">The connector has not contacted the ERP yet. Create a key below, install the Tally Connector on the PC where TallyPrime runs, and paste the key into it.</p>
        ) : (
          <>
            <p className="mb-3 flex items-center gap-2 text-sm font-medium">
              {c.online ? <CheckCircle2 className="size-4 text-emerald-600" /> : <XCircle className="size-4 text-brand-600" />}
              {c.online ? "Online" : "Not in contact"} <span className="font-normal text-ink-500">· last contact {dateTime(c.last_seen_at)}</span>
            </p>
            <Detail cols={2} items={[
              ["Tally reachable", c.tally_ok ? <Badge key="t" tone="green">Yes</Badge> : <span key="t" className="text-brand-700">No{c.tally_error ? ` — ${c.tally_error}` : ""}</span>],
              ["Company open in Tally", c.tally_company ? <span key="c" className={companyMismatch ? "text-brand-700" : ""}>{c.tally_company}</span> : "—"],
              ["PC name", c.host], ["Connector version", c.agent_version], ["Tally address", c.tally_url], ["Tally version", c.tally_version],
            ]} />
            {companyMismatch && <p className="mt-3 flex items-start gap-2 rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-900"><AlertTriangle className="mt-0.5 size-4 shrink-0" /> Tally has “{c.tally_company}” open, but the ERP sends entries for “{st.settings.tally_company}”. Open the right company in Tally, or correct the name in the settings.</p>}
          </>
        )}
        <div className="mt-4 grid grid-cols-3 gap-2 text-center text-sm">
          {[["Waiting", st.counts.pending + st.counts.leased, "text-sky-700"], ["Not accepted", st.counts.failed, st.counts.failed ? "text-brand-700" : "text-ink-700"], ["In Tally", st.counts.done, "text-emerald-700"]].map(([l, n, cls]) => (
            <div key={l as string} className="rounded-md border border-ink-100 px-2 py-2"><p className={`num text-xl font-semibold ${cls}`}>{n as number}</p><p className="text-xs text-ink-500">{l as string}</p></div>
          ))}
        </div>
        {st.last_done_at && <p className="mt-2 text-xs text-ink-500">Last entry accepted by Tally {dateTime(st.last_done_at)}</p>}
      </Card>

      <Card title="Connector keys" actions={canEdit && <Button size="sm" icon={<KeyRound className="size-4" />} onClick={() => setNewKey({ open: true, name: "Accounts PC" })}>Create key</Button>}>
        {st.keys.length === 0 ? <p className="text-sm text-ink-500">No key yet.</p> : (
          <ul className="divide-y divide-ink-100">
            {st.keys.map((k: any) => (
              <li key={k.id} className={`flex flex-wrap items-center gap-2 py-2 text-sm ${k.revoked_at ? "opacity-60" : ""}`}>
                <span className="font-medium">{k.name}</span>
                <code className="rounded bg-ink-100 px-1.5 text-xs">{k.key_prefix}…</code>
                {k.revoked_at ? <Badge tone="grey">Revoked {date(k.revoked_at)}</Badge> : k.online ? <Badge tone="green">Online</Badge> : <Badge tone="amber">{k.last_seen_at ? `Last seen ${dateTime(k.last_seen_at)}` : "Never used"}</Badge>}
                <span className="text-xs text-ink-500">created {date(k.created_at)}</span>
                {canEdit && !k.revoked_at && <Button size="sm" variant="ghost" className="ml-auto" onClick={async () => {
                  if (!(await confirm({ title: `Revoke “${k.name}”?`, body: "The connector using this key stops working at once. Use this if the key was lost or the PC is replaced, then create a new key.", confirmLabel: "Revoke" }))) return;
                  try { await api(`/tally/keys/${k.id}/revoke`, { method: "POST" }); toast("Key revoked"); refresh(); } catch (e: any) { toast(e.message, "error"); }
                }}>Revoke</Button>}
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card title="Settings" className="lg:col-span-2">
        <fieldset disabled={!canEdit} className="grid gap-4 md:grid-cols-2">
          <div className="space-y-3">
            <Checkbox label="Send entries to Tally (untick to pause; entries keep queueing)" checked={!!form.enabled} onChange={(e) => setForm({ ...form, enabled: e.target.checked })} />
            <Field label="Company name in Tally" hint="Exactly as it appears in TallyPrime's company list.">
              <Input value={form.tally_company ?? ""} maxLength={200} onChange={(e) => setForm({ ...form, tally_company: e.target.value })} />
            </Field>
            <Field label="Send entries dated on or after" required={pushed} hint="Usually the day after the last entry already typed into Tally. Older entries are never sent.">
              <Input type="date" value={form.start_date ?? ""} onChange={(e) => setForm({ ...form, start_date: e.target.value || null })} />
            </Field>
            <Field label="Connector checks for work every">
              <Select value={form.poll_seconds} onChange={(e) => setForm({ ...form, poll_seconds: Number(e.target.value) })}>
                {[30, 60, 120, 300].map((s) => <option key={s} value={s}>{s < 60 ? `${s} seconds` : `${s / 60} minute${s > 60 ? "s" : ""}`}</option>)}
              </Select>
            </Field>
            <Checkbox label="Create customer and supplier ledgers in Tally when they are first used" checked={!!form.create_party_ledgers} onChange={(e) => setForm({ ...form, create_party_ledgers: e.target.checked })} />
          </div>
          <div>
            <p className="mb-1 text-[13px] font-medium text-ink-700">Where is each entry made?</p>
            <p className="mb-2 text-xs text-ink-500">Each kind of entry is made in one place only, so nothing is counted twice.</p>
            <ul className="divide-y divide-ink-100 rounded-md border border-ink-100">
              {Object.entries(form.voucher_type_labels ?? {}).map(([k, v]: [string, any]) => (
                <li key={k} className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 text-sm">
                  <span>{v.label} <span className="text-xs text-ink-500">(Tally: {v.tally_type})</span></span>
                  <Select className="w-auto" aria-label={v.label} value={form.voucher_types?.[k] ?? "tally"} onChange={(e) => setForm({ ...form, voucher_types: { ...form.voucher_types, [k]: e.target.value } })}>
                    <option value="erp">In the ERP — send to Tally</option>
                    <option value="tally">In Tally — not sent</option>
                  </Select>
                </li>
              ))}
            </ul>
          </div>
        </fieldset>
        {saveError ? <div className="mt-3"><ErrorNote error={saveError} /></div> : null}
        {canEdit && <div className="mt-4 flex flex-wrap gap-2">
          <Button loading={saving} onClick={async () => {
            setSaving(true); setSaveError(null);
            try {
              await api("/tally/settings", { method: "PUT", body: { enabled: form.enabled, poll_seconds: form.poll_seconds, tally_company: form.tally_company || null, start_date: form.start_date || null, voucher_types: form.voucher_types, create_party_ledgers: form.create_party_ledgers, row_version: form.row_version } });
              toast("Settings saved"); refresh();
            } catch (e) { setSaveError(e); } finally { setSaving(false); }
          }}>Save settings</Button>
          <Button variant="secondary" icon={<Send className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Send the ERP's ledger list to Tally?", body: "Creates in Tally any ledger it does not have yet (sales, GST, bank, TDS, expense ledgers…), under the Tally group shown in the ledger mapping. Ledgers Tally already has are left as they are.", confirmLabel: "Send" }))) return;
            try { await api("/tally/ledgers/push", { method: "POST" }); toast("Ledger list queued"); refresh(); } catch (e: any) { toast(e.message, "error"); }
          }}>Send ledger list to Tally</Button>
          <Button variant="secondary" icon={<ListRestart className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Queue all entries since the start date?", body: `Every entry dated from ${date(st.settings.start_date)} that is set to be sent and is not yet queued will be queued, oldest first. Entries already sent are not sent again.`, confirmLabel: "Queue them" }))) return;
            try { const r = await api<any>("/tally/backfill", { body: {} }); toast(`${r.data.queued} entr${r.data.queued === 1 ? "y" : "ies"} queued`); refresh(); } catch (e: any) { toast(e.message, "error"); }
          }}>Queue all from start date</Button>
        </div>}
      </Card>

      <Card title="Setting up — in short" className="lg:col-span-2">
        <ol className="list-decimal space-y-1 pl-5 text-sm text-ink-700">
          <li>In TallyPrime: <i>Help → Settings → Connectivity</i>, TallyPrime acts as <b>Both</b>, port <b>9000</b>. Keep the company open. In each voucher type the ERP sends, set numbering to <i>Manual</i> with <i>Prevent duplicates</i>.</li>
          <li>Create a connector key here and copy it. Install the Tally Connector on the Tally PC and paste the ERP address and the key.</li>
          <li>Check the <b>Ledger names</b> tab: each ERP ledger must match a ledger in Tally (or press <i>Send ledger list to Tally</i>).</li>
          <li>Choose the start date and which entries are made in the ERP, tick <i>Send entries to Tally</i> and save. Watch the <b>Queue</b>; anything Tally does not accept shows Tally's reason and can be retried after fixing it.</li>
          <li>Once a month, use <b>Check balances</b> to compare party and ledger balances with Tally.</li>
        </ol>
      </Card>

      <Modal open={newKey.open} onClose={() => { setNewKey({ open: false, name: "Accounts PC" }); refresh(); }} title={newKey.key ? "Copy the key now" : "Create a connector key"}
        footer={newKey.key ? <Button onClick={() => { setNewKey({ open: false, name: "Accounts PC" }); refresh(); }}>I have stored it safely</Button> : <>
          <Button variant="secondary" onClick={() => setNewKey({ open: false, name: "Accounts PC" })}>Cancel</Button>
          <Button loading={newKey.busy} onClick={async () => {
            setNewKey({ ...newKey, busy: true, error: undefined });
            try { const r = await api<any>("/tally/keys", { body: { name: newKey.name } }); setNewKey({ open: true, name: newKey.name, key: r.data.key }); }
            catch (e: any) { setNewKey({ ...newKey, busy: false, error: e.message }); }
          }}>Create key</Button></>}>
        {newKey.key ? (
          <div className="space-y-3 text-sm">
            <p className="flex items-start gap-2 rounded-md bg-amber-50 px-3 py-2 text-amber-900"><AlertTriangle className="mt-0.5 size-4 shrink-0" /> This key is shown only once. Paste it into the Tally Connector now, or keep it in a safe place. Anyone with it can read and write your Tally data through the ERP. If it is lost, revoke it and create a new one.</p>
            <div className="flex gap-2">
              <Input readOnly value={newKey.key} className="font-mono text-xs" onFocus={(e) => e.currentTarget.select()} aria-label="Connector key" />
              <Button variant="secondary" icon={<Copy className="size-4" />} onClick={async (e) => {
                e.preventDefault();
                try { await navigator.clipboard.writeText(newKey.key!); toast("Copied"); } catch { toast("Select the key and copy it with Ctrl+C", "error"); }
              }}>Copy</Button>
            </div>
          </div>
        ) : (
          <Field label="Name (which PC it is for)" error={newKey.error}>
            <Input value={newKey.name} maxLength={80} onChange={(e) => setNewKey({ ...newKey, name: e.target.value })} />
          </Field>
        )}
      </Modal>
    </div>
  );
}

// ============================================================================================ ledger mapping
function MappingTab({ canEdit }: { canEdit: boolean }) {
  const qc = useQueryClient();
  const toast = useToast();
  const { data, isLoading, error } = useQuery({ queryKey: ["/tally/mapping"], queryFn: () => api<any>("/tally/mapping"), select: (x) => x.data });
  const [edits, setEdits] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  if (isLoading) return <Spinner />;
  if (error || !data) return <ErrorNote error={error} />;
  const k = (r: any) => `${r.kind}:${r.erp_key}`;
  const val = (r: any) => (k(r) in edits ? edits[k(r)] : r.tally_name ?? "");
  const dirty = Object.keys(edits).length;
  const section = (title: string, hint: string, rows: any[], extra?: (r: any) => ReactNode) => (
    <Card title={title} padded={false} className="mb-4">
      <p className="border-b border-ink-100 px-4 py-2 text-xs text-ink-500">{hint}</p>
      {rows.length === 0 ? <p className="px-4 py-3 text-sm text-ink-500">Nothing yet.</p> : (
        <ul className="divide-y divide-ink-100">
          {rows.map((r) => (
            <li key={k(r)} className="grid items-center gap-2 px-4 py-2 text-sm md:grid-cols-[1fr_1fr]">
              <div className="min-w-0"><span className={r.is_active === false ? "text-ink-400" : ""}>{r.erp_name}</span> {extra?.(r)}</div>
              <Input aria-label={`Tally name for ${r.erp_name}`} value={val(r)} placeholder={r.default ?? "(none)"} disabled={!canEdit} maxLength={200}
                onChange={(e) => setEdits({ ...edits, [k(r)]: e.target.value })} />
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
  return (
    <>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2 rounded-md bg-ink-50 px-3 py-2 text-sm text-ink-700">
        <span>Leave a box empty to use the name shown in grey. Names must match Tally exactly (spelling, spaces, “&”).</span>
        {canEdit && <Button disabled={!dirty} loading={saving} onClick={async () => {
          setSaving(true);
          try {
            const all = [...data.accounts, ...data.gst, ...data.parties, ...data.projects];
            const items = all.filter((r) => k(r) in edits).map((r) => ({ kind: r.kind, erp_key: r.erp_key, tally_name: edits[k(r)].trim() || null }));
            const r = await api<any>("/tally/mapping", { method: "PUT", body: { items } });
            toast(`${r.data.changed} name(s) saved. Entries already waiting use the new names when they are sent again.`);
            setEdits({}); qc.invalidateQueries({ queryKey: ["/tally/mapping"] });
          } catch (e: any) { toast(e.message, "error"); } finally { setSaving(false); }
        }}>Save names{dirty ? ` (${dirty})` : ""}</Button>}
      </div>
      {section("ERP ledgers", "Each ERP ledger and the Tally ledger it posts to. The group in brackets is used when the ERP creates the ledger in Tally.", data.accounts,
        (r) => <span className="text-xs text-ink-500">({r.group ?? "—"})</span>)}
      {section("GST ledgers by rate (optional)", "Only if Tally keeps a separate ledger per GST rate, e.g. “Output CGST 9%”. Otherwise leave empty.", data.gst)}
      {section("Customers and suppliers", "Sent to Tally under their ERP name unless you give another. Change a name only if the ledger in Tally is called differently.", data.parties,
        (r) => <><Badge tone="grey">{r.kind === "customer" ? "Customer" : "Supplier"}</Badge> {r.in_tally && <Badge tone="green">In Tally</Badge>}</>)}
      {section("Projects → Tally cost centres (optional)", "Give a cost centre name to book a project's sales and costs to that cost centre in Tally.", data.projects)}
    </>
  );
}

// ============================================================================================ queue
function JobDetail({ id, onClose }: { id: string | null; onClose: () => void }) {
  const { data, isLoading } = useQuery({ queryKey: ["/tally/jobs", id], queryFn: () => api<any>(`/tally/jobs/${id}`), select: (x) => x.data, enabled: !!id });
  return (
    <Modal open={!!id} onClose={onClose} title={data?.label ?? "Entry"} wide>
      {isLoading || !data ? <Spinner /> : (
        <div className="space-y-3 text-sm">
          <Detail cols={3} items={[["Status", JOB_LOOK[data.status]?.text ?? data.status], ["Tries", String(data.attempts)], ["Date", date(data.doc_date)],
            ["Queued", dateTime(data.created_at)], ["Last sent", dateTime(data.sent_at)], ["Accepted", dateTime(data.done_at)]]} />
          {data.last_error && <p className={`rounded-md px-3 py-2 ${data.status === "done" ? "bg-ink-50 text-ink-700" : "bg-brand-50 text-brand-800"}`}>{data.last_error}</p>}
          {data.waiting_for && <p className="rounded-md bg-sky-50 px-3 py-2 text-sky-800">Waiting for “{data.waiting_for}” to be accepted by Tally first.</p>}
          <details><summary className="cursor-pointer text-ink-600">What the ERP sends to Tally (XML)</summary><pre className="mt-2 max-h-72 overflow-auto rounded bg-ink-50 p-2 text-xs">{data.xml ?? "—"}</pre></details>
          <details><summary className="cursor-pointer text-ink-600">Tally's last reply</summary><pre className="mt-2 max-h-72 overflow-auto rounded bg-ink-50 p-2 text-xs">{data.tally_response ?? "—"}</pre></details>
        </div>
      )}
    </Modal>
  );
}

function QueueTab({ canEdit, initialStatus }: { canEdit: boolean; initialStatus: string }) {
  const qc = useQueryClient();
  const toast = useToast();
  const list = useList<any>("/tally/jobs", { filters: { status: initialStatus } });
  const [open, setOpen] = useState<string | null>(null);
  const [skip, setSkip] = useState<any>(null);
  const refetch = list.refetch;
  useEffect(() => { const t = setInterval(() => refetch(), 15_000); return () => clearInterval(t); }, [refetch]);
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/tally/jobs"] }); qc.invalidateQueries({ queryKey: ["/tally/status"] }); };
  const retry = async (id: string) => {
    try { await api(`/tally/jobs/${id}/retry`, { method: "POST" }); toast("Will be sent again"); refresh(); } catch (e: any) { toast(e.message, "error"); }
  };
  const columns: Column<any>[] = [
    { key: "label", header: "Entry", cell: (j) => <div><p className="font-medium text-ink-900">{j.label}</p><p className="text-xs text-ink-500">{j.doc_date ? date(j.doc_date) : "—"}{j.attempts > 1 ? ` · tried ${j.attempts} times` : ""}</p></div> },
    { key: "status", header: "Status", className: "whitespace-nowrap", cell: (j) => <Badge tone={JOB_LOOK[j.status]?.tone ?? "grey"}>{JOB_LOOK[j.status]?.text ?? j.status}</Badge> },
    { key: "error", header: "Message", className: "max-w-md", cell: (j) => (
      <span className={`block text-xs ${j.status === "failed" ? "text-brand-700" : "text-ink-500"}`}>
        {j.waiting_for ? `Waiting for “${j.waiting_for}”` : j.last_error ?? (j.status === "done" ? `Accepted ${dateTime(j.done_at)}` : "")}
      </span>) },
    { key: "updated", header: "Updated", hideOnMobile: true, cell: (j) => <span className="text-xs text-ink-500">{dateTime(j.updated_at)}</span> },
    { key: "act", header: "", cell: (j) => canEdit && (j.status === "failed" || j.status === "pending") ? (
      <div className="flex justify-end gap-1" onClick={(e) => e.stopPropagation()}>
        {j.status === "failed" && <Button size="sm" variant="secondary" icon={<RefreshCw className="size-3.5" />} onClick={() => retry(j.id)}>Retry</Button>}
        <Button size="sm" variant="ghost" onClick={() => setSkip(j)}>Don't send</Button>
      </div>) : null },
  ];
  return (
    <Card padded={false}>
      <div className="flex flex-wrap items-center gap-2 border-b border-ink-100 px-4 py-2.5">
        <div className="w-full sm:w-48"><Select aria-label="Show" value={list.filters.status ?? ""} onChange={(e) => list.setFilter("status", e.target.value)}>
          <option value="">All</option><option value="open">Waiting / sending</option><option value="failed">Not accepted</option><option value="done">In Tally</option><option value="cancelled">Not sent</option>
        </Select></div>
        <div className="w-full sm:w-64"><Input placeholder="Search number or message" aria-label="Search" value={list.q} onChange={(e) => list.setQ(e.target.value)} /></div>
        <div className="ml-auto flex gap-2">
          <Button size="sm" variant="ghost" icon={<RefreshCw className="size-3.5" />} onClick={() => refresh()}>Refresh</Button>
          {canEdit && <Button size="sm" icon={<RefreshCw className="size-3.5" />} onClick={async () => {
            try { const r = await api<any>("/tally/jobs/retry-failed", { method: "POST" }); toast(`${r.data.retried} entr${r.data.retried === 1 ? "y" : "ies"} will be sent again` + (r.data.not_ready ? `; ${r.data.not_ready} still need fixing` : "")); refresh(); } catch (e: any) { toast(e.message, "error"); }
          }}>Retry all not accepted</Button>}
        </div>
      </div>
      {list.isLoading ? <Spinner /> : list.error ? <div className="p-4"><ErrorNote error={list.error} /></div> : (
        <DataTable columns={columns} rows={list.rows} onRowClick={(j) => setOpen(j.id)}
          empty={<EmptyState title="Nothing in this list" body="Entries appear here when they are issued or posted in the ERP and are set to be sent to Tally." />} />
      )}
      {list.meta && list.meta.total > list.meta.page_size && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      <JobDetail id={open} onClose={() => setOpen(null)} />
      <ReasonDialog open={!!skip} title={`Don't send “${skip?.label ?? ""}”?`} required confirmLabel="Don't send"
        label="Why (e.g. already entered in Tally by hand)? The ERP entry is not changed." onClose={() => setSkip(null)}
        onSubmit={async (reason) => { await api(`/tally/jobs/${skip.id}/skip`, { body: { reason } }); toast("Taken off the queue"); refresh(); }} />
    </Card>
  );
}

// ============================================================================================ reconciliation
function CheckTab({ canEdit }: { canEdit: boolean }) {
  const qc = useQueryClient();
  const toast = useToast();
  const [onlyDiff, setOnlyDiff] = useState(true);
  const { data, isLoading, error } = useQuery({
    queryKey: ["/tally/reconciliations/latest"], queryFn: () => api<any>("/tally/reconciliations/latest"), select: (x) => x.data,
    refetchInterval: (q) => (q.state.data as any)?.data?.status === "waiting" ? 5000 : false,
  });
  const rows = useMemo(() => (data?.rows ?? []).filter((r: any) => !onlyDiff || r.status !== "match").map((r: any, i: number) => ({ ...r, id: String(i) })), [data, onlyDiff]);
  const look: Record<string, [string, "green" | "red" | "amber"]> = { match: ["Same", "green"], different: ["Different", "red"], missing_in_tally: ["Not in Tally", "amber"] };
  const columns: Column<any>[] = [
    { key: "name", header: "In the ERP", cell: (r) => <div><p className="font-medium">{r.erp_name}</p><p className="text-xs text-ink-500">{r.group}</p></div> },
    { key: "tally", header: "Tally ledger", hideOnMobile: true, cell: (r) => <span className="text-xs">{r.tally_name}</span> },
    { key: "erp", header: "ERP balance", className: "num text-right", cell: (r) => drcr(r.erp) },
    { key: "tb", header: "Tally balance", className: "num text-right", cell: (r) => drcr(r.tally) },
    { key: "diff", header: "Difference", className: "num text-right", cell: (r) => Number(r.difference) ? drcr(r.difference) : "—" },
    { key: "st", header: "", cell: (r) => <Badge tone={look[r.status]?.[1] ?? "grey"}>{look[r.status]?.[0] ?? r.status}</Badge> },
  ];
  if (isLoading) return <Spinner />;
  if (error) return <ErrorNote error={error} />;
  return (
    <Card title="ERP and Tally balances" actions={canEdit && <Button size="sm" icon={<Scale className="size-4" />} disabled={data?.status === "waiting"} onClick={async () => {
      try { await api("/tally/reconciliations", { method: "POST" }); toast("Asked Tally for its balances"); qc.invalidateQueries({ queryKey: ["/tally/reconciliations/latest"] }); } catch (e: any) { toast(e.message, "error"); }
    }}>Ask Tally for balances</Button>} padded={false}>
      <p className="border-b border-ink-100 px-4 py-2 text-xs text-ink-500">Compares each customer, supplier and ledger. Differences are expected for entries made before the start date or typed only in Tally (opening balances, bank charges…). Dr = debit balance, Cr = credit balance.</p>
      {!data ? <EmptyState title="No comparison yet" body="Press “Ask Tally for balances”. The connector fetches them on its next round (about a minute)." /> :
        data.status === "waiting" ? <Spinner label="Waiting for the connector to fetch balances from Tally…" /> :
        data.status === "failed" ? <div className="p-4"><ErrorNote error={new Error(data.error ?? "Tally did not answer.")} /></div> : (
          <>
            <div className="flex flex-wrap items-center gap-3 px-4 py-2 text-sm">
              <span>Checked {dateTime(data.finished_at)} · {data.summary.rows} rows · <b className={data.summary.different ? "text-brand-700" : "text-emerald-700"}>{data.summary.different} different</b> · {data.summary.tally_ledgers} ledgers in Tally</span>
              <span className="ml-auto"><Checkbox label="Only differences" checked={onlyDiff} onChange={(e) => setOnlyDiff(e.target.checked)} /></span>
            </div>
            <DataTable columns={columns} rows={rows} empty={<EmptyState title="Everything matches" />} />
          </>
        )}
    </Card>
  );
}

// ============================================================================================ page
function TallySync() {
  const sp = useSearchParams();
  const router = useRouter();
  const { can } = useAuth();
  const canEdit = can("tally.update");
  const tabParam = sp.get("tab") as Tab | null;
  const [tab, setTab] = useState<Tab>(tabParam && TABS.includes(tabParam) ? tabParam : "status");
  const { data: st, isLoading, error } = useQuery({ queryKey: ["/tally/status"], queryFn: () => api<any>("/tally/status"), select: (x) => x.data, refetchInterval: 15_000 });
  if (isLoading) return <Spinner />;
  if (error || !st) return <ErrorNote error={error} />;
  const failed = st.counts.failed;
  return (
    <>
      <PageHeader title="Tally Sync" subtitle={st.settings.enabled ? `Sending to “${st.settings.tally_company ?? "the open company"}” · entries from ${date(st.settings.start_date)}` : "Sending to Tally is switched off"} />
      {failed > 0 && tab !== "queue" && <button className="mb-4 flex w-full items-center gap-2 rounded-md border border-brand-200 bg-brand-50 px-3 py-2 text-left text-sm text-brand-800" onClick={() => { setTab("queue"); router.replace("/finance/tally?tab=queue&status=failed"); }}>
        <AlertTriangle className="size-4 shrink-0" /> {failed} entr{failed === 1 ? "y was" : "ies were"} not accepted by Tally. Open the queue to see why.</button>}
      <Tabs<Tab> value={tab} onChange={(t) => { setTab(t); router.replace(`/finance/tally?tab=${t}`); }} tabs={[
        { id: "status", label: "Status & settings" }, { id: "mapping", label: "Ledger names" },
        { id: "queue", label: "Queue", count: st.counts.pending + st.counts.leased + st.counts.failed }, { id: "check", label: "Check balances" },
      ]} />
      {tab === "status" && <StatusTab st={st} canEdit={canEdit} />}
      {tab === "mapping" && <MappingTab canEdit={canEdit} />}
      {tab === "queue" && <QueueTab canEdit={canEdit} initialStatus={sp.get("status") ?? ""} />}
      {tab === "check" && <CheckTab canEdit={canEdit} />}
    </>
  );
}

export default function Page() {
  return <Suspense><TallySync /></Suspense>;
}
