"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Download } from "lucide-react";
import { Button, Card, ErrorNote, Field, Input, PageHeader, Pagination, Spinner, Tabs } from "@/components/ui";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

type Tab = "gst" | "journal" | "tb";
const firstOfMonth = () => new Date(Date.now() + 5.5 * 3600_000).toISOString().slice(0, 8) + "01";
const today = () => new Date(Date.now() + 5.5 * 3600_000).toISOString().slice(0, 10);

function Gst({ from, to }: { from: string; to: string }) {
  const q = useQuery({ queryKey: ["/finance/gst-summary", from, to], queryFn: () => api<any>("/finance/gst-summary", { params: { date_from: from, date_to: to } }), select: (r) => r.data });
  if (q.isLoading) return <Spinner />;
  if (q.error) return <ErrorNote error={q.error} />;
  const g = q.data;
  const table = (title: string, rows: any[], total: any) => (
    <Card title={title} padded={false}>
      <table className="w-full text-sm">
        <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500"><th className="px-3 py-2">GST rate</th><th className="px-3 py-2 text-right">Taxable</th><th className="px-3 py-2 text-right">CGST</th><th className="px-3 py-2 text-right">SGST</th><th className="px-3 py-2 text-right">IGST</th><th className="px-3 py-2 text-right">Docs</th></tr></thead>
        <tbody>
          {rows.length === 0 && <tr><td colSpan={6} className="px-3 py-3 text-ink-500">Nothing in this period.</td></tr>}
          {rows.map((r) => <tr key={r.rate} className="border-b border-ink-100"><td className="px-3 py-2">{r.rate} %</td>{["taxable", "cgst", "sgst", "igst"].map((k) => <td key={k} className="num px-3 py-2 text-right">{inr(r[k])}</td>)}<td className="num px-3 py-2 text-right">{r.documents}</td></tr>)}
          <tr className="bg-ink-50 font-semibold"><td className="px-3 py-2">Total</td>{["taxable", "cgst", "sgst", "igst"].map((k) => <td key={k} className="num px-3 py-2 text-right">{inr(total[k])}</td>)}<td /></tr>
        </tbody>
      </table>
    </Card>
  );
  return (
    <div className="space-y-4">
      {table("Output GST — sales invoices", g.output, g.output_total)}
      <Card title="Less: credit notes"><p className="text-sm">{g.credit_notes.count} credit note(s): taxable {inr(g.credit_notes.taxable)} · CGST {inr(g.credit_notes.cgst)} · SGST {inr(g.credit_notes.sgst)} · IGST {inr(g.credit_notes.igst)}</p></Card>
      {table("Input GST — supplier bills", g.input, g.input_total)}
      <Card title="Net GST payable (before ITC set-off rules)">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          {["cgst", "sgst", "igst", "total"].map((k) => <div key={k}><p className="text-xs uppercase text-ink-500">{k === "total" ? "Total" : k.toUpperCase()}</p><p className={`num text-xl font-semibold ${Number(g.net_payable[k]) < 0 ? "text-emerald-700" : ""}`}>{inr(g.net_payable[k])}</p></div>)}
        </div>
        <p className="mt-3 text-xs text-ink-500">A working figure for GSTR-3B. File returns from your GST software / the portal; ITC cross-utilisation (IGST first, then CGST/SGST) is applied there.</p>
      </Card>
    </div>
  );
}

function Journal({ from, to }: { from: string; to: string }) {
  const list = useList<any>("/finance/journal", { filters: { date_from: from, date_to: to } });
  return (
    <Card padded={false}>
      <div className="border-b border-ink-100 p-3"><Input placeholder="Search voucher, document, narration…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" /></div>
      {list.isLoading ? <Spinner /> : (
        <ul className="divide-y divide-ink-100">{list.rows.map((e: any) => (
          <li key={e.id} className="px-4 py-3 text-sm">
            <div className="flex flex-wrap items-baseline gap-2"><span className="font-mono text-xs">{e.entry_number}</span><span className="text-ink-500">{date(e.entry_date)}</span><span className="font-medium">{e.source_number}</span><span className="ml-auto num">{inr(e.total)}</span></div>
            <p className="text-xs text-ink-500">{e.narration}</p>
            <table className="mt-1 w-full max-w-2xl text-xs"><tbody>{e.lines.map((l: any, i: number) => (
              <tr key={i}><td className={`py-0.5 ${Number(l.credit) ? "pl-6" : ""}`}>{Number(l.credit) ? "To " : ""}{l.account}</td><td className="num w-28 text-right">{Number(l.debit) ? inr(l.debit) : ""}</td><td className="num w-28 text-right">{Number(l.credit) ? inr(l.credit) : ""}</td></tr>))}</tbody></table>
          </li>))}</ul>
      )}
      {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
    </Card>
  );
}

function TrialBalance({ to }: { to: string }) {
  const q = useQuery({ queryKey: ["/finance/trial-balance", to], queryFn: () => api<any>("/finance/trial-balance", { params: { as_of: to } }), select: (r) => r.data });
  if (q.isLoading) return <Spinner />;
  if (q.error) return <ErrorNote error={q.error} />;
  return (
    <Card padded={false}>
      <table className="w-full text-sm">
        <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500"><th className="px-3 py-2">Ledger</th><th className="px-3 py-2">Group</th><th className="px-3 py-2 text-right">Debit</th><th className="px-3 py-2 text-right">Credit</th></tr></thead>
        <tbody>
          {q.data.rows.map((r: any) => <tr key={r.account_id} className="border-b border-ink-100"><td className="px-3 py-2"><span className="font-mono text-xs text-ink-500">{r.code}</span> {r.name}</td><td className="px-3 py-2 text-ink-500">{r.group}</td><td className="num px-3 py-2 text-right">{Number(r.debit) ? inr(r.debit) : ""}</td><td className="num px-3 py-2 text-right">{Number(r.credit) ? inr(r.credit) : ""}</td></tr>)}
          <tr className="bg-ink-50 font-semibold"><td className="px-3 py-2" colSpan={2}>Total {q.data.debit === q.data.credit ? "— balanced" : "— DOES NOT BALANCE"}</td><td className="num px-3 py-2 text-right">{inr(q.data.debit)}</td><td className="num px-3 py-2 text-right">{inr(q.data.credit)}</td></tr>
        </tbody>
      </table>
    </Card>
  );
}

export default function FinanceReports() {
  const { can } = useAuth();
  const [tab, setTab] = useState<Tab>("gst");
  const [from, setFrom] = useState(firstOfMonth());
  const [to, setTo] = useState(today());
  return (
    <>
      <PageHeader title="GST & books" subtitle="GST summary, the journal every document posts to, and the trial balance. The day book exports for Tally."
        actions={can("finance_report.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/finance/daybook/export", `daybook-${from}-to-${to}.xlsx`, { date_from: from, date_to: to })}>Day book for Tally</Button>} />
      <div className="mb-4 flex flex-wrap items-end gap-3">
        {tab !== "tb" && <Field label="From" className="w-44"><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></Field>}
        <Field label={tab === "tb" ? "As of" : "To"} className="w-44"><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></Field>
      </div>
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[{ id: "gst", label: "GST summary" }, { id: "journal", label: "Journal" }, { id: "tb", label: "Trial balance" }]} />
      {tab === "gst" && <Gst from={from} to={to} />}
      {tab === "journal" && <Journal key={`${from}${to}`} from={from} to={to} />}
      {tab === "tb" && <TrialBalance to={to} />}
    </>
  );
}
