"use client";

import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Card, PageHeader, Spinner } from "@/components/ui";
import { useDashboard } from "@/components/finance/common";
import { AccountsTiles } from "@/components/finance/tiles";
import { useAuth } from "@/lib/auth";
import { inr } from "@/lib/format";

export default function FinanceOverview() {
  const { can } = useAuth();
  const d = useDashboard().data;
  if (!d) return <Spinner />;
  const max = Math.max(1, ...d.trend.map((t: any) => Math.max(Number(t.billed), Number(t.collected))));
  return (
    <>
      <PageHeader title="Accounts" subtitle="Receivables, payables, collections, expenses and GST at a glance." />
      <AccountsTiles d={d} />
      <div className="mt-4 grid gap-4 lg:grid-cols-[2fr_1fr]">
        <Card title="Billed vs collected — last 6 months">
          <div className="flex h-48 items-end gap-4">
            {d.trend.map((t: any) => (
              <div key={t.month} className="flex flex-1 flex-col items-center gap-1">
                <div className="flex h-40 w-full items-end justify-center gap-1">
                  <div className="w-1/3 rounded-t bg-ink-300" style={{ height: `${(Number(t.billed) / max) * 100}%` }} title={`Billed ${inr(t.billed, 0)}`} />
                  <div className="w-1/3 rounded-t bg-brand-600" style={{ height: `${(Number(t.collected) / max) * 100}%` }} title={`Collected ${inr(t.collected, 0)}`} />
                </div>
                <span className="text-[11px] text-ink-500">{t.month}</span>
              </div>
            ))}
          </div>
          <p className="mt-2 flex gap-4 text-xs text-ink-500"><span><span className="mr-1 inline-block size-2 rounded-sm bg-ink-300" />Billed (before GST)</span><span><span className="mr-1 inline-block size-2 rounded-sm bg-brand-600" />Collected</span></p>
        </Card>
        <Card title="Go to">
          <ul className="space-y-2 text-sm">
            {[["/sales/invoices", "Sales invoices", "invoice.read"], ["/finance/receipts", "Receipts", "receipt.read"], ["/finance/receivables", "Receivables ageing", "receivable.read"],
              ["/finance/bills", "Supplier bills", "supplier_invoice.read"], ["/finance/payments", "Supplier payments", "supplier_payment.read"], ["/finance/payables", "Payables ageing", "payable.read"],
              ["/finance/expenses", "Expense claims", "expense.read"], ["/finance/reports", "GST & books", "finance_report.read"], ["/admin/masters/view?kind=ledger-accounts", "Ledger accounts", "finance_master.read"]]
              .filter(([, , p]) => can(p)).map(([h, l]) => <li key={h}><Link href={h} className="flex items-center justify-between rounded-md px-2 py-1.5 hover:bg-ink-50">{l}<ArrowRight className="size-3.5 text-ink-400" /></Link></li>)}
          </ul>
        </Card>
      </div>
    </>
  );
}
