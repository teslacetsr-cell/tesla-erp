"use client";

import { AgeingPage } from "@/components/finance/ageing";

export default function Page() {
  return <AgeingPage kind="receivables" />;
}
