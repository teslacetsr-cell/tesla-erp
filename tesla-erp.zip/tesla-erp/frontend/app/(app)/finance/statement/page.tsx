"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import { Card, ErrorNote, Field, Input, PageHeader, Spinner } from "@/components/ui";
import { api } from "@/lib/api/client";
import { date, inr } from "@/lib/format";

const LINKS: Record<string, string> = {
  invoice: "/sales/invoices/view", receipt: "/finance/receipts/view", supplier_invoice: "/finance/bills/view",
  supplier_payment: "/finance/payments/view", expense: "/finance/expenses/view", expense_payment: "/finance/expenses/view",
};

function Statement() {
  const sp = useSearchParams();
  const type = sp.get("type") ?? "customer";
  const id = sp.get("id") ?? "";
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const q = useQuery({ queryKey: ["/finance/statement", type, id, from, to], queryFn: () => api<any>("/finance/statement", { params: { party_type: type, party_id: id, date_from: from || undefined, date_to: to || undefined } }), select: (r) => r.data });
  if (q.isLoading) return <Spinner />;
  if (q.error || !q.data) return <ErrorNote error={q.error} />;
  const s = q.data;
  const back = type === "customer" ? ["/finance/receivables", "Receivables"] : type === "supplier" ? ["/finance/payables", "Payables"] : ["/finance/expenses", "Expenses"];
  return (
    <>
      <PageHeader back={<Link href={back[0]} className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> {back[1]}</Link>}
        title={`Statement — ${s.party.name}`} subtitle={type === "customer" ? "Positive balance = the customer owes us." : "Positive balance = we owe them."} />
      <Card padded={false}>
        <div className="flex flex-wrap items-end gap-3 border-b border-ink-100 p-3">
          <Field label="From" className="w-44"><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></Field>
          <Field label="To" className="w-44"><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></Field>
          <p className="ml-auto text-sm">Closing balance <b className="num text-lg">{inr(s.closing)}</b></p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-sm">
            <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
              <th className="px-3 py-2">Date</th><th className="px-3 py-2">Document</th><th className="px-3 py-2">Particulars</th>
              <th className="px-3 py-2 text-right">Debit</th><th className="px-3 py-2 text-right">Credit</th><th className="px-3 py-2 text-right">Balance</th></tr></thead>
            <tbody>
              <tr className="border-b border-ink-100 bg-ink-50"><td className="px-3 py-2" colSpan={5}>Opening balance</td><td className="num px-3 py-2 text-right">{inr(s.opening)}</td></tr>
              {s.lines.map((l: any, i: number) => (
                <tr key={i} className="border-b border-ink-100 align-top">
                  <td className="px-3 py-2 whitespace-nowrap">{date(l.date)}</td>
                  <td className="px-3 py-2">{LINKS[l.type] ? <Link className="text-brand-700 hover:underline" href={`${LINKS[l.type]}?id=${l.source_id}`}>{l.reference ?? l.entry_number}</Link> : l.reference ?? l.entry_number}</td>
                  <td className="px-3 py-2 text-ink-600">{l.narration}</td>
                  <td className="num px-3 py-2 text-right">{Number(l.debit) ? inr(l.debit) : ""}</td>
                  <td className="num px-3 py-2 text-right">{Number(l.credit) ? inr(l.credit) : ""}</td>
                  <td className="num px-3 py-2 text-right font-medium">{inr(l.balance)}</td>
                </tr>
              ))}
              <tr className="bg-ink-50 font-semibold"><td className="px-3 py-2" colSpan={3}>Total / closing</td><td className="num px-3 py-2 text-right">{inr(s.debits)}</td><td className="num px-3 py-2 text-right">{inr(s.credits)}</td><td className="num px-3 py-2 text-right">{inr(s.closing)}</td></tr>
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
}

export default function Page() {
  return <Suspense><Statement /></Suspense>;
}
