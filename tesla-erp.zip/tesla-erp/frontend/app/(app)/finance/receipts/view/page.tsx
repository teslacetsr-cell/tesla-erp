"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, FileDown, Link2, Unlink, XCircle } from "lucide-react";
import { Badge, Button, Card, Detail, ErrorNote, Modal, PageHeader, Spinner, Tabs, useConfirm, useToast } from "@/components/ui";
import { AllocateDialogBody } from "@/components/finance/money-form";
import { TallyBadge } from "@/components/finance/tally-badge";
import { ReasonDialog } from "@/components/purchase/common";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api, download } from "@/lib/api/client";
import { date, dateTime, inr } from "@/lib/format";

type Tab = "allocations" | "documents" | "history";

function ReceiptDetail() {
  const id = useSearchParams().get("id") ?? "";
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [tab, setTab] = useState<Tab>("allocations");
  const [dialog, setDialog] = useState<"cancel" | "allocate" | null>(null);
  const { data: r, isLoading, error } = useQuery({ queryKey: ["/receipts", id], queryFn: () => api<any>(`/receipts/${id}`), select: (x) => x.data });
  const refresh = () => { ["/receipts", "/invoices", "/finance/dashboard"].forEach((k) => qc.invalidateQueries({ queryKey: [k] })); };
  if (isLoading) return <Spinner />;
  if (error || !r) return <ErrorNote error={error} />;
  const tdsUsed = r.allocations.filter((a: any) => a.is_active).reduce((s: number, a: any) => s + Number(a.tds), 0);
  return (
    <>
      <PageHeader back={<Link href="/finance/receipts" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Receipts</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{r.receipt_number} {r.status === "cancelled" && <Badge tone="grey">Cancelled</Badge>} <TallyBadge entityType="receipt" entityId={id} /></span>}
        subtitle={`${r.customer} · ${date(r.receipt_date)} · ${r.mode.toUpperCase()}${r.reference_no ? ` ${r.reference_no}` : ""}`}
        actions={<>
          {r.can.allocate && <Button icon={<Link2 className="size-4" />} onClick={() => setDialog("allocate")}>Allocate to invoices</Button>}
          {r.can.print && <Button variant="secondary" icon={<FileDown className="size-4" />} onClick={() => download(`/receipts/${id}/pdf`, `${r.receipt_number.replaceAll("/", "-")}.pdf`)}>Receipt PDF</Button>}
          {r.can.cancel && <Button variant="ghost" icon={<XCircle className="size-4" />} onClick={() => setDialog("cancel")}>Cancel receipt</Button>}
        </>} />
      {r.status === "cancelled" && <p className="mb-4 rounded-md bg-ink-100 px-3 py-2 text-sm"><b>Cancelled:</b> {r.status_reason}</p>}
      <div className="mb-4 grid gap-4 lg:grid-cols-[1fr_320px]">
        <Card>
          <Detail cols={3} items={[
            ["Customer", <Link key="c" href={`/customers/view?id=${r.customer_id}`} className="text-brand-700 hover:underline">{r.customer}</Link>],
            ["Date", date(r.receipt_date)], ["Mode", r.mode.toUpperCase()], ["Reference", r.reference_no], ["Cheque date", date(r.instrument_date)], ["Bank", r.bank_name],
            ["Project", r.project ? <Link key="p" href={`/projects/view?id=${r.project.id}`} className="text-brand-700 hover:underline">{r.project.number}</Link> : "—"],
            ["Notes", r.notes],
          ]} />
        </Card>
        <Card>
          <p className="text-xs uppercase tracking-wide text-ink-500">Received</p>
          <p className="num mt-1 text-3xl font-semibold text-ink-900">{inr(r.amount)}</p>
          {Number(r.tds_amount) > 0 && <p className="text-sm text-ink-600">+ TDS {inr(r.tds_amount)}</p>}
          <p className="mt-2 text-sm">Allocated <span className="num">{inr(r.allocated)}</span></p>
          {Number(r.unallocated) > 0 && <p className="mt-1"><Badge tone="amber">On account {inr(r.unallocated)}</Badge></p>}
        </Card>
      </div>
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[{ id: "allocations", label: "Invoices settled", count: r.allocations.filter((a: any) => a.is_active).length }, { id: "documents", label: "Documents" }, { id: "history", label: "History" }]} />
      {tab === "allocations" && (
        <Card padded={false}>
          {r.allocations.length === 0 ? <p className="p-4 text-sm text-ink-500">Not allocated to any invoice — the whole amount is an advance.</p> : (
            <ul className="divide-y divide-ink-100">{r.allocations.map((a: any) => (
              <li key={a.id} className={`flex flex-wrap items-center gap-3 px-4 py-3 text-sm ${a.is_active ? "" : "opacity-50"}`}>
                <Link href={`/sales/invoices/view?id=${a.invoice_id}`} className="font-medium text-brand-700 hover:underline">{a.invoice_number}</Link>
                <span className="text-xs text-ink-500">{dateTime(a.created_at)}</span>
                {!a.is_active && <Badge tone="grey">Released</Badge>}
                <span className="num ml-auto">{inr(a.amount)}{Number(a.tds) ? <span className="text-ink-500"> + TDS {inr(a.tds)}</span> : null}</span>
                {a.is_active && r.can.unallocate && <Button size="sm" variant="ghost" icon={<Unlink className="size-3.5" />} onClick={async () => {
                  if (!(await confirm({ title: `Take this off ${a.invoice_number}?`, body: "The invoice becomes unpaid by this amount and the money stays on this receipt as an advance.", confirmLabel: "Take off" }))) return;
                  try { await api(`/receipts/${id}/allocations/${a.id}/remove`, { method: "POST" }); toast("Allocation removed"); refresh(); } catch (e: any) { toast(e.message, "error"); }
                }}>Take off</Button>}
              </li>))}</ul>
          )}
        </Card>
      )}
      {tab === "documents" && <DocumentsPanel entityType="receipt" entityId={id} canEdit={r.can.allocate || r.can.cancel} defaultCategory="receipt" />}
      {tab === "history" && <HistoryPanel entityType="receipt" entityId={id} />}
      <ReasonDialog open={dialog === "cancel"} title="Cancel this receipt?" label="Reason (e.g. cheque returned unpaid). Invoices it paid become unpaid again and the books are reversed." required confirmLabel="Cancel receipt"
        onClose={() => setDialog(null)} onSubmit={async (reason) => { await api(`/receipts/${id}/cancel`, { body: { reason, row_version: r.row_version } }); toast("Receipt cancelled"); refresh(); }} />
      <Modal open={dialog === "allocate"} onClose={() => setDialog(null)} title="Allocate to invoices" wide>
        {dialog === "allocate" && <AllocateDialogBody kind="customer" partyId={r.customer_id} free={Number(r.unallocated)} tdsFree={Math.max(Number(r.tds_amount) - tdsUsed, 0)} onCancel={() => setDialog(null)}
          onSubmit={async (allocations) => { await api(`/receipts/${id}/allocate`, { body: { allocations, row_version: r.row_version } }); toast("Allocated"); refresh(); setDialog(null); }} />}
      </Modal>
    </>
  );
}

export default function Page() {
  return <Suspense><ReceiptDetail /></Suspense>;
}
