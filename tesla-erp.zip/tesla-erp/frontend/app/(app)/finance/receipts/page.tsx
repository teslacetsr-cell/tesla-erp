"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Download, IndianRupee, Plus } from "lucide-react";
import { Badge, Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { MiniStat } from "@/components/crm/common";
import { useDashboard } from "@/components/finance/common";
import { download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function ReceiptsPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/receipts");
  const d = useDashboard(can("receivable.read")).data;
  const f = list.filters;
  const view = f.unallocated === "true" ? "unallocated" : f.status ?? "";
  const setView = (v: string) => { list.setFilter("unallocated", v === "unallocated" ? "true" : ""); list.setFilter("status", ["posted", "cancelled"].includes(v) ? v : ""); };
  return (
    <>
      <PageHeader title="Receipts" subtitle="Money received from customers, with TDS they deducted, allocated to invoices. What is not allocated stays as an advance."
        actions={<>
          {can("receipt.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/receipts/export", "collections.xlsx", { q: list.q })}>Collection report</Button>}
          {can("receipt.create") && <Link href="/finance/receipts/new"><Button icon={<Plus className="size-4" />}>Record receipt</Button></Link>}
        </>} />
      {d && (
        <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <MiniStat label="Collected this month" value={inr(d.collected_month, 0)} />
          <MiniStat label="Receivable" value={inr(d.receivable, 0)} />
          <MiniStat label="Overdue" value={inr(d.receivable_overdue, 0)} tone="red" />
          <MiniStat label="Advances on account" value={inr(d.customer_advances, 0)} tone="amber" onClick={() => setView("unallocated")} active={view === "unallocated"} />
        </div>
      )}
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search receipt no., UTR / cheque, customer…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={view} onChange={(e) => setView(e.target.value)} className="sm:w-52" aria-label="Show">
            <option value="">All receipts</option><option value="unallocated">With money on account</option><option value="posted">Posted</option><option value="cancelled">Cancelled</option>
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/finance/receipts/view?id=${r.id}`)}
            empty={<EmptyState icon={<IndianRupee className="size-8" />} title="No receipts here" />}
            columns={[
              { key: "n", header: "Receipt", sortKey: "receipt_number", cell: (r) => <div><p className="font-medium text-ink-900">{r.customer}</p><p className="text-xs text-ink-500">{r.receipt_number} · {r.mode.toUpperCase()}{r.reference_no ? ` ${r.reference_no}` : ""}</p></div> },
              { key: "d", header: "Date", sortKey: "receipt_date", hideOnMobile: true, cell: (r) => date(r.receipt_date) },
              { key: "a", header: "Amount", sortKey: "amount", className: "text-right", cell: (r) => <span className="num">{inr(r.amount)}</span> },
              { key: "t", header: "TDS", className: "text-right", hideOnMobile: true, cell: (r) => <span className="num text-ink-500">{Number(r.tds_amount) ? inr(r.tds_amount) : ""}</span> },
              { key: "u", header: "On account", className: "text-right", hideOnMobile: true, cell: (r) => <span className="num">{Number(r.unallocated) ? inr(r.unallocated) : ""}</span> },
              { key: "s", header: "", cell: (r) => r.status === "cancelled" ? <Badge tone="grey">Cancelled</Badge> : null },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
