"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader, useToast } from "@/components/ui";
import { MoneyForm } from "@/components/finance/money-form";
import { api } from "@/lib/api/client";

function NewReceipt() {
  const sp = useSearchParams();
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Record receipt" subtitle="Money from a customer — by bank, cheque, UPI or cash — and the TDS they deducted." />
      <MoneyForm kind="receipt" partyId={sp.get("customer")} docId={sp.get("invoice")} onCancel={() => router.back()} onSubmit={async (body) => {
        const r = await api<any>("/receipts", { body });
        toast(`Receipt ${r.data.receipt_number} saved`);
        qc.invalidateQueries({ queryKey: ["/receipts"] }); qc.invalidateQueries({ queryKey: ["/invoices"] }); qc.invalidateQueries({ queryKey: ["/finance/dashboard"] });
        router.push(`/finance/receipts/view?id=${r.data.id}`);
      }} />
    </div>
  );
}

export default function Page() {
  return <Suspense><NewReceipt /></Suspense>;
}
