"use client";

import Link from "next/link";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AlarmClock } from "lucide-react";
import { Badge, Card, EmptyState, PageHeader, Pagination, Spinner } from "@/components/ui";
import { MiniStat } from "@/components/crm/common";
import { DoneButton, isOverdue, type Activity } from "@/components/crm/activities";
import { api, type Page } from "@/lib/api/client";
import { dateTime } from "@/lib/format";

type Bucket = "overdue" | "today" | "upcoming" | "done";

export default function FollowUpsPage() {
  const [bucket, setBucket] = useState<Bucket>("today");
  const [mine, setMine] = useState(true);
  const [page, setPage] = useState(1);
  const qc = useQueryClient();
  const key = ["/crm/follow-ups", bucket, mine, page];
  const { data, isLoading } = useQuery({ queryKey: key, queryFn: () => api<Page<Activity>>("/crm/follow-ups", { params: { bucket, mine, page, page_size: 25 } }) });
  const summary = useQuery({ queryKey: ["/crm/summary"], queryFn: () => api<{ data: any }>("/crm/summary"), select: (r) => r.data });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/crm/follow-ups"] }); qc.invalidateQueries({ queryKey: ["/crm/summary"] }); qc.invalidateQueries({ queryKey: ["/crm/activities"] }); };
  const pick = (b: Bucket) => { setBucket(b); setPage(1); };

  return (
    <>
      <PageHeader title="Follow-ups" subtitle="Calls, visits and proposals promised to customers — so nothing is forgotten." />
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <MiniStat label="Overdue (mine)" value={summary.data?.my_follow_ups_overdue} tone="red" onClick={() => pick("overdue")} active={bucket === "overdue"} />
        <MiniStat label="Due today (mine)" value={summary.data?.my_follow_ups_today} tone="amber" onClick={() => pick("today")} active={bucket === "today"} />
        <MiniStat label="Upcoming" value={bucket === "upcoming" ? data?.meta.total : undefined} onClick={() => pick("upcoming")} active={bucket === "upcoming"} />
        <MiniStat label="Done" value={bucket === "done" ? data?.meta.total : undefined} onClick={() => pick("done")} active={bucket === "done"} />
      </div>
      <Card padded={false} title={{ overdue: "Overdue", today: "Due today", upcoming: "Upcoming", done: "Done" }[bucket]}
        actions={
          <div className="inline-flex rounded-md border border-ink-200 p-0.5 text-[13px]">
            {[true, false].map((m) => (
              <button key={String(m)} onClick={() => { setMine(m); setPage(1); }} className={`rounded px-2.5 py-1 ${mine === m ? "bg-brand-600 text-white" : "text-ink-600 hover:bg-ink-100"}`}>
                {m ? "Mine" : "Everyone"}
              </button>
            ))}
          </div>
        }>
        {isLoading ? <Spinner /> : !data?.data.length ? (
          <EmptyState icon={<AlarmClock className="size-8" />} title={bucket === "overdue" ? "Nothing overdue" : bucket === "today" ? "Nothing due today" : "Nothing here"} body="Follow-ups are added on leads and enquiries, and automatically from site visit reports." />
        ) : (
          <ul className="divide-y divide-ink-100">
            {data.data.map((a) => (
              <li key={a.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-ink-900">{a.subject} {isOverdue(a) && <Badge tone="red">Overdue</Badge>}</p>
                  {a.parent && (
                    <Link href={a.parent.href} className="text-xs text-brand-700 hover:underline">
                      {a.parent.number}{a.parent.party ? ` · ${a.parent.party}` : ""} — {a.parent.title}
                    </Link>
                  )}
                  <p className="text-xs text-ink-500">
                    {a.done_at ? `Done ${dateTime(a.done_at)} by ${a.done_by ?? "—"}${a.outcome ? ` · ${a.outcome}` : ""}` : `Due ${dateTime(a.due_at)}`}
                    {!mine && a.assigned_to && ` · ${a.assigned_to}`}
                  </p>
                </div>
                {!a.done_at && <DoneButton a={a} onDone={refresh} />}
              </li>
            ))}
          </ul>
        )}
        {data && data.meta.total > 0 && <Pagination page={page} pageSize={data.meta.page_size} total={data.meta.total} onPage={setPage} />}
      </Card>
    </>
  );
}
