"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, CalendarPlus, Pencil, Trash2 } from "lucide-react";
import { Badge, Button, Card, DataTable, Detail, EmptyState, ErrorNote, PageHeader, Spinner, Tabs, useConfirm, useToast } from "@/components/ui";
import { CrmStatus, ENQUIRY_STATUSES, PriorityBadge, sourceLabel, StatusDialog } from "@/components/crm/common";
import { ActivityPanel } from "@/components/crm/activities";
import { EnquiryForm } from "@/components/crm/enquiry-form";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, dateTime, inr, titleCase } from "@/lib/format";

type Tab = "overview" | "visits" | "activity" | "documents" | "history";

function EnquiryDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const { can } = useAuth();
  const [tab, setTab] = useState<Tab>("overview");
  const [editing, setEditing] = useState(false);
  const [statusOpen, setStatusOpen] = useState(false);
  const key = ["/enquiries", id];
  const { data, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api(`/enquiries/${id}`), select: (r: any) => r.data });
  const visits = useQuery({ queryKey: ["/site-visits", "enquiry", id], queryFn: () => api<any>("/site-visits", { params: { enquiry_id: id, page_size: 50 } }), enabled: can("site_visit.read") && !!id });
  const refresh = () => { qc.invalidateQueries({ queryKey: key }); qc.invalidateQueries({ queryKey: ["/enquiries"] }); qc.invalidateQueries({ queryKey: ["/crm/summary"] }); };

  if (isLoading) return <Spinner />;
  if (error || !data) return <ErrorNote error={error} />;
  const e = data;
  const closed = ["won", "lost", "cancelled"].includes(e.status);

  if (editing)
    return (
      <div className="mx-auto max-w-4xl">
        <PageHeader title={`Edit ${e.enquiry_number}`} />
        <EnquiryForm initial={e} customerLocked={(visits.data?.meta.total ?? 0) > 0} submitLabel="Save changes" onCancel={() => setEditing(false)}
          onSubmit={async (values) => {
            await api(`/enquiries/${id}`, { method: "PUT", body: { ...values, row_version: e.row_version } });
            toast("Enquiry saved");
            setEditing(false);
            refresh();
          }} />
      </div>
    );

  return (
    <>
      <PageHeader
        back={<Link href="/crm/enquiries" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Enquiries</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{e.subject} <CrmStatus kind="enquiry" status={e.status} /> <PriorityBadge priority={e.priority} /></span>}
        subtitle={`${e.enquiry_number} · ${e.customer?.name}${e.sales_person ? ` · ${e.sales_person}` : ""}`}
        actions={<>
          {can("site_visit.create") && !closed && <Link href={`/crm/site-visits/new?enquiry_id=${id}`}><Button icon={<CalendarPlus className="size-4" />}>Schedule site visit</Button></Link>}
          {e.can_edit && <Button variant="secondary" onClick={() => setStatusOpen(true)}>Change status</Button>}
          {e.can_edit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {e.can_delete && (
            <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
              if (!(await confirm({ title: "Delete enquiry?", body: "Only enquiries without site visits can be deleted. Otherwise set it to Cancelled.", confirmLabel: "Delete" }))) return;
              try { await api(`/enquiries/${id}`, { method: "DELETE" }); toast("Enquiry deleted"); qc.invalidateQueries({ queryKey: ["/enquiries"] }); router.push("/crm/enquiries"); }
              catch (err: any) { toast(err.message, "error"); }
            }}>Delete</Button>
          )}
        </>} />
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[
        { id: "overview", label: "Overview" },
        ...(can("site_visit.read") ? [{ id: "visits" as Tab, label: "Site visits", count: visits.data?.meta.total }] : []),
        { id: "activity", label: "Follow-ups & activity" }, { id: "documents", label: "Documents" }, { id: "history", label: "History" },
      ]} />
      {tab === "overview" && (
        <div className="grid gap-4 xl:grid-cols-[1fr_340px]">
          <div className="space-y-4">
            <Card title="Scope"><p className="whitespace-pre-line text-sm text-ink-800">{e.description || <span className="text-ink-400">No description.</span>}</p></Card>
            <Card title="Details">
              <Detail items={[
                ["Enquiry date", date(e.enquiry_date)], ["Required by", date(e.required_by)], ["Priority", titleCase(e.priority)],
                ["Estimated value", e.estimated_value ? <span className="num">{inr(e.estimated_value, 0)}</span> : null],
                ["Division", e.division], ["Source", sourceLabel(e.source)], ["Salesperson", e.sales_person],
                ["From lead", e.lead_id ? <Link key="l" href={`/crm/leads/view?id=${e.lead_id}`} className="text-brand-700 hover:underline">{e.lead_number}</Link> : null],
                ...(e.status === "lost" ? [["Lost because", e.lost_reason] as [string, string]] : []),
              ]} />
            </Card>
            <div className="flex flex-wrap gap-1.5">{["BOQ", "Quotation"].map((x) => <Badge key={x}>{x} — Phase 3</Badge>)}</div>
          </div>
          <div className="space-y-4">
            <Card title="Customer">
              <Link href={`/customers/view?id=${e.customer_id}`} className="text-sm font-medium text-brand-700 hover:underline">{e.customer?.name} · {e.customer?.code}</Link>
              {e.site && <p className="mt-1 text-sm text-ink-600">Site: {e.site}</p>}
              {e.contact && (
                <div className="mt-3 text-sm">
                  <p className="font-medium">{e.contact.name}</p>
                  {e.contact.designation && <p className="text-ink-500">{e.contact.designation}</p>}
                  {e.contact.phone && <a className="block text-brand-700" href={`tel:${e.contact.phone.replace(/\s/g, "")}`}>{e.contact.phone}</a>}
                  {e.contact.email && <a className="block text-brand-700" href={`mailto:${e.contact.email}`}>{e.contact.email}</a>}
                </div>
              )}
            </Card>
            <p className="text-xs text-ink-400">Created {dateTime(e.created_at)}{e.created_by ? ` by ${e.created_by}` : ""} · updated {dateTime(e.updated_at)}</p>
          </div>
        </div>
      )}
      {tab === "visits" && (
        <Card padded={false}>
          <DataTable rows={visits.data?.data ?? []} onRowClick={(r: any) => router.push(`/crm/site-visits/view?id=${r.id}`)}
            empty={<EmptyState title="No site visits yet" body={can("site_visit.create") && !closed ? "Use “Schedule site visit” to send an engineer." : undefined} />}
            columns={[
              { key: "n", header: "Visit", cell: (r: any) => <div><p className="font-medium">{date(r.visit_date)}{r.visit_time ? `, ${r.visit_time}` : ""}</p><p className="text-xs text-ink-500">{r.visit_number}</p></div> },
              { key: "e", header: "Engineer", cell: (r: any) => r.engineer ?? "—" },
              { key: "p", header: "Purpose", hideOnMobile: true, cell: (r: any) => r.purpose ?? "—" },
              { key: "s", header: "Status", cell: (r: any) => <CrmStatus kind="visit" status={r.status} /> },
            ]} />
        </Card>
      )}
      {tab === "activity" && <ActivityPanel enquiryId={id} canEdit={e.can_edit} />}
      {tab === "documents" && <DocumentsPanel entityType="enquiry" entityId={id} canEdit={e.can_edit} />}
      {tab === "history" && <HistoryPanel entityType="enquiry" entityId={id} />}
      <StatusDialog open={statusOpen} onClose={() => setStatusOpen(false)} statuses={ENQUIRY_STATUSES} current={e.status} title="Change enquiry status"
        onSubmit={async (status, lost_reason) => { await api(`/enquiries/${id}/status`, { body: { status, lost_reason, row_version: e.row_version } }); toast("Status updated"); refresh(); qc.invalidateQueries({ queryKey: ["/leads"] }); }} />
    </>
  );
}

export default function Page() {
  return <Suspense><EnquiryDetail /></Suspense>;
}
