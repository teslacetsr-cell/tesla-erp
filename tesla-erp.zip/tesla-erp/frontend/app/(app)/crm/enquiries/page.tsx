"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Download, Inbox, Plus } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { CrmStatus, ENQUIRY_STATUSES, PriorityBadge, usePeople } from "@/components/crm/common";
import { download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function EnquiriesPage() {
  const router = useRouter();
  const { can, me } = useAuth();
  const list = useList<any>("/enquiries", { filters: { open_only: "true" } });
  const allScope = me?.permissions["enquiry.read"] !== "own";
  const sales = usePeople("sales", allScope);
  const statusValue = list.filters.status || (list.filters.open_only === "true" ? "_open" : "");
  const setStatus = (v: string) => { list.setFilter("open_only", v === "_open" ? "true" : ""); list.setFilter("status", v.startsWith("_") ? "" : v); };
  return (
    <>
      <PageHeader title="Enquiries" subtitle="Confirmed requirements from customers — each one leads to site visits, BOQ and a quotation."
        actions={<>
          {can("enquiry.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/enquiries/export", "enquiries.xlsx", { q: list.q, ...list.filters })}>Export</Button>}
          {can("enquiry.create") && <Link href="/crm/enquiries/new"><Button icon={<Plus className="size-4" />}>New enquiry</Button></Link>}
        </>} />
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search number, subject, customer…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={statusValue} onChange={(e) => setStatus(e.target.value)} className="sm:w-52" aria-label="Status">
            <option value="_open">Open enquiries</option>
            <option value="">All statuses</option>
            {ENQUIRY_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
          {allScope && (
            <Select value={list.filters.sales_person_id ?? ""} onChange={(e) => list.setFilter("sales_person_id", e.target.value)} className="sm:w-52" aria-label="Salesperson">
              <option value="">All salespeople</option>
              {sales.data?.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          )}
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/crm/enquiries/view?id=${r.id}`)}
            empty={<EmptyState icon={<Inbox className="size-8" />} title={list.q ? "No enquiries match your search" : "No enquiries here"} />}
            columns={[
              { key: "s", header: "Enquiry", sortKey: "created_at", cell: (r) => <div><p className="font-medium text-ink-900">{r.subject} <PriorityBadge priority={r.priority} /></p><p className="text-xs text-ink-500">{r.enquiry_number}</p></div> },
              { key: "c", header: "Customer", cell: (r) => <div>{r.customer?.name}<p className="text-xs text-ink-500">{r.site ?? r.customer?.city ?? ""}</p></div> },
              { key: "d", header: "Date", sortKey: "enquiry_date", hideOnMobile: true, cell: (r) => date(r.enquiry_date) },
              { key: "r", header: "Required by", sortKey: "required_by", hideOnMobile: true, cell: (r) => date(r.required_by) },
              { key: "v", header: "Value", sortKey: "estimated_value", className: "text-right", hideOnMobile: true, cell: (r) => <span className="num">{r.estimated_value ? inr(r.estimated_value, 0) : "—"}</span> },
              { key: "st", header: "Status", sortKey: "status", cell: (r) => <CrmStatus kind="enquiry" status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
