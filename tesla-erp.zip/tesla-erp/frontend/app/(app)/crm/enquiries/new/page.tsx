"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { ArrowLeft } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader, Spinner, useToast } from "@/components/ui";
import { EnquiryForm } from "@/components/crm/enquiry-form";
import { useCustomerDetail } from "@/components/crm/common";
import { api } from "@/lib/api/client";

function NewEnquiry() {
  const router = useRouter();
  const toast = useToast();
  const qc = useQueryClient();
  const customerId = useSearchParams().get("customer_id");
  const customer = useCustomerDetail(customerId);
  if (customerId && customer.isLoading) return <Spinner />;
  const c = customer.data;
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader back={<Link href="/crm/enquiries" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Enquiries</Link>} title="New enquiry" />
      <EnquiryForm submitLabel="Create enquiry" onCancel={() => router.back()}
        initial={c ? { customer: { id: c.id, name: c.customer_name, code: c.customer_code, city: c.city }, sales_person_id: c.assigned_sales_person_id } : undefined}
        onSubmit={async (values) => {
          const r = await api("/enquiries", { body: values });
          qc.invalidateQueries({ queryKey: ["/enquiries"] });
          toast(`Enquiry ${r.data.enquiry_number} created`);
          router.push(`/crm/enquiries/view?id=${r.data.id}`);
        }} />
    </div>
  );
}

export default function Page() {
  return <Suspense><NewEnquiry /></Suspense>;
}
