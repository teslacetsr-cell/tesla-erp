"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, ArrowRightCircle, Pencil, Phone, Mail, Trash2 } from "lucide-react";
import { Button, Card, DataTable, Detail, EmptyState, ErrorNote, Field, Input, Modal, PageHeader, Spinner, Tabs, Textarea, useConfirm, useToast } from "@/components/ui";
import { SelectInput } from "@/components/forms";
import { CrmStatus, CustomerPicker, LEAD_STATUSES, PRIORITIES, sourceLabel, StatusDialog, useCustomerDetail, type CustomerRef } from "@/components/crm/common";
import { ActivityPanel } from "@/components/crm/activities";
import { LeadForm } from "@/components/crm/lead-form";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api, ApiError } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, dateTime, inr } from "@/lib/format";
import { useForm } from "react-hook-form";

type Tab = "overview" | "activity" | "enquiries" | "documents" | "history";

function ConvertDialog({ lead, open, onClose, onDone }: { lead: any; open: boolean; onClose: () => void; onDone: (enquiryId: string) => void }) {
  const [customer, setCustomer] = useState<CustomerRef | null>(null);
  const [mode, setMode] = useState<"new" | "existing">("new");
  const [dups, setDups] = useState<any[] | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  const linked: CustomerRef | null = lead.customer ? { id: lead.customer.id, name: lead.customer.name, code: lead.customer.code, city: lead.customer.city } : null;
  const target = linked ?? (mode === "existing" ? customer : null);
  const detail = useCustomerDetail(target?.id);
  const form = useForm({ defaultValues: { subject: lead.title, description: lead.requirement ?? "", site_id: "", required_by: "", priority: "normal" } });
  const sites: [string, string][] = [["", "— No specific site —"], ...(detail.data?.sites ?? []).filter((s: any) => s.is_active).map((s: any) => [s.id, [s.site_name, s.city].filter(Boolean).join(", ")] as [string, string])];

  async function go(extra: Record<string, any> = {}) {
    setError(null);
    setBusy(true);
    const v = form.getValues();
    const body: Record<string, any> = { subject: v.subject || null, description: v.description || null, site_id: v.site_id || null, required_by: v.required_by || null, priority: v.priority, ...extra };
    if (!linked && mode === "existing") {
      if (!customer) { setBusy(false); return setError(new Error("Choose the customer.")); }
      body.customer_id = customer.id;
    }
    try {
      const r = await api("/leads/" + lead.id + "/convert", { body });
      onDone(r.data.id);
    } catch (err) {
      if (err instanceof ApiError && err.code === "POSSIBLE_DUPLICATE_CUSTOMER") setDups((err.details as any)?.candidates ?? []);
      else setError(err);
    } finally { setBusy(false); }
  }

  return (
    <Modal open={open} onClose={onClose} title="Create enquiry from lead" wide
      footer={dups ? null : <><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={() => go()}>Create enquiry</Button></>}>
      {dups ? (
        <div className="space-y-4">
          <p className="text-sm text-ink-700">A customer that looks the same already exists. Use it so the customer is not duplicated:</p>
          <ul className="divide-y divide-ink-100 rounded-md border border-ink-200">
            {dups.map((d) => (
              <li key={d.id} className="flex items-center gap-3 px-3 py-2.5">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">{d.customer_name} <span className="text-ink-500">· {d.customer_code}</span></p>
                  <p className="text-xs text-ink-500">{[d.city, d.reasons.join(", ")].filter(Boolean).join(" · ")}</p>
                </div>
                <Button size="sm" loading={busy} onClick={() => go({ customer_id: d.id })}>Use this customer</Button>
              </li>
            ))}
          </ul>
          <div className="flex justify-between gap-2">
            <Button variant="secondary" onClick={() => setDups(null)}>Back</Button>
            <Button variant="secondary" loading={busy} onClick={() => go({ allow_duplicate: true })}>No — create a new customer</Button>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <ErrorNote error={error} />
          {linked ? (
            <p className="rounded-md bg-ink-50 px-3 py-2 text-sm">Customer: <b>{linked.name}</b> ({linked.code})</p>
          ) : (
            <div className="space-y-3">
              <div className="inline-flex rounded-md border border-ink-200 p-0.5 text-sm">
                {(["new", "existing"] as const).map((m) => (
                  <button key={m} type="button" onClick={() => setMode(m)} className={`rounded px-3 py-1.5 ${mode === m ? "bg-brand-600 text-white" : "text-ink-600 hover:bg-ink-100"}`}>
                    {m === "new" ? "Create customer from prospect" : "Link to existing customer"}
                  </button>
                ))}
              </div>
              {mode === "new" ? (
                <p className="text-sm text-ink-600">A customer record is created from <b>{lead.company_name ?? lead.contact_name}</b>{lead.contact_phone ? `, ${lead.contact_phone}` : ""}. Existing customers are checked first.</p>
              ) : (
                <Field label="Customer" required><CustomerPicker value={customer} onChange={setCustomer} /></Field>
              )}
            </div>
          )}
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Subject" className="sm:col-span-2"><Input {...form.register("subject")} /></Field>
            <Field label="Scope / description" className="sm:col-span-2"><Textarea rows={3} {...form.register("description")} /></Field>
            {target && <Field label="Site"><SelectInput control={form.control} name="site_id" options={sites} /></Field>}
            <Field label="Required by"><Input type="date" {...form.register("required_by")} /></Field>
            <Field label="Priority"><SelectInput control={form.control} name="priority" options={PRIORITIES} /></Field>
          </div>
        </div>
      )}
    </Modal>
  );
}

function LeadDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const { can } = useAuth();
  const [tab, setTab] = useState<Tab>("overview");
  const [editing, setEditing] = useState(false);
  const [statusOpen, setStatusOpen] = useState(false);
  const [converting, setConverting] = useState(false);
  const key = ["/leads", id];
  const { data, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api(`/leads/${id}`), select: (r: any) => r.data });
  const enquiries = useQuery({ queryKey: ["/enquiries", "lead", id], queryFn: () => api<any>("/enquiries", { params: { lead_id: id, page_size: 50 } }), enabled: can("enquiry.read") && !!id });
  const refresh = () => { qc.invalidateQueries({ queryKey: key }); qc.invalidateQueries({ queryKey: ["/leads"] }); qc.invalidateQueries({ queryKey: ["/crm/summary"] }); };

  if (isLoading) return <Spinner />;
  if (error || !data) return <ErrorNote error={error} />;
  const l = data;
  const closed = ["won", "lost"].includes(l.status);

  if (editing)
    return (
      <div className="mx-auto max-w-4xl">
        <PageHeader title={`Edit ${l.lead_number}`} />
        <LeadForm initial={l} submitLabel="Save changes" onCancel={() => setEditing(false)} onSubmit={async (values) => {
          await api(`/leads/${id}`, { method: "PUT", body: { ...values, row_version: l.row_version } });
          toast("Lead saved");
          setEditing(false);
          refresh();
        }} />
      </div>
    );

  return (
    <>
      <PageHeader
        back={<Link href="/crm/leads" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Leads</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{l.title} <CrmStatus kind="lead" status={l.status} /></span>}
        subtitle={`${l.lead_number} · ${l.customer?.name ?? l.company_name ?? l.contact_name}${l.sales_person ? ` · ${l.sales_person}` : ""}`}
        actions={<>
          {l.can_edit && can("enquiry.create") && !closed && <Button icon={<ArrowRightCircle className="size-4" />} onClick={() => setConverting(true)}>Create enquiry</Button>}
          {l.can_edit && <Button variant="secondary" onClick={() => setStatusOpen(true)}>Change status</Button>}
          {l.can_edit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {l.can_delete && (
            <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
              if (!(await confirm({ title: "Delete lead?", body: "Only leads without enquiries or visits can be deleted. Otherwise mark it Lost.", confirmLabel: "Delete" }))) return;
              try { await api(`/leads/${id}`, { method: "DELETE" }); toast("Lead deleted"); qc.invalidateQueries({ queryKey: ["/leads"] }); router.push("/crm/leads"); }
              catch (e: any) { toast(e.message, "error"); }
            }}>Delete</Button>
          )}
        </>} />
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[
        { id: "overview", label: "Overview" }, { id: "activity", label: "Follow-ups & activity" },
        ...(can("enquiry.read") ? [{ id: "enquiries" as Tab, label: "Enquiries", count: enquiries.data?.meta.total }] : []),
        { id: "documents", label: "Documents" }, { id: "history", label: "History" },
      ]} />
      {tab === "overview" && (
        <div className="grid gap-4 xl:grid-cols-[1fr_340px]">
          <div className="space-y-4">
            <Card title="Requirement"><p className="whitespace-pre-line text-sm text-ink-800">{l.requirement || <span className="text-ink-400">No details recorded.</span>}</p></Card>
            <Card title="Pipeline">
              <Detail items={[
                ["Estimated value", l.estimated_value ? <span className="num">{inr(l.estimated_value, 0)}</span> : null],
                ["Probability", l.probability !== null ? `${l.probability}%` : null], ["Expected closing", date(l.expected_closing_date)],
                ["Division", l.division], ["Source", sourceLabel(l.source)], ["Salesperson", l.sales_person],
                ...(l.status === "lost" ? [["Lost because", l.lost_reason] as [string, string]] : []),
              ]} />
            </Card>
            {l.notes && <Card title="Internal notes"><p className="whitespace-pre-line text-sm">{l.notes}</p></Card>}
          </div>
          <div className="space-y-4">
            <Card title={l.customer ? "Customer" : "Prospect"}>
              {l.customer ? (
                <Link href={`/customers/view?id=${l.customer.id}`} className="text-sm font-medium text-brand-700 hover:underline">{l.customer.name} · {l.customer.code}</Link>
              ) : (
                <div className="space-y-1 text-sm">
                  <p className="font-medium">{l.company_name ?? l.contact_name}</p>
                  {l.company_name && l.contact_name && <p className="text-ink-600">{l.contact_name}</p>}
                  {l.city && <p className="text-ink-500">{l.city}</p>}
                  {l.contact_phone && <a href={`tel:${l.contact_phone.replace(/\s/g, "")}`} className="flex items-center gap-1.5 text-brand-700"><Phone className="size-3.5" />{l.contact_phone}</a>}
                  {l.contact_email && <a href={`mailto:${l.contact_email}`} className="flex items-center gap-1.5 text-brand-700"><Mail className="size-3.5" />{l.contact_email}</a>}
                  <p className="pt-2 text-xs text-ink-500">Becomes a customer when you create the first enquiry.</p>
                </div>
              )}
            </Card>
            <p className="text-xs text-ink-400">Created {dateTime(l.created_at)}{l.created_by ? ` by ${l.created_by}` : ""} · updated {dateTime(l.updated_at)}</p>
          </div>
        </div>
      )}
      {tab === "activity" && <ActivityPanel leadId={id} canEdit={l.can_edit} />}
      {tab === "enquiries" && (
        <Card padded={false}>
          <DataTable rows={enquiries.data?.data ?? []} onRowClick={(r: any) => router.push(`/crm/enquiries/view?id=${r.id}`)}
            empty={<EmptyState title="No enquiries yet" body={l.can_edit && !closed ? "Use “Create enquiry” when the customer confirms a requirement." : undefined} />}
            columns={[
              { key: "n", header: "Enquiry", cell: (r: any) => <div><p className="font-medium">{r.subject}</p><p className="text-xs text-ink-500">{r.enquiry_number}</p></div> },
              { key: "d", header: "Date", cell: (r: any) => date(r.enquiry_date) },
              { key: "s", header: "Status", cell: (r: any) => <CrmStatus kind="enquiry" status={r.status} /> },
            ]} />
        </Card>
      )}
      {tab === "documents" && <DocumentsPanel entityType="lead" entityId={id} canEdit={l.can_edit} />}
      {tab === "history" && <HistoryPanel entityType="lead" entityId={id} />}
      <StatusDialog open={statusOpen} onClose={() => setStatusOpen(false)} statuses={LEAD_STATUSES} current={l.status} title="Change lead status"
        onSubmit={async (status, lost_reason) => { await api(`/leads/${id}/status`, { body: { status, lost_reason, row_version: l.row_version } }); toast("Status updated"); refresh(); }} />
      {converting && <ConvertDialog lead={l} open onClose={() => setConverting(false)} onDone={(enqId) => {
        setConverting(false);
        refresh();
        qc.invalidateQueries({ queryKey: ["/enquiries"] });
        qc.invalidateQueries({ queryKey: ["/customers"] });
        toast("Enquiry created");
        router.push(`/crm/enquiries/view?id=${enqId}`);
      }} />}
    </>
  );
}

export default function Page() {
  return <Suspense><LeadDetail /></Suspense>;
}
