"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Download, Magnet, Plus } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { CrmStatus, LEAD_STATUSES, MiniStat, usePeople } from "@/components/crm/common";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function LeadsPage() {
  const router = useRouter();
  const { can, me } = useAuth();
  const list = useList<any>("/leads", { filters: { open_only: "true" } });
  const allScope = me?.permissions["lead.read"] !== "own";
  const sales = usePeople("sales", allScope);
  const summary = useQuery({ queryKey: ["/crm/summary"], queryFn: () => api<{ data: any }>("/crm/summary"), select: (r) => r.data });
  const counts = Object.fromEntries((summary.data?.leads_by_status ?? []).map((s: any) => [s.status, s.count]));
  const openCount = (summary.data?.leads_by_status ?? []).filter((s: any) => !["won", "lost"].includes(s.status)).reduce((n: number, s: any) => n + s.count, 0);
  const statusValue = list.filters.status || (list.filters.open_only === "true" ? "_open" : "");
  const setStatus = (v: string) => {
    list.setFilter("open_only", v === "_open" ? "true" : "");
    list.setFilter("status", v.startsWith("_") ? "" : v);
  };

  return (
    <>
      <PageHeader title="Leads" subtitle={allScope ? "Every sales opportunity, from first contact to won or lost." : "Leads assigned to you."}
        actions={<>
          {can("lead.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/leads/export", "leads.xlsx", { q: list.q, ...list.filters })}>Export</Button>}
          {can("lead.create") && <Link href="/crm/leads/new"><Button icon={<Plus className="size-4" />}>New lead</Button></Link>}
        </>} />
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <MiniStat label="Open leads" value={openCount} onClick={() => setStatus("_open")} active={statusValue === "_open"} />
        <MiniStat label="New" value={counts.new} onClick={() => setStatus("new")} active={statusValue === "new"} />
        <MiniStat label="Site visit stage" value={counts.site_visit} tone="amber" onClick={() => setStatus("site_visit")} active={statusValue === "site_visit"} />
        <MiniStat label="Won" value={counts.won} onClick={() => setStatus("won")} active={statusValue === "won"} />
      </div>
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search title, number, company, contact, phone…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={statusValue} onChange={(e) => setStatus(e.target.value)} className="sm:w-44" aria-label="Status">
            <option value="_open">Open leads</option>
            <option value="">All statuses</option>
            {LEAD_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
          {allScope && (
            <Select value={list.filters.sales_person_id ?? ""} onChange={(e) => list.setFilter("sales_person_id", e.target.value)} className="sm:w-52" aria-label="Salesperson">
              <option value="">All salespeople</option>
              {sales.data?.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          )}
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/crm/leads/view?id=${r.id}`)}
            empty={<EmptyState icon={<Magnet className="size-8" />} title={list.q ? "No leads match your search" : "No leads here"} body={can("lead.create") ? "Record every enquiry call, email or walk-in as a lead so nothing slips." : undefined} />}
            columns={[
              { key: "t", header: "Lead", sortKey: "created_at", cell: (r) => <div><p className="font-medium text-ink-900">{r.title}</p><p className="text-xs text-ink-500">{r.lead_number}</p></div> },
              { key: "c", header: "Customer", cell: (r) => r.customer ? (
                <span>
                  <Link href={`/customers/view?id=${r.customer.id}`} onClick={(e) => e.stopPropagation()} className="text-ink-900 hover:text-brand-700 hover:underline">{r.customer.name}</Link>
                  <span className="block text-xs text-ink-500">{r.customer.code}{r.customer.is_prospect ? " · Prospect" : ""}{r.customer.city ? ` · ${r.customer.city}` : ""}</span>
                </span>
              ) : <span className="text-ink-700">{r.company_name ?? r.contact_name}<span className="block text-xs text-ink-500">Not saved as a customer{r.city ? ` · ${r.city}` : ""}</span></span> },
              { key: "v", header: "Value", sortKey: "estimated_value", className: "text-right", hideOnMobile: true, cell: (r) => <span className="num">{r.estimated_value ? inr(r.estimated_value, 0) : "—"}</span> },
              { key: "e", header: "Expected close", sortKey: "expected_closing_date", hideOnMobile: true, cell: (r) => date(r.expected_closing_date) },
              { key: "sp", header: "Salesperson", hideOnMobile: true, cell: (r) => r.sales_person ?? <span className="text-ink-400">Unassigned</span> },
              { key: "s", header: "Status", sortKey: "status", cell: (r) => <CrmStatus kind="lead" status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
