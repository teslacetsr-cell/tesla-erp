"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader, useToast } from "@/components/ui";
import { LeadForm } from "@/components/crm/lead-form";
import { api } from "@/lib/api/client";

export default function NewLeadPage() {
  const router = useRouter();
  const toast = useToast();
  const qc = useQueryClient();
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader back={<Link href="/crm/leads" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Leads</Link>} title="New lead" />
      <LeadForm submitLabel="Create lead" onCancel={() => router.push("/crm/leads")} onSubmit={async (values) => {
        const r = await api("/leads", { body: values });
        qc.invalidateQueries({ queryKey: ["/leads"] });
        qc.invalidateQueries({ queryKey: ["/crm/summary"] });
        toast(`Lead ${r.data.lead_number} created`);
        router.push(`/crm/leads/view?id=${r.data.id}`);
      }} />
    </div>
  );
}
