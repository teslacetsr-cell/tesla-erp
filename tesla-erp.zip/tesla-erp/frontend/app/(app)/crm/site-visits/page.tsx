"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { MapPinned, Plus } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { CrmStatus, usePeople, VISIT_STATUSES } from "@/components/crm/common";
import { useAuth } from "@/lib/auth";
import { date } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function SiteVisitsPage() {
  const router = useRouter();
  const { can, me } = useAuth();
  const list = useList<any>("/site-visits");
  const allScope = me?.permissions["site_visit.read"] !== "own";
  const engineers = usePeople("engineer", allScope);
  return (
    <>
      <PageHeader title="Site visits" subtitle={allScope ? "Surveys and inspections at customer sites, with photos, measurements and the visit report." : "Visits assigned to you, and visits for your enquiries."}
        actions={can("site_visit.create") && <Link href="/crm/site-visits/new"><Button icon={<Plus className="size-4" />}>New site visit</Button></Link>} />
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search number, customer, location…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={list.filters.status ?? ""} onChange={(e) => list.setFilter("status", e.target.value)} className="sm:w-40" aria-label="Status">
            <option value="">Any status</option>
            {VISIT_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
          <Select value={list.filters.engineer_id ?? ""} onChange={(e) => list.setFilter("engineer_id", e.target.value)} className="sm:w-52" aria-label="Engineer">
            <option value="">{allScope ? "All engineers" : "Everyone"}</option>
            <option value={me?.id ?? ""}>My visits</option>
            {allScope && engineers.data?.filter((p) => p.id !== me?.id).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/crm/site-visits/view?id=${r.id}`)}
            empty={<EmptyState icon={<MapPinned className="size-8" />} title={list.q ? "No visits match your search" : "No site visits yet"} body="Schedule visits from an enquiry, or create one here for any customer." />}
            columns={[
              { key: "d", header: "Date", sortKey: "visit_date", cell: (r) => <div><p className="font-medium text-ink-900">{date(r.visit_date)}{r.visit_time ? `, ${r.visit_time}` : ""}</p><p className="text-xs text-ink-500">{r.visit_number}</p></div> },
              { key: "c", header: "Customer & location", cell: (r) => <div className="max-w-xs"><p>{r.customer?.name}</p><p className="truncate text-xs text-ink-500">{r.site_location}</p></div> },
              { key: "q", header: "Enquiry", hideOnMobile: true, cell: (r) => r.enquiry_number ?? "—" },
              { key: "e", header: "Engineer", hideOnMobile: true, cell: (r) => r.engineer ?? <span className="text-ink-400">Unassigned</span> },
              { key: "s", header: "Status", sortKey: "status", cell: (r) => <CrmStatus kind="visit" status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
