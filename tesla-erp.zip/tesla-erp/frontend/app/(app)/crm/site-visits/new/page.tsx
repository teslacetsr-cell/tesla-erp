"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import { ErrorNote, PageHeader, Spinner, useToast } from "@/components/ui";
import { useCustomerDetail } from "@/components/crm/common";
import { VisitForm } from "@/components/crm/visit-form";
import { api } from "@/lib/api/client";

function NewVisit() {
  const router = useRouter();
  const toast = useToast();
  const qc = useQueryClient();
  const sp = useSearchParams();
  const enquiryId = sp.get("enquiry_id");
  const customerId = sp.get("customer_id");
  const enq = useQuery({ queryKey: ["/enquiries", enquiryId], queryFn: () => api<any>(`/enquiries/${enquiryId}`), select: (r) => r.data, enabled: !!enquiryId });
  const cust = useCustomerDetail(customerId);
  if ((enquiryId && enq.isLoading) || (customerId && cust.isLoading)) return <Spinner />;
  if (enq.error) return <ErrorNote error={enq.error} />;
  const e = enq.data;
  const c = cust.data;
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader back={<Link href={e ? `/crm/enquiries/view?id=${e.id}` : "/crm/site-visits"} className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> {e ? e.enquiry_number : "Site visits"}</Link>}
        title="New site visit" subtitle="Schedule it now and fill in the findings at the site — or record a visit already made." />
      <VisitForm draftKey={`new:${enquiryId ?? customerId ?? "-"}`} submitLabel="Save visit" onCancel={() => router.back()}
        enquiry={e ? { id: e.id, enquiry_number: e.enquiry_number, site_id: e.site_id, customer: { id: e.customer.id, name: e.customer.name, code: e.customer.code, city: e.customer.city } } : null}
        initial={!e && c ? { customer: { id: c.id, name: c.customer_name, code: c.customer_code, city: c.city } } : undefined}
        onSubmit={async (values) => {
          const r = await api("/site-visits", { body: values });
          qc.invalidateQueries({ queryKey: ["/site-visits"] });
          qc.invalidateQueries({ queryKey: ["/enquiries"] });
          toast(`Site visit ${r.data.visit_number} saved`);
          router.push(`/crm/site-visits/view?id=${r.data.id}`);
        }} />
    </div>
  );
}

export default function Page() {
  return <Suspense><NewVisit /></Suspense>;
}
