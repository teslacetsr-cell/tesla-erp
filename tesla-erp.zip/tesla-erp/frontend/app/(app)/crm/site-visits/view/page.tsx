"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, CheckCircle2, ClipboardEdit, FileDown, FileText, MapPin, Trash2, XCircle } from "lucide-react";
import { Button, Card, Detail, ErrorNote, PageHeader, Spinner, Tabs, useConfirm, useToast } from "@/components/ui";
import { CrmStatus } from "@/components/crm/common";
import { PhotoPanel } from "@/components/crm/photos";
import { clearVisitDraft, VisitForm } from "@/components/crm/visit-form";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, dateTime } from "@/lib/format";

type Tab = "report" | "photos" | "documents" | "history";

function Block({ title, text }: { title: string; text: string | null }) {
  return (
    <Card title={title}>
      <p className="whitespace-pre-line text-sm text-ink-800">{text || <span className="text-ink-400">Not recorded yet.</span>}</p>
    </Card>
  );
}

function VisitDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const { can } = useAuth();
  const [tab, setTab] = useState<Tab>("report");
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const key = ["/site-visits", id];
  const { data, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api(`/site-visits/${id}`), select: (r: any) => r.data });
  const reports = useQuery({
    queryKey: ["/documents", "site_visit", id],
    queryFn: () => api<{ data: any[] }>("/documents", { params: { entity_type: "site_visit", entity_id: id } }),
    enabled: !!id,
  });
  const report = reports.data?.data.find((d) => d.category === "report");
  const refresh = () => { qc.invalidateQueries({ queryKey: key }); qc.invalidateQueries({ queryKey: ["/site-visits"] }); qc.invalidateQueries({ queryKey: ["/enquiries"] }); qc.invalidateQueries({ queryKey: ["/crm/summary"] }); };

  if (isLoading) return <Spinner />;
  if (error || !data) return <ErrorNote error={error} />;
  const v = data;
  const hasFindings = !!(v.observations || v.requirements || v.recommendations || v.measurements?.length);

  if (editing)
    return (
      <div className="mx-auto max-w-4xl">
        <PageHeader title={`Visit report ${v.visit_number}`} subtitle={`${v.customer?.name} · ${v.site_location}`} />
        <VisitForm initial={v} draftKey={v.id} submitLabel="Save report" onCancel={() => setEditing(false)}
          enquiry={v.enquiry_id ? { id: v.enquiry_id, enquiry_number: v.enquiry_number, customer: { id: v.customer.id, name: v.customer.name, code: v.customer.code, city: v.customer.city } } : null}
          onSubmit={async (values) => {
            await api(`/site-visits/${id}`, { method: "PUT", body: { ...values, row_version: v.row_version } });
            toast("Visit report saved");
            setEditing(false);
            refresh();
          }} />
      </div>
    );

  async function act(label: string, fn: () => Promise<void>) {
    setBusy(label);
    try { await fn(); } catch (e: any) { toast(e.message, "error"); } finally { setBusy(null); }
  }
  const maps = v.latitude ? `https://maps.google.com/?q=${v.latitude},${v.longitude}` : null;

  return (
    <>
      <PageHeader
        back={<Link href="/crm/site-visits" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Site visits</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{v.customer?.name} <CrmStatus kind="visit" status={v.status} /></span>}
        subtitle={`${v.visit_number} · ${date(v.visit_date)}${v.visit_time ? `, ${v.visit_time}` : ""}${v.engineer ? ` · ${v.engineer}` : ""}`}
        actions={<>
          {v.can_edit && <Button icon={<ClipboardEdit className="size-4" />} variant={v.status === "scheduled" && !hasFindings ? "primary" : "secondary"} onClick={() => setEditing(true)}>
            {v.status === "scheduled" && !hasFindings ? "Fill in report" : "Edit report"}
          </Button>}
          {v.can_edit && v.status === "scheduled" && (
            <Button icon={<CheckCircle2 className="size-4" />} loading={busy === "complete"} disabled={!hasFindings} title={hasFindings ? undefined : "Record the findings first"}
              onClick={() => act("complete", async () => {
                if (!(await confirm({ title: "Complete this visit?", body: v.follow_up_date ? `A follow-up for ${date(v.follow_up_date)} will be created for the salesperson.` : "The enquiry moves to technical evaluation.", confirmLabel: "Complete visit" }))) return;
                await api(`/site-visits/${id}/complete`, { body: { row_version: v.row_version } });
                clearVisitDraft(v.id);
                toast("Visit completed");
                refresh();
              })}>Complete visit</Button>
          )}
          {v.can_print && (
            <Button variant="secondary" icon={<FileText className="size-4" />} loading={busy === "report"} onClick={() => act("report", async () => {
              const r = await api(`/site-visits/${id}/report`, { method: "POST" });
              qc.invalidateQueries({ queryKey: ["/documents", "site_visit", id] });
              toast(`Report generated (version ${r.data.version})`);
              await download(`/documents/${r.data.id}/content`, r.data.file_name);
            })}>{report ? "Regenerate PDF" : "Generate PDF report"}</Button>
          )}
          {report && <Button variant="ghost" icon={<FileDown className="size-4" />} onClick={() => download(`/documents/${report.id}/content`, report.file_name)}>Download report</Button>}
          {v.can_edit && v.status === "scheduled" && (
            <Button variant="ghost" icon={<XCircle className="size-4" />} onClick={() => act("cancel", async () => {
              if (!(await confirm({ title: "Cancel this visit?", body: "The visit stays on record as cancelled.", confirmLabel: "Cancel visit" }))) return;
              await api(`/site-visits/${id}/cancel`, { method: "POST" });
              refresh();
            })}>Cancel visit</Button>
          )}
          {v.can_delete && can("site_visit.delete") && (
            <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={() => act("delete", async () => {
              if (!(await confirm({ title: "Delete visit?", body: "Completed visits cannot be deleted.", confirmLabel: "Delete" }))) return;
              await api(`/site-visits/${id}`, { method: "DELETE" });
              qc.invalidateQueries({ queryKey: ["/site-visits"] });
              router.push("/crm/site-visits");
            })}>Delete</Button>
          )}
        </>} />
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[{ id: "report", label: "Report" }, { id: "photos", label: "Photos" }, { id: "documents", label: "Documents" }, { id: "history", label: "History" }]} />
      {tab === "report" && (
        <div className="grid gap-4 xl:grid-cols-[1fr_340px]">
          <div className="space-y-4">
            <Card title="Visit">
              <Detail items={[
                ["Location", v.site_location], ["Site", v.site], ["Purpose", v.purpose],
                ["Enquiry", v.enquiry_id ? <Link key="e" href={`/crm/enquiries/view?id=${v.enquiry_id}`} className="text-brand-700 hover:underline">{v.enquiry_number}</Link> : null],
                ["Engineer", v.engineer], ["Follow-up date", date(v.follow_up_date)],
              ]} />
            </Card>
            <Block title="Observations" text={v.observations} />
            <Block title="Customer requirements" text={v.requirements} />
            {v.measurements?.length > 0 && (
              <Card title="Measurements" padded={false}>
                <table className="w-full text-sm">
                  <tbody>
                    {v.measurements.map((m: any, i: number) => (
                      <tr key={i} className="border-b border-ink-100 last:border-0">
                        <td className="px-4 py-2 text-ink-700">{m.label}</td>
                        <td className="num px-4 py-2 text-right font-medium">{m.value} {m.unit}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>
            )}
            <Block title="Recommendations" text={v.recommendations} />
          </div>
          <div className="space-y-4">
            <Card title="Customer">
              <Link href={`/customers/view?id=${v.customer_id}`} className="text-sm font-medium text-brand-700 hover:underline">{v.customer?.name} · {v.customer?.code}</Link>
              {(v.customer_rep_name || v.customer_rep_phone) && (
                <div className="mt-3 text-sm">
                  <p className="text-xs uppercase tracking-wide text-ink-500">Met on site</p>
                  <p className="font-medium">{v.customer_rep_name}</p>
                  {v.customer_rep_designation && <p className="text-ink-500">{v.customer_rep_designation}</p>}
                  {v.customer_rep_phone && <a className="text-brand-700" href={`tel:${v.customer_rep_phone.replace(/\s/g, "")}`}>{v.customer_rep_phone}</a>}
                </div>
              )}
            </Card>
            {maps && (
              <Card title="GPS location">
                <a href={maps} target="_blank" rel="noreferrer" className="flex items-start gap-2 text-sm text-brand-700 hover:underline">
                  <MapPin className="mt-0.5 size-4 shrink-0" />
                  <span><span className="num">{v.latitude}, {v.longitude}</span>{v.location_accuracy_m ? ` (±${v.location_accuracy_m} m)` : ""}<br /><span className="text-xs text-ink-500">Recorded {dateTime(v.location_captured_at)}</span></span>
                </a>
              </Card>
            )}
            {report && (
              <Card title="Visit report PDF">
                <button onClick={() => download(`/documents/${report.id}/content`, report.file_name)} className="text-left text-sm text-brand-700 hover:underline">{report.file_name}</button>
                <p className="text-xs text-ink-500">Version {report.version} · {dateTime(report.uploaded_at)}</p>
              </Card>
            )}
            <p className="text-xs text-ink-400">Created {dateTime(v.created_at)}{v.created_by ? ` by ${v.created_by}` : ""}{v.completed_at ? ` · completed ${dateTime(v.completed_at)}` : ""}</p>
          </div>
        </div>
      )}
      {tab === "photos" && <PhotoPanel visitId={id} canEdit={v.can_edit} />}
      {tab === "documents" && <DocumentsPanel entityType="site_visit" entityId={id} canEdit={v.can_edit} defaultCategory="drawing" />}
      {tab === "history" && <HistoryPanel entityType="site_visit" entityId={id} />}
    </>
  );
}

export default function Page() {
  return <Suspense><VisitDetail /></Suspense>;
}
