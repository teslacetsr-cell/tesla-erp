"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowRightLeft, Plus } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { TRANSFER_STATUSES, TransferStatus } from "@/components/purchase/common";
import { useAuth } from "@/lib/auth";
import { date } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function TransfersPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/stock-transfers");
  return (
    <>
      <PageHeader title="Stock transfers" subtitle="Move stock between the main store and site stores. The value moves at weighted average cost."
        actions={can("stock_transfer.create") && <Link href="/inventory/transfers/new"><Button icon={<Plus className="size-4" />}>New transfer</Button></Link>} />
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search number or notes…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={list.filters.status ?? ""} onChange={(e) => list.setFilter("status", e.target.value)} className="sm:w-48" aria-label="Status">
            <option value="">All statuses</option>{TRANSFER_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/inventory/transfers/view?id=${r.id}`)}
            empty={<EmptyState icon={<ArrowRightLeft className="size-8" />} title="No transfers" body="Send stock from the main store to a project's site store." />}
            columns={[
              { key: "n", header: "Transfer", sortKey: "created_at", cell: (r) => <div><p className="font-medium text-ink-900">{r.transfer_number ?? "Draft"}</p><p className="text-xs text-ink-500">{r.lines_count} item(s) · {r.created_by}</p></div> },
              { key: "f", header: "From → to", cell: (r) => `${r.from_warehouse?.name} → ${r.to_warehouse?.name}` },
              { key: "d", header: "Date", sortKey: "transfer_date", hideOnMobile: true, cell: (r) => date(r.transfer_date) },
              { key: "s", header: "Status", cell: (r) => <TransferStatus status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
