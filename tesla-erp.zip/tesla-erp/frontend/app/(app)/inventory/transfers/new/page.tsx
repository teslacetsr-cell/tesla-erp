"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Button, Card, ErrorNote, Field, Input, PageHeader, Textarea, useToast } from "@/components/ui";
import { istToday } from "@/components/projects/common";
import { newRow, QtyLines, qtyProblems, splitSerials, WarehouseSelect, type QtyRow } from "@/components/purchase/common";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";

function NewTransfer() {
  const to = useSearchParams().get("to");
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const { can } = useAuth();
  const [h, setH] = useState({ transfer_date: istToday(), from_warehouse_id: "", to_warehouse_id: to ?? "", vehicle_no: "", notes: "" });
  const [rows, setRows] = useState<QtyRow[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<unknown>(null);
  async function save(post: boolean) {
    setError(null);
    if (!h.from_warehouse_id || !h.to_warehouse_id) return setError(new Error("Choose both warehouses."));
    const p = qtyProblems(rows, { requireItem: true });
    if (p) return setError(new Error(p));
    setBusy(post ? "post" : "draft");
    try {
      const r = await api<any>("/stock-transfers", { body: { ...h, vehicle_no: h.vehicle_no.trim() || null, notes: h.notes.trim() || null, post,
        lines: rows.map((x) => ({ item_id: x.item_id, quantity: x.quantity.trim(), batch_no: x.batch_no?.trim() || null, serial_nos: splitSerials(x.serials) })) } });
      toast(post ? `${r.data.transfer_number} posted — stock moved` : "Draft saved");
      qc.invalidateQueries({ queryKey: ["/stock-transfers"] });
      qc.invalidateQueries({ queryKey: ["/stock/items"] });
      router.push(`/inventory/transfers/view?id=${r.data.id}`);
    } catch (err) { setError(err); window.scrollTo({ top: 0, behavior: "smooth" }); } finally { setBusy(null); }
  }
  return (
    <div className="mx-auto max-w-4xl space-y-5">
      <PageHeader title="New stock transfer" subtitle="Stock leaves the source and arrives at the destination in one step, at its average cost." />
      <ErrorNote error={error} />
      <Card title="From and to">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="From" required><WarehouseSelect value={h.from_warehouse_id} onChange={(v) => setH({ ...h, from_warehouse_id: v })} blank="— Choose —" exclude={h.to_warehouse_id} /></Field>
          <Field label="To" required><WarehouseSelect value={h.to_warehouse_id} onChange={(v) => setH({ ...h, to_warehouse_id: v })} blank="— Choose —" exclude={h.from_warehouse_id} /></Field>
          <Field label="Date"><Input type="date" max={istToday()} value={h.transfer_date} onChange={(e) => setH({ ...h, transfer_date: e.target.value })} /></Field>
          <Field label="Vehicle no."><Input value={h.vehicle_no} onChange={(e) => setH({ ...h, vehicle_no: e.target.value })} /></Field>
          <Field label="Notes" className="sm:col-span-2"><Textarea rows={2} value={h.notes} onChange={(e) => setH({ ...h, notes: e.target.value })} /></Field>
        </div>
      </Card>
      <Card title="Items"><QtyLines rows={rows} onChange={setRows} tracking requireItem /></Card>
      <div className="flex justify-end gap-2">
        <Button type="button" variant="secondary" onClick={() => router.back()}>Cancel</Button>
        <Button type="button" variant="secondary" loading={busy === "draft"} onClick={() => save(false)}>Save draft</Button>
        {can("stock_transfer.update") && <Button type="button" loading={busy === "post"} onClick={() => save(true)}>Post transfer</Button>}
      </div>
    </div>
  );
}

export default function Page() {
  return <Suspense><NewTransfer /></Suspense>;
}
