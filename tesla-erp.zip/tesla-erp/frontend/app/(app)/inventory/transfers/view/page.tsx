"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Send, XCircle } from "lucide-react";
import { Button, Card, Detail, ErrorNote, PageHeader, Spinner, useConfirm, useToast } from "@/components/ui";
import { TransferStatus } from "@/components/purchase/common";
import { HistoryPanel } from "@/components/record-panels";
import { api } from "@/lib/api/client";
import { date, dateTime, inr, qty } from "@/lib/format";

function TransferDetail() {
  const id = useSearchParams().get("id") ?? "";
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const { data: t, isLoading, error } = useQuery({ queryKey: ["/stock-transfers", id], queryFn: () => api<any>(`/stock-transfers/${id}`), select: (r) => r.data });
  if (isLoading) return <Spinner />;
  if (error || !t) return <ErrorNote error={error} />;
  async function act(path: string, msg: string) {
    try { await api(`/stock-transfers/${id}/${path}`, { body: {} }); toast(msg); qc.invalidateQueries({ queryKey: ["/stock-transfers"] }); qc.invalidateQueries({ queryKey: ["/stock/items"] }); }
    catch (e: any) { toast(e.message, "error"); }
  }
  return (
    <>
      <PageHeader back={<Link href="/inventory/transfers" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Transfers</Link>}
        title={<span className="flex items-center gap-2">{t.transfer_number ?? "Draft transfer"} <TransferStatus status={t.status} /></span>}
        subtitle={`${t.from_warehouse?.name} → ${t.to_warehouse?.name}`}
        actions={<>
          {t.can.post && <Button icon={<Send className="size-4" />} onClick={async () => { if (await confirm({ title: "Post this transfer?", body: "The stock moves now and cannot be changed afterwards.", confirmLabel: "Post" })) act("post", "Transfer posted — stock moved"); }}>Post</Button>}
          {t.can.cancel && <Button variant="ghost" icon={<XCircle className="size-4" />} onClick={() => act("cancel", "Draft cancelled")}>Cancel draft</Button>}
        </>} />
      <Card className="mb-4">
        <Detail cols={4} items={[["Date", date(t.transfer_date)], ["Posted", t.posted_at ? dateTime(t.posted_at) : "—"], ["Vehicle", t.vehicle_no],
          ["Project", t.project ? <Link key="p" href={`/projects/view?id=${t.project.id}`} className="text-brand-700 hover:underline">{t.project.number}</Link> : "—"]]} />
        {t.notes && <p className="mt-3 border-t border-ink-100 pt-3 text-sm">{t.notes}</p>}
      </Card>
      <Card title="Items" padded={false}>
        <table className="w-full text-sm">
          <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500"><th className="px-3 py-2">#</th><th className="px-3 py-2">Item</th><th className="px-3 py-2 text-right">Quantity</th><th className="px-3 py-2 text-right">Cost moved</th></tr></thead>
          <tbody>{t.lines.map((l: any) => (
            <tr key={l.id} className="border-b border-ink-100 align-top"><td className="px-3 py-2 text-ink-500">{l.line_no}</td>
              <td className="px-3 py-2"><p>{l.item?.name}</p><p className="text-xs text-ink-500">{l.item?.code}{l.batch_no ? ` · batch ${l.batch_no}` : ""}{l.serial_nos.length ? ` · ${l.serial_nos.join(", ")}` : ""}</p></td>
              <td className="num px-3 py-2 text-right font-medium">{qty(l.quantity)} {l.item?.unit}</td>
              <td className="num px-3 py-2 text-right">{l.unit_cost ? `${inr(l.unit_cost)} / ${l.item?.unit}` : "—"}</td></tr>))}</tbody>
        </table>
      </Card>
      <div className="mt-4"><HistoryPanel entityType="stock_transfer" entityId={id} /></div>
    </>
  );
}

export default function Page() {
  return <Suspense><TransferDetail /></Suspense>;
}
