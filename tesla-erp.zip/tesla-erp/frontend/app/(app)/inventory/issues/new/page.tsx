"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader, useToast } from "@/components/ui";
import { IssueForm } from "@/components/costing/common";
import { api } from "@/lib/api/client";

function NewIssue() {
  const sp = useSearchParams();
  const kind = sp.get("kind") === "return" ? "return" : "issue";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  return (
    <div className="mx-auto max-w-5xl space-y-5">
      <PageHeader title={kind === "issue" ? "Issue material to a project" : "Return material from site"}
        subtitle={kind === "issue" ? "Stock leaves the store and its cost is charged to the project. Quantities beyond the BOQ need approval."
          : "Unused material comes back to the store; the project is credited at the cost it was issued at."} />
      <IssueForm kind={kind} projectId={sp.get("project")} onCancel={() => router.back()} onSubmit={async (body, submit) => {
        const r = await api<any>(kind === "issue" ? "/material-issues" : "/material-returns", { body: { ...body, submit } });
        const d = r.data;
        toast(d.status === "posted" ? `${d.issue_number} posted — stock moved` : d.status === "pending_approval" ? `${d.issue_number} sent for approval` : "Draft saved");
        qc.invalidateQueries({ queryKey: ["/material-issues"] });
        qc.invalidateQueries({ queryKey: ["/stock/items"] });
        router.push(`/inventory/issues/view?id=${d.id}`);
      }} />
    </div>
  );
}

export default function Page() {
  return <Suspense><NewIssue /></Suspense>;
}
