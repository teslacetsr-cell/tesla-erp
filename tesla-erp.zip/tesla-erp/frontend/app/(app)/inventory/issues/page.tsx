"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Download, PackageMinus, Plus, Undo2 } from "lucide-react";
import { Badge, Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { ISSUE_STATUSES, IssueStatus } from "@/components/costing/common";
import { useProjectOptions } from "@/components/purchase/common";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function IssuesPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/material-issues");
  const projects = useProjectOptions();
  const sum = useQuery({ queryKey: ["/material-issues/summary"], queryFn: () => api<any>("/material-issues/summary"), select: (r) => r.data });
  return (
    <>
      <PageHeader title="Material issues" subtitle="Stock issued from a store to a project, and returns from site. Each issue is charged to the project at weighted average cost."
        actions={<>
          {can("material_issue.export") && <Button variant="ghost" icon={<Download className="size-4" />} onClick={() => download("/material-issues/export", "material-issues.xlsx", list.filters)}>Export</Button>}
          {can("material_issue.create") && <Link href="/inventory/issues/new?kind=return"><Button variant="secondary" icon={<Undo2 className="size-4" />}>Return from site</Button></Link>}
          {can("material_issue.create") && <Link href="/inventory/issues/new"><Button icon={<Plus className="size-4" />}>Issue material</Button></Link>}
        </>} />
      {sum.data && (
        <div className="mb-4 grid gap-3 sm:grid-cols-3">
          <Card><p className="text-xs text-ink-500">Issued this month (net of returns)</p><p className="num mt-1 text-xl font-semibold">{inr(sum.data.issued_month, 0)}</p></Card>
          <Card><p className="text-xs text-ink-500">Waiting for approval</p><p className="num mt-1 text-xl font-semibold">{sum.data.pending_approval}</p></Card>
          <Card><p className="text-xs text-ink-500">Drafts</p><p className="num mt-1 text-xl font-semibold">{sum.data.drafts}</p></Card>
        </div>
      )}
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search number, issued to or notes…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={list.filters.project_id ?? ""} onChange={(e) => list.setFilter("project_id", e.target.value)} className="sm:w-56" aria-label="Project">
            <option value="">All projects</option>{(projects.data ?? []).map((p: any) => <option key={p.id} value={p.id}>{p.project_number}</option>)}
          </Select>
          <Select value={list.filters.kind ?? ""} onChange={(e) => list.setFilter("kind", e.target.value)} className="sm:w-36" aria-label="Type">
            <option value="">Issues & returns</option><option value="issue">Issues</option><option value="return">Returns</option>
          </Select>
          <Select value={list.filters.status ?? ""} onChange={(e) => list.setFilter("status", e.target.value)} className="sm:w-48" aria-label="Status">
            <option value="">All statuses</option>{ISSUE_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/inventory/issues/view?id=${r.id}`)}
            empty={<EmptyState icon={<PackageMinus className="size-8" />} title="No material issues" body="Issue BOQ material from the store to a project; its cost goes to the project." />}
            columns={[
              { key: "n", header: "Number", sortKey: "created_at", cell: (r) => <div><p className="font-medium text-ink-900">{r.issue_number ?? "Draft"} {r.kind === "return" && <Badge tone="blue">Return</Badge>}</p><p className="text-xs text-ink-500">{r.lines_count} item(s){r.issued_to ? ` · ${r.issued_to}` : ""}</p></div> },
              { key: "p", header: "Project", cell: (r) => <div><p>{r.project.number}</p><p className="text-xs text-ink-500">{r.project.name}</p></div> },
              { key: "w", header: "Store", hideOnMobile: true, cell: (r) => r.warehouse.name },
              { key: "d", header: "Date", sortKey: "issue_date", hideOnMobile: true, cell: (r) => date(r.issue_date) },
              { key: "v", header: "Value", cell: (r) => <span className="num">{r.status === "posted" ? `${r.kind === "return" ? "−" : ""}${inr(r.value, 0)}` : `~${inr(r.estimated_value, 0)}`}</span> },
              { key: "s", header: "Status", cell: (r) => <span className="flex flex-wrap gap-1"><IssueStatus status={r.status} />{r.has_excess && r.status !== "posted" && <Badge tone="amber">Over BOQ</Badge>}</span> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
