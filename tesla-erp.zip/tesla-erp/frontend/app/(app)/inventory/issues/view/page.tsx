"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Pencil, Printer, Send, Trash2, Undo2, XCircle } from "lucide-react";
import { Badge, Button, Card, Detail, ErrorNote, PageHeader, Spinner, Tabs, useConfirm, useToast } from "@/components/ui";
import { IssueForm, IssueStatus } from "@/components/costing/common";
import { ApprovalCard, ApprovalHistory, ReasonDialog } from "@/components/purchase/common";
import { HistoryPanel } from "@/components/record-panels";
import { api, objectUrl } from "@/lib/api/client";
import { date, dateTime, inr, qty } from "@/lib/format";
import { useRouter } from "next/navigation";

function IssueDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [tab, setTab] = useState<"items" | "approvals" | "history">("items");
  const [editing, setEditing] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const { data: m, isLoading, error } = useQuery({ queryKey: ["/material-issues", id], queryFn: () => api<any>(`/material-issues/${id}`), select: (r) => r.data });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/material-issues"] }); qc.invalidateQueries({ queryKey: ["/stock/items"] }); qc.invalidateQueries({ queryKey: ["/approvals/inbox"] }); };
  if (isLoading) return <Spinner />;
  if (error || !m) return <ErrorNote error={error} />;
  const can = m.can;
  async function act(action: string, body: any = {}) {
    try {
      const r = await api<any>(`/material-issues/${id}/${action}`, { body: { row_version: m.row_version, ...body } });
      toast(r.data.status === "posted" ? `Posted — stock issued to ${m.project.number}` : r.data.status === "pending_approval" ? "Sent for approval" : r.data.status === "cancelled" ? "Cancelled" : "Back to draft");
      refresh();
    } catch (e: any) { toast(e.message, "error"); }
  }
  async function print() {
    try { window.open(await objectUrl(`/material-issues/${id}/pdf`), "_blank"); } catch (e: any) { toast(e.message, "error"); }
  }
  if (editing)
    return (
      <div className="mx-auto max-w-5xl">
        <PageHeader title={`Edit ${m.issue_number ?? "draft issue"}`} />
        <IssueForm kind="issue" initial={m} onCancel={() => setEditing(false)} onSubmit={async (body, submit) => {
          await api(`/material-issues/${id}`, { method: "PUT", body: { ...body, submit, row_version: m.row_version } });
          toast(submit ? "Submitted" : "Saved"); setEditing(false); refresh();
        }} />
      </div>
    );
  const isReturn = m.kind === "return";
  return (
    <>
      <PageHeader back={<Link href="/inventory/issues" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Material issues</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{m.issue_number ?? "Draft issue"} {isReturn && <Badge tone="blue">Return</Badge>} <IssueStatus status={m.status} />{m.has_excess && m.status !== "posted" && <Badge tone="amber">Over BOQ</Badge>}</span>}
        subtitle={`${m.project.number} · ${m.project.name} · ${isReturn ? "to" : "from"} ${m.warehouse.name}`}
        actions={<>
          {can.submit && <Button icon={<Send className="size-4" />} onClick={() => act("submit")}>Issue material</Button>}
          {can.edit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {can.withdraw && <Button variant="secondary" icon={<Undo2 className="size-4" />} onClick={() => act("withdraw")}>Withdraw</Button>}
          {can.return && <Link href={`/inventory/issues/new?kind=return&project=${m.project.id}`}><Button variant="secondary" icon={<Undo2 className="size-4" />}>Return unused</Button></Link>}
          {can.print && <Button variant="ghost" icon={<Printer className="size-4" />} onClick={print}>{isReturn ? "Return note" : "Issue slip"}</Button>}
          {can.cancel && <Button variant="ghost" icon={<XCircle className="size-4" />} onClick={() => setCancelling(true)}>Cancel</Button>}
          {can.delete && <Button variant="ghost" icon={<Trash2 className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Delete this draft?", body: "It has no number yet, so nothing is lost.", confirmLabel: "Delete" }))) return;
            try { await api(`/material-issues/${id}`, { method: "DELETE" }); toast("Draft deleted"); refresh(); router.push("/inventory/issues"); } catch (e: any) { toast(e.message, "error"); }
          }}>Delete</Button>}
        </>} />
      <ApprovalCard approval={m.approval} onDone={refresh} />
      {m.last_rejection && m.status === "draft" && <p className="mb-4 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900"><b>Returned by the approver:</b> {m.last_rejection}</p>}
      {m.status === "cancelled" && m.status_reason && <p className="mb-4 rounded-md border border-ink-200 bg-ink-50 px-3 py-2 text-sm"><b>Cancelled:</b> {m.status_reason}</p>}
      <Card className="mb-4">
        <Detail cols={4} items={[
          ["Project", <Link key="p" className="text-brand-700 hover:underline" href={`/projects/view?id=${m.project.id}`}>{m.project.number}</Link>],
          ["Date", date(m.issue_date)], [isReturn ? "Returned by" : "Issued to", m.issued_to || "—"], ["Raised by", m.created_by],
          ["Value", m.status === "posted" ? inr(m.value) : `~${inr(m.estimated_value)} (estimate)`], ["Posted", m.posted_at ? dateTime(m.posted_at) : "—"],
        ]} />
        {m.notes && <p className="mt-3 border-t border-ink-100 pt-3 text-sm">{m.notes}</p>}
      </Card>
      <Tabs value={tab} onChange={setTab} tabs={[{ id: "items", label: "Items", count: m.lines.length }, { id: "approvals", label: "Approvals", count: m.approvals.length }, { id: "history", label: "History" }]} />
      {tab === "items" && (
        <Card padded={false}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
                <th className="px-3 py-2">#</th><th className="px-3 py-2">Item</th><th className="px-3 py-2 text-right">Qty</th>
                {m.status !== "posted" && <th className="px-3 py-2 text-right">In store</th>}
                <th className="px-3 py-2 text-right">Cost</th><th className="px-3 py-2 text-right">Value</th></tr></thead>
              <tbody>{m.lines.map((l: any) => (
                <tr key={l.id} className="border-b border-ink-100 align-top">
                  <td className="px-3 py-2 text-ink-500">{l.line_no}</td>
                  <td className="px-3 py-2"><p>{l.item_name}</p>
                    <p className="text-xs text-ink-500">{l.item_code}{l.boq_line ? ` · BOQ line ${l.boq_line.line_no} (${qty(l.boq_line.issued_qty)} of ${qty(l.boq_line.approved_qty)} issued)` : isReturn ? "" : " · not in BOQ"}{l.batch_no ? ` · batch ${l.batch_no}` : ""}{l.serial_nos.length ? ` · ${l.serial_nos.join(", ")}` : ""}</p>
                    {Number(l.excess_qty) > 0 && <p className="text-xs text-amber-700">{qty(l.excess_qty)} {l.unit} beyond the BOQ</p>}</td>
                  <td className="num px-3 py-2 text-right font-medium">{qty(l.quantity)} {l.unit}</td>
                  {m.status !== "posted" && <td className={`num px-3 py-2 text-right ${Number(l.available) < Number(l.quantity) ? "text-brand-700" : ""}`}>{l.available != null ? qty(l.available) : "—"}</td>}
                  <td className="num px-3 py-2 text-right">{l.unit_cost ? inr(l.unit_cost) : "average"}</td>
                  <td className="num px-3 py-2 text-right">{l.value ? inr(l.value) : "—"}</td>
                </tr>))}</tbody>
            </table>
          </div>
        </Card>
      )}
      {tab === "approvals" && <ApprovalHistory approvals={m.approvals} />}
      {tab === "history" && <HistoryPanel entityType="material_issue" entityId={id} />}
      <ReasonDialog open={cancelling} title="Cancel this issue?" label="Reason" required confirmLabel="Cancel issue" onClose={() => setCancelling(false)}
        onSubmit={async (reason) => { await api(`/material-issues/${id}/cancel`, { body: { reason } }); toast("Cancelled"); refresh(); }} />
    </>
  );
}

export default function Page() {
  return <Suspense><IssueDetail /></Suspense>;
}
