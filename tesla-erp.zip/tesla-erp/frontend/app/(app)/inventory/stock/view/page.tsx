"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import { Card, ErrorNote, PageHeader, Pagination, Spinner } from "@/components/ui";
import { StockBadge, TXN_TYPES, WarehouseSelect } from "@/components/purchase/common";
import { api } from "@/lib/api/client";
import { date, inr, qty } from "@/lib/format";
import { useList } from "@/lib/hooks";

const SOURCE_LINK: Record<string, string> = { grn: "/purchase/grn/view", transfer: "/inventory/transfers/view", adjustment: "/inventory/adjustments/view" };

function StockItem() {
  const id = useSearchParams().get("id") ?? "";
  const { data: s, isLoading, error } = useQuery({ queryKey: ["/stock/items", id], queryFn: () => api<any>(`/stock/items/${id}`), select: (r) => r.data });
  const led = useList<any>("/stock/ledger", { filters: { item_id: id } });
  if (isLoading) return <Spinner />;
  if (error || !s) return <ErrorNote error={error} />;
  return (
    <>
      <PageHeader back={<Link href="/inventory/stock" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Stock</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{s.item.name} <StockBadge status={s.status} /></span>}
        subtitle={`${s.item.code}${s.category ? ` · ${s.category}` : ""} · minimum ${qty(s.minimum_stock)} · reorder at ${qty(s.reorder_level)} ${s.item.unit}`} />
      <div className="mb-4 grid gap-4 lg:grid-cols-[1fr_320px]">
        <Card title="By warehouse" padded={false}>
          {s.warehouses.length === 0 ? <p className="p-4 text-sm text-ink-500">No stock anywhere.</p> : (
            <table className="w-full text-sm">
              <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500"><th className="px-3 py-2">Warehouse</th><th className="px-3 py-2 text-right">Quantity</th><th className="px-3 py-2 text-right">Avg cost</th><th className="px-3 py-2 text-right">Value</th></tr></thead>
              <tbody>{s.warehouses.map((w: any) => (
                <tr key={w.warehouse.id} className="border-b border-ink-100"><td className="px-3 py-2">{w.warehouse.name}{w.warehouse.type === "site" ? <span className="text-xs text-ink-500"> · site</span> : null}</td>
                  <td className="num px-3 py-2 text-right font-medium">{qty(w.quantity)} {s.item.unit}</td><td className="num px-3 py-2 text-right">{w.average_cost ? inr(w.average_cost) : "—"}</td><td className="num px-3 py-2 text-right">{inr(w.value)}</td></tr>))}</tbody>
            </table>
          )}
        </Card>
        <Card>
          <p className="text-xs uppercase tracking-wide text-ink-500">Total</p>
          <p className="num mt-1 text-3xl font-semibold text-ink-900">{qty(s.quantity)} <span className="text-lg text-ink-500">{s.item.unit}</span></p>
          <p className="num mt-1 text-sm text-ink-500">{inr(s.value)}{s.average_cost ? ` · average ${inr(s.average_cost)}` : ""}</p>
        </Card>
      </div>
      {(s.batches.length > 0 || s.serials.length > 0) && (
        <div className="mb-4 grid gap-4 lg:grid-cols-2">
          {s.batches.length > 0 && <Card title="Batches"><ul className="space-y-1 text-sm">{s.batches.map((b: any) => <li key={b.batch_no + b.warehouse.id}>{b.batch_no} · {qty(b.quantity)} at {b.warehouse.name}{b.expiry_date ? ` · expiry ${date(b.expiry_date)}` : ""}</li>)}</ul></Card>}
          {s.serials.length > 0 && <Card title={`Serial numbers in stock (${s.serials.length})`}><ul className="grid gap-1 text-sm sm:grid-cols-2">{s.serials.map((x: any) => <li key={x.serial_no}><span className="font-mono">{x.serial_no}</span> <span className="text-xs text-ink-500">· {x.warehouse?.name}</span></li>)}</ul></Card>}
        </div>
      )}
      <Card title="Stock ledger" padded={false} actions={<div className="w-56"><WarehouseSelect value={led.filters.warehouse_id ?? ""} onChange={(v) => led.setFilter("warehouse_id", v)} blank="All warehouses" ariaLabel="Ledger warehouse" /></div>}>
        {led.isLoading ? <Spinner /> : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-sm">
              <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
                <th className="px-3 py-2">Date</th><th className="px-3 py-2">Movement</th><th className="px-3 py-2">Document</th><th className="px-3 py-2">Warehouse</th>
                <th className="px-3 py-2 text-right">In / out</th><th className="px-3 py-2 text-right">Cost</th><th className="px-3 py-2 text-right">Value</th><th className="px-3 py-2 text-right">Balance</th></tr></thead>
              <tbody>{led.rows.map((t: any) => (
                <tr key={t.id} className="border-b border-ink-100 align-top">
                  <td className="px-3 py-2 text-ink-600">{date(t.txn_date)}</td>
                  <td className="px-3 py-2">{TXN_TYPES[t.txn_type] ?? t.txn_type}{t.serial_nos.length ? <p className="text-xs text-ink-500">{t.serial_nos.join(", ")}</p> : null}</td>
                  <td className="px-3 py-2">{SOURCE_LINK[t.source_type] ? <Link href={`${SOURCE_LINK[t.source_type]}?id=${t.source_id}`} className="text-brand-700 hover:underline">{t.source_number}</Link> : t.source_number}</td>
                  <td className="px-3 py-2 text-ink-600">{t.warehouse?.name}</td>
                  <td className={`num px-3 py-2 text-right font-medium ${Number(t.quantity) > 0 ? "text-emerald-700" : "text-brand-700"}`}>{Number(t.quantity) > 0 ? "+" : ""}{qty(t.quantity)}</td>
                  <td className="num px-3 py-2 text-right">{inr(t.unit_cost)}</td>
                  <td className="num px-3 py-2 text-right">{Number(t.value) < 0 ? `−${inr(-Number(t.value))}` : inr(t.value)}</td>
                  <td className="num px-3 py-2 text-right text-ink-600">{qty(t.balance_qty)}</td>
                </tr>))}</tbody>
            </table>
          </div>
        )}
        {led.meta && led.meta.total > 0 && <Pagination page={led.page} pageSize={led.meta.page_size} total={led.meta.total} onPage={led.setPage} />}
      </Card>
    </>
  );
}

export default function Page() {
  return <Suspense><StockItem /></Suspense>;
}
