"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Boxes, Download, ShieldCheck } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner, useToast } from "@/components/ui";
import { MiniStat } from "@/components/crm/common";
import { StockBadge, WarehouseSelect } from "@/components/purchase/common";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { inr, qty } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function StockPage() {
  const router = useRouter();
  const { can } = useAuth();
  const toast = useToast();
  const list = useList<any>("/stock/items", { sort: "item_name" });
  const s = useQuery({ queryKey: ["/stock/summary"], queryFn: () => api<any>("/stock/summary"), select: (r) => r.data }).data;
  const [checking, setChecking] = useState(false);
  const status = list.filters.status ?? "";
  return (
    <>
      <PageHeader title="Stock" subtitle="Quantity and value of every stock item, valued at weighted average cost. Balances come from the stock ledger."
        actions={<>
          <Button variant="secondary" loading={checking} icon={<ShieldCheck className="size-4" />} onClick={async () => {
            setChecking(true);
            try {
              const r = await api<any>("/stock/verify");
              toast(r.data.ok ? "Checked: every balance matches the ledger" : `${r.data.problems.length} balance(s) differ from the ledger — contact support`, r.data.ok ? "ok" : "error");
            } finally { setChecking(false); }
          }}>Check ledger</Button>
          {can("stock.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/stock/items/export", "stock.xlsx", { q: list.q, ...list.filters })}>Export</Button>}
        </>} />
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <MiniStat label="Stock value" value={s ? inr(s.stock_value, 0) : undefined} />
        <MiniStat label="Out of stock" value={s?.out_of_stock} tone="red" onClick={() => list.setFilter("status", "out")} active={status === "out"} />
        <MiniStat label="Below reorder level" value={s?.below_reorder} tone="amber" onClick={() => list.setFilter("status", "low")} active={status === "low"} />
        <MiniStat label="Items in stock" value={s?.items_in_stock} onClick={() => list.setFilter("status", "in_stock")} active={status === "in_stock"} />
      </div>
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search item code, name, model…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <div className="sm:w-60"><WarehouseSelect value={list.filters.warehouse_id ?? ""} onChange={(v) => list.setFilter("warehouse_id", v)} blank="All warehouses" ariaLabel="Warehouse" /></div>
          <Select value={status} onChange={(e) => list.setFilter("status", e.target.value)} className="sm:w-48" aria-label="Stock status">
            <option value="">All items</option><option value="in_stock">In stock</option><option value="low">Low / reorder</option><option value="out">Out of stock</option>
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows.map((r: any) => ({ ...r, id: r.item.id }))} sort={list.sort} onSort={list.setSort}
            onRowClick={(r) => router.push(`/inventory/stock/view?id=${r.item.id}`)}
            empty={<EmptyState icon={<Boxes className="size-8" />} title="No items match" body="Stock enters through GRNs and opening-stock adjustments." />}
            columns={[
              { key: "i", header: "Item", sortKey: "item_name", cell: (r) => <div><p className="font-medium text-ink-900">{r.item.name}</p><p className="text-xs text-ink-500">{r.item.code}{r.category ? ` · ${r.category}` : ""}</p></div> },
              { key: "q", header: "Quantity", sortKey: "quantity", className: "text-right", cell: (r) => <span className="num font-medium">{qty(r.quantity)} {r.item.unit}</span> },
              { key: "a", header: "Avg cost", hideOnMobile: true, className: "text-right", cell: (r) => <span className="num">{r.average_cost ? inr(r.average_cost) : "—"}</span> },
              { key: "v", header: "Value", sortKey: "value", className: "text-right", hideOnMobile: true, cell: (r) => <span className="num">{inr(r.value, 0)}</span> },
              { key: "r", header: "Reorder at", hideOnMobile: true, className: "text-right", cell: (r) => <span className="num text-ink-500">{Number(r.reorder_level) ? qty(r.reorder_level) : "—"}</span> },
              { key: "s", header: "Status", cell: (r) => <StockBadge status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
