"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Plus, SlidersHorizontal } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { ADJ_REASONS, ADJ_STATUSES, AdjStatus } from "@/components/purchase/common";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function AdjustmentsPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/stock-adjustments");
  return (
    <>
      <PageHeader title="Stock adjustments" subtitle="Opening stock and corrections after a count. Every adjustment is approved before it moves stock."
        actions={can("stock_adjustment.create") && <Link href="/inventory/adjustments/new"><Button icon={<Plus className="size-4" />}>New adjustment</Button></Link>} />
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search number or reason…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={list.filters.status ?? ""} onChange={(e) => list.setFilter("status", e.target.value)} className="sm:w-48" aria-label="Status">
            <option value="">All statuses</option>{ADJ_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/inventory/adjustments/view?id=${r.id}`)}
            empty={<EmptyState icon={<SlidersHorizontal className="size-8" />} title="No adjustments" body="Start with the opening stock of each store." />}
            columns={[
              { key: "n", header: "Adjustment", sortKey: "created_at", cell: (r) => <div><p className="font-medium text-ink-900">{r.adjustment_number ?? "Draft"}</p><p className="text-xs text-ink-500">{ADJ_REASONS.find(([k]) => k === r.reason_type)?.[1]} · {r.reason.slice(0, 60)}</p></div> },
              { key: "w", header: "Warehouse", cell: (r) => r.warehouse?.name },
              { key: "d", header: "Date", sortKey: "adjustment_date", hideOnMobile: true, cell: (r) => date(r.adjustment_date) },
              { key: "v", header: "Value", sortKey: "value", className: "text-right", cell: (r) => <span className="num">{inr(r.value, 0)}</span> },
              { key: "s", header: "Status", cell: (r) => <AdjStatus status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
