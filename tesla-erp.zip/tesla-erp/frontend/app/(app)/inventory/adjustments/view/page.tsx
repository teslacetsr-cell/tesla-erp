"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Download, FileSpreadsheet, Pencil, ShieldCheck, Undo2, XCircle } from "lucide-react";
import { Button, Card, Detail, ErrorNote, PageHeader, Spinner, Tabs, useConfirm, useToast } from "@/components/ui";
import { ADJ_REASONS, AdjStatus, ApprovalCard, ApprovalHistory } from "@/components/purchase/common";
import { AdjustmentForm } from "@/components/purchase/adjustment-form";
import { HistoryPanel } from "@/components/record-panels";
import { api, ApiError, download } from "@/lib/api/client";
import { date, dateTime, inr, qty } from "@/lib/format";

function AdjDetail() {
  const id = useSearchParams().get("id") ?? "";
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const file = useRef<HTMLInputElement>(null);
  const [tab, setTab] = useState<"items" | "approvals" | "history">("items");
  const [editing, setEditing] = useState(false);
  const [importErrors, setImportErrors] = useState<{ row: number; message: string }[] | null>(null);
  const key = ["/stock-adjustments", id];
  const { data: a, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api<any>(`/stock-adjustments/${id}`), select: (r) => r.data });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/stock-adjustments"] }); qc.invalidateQueries({ queryKey: ["/stock/items"] }); qc.invalidateQueries({ queryKey: ["/approvals/inbox"] }); };
  if (isLoading) return <Spinner />;
  if (error || !a) return <ErrorNote error={error} />;
  const can = a.can;
  async function act(path: string, msg: string) {
    try {
      const r = await api<any>(`/stock-adjustments/${id}/${path}`, { body: { row_version: a.row_version } });
      toast(path === "submit" && r.data.status === "posted" ? "Posted — stock updated" : msg); refresh();
    } catch (e: any) { toast(e.message, "error"); }
  }
  async function importFile(f: File | undefined) {
    if (!f) return;
    setImportErrors(null);
    const form = new FormData();
    form.append("file", f);
    try {
      const r = await api<any>(`/stock-adjustments/${id}/import`, { method: "POST", form, params: { mode: "append" } });
      toast(`${r.meta?.imported ?? 0} line(s) imported`); refresh();
    } catch (e) {
      if (e instanceof ApiError && Array.isArray((e as any).details)) setImportErrors((e as any).details);
      else toast((e as any).message, "error");
    } finally { if (file.current) file.current.value = ""; }
  }
  if (editing)
    return (
      <div className="mx-auto max-w-4xl">
        <PageHeader title={`Edit ${a.adjustment_number ?? "draft adjustment"}`} />
        <AdjustmentForm initial={a} submitLabel="Save" onCancel={() => setEditing(false)} onSubmit={async (body) => {
          await api(`/stock-adjustments/${id}`, { method: "PUT", body: { ...body, row_version: a.row_version } });
          toast("Saved"); setEditing(false); refresh();
        }} />
      </div>
    );
  return (
    <>
      <PageHeader back={<Link href="/inventory/adjustments" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Adjustments</Link>}
        title={<span className="flex items-center gap-2">{a.adjustment_number ?? "Draft adjustment"} <AdjStatus status={a.status} /></span>}
        subtitle={`${ADJ_REASONS.find(([k]) => k === a.reason_type)?.[1]} · ${a.warehouse?.name} · ${inr(a.value, 0)}`}
        actions={<>
          {can.submit && <Button icon={<ShieldCheck className="size-4" />} disabled={!a.lines.length} onClick={() => act("submit", "Sent for approval")}>Submit for approval</Button>}
          {can.edit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {can.edit && <Button variant="secondary" icon={<FileSpreadsheet className="size-4" />} onClick={() => file.current?.click()}>Import Excel</Button>}
          {can.edit && <Button variant="ghost" icon={<Download className="size-4" />} onClick={() => download("/stock-adjustments/template", "stock-import-template.xlsx")}>Template</Button>}
          {can.withdraw && <Button variant="secondary" icon={<Undo2 className="size-4" />} onClick={() => act("withdraw", "Back to draft")}>Withdraw</Button>}
          {can.cancel && <Button variant="ghost" icon={<XCircle className="size-4" />} onClick={async () => { if (await confirm({ title: "Cancel this adjustment?", body: "Nothing has moved yet.", confirmLabel: "Cancel adjustment" })) act("cancel", "Cancelled"); }}>Cancel</Button>}
          <input ref={file} type="file" accept=".xlsx" className="sr-only" onChange={(e) => importFile(e.target.files?.[0])} />
        </>} />
      <ApprovalCard approval={a.approval} onDone={refresh} />
      {a.last_rejection && a.status === "draft" && <p className="mb-4 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900"><b>Returned by the approver:</b> {a.last_rejection}</p>}
      {importErrors && (
        <div className="mb-4 rounded-md border border-brand-200 bg-brand-50 px-3 py-2 text-sm text-brand-800">
          <b>Nothing was imported — fix these rows and try again:</b>
          <ul className="mt-1 list-disc pl-5">{importErrors.slice(0, 20).map((x) => <li key={x.row}>Row {x.row}: {x.message}</li>)}</ul>
        </div>
      )}
      <Card className="mb-4">
        <Detail cols={4} items={[["Warehouse", a.warehouse?.name], ["Date", date(a.adjustment_date)], ["Raised by", a.created_by], ["Posted", a.posted_at ? dateTime(a.posted_at) : "—"]]} />
        <p className="mt-3 border-t border-ink-100 pt-3 text-sm">{a.reason}</p>
      </Card>
      <Tabs value={tab} onChange={setTab} tabs={[{ id: "items", label: "Items", count: a.lines.length }, { id: "approvals", label: "Approvals", count: a.approvals.length }, { id: "history", label: "History" }]} />
      {tab === "items" && (
        <Card padded={false}>
          {a.lines.length === 0 ? <p className="p-4 text-sm text-ink-500">No lines yet. Edit to add items, or import from Excel.</p> : (
            <table className="w-full text-sm">
              <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500"><th className="px-3 py-2">#</th><th className="px-3 py-2">Item</th><th className="px-3 py-2 text-right">Quantity</th><th className="px-3 py-2 text-right">Unit cost</th></tr></thead>
              <tbody>{a.lines.map((l: any) => (
                <tr key={l.id} className="border-b border-ink-100 align-top"><td className="px-3 py-2 text-ink-500">{l.line_no}</td>
                  <td className="px-3 py-2"><p>{l.item?.name}</p><p className="text-xs text-ink-500">{l.item?.code}{l.batch_no ? ` · batch ${l.batch_no}` : ""}{l.serial_nos.length ? ` · ${l.serial_nos.join(", ")}` : ""}</p></td>
                  <td className={`num px-3 py-2 text-right font-medium ${Number(l.quantity) < 0 ? "text-brand-700" : "text-emerald-700"}`}>{Number(l.quantity) > 0 ? "+" : ""}{qty(l.quantity)} {l.item?.unit}</td>
                  <td className="num px-3 py-2 text-right">{l.unit_cost ? inr(l.unit_cost) : Number(l.quantity) < 0 ? "average" : "item price"}</td></tr>))}</tbody>
            </table>
          )}
        </Card>
      )}
      {tab === "approvals" && <ApprovalHistory approvals={a.approvals} />}
      {tab === "history" && <HistoryPanel entityType="stock_adjustment" entityId={id} />}
    </>
  );
}

export default function Page() {
  return <Suspense><AdjDetail /></Suspense>;
}
