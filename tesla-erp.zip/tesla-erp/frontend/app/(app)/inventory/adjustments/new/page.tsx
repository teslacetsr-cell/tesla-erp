"use client";

import { useRouter } from "next/navigation";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader, useToast } from "@/components/ui";
import { AdjustmentForm } from "@/components/purchase/adjustment-form";
import { api } from "@/lib/api/client";

export default function NewAdjustmentPage() {
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title="New stock adjustment" subtitle="Save as draft, then submit for approval. Stock moves only when approved." />
      <AdjustmentForm submitLabel="Save draft" onCancel={() => router.back()} onSubmit={async (body) => {
        const r = await api<any>("/stock-adjustments", { body });
        toast("Draft saved");
        qc.invalidateQueries({ queryKey: ["/stock-adjustments"] });
        router.push(`/inventory/adjustments/view?id=${r.data.id}`);
      }} />
    </div>
  );
}
