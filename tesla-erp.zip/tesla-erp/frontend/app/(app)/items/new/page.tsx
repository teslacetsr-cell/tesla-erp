"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader, Spinner, useToast } from "@/components/ui";
import { SectionForm } from "@/components/section-form";
import { itemPayload, useItemSections } from "@/components/items/item-sections";
import { api } from "@/lib/api/client";

export default function NewItemPage() {
  const router = useRouter();
  const toast = useToast();
  const qc = useQueryClient();
  const { sections } = useItemSections();
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader back={<Link href="/items" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Items</Link>} title="New item" />
      {!sections ? <Spinner /> : (
        <SectionForm sections={sections} submitLabel="Create item" onCancel={() => router.push("/items")}
          onSubmit={async (v) => {
            const r = await api("/items", { body: itemPayload(v) });
            qc.invalidateQueries({ queryKey: ["/items"] });
            toast(`Item ${r.data.item_code} created`);
            router.push(`/items/view?id=${r.data.id}`);
          }} />
      )}
    </div>
  );
}
