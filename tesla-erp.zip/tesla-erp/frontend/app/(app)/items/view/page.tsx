"use client";

import Link from "next/link";
import { useSearchParams, useRouter } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Pencil, Trash2 } from "lucide-react";
import { Badge, Button, Card, Detail, ErrorNote, PageHeader, Spinner, StatusBadge, Tabs, useConfirm, useToast } from "@/components/ui";
import { SectionForm } from "@/components/section-form";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { itemPayload, useItemSections } from "@/components/items/item-sections";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { inr, qty } from "@/lib/format";

type Tab = "overview" | "documents" | "history";

function ItemDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const { can } = useAuth();
  const [tab, setTab] = useState<Tab>("overview");
  const [editing, setEditing] = useState(false);
  const { sections } = useItemSections();
  const key = ["/items", id];
  const { data, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api(`/items/${id}`) });
  if (isLoading) return <Spinner />;
  if (error || !data) return <ErrorNote error={error} />;
  const i = data.data;

  if (editing)
    return (
      <div className="mx-auto max-w-4xl">
        <PageHeader title={`Edit ${i.item_name}`} subtitle={i.item_code} />
        {!sections ? <Spinner /> : (
          <SectionForm sections={sections} initial={i} submitLabel="Save changes" onCancel={() => setEditing(false)}
            onSubmit={async (v) => {
              await api(`/items/${id}`, { method: "PUT", body: { ...itemPayload(v), row_version: i.row_version } });
              toast("Item saved");
              setEditing(false);
              qc.invalidateQueries({ queryKey: key });
              qc.invalidateQueries({ queryKey: ["/items"] });
            }} />
        )}
      </div>
    );

  return (
    <>
      <PageHeader
        back={<Link href="/items" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Items</Link>}
        title={<span className="flex items-center gap-2">{i.item_name} <StatusBadge status={i.is_active} /></span>}
        subtitle={`${i.item_code} · ${i.category}${i.brand ? ` · ${i.brand}` : ""}`}
        actions={<>
          {can("item.update") && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {can("item.delete") && <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Delete item?", body: "Items used anywhere cannot be deleted — deactivate them instead.", confirmLabel: "Delete" }))) return;
            try { await api(`/items/${id}`, { method: "DELETE" }); toast("Item deleted"); router.push("/items"); } catch (e: any) { toast(e.message, "error"); }
          }}>Delete</Button>}
        </>}
      />
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[{ id: "overview", label: "Overview" }, { id: "documents", label: "Datasheets & documents" }, { id: "history", label: "History" }]} />
      {tab === "overview" && (
        <div className="space-y-4">
          <Card title="Item">
            <Detail cols={4} items={[
              ["Type", i.item_type === "goods" ? "Goods" : "Service"], ["Category", i.category], ["Brand", i.brand], ["Model", i.model],
              ["Unit", i.unit], ["HSN / SAC", i.hsn_sac && <span className="font-mono">{i.hsn_sac}</span>], ["GST", i.gst_rate ? `${Number(i.gst_rate)}%` : null],
              ["Tracking", <span key="t" className="flex gap-1">{i.serial_number_required && <Badge tone="blue">Serial no.</Badge>}{i.batch_required && <Badge tone="blue">Batch</Badge>}{!i.serial_number_required && !i.batch_required && "—"}</span>],
            ]} />
          </Card>
          <Card title="Pricing & stock levels">
            <Detail cols={4} items={[["Purchase price", <span key="pp" className="num">{inr(i.purchase_price)}</span>], ["Selling price", <span key="sp" className="num">{inr(i.selling_price)}</span>],
              ["Minimum stock", <span key="m" className="num">{qty(i.minimum_stock)} {i.unit}</span>], ["Reorder level", <span key="r" className="num">{qty(i.reorder_level)} {i.unit}</span>]]} />
            <p className="mt-3 text-xs text-ink-500">Stock on hand appears here once inventory goes live in Phase 5.</p>
          </Card>
          {(i.description || i.technical_specification) && (
            <Card title="Description & specification">
              <Detail cols={2} items={[["Description", i.description], ["Technical specification", i.technical_specification && <span className="whitespace-pre-line">{i.technical_specification}</span>]]} />
            </Card>
          )}
        </div>
      )}
      {tab === "documents" && <DocumentsPanel entityType="item" entityId={id} canEdit={can("item.update")} defaultCategory="certificate" />}
      {tab === "history" && <HistoryPanel entityType="item" entityId={id} />}
    </>
  );
}

// Record id comes from ?id= so the UI can be exported as static files (served by the on-premise server).
export default function Page() {
  return (
    <Suspense>
      <ItemDetail />
    </Suspense>
  );
}
