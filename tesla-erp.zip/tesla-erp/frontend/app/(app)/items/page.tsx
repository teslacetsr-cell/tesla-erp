"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Boxes, Download, Plus, Upload } from "lucide-react";
import { Badge, Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { ImportDialog } from "@/components/import-dialog";
import { download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { inr } from "@/lib/format";
import { useList, useOptions } from "@/lib/hooks";

type Row = { id: string; item_code: string; item_name: string; item_type: string; category: string; brand: string | null; model: string | null; unit: string; hsn_sac: string | null; gst_rate: string | null; selling_price: string | null; is_active: boolean; serial_number_required: boolean };

export default function ItemsPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<Row>("/items");
  const cats = useOptions("/item-categories");
  const [importing, setImporting] = useState(false);
  return (
    <>
      <PageHeader title="Items & services" subtitle="Products, materials and services used in BOQs, quotations, purchase and stock."
        actions={<>
          {can("item.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/items/export", "items.xlsx")}>Export</Button>}
          {can("item.create") && <>
            <Button variant="secondary" icon={<Upload className="size-4" />} onClick={() => setImporting(true)}>Import</Button>
            <Link href="/items/new"><Button icon={<Plus className="size-4" />}>New item</Button></Link>
          </>}
        </>} />
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search name, code, model, HSN…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={list.filters.category_id ?? ""} onChange={(e) => list.setFilter("category_id", e.target.value)} className="sm:w-52">
            <option value="">All categories</option>
            {cats.data?.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
          <Select value={list.filters.item_type ?? ""} onChange={(e) => list.setFilter("item_type", e.target.value)} className="sm:w-36">
            <option value="">Goods & services</option><option value="goods">Goods</option><option value="service">Services</option>
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/items/view?id=${r.id}`)}
            empty={<EmptyState icon={<Boxes className="size-8" />} title="No items found" />}
            columns={[
              { key: "n", header: "Item", sortKey: "item_name", cell: (r) => <div><p className="font-medium">{r.item_name}{!r.is_active && <span className="ml-2"><Badge>Inactive</Badge></span>}</p><p className="text-xs text-ink-500">{r.item_code}{r.brand ? ` · ${r.brand}` : ""}{r.model ? ` ${r.model}` : ""}</p></div> },
              { key: "c", header: "Category", hideOnMobile: true, cell: (r) => r.category },
              { key: "h", header: "HSN/SAC", hideOnMobile: true, cell: (r) => <span className="font-mono text-xs">{r.hsn_sac ?? "—"}</span> },
              { key: "g", header: "GST", hideOnMobile: true, cell: (r) => r.gst_rate ? `${Number(r.gst_rate)}%` : "—" },
              { key: "u", header: "Unit", cell: (r) => r.unit },
              { key: "p", header: "Selling price", sortKey: "selling_price", className: "text-right", cell: (r) => <span className="num">{inr(r.selling_price)}</span> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
      <ImportDialog open={importing} onClose={() => setImporting(false)} base="/items" noun="items" />
    </>
  );
}
