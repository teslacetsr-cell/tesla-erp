"use client";

import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ImageUp } from "lucide-react";
import { Button, Card, Detail, ErrorNote, PageHeader, Spinner, useToast } from "@/components/ui";
import { SectionForm, type Section } from "@/components/section-form";
import { api, objectUrl } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";

const SECTIONS: Section[] = [
  { title: "Company", fields: [
    { name: "company_name", label: "Company name", required: true, span: 2 }, { name: "tagline", label: "Tagline" },
    { name: "legal_name", label: "Legal name", required: true, span: 2 }, { name: "gstin", label: "GSTIN", upper: true },
    { name: "pan", label: "PAN", upper: true }, { name: "phone", label: "Phone" }, { name: "email", label: "Email" }, { name: "website", label: "Website" },
  ] },
  { title: "Registered address", columns: 2, fields: [
    { name: "address_line1", label: "Address line 1", span: 2 }, { name: "address_line2", label: "Address line 2", span: 2 },
    { name: "city", label: "City" }, { name: "state_code", label: "State", type: "state" }, { name: "pincode", label: "PIN code" },
  ] },
  { title: "Bank details (printed on quotations & invoices)", fields: [
    { name: "bank_name", label: "Bank" }, { name: "branch", label: "Branch" }, { name: "ifsc", label: "IFSC", upper: true },
    { name: "bank_account_name", label: "Account name", span: 2 }, { name: "account_number", label: "Account number" },
  ] },
];

function Logo({ version, canEdit }: { version: number; canEdit: boolean }) {
  const [src, setSrc] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const toast = useToast();
  const qc = useQueryClient();
  useEffect(() => {
    let url: string | null = null;
    objectUrl("/company/logo").then((u) => setSrc((url = u))).catch(() => setSrc(null));
    return () => { if (url) URL.revokeObjectURL(url); };
  }, [version]);
  return (
    <Card title="Logo">
      <div className="flex items-center gap-4">
        <div className="flex size-24 items-center justify-center rounded-lg border border-ink-200 bg-white">
          {src ? <img src={src} alt="Company logo" className="size-20 object-contain" /> : <span className="text-xs text-ink-400">No logo</span>}
        </div>
        {canEdit && (
          <div>
            <Button variant="secondary" icon={<ImageUp className="size-4" />} loading={busy} onClick={() => input.current?.click()}>Replace logo</Button>
            <p className="mt-1 text-xs text-ink-500">PNG, JPG or WEBP. Used on the sign-in page, quotations, POs and invoices.</p>
            <input ref={input} type="file" accept=".png,.jpg,.jpeg,.webp" className="sr-only" onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              setBusy(true);
              try {
                const form = new FormData();
                form.append("file", f);
                await api("/company/logo", { method: "POST", form });
                toast("Logo updated");
                qc.invalidateQueries({ queryKey: ["/company"] });
              } catch (err: any) { toast(err.message, "error"); } finally { setBusy(false); }
            }} />
          </div>
        )}
      </div>
    </Card>
  );
}

export default function CompanyPage() {
  const { can } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const { data, isLoading, error } = useQuery({ queryKey: ["/company"], queryFn: () => api("/company") });
  const [editing, setEditing] = useState(false);
  if (isLoading) return <Spinner />;
  if (error) return <ErrorNote error={error} />;
  const c = data.data;
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title="Company profile" subtitle="Details printed on every document the ERP generates."
        actions={can("company.update") && !editing && <Button variant="secondary" onClick={() => setEditing(true)}>Edit</Button>} />
      <div className="space-y-5">
        <Logo version={c.row_version} canEdit={can("company.update")} />
        {editing ? (
          <SectionForm sections={SECTIONS} initial={c} gstinAutofill submitLabel="Save company" onCancel={() => setEditing(false)}
            onSubmit={async (v) => {
              await api("/company", { method: "PUT", body: { ...v, row_version: c.row_version } });
              toast("Company profile saved");
              setEditing(false);
              qc.invalidateQueries({ queryKey: ["/company"] });
            }} />
        ) : (
          <>
            <Card title="Company"><Detail items={[["Name", c.company_name], ["Legal name", c.legal_name], ["Tagline", c.tagline], ["GSTIN", c.gstin], ["PAN", c.pan], ["Phone", c.phone], ["Email", c.email], ["Website", c.website]]} /></Card>
            <Card title="Registered address"><Detail cols={2} items={[["Address", [c.address_line1, c.address_line2, c.city, c.state, c.pincode].filter(Boolean).join(", ")], ["State code", c.state_code]]} /></Card>
            <Card title="Bank details"><Detail items={[["Bank", c.bank_name], ["Branch", c.branch], ["IFSC", c.ifsc], ["Account name", c.bank_account_name], ["Account number", c.account_number && <span className="font-mono">{c.account_number}</span>]]} /></Card>
          </>
        )}
      </div>
    </div>
  );
}
