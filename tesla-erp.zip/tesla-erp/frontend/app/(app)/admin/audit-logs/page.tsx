"use client";

import { ScrollText } from "lucide-react";
import { Card, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { AuditList } from "@/components/record-panels";
import { useList } from "@/lib/hooks";

const ENTITIES = ["customer", "customer_contact", "customer_site", "supplier", "supplier_bank_account", "item", "user", "role", "company", "setting", "numbering_format", "employee", "division", "warehouse", "tax_rate", "auth"];
const ACTIONS = ["create", "update", "delete", "login", "login_failed", "logout", "password_change", "password_reset", "upload", "export", "import", "revoke_sessions", "token_reuse"];

export default function AuditLogsPage() {
  const list = useList<any>("/audit-logs");
  return (
    <>
      <PageHeader title="Audit log" subtitle="Every important change — who, what, when, old and new values. Entries cannot be edited or deleted." />
      <Card padded={false}>
        <div className="grid gap-2 border-b border-ink-100 p-3 sm:grid-cols-2 lg:grid-cols-5">
          <Input placeholder="Search record or summary…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="lg:col-span-2" />
          <Select value={list.filters.entity_type ?? ""} onChange={(e) => list.setFilter("entity_type", e.target.value)}>
            <option value="">All records</option>{ENTITIES.map((x) => <option key={x} value={x}>{x.replace(/_/g, " ")}</option>)}
          </Select>
          <Select value={list.filters.action ?? ""} onChange={(e) => list.setFilter("action", e.target.value)}>
            <option value="">All actions</option>{ACTIONS.map((x) => <option key={x} value={x}>{x.replace(/_/g, " ")}</option>)}
          </Select>
          <Input type="date" value={list.filters.date_from ?? ""} onChange={(e) => list.setFilter("date_from", e.target.value)} aria-label="From date" />
        </div>
        <div className="bg-ink-50/40 p-3">
          {list.isLoading ? <Spinner /> : list.rows.length ? <AuditList logs={list.rows} showEntity /> : <EmptyState icon={<ScrollText className="size-8" />} title="No matching entries" />}
        </div>
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
