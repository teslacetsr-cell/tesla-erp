"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Plus, Trash2 } from "lucide-react";
import { Button, Card, DataTable, EmptyState, ErrorNote, Input, PageHeader, Pagination, Spinner, useConfirm, useToast } from "@/components/ui";
import { RecordForm } from "@/components/record-form";
import { MASTERS } from "@/components/masters";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { useList, useOptions } from "@/lib/hooks";

function MasterPage() {
  const kind = useSearchParams().get("kind") ?? "";
  const def = MASTERS.find((m) => m.kind === kind);
  const { can } = useAuth();
  const list = useList<any>(def?.path ?? "/none");
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [editing, setEditing] = useState<any | "new" | null>(null);
  const src = def?.optionSources?.base;
  const baseOpts = useOptions(src?.path ?? "/units", !!src);
  if (!def) return <ErrorNote error={new Error("Unknown master list")} />;
  const fields = typeof def.fields === "function"
    ? def.fields({ base: (baseOpts.data ?? []).filter((u: any) => !u.base_unit_id && (editing === "new" || u.id !== editing?.id)).map((u: any) => [u.id, src!.label(u)]) })
    : def.fields;
  const canEdit = can(`${def.perm}.update`);
  const refresh = () => qc.invalidateQueries({ queryKey: [def.path] });

  return (
    <>
      <PageHeader back={<Link href="/admin/masters" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Masters</Link>}
        title={def.title} subtitle={def.description}
        actions={can(`${def.perm}.create`) && <Button icon={<Plus className="size-4" />} onClick={() => setEditing("new")}>Add {def.noun}</Button>} />
      <Card padded={false}>
        <div className="border-b border-ink-100 p-3"><Input placeholder="Search…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-xs" /></div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} onRowClick={canEdit ? (r) => setEditing(r) : undefined} empty={<EmptyState title={`No ${def.noun}s`} />}
            columns={[...def.columns, { key: "_d", header: "", className: "w-12", cell: (r: any) => can(`${def.perm}.delete`) && (
              <Button size="sm" variant="ghost" aria-label="Delete" onClick={async (e) => {
                e.stopPropagation();
                if (!(await confirm({ title: `Delete ${def.noun}?`, body: "Records in use cannot be deleted — deactivate them instead.", confirmLabel: "Delete" }))) return;
                try { await api(`${def.path}/${r.id}`, { method: "DELETE" }); toast("Deleted"); refresh(); } catch (err: any) { toast(err.message, "error"); }
              }}><Trash2 className="size-3.5 text-ink-400" /></Button>
            ) }]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
      <RecordForm open={editing !== null} title={editing === "new" ? `Add ${def.noun}` : `Edit ${def.noun}`} fields={fields}
        initial={editing === "new" ? { decimals: "0", warehouse_type: "main", cess_rate: "0" } : editing ? { ...editing, decimals: String(editing.decimals ?? "") } : null}
        onClose={() => setEditing(null)}
        onSave={async (v) => {
          if (v.decimals !== undefined && v.decimals !== null) v.decimals = Number(v.decimals);
          if (editing === "new") await api(def.path, { body: v });
          else await api(`${def.path}/${editing.id}`, { method: "PUT", body: { ...v, row_version: editing.row_version } });
          toast("Saved");
          setEditing(null);
          refresh();
          qc.invalidateQueries({ queryKey: [def.path, "options"] });
        }} />
    </>
  );
}

// Record id comes from ?kind= so the UI can be exported as static files (served by the on-premise server).
export default function Page() {
  return (
    <Suspense>
      <MasterPage />
    </Suspense>
  );
}
