"use client";

import Link from "next/link";
import { ChevronRight } from "lucide-react";
import { PageHeader } from "@/components/ui";
import { MASTERS } from "@/components/masters";
import { useAuth } from "@/lib/auth";

export default function MastersIndex() {
  const { can } = useAuth();
  return (
    <>
      <PageHeader title="Masters" subtitle="Reference lists used across the ERP." />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {MASTERS.filter((m) => can(`${m.perm}.read`)).map((m) => (
          <Link key={m.kind} href={`/admin/masters/view?kind=${m.kind}`} className="group flex items-start justify-between gap-3 rounded-lg border border-ink-200 bg-white p-4 hover:border-brand-300">
            <span>
              <span className="block font-medium text-ink-900">{m.title}</span>
              <span className="mt-0.5 block text-sm text-ink-500">{m.description}</span>
            </span>
            <ChevronRight className="mt-0.5 size-4 shrink-0 text-ink-300 group-hover:text-brand-600" />
          </Link>
        ))}
      </div>
    </>
  );
}
