"use client";

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { BellRing, Hash, Mail, Server } from "lucide-react";
import { Badge, Button, Card, Checkbox, Input, PageHeader, Select, Spinner, useToast } from "@/components/ui";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { bytes, date, dateTime } from "@/lib/format";

type Setting = { key: string; label: string; group: string; help: string; type: "bool" | "int" | "str"; value: any; default: any };
type Fmt = { doc_type: string; label: string; pattern: string; period: string; max_length: number | null; example: string; row_version: number };

function SettingRow({ s, canEdit }: { s: Setting; canEdit: boolean }) {
  const [value, setValue] = useState<any>(s.value);
  const qc = useQueryClient();
  const toast = useToast();
  const save = async (v: any) => {
    try {
      await api(`/settings/${s.key}`, { method: "PUT", body: { value: v } });
      toast("Setting saved");
      qc.invalidateQueries({ queryKey: ["/settings"] });
    } catch (e: any) { toast(e.message, "error"); setValue(s.value); }
  };
  return (
    <div className="flex flex-col gap-2 border-b border-ink-100 px-4 py-3 last:border-0 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <p className="text-sm font-medium text-ink-900">{s.label}</p>
        {s.help && <p className="text-xs text-ink-500">{s.help}</p>}
      </div>
      {s.type === "bool" ? (
        <Checkbox label={value ? "On" : "Off"} checked={!!value} disabled={!canEdit} onChange={(e) => { setValue(e.target.checked); save(e.target.checked); }} />
      ) : (
        <div className="flex gap-2">
          <Input className={s.type === "int" ? "num w-40 text-right" : "w-80"} value={value} disabled={!canEdit} onChange={(e) => setValue(e.target.value)} />
          {canEdit && String(value) !== String(s.value) && <Button size="sm" onClick={() => save(s.type === "int" ? Number(value) : value)}>Save</Button>}
        </div>
      )}
    </div>
  );
}

function FormatRow({ f, canEdit }: { f: Fmt; canEdit: boolean }) {
  const [pattern, setPattern] = useState(f.pattern);
  const [period, setPeriod] = useState(f.period);
  const qc = useQueryClient();
  const toast = useToast();
  const changed = pattern !== f.pattern || period !== f.period;
  return (
    <tr className="border-b border-ink-100 last:border-0">
      <td className="px-4 py-2.5 font-medium">{f.label}{f.max_length && <span className="ml-2"><Badge tone="amber">max {f.max_length} chars</Badge></span>}</td>
      <td className="px-4 py-2.5"><Input className="font-mono text-xs" value={pattern} disabled={!canEdit} onChange={(e) => setPattern(e.target.value)} /></td>
      <td className="px-4 py-2.5">
        <Select value={period} disabled={!canEdit} onChange={(e) => setPeriod(e.target.value)} className="w-44">
          <option value="fy">Financial year (Apr–Mar)</option><option value="calendar">Calendar year</option><option value="none">Never resets</option>
        </Select>
      </td>
      <td className="px-4 py-2.5 font-mono text-xs text-ink-600">{f.example}</td>
      <td className="px-4 py-2.5 text-right">{canEdit && changed && <Button size="sm" onClick={async () => {
        try {
          await api(`/numbering-formats/${f.doc_type}`, { method: "PUT", body: { pattern, period, row_version: f.row_version } });
          toast("Numbering updated — applies to documents issued from now on");
          qc.invalidateQueries({ queryKey: ["/numbering-formats"] });
        } catch (e: any) { toast(e.message, "error"); }
      }}>Save</Button>}</td>
    </tr>
  );
}

type SysStatus = {
  version: string; deployment: string;
  storage: { backend: string; location: string; ok: boolean; detail: string };
  database: { size: string };
  backup: { ok?: boolean; last_success?: string; file?: string; size_bytes?: number; error?: string | null } | null;
  tunnel: { state: string; detail?: string | null } | null;
  server: { urls?: string[]; public_url?: string | null; started?: string } | null;
};

function backupHealth(s?: SysStatus): "ok" | "stale" | "failed" | "n/a" {
  if (!s || (s.deployment !== "onprem" && !s.backup)) return "n/a";
  if (!s.backup?.last_success) return "failed";
  if (s.backup.ok === false) return "failed";
  return Date.now() - new Date(s.backup.last_success).getTime() > 26 * 3600 * 1000 ? "stale" : "ok";
}

function SystemCard() {
  const { data } = useQuery({ queryKey: ["/system/status"], queryFn: () => api<{ data: SysStatus }>("/system/status"), refetchInterval: 60_000 });
  const s = data?.data;
  if (!s) return null;
  const bh = backupHealth(s);
  const Row = ({ label, ok, children }: { label: string; ok?: boolean; children: React.ReactNode }) => (
    <div className="flex flex-col gap-1 border-b border-ink-100 px-4 py-3 last:border-0 sm:flex-row sm:items-center sm:justify-between">
      <p className="text-sm font-medium text-ink-900">{label}</p>
      <div className="flex items-center gap-2 text-sm text-ink-700">
        {ok !== undefined && <Badge tone={ok ? "green" : "red"}>{ok ? "OK" : "Attention"}</Badge>}
        <span className="break-all text-right">{children}</span>
      </div>
    </div>
  );
  return (
    <Card title={<span className="flex items-center gap-2"><Server className="size-4 text-brand-600" /> System</span>} padded={false}>
      <Row label="Version">{s.version} · {s.deployment === "onprem" ? "Office server" : "Cloud server"}</Row>
      {s.server?.urls && <Row label="Office address">{s.server.urls.join("  ·  ")}</Row>}
      {s.deployment === "onprem" && (
        <Row label="Remote access" ok={s.tunnel?.state !== "reconnecting"}>
          {s.server?.public_url ?? "—"} {s.tunnel ? `(${s.tunnel.state})` : ""}
        </Row>
      )}
      <Row label="Document storage" ok={s.storage.ok}>{s.storage.location} — {s.storage.detail}</Row>
      <Row label="Database size">{s.database.size}</Row>
      {bh !== "n/a" && (
        <Row label="Last backup" ok={bh === "ok"}>
          {s.backup?.last_success ? dateTime(s.backup.last_success) : "never"}
          {s.backup?.size_bytes ? ` · ${bytes(s.backup.size_bytes)}` : ""}
          {s.backup?.error ? ` · ${s.backup.error}` : ""}
        </Row>
      )}
    </Card>
  );
}


type Channels = {
  email: { configured: boolean; host: string | null; port: number; tls: string; sender: string | null; base_url: string | null };
  whatsapp: { configured: boolean; provider: string }; sms: { configured: boolean; provider: string };
  last_7_days: { sent: number; waiting: number; failed: number }; last_error: string | null;
};
type AlertRun = { alert: string; label: string; enabled?: boolean; ran?: boolean; already_ran?: boolean; items: number; recipients: number; run_date?: string; ran_at?: string };

function EmailCard({ canEdit }: { canEdit: boolean }) {
  const { data } = useQuery({ queryKey: ["/notifications/channels"], queryFn: () => api<{ data: Channels }>("/notifications/channels"), select: (r) => r.data });
  const [to, setTo] = useState("");
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  if (!data) return null;
  const e = data.email;
  const Row = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div className="flex flex-col gap-1 border-b border-ink-100 px-4 py-3 last:border-0 sm:flex-row sm:items-center sm:justify-between">
      <p className="text-sm font-medium text-ink-900">{label}</p>
      <div className="text-sm text-ink-700 sm:text-right">{children}</div>
    </div>
  );
  return (
    <Card title={<span className="flex items-center gap-2"><Mail className="size-4 text-brand-600" /> Email &amp; notifications</span>} padded={false}>
      <Row label="Outgoing email">
        {e.configured ? <span className="flex flex-wrap items-center gap-2 sm:justify-end"><Badge tone="green">Set up</Badge> {e.sender} via {e.host}:{e.port} ({e.tls})</span>
          : <span className="flex flex-wrap items-center gap-2 sm:justify-end"><Badge tone="amber">Not set up</Badge> Add SMTP_HOST, SMTP_USER, SMTP_PASSWORD and SMTP_FROM to the server settings.</span>}
      </Row>
      <Row label="Links in emails open">{e.base_url ?? <span className="text-amber-700">APP_BASE_URL is not set — emails will have no links</span>}</Row>
      <Row label="Emails in the last 7 days">
        {data.last_7_days.sent} sent · {data.last_7_days.waiting} waiting · <span className={data.last_7_days.failed ? "font-medium text-brand-700" : ""}>{data.last_7_days.failed} failed</span>
        {data.last_error && <span className="block text-xs text-brand-700">Last failure: {data.last_error}</span>}
      </Row>
      <Row label="WhatsApp / SMS">{data.whatsapp.configured || data.sms.configured ? `Test mode (${[data.whatsapp.configured && "WhatsApp", data.sms.configured && "SMS"].filter(Boolean).join(", ")} written to the log only)` : "Not connected — a provider can be added later"}</Row>
      {canEdit && e.configured && (
        <div className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:justify-end">
          <Input type="email" className="sm:w-72" placeholder="Send to (blank = my own email)" value={to} onChange={(ev) => setTo(ev.target.value)} />
          <Button size="sm" variant="secondary" disabled={busy} onClick={async () => {
            setBusy(true);
            try {
              const r = await api<{ data: { to: string } }>("/notifications/test-email", { method: "POST", body: to.trim() ? { to: to.trim() } : {} });
              toast(`Test email sent to ${r.data.to}`);
            } catch (err: any) { toast(err.message, "error"); } finally { setBusy(false); }
          }}>{busy ? "Sending…" : "Send test email"}</Button>
        </div>
      )}
    </Card>
  );
}

function AlertsCard({ canEdit }: { canEdit: boolean }) {
  const qc = useQueryClient();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const { data } = useQuery({ queryKey: ["/notifications/alerts"], queryFn: () => api<{ data: { history: AlertRun[] } }>("/notifications/alerts"), select: (r) => r.data });
  const days = [...new Set((data?.history ?? []).map((h) => h.run_date!))].slice(0, 3);
  return (
    <Card title={<span className="flex items-center gap-2"><BellRing className="size-4 text-brand-600" /> Daily alerts</span>}
      actions={canEdit && <Button size="sm" variant="secondary" disabled={busy} onClick={async () => {
        setBusy(true);
        try {
          const r = await api<{ data: AlertRun[] }>("/notifications/alerts/run", { method: "POST", body: {} });
          const ran = r.data.filter((x) => x.ran);
          toast(ran.length ? `Sent: ${ran.map((x) => `${x.label} (${x.items})`).join(", ")}` : "Today's alerts were already sent.");
          qc.invalidateQueries({ queryKey: ["/notifications/alerts"] });
          qc.invalidateQueries({ queryKey: ["/notifications"] });
        } catch (err: any) { toast(err.message, "error"); } finally { setBusy(false); }
      }}>{busy ? "Running…" : "Run today's alerts now"}</Button>}>
      <p className="text-sm text-ink-600">Once a day, at the hour set below (India time), each person gets one notification per alert listing what needs their attention — and, if they chose it, one summary email. Switch each alert on or off and set its limits under <span className="font-medium">Alerts</span> below.</p>
      {days.length > 0 && (
        <div className="mt-3 space-y-2">
          {days.map((d) => (
            <div key={d} className="text-sm">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-500">{date(d)}</p>
              <p className="text-ink-700">{data!.history.filter((h) => h.run_date === d).map((h) => `${h.label}: ${h.items}`).join(" · ")}</p>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}

export default function SettingsPage() {
  const { can } = useAuth();
  const settings = useQuery({ queryKey: ["/settings"], queryFn: () => api<{ data: Setting[] }>("/settings") });
  const formats = useQuery({ queryKey: ["/numbering-formats"], queryFn: () => api<{ data: Fmt[] }>("/numbering-formats") });
  if (settings.isLoading || formats.isLoading) return <Spinner />;
  const groups = [...new Set(settings.data?.data.map((s) => s.group))];
  const canEdit = can("settings.update");
  return (
    <>
      <PageHeader title="Settings" subtitle="Company-wide rules. Every change is audited." />
      <div className="space-y-5">
        <SystemCard />
        <EmailCard canEdit={canEdit} />
        <AlertsCard canEdit={canEdit} />
        <Card title={<span className="flex items-center gap-2"><Hash className="size-4 text-brand-600" /> Document numbering</span>} padded={false}>
          <p className="border-b border-ink-100 px-4 py-2.5 text-sm text-ink-600">
            Tokens: <code className="text-xs">{"{FY}"}</code> 2026-27 · <code className="text-xs">{"{FYS}"}</code> 2627 · <code className="text-xs">{"{YYYY}"}</code> calendar year · <code className="text-xs">{"{SEQ:4}"}</code> 0001.
            Numbers are allocated inside the saving transaction, so two users can never get the same number.
          </p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-ink-200 bg-ink-50/60 text-left text-xs uppercase tracking-wide text-ink-500">
                <th className="px-4 py-2 font-medium">Document</th><th className="px-4 py-2 font-medium">Pattern</th><th className="px-4 py-2 font-medium">Resets</th><th className="px-4 py-2 font-medium">Example</th><th />
              </tr></thead>
              <tbody>{formats.data?.data.map((f) => <FormatRow key={f.doc_type + f.row_version} f={f} canEdit={canEdit} />)}</tbody>
            </table>
          </div>
        </Card>
        {groups.map((g) => (
          <Card key={g} title={g} padded={false}>
            {settings.data?.data.filter((s) => s.group === g).map((s) => <SettingRow key={s.key + String(s.value)} s={s} canEdit={canEdit} />)}
          </Card>
        ))}
      </div>
    </>
  );
}
