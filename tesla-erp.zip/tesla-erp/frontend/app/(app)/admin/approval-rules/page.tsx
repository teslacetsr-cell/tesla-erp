"use client";

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowRight, Plus, X } from "lucide-react";
import { Badge, Button, Card, Checkbox, EmptyState, ErrorNote, Field, Input, Modal, PageHeader, Select, Spinner, StatusBadge, useConfirm, useToast } from "@/components/ui";
import { useDivisionOptions } from "@/components/crm/common";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { inr } from "@/lib/format";

const ENTITY_TYPES: [string, string][] = [["quotation", "Quotations"], ["purchase_request", "Purchase requests"], ["purchase_order", "Purchase orders"], ["stock_adjustment", "Stock adjustments"], ["expense", "Expense claims"], ["supplier_invoice", "Supplier bills that differ from the PO / GRN"], ["material_issue", "Material issues to projects"], ["leave_request", "Leave requests"]];

type Policy = { id: string; entity_type: string; entity_name: string; name: string; min_amount: string; division_id: string | null; division: string | null; steps: string[]; is_active: boolean; row_version: number };

function PolicyDialog({ policy, open, onClose, onSaved }: { policy: Policy | null; open: boolean; onClose: () => void; onSaved: () => void }) {
  const roles = useQuery({ queryKey: ["/approval-policies/roles"], queryFn: () => api<{ data: { code: string; name: string }[] }>("/approval-policies/roles"), select: (r) => r.data });
  const divisions = useDivisionOptions();
  const [entityType, setEntityType] = useState(policy?.entity_type ?? "quotation");
  const [name, setName] = useState(policy?.name ?? "");
  const [min, setMin] = useState(policy ? String(Number(policy.min_amount)) : "500000");
  const [division, setDivision] = useState(policy?.division_id ?? "");
  const [steps, setSteps] = useState<string[]>(policy?.steps ?? ["MANAGER"]);
  const [active, setActive] = useState(policy?.is_active ?? true);
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  const label = (c: string) => roles.data?.find((r) => r.code === c)?.name ?? c;
  return (
    <Modal open={open} onClose={onClose} title={policy ? "Edit approval rule" : "New approval rule"}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setBusy(true);
        setError(null);
        try {
          const body = { entity_type: entityType, name, min_amount: min || "0", division_id: division || null, steps, is_active: active };
          if (policy) await api(`/approval-policies/${policy.id}`, { method: "PUT", body: { ...body, row_version: policy.row_version } });
          else await api("/approval-policies", { body });
          onSaved();
        } catch (e) { setError(e); } finally { setBusy(false); }
      }}>Save</Button></>}>
      <div className="space-y-4">
        <ErrorNote error={error} />
        <Field label="Applies to" required>
          <Select value={entityType} onChange={(e) => setEntityType(e.target.value)} disabled={!!policy}>
            {ENTITY_TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
        </Field>
        <Field label="Name" required><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Quotations above ₹5 lakh" /></Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Applies above (₹, before GST)" hint={`${inr(Number(min) || 0, 0)} — use 0 for every document`}><Input inputMode="decimal" className="num" value={min} onChange={(e) => setMin(e.target.value)} /></Field>
          <Field label="Business division" hint="Blank = all divisions"><Select value={division} onChange={(e) => setDivision(e.target.value)}>{divisions.map(([v, l]) => <option key={v} value={v}>{v ? l : "All divisions"}</option>)}</Select></Field>
        </div>
        <div>
          <p className="mb-1 text-[13px] font-medium text-ink-700">Approvers, in order</p>
          <div className="flex flex-wrap items-center gap-1.5">
            <Badge>Requester</Badge>
            {steps.map((s, i) => (
              <span key={i} className="flex items-center gap-1.5">
                <ArrowRight className="size-3.5 text-ink-400" />
                <span className="inline-flex items-center gap-1 rounded bg-brand-50 px-2 py-0.5 text-xs font-medium text-brand-700">
                  {label(s)}
                  <button type="button" aria-label={`Remove ${label(s)}`} onClick={() => setSteps(steps.filter((_, j) => j !== i))}><X className="size-3" /></button>
                </span>
              </span>
            ))}
          </div>
          {steps.length < 5 && (
            <Select value="" onChange={(e) => e.target.value && setSteps([...steps, e.target.value])} className="mt-2 w-56" aria-label="Add approver">
              <option value="">+ Add approver role…</option>
              {roles.data?.filter((r) => r.code !== "ADMIN").map((r) => <option key={r.code} value={r.code}>{r.name}</option>)}
            </Select>
          )}
          <p className="mt-1 text-xs text-ink-500">Administrators and Directors may also decide any step. Nobody approves their own request.</p>
        </div>
        <Checkbox label="Active" checked={active} onChange={(e) => setActive(e.target.checked)} />
      </div>
    </Modal>
  );
}

export default function ApprovalRulesPage() {
  const { can } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const { data, isLoading } = useQuery({ queryKey: ["/approval-policies"], queryFn: () => api<{ data: Policy[] }>("/approval-policies"), select: (r) => r.data });
  const [editing, setEditing] = useState<Policy | "new" | null>(null);
  const refresh = () => qc.invalidateQueries({ queryKey: ["/approval-policies"] });
  return (
    <>
      <PageHeader title="Approval rules" subtitle="Which quotations, purchase requests, purchase orders and stock adjustments need approval, and by whom (Spec §30). For each kind of document the rule with the highest limit that applies is used; amounts are before GST."
        actions={can("approval_policy.create") && <Button icon={<Plus className="size-4" />} onClick={() => setEditing("new")}>New rule</Button>} />
      {isLoading ? <Spinner /> : !data?.length ? <Card><EmptyState title="No rules — documents are approved on submission" /></Card> : (
        <Card padded={false}>
          <ul className="divide-y divide-ink-100">
            {data.map((p) => (
              <li key={p.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                <div className="min-w-0 flex-1">
                  <p className="font-medium text-ink-900">{p.name} {!p.is_active && <StatusBadge status={false} />}</p>
                  <p className="text-sm text-ink-600">{p.entity_name} above <span className="num">{inr(p.min_amount, 0)}</span>{p.division ? ` · ${p.division}` : ""} · {p.steps.map((s) => s.replace(/_/g, " ").toLowerCase()).join(" → ")}</p>
                </div>
                {can("approval_policy.update") && <Button size="sm" variant="secondary" onClick={() => setEditing(p)}>Edit</Button>}
                {can("approval_policy.delete") && <Button size="sm" variant="ghost" onClick={async () => {
                  if (!(await confirm({ title: "Delete this rule?", body: "Requests already in progress keep their steps.", confirmLabel: "Delete" }))) return;
                  try { await api(`/approval-policies/${p.id}`, { method: "DELETE" }); refresh(); } catch (e: any) { toast(e.message, "error"); }
                }}>Delete</Button>}
              </li>
            ))}
          </ul>
        </Card>
      )}
      {editing && <PolicyDialog open policy={editing === "new" ? null : editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); toast("Rule saved"); refresh(); }} />}
    </>
  );
}
