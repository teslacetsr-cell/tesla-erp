"use client";

import clsx from "clsx";
import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Lock, Plus, Shield } from "lucide-react";
import { Badge, Button, Card, ErrorNote, Field, Input, Modal, PageHeader, Spinner, useToast } from "@/components/ui";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";

type Role = { id: string; code: string; name: string; description: string | null; is_system: boolean; is_active: boolean; row_version: number; user_count: number; grants: Record<string, string> };
type Module = { module: string; label: string; permissions: { code: string; action: string; label: string; supports_scope: boolean }[] };
const ACTIONS = ["create", "read", "update", "delete", "approve", "export", "print", "use", "moderate"];
const ACTION_LABEL: Record<string, string> = { create: "Create", read: "View", update: "Edit", delete: "Delete", approve: "Approve", export: "Export", print: "Print", use: "Use", moderate: "Moderate" };

export default function RolesPage() {
  const { can } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const roles = useQuery({ queryKey: ["/roles"], queryFn: () => api<{ data: Role[] }>("/roles") });
  const perms = useQuery({ queryKey: ["/permissions"], queryFn: () => api<{ data: Module[] }>("/permissions") });
  const [selected, setSelected] = useState<string | null>(null);
  const [grants, setGrants] = useState<Record<string, string>>({});
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [creating, setCreating] = useState(false);
  const role = roles.data?.data.find((r) => r.id === selected) ?? roles.data?.data[0];
  useEffect(() => {
    if (role) {
      setGrants(role.grants);
      setDirty(false);
    }
  }, [role?.id, role?.row_version]); // eslint-disable-line react-hooks/exhaustive-deps

  const locked = !role || role.code === "ADMIN" || !can("role.update");
  const count = useMemo(() => Object.keys(grants).length, [grants]);

  function toggle(code: string, on: boolean) {
    setGrants((g) => {
      const n = { ...g };
      if (on) n[code] = "all";
      else delete n[code];
      return n;
    });
    setDirty(true);
  }

  async function save() {
    if (!role) return;
    setSaving(true);
    try {
      await api(`/roles/${role.id}`, { method: "PUT", body: { name: role.name, description: role.description, is_active: role.is_active, grants, row_version: role.row_version } });
      toast(`${role.name} saved. Users with this role get the new access on their next request.`);
      qc.invalidateQueries({ queryKey: ["/roles"] });
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setSaving(false);
    }
  }

  if (roles.isLoading || perms.isLoading) return <Spinner />;
  return (
    <>
      <PageHeader title="Roles & permissions" subtitle="What each role may do, module by module. Every change is recorded in the audit log."
        actions={can("role.create") && <Button variant="secondary" icon={<Plus className="size-4" />} onClick={() => setCreating(true)}>New role</Button>} />
      <div className="grid gap-4 lg:grid-cols-[260px_1fr]">
        <Card padded={false}>
          <ul className="p-1">
            {roles.data?.data.map((r) => (
              <li key={r.id}>
                <button onClick={() => setSelected(r.id)} className={clsx("flex w-full items-center justify-between rounded-md px-3 py-2 text-left text-sm", role?.id === r.id ? "bg-brand-50 text-brand-800" : "hover:bg-ink-50")}>
                  <span>
                    <span className="block font-medium">{r.name}</span>
                    <span className="block text-xs text-ink-500">{r.user_count} user{r.user_count === 1 ? "" : "s"}</span>
                  </span>
                  {r.code === "ADMIN" ? <Shield className="size-4 text-brand-600" /> : !r.is_active ? <Badge>Off</Badge> : null}
                </button>
              </li>
            ))}
          </ul>
        </Card>
        {role && (
          <Card
            title={<span className="flex items-center gap-2">{role.name}{locked && <Lock className="size-3.5 text-ink-400" />}</span>}
            actions={!locked && <Button size="sm" onClick={save} disabled={!dirty} loading={saving}>Save changes</Button>}
            padded={false}
          >
            <p className="border-b border-ink-100 px-4 py-2.5 text-sm text-ink-600">
              {role.description}
              {role.code === "ADMIN" && " The Administrator role always has every permission."}
              <span className="ml-1 text-ink-400">· {count} permissions</span>
            </p>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-ink-200 bg-ink-50/60 text-xs uppercase tracking-wide text-ink-500">
                    <th className="px-4 py-2 text-left font-medium">Module</th>
                    {ACTIONS.map((a) => <th key={a} className="px-2 py-2 text-center font-medium">{ACTION_LABEL[a]}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {perms.data?.data.map((m) => (
                    <tr key={m.module} className="border-b border-ink-100 last:border-0">
                      <td className="px-4 py-2 font-medium text-ink-800">{m.label}</td>
                      {ACTIONS.map((a) => {
                        const p = m.permissions.find((x) => x.action === a);
                        if (!p) return <td key={a} className="px-2 py-2 text-center text-ink-200">·</td>;
                        const on = !!grants[p.code];
                        return (
                          <td key={a} className="px-2 py-2 text-center">
                            <div className="flex flex-col items-center gap-1">
                              <input type="checkbox" aria-label={p.code} className="size-4 accent-brand-600" checked={on} disabled={locked} onChange={(e) => toggle(p.code, e.target.checked)} />
                              {on && p.supports_scope && (
                                <select disabled={locked} value={grants[p.code]} onChange={(e) => { setGrants((g) => ({ ...g, [p.code]: e.target.value })); setDirty(true); }}
                                  className="rounded border border-ink-200 bg-white px-1 text-[11px]" title="Which records">
                                  <option value="all">All</option><option value="own">Own only</option>
                                </select>
                              )}
                            </div>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}
      </div>
      {creating && <NewRole onClose={() => setCreating(false)} onCreated={(id) => { setSelected(id); setCreating(false); }} />}
    </>
  );
}

function NewRole({ onClose, onCreated }: { onClose: () => void; onCreated: (id: string) => void }) {
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState<unknown>(null);
  const qc = useQueryClient();
  return (
    <Modal open onClose={onClose} title="New role" footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button onClick={async () => {
      try {
        const r = await api("/roles", { body: { code, name, description: description || null, grants: {} } });
        qc.invalidateQueries({ queryKey: ["/roles"] });
        onCreated(r.data.id);
      } catch (e) { setError(e); }
    }}>Create</Button></>}>
      <div className="space-y-3">
        <ErrorNote error={error} />
        <Field label="Code" hint="Capitals and underscores, e.g. SOLAR_SALES"><Input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} /></Field>
        <Field label="Name"><Input value={name} onChange={(e) => setName(e.target.value)} /></Field>
        <Field label="Description"><Input value={description} onChange={(e) => setDescription(e.target.value)} /></Field>
        <p className="text-xs text-ink-500">After creating the role, tick its permissions in the matrix.</p>
      </div>
    </Modal>
  );
}
