"use client";

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { KeyRound, LogOut, Plus, Unlock, UserCog } from "lucide-react";
import { Badge, Button, Card, Checkbox, DataTable, EmptyState, ErrorNote, Field, Input, Modal, PageHeader, Pagination, Select, Spinner, useConfirm, useToast } from "@/components/ui";
import { api, ApiError } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { dateTime } from "@/lib/format";
import { useList } from "@/lib/hooks";

type Role = { id: string; code: string; name: string };
type User = { id: string; username: string; email: string; full_name: string; phone: string | null; is_active: boolean; must_change_password: boolean; last_login_at: string | null; locked_until: string | null; roles: Role[]; row_version: number };

function UserDialog({ user, roles, onClose }: { user: User | "new"; roles: Role[]; onClose: () => void }) {
  const isNew = user === "new";
  const u = isNew ? null : user;
  const [values, setValues] = useState({
    username: u?.username ?? "", email: u?.email ?? "", full_name: u?.full_name ?? "", phone: u?.phone ?? "",
    role_codes: u?.roles.map((r) => r.code) ?? [], is_active: u?.is_active ?? true, temporary_password: "",
  });
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  const qc = useQueryClient();
  const toast = useToast();
  const fe = error instanceof ApiError ? error.fieldErrors() : {};
  const set = (k: string, v: unknown) => setValues((x) => ({ ...x, [k]: v }));
  async function save() {
    setBusy(true);
    setError(null);
    try {
      if (isNew) await api("/users", { body: { ...values, phone: values.phone || null } });
      else await api(`/users/${u!.id}`, { method: "PUT", body: { email: values.email, full_name: values.full_name, phone: values.phone || null, role_codes: values.role_codes, is_active: values.is_active, row_version: u!.row_version } });
      toast(isNew ? "User created — they must change the temporary password at first sign-in" : "User saved");
      qc.invalidateQueries({ queryKey: ["/users"] });
      onClose();
    } catch (e) {
      setError(e);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal open onClose={onClose} title={isNew ? "New user" : `Edit ${u!.full_name}`} wide
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button onClick={save} loading={busy}>Save</Button></>}>
      <div className="space-y-4">
        <ErrorNote error={error instanceof ApiError && error.status === 422 ? null : error} />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Full name" required error={fe.full_name}><Input value={values.full_name} onChange={(e) => set("full_name", e.target.value)} /></Field>
          <Field label="Username" required error={fe.username} hint={isNew ? "Letters, digits, dot, dash, underscore" : "Cannot be changed"}>
            <Input value={values.username} disabled={!isNew} onChange={(e) => set("username", e.target.value)} />
          </Field>
          <Field label="Email" required error={fe.email}><Input type="email" value={values.email} onChange={(e) => set("email", e.target.value)} /></Field>
          <Field label="Phone" error={fe.phone}><Input value={values.phone} onChange={(e) => set("phone", e.target.value)} /></Field>
          {isNew && (
            <Field label="Temporary password" required error={fe.temporary_password} hint="At least 10 characters. The user must change it at first sign-in." className="sm:col-span-2">
              <Input type="text" autoComplete="off" value={values.temporary_password} onChange={(e) => set("temporary_password", e.target.value)} />
            </Field>
          )}
        </div>
        <div>
          <p className="mb-2 text-[13px] font-medium text-ink-700">Roles <span className="text-brand-600">*</span></p>
          <div className="grid gap-2 sm:grid-cols-3">
            {roles.map((r) => (
              <Checkbox key={r.code} label={r.name} checked={values.role_codes.includes(r.code)}
                onChange={(e) => set("role_codes", e.target.checked ? [...values.role_codes, r.code] : values.role_codes.filter((c) => c !== r.code))} />
            ))}
          </div>
          {fe.role_codes && <p className="mt-1 text-xs text-brand-700">{fe.role_codes}</p>}
        </div>
        {!isNew && <Checkbox label="Active (can sign in)" checked={values.is_active} onChange={(e) => set("is_active", e.target.checked)} />}
      </div>
    </Modal>
  );
}

function ResetDialog({ user, onClose }: { user: User; onClose: () => void }) {
  const [pw, setPw] = useState("");
  const [error, setError] = useState<unknown>(null);
  const toast = useToast();
  return (
    <Modal open onClose={onClose} title={`Reset password — ${user.full_name}`}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button onClick={async () => {
        try { await api(`/users/${user.id}/reset-password`, { body: { temporary_password: pw } }); toast("Password reset. All of this user's sessions were signed out."); onClose(); } catch (e) { setError(e); }
      }}>Reset password</Button></>}>
      <div className="space-y-3">
        <ErrorNote error={error} />
        <Field label="Temporary password" hint="Give this to the user privately. They must change it when they next sign in.">
          <Input value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="off" />
        </Field>
      </div>
    </Modal>
  );
}

export default function UsersPage() {
  const { can, me } = useAuth();
  const list = useList<User>("/users");
  const roles = useQuery({ queryKey: ["/roles"], queryFn: () => api<{ data: (Role & { is_active: boolean })[] }>("/roles"), select: (r) => r.data.filter((x) => x.is_active) });
  const [editing, setEditing] = useState<User | "new" | null>(null);
  const [resetting, setResetting] = useState<User | null>(null);
  const toast = useToast();
  const confirm = useConfirm();
  const qc = useQueryClient();
  const action = async (u: User, path: string, msg: string) => {
    await api(`/users/${u.id}/${path}`, { method: "POST" });
    toast(msg);
    qc.invalidateQueries({ queryKey: ["/users"] });
  };
  return (
    <>
      <PageHeader title="Users" subtitle="Who can sign in, and with which roles."
        actions={can("user.create") && <Button icon={<Plus className="size-4" />} onClick={() => setEditing("new")}>New user</Button>} />
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search name, username, email…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={list.filters.is_active ?? ""} onChange={(e) => list.setFilter("is_active", e.target.value)} className="sm:w-36">
            <option value="">All users</option><option value="true">Active</option><option value="false">Deactivated</option>
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort}
            onRowClick={can("user.update") ? (u) => setEditing(u) : undefined}
            empty={<EmptyState icon={<UserCog className="size-8" />} title="No users found" />}
            columns={[
              { key: "n", header: "User", sortKey: "full_name", cell: (u) => <div><p className="font-medium">{u.full_name}</p><p className="text-xs text-ink-500">{u.username} · {u.email}</p></div> },
              { key: "r", header: "Roles", cell: (u) => <div className="flex flex-wrap gap-1">{u.roles.map((r) => <Badge key={r.code} tone={r.code === "ADMIN" ? "red" : "grey"}>{r.name}</Badge>)}</div> },
              { key: "l", header: "Last sign-in", sortKey: "last_login_at", hideOnMobile: true, cell: (u) => <span className="text-ink-600">{dateTime(u.last_login_at)}</span> },
              { key: "s", header: "Status", cell: (u) => (
                <div className="flex flex-wrap gap-1">
                  {u.is_active ? <Badge tone="green">Active</Badge> : <Badge>Deactivated</Badge>}
                  {u.locked_until && new Date(u.locked_until) > new Date() && <Badge tone="red">Locked</Badge>}
                  {u.must_change_password && <Badge tone="amber">Temp password</Badge>}
                </div>
              ) },
              { key: "a", header: "", className: "text-right", cell: (u) => can("user.update") && (
                <div className="flex justify-end gap-1" onClick={(e) => e.stopPropagation()}>
                  {u.locked_until && new Date(u.locked_until) > new Date() && <Button size="sm" variant="ghost" title="Unlock" onClick={() => action(u, "unlock", "Account unlocked")}><Unlock className="size-4" /></Button>}
                  <Button size="sm" variant="ghost" title="Reset password" onClick={() => setResetting(u)}><KeyRound className="size-4" /></Button>
                  {u.id !== me?.id && <Button size="sm" variant="ghost" title="Sign out everywhere" onClick={async () => {
                    if (await confirm({ title: "Sign this user out everywhere?", body: `${u.full_name} will be signed out on every device immediately.`, confirmLabel: "Sign out" })) action(u, "revoke-sessions", "Signed out on all devices");
                  }}><LogOut className="size-4" /></Button>}
                </div>
              ) },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
      {editing && roles.data && <UserDialog user={editing} roles={roles.data} onClose={() => setEditing(null)} />}
      {resetting && <ResetDialog user={resetting} onClose={() => setResetting(null)} />}
    </>
  );
}
