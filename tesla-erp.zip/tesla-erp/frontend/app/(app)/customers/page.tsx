"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Download, Plus, Upload, Users } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner, StatusBadge } from "@/components/ui";
import { ImportDialog } from "@/components/import-dialog";
import { CUSTOMER_TYPES } from "@/components/customers/customer-form";
import { download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { useList } from "@/lib/hooks";

type Row = {
  id: string; customer_code: string; customer_name: string; customer_type: string; gstin: string | null; phone: string | null;
  city: string | null; state: string | null; status: string; assigned_sales_person: string | null;
};

export default function CustomersPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<Row>("/customers");
  const [importing, setImporting] = useState(false);

  return (
    <>
      <PageHeader
        title="Customers"
        subtitle="One customer master for every division — quotations, projects and invoices all point here."
        actions={
          <>
            {can("customer.export") && (
              <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/customers/export", "customers.xlsx", { q: list.q, ...list.filters })}>
                Export
              </Button>
            )}
            {can("customer.create") && (
              <>
                <Button variant="secondary" icon={<Upload className="size-4" />} onClick={() => setImporting(true)}>
                  Import
                </Button>
                <Link href="/customers/new">
                  <Button icon={<Plus className="size-4" />}>New customer</Button>
                </Link>
              </>
            )}
          </>
        }
      />
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search name, code, GSTIN, phone, city, contact…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={list.filters.customer_type ?? ""} onChange={(e) => list.setFilter("customer_type", e.target.value)} className="sm:w-44">
            <option value="">All types</option>
            {CUSTOMER_TYPES.map((t) => (
              <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>
            ))}
          </Select>
          <Select value={list.filters.status ?? ""} onChange={(e) => list.setFilter("status", e.target.value)} className="sm:w-36">
            <option value="">Any status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="blocked">Blocked</option>
          </Select>
        </div>
        {list.isLoading ? (
          <Spinner />
        ) : (
          <DataTable
            rows={list.rows}
            sort={list.sort}
            onSort={list.setSort}
            onRowClick={(r) => router.push(`/customers/view?id=${r.id}`)}
            empty={<EmptyState icon={<Users className="size-8" />} title={list.q ? "No customers match your search" : "No customers yet"} />}
            columns={[
              { key: "name", header: "Customer", sortKey: "customer_name", cell: (r) => (
                <div>
                  <p className="font-medium text-ink-900">{r.customer_name}</p>
                  <p className="text-xs text-ink-500">{r.customer_code} · {r.customer_type.charAt(0).toUpperCase() + r.customer_type.slice(1)}</p>
                </div>
              ) },
              { key: "gstin", header: "GSTIN", hideOnMobile: true, cell: (r) => <span className="font-mono text-xs">{r.gstin ?? "—"}</span> },
              { key: "city", header: "Location", sortKey: "city", hideOnMobile: true, cell: (r) => [r.city, r.state].filter(Boolean).join(", ") || "—" },
              { key: "phone", header: "Phone", hideOnMobile: true, cell: (r) => r.phone ?? "—" },
              { key: "sp", header: "Salesperson", hideOnMobile: true, cell: (r) => r.assigned_sales_person ?? <span className="text-ink-400">Unassigned</span> },
              { key: "status", header: "Status", cell: (r) => <StatusBadge status={r.status} /> },
            ]}
          />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
      <ImportDialog open={importing} onClose={() => setImporting(false)} base="/customers" noun="customers" />
    </>
  );
}
