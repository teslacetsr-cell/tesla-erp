"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader, useToast } from "@/components/ui";
import { CustomerForm } from "@/components/customers/customer-form";
import { api } from "@/lib/api/client";

export default function NewCustomerPage() {
  const router = useRouter();
  const toast = useToast();
  const qc = useQueryClient();
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader
        back={<Link href="/customers" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Customers</Link>}
        title="New customer"
      />
      <CustomerForm
        submitLabel="Create customer"
        onCancel={() => router.push("/customers")}
        onSubmit={async (values, allowDuplicate) => {
          const r = await api("/customers", { body: values, params: { allow_duplicate: allowDuplicate || undefined } });
          qc.invalidateQueries({ queryKey: ["/customers"] });
          toast(`Customer ${r.data.customer_code} created`);
          router.push(`/customers/view?id=${r.data.id}`);
        }}
      />
    </div>
  );
}
