"use client";

import Link from "next/link";
import { useSearchParams, useRouter } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, MapPin, Pencil, Trash2 } from "lucide-react";
import { Badge, Button, Card, DataTable, Detail, EmptyState, ErrorNote, PageHeader, Spinner, StatusBadge, Tabs, useConfirm, useToast } from "@/components/ui";
import { CrmStatus } from "@/components/crm/common";
import { QuotationStatus } from "@/components/quotations/status";
import { CustomerForm } from "@/components/customers/customer-form";
import { ChildEditor, type FieldDef } from "@/components/record-form";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, dateTime, inr, titleCase } from "@/lib/format";

const CONTACT_FIELDS: FieldDef[] = [
  { name: "name", label: "Name", required: true },
  { name: "designation", label: "Designation" },
  { name: "phone", label: "Phone" },
  { name: "email", label: "Email" },
  { name: "is_primary", label: "Primary contact", type: "checkbox" },
  { name: "is_active", label: "Active", type: "checkbox" },
];
const ADDRESS: FieldDef[] = [
  { name: "address_line1", label: "Address line 1", span: 2 },
  { name: "address_line2", label: "Address line 2", span: 2 },
  { name: "city", label: "City" },
  { name: "district", label: "District" },
  { name: "state_code", label: "State", type: "state" },
  { name: "pincode", label: "PIN code" },
];
const SITE_FIELDS: FieldDef[] = [
  { name: "site_name", label: "Site name", required: true, span: 2 },
  { name: "contact_name", label: "Site contact" },
  { name: "contact_phone", label: "Contact phone" },
  ...ADDRESS,
  { name: "latitude", label: "Latitude", type: "number", hint: "Optional, e.g. 10.5276" },
  { name: "longitude", label: "Longitude", type: "number", hint: "Optional, e.g. 76.2144" },
  { name: "notes", label: "Notes", type: "textarea" },
  { name: "is_active", label: "Active", type: "checkbox" },
];
const ADDR_FIELDS: FieldDef[] = [
  { name: "address_type", label: "Type", type: "select", options: [["shipping", "Shipping"], ["delivery", "Delivery"], ["office", "Office"], ["other", "Other"]] },
  { name: "label", label: "Label" },
  { name: "gstin", label: "GSTIN (if registered in another state)", span: 2, upper: true },
  ...ADDRESS,
  { name: "is_active", label: "Active", type: "checkbox" },
];

type Tab = "overview" | "crm" | "contacts" | "sites" | "addresses" | "documents" | "history";

/** Enquiries and site visits for this customer (Phase 2). */
function CustomerCrm({ customerId }: { customerId: string }) {
  const { can } = useAuth();
  const router = useRouter();
  const enquiries = useQuery({ queryKey: ["/enquiries", "customer", customerId], queryFn: () => api<any>("/enquiries", { params: { customer_id: customerId, page_size: 50 } }), enabled: can("enquiry.read") });
  const quotes = useQuery({ queryKey: ["/quotations", "customer", customerId], queryFn: () => api<any>("/quotations", { params: { customer_id: customerId, page_size: 50 } }), enabled: can("quotation.read") });
  const visits = useQuery({ queryKey: ["/site-visits", "customer", customerId], queryFn: () => api<any>("/site-visits", { params: { customer_id: customerId, page_size: 50 } }), enabled: can("site_visit.read") });
  return (
    <div className="space-y-4">
      {can("enquiry.read") && (
        <Card title="Enquiries" padded={false} actions={can("enquiry.create") && <Link href={`/crm/enquiries/new?customer_id=${customerId}`}><Button size="sm">New enquiry</Button></Link>}>
          <DataTable rows={enquiries.data?.data ?? []} onRowClick={(r: any) => router.push(`/crm/enquiries/view?id=${r.id}`)} empty={<EmptyState title="No enquiries" />}
            columns={[
              { key: "s", header: "Enquiry", cell: (r: any) => <div><p className="font-medium">{r.subject}</p><p className="text-xs text-ink-500">{r.enquiry_number}</p></div> },
              { key: "d", header: "Date", cell: (r: any) => date(r.enquiry_date) },
              { key: "st", header: "Status", cell: (r: any) => <CrmStatus kind="enquiry" status={r.status} /> },
            ]} />
        </Card>
      )}
      {can("quotation.read") && (
        <Card title="Quotations" padded={false} actions={can("quotation.create") && <Link href={`/sales/quotations/new?customer_id=${customerId}`}><Button size="sm" variant="secondary">New quotation</Button></Link>}>
          <DataTable rows={quotes.data?.data ?? []} onRowClick={(r: any) => router.push(`/sales/quotations/view?id=${r.id}`)} empty={<EmptyState title="No quotations" />}
            columns={[
              { key: "n", header: "Quotation", cell: (r: any) => <div><p className="font-medium">{r.subject}</p><p className="text-xs text-ink-500">{r.display_number}</p></div> },
              { key: "d", header: "Date", hideOnMobile: true, cell: (r: any) => date(r.quotation_date) },
              { key: "t", header: "Grand total", className: "text-right", cell: (r: any) => <span className="num">{inr(r.grand_total, 0)}</span> },
              { key: "s", header: "Status", cell: (r: any) => <QuotationStatus status={r.status} /> },
            ]} />
        </Card>
      )}
      {can("site_visit.read") && (
        <Card title="Site visits" padded={false} actions={can("site_visit.create") && <Link href={`/crm/site-visits/new?customer_id=${customerId}`}><Button size="sm" variant="secondary">New site visit</Button></Link>}>
          <DataTable rows={visits.data?.data ?? []} onRowClick={(r: any) => router.push(`/crm/site-visits/view?id=${r.id}`)} empty={<EmptyState title="No site visits" />}
            columns={[
              { key: "d", header: "Date", cell: (r: any) => <div><p className="font-medium">{date(r.visit_date)}</p><p className="text-xs text-ink-500">{r.visit_number}</p></div> },
              { key: "l", header: "Location", cell: (r: any) => r.site_location },
              { key: "e", header: "Engineer", hideOnMobile: true, cell: (r: any) => r.engineer ?? "—" },
              { key: "s", header: "Status", cell: (r: any) => <CrmStatus kind="visit" status={r.status} /> },
            ]} />
        </Card>
      )}
    </div>
  );
}

function CustomerDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const { can } = useAuth();
  const [tab, setTab] = useState<Tab>("overview");
  const [editing, setEditing] = useState(false);
  const key = ["/customers", id];
  const { data, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api(`/customers/${id}`) });
  const refresh = () => qc.invalidateQueries({ queryKey: key });

  if (isLoading) return <Spinner />;
  if (error || !data) return <ErrorNote error={error} />;
  const c = data.data;
  const canEdit = c.can_edit && can("customer.update");
  const addr = [c.address_line1, c.address_line2, c.city, c.district, c.state, c.pincode].filter(Boolean).join(", ");

  if (editing)
    return (
      <div className="mx-auto max-w-4xl">
        <PageHeader title={`Edit ${c.customer_name}`} subtitle={c.customer_code} />
        <CustomerForm
          initial={c}
          submitLabel="Save changes"
          onCancel={() => setEditing(false)}
          onSubmit={async (values, allowDuplicate) => {
            await api(`/customers/${id}`, { method: "PUT", body: { ...values, row_version: c.row_version }, params: { allow_duplicate: allowDuplicate || undefined } });
            toast("Customer saved");
            setEditing(false);
            refresh();
            qc.invalidateQueries({ queryKey: ["/customers"] });
          }}
        />
      </div>
    );

  return (
    <>
      <PageHeader
        back={<Link href="/customers" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Customers</Link>}
        title={
          <span className="flex flex-wrap items-center gap-2">
            {c.customer_name} <StatusBadge status={c.status} />
          </span>
        }
        subtitle={`${c.customer_code} · ${titleCase(c.customer_type)}${c.assigned_sales_person ? ` · ${c.assigned_sales_person}` : ""}`}
        actions={
          <>
            {canEdit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
            {can("customer.delete") && c.can_edit && (
              <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
                if (!(await confirm({ title: "Delete customer?", body: "Only customers with no linked records can be deleted. Otherwise set the status to Inactive.", confirmLabel: "Delete" }))) return;
                try {
                  await api(`/customers/${id}`, { method: "DELETE" });
                  toast("Customer deleted");
                  qc.invalidateQueries({ queryKey: ["/customers"] });
                  router.push("/customers");
                } catch (e: any) { toast(e.message, "error"); }
              }}>Delete</Button>
            )}
          </>
        }
      />
      {!canEdit && can("customer.update") && (
        <p className="mb-4 rounded-md bg-ink-100 px-3 py-2 text-sm text-ink-600">
          You can view this customer. Only its assigned salesperson or a manager can change it.
        </p>
      )}
      <Tabs<Tab>
        value={tab}
        onChange={setTab}
        tabs={[
          { id: "overview", label: "Overview" },
          ...(can("enquiry.read|site_visit.read|quotation.read") ? [{ id: "crm" as Tab, label: "Enquiries, quotations & visits" }] : []),
          { id: "contacts", label: "Contacts", count: c.contacts.length },
          { id: "sites", label: "Sites", count: c.sites.length },
          { id: "addresses", label: "Addresses", count: c.addresses.length },
          { id: "documents", label: "Documents" },
          { id: "history", label: "History" },
        ]}
      />
      {tab === "overview" && (
        <div className="grid gap-4 xl:grid-cols-[1fr_340px]">
          <div className="space-y-4">
            <Card title="Details">
              <Detail items={[
                ["Legal / company name", c.company_name], ["GSTIN", c.gstin && <span className="font-mono">{c.gstin}</span>],
                ["PAN", c.pan && <span className="font-mono">{c.pan}</span>], ["Phone", c.phone], ["Email", c.email], ["Website", c.website],
              ]} />
            </Card>
            <Card title="Billing address">
              <Detail cols={2} items={[["Address", addr], ["Place of supply", c.state_code ? `${c.state} (${c.state_code})` : null]]} />
            </Card>
            <Card title="Commercial">
              <Detail items={[
                ["Payment terms", c.default_payment_terms], ["Credit limit", c.credit_limit ? <span className="num">{inr(c.credit_limit, 0)}</span> : null],
                ["Credit days", c.credit_days], ["Salesperson", c.assigned_sales_person], ["Notes", c.notes],
              ]} />
            </Card>
          </div>
          <div className="space-y-4">
            <Card title="Primary contact">
              {c.contacts.find((x: any) => x.is_primary) ? (() => {
                const p = c.contacts.find((x: any) => x.is_primary);
                return (<div className="text-sm"><p className="font-medium">{p.name}</p><p className="text-ink-500">{p.designation}</p><p className="mt-1">{p.phone}</p><p>{p.email}</p></div>);
              })() : <p className="text-sm text-ink-500">None set.</p>}
            </Card>
            <Card title="Sites">
              {c.sites.length ? (
                <ul className="space-y-2">
                  {c.sites.map((s: any) => (
                    <li key={s.id} className="flex gap-2 text-sm"><MapPin className="mt-0.5 size-4 shrink-0 text-brand-600" /><span><span className="font-medium">{s.site_name}</span><br /><span className="text-ink-500">{[s.city, s.state].filter(Boolean).join(", ")}</span></span></li>
                  ))}
                </ul>
              ) : <p className="text-sm text-ink-500">No sites yet.</p>}
            </Card>
            <p className="text-xs text-ink-400">Created {dateTime(c.created_at)} · updated {dateTime(c.updated_at)}</p>
            <div className="flex flex-wrap gap-1.5">
              {["Projects", "Invoices"].map((x) => <Badge key={x}>{x} — later phases</Badge>)}
            </div>
          </div>
        </div>
      )}
      {tab === "crm" && <CustomerCrm customerId={id} />}
      {tab === "contacts" && (
        <ChildEditor title="Contacts" noun="contact" rows={c.contacts} fields={CONTACT_FIELDS} basePath={`/customers/${id}/contacts`} canEdit={canEdit} onChanged={refresh}
          columns={[
            { key: "n", header: "Name", cell: (r: any) => <span className="font-medium">{r.name}{r.is_primary && <span className="ml-2"><Badge tone="red">Primary</Badge></span>}</span> },
            { key: "d", header: "Designation", cell: (r: any) => r.designation ?? "—", hideOnMobile: true },
            { key: "p", header: "Phone", cell: (r: any) => r.phone ?? "—" },
            { key: "e", header: "Email", cell: (r: any) => r.email ?? "—", hideOnMobile: true },
          ]} />
      )}
      {tab === "sites" && (
        <ChildEditor title="Project sites" noun="site" rows={c.sites} fields={SITE_FIELDS} basePath={`/customers/${id}/sites`} canEdit={canEdit} onChanged={refresh}
          columns={[
            { key: "n", header: "Site", cell: (r: any) => <span className="font-medium">{r.site_name}</span> },
            { key: "a", header: "Location", cell: (r: any) => [r.city, r.state].filter(Boolean).join(", ") || "—" },
            { key: "c", header: "Contact", hideOnMobile: true, cell: (r: any) => [r.contact_name, r.contact_phone].filter(Boolean).join(" · ") || "—" },
            { key: "s", header: "Status", cell: (r: any) => <StatusBadge status={r.is_active} /> },
          ]} />
      )}
      {tab === "addresses" && (
        <ChildEditor title="Other addresses" noun="address" rows={c.addresses} fields={ADDR_FIELDS} basePath={`/customers/${id}/addresses`} canEdit={canEdit} onChanged={refresh}
          columns={[
            { key: "t", header: "Type", cell: (r: any) => titleCase(r.address_type) },
            { key: "l", header: "Label", cell: (r: any) => r.label ?? "—" },
            { key: "a", header: "Address", cell: (r: any) => [r.address_line1, r.city, r.state].filter(Boolean).join(", ") || "—" },
          ]} />
      )}
      {tab === "documents" && <DocumentsPanel entityType="customer" entityId={id} canEdit={canEdit} defaultCategory="customer_document" />}
      {tab === "history" && <HistoryPanel entityType="customer" entityId={id} />}
    </>
  );
}

// Record id comes from ?id= so the UI can be exported as static files (served by the on-premise server).
export default function Page() {
  return (
    <Suspense>
      <CustomerDetail />
    </Suspense>
  );
}
