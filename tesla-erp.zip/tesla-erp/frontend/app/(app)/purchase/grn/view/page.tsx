"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, FileDown } from "lucide-react";
import { Badge, Button, Card, Detail, ErrorNote, PageHeader, Spinner, Tabs } from "@/components/ui";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api, download } from "@/lib/api/client";
import { date, dateTime, inr, qty } from "@/lib/format";

function GrnDetail() {
  const id = useSearchParams().get("id") ?? "";
  const [tab, setTab] = useState<"items" | "documents" | "history">("items");
  const { data: g, isLoading, error } = useQuery({ queryKey: ["/grns", id], queryFn: () => api<any>(`/grns/${id}`), select: (r) => r.data });
  if (isLoading) return <Spinner />;
  if (error || !g) return <ErrorNote error={error} />;
  return (
    <>
      <PageHeader back={<Link href="/purchase/grn" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Goods received</Link>}
        title={g.grn_number} subtitle={`${g.supplier.name} · ${g.po_number} · received by ${g.received_by}`}
        actions={g.can.print && <Button variant="secondary" icon={<FileDown className="size-4" />} onClick={() => download(`/grns/${id}/pdf`, `${g.grn_number.replaceAll("/", "-")}.pdf`)}>PDF</Button>} />
      <Card className="mb-4">
        <Detail cols={4} items={[
          ["Purchase order", <Link key="p" href={`/purchase/orders/view?id=${g.purchase_order_id}`} className="text-brand-700 hover:underline">{g.po_number}</Link>],
          ["Received at", g.warehouse?.name], ["Date", date(g.grn_date)], ["Recorded", dateTime(g.created_at)],
          ["Supplier invoice", g.supplier_invoice_no ? `${g.supplier_invoice_no}${g.supplier_invoice_date ? ` · ${date(g.supplier_invoice_date)}` : ""}` : null],
          ["Delivery challan", g.delivery_challan_no], ["Vehicle", g.vehicle_no], ["Accepted value", inr(g.value)],
        ]} />
        {g.notes && <p className="mt-3 border-t border-ink-100 pt-3 text-sm">{g.notes}</p>}
      </Card>
      <Tabs value={tab} onChange={setTab} tabs={[{ id: "items", label: "Items", count: g.lines.length }, { id: "documents", label: "Documents" }, { id: "history", label: "History" }]} />
      {tab === "items" && (
        <Card padded={false}>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-sm">
              <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
                <th className="px-3 py-2">#</th><th className="px-3 py-2">Item</th><th className="px-3 py-2 text-right">Received</th><th className="px-3 py-2 text-right">Accepted</th>
                <th className="px-3 py-2 text-right">Rejected</th><th className="px-3 py-2 text-right">Unit cost</th><th className="px-3 py-2 text-right">Value</th></tr></thead>
              <tbody>{g.lines.map((l: any) => (
                <tr key={l.id} className="border-b border-ink-100 align-top">
                  <td className="px-3 py-2 text-ink-500">{l.line_no}</td>
                  <td className="px-3 py-2">
                    <p className="text-ink-900">{l.description} {!l.stocked && <Badge>Not stocked</Badge>}</p>
                    {l.batch_no && <p className="text-xs text-ink-500">Batch {l.batch_no}{l.expiry_date ? ` · expiry ${date(l.expiry_date)}` : ""}</p>}
                    {l.serial_nos.length > 0 && <p className="text-xs text-ink-500">Serial nos: {l.serial_nos.join(", ")}</p>}
                    {l.rejection_reason && <p className="text-xs text-brand-700">Rejected: {l.rejection_reason}</p>}
                  </td>
                  <td className="num px-3 py-2 text-right">{qty(l.received_qty)} {l.unit}</td>
                  <td className="num px-3 py-2 text-right text-emerald-700">{qty(l.accepted_qty)}</td>
                  <td className={`num px-3 py-2 text-right ${Number(l.rejected_qty) ? "text-brand-700" : "text-ink-400"}`}>{qty(l.rejected_qty)}</td>
                  <td className="num px-3 py-2 text-right">{inr(l.unit_cost)}</td>
                  <td className="num px-3 py-2 text-right font-medium">{inr(l.value)}</td>
                </tr>))}</tbody>
            </table>
          </div>
          <p className="border-t border-ink-100 px-3 py-2 text-xs text-ink-500">Unit cost = the order's rate after discounts, before GST. A GRN cannot be edited; a wrong receipt is corrected with a stock adjustment.</p>
        </Card>
      )}
      {tab === "documents" && <DocumentsPanel entityType="grn" entityId={id} canEdit={false} defaultCategory="invoice" />}
      {tab === "history" && <HistoryPanel entityType="grn" entityId={id} />}
    </>
  );
}

export default function Page() {
  return <Suspense><GrnDetail /></Suspense>;
}
