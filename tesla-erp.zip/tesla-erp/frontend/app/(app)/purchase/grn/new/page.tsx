"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button, Card, ErrorNote, Field, Input, PageHeader, Select, Spinner, Textarea, useToast } from "@/components/ui";
import { istToday } from "@/components/projects/common";
import { splitSerials, WarehouseSelect } from "@/components/purchase/common";
import { api, type Page } from "@/lib/api/client";
import { qty } from "@/lib/format";

type L = { accepted: string; rejected: string; reason: string; batch: string; expiry: string; serials: string };

function NewGrn() {
  const poParam = useSearchParams().get("po");
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const [poId, setPoId] = useState(poParam ?? "");
  const open = useQuery({ queryKey: ["/purchase-orders", "receivable"], queryFn: () => api<Page<any>>("/purchase-orders", { params: { receivable: true, page_size: 200 } }), select: (r) => r.data, enabled: !poParam });
  const po = useQuery({ queryKey: ["/purchase-orders", poId], queryFn: () => api<any>(`/purchase-orders/${poId}`), select: (r) => r.data, enabled: !!poId });
  const [h, setH] = useState({ grn_date: istToday(), warehouse_id: "", supplier_invoice_no: "", supplier_invoice_date: "", delivery_challan_no: "", vehicle_no: "", notes: "" });
  const [lines, setLines] = useState<Record<string, L>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  useEffect(() => {
    if (!po.data) return;
    setH((x) => ({ ...x, warehouse_id: po.data.warehouse?.id ?? "" }));
    setLines(Object.fromEntries(po.data.items.filter((i: any) => Number(i.pending_qty) > 0).map((i: any) => [i.id, { accepted: String(Number(i.pending_qty)), rejected: "", reason: "", batch: "", expiry: "", serials: "" }])));
  }, [po.data]);
  const set = (k: keyof typeof h) => (e: { target: { value: string } }) => setH({ ...h, [k]: e.target.value });
  const upd = (id: string, patch: Partial<L>) => setLines({ ...lines, [id]: { ...lines[id], ...patch } });
  const pending = (po.data?.items ?? []).filter((i: any) => Number(i.pending_qty) > 0);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const body: any[] = [];
    for (const it of pending) {
      const l = lines[it.id];
      const a = Number(l?.accepted || 0), r = Number(l?.rejected || 0);
      if (!a && !r) continue;
      if (a > Number(it.pending_qty)) return setError(new Error(`Line ${it.line_no}: only ${it.pending_qty} ${it.unit} are pending.`));
      if (r && !l.reason.trim()) return setError(new Error(`Line ${it.line_no}: give the reason for the rejected quantity.`));
      if (it.serial && a && splitSerials(l.serials).length !== a) return setError(new Error(`Line ${it.line_no}: enter ${a} serial number(s).`));
      if (it.batch && a && !l.batch.trim()) return setError(new Error(`Line ${it.line_no}: enter the batch number.`));
      body.push({ po_line_id: it.id, accepted_qty: String(a), rejected_qty: String(r), rejection_reason: l.reason.trim() || null,
        batch_no: l.batch.trim() || null, expiry_date: l.expiry || null, serial_nos: splitSerials(l.serials) });
    }
    if (!body.length) return setError(new Error("Enter the quantity received on at least one line."));
    setBusy(true);
    try {
      const n = (s: string) => (s.trim() ? s.trim() : null);
      const r = await api<any>("/grns", { body: { purchase_order_id: poId, grn_date: h.grn_date, warehouse_id: h.warehouse_id || null,
        supplier_invoice_no: n(h.supplier_invoice_no), supplier_invoice_date: h.supplier_invoice_date || null,
        delivery_challan_no: n(h.delivery_challan_no), vehicle_no: n(h.vehicle_no), notes: n(h.notes), lines: body } });
      toast(`${r.data.grn_number} saved — stock updated`);
      qc.invalidateQueries({ queryKey: ["/purchase-orders"] });
      qc.invalidateQueries({ queryKey: ["/grns"] });
      qc.invalidateQueries({ queryKey: ["/stock/items"] });
      router.push(`/purchase/grn/view?id=${r.data.id}`);
    } catch (err) { setError(err); window.scrollTo({ top: 0, behavior: "smooth" }); } finally { setBusy(false); }
  }
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Receive goods (GRN)" subtitle={po.data ? `${po.data.po_number} · ${po.data.supplier.name}` : "Choose the purchase order the goods came against."} />
      <form onSubmit={submit} className="space-y-5">
        <ErrorNote error={error} />
        {!poParam && (
          <Card><Field label="Purchase order" required>
            <Select value={poId} onChange={(e) => setPoId(e.target.value)}>
              <option value="">— Choose an open order —</option>
              {(open.data ?? []).map((p) => <option key={p.id} value={p.id}>{p.po_number} · {p.supplier.name}</option>)}
            </Select>
          </Field></Card>
        )}
        {poId && po.isLoading && <Spinner />}
        {po.data && (
          <>
            <Card title="Delivery">
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <Field label="Date received" required><Input type="date" max={istToday()} value={h.grn_date} onChange={set("grn_date")} /></Field>
                <Field label="Received at"><WarehouseSelect value={h.warehouse_id} onChange={(v) => setH({ ...h, warehouse_id: v })} /></Field>
                <Field label="Supplier invoice no."><Input value={h.supplier_invoice_no} onChange={set("supplier_invoice_no")} /></Field>
                <Field label="Invoice date"><Input type="date" value={h.supplier_invoice_date} onChange={set("supplier_invoice_date")} /></Field>
                <Field label="Delivery challan no."><Input value={h.delivery_challan_no} onChange={set("delivery_challan_no")} /></Field>
                <Field label="Vehicle no."><Input value={h.vehicle_no} onChange={set("vehicle_no")} /></Field>
                <Field label="Notes" className="sm:col-span-2"><Input value={h.notes} onChange={set("notes")} /></Field>
              </div>
            </Card>
            <Card title="Items received" padded={false}>
              {pending.length === 0 ? <p className="p-4 text-sm text-ink-500">Everything on this order has been received.</p> : (
                <ul className="divide-y divide-ink-100">
                  {pending.map((it: any) => {
                    const l = lines[it.id] ?? { accepted: "", rejected: "", reason: "", batch: "", expiry: "", serials: "" };
                    return (
                      <li key={it.id} className="space-y-2 p-4">
                        <div className="flex flex-wrap items-baseline justify-between gap-2">
                          <p className="font-medium text-ink-900">{it.line_no}. {it.description}</p>
                          <p className="text-xs text-ink-500">Ordered {qty(it.quantity)} · received {qty(it.received_qty)} · <b>pending {qty(it.pending_qty)} {it.unit}</b>{!it.stocked ? " · not a stock item" : ""}</p>
                        </div>
                        <div className="grid gap-2 sm:grid-cols-4">
                          <Field label="Accepted"><Input inputMode="decimal" className="num" aria-label={`Accepted, line ${it.line_no}`} value={l.accepted} onChange={(e) => upd(it.id, { accepted: e.target.value })} /></Field>
                          <Field label="Rejected"><Input inputMode="decimal" className="num" aria-label={`Rejected, line ${it.line_no}`} value={l.rejected} onChange={(e) => upd(it.id, { rejected: e.target.value })} /></Field>
                          {Number(l.rejected) > 0 && <Field label="Reason for rejection" className="sm:col-span-2"><Input aria-label={`Rejection reason, line ${it.line_no}`} value={l.reason} onChange={(e) => upd(it.id, { reason: e.target.value })} /></Field>}
                          {it.batch && <Field label="Batch no."><Input value={l.batch} onChange={(e) => upd(it.id, { batch: e.target.value })} /></Field>}
                          {it.batch && <Field label="Expiry"><Input type="date" value={l.expiry} onChange={(e) => upd(it.id, { expiry: e.target.value })} /></Field>}
                        </div>
                        {it.serial && it.stocked && (
                          <Field label={`Serial numbers (${splitSerials(l.serials).length} of ${Number(l.accepted) || 0}) — one per line, or scan them in`}>
                            <Textarea rows={2} aria-label={`Serial numbers, line ${it.line_no}`} value={l.serials} onChange={(e) => upd(it.id, { serials: e.target.value })} />
                          </Field>
                        )}
                      </li>
                    );
                  })}
                </ul>
              )}
            </Card>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="secondary" onClick={() => router.back()}>Cancel</Button>
              <Button type="submit" loading={busy} disabled={pending.length === 0}>Save GRN</Button>
            </div>
          </>
        )}
      </form>
    </div>
  );
}

export default function Page() {
  return <Suspense><NewGrn /></Suspense>;
}
