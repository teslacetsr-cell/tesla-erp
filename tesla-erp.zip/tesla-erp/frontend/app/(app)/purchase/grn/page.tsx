"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { PackageCheck, Plus } from "lucide-react";
import { Badge, Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Spinner } from "@/components/ui";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function GrnListPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/grns");
  return (
    <>
      <PageHeader title="Goods received (GRN)" subtitle="What arrived against each purchase order. Accepted quantities enter stock at the order's net rate."
        actions={can("grn.create") && <Link href="/purchase/grn/new"><Button icon={<Plus className="size-4" />}>Receive goods</Button></Link>} />
      <Card padded={false}>
        <div className="border-b border-ink-100 p-3"><Input placeholder="Search GRN, PO, supplier invoice, challan…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" /></div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/purchase/grn/view?id=${r.id}`)}
            empty={<EmptyState icon={<PackageCheck className="size-8" />} title="Nothing received yet" body="Open a purchase order and choose “Receive goods”." />}
            columns={[
              { key: "n", header: "GRN", sortKey: "created_at", cell: (r) => <div><p className="font-medium text-ink-900">{r.grn_number}</p><p className="text-xs text-ink-500">{r.po_number}{r.supplier_invoice_no ? ` · inv. ${r.supplier_invoice_no}` : ""}</p></div> },
              { key: "s", header: "Supplier", cell: (r) => r.supplier.name },
              { key: "w", header: "Received at", hideOnMobile: true, cell: (r) => r.warehouse?.name },
              { key: "d", header: "Date", sortKey: "grn_date", hideOnMobile: true, cell: (r) => date(r.grn_date) },
              { key: "v", header: "Accepted value", sortKey: "value", className: "text-right", cell: (r) => <span className="num">{inr(r.value, 0)}</span> },
              { key: "x", header: "", cell: (r) => r.rejected ? <Badge tone="red">Rejections</Badge> : null },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
