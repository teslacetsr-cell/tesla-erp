"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Download, FileSpreadsheet, FileText, Pencil, Send, Trash2, UserPlus } from "lucide-react";
import { Button, Card, Detail, ErrorNote, PageHeader, Spinner, Tabs, useConfirm, useToast } from "@/components/ui";
import { ReasonDialog } from "@/components/purchase/common";
import { QuoteStatus, RfqStatus } from "@/components/purchase/rfq-common";
import { freshPayload, RfqForm, SupplierChooser } from "@/components/purchase/rfq-form";
import { QuotationCard } from "@/components/purchase/rfq-quotes";
import { ComparisonPanel } from "@/components/purchase/rfq-compare";
import { HistoryPanel } from "@/components/record-panels";
import { api, download } from "@/lib/api/client";
import { date, qty } from "@/lib/format";

type Tab = "lines" | "quotes" | "compare" | "history";

function AddSuppliers({ rfq, onDone }: { rfq: any; onDone: () => void }) {
  const toast = useToast();
  const [chosen, setChosen] = useState<{ id: string; name: string }[]>([]);
  const [fresh, setFresh] = useState<{ supplier_name: string; phone: string; email: string }[]>([]);
  const [busy, setBusy] = useState(false);
  const taken = new Set<string>(rfq.quotations.map((q: any) => q.supplier.id));
  return (
    <Card title="Add suppliers">
      <SupplierChooser chosen={chosen.filter((c) => !taken.has(c.id))} onChosen={setChosen} fresh={fresh} onFresh={setFresh} exclude={[...taken]} emptyText="Got a quotation from a supplier you did not ask? Add them here." />
      {(chosen.length > 0 || fresh.length > 0) && (
        <div className="mt-3 flex justify-end"><Button loading={busy} icon={<UserPlus className="size-4" />} onClick={async () => {
          setBusy(true);
          try {
            for (const c of chosen) if (!taken.has(c.id)) await api(`/rfqs/${rfq.id}/suppliers`, { body: { supplier_id: c.id } });
            for (const f of freshPayload(fresh)) await api(`/rfqs/${rfq.id}/suppliers`, { body: { new_supplier: f } });
            setChosen([]); setFresh([]); toast("Suppliers added"); onDone();
          } catch (e: any) { toast(e.message, "error"); } finally { setBusy(false); }
        }}>Add to this RFQ</Button></div>
      )}
    </Card>
  );
}

function RfqDetail() {
  const params = useSearchParams();
  const id = params.get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [tab, setTab] = useState<Tab>((params.get("tab") as Tab) || "lines");
  const [editing, setEditing] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const key = ["/rfqs", id];
  const { data: rfq, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api<any>(`/rfqs/${id}`), select: (r) => r.data });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/rfqs"] }); };
  if (isLoading) return <Spinner />;
  if (error || !rfq) return <ErrorNote error={error} />;
  const can = rfq.can;
  const fail = (e: any) => toast(e.message, "error");
  async function downloadAll() {
    try {
      await download(`/rfqs/${id}/pdf`, "RFQ-all-suppliers.pdf");
      for (const q of rfq.quotations) await download(`/rfqs/${id}/quotations/${q.id}/template`, `RFQ-${q.supplier.code}.xlsx`);
      refresh();
    } catch (e) { fail(e); }
  }
  if (editing)
    return (
      <div className="mx-auto max-w-5xl">
        <PageHeader title={`Edit ${rfq.display_number}`} />
        <RfqForm initial={rfq} submitLabel="Save" onCancel={() => setEditing(false)} onSubmit={async (body) => {
          await api(`/rfqs/${id}`, { method: "PUT", body: { ...body, row_version: rfq.row_version } });
          toast("Saved"); setEditing(false); refresh();
        }} />
      </div>
    );
  const received = rfq.quotations.filter((q: any) => q.status === "received").length;
  return (
    <>
      <PageHeader back={<Link href="/purchase/rfqs" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Vendor quotations</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{rfq.display_number} <RfqStatus status={rfq.status} /></span>}
        subtitle={`${rfq.purchase_request ? `For ${rfq.purchase_request.number} · ` : rfq.material_request ? `For ${rfq.material_request.number} · ` : ""}${rfq.project ? `${rfq.project.number} · ` : ""}${rfq.quotations.length} supplier(s), ${received} quoted · by ${rfq.created_by}`}
        actions={<>
          {can.send && <Button icon={<Send className="size-4" />} onClick={async () => {
            try { await api(`/rfqs/${id}/send`, { body: { row_version: rfq.row_version } }); toast("Marked as sent to the suppliers"); refresh(); } catch (e) { fail(e); }
          }}>Mark as sent</Button>}
          {can.export && rfq.quotations.length > 0 && <Button variant="secondary" icon={<Download className="size-4" />} onClick={downloadAll}>Download all</Button>}
          {can.edit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {can.cancel && rfq.rfq_number && <Button variant="ghost" onClick={() => setCancelling(true)}>Cancel RFQ</Button>}
          {can.delete && <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Delete this draft RFQ?", body: "It has not been sent or printed.", confirmLabel: "Delete" }))) return;
            try { await api(`/rfqs/${id}`, { method: "DELETE" }); refresh(); router.push("/purchase/rfqs"); } catch (e) { fail(e); }
          }}>Delete</Button>}
        </>} />
      {rfq.status === "cancelled" && rfq.status_reason && <p className="mb-4 rounded-md bg-ink-100 px-3 py-2 text-sm"><b>Cancelled:</b> {rfq.status_reason}</p>}
      <Card className="mb-4">
        <Detail cols={4} items={[
          ["Request", rfq.purchase_request ? <Link key="pr" className="text-brand-700 hover:underline" href={`/purchase/requests/view?id=${rfq.purchase_request.id}`}>{rfq.purchase_request.number}</Link>
            : rfq.material_request ? <Link key="mr" className="text-brand-700 hover:underline" href={`/purchase/material-requests/view?id=${rfq.material_request.id}`}>{rfq.material_request.number}</Link> : "—"],
          ["Quotes due by", date(rfq.due_date)], ["Needed by", date(rfq.required_by)], ["Compare on", rfq.compare_on === "net" ? "Value before GST" : "Value incl. GST"],
          ["Deliver to", rfq.delivery_location ? <span key="d" className="whitespace-pre-line">{rfq.delivery_location}</span> : rfq.warehouse?.name],
          ["Contact", rfq.contact_person], ["Sent", rfq.sent_at ? date(rfq.sent_at) : "—"], ["Terms", rfq.terms],
        ]} />
        {rfq.notes && <p className="mt-3 border-t border-ink-100 pt-3 text-sm">{rfq.notes}</p>}
      </Card>
      <Tabs value={tab} onChange={setTab} tabs={[{ id: "lines", label: "Lines & suppliers", count: rfq.lines.length }, { id: "quotes", label: "Vendor quotations", count: received },
        { id: "compare", label: "Comparison" }, { id: "history", label: "History" }]} />
      {tab === "lines" && (
        <div className="space-y-4">
          <Card padded={false} title="Items to be quoted">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px] text-sm">
                <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
                  <th className="px-3 py-2">#</th><th className="px-3 py-2">Item</th><th className="px-3 py-2">Specification</th><th className="px-3 py-2 text-right">Qty</th><th className="px-3 py-2">Needed by</th></tr></thead>
                <tbody>{rfq.lines.map((l: any) => (
                  <tr key={l.id} className="border-b border-ink-100">
                    <td className="px-3 py-2 text-ink-500">{l.line_no}</td>
                    <td className="px-3 py-2"><p className="text-ink-900">{l.description}</p><p className="text-xs text-ink-500">{l.item_code ?? "Free text"}</p></td>
                    <td className="px-3 py-2 text-xs text-ink-600">{l.specification ?? "—"}</td>
                    <td className="num px-3 py-2 text-right font-medium">{qty(l.quantity)} {l.unit}</td>
                    <td className="px-3 py-2">{date(l.required_by)}</td>
                  </tr>))}</tbody>
              </table>
            </div>
          </Card>
          <Card padded={false} title="Suppliers asked to quote">
            {rfq.quotations.length === 0 ? <p className="p-4 text-sm text-ink-500">No suppliers yet.{can.edit ? " Use Edit or add them below." : ""}</p> : (
              <ul className="divide-y divide-ink-100">{rfq.quotations.map((q: any) => (
                <li key={q.id} className="flex flex-col gap-2 px-4 py-2.5 sm:flex-row sm:items-center">
                  <div className="min-w-0 flex-1"><p className="flex items-center gap-2 text-sm font-medium text-ink-900">{q.supplier.name} <QuoteStatus status={q.status} /></p>
                    <p className="text-xs text-ink-500">{[q.supplier.code, q.supplier.phone, q.supplier.email].filter(Boolean).join(" · ")}</p></div>
                  {can.export && <div className="flex gap-1.5">
                    <Button size="sm" variant="secondary" icon={<FileText className="size-3.5" />} onClick={() => download(`/rfqs/${id}/pdf`, `RFQ-${q.supplier.code}.pdf`, { quotation_id: q.id }).then(refresh).catch(fail)}>PDF</Button>
                    <Button size="sm" variant="secondary" icon={<FileSpreadsheet className="size-3.5" />} onClick={() => download(`/rfqs/${id}/quotations/${q.id}/template`, `RFQ-${q.supplier.code}.xlsx`).then(refresh).catch(fail)}>Excel form</Button>
                  </div>}
                </li>))}</ul>
            )}
            {can.export && rfq.quotations.length > 0 && <p className="border-t border-ink-100 px-4 py-2 text-xs text-ink-500">Send each supplier the PDF letter and the Excel form. When they fill the form and send it back, upload it on the Vendor quotations tab — the rates are read automatically.</p>}
          </Card>
          {can.add_supplier && !can.edit && <AddSuppliers rfq={rfq} onDone={refresh} />}
        </div>
      )}
      {tab === "quotes" && (
        <div className="space-y-4">
          {rfq.quotations.map((q: any) => <QuotationCard key={q.id} rfq={rfq} q={q} onChanged={refresh} />)}
          {can.add_supplier && <AddSuppliers rfq={rfq} onDone={refresh} />}
        </div>
      )}
      {tab === "compare" && <ComparisonPanel rfq={rfq} onChanged={refresh} />}
      {tab === "history" && <HistoryPanel entityType="rfq" entityId={id} />}
      <ReasonDialog open={cancelling} title="Cancel this RFQ" label="Why is it cancelled?" required confirmLabel="Cancel RFQ" onClose={() => setCancelling(false)}
        onSubmit={async (reason) => { await api(`/rfqs/${id}/cancel`, { body: { reason, row_version: rfq.row_version } }); toast("Cancelled"); refresh(); }} />
    </>
  );
}

export default function Page() {
  return <Suspense><RfqDetail /></Suspense>;
}
