"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Plus, Scale } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { RFQ_STATUSES, RfqStatus } from "@/components/purchase/rfq-common";
import { useAuth } from "@/lib/auth";
import { date } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function RfqsPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/rfqs", { filters: { open_only: "true" } });
  const statusValue = list.filters.status || (list.filters.open_only === "true" ? "_open" : "");
  const setStatus = (v: string) => { list.setFilter("open_only", v === "_open" ? "true" : ""); list.setFilter("status", v.startsWith("_") ? "" : v); };
  return (
    <>
      <PageHeader title="Vendor quotations" subtitle="Ask several suppliers for rates, record their quotations, compare and order from the best."
        actions={can("rfq.create") && <Link href="/purchase/rfqs/new"><Button icon={<Plus className="size-4" />}>New RFQ</Button></Link>} />
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search RFQ, PR / MR number, supplier or item…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={statusValue} onChange={(e) => setStatus(e.target.value)} className="sm:w-52" aria-label="Status">
            <option value="_open">Open</option><option value="">All statuses</option>
            {RFQ_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/purchase/rfqs/view?id=${r.id}`)}
            empty={<EmptyState icon={<Scale className="size-8" />} title="No requests for quotation here" body="Use “Get vendor quotations” on a purchase request or material request, or start a new RFQ." />}
            columns={[
              { key: "n", header: "RFQ", sortKey: "created_at", cell: (r) => <div><p className="font-medium text-ink-900">{r.display_number}</p><p className="text-xs text-ink-500">{r.lines_count} item(s) · {r.created_by}</p></div> },
              { key: "src", header: "For", cell: (r) => r.purchase_request?.number ?? r.material_request?.number ?? (r.project ? r.project.number : "—") },
              { key: "s", header: "Suppliers", hideOnMobile: true, cell: (r) => <div className="max-w-xs"><p className="truncate">{r.suppliers.join(", ") || "—"}</p><p className="text-xs text-ink-500">{r.received_count} of {r.suppliers.length} quoted</p></div> },
              { key: "d", header: "Quotes due", sortKey: "due_date", hideOnMobile: true, cell: (r) => date(r.due_date) },
              { key: "st", header: "Status", sortKey: "status", cell: (r) => <RfqStatus status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
