"use client";

import { useRouter } from "next/navigation";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader, useToast } from "@/components/ui";
import { RfqForm } from "@/components/purchase/rfq-form";
import { api } from "@/lib/api/client";

export default function NewRfqPage() {
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="New request for quotation" subtitle="To quote from a purchase or material request, open it and use “Get vendor quotations”." />
      <RfqForm submitLabel="Save draft" onCancel={() => router.back()} onSubmit={async (body) => {
        const r = await api<any>("/rfqs", { body });
        toast("Draft RFQ saved");
        qc.invalidateQueries({ queryKey: ["/rfqs"] });
        router.push(`/purchase/rfqs/view?id=${r.data.id}`);
      }} />
    </div>
  );
}
