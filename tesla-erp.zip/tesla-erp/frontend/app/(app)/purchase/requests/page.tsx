"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FileText, Plus } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { PR_STATUSES, PrStatus } from "@/components/purchase/common";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function PurchaseRequestsPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/purchase-requests", { filters: { open_only: "true" } });
  const statusValue = list.filters.status || (list.filters.open_only === "true" ? "_open" : "");
  const setStatus = (v: string) => { list.setFilter("open_only", v === "_open" ? "true" : ""); list.setFilter("status", v.startsWith("_") ? "" : v); };
  return (
    <>
      <PageHeader title="Purchase requests" subtitle="Requests to buy, approved before orders are placed."
        actions={can("purchase_request.create") && <Link href="/purchase/requests/new"><Button icon={<Plus className="size-4" />}>New request</Button></Link>} />
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search number or notes…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={statusValue} onChange={(e) => setStatus(e.target.value)} className="sm:w-52" aria-label="Status">
            <option value="_open">Open requests</option><option value="">All statuses</option>
            {PR_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/purchase/requests/view?id=${r.id}`)}
            empty={<EmptyState icon={<FileText className="size-8" />} title="No purchase requests here" body="Create one from a material request, or directly." />}
            columns={[
              { key: "n", header: "Request", sortKey: "created_at", cell: (r) => <div><p className="font-medium text-ink-900">{r.pr_number ?? "Draft"}</p><p className="text-xs text-ink-500">{r.lines_count} item(s) · {r.created_by}</p></div> },
              { key: "p", header: "Project", cell: (r) => r.project ? r.project.number : "—" },
              { key: "d", header: "Needed by", hideOnMobile: true, cell: (r) => date(r.required_by) },
              { key: "v", header: "Estimated", sortKey: "estimated_value", className: "text-right", cell: (r) => <span className="num">{inr(r.estimated_value, 0)}</span> },
              { key: "s", header: "Status", sortKey: "status", cell: (r) => <PrStatus status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
