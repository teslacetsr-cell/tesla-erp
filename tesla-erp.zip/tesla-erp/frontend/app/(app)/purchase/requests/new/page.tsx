"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { PageHeader, Spinner, useToast } from "@/components/ui";
import { PurchaseRequestForm } from "@/components/purchase/pr-form";
import { api } from "@/lib/api/client";

function NewPr() {
  const mrId = useSearchParams().get("mr");
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const mr = useQuery({ queryKey: ["/material-requests", mrId], queryFn: () => api<any>(`/material-requests/${mrId}`), select: (r) => r.data, enabled: !!mrId });
  if (mrId && mr.isLoading) return <Spinner />;
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="New purchase request" subtitle={mr.data ? `From material request ${mr.data.mr_number}` : "Save as draft, then submit for approval."} />
      <PurchaseRequestForm prefill={mr.data ? { mr: mr.data } : null} submitLabel="Save draft" onCancel={() => router.back()} onSubmit={async (body) => {
        const r = await api<any>("/purchase-requests", { body });
        toast("Draft saved");
        qc.invalidateQueries({ queryKey: ["/purchase-requests"] });
        qc.invalidateQueries({ queryKey: ["/material-requests"] });
        router.push(`/purchase/requests/view?id=${r.data.id}`);
      }} />
    </div>
  );
}

export default function Page() {
  return <Suspense><NewPr /></Suspense>;
}
