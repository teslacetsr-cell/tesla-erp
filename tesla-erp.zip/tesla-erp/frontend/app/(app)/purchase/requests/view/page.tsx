"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, CheckCircle2, FilePlus2, Pencil, ShieldCheck, Trash2, Undo2 } from "lucide-react";
import { Button, Card, Detail, ErrorNote, PageHeader, Spinner, Tabs, useConfirm, useToast } from "@/components/ui";
import { PriorityBadge } from "@/components/crm/common";
import { ApprovalCard, ApprovalHistory, PoStatus, PrStatus, ReasonDialog } from "@/components/purchase/common";
import { PurchaseRequestForm } from "@/components/purchase/pr-form";
import { GetQuotesButton, RfqLinks } from "@/components/purchase/rfq-common";
import { HistoryPanel } from "@/components/record-panels";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr, qty } from "@/lib/format";

function PrDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const auth = useAuth();
  const [tab, setTab] = useState<"items" | "approvals" | "history">("items");
  const [editing, setEditing] = useState(false);
  const [dialog, setDialog] = useState<"close" | null>(null);
  const key = ["/purchase-requests", id];
  const { data: pr, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api<any>(`/purchase-requests/${id}`), select: (r) => r.data });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/purchase-requests"] }); qc.invalidateQueries({ queryKey: ["/approvals/inbox"] }); };
  if (isLoading) return <Spinner />;
  if (error || !pr) return <ErrorNote error={error} />;
  const can = pr.can;
  async function act(path: string, body: any = {}, msg?: string) {
    try {
      const r = await api<any>(`/purchase-requests/${id}/${path}`, { body: { row_version: pr.row_version, ...body } });
      if (msg) toast(typeof msg === "string" ? msg : ""); refresh(); return r.data;
    } catch (e: any) { toast(e.message, "error"); }
  }
  if (editing)
    return (
      <div className="mx-auto max-w-5xl">
        <PageHeader title={`Edit ${pr.pr_number ?? "draft purchase request"}`} />
        <PurchaseRequestForm initial={pr} submitLabel="Save" onCancel={() => setEditing(false)} onSubmit={async (body) => {
          await api(`/purchase-requests/${id}`, { method: "PUT", body: { ...body, row_version: pr.row_version } });
          toast("Saved"); setEditing(false); refresh();
        }} />
      </div>
    );
  return (
    <>
      <PageHeader back={<Link href="/purchase/requests" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Purchase requests</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{pr.pr_number ?? "Draft purchase request"} <PrStatus status={pr.status} /> <PriorityBadge priority={pr.priority} /></span>}
        subtitle={`${pr.project ? `${pr.project.number} · ${pr.project.name} · ` : ""}estimated ${inr(pr.estimated_value, 0)} · by ${pr.created_by}`}
        actions={<>
          {can.submit && <Button icon={<ShieldCheck className="size-4" />} onClick={async () => {
            const r = await act("submit");
            if (r) toast(r.status === "approved" ? "Approved — no approval rule applies" : "Sent for approval");
          }}>Submit</Button>}
          {auth.can("rfq.create") && ["pending_approval", "approved", "partially_ordered"].includes(pr.status) && <GetQuotesButton source="pr" id={pr.id} />}
          {can.create_po && <Link href={`/purchase/orders/new?pr=${pr.id}`}><Button icon={<FilePlus2 className="size-4" />}>Create purchase order</Button></Link>}
          {can.edit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {can.withdraw && <Button variant="secondary" icon={<Undo2 className="size-4" />} onClick={() => act("withdraw", {}, "Back to draft")}>Withdraw</Button>}
          {can.close && <Button variant="secondary" icon={<CheckCircle2 className="size-4" />} onClick={() => setDialog("close")}>Close</Button>}
          {can.cancel && pr.pr_number && <Button variant="ghost" onClick={async () => { if (await confirm({ title: "Cancel this purchase request?", body: "Material request lines on it become open again.", confirmLabel: "Cancel request" })) act("cancel", {}, "Cancelled"); }}>Cancel</Button>}
          {can.delete && <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Delete this draft?", body: "Material request lines on it become open again.", confirmLabel: "Delete" }))) return;
            await api(`/purchase-requests/${id}`, { method: "DELETE" }); refresh(); router.push("/purchase/requests");
          }}>Delete</Button>}
        </>} />
      <ApprovalCard approval={pr.approval} onDone={refresh} />
      {pr.last_rejection && pr.status === "draft" && <p className="mb-4 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900"><b>Returned by the approver:</b> {pr.last_rejection}</p>}
      {pr.status_reason && pr.status === "closed" && <p className="mb-4 rounded-md bg-ink-100 px-3 py-2 text-sm"><b>Closed:</b> {pr.status_reason}</p>}
      <Card className="mb-4">
        <Detail cols={4} items={[["Project", pr.project ? <Link key="p" href={`/projects/view?id=${pr.project.id}`} className="text-brand-700 hover:underline">{pr.project.number}</Link> : "—"],
          ["Deliver to", pr.warehouse?.name], ["Needed by", date(pr.required_by)], ["Approved", pr.approved_at ? date(pr.approved_at) : "—"]]} />
        {pr.notes && <p className="mt-3 border-t border-ink-100 pt-3 text-sm">{pr.notes}</p>}
      </Card>
      <Tabs value={tab} onChange={setTab} tabs={[{ id: "items", label: "Items", count: pr.lines.length }, { id: "approvals", label: "Approvals", count: pr.approvals.length }, { id: "history", label: "History" }]} />
      {tab === "items" && (
        <div className="space-y-4">
          <Card padded={false}>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] text-sm">
                <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
                  <th className="px-3 py-2">#</th><th className="px-3 py-2">Item</th><th className="px-3 py-2 text-right">Qty</th><th className="px-3 py-2 text-right">Est. rate</th>
                  <th className="px-3 py-2 text-right">Est. amount</th><th className="px-3 py-2 text-right">Ordered</th><th className="px-3 py-2">Supplier</th></tr></thead>
                <tbody>{pr.lines.map((l: any) => (
                  <tr key={l.id} className="border-b border-ink-100">
                    <td className="px-3 py-2 text-ink-500">{l.line_no}</td>
                    <td className="px-3 py-2"><p className="text-ink-900">{l.description}</p><p className="text-xs text-ink-500">{l.item_code ?? "Free text"}{l.mr_number ? ` · from ${l.mr_number}` : ""}{l.stock_total !== null ? ` · ${qty(l.stock_total)} in stock` : ""}</p></td>
                    <td className="num px-3 py-2 text-right font-medium">{qty(l.quantity)} {l.unit}</td>
                    <td className="num px-3 py-2 text-right">{inr(l.estimated_rate)}</td>
                    <td className="num px-3 py-2 text-right">{inr(l.estimated_amount)}</td>
                    <td className="num px-3 py-2 text-right">{qty(l.ordered_qty)}</td>
                    <td className="px-3 py-2 text-ink-600">{l.suggested_supplier ?? "—"}</td>
                  </tr>))}</tbody>
              </table>
            </div>
          </Card>
          <RfqLinks source="pr" id={pr.id} />
          {pr.purchase_orders.length > 0 && (
            <Card title="Purchase orders">
              <ul className="space-y-1 text-sm">{pr.purchase_orders.map((p: any) => <li key={p.id} className="flex items-center gap-2"><Link href={`/purchase/orders/view?id=${p.id}`} className="text-brand-700 hover:underline">{p.po_number ?? "Draft PO"}</Link><PoStatus status={p.status} /></li>)}</ul>
            </Card>
          )}
        </div>
      )}
      {tab === "approvals" && <ApprovalHistory approvals={pr.approvals} />}
      {tab === "history" && <HistoryPanel entityType="purchase_request" entityId={id} />}
      <ReasonDialog open={dialog === "close"} title="Close this purchase request" label="Why will the rest not be ordered?" required confirmLabel="Close"
        onClose={() => setDialog(null)} onSubmit={async (reason) => { await act("close", { reason }, "Closed"); }} />
    </>
  );
}

export default function Page() {
  return <Suspense><PrDetail /></Suspense>;
}
