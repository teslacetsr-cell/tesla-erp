"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, CheckCircle2, FilePlus2, Pencil, Send, Trash2, XCircle } from "lucide-react";
import { Button, Card, Detail, ErrorNote, PageHeader, Spinner, Tabs, useConfirm, useToast } from "@/components/ui";
import { PriorityBadge } from "@/components/crm/common";
import { MrStatus, PrStatus, ReasonDialog } from "@/components/purchase/common";
import { MaterialRequestForm } from "@/components/purchase/mr-form";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api } from "@/lib/api/client";
import { date, dateTime, qty } from "@/lib/format";

function MrDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [tab, setTab] = useState<"items" | "documents" | "history">("items");
  const [editing, setEditing] = useState(false);
  const [dialog, setDialog] = useState<"reject" | "close" | null>(null);
  const key = ["/material-requests", id];
  const { data: mr, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api<any>(`/material-requests/${id}`), select: (r) => r.data });
  const refresh = () => qc.invalidateQueries({ queryKey: ["/material-requests"] });
  if (isLoading) return <Spinner />;
  if (error || !mr) return <ErrorNote error={error} />;
  const can = mr.can;
  async function act(path: string, body: any = {}, msg?: string) {
    try { await api(`/material-requests/${id}/${path}`, { body }); if (msg) toast(msg); refresh(); } catch (e: any) { toast(e.message, "error"); }
  }
  if (editing)
    return (
      <div className="mx-auto max-w-5xl">
        <PageHeader title="Edit material request" />
        <MaterialRequestForm initial={mr} submitLabel="Save" onCancel={() => setEditing(false)} onSubmit={async (body) => {
          await api(`/material-requests/${id}`, { method: "PUT", body: { ...body, row_version: mr.row_version } });
          toast("Saved"); setEditing(false); refresh();
        }} />
      </div>
    );
  return (
    <>
      <PageHeader back={<Link href="/purchase/material-requests" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Material requests</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{mr.mr_number ?? "Draft material request"} <MrStatus status={mr.status} /> <PriorityBadge priority={mr.priority} /></span>}
        subtitle={`${mr.project ? `${mr.project.number} · ${mr.project.name}` : "Store stock"} · requested by ${mr.requested_by}`}
        actions={<>
          {can.submit && <Button icon={<Send className="size-4" />} onClick={() => act("submit", {}, "Submitted — the store and purchase team are notified")}>Submit</Button>}
          {can.create_pr && <Link href={`/purchase/requests/new?mr=${mr.id}`}><Button icon={<FilePlus2 className="size-4" />}>Create purchase request</Button></Link>}
          {can.edit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {can.close && <Button variant="secondary" icon={<CheckCircle2 className="size-4" />} onClick={() => setDialog("close")}>Close</Button>}
          {can.reject && <Button variant="ghost" icon={<XCircle className="size-4" />} onClick={() => setDialog("reject")}>Reject</Button>}
          {can.cancel && mr.mr_number && <Button variant="ghost" onClick={async () => { if (await confirm({ title: "Cancel this request?", body: "The store and purchase team will no longer act on it.", confirmLabel: "Cancel request" })) act("cancel", {}, "Request cancelled"); }}>Cancel request</Button>}
          {can.delete && <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Delete this draft?", body: "It has not been submitted.", confirmLabel: "Delete" }))) return;
            await api(`/material-requests/${id}`, { method: "DELETE" }); refresh(); router.push("/purchase/material-requests");
          }}>Delete</Button>}
        </>} />
      {mr.status_reason && ["rejected", "closed"].includes(mr.status) && <p className="mb-4 rounded-md bg-ink-100 px-3 py-2 text-sm"><b>{mr.status === "rejected" ? "Rejected" : "Closed"}:</b> {mr.status_reason}</p>}
      <Card className="mb-4">
        <Detail cols={4} items={[
          ["Project", mr.project ? <Link key="p" href={`/projects/view?id=${mr.project.id}`} className="text-brand-700 hover:underline">{mr.project.number}</Link> : "—"],
          ["Deliver to", mr.warehouse?.name], ["Needed by", date(mr.required_by)], ["Submitted", mr.submitted_at ? dateTime(mr.submitted_at) : "—"],
        ]} />
        {mr.purpose && <p className="mt-3 border-t border-ink-100 pt-3 text-sm">{mr.purpose}</p>}
      </Card>
      <Tabs value={tab} onChange={setTab} tabs={[{ id: "items", label: "Items", count: mr.lines.length }, { id: "documents", label: "Documents" }, { id: "history", label: "History" }]} />
      {tab === "items" && (
        <div className="space-y-4">
          <Card padded={false}>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] text-sm">
                <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
                  <th className="px-3 py-2">#</th><th className="px-3 py-2">Item</th><th className="px-3 py-2 text-right">Requested</th><th className="px-3 py-2 text-right">On purchase requests</th>
                  <th className="px-3 py-2 text-right">In stock (all stores)</th><th className="px-3 py-2 text-right">At delivery store</th><th className="px-3 py-2">BOQ line</th></tr></thead>
                <tbody>{mr.lines.map((l: any) => (
                  <tr key={l.id} className="border-b border-ink-100">
                    <td className="px-3 py-2 text-ink-500">{l.line_no}</td>
                    <td className="px-3 py-2"><p className="text-ink-900">{l.description}</p><p className="text-xs text-ink-500">{l.item_code ?? "Free text"}{l.remarks ? ` · ${l.remarks}` : ""}</p></td>
                    <td className="num px-3 py-2 text-right font-medium">{qty(l.quantity)} {l.unit}</td>
                    <td className="num px-3 py-2 text-right">{qty(l.processed_qty)}</td>
                    <td className={`num px-3 py-2 text-right ${l.stock_total && Number(l.stock_total) >= Number(l.quantity) ? "text-emerald-700" : ""}`}>{l.stock_total !== null ? qty(l.stock_total) : "—"}</td>
                    <td className="num px-3 py-2 text-right">{l.stock_here !== null ? qty(l.stock_here) : "—"}</td>
                    <td className="px-3 py-2 text-ink-600">{l.boq_line_no ?? "—"}</td>
                  </tr>))}</tbody>
              </table>
            </div>
            <p className="border-t border-ink-100 px-3 py-2 text-xs text-ink-500">If the stock is already in a store, transfer it to site instead of buying (Inventory → Transfers). Issues to projects arrive in Phase 6.</p>
          </Card>
          {mr.purchase_requests.length > 0 && (
            <Card title="Purchase requests">
              <ul className="space-y-1 text-sm">{mr.purchase_requests.map((p: any) => <li key={p.id} className="flex items-center gap-2"><Link href={`/purchase/requests/view?id=${p.id}`} className="text-brand-700 hover:underline">{p.pr_number ?? "Draft PR"}</Link><PrStatus status={p.status} /></li>)}</ul>
            </Card>
          )}
        </div>
      )}
      {tab === "documents" && <DocumentsPanel entityType="material_request" entityId={id} canEdit={can.edit} defaultCategory="other" />}
      {tab === "history" && <HistoryPanel entityType="material_request" entityId={id} />}
      <ReasonDialog open={dialog === "reject"} title="Reject this request" label="Reason (the requester is told)" required confirmLabel="Reject"
        onClose={() => setDialog(null)} onSubmit={async (reason) => { await act("reject", { reason }, "Request rejected"); }} />
      <ReasonDialog open={dialog === "close"} title="Close this request" label="Reason, e.g. “Supplied from the main store”" required confirmLabel="Close request"
        onClose={() => setDialog(null)} onSubmit={async (reason) => { await act("close", { reason }, "Request closed"); }} />
    </>
  );
}

export default function Page() {
  return <Suspense><MrDetail /></Suspense>;
}
