"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { ClipboardList, Plus } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { PriorityBadge } from "@/components/crm/common";
import { MR_STATUSES, MrStatus } from "@/components/purchase/common";
import { useAuth } from "@/lib/auth";
import { date } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function MaterialRequestsPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/material-requests", { filters: { open_only: "true" } });
  const statusValue = list.filters.status || (list.filters.open_only === "true" ? "_open" : "");
  const setStatus = (v: string) => { list.setFilter("open_only", v === "_open" ? "true" : ""); list.setFilter("status", v.startsWith("_") ? "" : v); };
  return (
    <>
      <PageHeader title="Material requests" subtitle="What the site or store needs. Purchase turns them into purchase requests."
        actions={can("material_request.create") && <Link href="/purchase/material-requests/new"><Button icon={<Plus className="size-4" />}>New request</Button></Link>} />
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search number, project, purpose…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={statusValue} onChange={(e) => setStatus(e.target.value)} className="sm:w-52" aria-label="Status">
            <option value="_open">Open requests</option><option value="">All statuses</option>
            {MR_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/purchase/material-requests/view?id=${r.id}`)}
            empty={<EmptyState icon={<ClipboardList className="size-8" />} title="No material requests here" body="Site engineers raise them from a project, or create one here." />}
            columns={[
              { key: "n", header: "Request", sortKey: "created_at", cell: (r) => <div><p className="font-medium text-ink-900">{r.mr_number ?? "Draft"}</p><p className="text-xs text-ink-500">{r.lines_count} item(s){r.purpose ? ` · ${r.purpose.slice(0, 50)}` : ""}</p></div> },
              { key: "p", header: "Project", cell: (r) => r.project ? `${r.project.number} · ${r.project.name}` : "Store" },
              { key: "b", header: "Requested by", hideOnMobile: true, cell: (r) => r.requested_by },
              { key: "d", header: "Needed by", sortKey: "required_by", hideOnMobile: true, cell: (r) => <span className="flex items-center gap-1.5">{date(r.required_by)} <PriorityBadge priority={r.priority} /></span> },
              { key: "s", header: "Status", sortKey: "status", cell: (r) => <MrStatus status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
