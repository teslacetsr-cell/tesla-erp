"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader, useToast } from "@/components/ui";
import { MaterialRequestForm } from "@/components/purchase/mr-form";
import { api } from "@/lib/api/client";

function NewMr() {
  const project = useSearchParams().get("project");
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="New material request" subtitle="Save as draft, then submit — the store and purchase team are notified." />
      <MaterialRequestForm projectId={project} submitLabel="Save draft" onCancel={() => router.back()} onSubmit={async (body) => {
        const r = await api<any>("/material-requests", { body });
        toast("Draft saved");
        qc.invalidateQueries({ queryKey: ["/material-requests"] });
        router.push(`/purchase/material-requests/view?id=${r.data.id}`);
      }} />
    </div>
  );
}

export default function Page() {
  return <Suspense><NewMr /></Suspense>;
}
