"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, CheckCircle2, FileDown, PackageCheck, Pencil, Send, ShieldCheck, Trash2, Undo2, XCircle } from "lucide-react";
import { Badge, Button, Card, Detail, ErrorNote, PageHeader, Spinner, Tabs, useConfirm, useToast } from "@/components/ui";
import { TotalsBox } from "@/components/lines-editor";
import { ApprovalCard, ApprovalHistory, PoStatus, ReasonDialog } from "@/components/purchase/common";
import { PurchaseOrderForm } from "@/components/purchase/po-form";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api, download } from "@/lib/api/client";
import { date, dateTime, inr, qty } from "@/lib/format";
import { useAuth } from "@/lib/auth";

type Tab = "order" | "receipts" | "approvals" | "documents" | "history";

function PoDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [tab, setTab] = useState<Tab>("order");
  const [editing, setEditing] = useState(false);
  const [dialog, setDialog] = useState<"cancel" | "close" | null>(null);
  const key = ["/purchase-orders", id];
  const mayBill = useAuth().can("supplier_invoice.create");
  const { data: po, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api<any>(`/purchase-orders/${id}`), select: (r) => r.data });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/purchase-orders"] }); qc.invalidateQueries({ queryKey: ["/purchase-orders/summary"] }); qc.invalidateQueries({ queryKey: ["/approvals/inbox"] }); };
  if (isLoading) return <Spinner />;
  if (error || !po) return <ErrorNote error={error} />;
  const can = po.can;
  const pdfName = `${(po.po_number ?? "DRAFT-PO").replaceAll("/", "-")}.pdf`;
  async function act(path: string, body: any = {}, msg?: string) {
    try {
      const r = await api<any>(`/purchase-orders/${id}/${path}`, { body: { row_version: po.row_version, ...body } });
      if (msg) toast(msg); refresh(); return r.data;
    } catch (e: any) { toast(e.message, "error"); }
  }
  if (editing)
    return (
      <div className="mx-auto max-w-6xl">
        <PageHeader title={`Edit ${po.display_number} purchase order`} />
        <PurchaseOrderForm initial={po} submitLabel="Save draft" onCancel={() => setEditing(false)} onSubmit={async (body) => {
          await api(`/purchase-orders/${id}`, { method: "PUT", body: { ...body, row_version: po.row_version } });
          toast("Saved"); setEditing(false); refresh();
        }} />
      </div>
    );
  return (
    <>
      <PageHeader back={<Link href="/purchase/orders" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Purchase orders</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{po.supplier.name} <PoStatus status={po.status} /></span>}
        subtitle={`${po.display_number}${po.project ? ` · ${po.project.number} ${po.project.name}` : ""} · deliver to ${po.warehouse?.name}`}
        actions={<>
          {can.submit && <Button icon={<ShieldCheck className="size-4" />} onClick={async () => {
            const r = await act("submit");
            if (r) toast(r.status === "approved" ? `${r.po_number} approved — below the approval limit` : `${r.po_number} sent for approval`);
          }}>Submit</Button>}
          {can.send && <Button icon={<Send className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Mark as sent to the supplier?", body: "Download the PDF and email it to the supplier. The order then waits for delivery.", confirmLabel: "Mark as sent" }))) return;
            const r = await act("send", {}, "Marked as sent");
            if (r) download(`/purchase-orders/${id}/pdf`, pdfName);
          }}>Mark as sent</Button>}
          {can.receive && <Link href={`/purchase/grn/new?po=${po.id}`}><Button icon={<PackageCheck className="size-4" />}>Receive goods (GRN)</Button></Link>}
          {mayBill && po.grns.length > 0 && <Link href={`/finance/bills/new?po=${po.id}`}><Button variant="secondary">Enter supplier bill</Button></Link>}
          {can.edit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {can.print && <Button variant="secondary" icon={<FileDown className="size-4" />} onClick={() => download(`/purchase-orders/${id}/pdf`, pdfName)}>PDF</Button>}
          {can.withdraw && <Button variant="secondary" icon={<Undo2 className="size-4" />} onClick={() => act("withdraw", {}, "Back to draft")}>Withdraw</Button>}
          {can.close && <Button variant="secondary" icon={<CheckCircle2 className="size-4" />} onClick={() => setDialog("close")}>Short-close</Button>}
          {can.cancel && po.po_number && <Button variant="ghost" icon={<XCircle className="size-4" />} onClick={() => setDialog("cancel")}>Cancel</Button>}
          {can.delete && <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Delete this draft?", body: "Purchase request lines on it become open again.", confirmLabel: "Delete" }))) return;
            await api(`/purchase-orders/${id}`, { method: "DELETE" }); refresh(); router.push("/purchase/orders");
          }}>Delete</Button>}
        </>} />
      <ApprovalCard approval={po.approval} onDone={refresh} />
      {po.last_rejection && po.status === "draft" && <p className="mb-4 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900"><b>Returned by the approver:</b> {po.last_rejection}</p>}
      {po.status_reason && ["cancelled", "closed"].includes(po.status) && <p className="mb-4 rounded-md bg-ink-100 px-3 py-2 text-sm"><b>{po.status === "closed" ? "Short-closed" : "Cancelled"}:</b> {po.status_reason}</p>}
      <div className="mb-4 grid gap-4 lg:grid-cols-[1fr_320px]">
        <Card>
          <Detail cols={4} items={[
            ["Supplier", <Link key="s" href={`/suppliers/view?id=${po.supplier.id}`} className="text-brand-700 hover:underline">{po.supplier.name}</Link>],
            ["Kind attention", po.contact], ["PO date", date(po.po_date)], ["Delivery by", date(po.expected_delivery)],
            ["Project", po.project ? <Link key="p" href={`/projects/view?id=${po.project.id}`} className="text-brand-700 hover:underline">{po.project.number}</Link> : "—"],
            ["Deliver to", po.warehouse?.name], ["Supplier quote", po.supplier_quote_ref], ["GST", po.inter_state ? "IGST (inter-state)" : "CGST + SGST"],
          ]} />
        </Card>
        <Card>
          <p className="text-xs uppercase tracking-wide text-ink-500">PO value</p>
          <p className="num mt-1 text-3xl font-semibold text-ink-900">{inr(po.grand_total, 0)}</p>
          <p className="mt-1 text-sm text-ink-500">{inr(po.taxable, 0)} before GST</p>
          {po.sent_at && <p className="mt-2"><Badge tone="blue">Sent {dateTime(po.sent_at)}</Badge></p>}
        </Card>
      </div>
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[{ id: "order", label: "Order" }, { id: "receipts", label: "Receipts", count: po.grns.length },
        { id: "approvals", label: "Approvals", count: po.approvals.length }, { id: "documents", label: "Documents" }, { id: "history", label: "History" }]} />
      {tab === "order" && (
        <div className="space-y-4">
          <Card padded={false}>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[860px] text-sm">
                <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
                  <th className="px-3 py-2">#</th><th className="px-3 py-2">Item</th><th className="px-3 py-2 text-right">Qty</th><th className="px-3 py-2 text-right">Rate</th>
                  <th className="px-3 py-2 text-right">Disc %</th><th className="px-3 py-2 text-right">GST %</th><th className="px-3 py-2 text-right">Amount</th>
                  <th className="px-3 py-2 text-right">Received</th><th className="px-3 py-2 text-right">Rejected</th><th className="px-3 py-2 text-right">Pending</th></tr></thead>
                <tbody>{po.items.map((l: any) => (
                  <tr key={l.id} className="border-b border-ink-100 align-top">
                    <td className="px-3 py-2 text-ink-500">{l.line_no}</td>
                    <td className="px-3 py-2"><p className="text-ink-900">{l.description}</p><p className="text-xs text-ink-500">{[l.item_code, l.hsn_sac && `HSN ${l.hsn_sac}`, l.pr_number && `from ${l.pr_number}`, !l.stocked && l.item_id && "service"].filter(Boolean).join(" · ")}</p></td>
                    <td className="num px-3 py-2 text-right">{qty(l.quantity)} {l.unit}</td>
                    <td className="num px-3 py-2 text-right">{inr(l.rate)}</td>
                    <td className="num px-3 py-2 text-right">{Number(l.discount_pct) || ""}</td>
                    <td className="num px-3 py-2 text-right">{Number(l.tax_rate)}</td>
                    <td className="num px-3 py-2 text-right font-medium">{inr(l.taxable)}</td>
                    <td className="num px-3 py-2 text-right text-emerald-700">{qty(l.received_qty)}</td>
                    <td className={`num px-3 py-2 text-right ${Number(l.rejected_qty) ? "text-brand-700" : "text-ink-400"}`}>{qty(l.rejected_qty)}</td>
                    <td className="num px-3 py-2 text-right font-medium">{qty(l.pending_qty)}</td>
                  </tr>))}</tbody>
              </table>
            </div>
            <div className="border-t border-ink-100 p-4">
              <TotalsBox interState={po.inter_state} taxSummary={po.tax_summary}
                t={{ gross: po.gross, lineDiscount: po.line_discount, special: po.special_discount, taxable: po.taxable, cgst: po.cgst, sgst: po.sgst, igst: po.igst, roundOff: po.round_off, grand: po.grand_total }} />
            </div>
          </Card>
          <div className="grid gap-4 lg:grid-cols-2">
            <Card title="Commercial terms"><Detail cols={2} items={[["Payment", po.payment_terms], ["Delivery", po.delivery_terms], ["Warranty", po.warranty], ["Delivery address", po.delivery_address]]} /></Card>
            <Card title="Terms and conditions">{po.terms.length ? <ol className="list-decimal space-y-1 pl-5 text-sm">{po.terms.map((t: string, i: number) => <li key={i}>{t}</li>)}</ol> : <p className="text-sm text-ink-500">None.</p>}</Card>
          </div>
          {po.notes && <Card title="Internal notes"><p className="whitespace-pre-line text-sm">{po.notes}</p></Card>}
        </div>
      )}
      {tab === "receipts" && (
        <Card padded={false}>
          {po.grns.length === 0 ? <p className="p-4 text-sm text-ink-500">Nothing received yet.</p> : (
            <ul className="divide-y divide-ink-100">{po.grns.map((g: any) => (
              <li key={g.id} className="flex items-center gap-3 px-4 py-3 text-sm">
                <PackageCheck className="size-4 text-emerald-600" />
                <Link href={`/purchase/grn/view?id=${g.id}`} className="font-medium text-brand-700 hover:underline">{g.grn_number}</Link>
                <span className="text-ink-500">{date(g.grn_date)}</span><span className="num ml-auto">{inr(g.value)}</span>
              </li>))}</ul>
          )}
        </Card>
      )}
      {tab === "approvals" && <ApprovalHistory approvals={po.approvals} />}
      {tab === "documents" && <DocumentsPanel entityType="purchase_order" entityId={id} canEdit={can.edit || can.send || can.receive} defaultCategory="po" />}
      {tab === "history" && <HistoryPanel entityType="purchase_order" entityId={id} />}
      <ReasonDialog open={dialog === "cancel"} title="Cancel this purchase order?" label="Reason" required confirmLabel="Cancel order"
        onClose={() => setDialog(null)} onSubmit={async (reason) => { await act("cancel", { reason }, "Order cancelled"); }} />
      <ReasonDialog open={dialog === "close"} title="Short-close this order" label="Why will the rest not be received? Pending quantities go back to the purchase request." required confirmLabel="Short-close"
        onClose={() => setDialog(null)} onSubmit={async (reason) => { await act("close", { reason }, "Order closed"); }} />
    </>
  );
}

export default function Page() {
  return <Suspense><PoDetail /></Suspense>;
}
