"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { PageHeader, Spinner, useToast } from "@/components/ui";
import { PurchaseOrderForm } from "@/components/purchase/po-form";
import { api } from "@/lib/api/client";

function NewPo() {
  const prId = useSearchParams().get("pr");
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const pr = useQuery({ queryKey: ["/purchase-requests", prId], queryFn: () => api<any>(`/purchase-requests/${prId}`), select: (r) => r.data, enabled: !!prId });
  if (prId && pr.isLoading) return <Spinner />;
  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title="New purchase order" subtitle={pr.data ? `From purchase request ${pr.data.pr_number}` : "Save as draft, then submit for approval."} />
      <PurchaseOrderForm prefill={pr.data ? { pr: pr.data } : null} submitLabel="Save draft" onCancel={() => router.back()} onSubmit={async (body) => {
        const r = await api<any>("/purchase-orders", { body });
        toast("Draft saved");
        qc.invalidateQueries({ queryKey: ["/purchase-orders"] });
        qc.invalidateQueries({ queryKey: ["/purchase-requests"] });
        router.push(`/purchase/orders/view?id=${r.data.id}`);
      }} />
    </div>
  );
}

export default function Page() {
  return <Suspense><NewPo /></Suspense>;
}
