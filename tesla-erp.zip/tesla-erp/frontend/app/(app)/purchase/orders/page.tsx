"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Download, Plus, ShoppingCart } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { MiniStat } from "@/components/crm/common";
import { PO_STATUSES, PoStatus } from "@/components/purchase/common";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function PurchaseOrdersPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/purchase-orders", { filters: { open_only: "true" } });
  const s = useQuery({ queryKey: ["/purchase-orders/summary"], queryFn: () => api<any>("/purchase-orders/summary"), select: (r) => r.data }).data;
  const statusValue = list.filters.status || (list.filters.open_only === "true" ? "_open" : "");
  const setStatus = (v: string) => { list.setFilter("open_only", v === "_open" ? "true" : ""); list.setFilter("status", v.startsWith("_") ? "" : v); };
  return (
    <>
      <PageHeader title="Purchase orders" subtitle="Orders to suppliers, approved above the limit. Goods enter stock only through a GRN."
        actions={<>
          {can("purchase_order.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/purchase-orders/export", "purchase-orders.xlsx", { q: list.q, status: list.filters.status })}>Export</Button>}
          {can("purchase_order.create") && <Link href="/purchase/orders/new"><Button icon={<Plus className="size-4" />}>New purchase order</Button></Link>}
        </>} />
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <MiniStat label="Waiting for approval" value={s?.po_pending_approval} tone="amber" onClick={() => setStatus("pending_approval")} active={statusValue === "pending_approval"} />
        <MiniStat label="Approved, not sent" value={s?.po_to_send} onClick={() => setStatus("approved")} active={statusValue === "approved"} />
        <MiniStat label="Awaiting delivery" value={s?.po_awaiting_delivery} onClick={() => setStatus("sent")} active={statusValue === "sent"} />
        <MiniStat label="Open order value" value={s ? inr(s.open_po_value, 0) : undefined} />
      </div>
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search PO, supplier, quotation ref…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={statusValue} onChange={(e) => setStatus(e.target.value)} className="sm:w-52" aria-label="Status">
            <option value="_open">Open orders</option><option value="">All statuses</option>
            {PO_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/purchase/orders/view?id=${r.id}`)}
            empty={<EmptyState icon={<ShoppingCart className="size-8" />} title="No purchase orders here" body="Create one from an approved purchase request, or directly." />}
            columns={[
              { key: "n", header: "Order", sortKey: "created_at", cell: (r) => <div><p className="font-medium text-ink-900">{r.supplier.name}</p><p className="text-xs text-ink-500">{r.display_number}{r.project ? ` · ${r.project.number}` : ""}</p></div> },
              { key: "w", header: "Deliver to", hideOnMobile: true, cell: (r) => r.warehouse?.name },
              { key: "d", header: "Date", sortKey: "po_date", hideOnMobile: true, cell: (r) => date(r.po_date) },
              { key: "e", header: "Delivery by", sortKey: "expected_delivery", hideOnMobile: true, cell: (r) => date(r.expected_delivery) },
              { key: "t", header: "Value", sortKey: "grand_total", className: "text-right", cell: (r) => <span className="num">{inr(r.grand_total, 0)}</span> },
              { key: "s", header: "Status", sortKey: "status", cell: (r) => <PoStatus status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
