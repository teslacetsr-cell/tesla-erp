"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Download, FileText, FolderOpen, Image as ImageIcon, Upload } from "lucide-react";
import { Badge, Button, Card, Checkbox, EmptyState, Input, PageHeader, Select, Spinner } from "@/components/ui";
import { CATEGORIES, DocumentsPanel } from "@/components/record-panels";
import { api, download } from "@/lib/api/client";
import { bytes, dateTime, titleCase } from "@/lib/format";

type Row = {
  id: string; file_name: string; title: string | null; category: string; content_type: string; size_bytes: number; version: number;
  uploaded_at: string; uploaded_by: string | null; entity_type: string; entity_kind: string; entity_id: string; entity_label: string; href: string | null;
};

export default function DocumentsPage() {
  const [q, setQ] = useState("");
  const [dq, setDq] = useState("");
  const [f, setF] = useState({ entity_type: "", category: "", date_from: "", date_to: "", mine: false });
  const [company, setCompany] = useState(false);
  useEffect(() => { const t = setTimeout(() => setDq(q.trim()), 300); return () => clearTimeout(t); }, [q]);
  const lib = useQuery({
    queryKey: ["/document-library", dq, f],
    queryFn: () => api<any>("/document-library", { params: { q: dq, ...f, mine: f.mine || undefined } }),
    select: (r) => r.data as { rows: Row[]; truncated: boolean; types: { key: string; label: string }[]; company_id: string | null; can_upload_company: boolean },
  });
  const d = lib.data;
  return (
    <>
      <PageHeader title="Documents" subtitle="Every file you may open — drawings, test reports, site photos, quotations, bills, certificates — whichever record it is attached to."
        actions={d?.can_upload_company && <Button variant={company ? "primary" : "secondary"} icon={<Upload className="size-4" />} onClick={() => setCompany(!company)}>Company documents</Button>} />
      {company && d?.company_id && (
        <div className="mb-4">
          <p className="mb-2 text-sm text-ink-600">Company-wide papers: registrations, GST and PAN certificates, insurance, ISO and test-lab certificates, agreements. To add a file to a project, order or bill, open that record.</p>
          <DocumentsPanel entityType="company" entityId={d.company_id} canEdit defaultCategory="certificate" />
        </div>
      )}
      <Card padded={false}>
        <div className="grid gap-2 border-b border-ink-100 p-3 sm:grid-cols-2 lg:grid-cols-[1fr_12rem_11rem_9.5rem_9.5rem_auto] lg:items-center">
          <Input placeholder="Search file name or title…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search" />
          <Select value={f.entity_type} onChange={(e) => setF({ ...f, entity_type: e.target.value })} aria-label="Attached to">
            <option value="">All records</option>{(d?.types ?? []).map((t) => <option key={t.key} value={t.key}>{t.label}</option>)}
          </Select>
          <Select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} aria-label="Category">
            <option value="">All kinds</option>{[...CATEGORIES, "logo"].map((c) => <option key={c} value={c}>{titleCase(c.replace(/_/g, " "))}</option>)}
          </Select>
          <Input type="date" aria-label="Uploaded from" value={f.date_from} onChange={(e) => setF({ ...f, date_from: e.target.value })} />
          <Input type="date" aria-label="Uploaded to" value={f.date_to} onChange={(e) => setF({ ...f, date_to: e.target.value })} />
          <Checkbox label="Mine" checked={f.mine} onChange={(e) => setF({ ...f, mine: e.target.checked })} />
        </div>
        {lib.isLoading || !d ? <Spinner /> : d.rows.length === 0 ? (
          <EmptyState icon={<FolderOpen className="size-8" />} title="No documents found" body="Files attached to projects, orders, bills, customers and other records appear here." />
        ) : (
          <ul className="divide-y divide-ink-100">
            {d.rows.map((r) => (
              <li key={r.id} className="flex flex-wrap items-center gap-3 px-4 py-2.5 text-sm">
                {r.content_type.startsWith("image/") ? <ImageIcon className="size-5 shrink-0 text-ink-400" /> : <FileText className="size-5 shrink-0 text-ink-400" />}
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium text-ink-900">{r.title || r.file_name}{r.version > 1 && <span className="ml-1 text-xs font-normal text-ink-500">v{r.version}</span>}</p>
                  <p className="truncate text-xs text-ink-500">
                    {r.entity_kind}: {r.href ? <Link href={r.href} className="text-brand-700 hover:underline">{r.entity_label}</Link> : r.entity_label}
                    {" · "}{r.uploaded_by ?? "—"} · {dateTime(r.uploaded_at)} · {bytes(r.size_bytes)}{r.title ? ` · ${r.file_name}` : ""}
                  </p>
                </div>
                <Badge tone="grey">{titleCase(r.category.replace(/_/g, " "))}</Badge>
                <Button size="sm" variant="ghost" icon={<Download className="size-4" />} onClick={() => download(`/documents/${r.id}/content`, r.file_name)}>Download</Button>
              </li>
            ))}
          </ul>
        )}
        {d?.truncated && <p className="border-t border-ink-100 px-4 py-2 text-xs text-ink-500">Showing the newest files only — narrow the search or filters to find older ones.</p>}
      </Card>
    </>
  );
}
