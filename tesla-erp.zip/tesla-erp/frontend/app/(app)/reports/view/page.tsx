"use client";

import { Suspense, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import clsx from "clsx";
import { ArrowLeft, BarChart3, FileSpreadsheet, FileText, Play } from "lucide-react";
import { Button, Card, EmptyState, ErrorNote, Input, PageHeader, Select, Spinner, useToast } from "@/components/ui";
import {
  NUMERIC,
  cellText,
  groupIcon,
  presets,
  type ReportDef,
  type ReportFilter,
  type ReportGroup,
  type ReportResult,
} from "@/components/reports/common";
import { api, download } from "@/lib/api/client";

type Values = Record<string, string>;

/** Every filter key → its value. A key the user cleared is sent as "-" when the report has a default for it, so the
 * server does not put the default back. */
function toParams(def: ReportDef, v: Values): Values {
  const out: Values = {};
  for (const f of def.filters)
    for (const k of f.keys) {
      if (v[k]) out[k] = v[k];
      else if (f.default[k] !== undefined) out[k] = "-";
    }
  return out;
}

function initialValues(def: ReportDef, sp: URLSearchParams): Values {
  const out: Values = {};
  for (const f of def.filters)
    for (const k of f.keys) {
      const fromUrl = sp.get(k);
      out[k] = fromUrl !== null ? (fromUrl === "-" ? "" : fromUrl) : (f.default[k] ?? "");
    }
  return out;
}

function SelectFilter({ f, value, onChange }: { f: ReportFilter; value: string; onChange: (v: string) => void }) {
  const opts = useQuery({
    queryKey: ["/reports/options", f.source],
    queryFn: () => api<any>(`/reports/options/${f.source}`),
    select: (r) => r.data as { value: string; label: string; hint?: string }[],
    enabled: !!f.source && !f.options,
    staleTime: 5 * 60_000,
  });
  const options = f.options ?? opts.data ?? [];
  return (
    <Select value={value} onChange={(e) => onChange(e.target.value)} aria-label={f.label} className="min-w-0">
      <option value="">{f.name === "group_by" ? "—" : `All`}</option>
      {options.map((o) => (
        <option key={o.value} value={o.value}>{o.label}</option>
      ))}
    </Select>
  );
}

function FilterBar({ def, values, set, onRun, running }: { def: ReportDef; values: Values; set: (k: string, v: string) => void; onRun: () => void; running: boolean }) {
  return (
    <form
      className="flex flex-wrap items-end gap-3 border-b border-ink-100 p-3"
      onSubmit={(e) => {
        e.preventDefault();
        onRun();
      }}
    >
      {def.filters.map((f) => (
        <div key={f.name} className={clsx("min-w-0", f.type === "daterange" ? "w-full sm:w-auto" : "w-full sm:w-52")}>
          <span className="mb-1 block text-[13px] font-medium text-ink-700">{f.label}</span>
          {f.type === "daterange" ? (
            <div>
              <div className="flex items-center gap-1.5">
                <Input type="date" value={values.date_from ?? ""} onChange={(e) => set("date_from", e.target.value)} aria-label="From" className="w-full sm:w-38" />
                <span className="text-ink-400">–</span>
                <Input type="date" value={values.date_to ?? ""} onChange={(e) => set("date_to", e.target.value)} aria-label="To" className="w-full sm:w-38" />
              </div>
              <div className="mt-1 flex flex-wrap gap-x-2.5 gap-y-1 text-xs">
                {presets().map((p) => (
                  <button key={p.label} type="button" className="text-brand-700 hover:underline" onClick={() => { set("date_from", p.from); set("date_to", p.to); }}>
                    {p.label}
                  </button>
                ))}
                <button type="button" className="text-ink-500 hover:underline" onClick={() => { set("date_from", ""); set("date_to", ""); }}>All dates</button>
              </div>
            </div>
          ) : f.type === "date" ? (
            <Input type="date" value={values[f.keys[0]] ?? ""} onChange={(e) => set(f.keys[0], e.target.value)} aria-label={f.label} />
          ) : f.type === "month" ? (
            <Input type="month" value={values[f.keys[0]] ?? ""} onChange={(e) => set(f.keys[0], e.target.value)} aria-label={f.label} />
          ) : (
            <SelectFilter f={f} value={values[f.keys[0]] ?? ""} onChange={(v) => set(f.keys[0], v)} />
          )}
        </div>
      ))}
      <Button type="submit" icon={<Play className="size-4" />} loading={running} className={clsx(def.filters.some((f) => f.type === "daterange") && "sm:mb-5")}>Run</Button>
    </form>
  );
}

function ResultTable({ res, onOpen }: { res: ReportResult; onOpen: (href: string) => void }) {
  const cols = res.columns;
  const hasTotals = Object.values(res.totals ?? {}).some((v) => v !== null && v !== "");
  if (res.rows.length === 0) return <EmptyState icon={<BarChart3 className="size-8" />} title="No records" body="Nothing matches these filters. Try a wider period or clear a filter." />;
  return (
    <div className="max-h-[70vh] overflow-auto">
      <table className="w-full border-separate border-spacing-0 text-[13px]">
        <thead>
          <tr>
            {cols.map((c) => (
              <th key={c.key} className={clsx("sticky top-0 z-10 border-b border-ink-200 bg-ink-50 px-3 py-2 text-xs font-medium uppercase tracking-wide text-ink-500 whitespace-nowrap",
                NUMERIC.includes(c.type) ? "text-right" : "text-left")}>
                {c.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {res.rows.map((r, i) => (
            <tr key={i} onClick={r._link ? () => onOpen(r._link) : undefined} className={clsx("hover:bg-brand-50/40", r._link && "cursor-pointer")}>
              {cols.map((c) => {
                const num = NUMERIC.includes(c.type);
                const t = cellText(c.type, r[c.key]);
                return (
                  <td key={c.key} className={clsx("border-b border-ink-100 px-3 py-1.5 align-top",
                    num ? "num text-right whitespace-nowrap" : c.type === "date" ? "whitespace-nowrap" : "",
                    num && r[c.key] != null && Number(r[c.key]) < 0 && "text-brand-700")}
                    style={c.type === "text" && c.width >= 20 ? { minWidth: `${Math.min(c.width, 40) * 0.42}rem` } : undefined}>
                    {t || <span className="text-ink-300">—</span>}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
        {hasTotals && (
          <tfoot>
            <tr className="font-semibold text-ink-900">
              {cols.map((c, i) => {
                const v = res.totals[c.key];
                return (
                  <td key={c.key} className={clsx("sticky bottom-0 border-t-2 border-ink-300 bg-brand-50 px-3 py-2", NUMERIC.includes(c.type) ? "num text-right whitespace-nowrap" : "")}>
                    {v !== undefined && v !== null && v !== "" ? cellText(c.type, v) : i === 0 ? "Total" : ""}
                  </td>
                );
              })}
            </tr>
          </tfoot>
        )}
      </table>
    </div>
  );
}

function ReportView({ def }: { def: ReportDef }) {
  const sp = useSearchParams();
  const router = useRouter();
  const toast = useToast();
  const start = useMemo(() => initialValues(def, new URLSearchParams(sp.toString())), [def]);
  const [draft, setDraft] = useState<Values>(start);
  const [applied, setApplied] = useState<Values>(start);
  const [busy, setBusy] = useState<"" | "xlsx" | "pdf">("");
  const params = toParams(def, applied);
  const q = useQuery({
    queryKey: ["/reports/run", def.key, params],
    queryFn: () => api<any>(`/reports/${def.key}`, { params }),
    select: (r) => r.data as ReportResult,
    retry: false,
  });
  const run = () => {
    setApplied({ ...draft });
    const qs = new URLSearchParams({ key: def.key, ...toParams(def, draft) });
    router.replace(`/reports/view?${qs.toString()}`, { scroll: false });
    if (JSON.stringify(draft) === JSON.stringify(applied)) q.refetch();
  };
  const exportAs = async (format: "xlsx" | "pdf") => {
    setBusy(format);
    try {
      await download(`/reports/${def.key}/export`, `${def.key}.${format}`, { ...params, format });
    } catch (e) {
      toast(e instanceof Error ? e.message : "Export failed", "error");
    } finally {
      setBusy("");
    }
  };
  const Icon = groupIcon(def.group);
  const res = q.data;
  return (
    <>
      <PageHeader
        back={<Link href="/reports" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Reports</Link>}
        title={<span className="flex items-center gap-2"><Icon className="size-5 text-brand-600" /> {def.title}</span>}
        subtitle={def.description}
        actions={<>
          <Button variant="secondary" icon={<FileSpreadsheet className="size-4" />} loading={busy === "xlsx"} disabled={!res} onClick={() => exportAs("xlsx")}>Excel</Button>
          <Button variant="secondary" icon={<FileText className="size-4" />} loading={busy === "pdf"} disabled={!res} onClick={() => exportAs("pdf")}>PDF</Button>
        </>}
      />
      <Card padded={false}>
        {def.filters.length > 0 && (
          <FilterBar def={def} values={draft} set={(k, v) => setDraft((d) => ({ ...d, [k]: v }))} onRun={run} running={q.isFetching} />
        )}
        {res && (
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-ink-100 px-3 py-2 text-xs text-ink-500">
            <span>{res.filters_label || "All records"}</span>
            <span className="num">
              {res.row_count.toLocaleString("en-IN")} record{res.row_count === 1 ? "" : "s"}
              {res.truncated && <span className="ml-1 text-brand-700">(first 5,000 shown — narrow the filters)</span>}
            </span>
          </div>
        )}
        {q.isLoading ? <Spinner /> : q.error ? <div className="p-3"><ErrorNote error={q.error} /></div> : res ? (
          <div className={clsx(q.isFetching && "opacity-60 transition-opacity")}>
            <ResultTable res={res} onOpen={(href) => router.push(href)} />
          </div>
        ) : null}
      </Card>
    </>
  );
}

function Viewer() {
  const key = useSearchParams().get("key") ?? "";
  const cat = useQuery({ queryKey: ["/reports"], queryFn: () => api<any>("/reports"), select: (r) => r.data as ReportGroup[] });
  const def = cat.data?.flatMap((g) => g.reports).find((r) => r.key === key);
  if (cat.isLoading) return <Spinner />;
  if (cat.error) return <ErrorNote error={cat.error} />;
  if (!def)
    return (
      <Card>
        <EmptyState icon={<BarChart3 className="size-8" />} title="Report not available" body="This report does not exist or your role does not give access to it."
          action={<Link href="/reports" className="text-sm font-medium text-brand-700 hover:underline">All reports</Link>} />
      </Card>
    );
  return <ReportView key={def.key} def={def} />;
}

export default function Page() {
  return <Suspense><Viewer /></Suspense>;
}
