"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { BarChart3, ChevronRight, Search } from "lucide-react";
import { Card, EmptyState, ErrorNote, Input, PageHeader, Spinner } from "@/components/ui";
import { groupIcon, type ReportGroup } from "@/components/reports/common";
import { api } from "@/lib/api/client";

export default function ReportsPage() {
  const [q, setQ] = useState("");
  const cat = useQuery({ queryKey: ["/reports"], queryFn: () => api<any>("/reports"), select: (r) => r.data as ReportGroup[] });
  const groups = useMemo(() => {
    const s = q.trim().toLowerCase();
    const all = cat.data ?? [];
    if (!s) return all;
    return all
      .map((g) => ({ ...g, reports: g.reports.filter((r) => `${r.title} ${r.description} ${g.group}`.toLowerCase().includes(s)) }))
      .filter((g) => g.reports.length > 0);
  }, [cat.data, q]);
  const total = (cat.data ?? []).reduce((n, g) => n + g.reports.length, 0);

  return (
    <>
      <PageHeader title="Reports" subtitle="Registers and summaries across the company, with filters and Excel / PDF export." />
      <div className="relative mb-4 max-w-md">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-ink-400" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={`Search ${total || ""} reports…`} className="pl-9" aria-label="Search reports" />
      </div>
      {cat.isLoading ? <Spinner /> : cat.error ? <ErrorNote error={cat.error} /> : groups.length === 0 ? (
        <Card><EmptyState icon={<BarChart3 className="size-8" />} title={q ? "No report matches your search" : "No reports available"}
          body={q ? undefined : "Your role does not give access to any report. Ask an administrator if you need one."} /></Card>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {groups.map((g) => {
            const Icon = groupIcon(g.group);
            return (
              <Card key={g.group} padded={false} title={<span className="flex items-center gap-2"><Icon className="size-4 text-brand-600" /> {g.group}</span>}
                actions={<span className="text-xs text-ink-500">{g.reports.length} report{g.reports.length === 1 ? "" : "s"}</span>}>
                <ul className="divide-y divide-ink-100">
                  {g.reports.map((r) => (
                    <li key={r.key}>
                      <Link href={`/reports/view?key=${r.key}`} className="group flex items-start gap-3 px-4 py-3 hover:bg-brand-50/40">
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium text-ink-900 group-hover:text-brand-700">{r.title}</p>
                          <p className="mt-0.5 text-[13px] leading-snug text-ink-500">{r.description}</p>
                        </div>
                        <ChevronRight className="mt-0.5 size-4 shrink-0 text-ink-300 group-hover:text-brand-600" />
                      </Link>
                    </li>
                  ))}
                </ul>
              </Card>
            );
          })}
        </div>
      )}
    </>
  );
}
