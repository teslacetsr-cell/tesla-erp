"use client";

import Link from "next/link";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ShieldCheck } from "lucide-react";
import { Badge, Card, EmptyState, PageHeader, Spinner, Tabs } from "@/components/ui";
import { ApprovalSteps, DecideButtons, type ApprovalReq } from "@/components/quotations/approval";
import { api } from "@/lib/api/client";
import { inr } from "@/lib/format";

type Tab = "inbox" | "history";

export default function ApprovalsPage() {
  const [tab, setTab] = useState<Tab>("inbox");
  const qc = useQueryClient();
  const inbox = useQuery({ queryKey: ["/approvals/inbox"], queryFn: () => api<{ data: ApprovalReq[] }>("/approvals/inbox"), select: (r) => r.data, refetchInterval: 60_000 });
  const history = useQuery({ queryKey: ["/approvals/history"], queryFn: () => api<{ data: ApprovalReq[] }>("/approvals/history"), select: (r) => r.data, enabled: tab === "history" });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/approvals/inbox"] }); qc.invalidateQueries({ queryKey: ["/approvals/history"] }); qc.invalidateQueries({ queryKey: ["/quotations"] }); qc.invalidateQueries({ queryKey: ["/notifications"] }); };
  const rows = tab === "inbox" ? inbox.data : history.data;
  const loading = tab === "inbox" ? inbox.isLoading : history.isLoading;
  return (
    <>
      <PageHeader title="Approvals" subtitle="Quotations, purchases, stock adjustments, material issues, expenses, supplier bills and leave wait here for each approver in turn." />
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[{ id: "inbox", label: "Waiting for me", count: inbox.data?.length }, { id: "history", label: "My requests & decisions" }]} />
      {loading ? <Spinner /> : !rows?.length ? (
        <Card><EmptyState icon={<ShieldCheck className="size-8" />} title={tab === "inbox" ? "Nothing waiting for you" : "No approvals yet"} /></Card>
      ) : (
        <div className="space-y-3">
          {rows.map((r) => (
            <Card key={r.id} title={
              <span className="flex flex-wrap items-center gap-2">
                {r.href ? <Link href={r.href} className="text-brand-700 hover:underline">{r.entity_name} {r.entity_label}</Link> : r.entity_label}
                {r.entity_type !== "leave_request" && <span className="num font-normal text-ink-600">{inr(r.amount, 0)}{["expense", "material_issue"].includes(r.entity_type ?? "") ? "" : " before GST"}</span>}
                {tab === "history" && <Badge tone={r.status === "approved" ? "green" : r.status === "rejected" ? "red" : r.status === "pending" ? "amber" : "grey"}>{r.status}</Badge>}
              </span>}>
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <ApprovalSteps req={r} />
                <div className="flex shrink-0 flex-col items-end gap-2">
                  <DecideButtons req={r} onDone={refresh} />
                  {r.href && <Link href={r.href} className="text-sm text-brand-700 hover:underline">Open {(r.entity_name ?? "the record").toLowerCase()}</Link>}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </>
  );
}
