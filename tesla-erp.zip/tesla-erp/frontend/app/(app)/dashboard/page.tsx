"use client";

import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, ArrowRight, Boxes, CheckCircle2, Circle, Truck, Users } from "lucide-react";
import { Card, PageHeader } from "@/components/ui";
import { api, type Page } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { dateTime, inr, titleCase } from "@/lib/format";

const PHASES = [
  { n: 1, name: "Foundation: users, roles, company, customers, suppliers, items", done: true },
  { n: 2, name: "CRM: leads, enquiries, site visits, follow-ups", done: true },
  { n: 3, name: "BOQ, quotations, quotation PDF, approvals", done: true },
  { n: 4, name: "Sales orders, projects, project BOQ, tasks", done: true },
  { n: 5, name: "Purchase, PO, GRN, inventory", done: true },
  { n: 6, name: "Material issue, project cost & profitability" },
  { n: 7, name: "Invoices, receipts, expenses, receivables" },
  { n: 8, name: "HR" },
  { n: 9, name: "Service / AMC" },
  { n: 10, name: "Reports, dashboards, notifications" },
];

function Stat({ label, path, href, icon: Icon, perm }: { label: string; path: string; href: string; icon: typeof Users; perm: string }) {
  const { can } = useAuth();
  const { data } = useQuery({
    queryKey: [path, "count"],
    queryFn: () => api<Page<unknown>>(path, { params: { page_size: 1 } }),
    enabled: can(perm),
  });
  if (!can(perm)) return null;
  return (
    <Link href={href} className="group rounded-lg border border-ink-200 bg-white p-4 transition-colors hover:border-brand-300">
      <div className="flex items-center justify-between">
        <p className="text-sm text-ink-500">{label}</p>
        <Icon className="size-4 text-ink-400 group-hover:text-brand-600" />
      </div>
      <p className="num mt-2 text-3xl font-semibold tracking-tight text-ink-900">{data ? data.meta.total.toLocaleString("en-IN") : "–"}</p>
    </Link>
  );
}

const PIPELINE: [string, string][] = [
  ["new", "New"], ["contacted", "Contacted"], ["qualified", "Qualified"], ["site_visit", "Site visit"],
  ["quotation", "Quotation"], ["negotiation", "Negotiation"], ["won", "Won"], ["lost", "Lost"],
];

/** Approvals waiting for me and quotations with customers. */
function QuotationTiles() {
  const { can } = useAuth();
  const { data } = useQuery({ queryKey: ["/quotations/summary"], queryFn: () => api<{ data: any }>("/quotations/summary"), select: (r) => r.data, enabled: can("quotation.read") });
  if (!data) return null;
  const by = data.by_status ?? {};
  const tiles: [string, number, string, string][] = [
    ["Waiting for my approval", data.awaiting_my_approval, "/approvals", data.awaiting_my_approval ? "text-amber-700" : "text-ink-900"],
    ["Quotations pending approval", by.pending_approval ?? 0, "/sales/quotations", "text-ink-900"],
    ["Quotations with customers", (by.sent ?? 0) + (by.negotiation ?? 0), "/sales/quotations", "text-ink-900"],
    ["Quotations accepted", by.accepted ?? 0, "/sales/quotations", "text-emerald-700"],
  ];
  return (
    <div className="mb-6 grid grid-cols-2 gap-3 xl:grid-cols-4">
      {tiles.map(([label, v, href, color]) => (
        <Link key={label} href={href} className="rounded-lg border border-ink-200 bg-white p-4 hover:border-brand-300">
          <p className="text-xs text-ink-500">{label}</p>
          <p className={`num mt-1 text-2xl font-semibold ${color}`}>{v}</p>
        </Link>
      ))}
    </div>
  );
}

/** Project manager dashboard (Spec §40): live projects, late ones, overdue tasks, open issues, my tasks. */
function ProjectTiles() {
  const { can } = useAuth();
  const prj = useQuery({ queryKey: ["/projects/summary"], queryFn: () => api<{ data: any }>("/projects/summary"), select: (r) => r.data, enabled: can("project.read") });
  const so = useQuery({ queryKey: ["/sales-orders/summary"], queryFn: () => api<{ data: any }>("/sales-orders/summary"), select: (r) => r.data, enabled: can("sales_order.read") });
  const mine = useQuery({ queryKey: ["/tasks", "mine-count"], queryFn: () => api<Page<unknown>>("/tasks", { params: { mine: true, open_only: true, page_size: 1 } }), select: (r) => r.meta.total });
  const tiles: [string, number | string, string, string][] = [];
  if (mine.data) tiles.push(["My open tasks", mine.data, "/projects/tasks", "text-ink-900"]);
  if (prj.data) {
    tiles.push(["Active projects", prj.data.active, "/projects", "text-ink-900"]);
    if (prj.data.late) tiles.push(["Projects past target date", prj.data.late, "/projects", "text-brand-700"]);
    tiles.push(["Overdue project tasks", prj.data.overdue_tasks, "/projects/tasks", prj.data.overdue_tasks ? "text-amber-700" : "text-ink-900"]);
    tiles.push(["Open site issues", prj.data.open_issues, "/projects", prj.data.open_issues ? "text-amber-700" : "text-ink-900"]);
  }
  if (so.data) tiles.push(["Orders without a project yet", so.data.confirmed, "/sales/orders", so.data.confirmed ? "text-amber-700" : "text-ink-900"],
    ["Open order value (before GST)", inr(so.data.open_value, 0), "/sales/orders", "text-ink-900"]);
  if (!tiles.length) return null;
  return (
    <div className="mb-6 grid grid-cols-2 gap-3 xl:grid-cols-4">
      {tiles.slice(0, 8).map(([label, v, href, color]) => (
        <Link key={label} href={href} className="rounded-lg border border-ink-200 bg-white p-4 hover:border-brand-300">
          <p className="text-xs text-ink-500">{label}</p>
          <p className={`num mt-1 text-2xl font-semibold ${color}`}>{v}</p>
        </Link>
      ))}
    </div>
  );
}

/** Purchase & stores dashboard (Spec §40): approvals, orders awaiting delivery, open requests, low stock. */
function PurchaseTiles() {
  const { can } = useAuth();
  const any = can("purchase_order.read|purchase_request.read|material_request.read|grn.read");
  const pur = useQuery({ queryKey: ["/purchase-orders/summary"], queryFn: () => api<{ data: any }>("/purchase-orders/summary"), select: (r) => r.data, enabled: any });
  const stock = useQuery({ queryKey: ["/stock/summary"], queryFn: () => api<{ data: any }>("/stock/summary"), select: (r) => r.data, enabled: can("stock.read") });
  const p = pur.data, st = stock.data;
  const tiles: [string, number | string, string, string][] = [];
  if (p?.mr_open !== undefined) tiles.push(["Material requests to act on", p.mr_open, "/purchase/material-requests", p.mr_open ? "text-amber-700" : "text-ink-900"]);
  if (p?.pr_to_order !== undefined) tiles.push(["Approved requests to order", p.pr_to_order, "/purchase/requests", "text-ink-900"]);
  if (p?.po_awaiting_delivery !== undefined) tiles.push(["POs awaiting delivery", p.po_awaiting_delivery, "/purchase/orders", "text-ink-900"]);
  if (p?.po_pending_approval !== undefined && can("purchase_order.approve")) tiles.push(["POs waiting for approval", p.po_pending_approval, "/approvals", p.po_pending_approval ? "text-amber-700" : "text-ink-900"]);
  if (st) {
    tiles.push(["Items out of stock", st.out_of_stock, "/inventory/stock", st.out_of_stock ? "text-brand-700" : "text-ink-900"]);
    tiles.push(["Items below reorder level", st.below_reorder, "/inventory/stock", st.below_reorder ? "text-amber-700" : "text-ink-900"]);
    if (can("stock.export") || can("stock_adjustment.approve")) tiles.push(["Stock value", inr(st.stock_value, 0), "/inventory/stock", "text-ink-900"]);
  }
  if (!tiles.length) return null;
  return (
    <div className="mb-6 grid grid-cols-2 gap-3 xl:grid-cols-4">
      {tiles.slice(0, 8).map(([label, v, href, color]) => (
        <Link key={label} href={href} className="rounded-lg border border-ink-200 bg-white p-4 hover:border-brand-300">
          <p className="text-xs text-ink-500">{label}</p>
          <p className={`num mt-1 text-2xl font-semibold ${color}`}>{v}</p>
        </Link>
      ))}
    </div>
  );
}

/** Sales dashboard (Spec §40): leads by stage, open enquiries, visits and the user's follow-ups. */
function SalesPipeline() {
  const { can } = useAuth();
  const any = can("lead.read|enquiry.read|site_visit.read");
  const { data } = useQuery({ queryKey: ["/crm/summary"], queryFn: () => api<{ data: any }>("/crm/summary"), select: (r) => r.data, enabled: any });
  if (!any || !data) return null;
  const rows: any[] = data.leads_by_status ?? [];
  const max = Math.max(1, ...rows.map((r) => r.count));
  const openValue = rows.filter((r) => !["won", "lost"].includes(r.status)).reduce((n, r) => n + Number(r.value), 0);
  const tiles: [string, number | undefined, string, string][] = [
    ["Follow-ups overdue", data.my_follow_ups_overdue, "/crm/follow-ups", "text-brand-700"],
    ["Follow-ups due today", data.my_follow_ups_today, "/crm/follow-ups", "text-amber-700"],
    ["Open enquiries", data.open_enquiries, "/crm/enquiries", "text-ink-900"],
    ["Site visits, next 7 days", data.visits_next_7_days, "/crm/site-visits", "text-ink-900"],
  ];
  return (
    <div className="mb-6 grid gap-4 xl:grid-cols-[1fr_380px]">
      {rows.length > 0 && (
        <Card title="Sales pipeline" actions={<Link href="/crm/leads" className="text-xs font-medium text-brand-700 hover:underline">All leads</Link>}>
          <div className="space-y-2">
            {PIPELINE.map(([status, label]) => {
              const r = rows.find((x) => x.status === status) ?? { count: 0, value: "0" };
              return (
                <div key={status} className="grid grid-cols-[6.5rem_1fr_3rem] items-center gap-3 text-sm">
                  <span className="text-ink-600">{label}</span>
                  <span className="h-2.5 overflow-hidden rounded-full bg-ink-100">
                    <span className={`block h-full rounded-full ${status === "won" ? "bg-emerald-600" : status === "lost" ? "bg-ink-300" : "bg-brand-600"}`} style={{ width: `${(r.count / max) * 100}%` }} />
                  </span>
                  <span className="num text-right font-medium">{r.count}</span>
                </div>
              );
            })}
          </div>
          <p className="mt-4 text-sm text-ink-600">Open pipeline value: <span className="num font-semibold text-ink-900">{inr(openValue, 0)}</span></p>
        </Card>
      )}
      <div className="grid grid-cols-2 gap-3 self-start">
        {tiles.filter(([, v]) => v !== undefined).map(([label, v, href, color]) => (
          <Link key={label} href={href} className="rounded-lg border border-ink-200 bg-white p-4 hover:border-brand-300">
            <p className="text-xs text-ink-500">{label}</p>
            <p className={`num mt-1 text-2xl font-semibold ${color}`}>{v}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}

function RecentActivity() {
  const { can } = useAuth();
  const { data } = useQuery({
    queryKey: ["/audit-logs", "recent"],
    queryFn: () => api<Page<any>>("/audit-logs", { params: { page_size: 8 } }),
    enabled: can("audit.read"),
  });
  if (!can("audit.read")) return null;
  return (
    <Card title="Recent activity" actions={<Link href="/admin/audit-logs" className="text-xs font-medium text-brand-700 hover:underline">View audit log</Link>} padded={false}>
      <ul className="divide-y divide-ink-100">
        {data?.data.map((a) => (
          <li key={a.id} className="flex items-start justify-between gap-4 px-4 py-2.5 text-sm">
            <span className="min-w-0">
              <span className="font-medium text-ink-800">{a.user_name ?? "System"}</span>{" "}
              <span className="text-ink-500">{titleCase(a.action).toLowerCase()}</span>{" "}
              <span className="text-ink-800">{titleCase(a.entity_type).toLowerCase()}</span>
              {a.entity_label && <span className="text-ink-500"> · {a.entity_label}</span>}
            </span>
            <span className="shrink-0 text-xs text-ink-400">{dateTime(a.occurred_at)}</span>
          </li>
        ))}
      </ul>
    </Card>
  );
}

function BackupWarning() {
  const { can } = useAuth();
  const { data } = useQuery({
    queryKey: ["/system/status"],
    queryFn: () => api<{ data: any }>("/system/status"),
    enabled: can("settings.read"),
  });
  const s = data?.data;
  if (!s || (s.deployment !== "onprem" && !s.backup)) return null;
  const last = s.backup?.last_success ? new Date(s.backup.last_success).getTime() : 0;
  const problem = !s.storage.ok ? "Document storage is not reachable — uploads will fail."
    : s.backup?.ok === false || Date.now() - last > 26 * 3600 * 1000 ? "The nightly backup has not succeeded in the last day." : null;
  if (!problem) return null;
  return (
    <Link href="/admin/settings" className="mb-5 flex items-center gap-2 rounded-md border border-brand-200 bg-brand-50 px-4 py-3 text-sm text-brand-800">
      <AlertTriangle className="size-4 shrink-0" /> <span className="font-medium">{problem}</span> <span className="ml-auto underline">Check system status</span>
    </Link>
  );
}

export default function Dashboard() {
  const { me } = useAuth();
  const hour = Number(new Date().toLocaleString("en-IN", { hour: "numeric", hour12: false, timeZone: "Asia/Kolkata" }));
  const greet = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  return (
    <>
      <BackupWarning />
      <PageHeader title={`${greet}, ${me?.full_name.split(" ")[0]}`} subtitle="Tesla Consulting Engineers · ERP" />
      <ProjectTiles />
      <PurchaseTiles />
      <QuotationTiles />
      <SalesPipeline />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Customers" path="/customers" href="/customers" icon={Users} perm="customer.read" />
        <Stat label="Suppliers" path="/suppliers" href="/suppliers" icon={Truck} perm="supplier.read" />
        <Stat label="Items & services" path="/items" href="/items" icon={Boxes} perm="item.read" />
        <Stat label="Users" path="/users" href="/admin/users" icon={Users} perm="user.read" />
      </div>
      <div className="mt-6 grid gap-6 xl:grid-cols-[1fr_380px]">
        <RecentActivity />
        <Card title="Build roadmap">
          <ol className="space-y-2">
            {PHASES.map((p) => (
              <li key={p.n} className="flex items-start gap-2.5 text-sm">
                {p.done ? <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-brand-600" /> : <Circle className="mt-0.5 size-4 shrink-0 text-ink-300" />}
                <span className={p.done ? "text-ink-900" : "text-ink-500"}>
                  <span className="font-medium">Phase {p.n}.</span> {p.name}
                </span>
              </li>
            ))}
          </ol>
          <Link href="/projects" className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-brand-700 hover:underline">
            Go to projects <ArrowRight className="size-3.5" />
          </Link>
        </Card>
      </div>
    </>
  );
}
