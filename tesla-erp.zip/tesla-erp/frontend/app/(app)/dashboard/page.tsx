"use client";

import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, ArrowRight, Boxes, CheckCircle2, Circle, Truck, Users } from "lucide-react";
import { Card, PageHeader } from "@/components/ui";
import { api, type Page } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { dateTime, titleCase } from "@/lib/format";

const PHASES = [
  { n: 1, name: "Foundation: users, roles, company, customers, suppliers, items", done: true },
  { n: 2, name: "CRM: leads, enquiries, site visits" },
  { n: 3, name: "BOQ, quotations, quotation PDF, approvals" },
  { n: 4, name: "Sales orders, projects, project BOQ, tasks" },
  { n: 5, name: "Purchase, PO, GRN, inventory" },
  { n: 6, name: "Material issue, project cost & profitability" },
  { n: 7, name: "Invoices, receipts, expenses, receivables" },
  { n: 8, name: "HR" },
  { n: 9, name: "Service / AMC" },
  { n: 10, name: "Reports, dashboards, notifications" },
];

function Stat({ label, path, href, icon: Icon, perm }: { label: string; path: string; href: string; icon: typeof Users; perm: string }) {
  const { can } = useAuth();
  const { data } = useQuery({
    queryKey: [path, "count"],
    queryFn: () => api<Page<unknown>>(path, { params: { page_size: 1 } }),
    enabled: can(perm),
  });
  if (!can(perm)) return null;
  return (
    <Link href={href} className="group rounded-lg border border-ink-200 bg-white p-4 transition-colors hover:border-brand-300">
      <div className="flex items-center justify-between">
        <p className="text-sm text-ink-500">{label}</p>
        <Icon className="size-4 text-ink-400 group-hover:text-brand-600" />
      </div>
      <p className="num mt-2 text-3xl font-semibold tracking-tight text-ink-900">{data ? data.meta.total.toLocaleString("en-IN") : "–"}</p>
    </Link>
  );
}

function RecentActivity() {
  const { can } = useAuth();
  const { data } = useQuery({
    queryKey: ["/audit-logs", "recent"],
    queryFn: () => api<Page<any>>("/audit-logs", { params: { page_size: 8 } }),
    enabled: can("audit.read"),
  });
  if (!can("audit.read")) return null;
  return (
    <Card title="Recent activity" actions={<Link href="/admin/audit-logs" className="text-xs font-medium text-brand-700 hover:underline">View audit log</Link>} padded={false}>
      <ul className="divide-y divide-ink-100">
        {data?.data.map((a) => (
          <li key={a.id} className="flex items-start justify-between gap-4 px-4 py-2.5 text-sm">
            <span className="min-w-0">
              <span className="font-medium text-ink-800">{a.user_name ?? "System"}</span>{" "}
              <span className="text-ink-500">{titleCase(a.action).toLowerCase()}</span>{" "}
              <span className="text-ink-800">{titleCase(a.entity_type).toLowerCase()}</span>
              {a.entity_label && <span className="text-ink-500"> · {a.entity_label}</span>}
            </span>
            <span className="shrink-0 text-xs text-ink-400">{dateTime(a.occurred_at)}</span>
          </li>
        ))}
      </ul>
    </Card>
  );
}

function BackupWarning() {
  const { can } = useAuth();
  const { data } = useQuery({
    queryKey: ["/system/status"],
    queryFn: () => api<{ data: any }>("/system/status"),
    enabled: can("settings.read"),
  });
  const s = data?.data;
  if (!s || (s.deployment !== "onprem" && !s.backup)) return null;
  const last = s.backup?.last_success ? new Date(s.backup.last_success).getTime() : 0;
  const problem = !s.storage.ok ? "Document storage is not reachable — uploads will fail."
    : s.backup?.ok === false || Date.now() - last > 26 * 3600 * 1000 ? "The nightly backup has not succeeded in the last day." : null;
  if (!problem) return null;
  return (
    <Link href="/admin/settings" className="mb-5 flex items-center gap-2 rounded-md border border-brand-200 bg-brand-50 px-4 py-3 text-sm text-brand-800">
      <AlertTriangle className="size-4 shrink-0" /> <span className="font-medium">{problem}</span> <span className="ml-auto underline">Check system status</span>
    </Link>
  );
}

export default function Dashboard() {
  const { me } = useAuth();
  const hour = Number(new Date().toLocaleString("en-IN", { hour: "numeric", hour12: false, timeZone: "Asia/Kolkata" }));
  const greet = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  return (
    <>
      <BackupWarning />
      <PageHeader title={`${greet}, ${me?.full_name.split(" ")[0]}`} subtitle="Tesla Consulting Engineers · ERP" />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Customers" path="/customers" href="/customers" icon={Users} perm="customer.read" />
        <Stat label="Suppliers" path="/suppliers" href="/suppliers" icon={Truck} perm="supplier.read" />
        <Stat label="Items & services" path="/items" href="/items" icon={Boxes} perm="item.read" />
        <Stat label="Users" path="/users" href="/admin/users" icon={Users} perm="user.read" />
      </div>
      <div className="mt-6 grid gap-6 xl:grid-cols-[1fr_380px]">
        <RecentActivity />
        <Card title="Build roadmap">
          <ol className="space-y-2">
            {PHASES.map((p) => (
              <li key={p.n} className="flex items-start gap-2.5 text-sm">
                {p.done ? <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-brand-600" /> : <Circle className="mt-0.5 size-4 shrink-0 text-ink-300" />}
                <span className={p.done ? "text-ink-900" : "text-ink-500"}>
                  <span className="font-medium">Phase {p.n}.</span> {p.name}
                </span>
              </li>
            ))}
          </ol>
          <Link href="/customers" className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-brand-700 hover:underline">
            Start with customers <ArrowRight className="size-3.5" />
          </Link>
        </Card>
      </div>
    </>
  );
}
