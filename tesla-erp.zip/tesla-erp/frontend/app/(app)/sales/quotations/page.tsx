"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Download, FileText, Plus } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { MiniStat } from "@/components/crm/common";
import { QuotationStatus, QUOTATION_STATUSES } from "@/components/quotations/status";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function QuotationsPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/quotations", { filters: { open_only: "true" } });
  const summary = useQuery({ queryKey: ["/quotations/summary"], queryFn: () => api<any>("/quotations/summary"), select: (r) => r.data });
  const by = summary.data?.by_status ?? {};
  const statusValue = list.filters.status || (list.filters.open_only === "true" ? "_open" : "");
  const setStatus = (v: string) => { list.setFilter("open_only", v === "_open" ? "true" : ""); list.setFilter("status", v.startsWith("_") ? "" : v); };
  return (
    <>
      <PageHeader title="Quotations" subtitle="Offers to customers, with every revision kept and approvals above the limit."
        actions={<>
          {can("quotation.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/quotations/export", "quotations.xlsx", { q: list.q, ...list.filters })}>Export</Button>}
          {can("quotation.create") && <Link href="/sales/quotations/new"><Button icon={<Plus className="size-4" />}>New quotation</Button></Link>}
        </>} />
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <MiniStat label="Drafts" value={by.draft ?? 0} onClick={() => setStatus("draft")} active={statusValue === "draft"} />
        <MiniStat label="Waiting for approval" value={by.pending_approval ?? 0} tone="amber" onClick={() => setStatus("pending_approval")} active={statusValue === "pending_approval"} />
        <MiniStat label="With customer" value={(by.sent ?? 0) + (by.negotiation ?? 0)} onClick={() => setStatus("sent")} active={statusValue === "sent"} />
        <MiniStat label="Accepted" value={by.accepted ?? 0} onClick={() => setStatus("accepted")} active={statusValue === "accepted"} />
      </div>
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search number, subject, customer…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={statusValue} onChange={(e) => setStatus(e.target.value)} className="sm:w-52" aria-label="Status">
            <option value="_open">Open quotations</option>
            <option value="">All statuses</option>
            {QUOTATION_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/sales/quotations/view?id=${r.id}`)}
            empty={<EmptyState icon={<FileText className="size-8" />} title={list.q ? "No quotations match your search" : "No quotations here"} body="Create one from an enquiry or a BOQ." />}
            columns={[
              { key: "n", header: "Quotation", sortKey: "updated_at", cell: (r) => <div><p className="font-medium text-ink-900">{r.subject}</p><p className="text-xs text-ink-500">{r.display_number}</p></div> },
              { key: "c", header: "Customer", cell: (r) => r.customer?.name },
              { key: "d", header: "Date", hideOnMobile: true, cell: (r) => date(r.quotation_date) },
              { key: "v", header: "Valid until", hideOnMobile: true, cell: (r) => date(r.valid_until) },
              { key: "t", header: "Grand total", className: "text-right", cell: (r) => <span className="num">{inr(r.grand_total, 0)}</span> },
              { key: "sp", header: "Salesperson", hideOnMobile: true, cell: (r) => r.sales_person ?? "—" },
              { key: "s", header: "Status", sortKey: "status", cell: (r) => <QuotationStatus status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
