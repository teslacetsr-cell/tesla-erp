"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, CheckCircle2, FileDown, GitBranch, Handshake, PackageCheck, Pencil, Send, ShieldCheck, Trash2, Undo2, XCircle } from "lucide-react";
import { Badge, Button, Card, Detail, ErrorNote, Field, Input, Modal, PageHeader, Spinner, Tabs, Textarea, useConfirm, useToast } from "@/components/ui";
import { ApprovalSteps, DecideButtons } from "@/components/quotations/approval";
import { QuotationForm } from "@/components/quotations/quotation-form";
import { QuotationStatus } from "@/components/quotations/status";
import { LinesTable, TotalsBox } from "@/components/lines-editor";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api, download } from "@/lib/api/client";
import { date, dateTime, inr } from "@/lib/format";

type Tab = "quotation" | "approval" | "revisions" | "documents" | "history";

/** Accepted quotation → sales order: the accepted revision's lines, prices, taxes and terms are copied exactly. */
function SalesOrderDialog({ q, open, onClose }: { q: any; open: boolean; onClose: () => void }) {
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const [v, setV] = useState({ so_date: "", customer_po_number: "", customer_po_date: "", expected_completion: "", notes: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV({ ...v, [k]: e.target.value });
  const n = (s: string) => (s.trim() ? s.trim() : null);
  return (
    <Modal open={open} onClose={onClose} title={`Sales order from ${q.display_number}`}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setBusy(true);
        try {
          const r = await api<any>(`/quotations/${q.id}/sales-order`, { body: { so_date: n(v.so_date), customer_po_number: n(v.customer_po_number),
            customer_po_date: n(v.customer_po_date), expected_completion: n(v.expected_completion), notes: n(v.notes) } });
          toast(`Sales order ${r.data.so_number} created`);
          qc.invalidateQueries({ queryKey: ["/quotations"] });
          qc.invalidateQueries({ queryKey: ["/sales-orders"] });
          router.push(`/sales/orders/view?id=${r.data.id}`);
        } catch (e) { setError(e); } finally { setBusy(false); }
      }}>Create sales order</Button></>}>
      <div className="space-y-3">
        <ErrorNote error={error} />
        <p className="text-sm text-ink-600">Every line, price, discount, GST and term of <b>R{q.accepted_revision_no}</b> ({inr(q.grand_total, 0)}) is copied and locked.</p>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Order date" hint="Blank = today"><Input type="date" value={v.so_date} onChange={set("so_date")} /></Field>
          <Field label="Expected completion"><Input type="date" value={v.expected_completion} onChange={set("expected_completion")} /></Field>
          <Field label="Customer PO number"><Input value={v.customer_po_number} onChange={set("customer_po_number")} /></Field>
          <Field label="Customer PO date"><Input type="date" value={v.customer_po_date} onChange={set("customer_po_date")} /></Field>
        </div>
        <Field label="Notes"><Textarea rows={2} value={v.notes} onChange={set("notes")} /></Field>
      </div>
    </Modal>
  );
}

function ReasonDialog({ open, title, label, required, confirmLabel, onClose, onSubmit }: {
  open: boolean; title: string; label: string; required?: boolean; confirmLabel: string; onClose: () => void; onSubmit: (reason: string) => Promise<void>;
}) {
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  return (
    <Modal open={open} onClose={onClose} title={title}
      footer={<><Button variant="secondary" onClick={onClose}>Back</Button><Button loading={busy} onClick={async () => {
        if (required && !text.trim()) return setError("This is required.");
        setBusy(true);
        try { await onSubmit(text.trim()); setText(""); onClose(); } catch (e: any) { setError(e.message); } finally { setBusy(false); }
      }}>{confirmLabel}</Button></>}>
      <Field label={label} error={error ?? undefined}><Textarea rows={3} value={text} onChange={(e) => setText(e.target.value)} /></Field>
    </Modal>
  );
}

function RevisionView({ q, rev }: { q: any; rev: any }) {
  return (
    <div className="space-y-4">
      {rev.last_rejection && q.status === "draft" && <p className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900"><b>Returned by the approver:</b> {rev.last_rejection}</p>}
      <Card title={`Items · R${rev.revision_no}${rev.locked ? " (sent — locked)" : ""}`} padded={false}>
        <div className="p-2"><LinesTable items={rev.items} /></div>
        <div className="border-t border-ink-100 p-4">
          <TotalsBox interState={rev.inter_state} taxSummary={rev.tax_summary}
            t={{ gross: rev.gross, lineDiscount: rev.line_discount, special: rev.special_discount, taxable: rev.taxable, cgst: rev.cgst, sgst: rev.sgst, igst: rev.igst, roundOff: rev.round_off, grand: rev.grand_total }} />
        </div>
      </Card>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Commercial terms">
          <Detail cols={2} items={[["Payment", rev.payment_terms], ["Delivery", rev.delivery_terms], ["Warranty", rev.warranty], ["Valid until", date(rev.valid_until)]]} />
        </Card>
        <Card title="Terms and conditions">
          {rev.terms.length ? <ol className="list-decimal space-y-1 pl-5 text-sm">{rev.terms.map((t: string, i: number) => <li key={i}>{t}</li>)}</ol> : <p className="text-sm text-ink-500">None.</p>}
        </Card>
      </div>
      {rev.technical_notes && <Card title="Technical specifications"><p className="whitespace-pre-line text-sm">{rev.technical_notes}</p></Card>}
    </div>
  );
}

function QuotationDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [tab, setTab] = useState<Tab>("quotation");
  const [editing, setEditing] = useState(false);
  const [viewRev, setViewRev] = useState<number | null>(null);
  const [dialog, setDialog] = useState<"reject" | "cancel" | "revise" | "so" | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const key = ["/quotations", id];
  const { data, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api(`/quotations/${id}`), select: (r: any) => r.data });
  const other = useQuery({
    queryKey: ["/quotations", id, "rev", viewRev],
    queryFn: () => api<any>(`/quotations/${id}/revisions/${viewRev}`), select: (r) => r.data,
    enabled: viewRev !== null && viewRev !== data?.current_revision_no,
  });
  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["/quotations"] });
    qc.invalidateQueries({ queryKey: ["/quotations/summary"] });
    qc.invalidateQueries({ queryKey: ["/approvals/inbox"] });
    qc.invalidateQueries({ queryKey: ["/documents", "quotation", id] });
  };
  if (isLoading) return <Spinner />;
  if (error || !data) return <ErrorNote error={error} />;
  const q = data;
  const can = q.can;
  const shownNo = viewRev ?? q.current_revision_no;
  const rev = shownNo === q.current_revision_no ? q.current : other.data;
  const pdfName = `${(q.quotation_number ?? "DRAFT").replaceAll("/", "-")}${shownNo ? `-R${shownNo}` : ""}.pdf`;

  async function act(action: string, body: Record<string, any> = {}, msg?: string) {
    setBusy(action);
    try {
      const r = await api(`/quotations/${id}/${action}`, { body: { row_version: q.row_version, ...body } });
      if (msg) toast(msg);
      refresh();
      return r.data;
    } catch (e: any) { toast(e.message, "error"); } finally { setBusy(null); }
  }

  if (editing)
    return (
      <div className="mx-auto max-w-6xl">
        <PageHeader title={`Edit ${q.display_number}`} subtitle={q.current_revision_no ? `Revision R${q.current_revision_no}` : "Draft"} />
        <QuotationForm initial={q} submitLabel="Save draft" onCancel={() => setEditing(false)} onSubmit={async (values) => {
          await api(`/quotations/${id}`, { method: "PUT", body: { ...values, row_version: q.row_version } });
          toast("Quotation saved");
          setEditing(false);
          refresh();
        }} />
      </div>
    );

  return (
    <>
      <PageHeader
        back={<Link href="/sales/quotations" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Quotations</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{q.subject} <QuotationStatus status={q.status} /></span>}
        subtitle={`${q.display_number} · ${q.customer?.name}${q.enquiry_number ? ` · ${q.enquiry_number}` : ""}${q.sales_person ? ` · ${q.sales_person}` : ""}`}
        actions={<>
          {can.edit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {can.submit && <Button icon={<ShieldCheck className="size-4" />} loading={busy === "submit"} onClick={async () => {
            const r = await act("submit");
            if (r) toast(r.status === "approved" ? `${r.display_number} approved — below the approval limit` : `${r.display_number} sent for approval`);
          }}>Submit</Button>}
          {can.send && <Button icon={<Send className="size-4" />} loading={busy === "send"} onClick={async () => {
            if (!(await confirm({ title: "Mark as sent to the customer?", body: `R${q.current_revision_no} will be locked for ever and its PDF filed. Any later change becomes a new revision. Email the downloaded PDF to the customer.`, confirmLabel: "Mark as sent" }))) return;
            const r = await act("send", {}, "Marked as sent — PDF filed");
            if (r) download(`/quotations/${id}/revisions/${r.current_revision_no}/pdf`, pdfName);
          }}>Mark as sent</Button>}
          {can.accept && <Button icon={<CheckCircle2 className="size-4" />} loading={busy === "accept"} onClick={async () => {
            if (await confirm({ title: `Customer accepted R${q.current_revision_no}?`, body: "The enquiry and lead are marked Won. Then create the sales order from this revision.", confirmLabel: "Mark accepted" })) act("accept", {}, "Marked accepted");
          }}>Accepted</Button>}
          {can.create_sales_order && <Button icon={<PackageCheck className="size-4" />} onClick={() => setDialog("so")}>Create sales order</Button>}
          {q.sales_order && <Link href={`/sales/orders/view?id=${q.sales_order.id}`}><Button variant="secondary" icon={<PackageCheck className="size-4" />}>{q.sales_order.so_number}</Button></Link>}
          {can.negotiation && <Button variant="secondary" icon={<Handshake className="size-4" />} onClick={() => act("negotiation", {}, "Marked as under negotiation")}>Negotiation</Button>}
          {can.revise && <Button variant="secondary" icon={<GitBranch className="size-4" />} onClick={() => setDialog("revise")}>Revise</Button>}
          {can.withdraw && <Button variant="secondary" icon={<Undo2 className="size-4" />} onClick={async () => {
            if (await confirm({ title: "Withdraw to edit?", body: q.status === "approved" ? "The approval is cancelled; it must be submitted again." : "The approval request is withdrawn.", confirmLabel: "Withdraw" })) act("withdraw", {}, "Back to draft");
          }}>Withdraw</Button>}
          {can.reject && <Button variant="ghost" icon={<XCircle className="size-4" />} onClick={() => setDialog("reject")}>Customer rejected</Button>}
          {can.print && rev && rev.items?.length > 0 && <Button variant="secondary" icon={<FileDown className="size-4" />} onClick={() => download(`/quotations/${id}/revisions/${shownNo}/pdf`, pdfName)}>PDF</Button>}
          {can.cancel && <Button variant="ghost" onClick={() => setDialog("cancel")}>Cancel quotation</Button>}
          {can.delete && <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Delete this draft?", body: "Only an unnumbered draft can be deleted.", confirmLabel: "Delete" }))) return;
            await api(`/quotations/${id}`, { method: "DELETE" });
            refresh();
            router.push("/sales/quotations");
          }}>Delete</Button>}
        </>} />

      {q.approval && (
        <Card className="mb-4 border-amber-300" title={<span className="flex items-center gap-2"><ShieldCheck className="size-4 text-amber-600" /> Waiting for approval · step {q.approval.current_step + 1} of {q.approval.steps.length}</span>}>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <ApprovalSteps req={q.approval} />
            <DecideButtons req={q.approval} onDone={refresh} />
          </div>
        </Card>
      )}
      {q.status_reason && ["rejected", "cancelled"].includes(q.status) && <p className="mb-4 rounded-md bg-ink-100 px-3 py-2 text-sm"><b>{q.status === "rejected" ? "Customer's reason" : "Reason"}:</b> {q.status_reason}</p>}

      <div className="mb-4 grid gap-4 lg:grid-cols-[1fr_320px]">
        <Card>
          <Detail cols={4} items={[
            ["Customer", <Link key="c" href={`/customers/view?id=${q.customer_id}`} className="text-brand-700 hover:underline">{q.customer?.name}</Link>],
            ["Site", q.site], ["Enquiry", q.enquiry_id ? <Link key="e" href={`/crm/enquiries/view?id=${q.enquiry_id}`} className="text-brand-700 hover:underline">{q.enquiry_number}</Link> : null],
            ["Division", q.division], ["Date", date(q.current.quotation_date)], ["Valid until", date(q.current.valid_until)],
            ["Place of supply", q.current.place_of_supply ? `${q.current.place_of_supply} · ${q.current.inter_state ? "IGST" : "CGST + SGST"}` : null],
            ["Kind attention", q.current.kind_attention],
          ]} />
        </Card>
        <Card>
          <p className="text-xs uppercase tracking-wide text-ink-500">Grand total · R{q.current_revision_no}</p>
          <p className="num mt-1 text-3xl font-semibold text-ink-900">{inr(q.current.grand_total, 0)}</p>
          <p className="mt-1 text-sm text-ink-500">{inr(q.current.taxable, 0)} before GST</p>
          {q.accepted_revision_no !== null && <p className="mt-2"><Badge tone="green">Accepted: R{q.accepted_revision_no}</Badge></p>}
        </Card>
      </div>

      <Tabs<Tab> value={tab} onChange={setTab} tabs={[
        { id: "quotation", label: "Quotation" }, { id: "approval", label: "Approvals", count: q.approvals.length },
        { id: "revisions", label: "Revisions", count: q.revisions.length }, { id: "documents", label: "Documents" }, { id: "history", label: "History" },
      ]} />
      {tab === "quotation" && (
        <>
          {q.revisions.length > 1 && (
            <div className="mb-3 flex flex-wrap items-center gap-2 text-sm">
              <span className="text-ink-500">Showing</span>
              {[...q.revisions].reverse().map((r: any) => (
                <button key={r.revision_no} onClick={() => setViewRev(r.revision_no)}
                  className={`rounded-md border px-2.5 py-1 ${shownNo === r.revision_no ? "border-brand-500 bg-brand-50 text-brand-700" : "border-ink-200 hover:bg-ink-50"}`}>
                  R{r.revision_no}{r.revision_no === q.current_revision_no ? " (current)" : ""}
                </button>
              ))}
            </div>
          )}
          {rev ? <RevisionView q={q} rev={rev} /> : <Spinner />}
        </>
      )}
      {tab === "approval" && (
        <div className="space-y-3">
          {q.approvals.length === 0 && <Card><p className="text-sm text-ink-500">No approvals yet. Quotations above the limit in Administration → Approval rules are routed for approval when submitted.</p></Card>}
          {q.approvals.map((a: any) => (
            <Card key={a.id} title={<span className="flex items-center gap-2">{a.policy_name} <Badge tone={a.status === "approved" ? "green" : a.status === "rejected" ? "red" : a.status === "pending" ? "amber" : "grey"}>{a.status}</Badge></span>}>
              <ApprovalSteps req={a} />
            </Card>
          ))}
        </div>
      )}
      {tab === "revisions" && (
        <Card padded={false}>
          <ul className="divide-y divide-ink-100">
            {q.revisions.map((r: any) => (
              <li key={r.revision_no} className="flex flex-wrap items-center gap-3 px-4 py-3">
                <span className="w-10 font-semibold">R{r.revision_no}</span>
                <div className="min-w-0 flex-1 text-sm">
                  <p>{date(r.quotation_date)} · <span className="num">{inr(r.grand_total, 0)}</span>{r.locked && <span className="ml-2"><Badge tone="blue">Sent {dateTime(r.sent_at)}</Badge></span>}</p>
                  {r.change_note && <p className="text-ink-500">{r.change_note}</p>}
                </div>
                <Button size="sm" variant="ghost" onClick={() => { setViewRev(r.revision_no); setTab("quotation"); }}>View</Button>
                {can.print && <Button size="sm" variant="secondary" icon={<FileDown className="size-3.5" />} onClick={() => download(`/quotations/${id}/revisions/${r.revision_no}/pdf`, `${(q.quotation_number ?? "DRAFT").replaceAll("/", "-")}${r.revision_no ? `-R${r.revision_no}` : ""}.pdf`)}>PDF</Button>}
              </li>
            ))}
          </ul>
        </Card>
      )}
      {tab === "documents" && <DocumentsPanel entityType="quotation" entityId={id} canEdit={can.edit || can.send || can.revise} defaultCategory="quotation" />}
      {tab === "history" && <HistoryPanel entityType="quotation" entityId={id} />}

      {dialog === "so" && <SalesOrderDialog q={q} open onClose={() => setDialog(null)} />}
      <ReasonDialog open={dialog === "reject"} title="Customer rejected the quotation" label="Customer's reason (required)" required confirmLabel="Mark rejected"
        onClose={() => setDialog(null)} onSubmit={async (reason) => { await act("reject", { reason }, "Marked rejected"); }} />
      <ReasonDialog open={dialog === "cancel"} title="Cancel this quotation?" label="Reason (optional)" confirmLabel="Cancel quotation"
        onClose={() => setDialog(null)} onSubmit={async (reason) => { await act("cancel", { reason: reason || null }, "Quotation cancelled"); }} />
      <ReasonDialog open={dialog === "revise"} title={`Start revision R${q.current_revision_no + 1}`} label="What changes? (optional, e.g. “5 % discount as discussed”)" confirmLabel="Start revision"
        onClose={() => setDialog(null)} onSubmit={async (note) => {
          await api(`/quotations/${id}/revise`, { body: { change_note: note || null, row_version: q.row_version } });
          toast(`Revision R${q.current_revision_no + 1} started — R${q.current_revision_no} is kept unchanged`);
          setViewRev(null);
          refresh();
          await qc.refetchQueries({ queryKey: key, exact: true });  // edit the NEW revision, with its row version
          setEditing(true);
        }} />
    </>
  );
}

export default function Page() {
  return <Suspense><QuotationDetail /></Suspense>;
}
