"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import { ErrorNote, PageHeader, Spinner, useToast } from "@/components/ui";
import { useCustomerDetail } from "@/components/crm/common";
import { QuotationForm } from "@/components/quotations/quotation-form";
import { api } from "@/lib/api/client";

function NewQuotation() {
  const router = useRouter();
  const toast = useToast();
  const qc = useQueryClient();
  const sp = useSearchParams();
  const boqId = sp.get("boq_id");
  const boq = useQuery({ queryKey: ["/boqs", boqId], queryFn: () => api<any>(`/boqs/${boqId}`), select: (r) => r.data, enabled: !!boqId });
  const enquiryId = sp.get("enquiry_id") ?? boq.data?.enquiry_id ?? null;
  const enq = useQuery({ queryKey: ["/enquiries", enquiryId], queryFn: () => api<any>(`/enquiries/${enquiryId}`), select: (r) => r.data, enabled: !!enquiryId });
  const customerId = sp.get("customer_id");
  const cust = useCustomerDetail(customerId);
  if ((boqId && boq.isLoading) || (enquiryId && enq.isLoading) || (customerId && cust.isLoading)) return <Spinner />;
  if (boq.error || enq.error) return <ErrorNote error={boq.error ?? enq.error} />;
  const e = enq.data;
  const b = boq.data;
  const c = cust.data;
  const customer = e ? e.customer : b?.customer ?? (c ? { id: c.id, name: c.customer_name, code: c.customer_code, city: c.city } : null);
  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader back={<Link href="/sales/quotations" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Quotations</Link>}
        title="New quotation" subtitle="Saved as a draft. Submit it for approval when ready; the number is given on submission." />
      <QuotationForm submitLabel="Save draft" onCancel={() => router.back()}
        prefill={{ customer, enquiry: e ? { id: e.id, enquiry_number: e.enquiry_number, subject: e.subject, site_id: e.site_id, contact_id: e.contact_id, division_id: e.division_id, sales_person_id: e.sales_person_id } : null,
          boq: b ? { id: b.id, boq_number: b.boq_number, title: b.title, items: b.items, site_id: b.site_id, division_id: b.division_id } : null }}
        onSubmit={async (values) => {
          const r = await api("/quotations", { body: values });
          qc.invalidateQueries({ queryKey: ["/quotations"] });
          toast("Draft quotation saved");
          router.push(`/sales/quotations/view?id=${r.data.id}`);
        }} />
    </div>
  );
}

export default function Page() {
  return <Suspense><NewQuotation /></Suspense>;
}
