"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Download, Plus, ReceiptText } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { MiniStat } from "@/components/crm/common";
import { InvoiceBadges, useDashboard } from "@/components/finance/common";
import { download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function InvoicesPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/invoices");
  const d = useDashboard(can("receivable.read")).data;
  const f = list.filters;
  const view = f.overdue === "true" ? "overdue" : f.outstanding === "true" ? "outstanding" : f.status ?? "";
  const setView = (v: string) => {
    list.setFilter("overdue", v === "overdue" ? "true" : "");
    list.setFilter("outstanding", v === "outstanding" ? "true" : "");
    list.setFilter("status", ["draft", "issued", "cancelled"].includes(v) ? v : "");
  };
  return (
    <>
      <PageHeader title="Sales invoices" subtitle="GST tax invoices — billed from sales orders or directly. Issued invoices are corrected only by credit notes."
        actions={<>
          {can("invoice.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/invoices/export", "sales-register.xlsx", { q: list.q, status: f.status, outstanding: f.outstanding, overdue: f.overdue })}>Sales register</Button>}
          {can("invoice.create") && <Link href="/sales/invoices/new"><Button icon={<Plus className="size-4" />}>New invoice</Button></Link>}
        </>} />
      {d && (
        <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <MiniStat label="Receivable" value={inr(d.receivable, 0)} onClick={() => setView("outstanding")} active={view === "outstanding"} />
          <MiniStat label="Overdue" value={inr(d.receivable_overdue, 0)} tone="red" onClick={() => setView("overdue")} active={view === "overdue"} />
          <MiniStat label="Billed this month" value={inr(d.invoiced_month, 0)} />
          <MiniStat label="Drafts" value={d.draft_invoices} tone="amber" onClick={() => setView("draft")} active={view === "draft"} />
        </div>
      )}
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search invoice no., customer, PO…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={view} onChange={(e) => setView(e.target.value)} className="sm:w-52" aria-label="Show">
            <option value="">All invoices</option><option value="outstanding">Outstanding</option><option value="overdue">Overdue</option>
            <option value="draft">Drafts</option><option value="issued">Issued</option><option value="cancelled">Cancelled</option>
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/sales/invoices/view?id=${r.id}`)}
            empty={<EmptyState icon={<ReceiptText className="size-8" />} title="No invoices here" body="Bill a sales order from its page, or create a direct invoice." />}
            columns={[
              { key: "n", header: "Invoice", sortKey: "invoice_number", cell: (r) => <div><p className="font-medium text-ink-900">{r.customer}</p><p className="text-xs text-ink-500">{r.invoice_number ?? "Draft"}{r.ra_bill_no ? ` · RA ${r.ra_bill_no}` : ""}{r.subject ? ` · ${r.subject}` : ""}</p></div> },
              { key: "d", header: "Date", sortKey: "invoice_date", hideOnMobile: true, cell: (r) => date(r.invoice_date) },
              { key: "due", header: "Due", sortKey: "due_date", hideOnMobile: true, cell: (r) => <span className={r.overdue ? "text-brand-700" : ""}>{date(r.due_date)}</span> },
              { key: "t", header: "Total", sortKey: "grand_total", className: "text-right", cell: (r) => <span className="num">{inr(r.grand_total, 0)}</span> },
              { key: "b", header: "Balance", className: "text-right", hideOnMobile: true, cell: (r) => <span className="num">{r.status === "issued" ? inr(r.balance, 0) : "—"}</span> },
              { key: "s", header: "Status", cell: (r) => <InvoiceBadges r={r} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
