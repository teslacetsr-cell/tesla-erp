"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, BadgeCheck, FileDown, FileMinus2, Hash, IndianRupee, Pencil, Trash2, XCircle } from "lucide-react";
import { Badge, Button, Card, Checkbox, Detail, ErrorNote, Field, Input, Modal, PageHeader, Spinner, Tabs, Textarea, useConfirm, useToast } from "@/components/ui";
import { LinesTable, TotalsBox } from "@/components/lines-editor";
import { InvoiceBadges } from "@/components/finance/common";
import { InvoiceForm } from "@/components/finance/invoice-form";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api, download } from "@/lib/api/client";
import { date, dateTime, inr } from "@/lib/format";

type Tab = "invoice" | "payments" | "documents" | "history";

function CreditNoteDialog({ inv, full, onClose, onDone }: { inv: any; full: boolean; onClose: () => void; onDone: () => void }) {
  const [reason, setReason] = useState("");
  const [cancel, setCancel] = useState(full);
  const [taxable, setTaxable] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const credited = inv.credit_notes.reduce((s: number, c: any) => s + Number(c.taxable), 0);
  const left = Number(inv.taxable) - credited;
  const rate = Number(inv.taxable) ? (Number(inv.cgst) + Number(inv.sgst) + Number(inv.igst)) / Number(inv.taxable) : 0;
  const toast = useToast();
  return (
    <Modal open onClose={onClose} title={cancel ? `Cancel invoice ${inv.invoice_number}` : `Credit note against ${inv.invoice_number}`}
      footer={<><Button variant="secondary" onClick={onClose}>Back</Button><Button loading={busy} variant={cancel ? "danger" : "primary"} onClick={async () => {
        setError(null);
        if (reason.trim().length < 3) return setError(new Error("Give the reason (it is printed on the credit note)."));
        if (!cancel && !(Number(taxable) > 0)) return setError(new Error("Enter the value to credit."));
        setBusy(true);
        try {
          const r = await api<any>(`/invoices/${inv.id}/credit-notes`, { body: { reason: reason.trim(), cancel_invoice: cancel, taxable: cancel ? null : taxable, row_version: inv.row_version } });
          toast(`Credit note ${r.data.cn_number} issued`); onDone(); onClose();
        } catch (e) { setError(e); } finally { setBusy(false); }
      }}>{cancel ? "Cancel invoice" : "Issue credit note"}</Button></>}>
      <div className="space-y-4">
        <ErrorNote error={error} />
        <p className="text-sm text-ink-600">A credit note is a GST document: it reverses the value and the tax in the invoice's own proportion. The invoice itself is never edited or deleted.</p>
        <Checkbox label="Cancel the whole invoice" checked={cancel} disabled={Number(inv.received) > 0} onChange={(e) => setCancel(e.target.checked)} />
        {Number(inv.received) > 0 && <p className="text-xs text-ink-500">Money has been received against this invoice, so it cannot be cancelled in full. Take the receipt off it first (on the receipt) — the money becomes an advance.</p>}
        {!cancel && (
          <Field label="Value to credit, before GST (₹)" hint={`Up to ${inr(left)}. GST of about ${inr((Number(taxable) || 0) * rate)} is reversed with it.`}>
            <Input inputMode="decimal" className="num" value={taxable} onChange={(e) => setTaxable(e.target.value)} />
          </Field>
        )}
        <Field label="Reason" required><Textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Rate difference agreed in meeting of 2 Oct" /></Field>
      </div>
    </Modal>
  );
}

function IrnDialog({ inv, onClose, onDone }: { inv: any; onClose: () => void; onDone: () => void }) {
  const [v, setV] = useState({ irn: inv.irn ?? "", irn_ack_no: inv.irn_ack_no ?? "", irn_ack_date: inv.irn_ack_date ?? "" });
  const [error, setError] = useState<unknown>(null);
  return (
    <Modal open onClose={onClose} title="e-Invoice IRN" footer={<><Button variant="secondary" onClick={onClose}>Back</Button><Button onClick={async () => {
      try { await api(`/invoices/${inv.id}/irn`, { body: { irn: v.irn.trim(), irn_ack_no: v.irn_ack_no.trim() || null, irn_ack_date: v.irn_ack_date || null, row_version: inv.row_version } }); onDone(); onClose(); }
      catch (e) { setError(e); }
    }}>Save</Button></>}>
      <div className="space-y-4">
        <ErrorNote error={error} />
        <p className="text-sm text-ink-600">If the company is above the e-invoicing limit, generate the IRN on the e-invoice portal and record it here; it prints on the invoice.</p>
        <Field label="IRN" required><Input value={v.irn} onChange={(e) => setV({ ...v, irn: e.target.value })} /></Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Ack. no."><Input value={v.irn_ack_no} onChange={(e) => setV({ ...v, irn_ack_no: e.target.value })} /></Field>
          <Field label="Ack. date"><Input type="date" value={v.irn_ack_date} onChange={(e) => setV({ ...v, irn_ack_date: e.target.value })} /></Field>
        </div>
      </div>
    </Modal>
  );
}

function InvoiceDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [tab, setTab] = useState<Tab>("invoice");
  const [editing, setEditing] = useState(false);
  const [dialog, setDialog] = useState<"credit" | "cancel" | "irn" | null>(null);
  const { data: inv, isLoading, error } = useQuery({ queryKey: ["/invoices", id], queryFn: () => api<any>(`/invoices/${id}`), select: (r) => r.data });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/invoices"] }); qc.invalidateQueries({ queryKey: ["/finance/dashboard"] }); };
  if (isLoading) return <Spinner />;
  if (error || !inv) return <ErrorNote error={error} />;
  const can = inv.can;
  const pdfName = `${(inv.invoice_number ?? "DRAFT-INVOICE").replaceAll("/", "-")}.pdf`;
  if (editing)
    return (
      <div className="mx-auto max-w-6xl">
        <PageHeader title="Edit draft invoice" />
        <InvoiceForm initial={inv} submitLabel="Save draft" onCancel={() => setEditing(false)} onSubmit={async (body) => {
          await api(`/invoices/${id}`, { method: "PUT", body: { ...body, row_version: inv.row_version } });
          toast("Saved"); setEditing(false); refresh();
        }} />
      </div>
    );
  return (
    <>
      <PageHeader back={<Link href="/sales/invoices" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Invoices</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{inv.invoice_number ?? "Draft invoice"} <InvoiceBadges r={inv} /></span>}
        subtitle={`${inv.customer}${inv.subject ? ` · ${inv.subject}` : ""}`}
        actions={<>
          {can.issue && <Button icon={<BadgeCheck className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Issue this tax invoice?", body: "It gets the next invoice number, posts to the books and can then only be changed by a credit note. Check the draft PDF first.", confirmLabel: "Issue invoice" }))) return;
            try { const r = await api<any>(`/invoices/${id}/issue`, { body: { row_version: inv.row_version } }); toast(`Invoice ${r.data.invoice_number} issued`); refresh(); }
            catch (e: any) { toast(e.message, "error"); }
          }}>Issue invoice</Button>}
          {can.receipt && <Link href={`/finance/receipts/new?customer=${inv.customer_id}&invoice=${inv.id}`}><Button icon={<IndianRupee className="size-4" />}>Record receipt</Button></Link>}
          {can.edit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {can.print && <Button variant="secondary" icon={<FileDown className="size-4" />} onClick={() => download(`/invoices/${id}/pdf`, pdfName)}>PDF</Button>}
          {can.credit_note && <Button variant="secondary" icon={<FileMinus2 className="size-4" />} onClick={() => setDialog("credit")}>Credit note</Button>}
          {can.irn && <Button variant="ghost" icon={<Hash className="size-4" />} onClick={() => setDialog("irn")}>{inv.irn ? "IRN" : "Record IRN"}</Button>}
          {can.cancel && <Button variant="ghost" icon={<XCircle className="size-4" />} onClick={() => setDialog("cancel")}>Cancel invoice</Button>}
          {can.delete && <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Discard this draft?", body: "It was never issued, so nothing is lost from the books.", confirmLabel: "Discard" }))) return;
            await api(`/invoices/${id}`, { method: "DELETE" }); refresh(); router.push("/sales/invoices");
          }}>Discard</Button>}
        </>} />
      {inv.status === "cancelled" && <p className="mb-4 rounded-md bg-ink-100 px-3 py-2 text-sm"><b>Cancelled:</b> {inv.status_reason}</p>}
      <div className="mb-4 grid gap-4 lg:grid-cols-[1fr_320px]">
        <Card>
          <Detail cols={4} items={[
            ["Customer", <Link key="c" href={`/customers/view?id=${inv.customer_id}`} className="text-brand-700 hover:underline">{inv.customer}</Link>],
            ["Invoice date", date(inv.invoice_date)], ["Due", date(inv.due_date)],
            ["Bill", inv.bill_type === "running" ? `Running bill${inv.ra_bill_no ? ` ${inv.ra_bill_no}` : ""}` : inv.bill_type === "final" ? "Final bill" : inv.bill_type === "service" ? "Service" : "Tax invoice"],
            ["Sales order", inv.sales_order ? <Link key="s" href={`/sales/orders/view?id=${inv.sales_order.id}`} className="text-brand-700 hover:underline">{inv.sales_order.so_number}</Link> : "—"],
            ["Project", inv.project ? <Link key="p" href={`/projects/view?id=${inv.project.id}`} className="text-brand-700 hover:underline">{inv.project.number}</Link> : "—"],
            ["Customer PO", inv.customer_po_number ? `${inv.customer_po_number}${inv.customer_po_date ? ` · ${date(inv.customer_po_date)}` : ""}` : "—"],
            ["GST", `${inv.inter_state ? "IGST (inter-state)" : "CGST + SGST"} · POS ${inv.place_of_supply ?? "—"}${inv.reverse_charge ? " · reverse charge" : ""}`],
            ...(inv.irn ? [["IRN", <span key="i" className="break-all text-xs">{inv.irn}</span>] as [string, any]] : []),
          ]} />
        </Card>
        <Card>
          <p className="text-xs uppercase tracking-wide text-ink-500">{inv.status === "issued" ? "Balance due" : "Invoice total"}</p>
          <p className="num mt-1 text-3xl font-semibold text-ink-900">{inr(inv.status === "issued" ? inv.balance : inv.grand_total, 2)}</p>
          <p className="mt-1 text-sm text-ink-500">of {inr(inv.grand_total)} · {inr(inv.taxable)} before GST</p>
          {Number(inv.received) > 0 && <p className="mt-1 text-sm text-emerald-700">Received {inr(inv.received)}{Number(inv.tds) ? ` (incl. TDS ${inr(inv.tds)})` : ""}</p>}
          {Number(inv.credited) > 0 && <p className="text-sm text-ink-600">Credited {inr(inv.credited)}</p>}
          {Number(inv.retention_amount) > 0 && <p className="mt-2"><Badge tone="amber">Retention {inr(inv.retention_amount)}</Badge></p>}
          {inv.issued_at && <p className="mt-2 text-xs text-ink-500">Issued {dateTime(inv.issued_at)}</p>}
        </Card>
      </div>
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[{ id: "invoice", label: "Invoice" }, { id: "payments", label: "Receipts & credits", count: inv.receipts.length + inv.credit_notes.length },
        { id: "documents", label: "Documents" }, { id: "history", label: "History" }]} />
      {tab === "invoice" && (
        <div className="space-y-4">
          <Card padded={false}>
            <LinesTable items={inv.items} />
            <div className="border-t border-ink-100 p-4">
              <TotalsBox interState={inv.inter_state} t={{ gross: inv.gross, lineDiscount: inv.line_discount, special: inv.special_discount, taxable: inv.taxable, cgst: inv.cgst, sgst: inv.sgst, igst: inv.igst, roundOff: inv.round_off, grand: inv.grand_total }} />
            </div>
          </Card>
          {(inv.payment_terms || inv.notes) && <Card title="Terms"><Detail cols={2} items={[["Payment terms", inv.payment_terms], ["Notes", inv.notes]]} /></Card>}
        </div>
      )}
      {tab === "payments" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Receipts" padded={false}>
            {inv.receipts.length === 0 ? <p className="p-4 text-sm text-ink-500">Nothing received yet.</p> : (
              <ul className="divide-y divide-ink-100">{inv.receipts.map((r: any) => (
                <li key={r.id} className="flex items-center gap-3 px-4 py-3 text-sm">
                  <Link href={`/finance/receipts/view?id=${r.id}`} className="font-medium text-brand-700 hover:underline">{r.receipt_number}</Link>
                  <span className="text-ink-500">{date(r.receipt_date)} · {r.mode.toUpperCase()}</span>
                  <span className="num ml-auto">{inr(r.amount)}{Number(r.tds) ? <span className="text-ink-500"> + TDS {inr(r.tds)}</span> : null}</span>
                </li>))}</ul>
            )}
          </Card>
          <Card title="Credit notes" padded={false}>
            {inv.credit_notes.length === 0 ? <p className="p-4 text-sm text-ink-500">None.</p> : (
              <ul className="divide-y divide-ink-100">{inv.credit_notes.map((c: any) => (
                <li key={c.id} className="px-4 py-3 text-sm">
                  <div className="flex items-center gap-3">
                    <button className="font-medium text-brand-700 hover:underline" onClick={() => download(`/credit-notes/${c.id}/pdf`, `${c.cn_number.replaceAll("/", "-")}.pdf`)}>{c.cn_number}</button>
                    <span className="text-ink-500">{date(c.cn_date)}</span>{c.cancels_invoice && <Badge tone="grey">Cancels invoice</Badge>}
                    <span className="num ml-auto">{inr(c.total)}</span>
                  </div>
                  <p className="text-xs text-ink-500">{c.reason}</p>
                </li>))}</ul>
            )}
          </Card>
        </div>
      )}
      {tab === "documents" && <DocumentsPanel entityType="invoice" entityId={id} canEdit={can.edit || can.irn} defaultCategory="invoice" />}
      {tab === "history" && <HistoryPanel entityType="invoice" entityId={id} />}
      {(dialog === "credit" || dialog === "cancel") && <CreditNoteDialog inv={inv} full={dialog === "cancel"} onClose={() => setDialog(null)} onDone={refresh} />}
      {dialog === "irn" && <IrnDialog inv={inv} onClose={() => setDialog(null)} onDone={refresh} />}
    </>
  );
}

export default function Page() {
  return <Suspense><InvoiceDetail /></Suspense>;
}
