"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader, useToast } from "@/components/ui";
import { InvoiceForm } from "@/components/finance/invoice-form";
import { api } from "@/lib/api/client";

function NewInvoice() {
  const soId = useSearchParams().get("so");
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title="New invoice" subtitle={soId ? "Bill what has been supplied or done on the order. Save as draft, check the PDF, then issue." : "A direct invoice for a customer. Save as draft, then issue."} />
      <InvoiceForm soId={soId} submitLabel="Save draft" onCancel={() => router.back()} onSubmit={async (body) => {
        const r = await api<any>("/invoices", { body });
        toast("Draft invoice saved");
        qc.invalidateQueries({ queryKey: ["/invoices"] });
        router.push(`/sales/invoices/view?id=${r.data.id}`);
      }} />
    </div>
  );
}

export default function Page() {
  return <Suspense><NewInvoice /></Suspense>;
}
