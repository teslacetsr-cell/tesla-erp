"use client";

import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Download, PackageCheck } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { MiniStat } from "@/components/crm/common";
import { SO_STATUSES, SoStatus } from "@/components/projects/common";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function SalesOrdersPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/sales-orders");
  const summary = useQuery({ queryKey: ["/sales-orders/summary"], queryFn: () => api<any>("/sales-orders/summary"), select: (r) => r.data });
  const s = summary.data;
  const status = list.filters.status ?? "";
  return (
    <>
      <PageHeader title="Sales orders" subtitle="Confirmed orders, created from accepted quotations with their prices and terms locked."
        actions={can("sales_order.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/sales-orders/export", "sales-orders.xlsx", { q: list.q, ...list.filters })}>Export</Button>} />
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <MiniStat label="Open order value (before GST)" value={s ? inr(s.open_value, 0) : undefined} />
        <MiniStat label="Confirmed, not started" value={s?.confirmed} tone="amber" onClick={() => list.setFilter("status", "confirmed")} active={status === "confirmed"} />
        <MiniStat label="In progress" value={s?.in_progress} onClick={() => list.setFilter("status", "in_progress")} active={status === "in_progress"} />
        <MiniStat label="Completed" value={s?.completed} onClick={() => list.setFilter("status", "completed")} active={status === "completed"} />
      </div>
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search SO, customer PO, quotation, customer…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={status} onChange={(e) => list.setFilter("status", e.target.value)} className="sm:w-52" aria-label="Status">
            <option value="">All statuses</option>
            {SO_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/sales/orders/view?id=${r.id}`)}
            empty={<EmptyState icon={<PackageCheck className="size-8" />} title={list.q ? "No orders match your search" : "No sales orders yet"} body="When a customer accepts a quotation, open it and choose “Create sales order”." />}
            columns={[
              { key: "n", header: "Order", sortKey: "so_number", cell: (r) => <div><p className="font-medium text-ink-900">{r.subject}</p><p className="text-xs text-ink-500">{r.so_number}</p></div> },
              { key: "c", header: "Customer", cell: (r) => r.customer?.name },
              { key: "d", header: "Date", sortKey: "so_date", hideOnMobile: true, cell: (r) => date(r.so_date) },
              { key: "po", header: "Customer PO", hideOnMobile: true, cell: (r) => r.customer_po_number ?? "—" },
              { key: "t", header: "Order value", sortKey: "grand_total", className: "text-right", cell: (r) => <span className="num">{inr(r.grand_total, 0)}</span> },
              { key: "s", header: "Status", sortKey: "status", cell: (r) => <SoStatus status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
