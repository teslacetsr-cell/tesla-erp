"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Briefcase, CheckCircle2, FileDown, Lock, Pencil, Play, Plus, Trash2, XCircle } from "lucide-react";
import { Badge, Button, Card, Detail, ErrorNote, Field, Input, Modal, PageHeader, Spinner, Tabs, Textarea, useConfirm, useToast } from "@/components/ui";
import { lineProblems, LinesEditor, LinesTable, preview, toPayload, toRows, TotalsBox, type LineRow } from "@/components/lines-editor";
import { ProjectStatus, SoStatus } from "@/components/projects/common";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, dateTime, inr } from "@/lib/format";

type Tab = "order" | "projects" | "documents" | "history";

function DetailsDialog({ so, open, onClose, onSaved }: { so: any; open: boolean; onClose: () => void; onSaved: () => void }) {
  const [v, setV] = useState({ customer_po_number: so.customer_po_number ?? "", customer_po_date: so.customer_po_date ?? "",
    expected_completion: so.expected_completion ?? "", notes: so.notes ?? "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV({ ...v, [k]: e.target.value });
  return (
    <Modal open={open} onClose={onClose} title="Order details"
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setBusy(true);
        try {
          const n = (s: string) => (s.trim() ? s.trim() : null);
          await api(`/sales-orders/${so.id}`, { method: "PUT", body: { customer_po_number: n(v.customer_po_number), customer_po_date: n(v.customer_po_date),
            expected_completion: n(v.expected_completion), notes: n(v.notes), row_version: so.row_version } });
          onSaved();
          onClose();
        } catch (e) { setError(e); } finally { setBusy(false); }
      }}>Save</Button></>}>
      <div className="space-y-3">
        <ErrorNote error={error} />
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Customer PO number"><Input value={v.customer_po_number} onChange={set("customer_po_number")} /></Field>
          <Field label="Customer PO date"><Input type="date" value={v.customer_po_date} onChange={set("customer_po_date")} /></Field>
          <Field label="Expected completion"><Input type="date" value={v.expected_completion} onChange={set("expected_completion")} /></Field>
        </div>
        <Field label="Notes"><Textarea rows={3} value={v.notes} onChange={set("notes")} /></Field>
        <p className="text-xs text-ink-500">Prices, quantities and terms are not changed here — they are locked at confirmation.</p>
      </div>
    </Modal>
  );
}

/** Change lines, rates, discounts or terms of a confirmed order — only with `sales_order_commercial.update`, and with a reason. */
function CommercialEditor({ so, onCancel, onSaved }: { so: any; onCancel: () => void; onSaved: (r: any) => void }) {
  const { can } = useAuth();
  const defaults = useQuery({ queryKey: ["/quotations/defaults"], queryFn: () => api<any>("/quotations/defaults"), select: (r) => r.data, enabled: can("quotation.read") });
  const gstRates: string[] = defaults.data?.gst_rates ?? ["0", "5", "12", "18", "28"];
  const [rows, setRows] = useState<LineRow[]>(() => toRows(so.items));
  const [special, setSpecial] = useState(Number(so.special_discount) ? String(Number(so.special_discount)) : "");
  const [h, setH] = useState({ payment_terms: so.payment_terms ?? "", delivery_terms: so.delivery_terms ?? "", warranty: so.warranty ?? "" });
  const [terms, setTerms] = useState<string[]>(so.terms ?? []);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const calc = preview(rows, so.inter_state, Number(special) || 0, true);
  async function save() {
    setError(null);
    const problem = lineProblems(rows);
    if (problem) return setError(new Error(problem));
    if (reason.trim().length < 5) return setError(new Error("Give the reason for changing a confirmed order (at least 5 characters)."));
    setBusy(true);
    try {
      const n = (s: string) => (s.trim() ? s.trim() : null);
      const r = await api(`/sales-orders/${so.id}/commercial`, { method: "PUT", body: {
        items: toPayload(rows), special_discount: special.trim() || "0", payment_terms: n(h.payment_terms), delivery_terms: n(h.delivery_terms),
        warranty: n(h.warranty), terms: terms.map((t) => t.trim()).filter(Boolean), reason: reason.trim(), row_version: so.row_version } });
      onSaved(r.data);
    } catch (e) { setError(e); window.scrollTo({ top: 0, behavior: "smooth" }); } finally { setBusy(false); }
  }
  return (
    <div className="mx-auto max-w-6xl space-y-5">
      <PageHeader title={`Change prices & terms · ${so.so_number}`} subtitle="Every change is recorded with your reason. Projects running for this order follow the new quantities." />
      <ErrorNote error={error} />
      <Card title="Items">
        <LinesEditor rows={rows} onChange={setRows} gstRates={gstRates} interState={so.inter_state} />
        <div className="mt-5 grid gap-4 border-t border-ink-100 pt-4 lg:grid-cols-[1fr_380px]">
          <Field label="Special discount (₹)" className="max-w-xs"><Input inputMode="decimal" className="num" value={special} onChange={(e) => setSpecial(e.target.value)} placeholder="0" /></Field>
          <TotalsBox interState={so.inter_state} t={{ gross: calc.gross, lineDiscount: calc.lineDiscount, special: calc.special, taxable: calc.taxable, cgst: calc.cgst, sgst: calc.sgst, igst: calc.igst, roundOff: calc.roundOff, grand: calc.grand }} />
        </div>
        <p className="mt-2 text-right text-xs text-ink-500">Was {inr(so.grand_total)} · difference {inr(calc.grand - Number(so.grand_total))}</p>
      </Card>
      <Card title="Commercial terms">
        <div className="grid gap-4 lg:grid-cols-3">
          {([["payment_terms", "Payment"], ["delivery_terms", "Delivery"], ["warranty", "Warranty"]] as const).map(([k, l]) => (
            <Field key={k} label={l}><Textarea rows={4} value={h[k]} onChange={(e) => setH({ ...h, [k]: e.target.value })} /></Field>
          ))}
        </div>
      </Card>
      <Card title="Terms and conditions" actions={<Button size="sm" variant="secondary" icon={<Plus className="size-3.5" />} onClick={() => setTerms([...terms, ""])}>Add clause</Button>}>
        <ol className="space-y-2">
          {terms.map((t, i) => (
            <li key={i} className="flex items-start gap-2">
              <span className="w-5 pt-2 text-right text-sm text-ink-500">{i + 1}.</span>
              <Textarea rows={2} className="flex-1" aria-label={`Clause ${i + 1}`} value={t} onChange={(e) => setTerms(terms.map((x, j) => (j === i ? e.target.value : x)))} />
              <Button variant="ghost" size="sm" aria-label="Remove clause" onClick={() => setTerms(terms.filter((_, j) => j !== i))}><Trash2 className="size-3.5 text-ink-400" /></Button>
            </li>
          ))}
        </ol>
      </Card>
      <Card className="border-amber-300">
        <Field label="Reason for the change" required hint="e.g. “Customer PO revised: 2 SPDs removed” — shown in the order history.">
          <Textarea rows={2} value={reason} onChange={(e) => setReason(e.target.value)} />
        </Field>
      </Card>
      <div className="flex justify-end gap-2">
        <Button variant="secondary" onClick={onCancel}>Cancel</Button>
        <Button loading={busy} onClick={save}>Save changes</Button>
      </div>
    </div>
  );
}

function SalesOrderDetail() {
  const id = useSearchParams().get("id") ?? "";
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [tab, setTab] = useState<Tab>("order");
  const [mode, setMode] = useState<"view" | "commercial">("view");
  const [dialog, setDialog] = useState<"details" | "cancel" | null>(null);
  const [reason, setReason] = useState("");
  const [warnings, setWarnings] = useState<string[]>([]);
  const key = ["/sales-orders", id];
  const { data: so, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api<any>(`/sales-orders/${id}`), select: (r) => r.data });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/sales-orders"] }); qc.invalidateQueries({ queryKey: ["/sales-orders/summary"] }); qc.invalidateQueries({ queryKey: ["/documents", "sales_order", id] }); };
  if (isLoading) return <Spinner />;
  if (error || !so) return <ErrorNote error={error} />;
  const can = so.can;
  const pdfName = `${so.so_number.replaceAll("/", "-")}.pdf`;

  async function status(s: string, r?: string) {
    try {
      await api(`/sales-orders/${id}/status`, { body: { status: s, reason: r ?? null } });
      toast(s === "in_progress" ? "Order started" : s === "completed" ? "Order completed" : "Order cancelled");
      refresh();
    } catch (e: any) { toast(e.message, "error"); }
  }

  if (mode === "commercial")
    return <CommercialEditor so={so} onCancel={() => setMode("view")} onSaved={(r) => {
      toast("Order changed — recorded in the history");
      setWarnings(r.sync_warnings ?? []);
      setMode("view");
      refresh();
      qc.invalidateQueries({ queryKey: ["/projects"] });
    }} />;

  return (
    <>
      <PageHeader
        back={<Link href="/sales/orders" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Sales orders</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{so.subject} <SoStatus status={so.status} /></span>}
        subtitle={`${so.so_number} · ${so.customer?.name}${so.sales_person ? ` · ${so.sales_person}` : ""}`}
        actions={<>
          {can.create_project && <Link href={`/projects/new?so=${so.id}`}><Button icon={<Briefcase className="size-4" />}>Create project</Button></Link>}
          {can.start && <Button variant="secondary" icon={<Play className="size-4" />} onClick={() => status("in_progress")}>Start</Button>}
          {can.complete && <Button variant="secondary" icon={<CheckCircle2 className="size-4" />} onClick={async () => {
            if (await confirm({ title: "Mark the order completed?", body: "Do this when the work is handed over.", confirmLabel: "Complete" })) status("completed");
          }}>Complete</Button>}
          {can.update && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setDialog("details")}>Edit details</Button>}
          {can.commercial && <Button variant="secondary" icon={<Lock className="size-4" />} onClick={() => setMode("commercial")}>Change prices & terms</Button>}
          {can.print && <Button variant="secondary" icon={<FileDown className="size-4" />} onClick={() => download(`/sales-orders/${id}/pdf`, pdfName)}>PDF</Button>}
          {can.cancel && <Button variant="ghost" icon={<XCircle className="size-4" />} onClick={() => { setReason(""); setDialog("cancel"); }}>Cancel order</Button>}
        </>} />

      {warnings.length > 0 && (
        <div className="mb-4 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900">
          <b>Project BOQ updated, with these exceptions:</b>
          <ul className="list-disc pl-5">{warnings.map((w) => <li key={w}>{w}</li>)}</ul>
        </div>
      )}
      {so.status === "cancelled" && so.status_reason && <p className="mb-4 rounded-md bg-ink-100 px-3 py-2 text-sm"><b>Cancelled:</b> {so.status_reason}</p>}

      <div className="mb-4 grid gap-4 lg:grid-cols-[1fr_320px]">
        <Card>
          <Detail cols={4} items={[
            ["Customer", <Link key="c" href={`/customers/view?id=${so.customer_id}`} className="text-brand-700 hover:underline">{so.customer?.name}</Link>],
            ["Quotation", so.quotation_id ? (can.quotation ? <Link key="q" href={`/sales/quotations/view?id=${so.quotation_id}`} className="text-brand-700 hover:underline">{so.quotation_number}</Link> : so.quotation_number) : null],
            ["Order date", date(so.so_date)], ["Site", so.site],
            ["Customer PO", so.customer_po_number ? `${so.customer_po_number}${so.customer_po_date ? ` · ${date(so.customer_po_date)}` : ""}` : null],
            ["Expected completion", date(so.expected_completion)], ["Division", so.division],
            ["Place of supply", so.place_of_supply ? `${so.place_of_supply} · ${so.inter_state ? "IGST" : "CGST + SGST"}` : null],
          ]} />
          {so.notes && <p className="mt-3 whitespace-pre-line border-t border-ink-100 pt-3 text-sm">{so.notes}</p>}
        </Card>
        <Card>
          <p className="text-xs uppercase tracking-wide text-ink-500">Order value</p>
          <p className="num mt-1 text-3xl font-semibold text-ink-900">{inr(so.grand_total, 0)}</p>
          <p className="mt-1 text-sm text-ink-500">{inr(so.taxable, 0)} before GST</p>
          <p className="mt-2 flex items-center gap-1 text-xs text-ink-500"><Lock className="size-3" /> Prices locked{so.commercial_changed_at ? ` · last changed ${dateTime(so.commercial_changed_at)}` : " at confirmation"}</p>
        </Card>
      </div>

      <Tabs<Tab> value={tab} onChange={setTab} tabs={[
        { id: "order", label: "Order" }, { id: "projects", label: "Projects", count: so.projects.length },
        { id: "documents", label: "Documents" }, { id: "history", label: "History" },
      ]} />
      {tab === "order" && (
        <div className="space-y-4">
          <Card title="Items" padded={false}>
            <div className="p-2"><LinesTable items={so.items} /></div>
            <div className="border-t border-ink-100 p-4">
              <TotalsBox interState={so.inter_state} taxSummary={so.tax_summary}
                t={{ gross: so.gross, lineDiscount: so.line_discount, special: so.special_discount, taxable: so.taxable, cgst: so.cgst, sgst: so.sgst, igst: so.igst, roundOff: so.round_off, grand: so.grand_total }} />
            </div>
          </Card>
          <div className="grid gap-4 lg:grid-cols-2">
            <Card title="Commercial terms"><Detail cols={2} items={[["Payment", so.payment_terms], ["Delivery", so.delivery_terms], ["Warranty", so.warranty]]} /></Card>
            <Card title="Terms and conditions">
              {so.terms.length ? <ol className="list-decimal space-y-1 pl-5 text-sm">{so.terms.map((t: string, i: number) => <li key={i}>{t}</li>)}</ol> : <p className="text-sm text-ink-500">None.</p>}
            </Card>
          </div>
        </div>
      )}
      {tab === "projects" && (
        <Card padded={false}>
          {so.projects.length === 0 ? (
            <div className="p-6 text-sm text-ink-500">No project yet.{can.create_project && <> <Link href={`/projects/new?so=${so.id}`} className="font-medium text-brand-700 hover:underline">Create the project</Link> to start execution — its BOQ is copied from this order.</>}</div>
          ) : (
            <ul className="divide-y divide-ink-100">
              {so.projects.map((p: any) => (
                <li key={p.id} className="flex items-center gap-3 px-4 py-3">
                  <Briefcase className="size-4 text-ink-400" />
                  <Link href={`/projects/view?id=${p.id}`} className="flex-1 font-medium text-brand-700 hover:underline">{p.project_number}</Link>
                  <ProjectStatus status={p.status} />
                </li>
              ))}
            </ul>
          )}
        </Card>
      )}
      {tab === "documents" && <DocumentsPanel entityType="sales_order" entityId={id} canEdit={can.update} defaultCategory="po" />}
      {tab === "history" && <HistoryPanel entityType="sales_order" entityId={id} />}

      {dialog === "details" && <DetailsDialog so={so} open onClose={() => setDialog(null)} onSaved={() => { toast("Saved"); refresh(); }} />}
      <Modal open={dialog === "cancel"} onClose={() => setDialog(null)} title="Cancel this sales order?"
        footer={<><Button variant="secondary" onClick={() => setDialog(null)}>Back</Button><Button variant="danger" disabled={!reason.trim()} onClick={async () => { await status("cancelled", reason.trim()); setDialog(null); }}>Cancel order</Button></>}>
        <Field label="Reason" required><Textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
        <p className="mt-2 text-xs text-ink-500">An order with a running project cannot be cancelled — cancel the project first.</p>
      </Modal>
      {so.status === "confirmed" && so.projects.length === 0 && !can.create_project && <p className="mt-4 text-sm text-ink-500"><Badge>Next</Badge> A project manager creates the project from this order.</p>}
    </>
  );
}

export default function Page() {
  return <Suspense><SalesOrderDetail /></Suspense>;
}
