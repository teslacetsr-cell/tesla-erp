"use client";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Bell, Mail, MessageCircle, Smartphone } from "lucide-react";
import { Card, ErrorNote, PageHeader, Spinner, useToast } from "@/components/ui";
import { api } from "@/lib/api/client";

type Ev = {
  key: string; label: string; group: string; description: string; alert: boolean;
  in_app: boolean; email: boolean; whatsapp: boolean; sms: boolean;
};
type Prefs = {
  channels: { email: boolean; whatsapp: boolean; sms: boolean };
  email_address: string; phone: string | null; digest: boolean; groups: string[]; events: Ev[];
};
type Ch = "in_app" | "email" | "whatsapp" | "sms";

function Toggle({ on, disabled, label, onChange }: { on: boolean; disabled?: boolean; label: string; onChange: (v: boolean) => void }) {
  return (
    <button type="button" role="switch" aria-checked={on} aria-label={label} title={label} disabled={disabled}
      onClick={(e) => { e.preventDefault(); onChange(!on); }}
      className={`relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors disabled:cursor-not-allowed disabled:opacity-40 ${on ? "bg-brand-600" : "bg-ink-300"}`}>
      <span className={`inline-block size-4 rounded-full bg-white shadow transition-transform ${on ? "translate-x-4.5" : "translate-x-0.5"}`} />
    </button>
  );
}

/** My notification settings: for every kind of notification, whether it shows in the bell and whether it is emailed. */
export default function NotificationSettings() {
  const qc = useQueryClient();
  const toast = useToast();
  const { data, isLoading, error } = useQuery({
    queryKey: ["/notifications/preferences"],
    queryFn: () => api<{ data: Prefs }>("/notifications/preferences"),
    select: (r) => r.data,
  });
  if (isLoading) return <Spinner />;
  if (error || !data) return <ErrorNote error={error} />;
  const cols: [Ch, string, typeof Bell][] = [["in_app", "In the ERP", Bell], ["email", "Email", Mail]];
  if (data.channels.whatsapp) cols.push(["whatsapp", "WhatsApp", MessageCircle]);
  if (data.channels.sms) cols.push(["sms", "SMS", Smartphone]);

  const save = async (body: object, msg = "Saved") => {
    try {
      const r = await api<{ data: Prefs }>("/notifications/preferences", { method: "PUT", body });
      qc.setQueryData(["/notifications/preferences"], r);
      toast(msg);
    } catch (e: any) { toast(e.message, "error"); }
  };
  const setOne = (ev: Ev, ch: Ch, v: boolean) =>
    save({ items: [{ event: ev.key, in_app: ev.in_app, email: ev.email, whatsapp: ev.whatsapp, sms: ev.sms, [ch]: v }] });
  const setGroup = (group: string, ch: Ch, v: boolean) =>
    save({ items: data.events.filter((e) => e.group === group).map((e) => ({ event: e.key, in_app: e.in_app, email: e.email, whatsapp: e.whatsapp, sms: e.sms, [ch]: v })) });

  return (
    <>
      <PageHeader title="My notification settings" subtitle="Choose what reaches you in the ERP (the bell) and by email." />
      <div className="space-y-5">
        <Card>
          <div className="space-y-3 text-sm">
            {data.channels.email ? (
              <p className="text-ink-700">Emails go to <span className="font-medium">{data.email_address}</span>. To change it, ask your administrator.</p>
            ) : (
              <p className="rounded-md bg-amber-50 px-3 py-2 text-amber-800">Email is not set up on the server yet, so only notifications in the ERP are sent. Your email choices are kept for when it is.</p>
            )}
            <label className="flex items-start justify-between gap-4">
              <span>
                <span className="block font-medium text-ink-900">Daily summary email</span>
                <span className="block text-xs text-ink-500">One email a day with your alerts (overdue invoices, tasks, low stock…) and anything unread, instead of a separate email for each alert.</span>
              </span>
              <Toggle on={data.digest} label="Daily summary email" onChange={(v) => save({ digest: v }, v ? "Daily summary switched on" : "Daily summary switched off")} />
            </label>
          </div>
        </Card>
        {data.groups.map((g) => {
          const evs = data.events.filter((e) => e.group === g);
          if (!evs.length) return null;
          return (
            <Card key={g} title={g} padded={false}>
              <div className="hidden grid-cols-[1fr_repeat(var(--n),5.5rem)] items-center gap-2 border-b border-ink-100 bg-ink-50/60 px-4 py-2 text-xs font-medium uppercase tracking-wide text-ink-500 sm:grid"
                style={{ ["--n" as any]: cols.length }}>
                <span>Notification</span>
                {cols.map(([ch, label]) => (
                  <span key={ch} className="flex flex-col items-center gap-1 text-center">
                    {label}
                    <span className="flex gap-1 normal-case tracking-normal">
                      <button type="button" className="text-[11px] font-medium text-brand-700 hover:underline" onClick={(e) => { e.preventDefault(); setGroup(g, ch, true); }}>all</button>
                      <span className="text-ink-300">·</span>
                      <button type="button" className="text-[11px] font-medium text-brand-700 hover:underline" onClick={(e) => { e.preventDefault(); setGroup(g, ch, false); }}>none</button>
                    </span>
                  </span>
                ))}
              </div>
              <ul className="divide-y divide-ink-100">
                {evs.map((ev) => (
                  <li key={ev.key} className="grid grid-cols-1 gap-2 px-4 py-3 sm:grid-cols-[1fr_repeat(var(--n),5.5rem)] sm:items-center" style={{ ["--n" as any]: cols.length }}>
                    <span>
                      <span className="block text-sm font-medium text-ink-900">{ev.label}</span>
                      <span className="block text-xs text-ink-500">{ev.description}</span>
                    </span>
                    {cols.map(([ch, label, Icon]) => (
                      <span key={ch} className="flex items-center gap-2 sm:justify-center">
                        <Icon className="size-3.5 text-ink-400 sm:hidden" />
                        <span className="text-xs text-ink-600 sm:hidden">{label}</span>
                        <Toggle on={ev[ch]} label={`${ev.label}: ${label}`} onChange={(v) => setOne(ev, ch, v)} />
                      </span>
                    ))}
                  </li>
                ))}
              </ul>
            </Card>
          );
        })}
      </div>
    </>
  );
}
