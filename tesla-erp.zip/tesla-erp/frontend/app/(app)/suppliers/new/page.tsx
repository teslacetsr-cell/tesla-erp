"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader, useToast } from "@/components/ui";
import { SectionForm } from "@/components/section-form";
import { SUPPLIER_SECTIONS } from "@/components/suppliers/sections";
import { api } from "@/lib/api/client";

export default function NewSupplierPage() {
  const router = useRouter();
  const toast = useToast();
  const qc = useQueryClient();
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader back={<Link href="/suppliers" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Suppliers</Link>} title="New supplier" />
      <SectionForm sections={SUPPLIER_SECTIONS} gstinAutofill submitLabel="Create supplier" onCancel={() => router.push("/suppliers")}
        onSubmit={async (values) => {
          const r = await api("/suppliers", { body: values });
          qc.invalidateQueries({ queryKey: ["/suppliers"] });
          toast(`Supplier ${r.data.supplier_code} created`);
          router.push(`/suppliers/view?id=${r.data.id}`);
        }} />
    </div>
  );
}
