"use client";

import Link from "next/link";
import { useSearchParams, useRouter } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Lock, Pencil, Trash2 } from "lucide-react";
import { Badge, Button, Card, Detail, ErrorNote, PageHeader, Spinner, StatusBadge, Tabs, useConfirm, useToast } from "@/components/ui";
import { ChildEditor, type FieldDef } from "@/components/record-form";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { SectionForm } from "@/components/section-form";
import { SUPPLIER_SECTIONS } from "@/components/suppliers/sections";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { titleCase } from "@/lib/format";

const CONTACT: FieldDef[] = [
  { name: "name", label: "Name", required: true }, { name: "designation", label: "Designation" },
  { name: "phone", label: "Phone" }, { name: "email", label: "Email" },
  { name: "is_primary", label: "Primary contact", type: "checkbox" }, { name: "is_active", label: "Active", type: "checkbox" },
];
const ADDR: FieldDef[] = [
  { name: "address_type", label: "Type", type: "select", options: [["dispatch", "Dispatch"], ["office", "Office"], ["warehouse", "Warehouse"], ["other", "Other"]] },
  { name: "label", label: "Label" }, { name: "gstin", label: "GSTIN", span: 2, upper: true },
  { name: "address_line1", label: "Address line 1", span: 2 }, { name: "city", label: "City" }, { name: "state_code", label: "State", type: "state" },
  { name: "pincode", label: "PIN code" }, { name: "is_active", label: "Active", type: "checkbox" },
];
const BANK: FieldDef[] = [
  { name: "account_name", label: "Account holder name", required: true, span: 2 }, { name: "bank_name", label: "Bank", required: true },
  { name: "branch", label: "Branch" }, { name: "account_number", label: "Account number", required: true }, { name: "ifsc", label: "IFSC", required: true, upper: true },
  { name: "is_primary", label: "Primary account", type: "checkbox" }, { name: "is_active", label: "Active", type: "checkbox" },
];

type Tab = "overview" | "contacts" | "addresses" | "bank" | "documents" | "history";

function SupplierDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const { can } = useAuth();
  const [tab, setTab] = useState<Tab>("overview");
  const [editing, setEditing] = useState(false);
  const key = ["/suppliers", id];
  const { data, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api(`/suppliers/${id}`) });
  const refresh = () => qc.invalidateQueries({ queryKey: key });
  if (isLoading) return <Spinner />;
  if (error || !data) return <ErrorNote error={error} />;
  const s = data.data;
  const canEdit = can("supplier.update");

  if (editing)
    return (
      <div className="mx-auto max-w-4xl">
        <PageHeader title={`Edit ${s.supplier_name}`} subtitle={s.supplier_code} />
        <SectionForm sections={SUPPLIER_SECTIONS} initial={s} gstinAutofill submitLabel="Save changes" onCancel={() => setEditing(false)}
          onSubmit={async (values) => {
            await api(`/suppliers/${id}`, { method: "PUT", body: { ...values, row_version: s.row_version } });
            toast("Supplier saved");
            setEditing(false);
            refresh();
          }} />
      </div>
    );

  return (
    <>
      <PageHeader
        back={<Link href="/suppliers" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Suppliers</Link>}
        title={<span className="flex items-center gap-2">{s.supplier_name} <StatusBadge status={s.status} /></span>}
        subtitle={`${s.supplier_code}${s.supplies ? ` · ${s.supplies}` : ""}`}
        actions={<>
          {can("payable.read") && <Link href={`/finance/statement?type=supplier&id=${id}`}><Button variant="secondary">Statement</Button></Link>}
          {canEdit && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {can("supplier.delete") && <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Delete supplier?", body: "Only suppliers with no linked records can be deleted. Otherwise set the status to Inactive.", confirmLabel: "Delete" }))) return;
            try { await api(`/suppliers/${id}`, { method: "DELETE" }); toast("Supplier deleted"); router.push("/suppliers"); } catch (e: any) { toast(e.message, "error"); }
          }}>Delete</Button>}
        </>}
      />
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[
        { id: "overview", label: "Overview" }, { id: "contacts", label: "Contacts", count: s.contacts.length },
        { id: "addresses", label: "Addresses", count: s.addresses.length }, { id: "bank", label: "Bank accounts", count: s.bank_accounts.length },
        { id: "documents", label: "Documents" }, { id: "history", label: "History" },
      ]} />
      {tab === "overview" && (
        <div className="space-y-4">
          <Card title="Details">
            <Detail items={[
              ["GSTIN", s.gstin && <span className="font-mono">{s.gstin}</span>], ["PAN", s.pan && <span className="font-mono">{s.pan}</span>],
              ["Rating", s.rating ? `${Number(s.rating).toFixed(1)} / 5` : null], ["Phone", s.phone], ["Email", s.email], ["Website", s.website],
              ["Address", [s.address_line1, s.address_line2, s.city, s.state, s.pincode].filter(Boolean).join(", ")],
              ["Payment terms", s.payment_terms], ["Credit days", s.credit_days], ["Notes", s.notes],
            ]} />
          </Card>
          <div className="flex flex-wrap gap-1.5">{["Purchase orders", "GRNs", "Supplier invoices", "Payments"].map((x) => <Badge key={x}>{x} — Phase 5–7</Badge>)}</div>
        </div>
      )}
      {tab === "contacts" && <ChildEditor title="Contacts" noun="contact" rows={s.contacts} fields={CONTACT} basePath={`/suppliers/${id}/contacts`} canEdit={canEdit} onChanged={refresh}
        columns={[{ key: "n", header: "Name", cell: (r: any) => <span className="font-medium">{r.name}{r.is_primary && <span className="ml-2"><Badge tone="red">Primary</Badge></span>}</span> },
          { key: "p", header: "Phone", cell: (r: any) => r.phone ?? "—" }, { key: "e", header: "Email", hideOnMobile: true, cell: (r: any) => r.email ?? "—" }]} />}
      {tab === "addresses" && <ChildEditor title="Addresses" noun="address" rows={s.addresses} fields={ADDR} basePath={`/suppliers/${id}/addresses`} canEdit={canEdit} onChanged={refresh}
        columns={[{ key: "t", header: "Type", cell: (r: any) => titleCase(r.address_type) }, { key: "a", header: "Address", cell: (r: any) => [r.address_line1, r.city, r.state].filter(Boolean).join(", ") || "—" }]} />}
      {tab === "bank" && (
        <>
          {!s.can_view_bank_details && <p className="mb-3 flex items-center gap-1.5 text-sm text-ink-500"><Lock className="size-3.5" /> Account numbers are masked. Accounts staff can see them in full.</p>}
          <ChildEditor title="Bank accounts" noun="bank account" rows={s.bank_accounts} fields={BANK} basePath={`/suppliers/${id}/bank-accounts`} canEdit={can("supplier_bank.update")} onChanged={refresh}
            columns={[{ key: "b", header: "Bank", cell: (r: any) => <span className="font-medium">{r.bank_name}{r.is_primary && <span className="ml-2"><Badge tone="red">Primary</Badge></span>}</span> },
              { key: "a", header: "Account", cell: (r: any) => <span className="font-mono text-xs">{r.account_number}</span> }, { key: "i", header: "IFSC", cell: (r: any) => <span className="font-mono text-xs">{r.ifsc}</span> },
              { key: "h", header: "Holder", hideOnMobile: true, cell: (r: any) => r.account_name }]} />
        </>
      )}
      {tab === "documents" && <DocumentsPanel entityType="supplier" entityId={id} canEdit={canEdit} defaultCategory="supplier_document" />}
      {tab === "history" && <HistoryPanel entityType="supplier" entityId={id} />}
    </>
  );
}

// Record id comes from ?id= so the UI can be exported as static files (served by the on-premise server).
export default function Page() {
  return (
    <Suspense>
      <SupplierDetail />
    </Suspense>
  );
}
