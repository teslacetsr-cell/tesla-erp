"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Download, Plus, Star, Truck, Upload } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner, StatusBadge } from "@/components/ui";
import { ImportDialog } from "@/components/import-dialog";
import { download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { useList } from "@/lib/hooks";

type Row = { id: string; supplier_code: string; supplier_name: string; gstin: string | null; phone: string | null; city: string | null; state: string | null; supplies: string | null; rating: string | null; status: string };

export default function SuppliersPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<Row>("/suppliers");
  const [importing, setImporting] = useState(false);
  return (
    <>
      <PageHeader
        title="Suppliers"
        subtitle="Vendors for purchase orders, goods receipts and payments."
        actions={
          <>
            {can("supplier.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download("/suppliers/export", "suppliers.xlsx")}>Export</Button>}
            {can("supplier.create") && (
              <>
                <Button variant="secondary" icon={<Upload className="size-4" />} onClick={() => setImporting(true)}>Import</Button>
                <Link href="/suppliers/new"><Button icon={<Plus className="size-4" />}>New supplier</Button></Link>
              </>
            )}
          </>
        }
      />
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search name, code, GSTIN, what they supply…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={list.filters.status ?? ""} onChange={(e) => list.setFilter("status", e.target.value)} className="sm:w-36">
            <option value="">Any status</option><option value="active">Active</option><option value="inactive">Inactive</option><option value="blocked">Blocked</option>
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/suppliers/view?id=${r.id}`)}
            empty={<EmptyState icon={<Truck className="size-8" />} title="No suppliers found" />}
            columns={[
              { key: "n", header: "Supplier", sortKey: "supplier_name", cell: (r) => <div><p className="font-medium">{r.supplier_name}</p><p className="text-xs text-ink-500">{r.supplier_code}</p></div> },
              { key: "s", header: "Supplies", hideOnMobile: true, cell: (r) => <span className="text-ink-600">{r.supplies ?? "—"}</span> },
              { key: "l", header: "Location", sortKey: "city", hideOnMobile: true, cell: (r) => [r.city, r.state].filter(Boolean).join(", ") || "—" },
              { key: "r", header: "Rating", sortKey: "rating", hideOnMobile: true, cell: (r) => r.rating ? <span className="inline-flex items-center gap-1 num"><Star className="size-3.5 fill-amber-400 text-amber-400" />{Number(r.rating).toFixed(1)}</span> : "—" },
              { key: "st", header: "Status", cell: (r) => <StatusBadge status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
      <ImportDialog open={importing} onClose={() => setImporting(false)} base="/suppliers" noun="suppliers" />
    </>
  );
}
