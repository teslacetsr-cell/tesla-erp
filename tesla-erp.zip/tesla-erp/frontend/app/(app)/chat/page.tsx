"use client";

import { Suspense } from "react";
import { ChatApp } from "@/components/chat/chat-app";
import { Spinner } from "@/components/ui";

export default function ChatPage() {
  return (
    <Suspense fallback={<Spinner />}>
      <ChatApp />
    </Suspense>
  );
}
