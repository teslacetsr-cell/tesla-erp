"use client";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ClipboardList } from "lucide-react";
import { Card, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { ReportCard } from "@/components/projects/report-card";
import { api, type Page } from "@/lib/api/client";
import { useList } from "@/lib/hooks";

/** Daily site reports across the projects the user can see — newest first. */
export default function SiteReportsPage() {
  const qc = useQueryClient();
  const list = useList<any>("/site-reports");
  const projects = useQuery({
    queryKey: ["/projects", "options"],
    queryFn: () => api<Page<any>>("/projects", { params: { page_size: 200, open_only: true } }),
    select: (r) => r.data,
  });
  return (
    <>
      <PageHeader title="Site reports" subtitle="What happened on site each day: work done, manpower, installation, hindrances and photos. Add reports from the project." />
      <Card padded={false} className="mb-4">
        <div className="flex flex-col gap-2 p-3 sm:flex-row">
          <Input placeholder="Search work done or project…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-xs" />
          <Select value={list.filters.project_id ?? ""} onChange={(e) => list.setFilter("project_id", e.target.value)} className="sm:w-72" aria-label="Project">
            <option value="">All projects</option>
            {(projects.data ?? []).map((p) => <option key={p.id} value={p.id}>{p.project_number} · {p.name}</option>)}
          </Select>
          <Input type="date" aria-label="From" value={list.filters.date_from ?? ""} onChange={(e) => list.setFilter("date_from", e.target.value)} className="sm:w-40" />
          <Input type="date" aria-label="To" value={list.filters.date_to ?? ""} onChange={(e) => list.setFilter("date_to", e.target.value)} className="sm:w-40" />
        </div>
      </Card>
      {list.isLoading ? <Spinner /> : list.rows.length === 0 ? (
        <Card><EmptyState icon={<ClipboardList className="size-8" />} title="No site reports" body="Open a project and choose Site reports → New site report." /></Card>
      ) : (
        <div className="space-y-4">
          {list.rows.map((r) => <ReportCard key={r.id} r={r} showProject onChanged={() => qc.invalidateQueries({ queryKey: ["/site-reports"] })} />)}
        </div>
      )}
      {list.meta && list.meta.total > list.meta.page_size && <Card padded={false} className="mt-4"><Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} /></Card>}
    </>
  );
}
