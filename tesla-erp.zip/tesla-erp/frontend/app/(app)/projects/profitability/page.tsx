"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Download, TrendingUp } from "lucide-react";
import { Button, Card, DataTable, EmptyState, PageHeader, Select, Spinner } from "@/components/ui";
import { ProjectStatus } from "@/components/projects/common";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { inr } from "@/lib/format";

const pct = (v: string | null) => (v == null ? "—" : `${v}%`);

export default function ProfitabilityPage() {
  const router = useRouter();
  const { can } = useAuth();
  const [status, setStatus] = useState("open");
  const q = useQuery({ queryKey: ["/project-profitability", status], queryFn: () => api<any>("/project-profitability", { params: { status } }), select: (r) => r.data as any[] });
  const rows = q.data ?? [];
  const tot = (k: string) => rows.reduce((s, r) => s + Number(r[k] ?? 0), 0);
  return (
    <>
      <PageHeader title="Project profitability" subtitle="Contract and billing against material, labour, subcontract, travel and other costs — estimated vs actual (before GST)."
        actions={can("project_cost.export") && <Button variant="ghost" icon={<Download className="size-4" />} onClick={() => download("/project-profitability/export", "project-profitability.xlsx", { status })}>Export</Button>} />
      {rows.length > 0 && (
        <div className="mb-4 grid gap-3 sm:grid-cols-4">
          {[["Contract value", tot("contract_value")], ["Billed", tot("billed")], ["Actual cost", tot("actual_cost")], ["Gross profit so far", tot("actual_profit")]].map(([l, v]) => (
            <Card key={l as string}><p className="text-xs text-ink-500">{l}</p><p className={`num mt-1 text-xl font-semibold ${Number(v) < 0 ? "text-brand-700" : ""}`}>{inr(v as number, 0)}</p></Card>
          ))}
        </div>
      )}
      <Card padded={false}>
        <div className="flex gap-2 border-b border-ink-100 p-3">
          <Select value={status} onChange={(e) => setStatus(e.target.value)} className="sm:w-48" aria-label="Projects">
            <option value="open">Open projects</option><option value="">All projects</option>
          </Select>
        </div>
        {q.isLoading ? <Spinner /> : (
          <DataTable rows={rows} onRowClick={(r) => router.push(`/projects/view?id=${r.id}&tab=costs`)}
            empty={<EmptyState icon={<TrendingUp className="size-8" />} title="No projects" />}
            columns={[
              { key: "p", header: "Project", cell: (r) => <div><p className="font-medium text-ink-900">{r.project_number}</p><p className="text-xs text-ink-500">{r.name}</p></div> },
              { key: "s", header: "Status", hideOnMobile: true, cell: (r) => <ProjectStatus status={r.status} /> },
              { key: "c", header: "Contract", hideOnMobile: true, cell: (r) => <span className="num">{inr(r.contract_value, 0)}</span> },
              { key: "b", header: "Billed", cell: (r) => <span className="num">{inr(r.billed, 0)}</span> },
              { key: "m", header: "Material", hideOnMobile: true, cell: (r) => <span className="num">{inr(r.material_cost, 0)}</span> },
              { key: "l", header: "Labour & other", hideOnMobile: true, cell: (r) => <span className="num">{inr(Number(r.actual_cost) - Number(r.material_cost), 0)}</span> },
              { key: "a", header: "Actual cost", cell: (r) => <div className="num"><p>{inr(r.actual_cost, 0)}</p><p className="text-xs text-ink-500">{r.cost_to_date_pct != null ? `${r.cost_to_date_pct}% of est. · ${r.progress_pct}% done` : `of est. ${inr(r.estimated_cost, 0)}`}</p></div> },
              { key: "g", header: "Gross profit", cell: (r) => <div className="num"><p className={Number(r.actual_profit) < 0 ? "text-brand-700" : "text-emerald-700"}>{inr(r.actual_profit, 0)}</p><p className="text-xs text-ink-500">{pct(r.actual_margin_pct)} · est. {pct(r.estimated_margin_pct)}</p></div> },
            ]} />
        )}
      </Card>
    </>
  );
}
