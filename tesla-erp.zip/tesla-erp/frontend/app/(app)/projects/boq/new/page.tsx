"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import { Button, Card, ErrorNote, Field, Input, PageHeader, Select, Spinner, Textarea, useToast } from "@/components/ui";
import { CustomerPicker, useCustomerDetail, useDivisionOptions, type CustomerRef } from "@/components/crm/common";
import { api } from "@/lib/api/client";

function NewBoq() {
  const router = useRouter();
  const toast = useToast();
  const qc = useQueryClient();
  const enquiryId = useSearchParams().get("enquiry_id");
  const enq = useQuery({ queryKey: ["/enquiries", enquiryId], queryFn: () => api<any>(`/enquiries/${enquiryId}`), select: (r) => r.data, enabled: !!enquiryId });
  const [customer, setCustomer] = useState<CustomerRef | null>(null);
  const [title, setTitle] = useState("");
  const [siteId, setSiteId] = useState("");
  const [divisionId, setDivisionId] = useState("");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  const divisions = useDivisionOptions();
  const e = enq.data;
  const cust = e ? { id: e.customer.id, name: e.customer.name, code: e.customer.code, city: e.customer.city } : customer;
  const detail = useCustomerDetail(cust?.id);
  if (enquiryId && enq.isLoading) return <Spinner />;
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader back={<Link href={e ? `/crm/enquiries/view?id=${e.id}` : "/projects/boq"} className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> {e ? e.enquiry_number : "BOQs"}</Link>}
        title="New BOQ" subtitle="Add the lines on the next screen — by hand, from the item master, or by importing an Excel BOQ." />
      <Card>
        <form className="space-y-4" onSubmit={async (ev) => {
          ev.preventDefault();
          setError(null);
          setBusy(true);
          try {
            const r = await api("/boqs", { body: { title: title || e?.subject, enquiry_id: e?.id ?? null, customer_id: cust?.id ?? null, site_id: siteId || e?.site_id || null, division_id: divisionId || e?.division_id || null, notes: notes || null } });
            qc.invalidateQueries({ queryKey: ["/boqs"] });
            toast(`BOQ ${r.data.boq_number} created`);
            router.push(`/projects/boq/view?id=${r.data.id}`);
          } catch (err) { setError(err); } finally { setBusy(false); }
        }}>
          <ErrorNote error={error} />
          <Field label="Title" required><Input value={title || (e?.subject ?? "")} onChange={(x) => setTitle(x.target.value)} placeholder="e.g. LPS for ABC Hospital main block" /></Field>
          <Field label="Customer" hint={e ? `From enquiry ${e.enquiry_number}` : "Optional — a BOQ can be prepared before the customer is known"}>
            <CustomerPicker value={cust} disabled={!!e} onChange={(c) => { setCustomer(c); setSiteId(""); }} />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Site">
              <Select value={siteId || e?.site_id || ""} onChange={(x) => setSiteId(x.target.value)} disabled={!cust}>
                <option value="">—</option>
                {detail.data?.sites?.map((s: any) => <option key={s.id} value={s.id}>{s.site_name}</option>)}
              </Select>
            </Field>
            <Field label="Business division">
              <Select value={divisionId || e?.division_id || ""} onChange={(x) => setDivisionId(x.target.value)}>
                {divisions.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </Select>
            </Field>
          </div>
          <Field label="Notes"><Textarea rows={2} value={notes} onChange={(x) => setNotes(x.target.value)} /></Field>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="secondary" onClick={() => router.back()}>Cancel</Button>
            <Button type="submit" loading={busy}>Create BOQ</Button>
          </div>
        </form>
      </Card>
    </div>
  );
}

export default function Page() {
  return <Suspense><NewBoq /></Suspense>;
}
