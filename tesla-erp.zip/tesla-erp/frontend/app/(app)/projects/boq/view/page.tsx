"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Copy, Download, FileSpreadsheet, FileText, Lock, Save, Trash2, Unlock, Upload } from "lucide-react";
import { Badge, Button, Card, Detail, ErrorNote, Modal, PageHeader, Spinner, Tabs, useConfirm, useToast } from "@/components/ui";
import { lineProblems, LinesEditor, preview, toPayload, toRows, TotalsBox, type LineRow } from "@/components/lines-editor";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api, ApiError, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { dateTime, inr } from "@/lib/format";

function ImportDialog({ boq, open, onClose, onDone }: { boq: any; open: boolean; onClose: () => void; onDone: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [mode, setMode] = useState<"append" | "replace">("append");
  const [report, setReport] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => { if (open) { setFile(null); setReport(null); setError(null); } }, [open]);
  async function run(dryRun: boolean) {
    if (!file) return;
    setBusy(true);
    setError(null);
    try {
      const form = new FormData();
      form.append("file", file);
      const r = await api(`/boqs/${boq.id}/import`, { method: "POST", form, params: { dry_run: dryRun, mode } });
      setReport(r.data);
      if (r.data.committed) onDone();
    } catch (e) { setError(e); } finally { setBusy(false); }
  }
  return (
    <Modal open={open} onClose={onClose} title="Import BOQ lines from Excel" wide
      footer={report?.committed ? <Button onClick={onClose}>Close</Button> : <>
        <Button variant="secondary" onClick={onClose}>Cancel</Button>
        {report && !report.errors.length ? <Button loading={busy} onClick={() => run(false)}>Import {report.valid} lines</Button>
          : <Button loading={busy} disabled={!file} onClick={() => run(true)}>Check file</Button>}
      </>}>
      <div className="space-y-4 text-sm">
        <ErrorNote error={error} />
        <p>Use the template. The columns are Section, Item code, Description, Qty, Unit, Rate, Discount % and GST %. An item code fills the description, unit, rate and GST from the item master. Nothing is saved until every row is valid.</p>
        <Button variant="secondary" size="sm" icon={<FileSpreadsheet className="size-4" />} onClick={() => download("/boqs/import-template", "boq-import-template.xlsx")}>Download template</Button>
        <div className="flex flex-wrap items-center gap-3">
          <Button variant="secondary" size="sm" icon={<Upload className="size-4" />} onClick={() => input.current?.click()}>{file ? file.name : "Choose .xlsx file"}</Button>
          <input ref={input} type="file" accept=".xlsx" className="sr-only" onChange={(e) => { setFile(e.target.files?.[0] ?? null); setReport(null); }} />
          <label className="flex items-center gap-1.5"><input type="radio" checked={mode === "append"} onChange={() => { setMode("append"); setReport(null); }} className="accent-brand-600" /> Add to existing lines</label>
          <label className="flex items-center gap-1.5"><input type="radio" checked={mode === "replace"} onChange={() => { setMode("replace"); setReport(null); }} className="accent-brand-600" /> Replace all lines</label>
        </div>
        {report && (
          report.committed ? <p className="rounded-md bg-emerald-50 px-3 py-2 text-emerald-800">Imported {report.valid} lines. The BOQ now has {report.lines_after} lines.</p>
            : report.errors.length ? (
              <div>
                <p className="mb-2 font-medium text-brand-700">{report.errors.length} problem(s) — fix them in Excel and check again:</p>
                <ul className="max-h-60 space-y-1 overflow-y-auto rounded-md border border-ink-200 p-2">
                  {report.errors.map((e: any, i: number) => <li key={i}><span className="font-medium">Row {e.row}</span>{e.field ? ` · ${e.field}` : ""}: {e.message}</li>)}
                </ul>
              </div>
            ) : <p className="rounded-md bg-ink-50 px-3 py-2">All {report.valid} rows are valid. After import: {report.lines_after} lines, {inr(report.totals?.taxable ?? 0)} before GST.</p>
        )}
      </div>
    </Modal>
  );
}

type Tab = "lines" | "documents" | "history";

function BoqDetail() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const { can } = useAuth();
  const key = ["/boqs", id];
  const { data, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api(`/boqs/${id}`), select: (r: any) => r.data });
  const opts = useQuery({ queryKey: ["/boqs/options"], queryFn: () => api<any>("/boqs/options"), select: (r) => r.data });
  const [rows, setRows] = useState<LineRow[]>([]);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<unknown>(null);
  const [importing, setImporting] = useState(false);
  const [tab, setTab] = useState<Tab>("lines");
  useEffect(() => { if (data && !dirty) setRows(toRows(data.items)); }, [data, dirty]);
  useEffect(() => {
    const warn = (e: BeforeUnloadEvent) => { if (dirty) e.preventDefault(); };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);
  if (isLoading) return <Spinner />;
  if (error || !data) return <ErrorNote error={error} />;
  const b = data;
  const editable = b.status === "draft" && can("boq.update");
  const calc = preview(rows, b.inter_state, 0, false);
  const refresh = () => { qc.invalidateQueries({ queryKey: key }); qc.invalidateQueries({ queryKey: ["/boqs"] }); };

  async function save() {
    const problem = lineProblems(rows);
    if (problem) return setSaveError(new Error(problem));
    setSaving(true);
    setSaveError(null);
    try {
      await api(`/boqs/${id}`, { method: "PUT", body: { title: b.title, customer_id: b.customer_id, enquiry_id: b.enquiry_id, site_id: b.site_id, division_id: b.division_id, notes: b.notes, items: toPayload(rows), row_version: b.row_version } });
      setDirty(false);
      toast("BOQ saved");
      refresh();
    } catch (e) {
      setSaveError(e);
    } finally { setSaving(false); }
  }

  return (
    <>
      <PageHeader
        back={<Link href="/projects/boq" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> BOQs</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{b.title} <Badge tone={b.status === "final" ? "green" : "grey"}>{b.status === "final" ? "Final" : "Draft"}</Badge></span>}
        subtitle={`${b.boq_number}${b.customer ? ` · ${b.customer.name}` : ""}${b.enquiry_number ? ` · ${b.enquiry_number}` : ""}`}
        actions={<>
          {editable && <Button icon={<Save className="size-4" />} loading={saving} disabled={!dirty} onClick={save}>{dirty ? "Save changes" : "Saved"}</Button>}
          {can("quotation.create") && b.customer_id && !dirty && <Link href={`/sales/quotations/new?boq_id=${id}`}><Button variant={editable ? "secondary" : "primary"} icon={<FileText className="size-4" />}>Create quotation</Button></Link>}
          {editable && <Button variant="secondary" icon={<Upload className="size-4" />} onClick={() => setImporting(true)} disabled={dirty}>Import Excel</Button>}
          {can("boq.export") && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download(`/boqs/${id}/export`, `${b.boq_number}.xlsx`)}>Excel</Button>}
          {can("boq.print") && <Button variant="secondary" icon={<FileText className="size-4" />} onClick={() => download(`/boqs/${id}/pdf`, `${b.boq_number}.pdf`)}>PDF</Button>}
          {can("boq.update") && !dirty && (b.status === "draft"
            ? <Button variant="ghost" icon={<Lock className="size-4" />} onClick={async () => { try { await api(`/boqs/${id}/status`, { body: { status: "final" } }); toast("BOQ marked final"); refresh(); } catch (e: any) { toast(e.message, "error"); } }}>Mark final</Button>
            : <Button variant="ghost" icon={<Unlock className="size-4" />} onClick={async () => { try { await api(`/boqs/${id}/status`, { body: { status: "draft" } }); refresh(); } catch (e: any) { toast(e.message, "error"); } }}>Reopen as draft</Button>)}
          {can("boq.create") && <Button variant="ghost" icon={<Copy className="size-4" />} onClick={async () => { try { const r = await api(`/boqs/${id}/copy`, { method: "POST" }); toast(`Copied to ${r.data.boq_number}`); router.push(`/projects/boq/view?id=${r.data.id}`); } catch (e: any) { toast(e.message, "error"); } }}>Copy</Button>}
          {can("boq.delete") && (
            <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
              if (!(await confirm({ title: "Delete BOQ?", body: "A BOQ that quotations were made from cannot be deleted.", confirmLabel: "Delete" }))) return;
              try { await api(`/boqs/${id}`, { method: "DELETE" }); qc.invalidateQueries({ queryKey: ["/boqs"] }); router.push("/projects/boq"); } catch (e: any) { toast(e.message, "error"); }
            }}>Delete</Button>
          )}
        </>} />
      {b.status === "final" && <p className="mb-4 rounded-md bg-ink-100 px-3 py-2 text-sm text-ink-600">This BOQ is final and can't be edited. Reopen it as a draft, or copy it, to make changes.</p>}
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[{ id: "lines", label: "Lines", count: rows.length }, { id: "documents", label: "Documents" }, { id: "history", label: "History" }]} />
      {tab === "lines" && (
        <div className="space-y-4">
          <ErrorNote error={saveError} />
          <Card padded>
            <LinesEditor rows={rows} onChange={(r) => { setRows(r); setDirty(true); }} gstRates={opts.data?.gst_rates ?? ["0", "5", "12", "18", "28"]} interState={b.inter_state} readOnly={!editable} />
          </Card>
          <div className="grid gap-4 lg:grid-cols-[1fr_380px]">
            <Card title="Details">
              <Detail cols={2} items={[
                ["Customer", b.customer ? <Link key="c" href={`/customers/view?id=${b.customer.id}`} className="text-brand-700 hover:underline">{b.customer.name}</Link> : null],
                ["Enquiry", b.enquiry_id ? <Link key="e" href={`/crm/enquiries/view?id=${b.enquiry_id}`} className="text-brand-700 hover:underline">{b.enquiry_number}</Link> : null],
                ["Site", b.site], ["Division", b.division], ["GST", b.inter_state ? "Inter-state (IGST)" : "Intra-state (CGST + SGST)"],
                ["Created", `${dateTime(b.created_at)}${b.created_by ? ` by ${b.created_by}` : ""}`], ["Notes", b.notes],
              ]} />
            </Card>
            <Card title={dirty ? "Totals (unsaved)" : "Totals"}>
              <TotalsBox interState={b.inter_state} t={{ gross: calc.gross, lineDiscount: calc.lineDiscount, taxable: calc.taxable, cgst: calc.cgst, sgst: calc.sgst, igst: calc.igst, grand: calc.grand }} />
            </Card>
          </div>
        </div>
      )}
      {tab === "documents" && <DocumentsPanel entityType="boq" entityId={id} canEdit={can("boq.update")} defaultCategory="drawing" />}
      {tab === "history" && <HistoryPanel entityType="boq" entityId={id} />}
      <ImportDialog boq={b} open={importing} onClose={() => setImporting(false)} onDone={() => { setDirty(false); refresh(); }} />
    </>
  );
}

export default function Page() {
  return <Suspense><BoqDetail /></Suspense>;
}
