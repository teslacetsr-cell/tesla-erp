"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { ClipboardList, Plus } from "lucide-react";
import { Badge, Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function BoqListPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/boqs");
  return (
    <>
      <PageHeader title="Bills of quantities" subtitle="Priced lists of materials and work. A BOQ becomes a quotation, and later the project's material plan."
        actions={can("boq.create") && <Link href="/projects/boq/new"><Button icon={<Plus className="size-4" />}>New BOQ</Button></Link>} />
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search number, title, customer…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={list.filters.status ?? ""} onChange={(e) => list.setFilter("status", e.target.value)} className="sm:w-36" aria-label="Status">
            <option value="">Any status</option><option value="draft">Draft</option><option value="final">Final</option>
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/projects/boq/view?id=${r.id}`)}
            empty={<EmptyState icon={<ClipboardList className="size-8" />} title={list.q ? "No BOQs match your search" : "No BOQs yet"} body="Create one from an enquiry, or import an Excel BOQ." />}
            columns={[
              { key: "t", header: "BOQ", sortKey: "created_at", cell: (r) => <div><p className="font-medium text-ink-900">{r.title}</p><p className="text-xs text-ink-500">{r.boq_number}</p></div> },
              { key: "c", header: "Customer", cell: (r) => r.customer?.name ?? <span className="text-ink-400">—</span> },
              { key: "l", header: "Lines", hideOnMobile: true, cell: (r) => r.line_count },
              { key: "v", header: "Before GST", sortKey: "total", className: "text-right", cell: (r) => <span className="num">{inr(r.taxable, 0)}</span> },
              { key: "d", header: "Created", hideOnMobile: true, cell: (r) => date(r.created_at) },
              { key: "s", header: "Status", cell: (r) => <Badge tone={r.status === "final" ? "green" : "grey"}>{r.status === "final" ? "Final" : "Draft"}</Badge> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
