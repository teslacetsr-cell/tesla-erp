"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2 } from "lucide-react";
import { Button, Card, ErrorNote, Field, Input, PageHeader, Select, Textarea, useToast } from "@/components/ui";
import { CustomerPicker, peopleOptions, useCustomerDetail, useDivisionOptions, usePeople, type CustomerRef } from "@/components/crm/common";
import { PRIORITY_OPTIONS } from "@/components/projects/common";
import { api, type Page } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";

function NewProject() {
  const soParam = useSearchParams().get("so");
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const { me } = useAuth();
  const [mode, setMode] = useState<"order" | "standalone">("order");
  const [soId, setSoId] = useState(soParam ?? "");
  const orders = useQuery({
    queryKey: ["/sales-orders", "open-for-project"],
    queryFn: () => api<Page<any>>("/sales-orders", { params: { page_size: 200, status: "confirmed" } }),
    select: (r) => r.data,
  });
  const so = useQuery({ queryKey: ["/sales-orders", soId], queryFn: () => api<any>(`/sales-orders/${soId}`), select: (r) => r.data, enabled: !!soId && mode === "order" });
  const [customer, setCustomer] = useState<CustomerRef | null>(null);
  const [v, setV] = useState({ name: "", site_id: "", division_id: "", project_manager_id: me?.id ?? "", start_date: "", target_end_date: "",
    priority: "normal", description: "", site_address: "", contract_value: "" });
  const [members, setMembers] = useState<{ user_id: string; role: string }[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const people = usePeople("engineer");
  const anyone = usePeople("any");
  const divisions = useDivisionOptions();
  const custId = mode === "order" ? so.data?.customer_id : customer?.id;
  const detail = useCustomerDetail(custId);
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV({ ...v, [k]: e.target.value });

  useEffect(() => {
    if (so.data) setV((x) => ({ ...x, name: x.name || so.data.subject, site_id: so.data.site_id ?? "", division_id: so.data.division_id ?? "",
      target_end_date: x.target_end_date || so.data.expected_completion || "" }));
  }, [so.data]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (mode === "order" && !soId) return setError(new Error("Choose the sales order."));
    if (mode === "standalone" && !customer) return setError(new Error("Choose the customer."));
    if (v.name.trim().length < 3) return setError(new Error("Enter the project name."));
    const n = (s: string) => (s.trim() ? s.trim() : null);
    setBusy(true);
    try {
      const r = await api<any>("/projects", { body: {
        sales_order_id: mode === "order" ? soId : null, customer_id: mode === "standalone" ? customer?.id : null,
        contract_value: mode === "standalone" ? n(v.contract_value) : null, name: v.name.trim(), site_id: n(v.site_id), division_id: n(v.division_id),
        project_manager_id: n(v.project_manager_id), start_date: n(v.start_date), target_end_date: n(v.target_end_date), priority: v.priority,
        description: n(v.description), site_address: n(v.site_address),
        members: members.filter((m) => m.user_id).map((m) => ({ user_id: m.user_id, role: n(m.role) })),
      } });
      toast(`Project ${r.data.project_number} created`);
      qc.invalidateQueries({ queryKey: ["/projects"] });
      qc.invalidateQueries({ queryKey: ["/sales-orders"] });
      router.push(`/projects/view?id=${r.data.id}`);
    } catch (err) { setError(err); window.scrollTo({ top: 0, behavior: "smooth" }); } finally { setBusy(false); }
  }

  const orderOptions = orders.data ?? [];
  const soInList = !soId || orderOptions.some((o) => o.id === soId);
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title="New project" subtitle="A project from a sales order takes its customer, site and BOQ from the order." />
      <form onSubmit={submit} className="space-y-5">
        <ErrorNote error={error} />
        <Card title="Source">
          <div className="mb-4 flex gap-2">
            <Button type="button" size="sm" variant={mode === "order" ? "primary" : "secondary"} onClick={() => setMode("order")}>From a sales order</Button>
            <Button type="button" size="sm" variant={mode === "standalone" ? "primary" : "secondary"} onClick={() => setMode("standalone")}>Without an order</Button>
          </div>
          {mode === "order" ? (
            <div className="space-y-3">
              <Field label="Sales order" required>
                <Select value={soId} onChange={(e) => { setSoId(e.target.value); setV({ ...v, name: "" }); }}>
                  <option value="">— Choose a confirmed order —</option>
                  {!soInList && so.data && <option value={so.data.id}>{so.data.so_number} · {so.data.subject}</option>}
                  {orderOptions.map((o) => <option key={o.id} value={o.id}>{o.so_number} · {o.customer?.name} · {o.subject}</option>)}
                </Select>
              </Field>
              {so.data && (
                <div className="grid gap-2 rounded-md bg-ink-50 p-3 text-sm sm:grid-cols-4">
                  <div><p className="text-xs text-ink-500">Customer</p><p className="font-medium">{so.data.customer?.name}</p></div>
                  <div><p className="text-xs text-ink-500">Contract value (before GST)</p><p className="num font-medium">{inr(so.data.taxable, 0)}</p></div>
                  <div><p className="text-xs text-ink-500">BOQ lines</p><p className="font-medium">{so.data.items.length}</p></div>
                  <div><p className="text-xs text-ink-500">Expected completion</p><p className="font-medium">{date(so.data.expected_completion)}</p></div>
                </div>
              )}
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Customer" required><CustomerPicker value={customer} onChange={(c) => { setCustomer(c); setV({ ...v, site_id: "" }); }} /></Field>
              <Field label="Contract value (₹, before GST)" hint="BOQ lines can be added on the project."><Input inputMode="decimal" className="num" value={v.contract_value} onChange={set("contract_value")} /></Field>
            </div>
          )}
        </Card>
        <Card title="Project">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Project name" required className="sm:col-span-2"><Input value={v.name} onChange={set("name")} placeholder="e.g. ABC Hospital Lightning Protection Project" /></Field>
            <Field label="Site">
              <Select value={v.site_id} onChange={set("site_id")} disabled={!custId}>
                <option value="">—</option>
                {detail.data?.sites?.map((s: any) => <option key={s.id} value={s.id}>{s.site_name}</option>)}
              </Select>
            </Field>
            <Field label="Business division"><Select value={v.division_id} onChange={set("division_id")}>{divisions.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
            <Field label="Project manager"><Select value={v.project_manager_id} onChange={set("project_manager_id")}>{peopleOptions(people.data).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
            <Field label="Priority"><Select value={v.priority} onChange={set("priority")}>{PRIORITY_OPTIONS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
            <Field label="Start date"><Input type="date" value={v.start_date} onChange={set("start_date")} /></Field>
            <Field label="Target completion"><Input type="date" value={v.target_end_date} onChange={set("target_end_date")} /></Field>
            <Field label="Site address" hint="Blank = the site's address" className="sm:col-span-2"><Input value={v.site_address} onChange={set("site_address")} /></Field>
            <Field label="Scope / description" className="sm:col-span-2"><Textarea rows={3} value={v.description} onChange={set("description")} /></Field>
          </div>
        </Card>
        <Card title="Team" actions={<Button type="button" size="sm" variant="secondary" icon={<Plus className="size-3.5" />} onClick={() => setMembers([...members, { user_id: "", role: "" }])}>Add person</Button>}>
          {members.length === 0 ? <p className="text-sm text-ink-500">Add site engineers and technicians. Team members see the project and record site work; anyone given a task joins automatically.</p> : (
            <div className="space-y-2">
              {members.map((m, i) => (
                <div key={i} className="flex gap-2">
                  <Select className="flex-1" aria-label={`Team member ${i + 1}`} value={m.user_id} onChange={(e) => setMembers(members.map((x, j) => (j === i ? { ...x, user_id: e.target.value } : x)))}>
                    {peopleOptions(anyone.data, "— Choose —").map(([k, l]) => <option key={k} value={k}>{l}</option>)}
                  </Select>
                  <Input className="w-44" placeholder="Role, e.g. Site Engineer" aria-label={`Role ${i + 1}`} value={m.role} onChange={(e) => setMembers(members.map((x, j) => (j === i ? { ...x, role: e.target.value } : x)))} />
                  <Button type="button" variant="ghost" aria-label="Remove" onClick={() => setMembers(members.filter((_, j) => j !== i))}><Trash2 className="size-4 text-ink-400" /></Button>
                </div>
              ))}
            </div>
          )}
        </Card>
        <div className="flex justify-end gap-2">
          <Button type="button" variant="secondary" onClick={() => router.back()}>Cancel</Button>
          <Button type="submit" loading={busy}>Create project</Button>
        </div>
      </form>
    </div>
  );
}

export default function Page() {
  return <Suspense><NewProject /></Suspense>;
}
