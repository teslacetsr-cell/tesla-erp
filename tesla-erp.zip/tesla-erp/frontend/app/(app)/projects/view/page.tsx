"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  AlertTriangle, ArrowLeft, CheckCircle2, ClipboardCheck, Download, FileDown, Flag, HardHat, Pause, Pencil, Play, Plus,
  RotateCcw, Trash2, UserPlus, Users, XCircle,
} from "lucide-react";
import { Badge, Button, Card, Detail, EmptyState, ErrorNote, Field, Input, Modal, PageHeader, Select, Spinner, Tabs, Textarea, useConfirm, useToast } from "@/components/ui";
import { peopleOptions, useDivisionOptions, usePeople } from "@/components/crm/common";
import {
  IssueDialog, IssueStatus, istToday, PRIORITY_OPTIONS, ProgressBar, ProjectStatus, Severity, SiteReportForm, TaskDialog, TaskList,
} from "@/components/projects/common";
import { ReportCard } from "@/components/projects/report-card";
import { CostsTab } from "@/components/costing/costs-tab";
import { MrStatus, PoStatus } from "@/components/purchase/common";
import { DocumentsPanel, HistoryPanel } from "@/components/record-panels";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, dateTime, inr, qty } from "@/lib/format";

type Tab = "overview" | "boq" | "materials" | "costs" | "tasks" | "issues" | "reports" | "documents" | "history";
const TABS: Tab[] = ["overview", "boq", "materials", "costs", "tasks", "issues", "reports", "documents", "history"];

function Tile({ label, value, sub, tone = "text-ink-900", muted }: { label: string; value: React.ReactNode; sub?: React.ReactNode; tone?: string; muted?: boolean }) {
  return (
    <div className={`rounded-lg border p-3 ${muted ? "border-dashed border-ink-200 bg-ink-50/50" : "border-ink-200 bg-white"}`}>
      <p className="text-xs text-ink-500">{label}</p>
      <p className={`num mt-1 text-xl font-semibold ${muted ? "text-ink-400" : tone}`}>{value}</p>
      {sub && <p className="mt-0.5 text-xs text-ink-500">{sub}</p>}
    </div>
  );
}

/* ------------------------------------------------------------------ edit / status dialogs */
function EditDialog({ prj, open, onClose, onSaved }: { prj: any; open: boolean; onClose: () => void; onSaved: () => void }) {
  const people = usePeople("engineer");
  const divisions = useDivisionOptions();
  const [v, setV] = useState({ name: prj.name, division_id: prj.division_id ?? "", project_manager_id: prj.project_manager_id ?? "",
    start_date: prj.start_date ?? "", target_end_date: prj.target_end_date ?? "", priority: prj.priority, description: prj.description ?? "",
    site_address: prj.site_address ?? "", contract_value: prj.contract_value });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV({ ...v, [k]: e.target.value });
  const n = (s: string) => (s?.trim() ? s.trim() : null);
  return (
    <Modal open={open} onClose={onClose} title="Edit project" wide
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setBusy(true);
        try {
          await api(`/projects/${prj.id}`, { method: "PUT", body: { name: v.name.trim(), site_id: prj.site_id, division_id: n(v.division_id),
            project_manager_id: n(v.project_manager_id), start_date: n(v.start_date), target_end_date: n(v.target_end_date), priority: v.priority,
            description: n(v.description), site_address: n(v.site_address), contract_value: prj.can.contract ? n(v.contract_value) : null, row_version: prj.row_version } });
          onSaved();
          onClose();
        } catch (e) { setError(e); } finally { setBusy(false); }
      }}>Save</Button></>}>
      <div className="space-y-3">
        <ErrorNote error={error} />
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Project name" required className="sm:col-span-2"><Input value={v.name} onChange={set("name")} /></Field>
          <Field label="Project manager"><Select value={v.project_manager_id} onChange={set("project_manager_id")}>{peopleOptions(people.data).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          <Field label="Business division"><Select value={v.division_id} onChange={set("division_id")}>{divisions.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          <Field label="Start date"><Input type="date" value={v.start_date} onChange={set("start_date")} /></Field>
          <Field label="Target completion"><Input type="date" value={v.target_end_date} onChange={set("target_end_date")} /></Field>
          <Field label="Priority"><Select value={v.priority} onChange={set("priority")}>{PRIORITY_OPTIONS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          {prj.can.contract && <Field label="Contract value (₹, before GST)"><Input inputMode="decimal" className="num" value={v.contract_value} onChange={set("contract_value")} /></Field>}
          <Field label="Site address" className="sm:col-span-2"><Input value={v.site_address} onChange={set("site_address")} /></Field>
          <Field label="Scope / description" className="sm:col-span-2"><Textarea rows={3} value={v.description} onChange={set("description")} /></Field>
        </div>
      </div>
    </Modal>
  );
}

const STATUS_ACTION: Record<string, { label: string; icon: typeof Play; reason?: "required" | "optional"; confirm?: string }> = {
  active: { label: "Start / resume", icon: Play },
  on_hold: { label: "Put on hold", icon: Pause, reason: "required" },
  completed: { label: "Complete", icon: CheckCircle2, confirm: "Mark the project completed? Site work is closed; it can be reopened." },
  cancelled: { label: "Cancel project", icon: XCircle, reason: "required" },
};

/* ------------------------------------------------------------------ overview: milestones & team */
function Milestones({ prj, onChanged }: { prj: any; onChanged: () => void }) {
  const toast = useToast();
  const confirm = useConfirm();
  const [edit, setEdit] = useState<any>(null);
  const editable = prj.can.team;
  async function save(m: any) {
    const body = { name: m.name.trim(), due_date: m.due_date || null, completed_on: m.completed_on || null, sort_order: Number(m.sort_order) || 0, notes: m.notes?.trim() || null };
    try {
      if (m.id) await api(`/projects/${prj.id}/milestones/${m.id}`, { method: "PUT", body });
      else await api(`/projects/${prj.id}/milestones`, { body });
      setEdit(null);
      onChanged();
    } catch (e: any) { toast(e.message, "error"); }
  }
  return (
    <Card title="Milestones" actions={editable && <Button size="sm" variant="secondary" icon={<Plus className="size-3.5" />} onClick={() => setEdit({ name: "", due_date: "", completed_on: "", sort_order: prj.milestones.length, notes: "" })}>Add</Button>}>
      {prj.milestones.length === 0 ? <p className="text-sm text-ink-500">No milestones.</p> : (
        <ol className="space-y-2">
          {prj.milestones.map((m: any) => (
            <li key={m.id} className="flex items-center gap-2.5 text-sm">
              {m.completed_on ? <CheckCircle2 className="size-4 shrink-0 text-emerald-600" /> : <Flag className={`size-4 shrink-0 ${m.late ? "text-brand-600" : "text-ink-400"}`} />}
              <span className={`flex-1 ${m.completed_on ? "text-ink-500" : "text-ink-900"}`}>{m.name}</span>
              <span className={`text-xs ${m.late ? "font-medium text-brand-700" : "text-ink-500"}`}>{m.completed_on ? `Done ${date(m.completed_on)}` : m.due_date ? `Due ${date(m.due_date)}` : ""}</span>
              {editable && !m.completed_on && <Button size="sm" variant="ghost" onClick={() => save({ ...m, completed_on: istToday() })}>Done</Button>}
              {editable && <Button size="sm" variant="ghost" aria-label="Edit milestone" onClick={() => setEdit({ ...m, due_date: m.due_date ?? "", completed_on: m.completed_on ?? "", notes: m.notes ?? "" })}><Pencil className="size-3.5" /></Button>}
              {editable && <Button size="sm" variant="ghost" aria-label="Delete milestone" onClick={async () => {
                if (!(await confirm({ title: "Delete milestone?", body: m.name, confirmLabel: "Delete" }))) return;
                await api(`/projects/${prj.id}/milestones/${m.id}`, { method: "DELETE" });
                onChanged();
              }}><Trash2 className="size-3.5 text-ink-400" /></Button>}
            </li>
          ))}
        </ol>
      )}
      {edit && (
        <Modal open onClose={() => setEdit(null)} title={edit.id ? "Milestone" : "New milestone"}
          footer={<><Button variant="secondary" onClick={() => setEdit(null)}>Cancel</Button><Button disabled={edit.name.trim().length < 2} onClick={() => save(edit)}>Save</Button></>}>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Milestone" required className="sm:col-span-2"><Input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></Field>
            <Field label="Due"><Input type="date" value={edit.due_date} onChange={(e) => setEdit({ ...edit, due_date: e.target.value })} /></Field>
            <Field label="Completed on"><Input type="date" value={edit.completed_on} onChange={(e) => setEdit({ ...edit, completed_on: e.target.value })} /></Field>
            <Field label="Order"><Input inputMode="numeric" value={edit.sort_order} onChange={(e) => setEdit({ ...edit, sort_order: e.target.value })} /></Field>
            <Field label="Notes" className="sm:col-span-2"><Input value={edit.notes} onChange={(e) => setEdit({ ...edit, notes: e.target.value })} /></Field>
          </div>
        </Modal>
      )}
    </Card>
  );
}

function Team({ prj, onChanged }: { prj: any; onChanged: () => void }) {
  const toast = useToast();
  const confirm = useConfirm();
  const anyone = usePeople("any", prj.can.team);
  const [adding, setAdding] = useState(false);
  const [m, setM] = useState({ user_id: "", role: "" });
  return (
    <Card title="Team" actions={prj.can.team && <Button size="sm" variant="secondary" icon={<UserPlus className="size-3.5" />} onClick={() => { setM({ user_id: "", role: "" }); setAdding(true); }}>Add</Button>}>
      <ul className="space-y-2 text-sm">
        <li className="flex items-center gap-2"><HardHat className="size-4 text-brand-600" /><span className="flex-1 font-medium">{prj.project_manager ?? "No project manager"}</span><span className="text-xs text-ink-500">Project manager</span></li>
        {prj.members.map((x: any) => (
          <li key={x.user_id} className="flex items-center gap-2">
            <Users className="size-4 text-ink-400" /><span className="flex-1">{x.name}</span><span className="text-xs text-ink-500">{x.role ?? ""}</span>
            {prj.can.team && <Button size="sm" variant="ghost" aria-label={`Remove ${x.name}`} onClick={async () => {
              if (!(await confirm({ title: `Remove ${x.name} from the team?`, body: "They no longer see the project unless they hold tasks on it.", confirmLabel: "Remove" }))) return;
              try { await api(`/projects/${prj.id}/members/${x.user_id}`, { method: "DELETE" }); onChanged(); } catch (e: any) { toast(e.message, "error"); }
            }}><Trash2 className="size-3.5 text-ink-400" /></Button>}
          </li>
        ))}
      </ul>
      <Modal open={adding} onClose={() => setAdding(false)} title="Add to the team"
        footer={<><Button variant="secondary" onClick={() => setAdding(false)}>Cancel</Button><Button disabled={!m.user_id} onClick={async () => {
          try { await api(`/projects/${prj.id}/members`, { body: { user_id: m.user_id, role: m.role.trim() || null } }); setAdding(false); onChanged(); } catch (e: any) { toast(e.message, "error"); }
        }}>Add</Button></>}>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Person" required><Select value={m.user_id} onChange={(e) => setM({ ...m, user_id: e.target.value })}>{peopleOptions(anyone.data, "— Choose —").map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          <Field label="Role on the project"><Input value={m.role} onChange={(e) => setM({ ...m, role: e.target.value })} placeholder="e.g. Site Engineer" /></Field>
        </div>
      </Modal>
    </Card>
  );
}

/* ------------------------------------------------------------------ BOQ tracking */
function InstallDialog({ prj, lines, line, onClose, onSaved }: { prj: any; lines: any[]; line: any | null; onClose: () => void; onSaved: () => void }) {
  const [v, setV] = useState({ boq_line_id: line?.id ?? "", quantity: "", entry_date: istToday(), location: "", remarks: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const sel = lines.find((l) => l.id === v.boq_line_id);
  return (
    <Modal open onClose={onClose} title="Record installation"
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setError(null);
        if (!v.boq_line_id) return setError(new Error("Choose the BOQ line."));
        if (!(Number(v.quantity) > 0)) return setError(new Error("Enter the quantity installed."));
        if (sel && Number(v.quantity) > Number(sel.remaining_qty)) return setError(new Error(`Only ${sel.remaining_qty} ${sel.unit} remain of the approved ${sel.approved_qty}.`));
        setBusy(true);
        try {
          await api(`/projects/${prj.id}/installations`, { body: { boq_line_id: v.boq_line_id, quantity: v.quantity.trim(), entry_date: v.entry_date, location: v.location.trim() || null, remarks: v.remarks.trim() || null } });
          onSaved();
          onClose();
        } catch (e) { setError(e); } finally { setBusy(false); }
      }}>Record</Button></>}>
      <div className="space-y-3">
        <ErrorNote error={error} />
        <Field label="BOQ line" required>
          <Select value={v.boq_line_id} onChange={(e) => setV({ ...v, boq_line_id: e.target.value })}>
            <option value="">— Choose —</option>
            {lines.filter((l) => Number(l.remaining_qty) > 0).map((l) => <option key={l.id} value={l.id}>{l.line_no}. {l.description} ({l.remaining_qty} {l.unit} left)</option>)}
          </Select>
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Quantity installed" required hint={sel ? `${sel.remaining_qty} ${sel.unit} remaining` : undefined}><Input inputMode="decimal" className="num" value={v.quantity} onChange={(e) => setV({ ...v, quantity: e.target.value })} /></Field>
          <Field label="Date"><Input type="date" max={istToday()} value={v.entry_date} onChange={(e) => setV({ ...v, entry_date: e.target.value })} /></Field>
          <Field label="Location"><Input value={v.location} onChange={(e) => setV({ ...v, location: e.target.value })} placeholder="e.g. North parapet" /></Field>
          <Field label="Remarks"><Input value={v.remarks} onChange={(e) => setV({ ...v, remarks: e.target.value })} /></Field>
        </div>
      </div>
    </Modal>
  );
}

function LineDialog({ prj, line, onClose, onSaved }: { prj: any; line: any | null; onClose: () => void; onSaved: () => void }) {
  const [v, setV] = useState({ section: line?.section ?? "", description: line?.description ?? "", unit: line?.unit ?? "NOS",
    approved_qty: line ? String(Number(line.approved_qty)) : "", rate: line ? String(Number(line.rate)) : "", remarks: line?.remarks ?? "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV({ ...v, [k]: e.target.value });
  return (
    <Modal open onClose={onClose} title={line ? `Line ${line.line_no}` : "Add a BOQ line"}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setBusy(true);
        try {
          const body = { section: v.section.trim() || null, item_id: line?.item_id ?? null, description: v.description.trim(), unit: v.unit.trim() || "NOS",
            approved_qty: v.approved_qty.trim() || "0", rate: v.rate.trim() || "0", remarks: v.remarks.trim() || null };
          if (line) await api(`/project-boq-lines/${line.id}`, { method: "PUT", body });
          else await api(`/projects/${prj.id}/boq-lines`, { body });
          onSaved();
          onClose();
        } catch (e) { setError(e); } finally { setBusy(false); }
      }}>Save</Button></>}>
      <div className="space-y-3">
        <ErrorNote error={error} />
        <p className="text-xs text-ink-500">Extra work or variations not on the sales order. Lines from the order change only through the order.</p>
        <Field label="Description" required><Input value={v.description} onChange={set("description")} /></Field>
        <div className="grid gap-3 sm:grid-cols-4">
          <Field label="Section" className="sm:col-span-2"><Input value={v.section} onChange={set("section")} /></Field>
          <Field label="Unit"><Input value={v.unit} onChange={set("unit")} /></Field>
          <Field label="Approved qty" required><Input inputMode="decimal" className="num" value={v.approved_qty} onChange={set("approved_qty")} /></Field>
          <Field label="Rate (₹)" className="sm:col-span-2"><Input inputMode="decimal" className="num" value={v.rate} onChange={set("rate")} /></Field>
          <Field label="Remarks" className="sm:col-span-2"><Input value={v.remarks} onChange={set("remarks")} /></Field>
        </div>
      </div>
    </Modal>
  );
}

function BoqTab({ prj, onChanged }: { prj: any; onChanged: () => void }) {
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const lines = useQuery({ queryKey: ["/projects", prj.id, "boq"], queryFn: () => api<any>(`/projects/${prj.id}/boq`), select: (r) => r.data as any[] });
  const log = useQuery({ queryKey: ["/projects", prj.id, "installations"], queryFn: () => api<any>(`/projects/${prj.id}/installations`), select: (r) => r.data as any[] });
  const [install, setInstall] = useState<any | undefined>(undefined);
  const [lineEdit, setLineEdit] = useState<any | undefined>(undefined);
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/projects", prj.id] }); onChanged(); };
  if (lines.isLoading) return <Spinner />;
  const rows = lines.data ?? [];
  let section: string | null = null;
  return (
    <div className="space-y-4">
      <Card padded={false} title="BOQ tracking" actions={<div className="flex flex-wrap gap-2">
        {prj.can.site_create && <Button size="sm" icon={<ClipboardCheck className="size-3.5" />} onClick={() => setInstall(null)}>Record installation</Button>}
        {prj.can.team && <Button size="sm" variant="secondary" icon={<Plus className="size-3.5" />} onClick={() => setLineEdit(null)}>Add line</Button>}
        {prj.can.export && <Button size="sm" variant="secondary" icon={<Download className="size-3.5" />} onClick={() => download(`/projects/${prj.id}/boq/export`, `${prj.project_number.replaceAll("/", "-")}-boq.xlsx`)}>Excel</Button>}
      </div>}>
        {rows.length === 0 ? <div className="p-6"><EmptyState title="No BOQ lines" body={prj.sales_order_id ? "The order has no lines." : "Add the lines of work for this project."} /></div> : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[860px] text-sm">
              <thead>
                <tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
                  <th className="px-3 py-2 font-medium">#</th><th className="px-3 py-2 font-medium">Description</th><th className="px-3 py-2 font-medium">Unit</th>
                  <th className="px-3 py-2 text-right font-medium">Approved</th><th className="px-3 py-2 text-right font-medium" title="Accepted on GRNs against this project's purchase orders">Procured</th>
                  <th className="px-3 py-2 text-right font-medium" title="Filled by stores (Phase 6)">Issued</th><th className="px-3 py-2 text-right font-medium">Installed</th>
                  <th className="px-3 py-2 text-right font-medium">Remaining</th><th className="w-32 px-3 py-2 font-medium">Progress</th><th className="px-3 py-2" />
                </tr>
              </thead>
              <tbody>
                {rows.map((l) => {
                  const head = l.section && l.section !== section;
                  section = l.section;
                  const pct = Number(l.installed_pct ?? 0);
                  return [
                    head ? <tr key={`s-${l.id}`} className="bg-ink-50"><td colSpan={10} className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wide text-ink-600">{l.section}</td></tr> : null,
                    <tr key={l.id} className="border-b border-ink-100 align-top">
                      <td className="px-3 py-2 text-ink-500">{l.line_no}</td>
                      <td className="px-3 py-2"><p className="text-ink-900">{l.description}</p>{!l.from_order && <Badge tone="amber">Added on project</Badge>}</td>
                      <td className="px-3 py-2">{l.unit}</td>
                      <td className="num px-3 py-2 text-right font-medium">{qty(l.approved_qty)}</td>
                      <td className="num px-3 py-2 text-right text-ink-500">{qty(l.procured_qty)}</td>
                      <td className="num px-3 py-2 text-right text-ink-500">{qty(l.issued_qty)}</td>
                      <td className="num px-3 py-2 text-right">{qty(l.installed_qty)}</td>
                      <td className={`num px-3 py-2 text-right ${Number(l.remaining_qty) === 0 ? "text-emerald-700" : ""}`}>{qty(l.remaining_qty)}</td>
                      <td className="px-3 py-2"><ProgressBar value={pct} tone={pct >= 100 ? "green" : "brand"} /><p className="num mt-0.5 text-[11px] text-ink-500">{pct}%</p></td>
                      <td className="whitespace-nowrap px-3 py-1.5 text-right">
                        {prj.can.site_create && Number(l.remaining_qty) > 0 && <Button size="sm" variant="ghost" onClick={() => setInstall(l)}>Install</Button>}
                        {prj.can.team && !l.from_order && <Button size="sm" variant="ghost" aria-label="Edit line" onClick={() => setLineEdit(l)}><Pencil className="size-3.5" /></Button>}
                        {prj.can.team && !l.from_order && Number(l.installed_qty) === 0 && <Button size="sm" variant="ghost" aria-label="Delete line" onClick={async () => {
                          if (!(await confirm({ title: "Delete this line?", body: l.description, confirmLabel: "Delete" }))) return;
                          try { await api(`/project-boq-lines/${l.id}`, { method: "DELETE" }); refresh(); } catch (e: any) { toast(e.message, "error"); }
                        }}><Trash2 className="size-3.5 text-ink-400" /></Button>}
                      </td>
                    </tr>,
                  ];
                })}
              </tbody>
            </table>
          </div>
        )}
        <p className="border-t border-ink-100 px-3 py-2 text-xs text-ink-500">Procured = accepted on GRNs of this project's purchase orders. Issued fills in with material issues (Phase 6).</p>
      </Card>
      <Card title="Installation log" padded={false}>
        {log.isLoading ? <Spinner /> : !log.data?.length ? <p className="p-4 text-sm text-ink-500">Nothing recorded yet.</p> : (
          <ul className="divide-y divide-ink-100">
            {log.data.map((e) => (
              <li key={e.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 px-4 py-2 text-sm">
                <span className="w-24 text-ink-500">{date(e.entry_date)}</span>
                <span className="num w-28 font-medium">{qty(e.quantity)} {e.unit}</span>
                <span className="min-w-0 flex-1">{e.line_no}. {e.description}{e.location ? <span className="text-ink-500"> · {e.location}</span> : null}</span>
                <span className="text-xs text-ink-500">{e.recorded_by}{e.site_report_id ? " · site report" : ""}</span>
                {e.can_delete && <Button size="sm" variant="ghost" aria-label="Remove entry" onClick={async () => {
                  if (!(await confirm({ title: "Remove this installation entry?", body: `${qty(e.quantity)} ${e.unit} go back to remaining.`, confirmLabel: "Remove" }))) return;
                  await api(`/installations/${e.id}`, { method: "DELETE" });
                  refresh();
                }}><Trash2 className="size-3.5 text-ink-400" /></Button>}
              </li>
            ))}
          </ul>
        )}
      </Card>
      {install !== undefined && <InstallDialog prj={prj} lines={rows} line={install} onClose={() => setInstall(undefined)} onSaved={() => { toast("Installation recorded"); refresh(); }} />}
      {lineEdit !== undefined && <LineDialog prj={prj} line={lineEdit} onClose={() => setLineEdit(undefined)} onSaved={() => { toast("Line saved"); refresh(); }} />}
    </div>
  );
}

/* ------------------------------------------------------------------ tasks / issues / reports */
function useTeam(prj: any) {
  const list = [...(prj.project_manager_id ? [{ id: prj.project_manager_id, name: prj.project_manager }] : []),
    ...prj.members.filter((m: any) => m.user_id !== prj.project_manager_id).map((m: any) => ({ id: m.user_id, name: m.name }))];
  const everyone = usePeople("any", prj.can.site_update);
  const extra = (everyone.data ?? []).filter((p) => !list.some((x) => x.id === p.id));
  return [...list, ...extra];
}

function TasksTab({ prj, onChanged }: { prj: any; onChanged: () => void }) {
  const qc = useQueryClient();
  const tasks = useQuery({ queryKey: ["/projects", prj.id, "tasks"], queryFn: () => api<any>(`/projects/${prj.id}/tasks`), select: (r) => r.data as any[] });
  const team = useTeam(prj);
  const [edit, setEdit] = useState<any | undefined>(undefined);
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/projects", prj.id] }); qc.invalidateQueries({ queryKey: ["/tasks"] }); onChanged(); };
  return (
    <Card padded={false} title="Tasks" actions={prj.can.site_create && <Button size="sm" icon={<Plus className="size-3.5" />} onClick={() => setEdit(null)}>New task</Button>}>
      {tasks.isLoading ? <Spinner /> : !tasks.data?.length ? <div className="p-6"><EmptyState title="No tasks yet" body="Break the work into tasks and assign them to the team." /></div>
        : <TaskList tasks={tasks.data} onChanged={refresh} onEdit={setEdit} />}
      {edit !== undefined && <TaskDialog open onClose={() => setEdit(undefined)} projectId={prj.id} task={edit ?? undefined} team={team} milestones={prj.milestones} onSaved={refresh} />}
    </Card>
  );
}

function IssuesTab({ prj, onChanged }: { prj: any; onChanged: () => void }) {
  const qc = useQueryClient();
  const confirm = useConfirm();
  const issues = useQuery({ queryKey: ["/projects", prj.id, "issues"], queryFn: () => api<any>(`/projects/${prj.id}/issues`), select: (r) => r.data as any[] });
  const team = useTeam(prj);
  const [edit, setEdit] = useState<any | undefined>(undefined);
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/projects", prj.id] }); onChanged(); };
  return (
    <Card padded={false} title="Issues" actions={prj.can.site_create && <Button size="sm" icon={<AlertTriangle className="size-3.5" />} onClick={() => setEdit(null)}>Raise issue</Button>}>
      {issues.isLoading ? <Spinner /> : !issues.data?.length ? <p className="p-4 text-sm text-ink-500">No issues raised.</p> : (
        <ul className="divide-y divide-ink-100">
          {issues.data.map((i) => (
            <li key={i.id} className="flex flex-col gap-1 px-4 py-3 sm:flex-row sm:items-start">
              <div className="min-w-0 flex-1">
                <p className="flex flex-wrap items-center gap-2 font-medium text-ink-900">{i.title} <Severity severity={i.severity} /> <IssueStatus status={i.status} /></p>
                {i.description && <p className="text-sm text-ink-600">{i.description}</p>}
                {i.resolution && <p className="text-sm text-emerald-800">Resolved: {i.resolution}</p>}
                <p className="text-xs text-ink-500">Raised by {i.raised_by} · {dateTime(i.created_at)}{i.assignee ? ` · assigned to ${i.assignee}` : ""}</p>
              </div>
              <div className="flex gap-1">
                {i.can.edit && <Button size="sm" variant="secondary" onClick={() => setEdit(i)}>{i.status === "open" ? "Update" : "Edit"}</Button>}
                {i.can.delete && <Button size="sm" variant="ghost" aria-label="Delete issue" onClick={async () => {
                  if (!(await confirm({ title: "Delete this issue?", body: i.title, confirmLabel: "Delete" }))) return;
                  await api(`/issues/${i.id}`, { method: "DELETE" });
                  refresh();
                }}><Trash2 className="size-3.5 text-ink-400" /></Button>}
              </div>
            </li>
          ))}
        </ul>
      )}
      {edit !== undefined && <IssueDialog open onClose={() => setEdit(undefined)} projectId={prj.id} issue={edit ?? undefined} team={team} onSaved={refresh} />}
    </Card>
  );
}

function MaterialsTab({ prj }: { prj: any }) {
  const qc = useQueryClient();
  const canIssue = useAuth().can("material_issue.create");
  const toast = useToast();
  const m = useQuery({ queryKey: ["/projects", prj.id, "materials"], queryFn: () => api<any>(`/projects/${prj.id}/materials`), select: (r) => r.data });
  if (m.isLoading || !m.data) return <Spinner />;
  const d = m.data;
  return (
    <div className="space-y-4">
      <Card title="Site store" actions={<div className="flex gap-2">
        {d.site_store && <Link href={`/inventory/transfers/new?to=${d.site_store.id}`}><Button size="sm" variant="secondary">Send stock to site</Button></Link>}
        {canIssue && <Link href={`/inventory/issues/new?project=${prj.id}`}><Button size="sm" variant="secondary">Issue material</Button></Link>}
        {d.can_create_store && <Button size="sm" onClick={async () => {
          try { await api(`/projects/${prj.id}/site-store`, { body: {} }); toast("Site store created"); qc.invalidateQueries({ queryKey: ["/projects", prj.id, "materials"] }); qc.invalidateQueries({ queryKey: ["/warehouses"] }); }
          catch (e: any) { toast(e.message, "error"); }
        }}>Create site store</Button>}
      </div>}>
        {!d.site_store ? <p className="text-sm text-ink-500">No site store yet. Create one so material delivered to site, or sent from the main store, is tracked here.</p> : (
          <>
            <p className="mb-2 text-sm"><b>{d.site_store.name}</b> <span className="text-ink-500">· {d.site_store.code}</span></p>
            {d.site_stock === undefined ? null : d.site_stock.length === 0 ? <p className="text-sm text-ink-500">Nothing in the site store.</p> : (
              <table className="w-full text-sm">
                <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500"><th className="py-1.5">Item</th><th className="py-1.5 text-right">At site</th><th className="py-1.5 text-right">Value</th></tr></thead>
                <tbody>{d.site_stock.map((x: any) => <tr key={x.item_id} className="border-b border-ink-100"><td className="py-1.5"><Link href={`/inventory/stock/view?id=${x.item_id}`} className="hover:underline">{x.name}</Link> <span className="text-xs text-ink-500">{x.code}</span></td><td className="num py-1.5 text-right">{qty(x.quantity)} {x.unit}</td><td className="num py-1.5 text-right">{inr(x.value, 0)}</td></tr>)}</tbody>
              </table>
            )}
          </>
        )}
      </Card>
      {d.material_requests && (
        <Card title="Material requests" padded={false} actions={d.can.request && <Link href={`/purchase/material-requests/new?project=${prj.id}`}><Button size="sm">Request material</Button></Link>}>
          {d.material_requests.length === 0 ? <p className="p-4 text-sm text-ink-500">None yet.</p> : (
            <ul className="divide-y divide-ink-100">{d.material_requests.map((r: any) => (
              <li key={r.id} className="flex flex-wrap items-center gap-3 px-4 py-2.5 text-sm">
                <Link href={`/purchase/material-requests/view?id=${r.id}`} className="font-medium text-brand-700 hover:underline">{r.mr_number ?? "Draft"}</Link>
                <span className="text-ink-500">{r.lines_count} item(s) · {r.requested_by}{r.required_by ? ` · needed ${date(r.required_by)}` : ""}</span>
                <span className="ml-auto"><MrStatus status={r.status} /></span>
              </li>))}</ul>
          )}
        </Card>
      )}
      {d.purchase_orders && (
        <Card title="Purchase orders" padded={false}>
          {d.purchase_orders.length === 0 ? <p className="p-4 text-sm text-ink-500">None yet.</p> : (
            <ul className="divide-y divide-ink-100">{d.purchase_orders.map((o: any) => (
              <li key={o.id} className="flex flex-wrap items-center gap-3 px-4 py-2.5 text-sm">
                <Link href={`/purchase/orders/view?id=${o.id}`} className="font-medium text-brand-700 hover:underline">{o.display_number}</Link>
                <span className="text-ink-500">{o.supplier.name} · {inr(o.grand_total, 0)}{o.expected_delivery ? ` · by ${date(o.expected_delivery)}` : ""}</span>
                <span className="ml-auto"><PoStatus status={o.status} /></span>
              </li>))}</ul>
          )}
        </Card>
      )}
    </div>
  );
}

function ReportsTab({ prj, onChanged }: { prj: any; onChanged: () => void }) {
  const qc = useQueryClient();
  const reports = useQuery({ queryKey: ["/site-reports", { project_id: prj.id }], queryFn: () => api<any>("/site-reports", { params: { project_id: prj.id, page_size: 100 } }), select: (r) => r.data as any[] });
  const lines = useQuery({ queryKey: ["/projects", prj.id, "boq"], queryFn: () => api<any>(`/projects/${prj.id}/boq`), select: (r) => r.data as any[] });
  const [adding, setAdding] = useState(false);
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/site-reports"] }); qc.invalidateQueries({ queryKey: ["/projects", prj.id] }); onChanged(); };
  return (
    <div className="space-y-4">
      {prj.can.site_create && !adding && <Button icon={<Plus className="size-4" />} onClick={() => setAdding(true)}>New site report</Button>}
      {adding && lines.data && (
        <Card title="Daily site report">
          <SiteReportForm projectId={prj.id} lines={lines.data} onCancel={() => setAdding(false)} onDone={() => { setAdding(false); refresh(); }} />
        </Card>
      )}
      {reports.isLoading ? <Spinner /> : !reports.data?.length ? <Card><EmptyState title="No site reports yet" body="The site team records the day's work, manpower, installation and photos." /></Card>
        : reports.data.map((r) => <ReportCard key={r.id} r={r} onChanged={refresh} lines={lines.data} />)}
    </div>
  );
}

/* ------------------------------------------------------------------ page */
function ProjectDetail() {
  const params = useSearchParams();
  const id = params.get("id") ?? "";
  const initialTab = params.get("tab") as Tab | null;
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [tab, setTab] = useState<Tab>(initialTab && TABS.includes(initialTab) ? initialTab : "overview");
  const [editing, setEditing] = useState(false);
  const [statusTo, setStatusTo] = useState<string | null>(null);
  const [reason, setReason] = useState("");
  const [progress, setProgress] = useState<string | null>(null);
  const key = ["/projects", id];
  const { data: prj, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api<any>(`/projects/${id}`), select: (r) => r.data });
  const refresh = () => { qc.invalidateQueries({ queryKey: key }); qc.invalidateQueries({ queryKey: ["/projects/summary"] }); };
  if (isLoading) return <Spinner />;
  if (error || !prj) return <ErrorNote error={error} />;
  const f = prj.financials;
  const c = prj.counts;
  const can = prj.can;

  async function changeStatus(s: string, r: string | null) {
    try {
      await api(`/projects/${id}/status`, { body: { status: s, reason: r, row_version: prj.row_version } });
      toast(`Project ${s.replace("_", " ")}`);
      refresh();
      qc.invalidateQueries({ queryKey: ["/projects"] });
    } catch (e: any) { toast(e.message, "error"); }
  }

  return (
    <>
      <PageHeader
        back={<Link href="/projects" className="mb-1 inline-flex items-center gap-1 text-sm text-ink-500 hover:text-ink-800"><ArrowLeft className="size-3.5" /> Projects</Link>}
        title={<span className="flex flex-wrap items-center gap-2">{prj.name} <ProjectStatus status={prj.status} />{prj.late && <Badge tone="red">Past target date</Badge>}</span>}
        subtitle={`${prj.project_number} · ${prj.customer?.name}${prj.site ? ` · ${prj.site}` : ""}`}
        actions={<>
          {can.status.map((s: string) => {
            const a = s === "active" && prj.status === "completed" ? { label: "Reopen", icon: RotateCcw, reason: "required" as const } : STATUS_ACTION[s];
            if (!a) return null;
            const Icon = a.icon;
            return <Button key={s} variant={s === "active" && prj.status === "planning" ? "primary" : s === "cancelled" ? "ghost" : "secondary"} icon={<Icon className="size-4" />}
              onClick={async () => {
                if (a.reason) { setReason(""); setStatusTo(s); return; }
                if (a.confirm && !(await confirm({ title: a.label, body: a.confirm, confirmLabel: a.label }))) return;
                changeStatus(s, null);
              }}>{a.label}</Button>;
          })}
          {can.update && <Button variant="secondary" icon={<Pencil className="size-4" />} onClick={() => setEditing(true)}>Edit</Button>}
          {can.print && <Button variant="secondary" icon={<FileDown className="size-4" />} onClick={() => download(`/projects/${id}/pdf`, `${prj.project_number.replaceAll("/", "-")}-status.pdf`)}>Status report</Button>}
          {can.delete && <Button variant="danger" icon={<Trash2 className="size-4" />} onClick={async () => {
            if (!(await confirm({ title: "Delete this project?", body: "Only a project still in planning with no site work can be deleted.", confirmLabel: "Delete" }))) return;
            try { await api(`/projects/${id}`, { method: "DELETE" }); qc.invalidateQueries({ queryKey: ["/projects"] }); router.push("/projects"); } catch (e: any) { toast(e.message, "error"); }
          }}>Delete</Button>}
        </>} />
      {prj.status_reason && ["on_hold", "cancelled"].includes(prj.status) && <p className="mb-4 rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-900"><b>{prj.status === "on_hold" ? "On hold" : "Cancelled"}:</b> {prj.status_reason}</p>}

      <div className="mb-3 grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-8">
        <Tile label="Contract value" value={inr(f.contract_value, 0)} sub="before GST" />
        <Tile label="Estimated cost" value={inr(f.estimated_cost, 0)} sub={f.uncosted_lines ? `${f.uncosted_lines} line(s) without a purchase price` : "from item purchase prices"} />
        <Tile label="Estimated profit" value={inr(f.estimated_profit, 0)} sub={f.estimated_margin_pct ? `${f.estimated_margin_pct}% margin` : undefined} tone={Number(f.estimated_profit) < 0 ? "text-brand-700" : "text-emerald-700"} />
        <Tile label="Work installed" value={inr(f.installed_value, 0)} sub={f.work_done_pct ? `${f.work_done_pct}% of BOQ value` : undefined} />
        <Tile label="Billed" value={inr(f.billed, 0)} sub={f.billed_pct ? `${f.billed_pct}% of contract · ${f.invoices} invoice(s)` : `${f.invoices} invoice(s), before GST`} />
        <Tile label="Collected" value={inr(f.collected, 0)} sub={[Number(f.advance) ? `${inr(f.advance, 0)} advance` : null, Number(f.outstanding) ? `${inr(f.outstanding, 0)} outstanding` : Number(f.billed) ? "nothing outstanding" : null].filter(Boolean).join(" · ") || "with GST, against invoices & advances"} tone="text-emerald-700" />
        <Tile label="Material cost" value={inr(f.material_cost, 0)} sub="issued from stores, net of returns" />
        <Tile label="Labour & other costs" value={inr(Number(f.actual_cost) - Number(f.material_cost), 0)} sub={[Number(f.labour_cost) && `labour ${inr(f.labour_cost, 0)}`, Number(f.subcontract_cost) && `subcontract ${inr(f.subcontract_cost, 0)}`, Number(f.travel_cost) && `travel ${inr(f.travel_cost, 0)}`, Number(f.other_cost) && `other ${inr(f.other_cost, 0)}`, Number(f.pending_expenses) && `${inr(f.pending_expenses, 0)} pending approval`].filter(Boolean).join(" · ") || "labour, subcontract, expenses & bills"} />
      </div>
      {(Number(f.billed) > 0 || Number(f.actual_cost) > 0) && (
        <p className="-mt-1 mb-3 text-xs text-ink-500">Actual cost so far <b className="num">{inr(f.actual_cost, 0)}</b> · gross profit (billed − actual cost): <b className={`num ${Number(f.gross_profit) < 0 ? "text-brand-700" : "text-emerald-700"}`}>{inr(f.gross_profit, 0)}</b>{f.gross_margin_pct ? ` · ${f.gross_margin_pct}%` : ""} · <button className="text-brand-700 hover:underline" onClick={() => setTab("costs")}>see costs</button></p>
      )}
      <Card className="mb-4">
        <div className="grid gap-4 sm:grid-cols-[1fr_auto_auto_auto] sm:items-center">
          <div>
            <div className="mb-1 flex items-center justify-between text-sm"><span className="font-medium text-ink-800">Progress</span><span className="num font-semibold">{prj.progress_pct}%</span></div>
            <ProgressBar value={prj.progress_pct} tone={prj.progress_pct >= 100 ? "green" : "brand"} className="h-2.5" />
            <p className="mt-1 text-xs text-ink-500">
              {can.site_update ? <button className="text-brand-700 hover:underline" onClick={() => setProgress(String(prj.progress_pct))}>Update progress</button> : null}
              {c.last_report ? `${can.site_update ? " · " : ""}last site report ${date(c.last_report)}` : ""}
            </p>
          </div>
          <button onClick={() => setTab("tasks")} className="text-left text-sm sm:px-4"><p className="text-xs text-ink-500">Tasks</p><p><b className="num">{c.tasks_done}</b>/{c.tasks_total} done{c.tasks_overdue ? <span className="ml-1.5 font-medium text-brand-700">{c.tasks_overdue} overdue</span> : null}</p></button>
          <button onClick={() => setTab("issues")} className="text-left text-sm sm:px-4"><p className="text-xs text-ink-500">Open issues</p><p className={c.issues_open ? "font-medium text-amber-700" : ""}>{c.issues_open}</p></button>
          <div className="text-sm sm:px-4"><p className="text-xs text-ink-500">Target</p><p className={prj.late ? "font-medium text-brand-700" : ""}>{date(prj.target_end_date)}</p></div>
        </div>
      </Card>

      <Tabs<Tab> value={tab} onChange={setTab} tabs={[
        { id: "overview", label: "Overview" }, { id: "boq", label: "BOQ & installation" }, { id: "materials", label: "Materials" }, { id: "costs", label: "Costs & profit" }, { id: "tasks", label: "Tasks", count: c.tasks_open },
        { id: "issues", label: "Issues", count: c.issues_open }, { id: "reports", label: "Site reports" }, { id: "documents", label: "Documents" }, { id: "history", label: "History" },
      ]} />
      {tab === "overview" && (
        <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
          <div className="space-y-4">
            <Card title="Details">
              <Detail cols={3} items={[
                ["Customer", <Link key="c" href={`/customers/view?id=${prj.customer_id}`} className="text-brand-700 hover:underline">{prj.customer?.name}</Link>],
                ["Sales order", prj.sales_order_id ? <Link key="s" href={`/sales/orders/view?id=${prj.sales_order_id}`} className="text-brand-700 hover:underline">{prj.so_number}</Link> : "Without an order"],
                ["Division", prj.division], ["Start", date(prj.start_date)], ["Target completion", date(prj.target_end_date)],
                ["Completed", date(prj.actual_end_date)], ["Priority", prj.priority], ["Site address", prj.site_address], ["Created", `${prj.created_by ?? ""} · ${date(prj.created_at)}`],
              ]} />
              {prj.description && <p className="mt-3 whitespace-pre-line border-t border-ink-100 pt-3 text-sm">{prj.description}</p>}
            </Card>
            <Milestones prj={prj} onChanged={refresh} />
          </div>
          <Team prj={prj} onChanged={refresh} />
        </div>
      )}
      {tab === "boq" && <BoqTab prj={prj} onChanged={refresh} />}
      {tab === "tasks" && <TasksTab prj={prj} onChanged={refresh} />}
      {tab === "issues" && <IssuesTab prj={prj} onChanged={refresh} />}
      {tab === "reports" && <ReportsTab prj={prj} onChanged={refresh} />}
      {tab === "materials" && <MaterialsTab prj={prj} />}
      {tab === "costs" && <CostsTab prj={prj} onChanged={refresh} />}
      {tab === "documents" && <DocumentsPanel entityType="project" entityId={id} canEdit={can.update} defaultCategory="drawing" />}
      {tab === "history" && <HistoryPanel entityType="project" entityId={id} />}

      {editing && <EditDialog prj={prj} open onClose={() => setEditing(false)} onSaved={() => { toast("Project saved"); refresh(); }} />}
      <Modal open={!!statusTo} onClose={() => setStatusTo(null)} title={statusTo === "active" ? "Reopen the project" : statusTo === "on_hold" ? "Put the project on hold" : "Cancel the project"}
        footer={<><Button variant="secondary" onClick={() => setStatusTo(null)}>Back</Button><Button disabled={!reason.trim()} onClick={async () => { await changeStatus(statusTo!, reason.trim()); setStatusTo(null); }}>Confirm</Button></>}>
        <Field label="Reason" required hint="The team is notified."><Textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
      </Modal>
      <Modal open={progress !== null} onClose={() => setProgress(null)} title="Update progress"
        footer={<><Button variant="secondary" onClick={() => setProgress(null)}>Cancel</Button><Button onClick={async () => {
          try { await api(`/projects/${id}/progress`, { method: "PUT", body: { progress_pct: Number(progress) } }); setProgress(null); refresh(); } catch (e: any) { toast(e.message, "error"); }
        }}>Save</Button></>}>
        <Field label={`Overall progress: ${progress ?? 0}%`}><input type="range" min={0} max={100} step={5} value={progress ?? 0} onChange={(e) => setProgress(e.target.value)} className="w-full accent-brand-600" /></Field>
      </Modal>
    </>
  );
}

export default function Page() {
  return <Suspense><ProjectDetail /></Suspense>;
}
