"use client";

import { useQueryClient } from "@tanstack/react-query";
import { ListChecks } from "lucide-react";
import { Button, Card, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { TASK_STATUSES, TaskList } from "@/components/projects/common";
import { useAuth } from "@/lib/auth";
import { useList } from "@/lib/hooks";

/** My tasks across projects (everyone), or all tasks the user can see (project team / managers). */
export default function TasksPage() {
  const { can } = useAuth();
  const qc = useQueryClient();
  const seeAll = can("site_work.read");
  const list = useList<any>("/tasks", { filters: { mine: "true", open_only: "true" } });
  const mine = list.filters.mine === "true";
  const statusValue = list.filters.status || (list.filters.overdue === "true" ? "_overdue" : list.filters.open_only === "true" ? "_open" : "");
  const setStatus = (v: string) => {
    list.setFilter("open_only", v === "_open" ? "true" : "");
    list.setFilter("overdue", v === "_overdue" ? "true" : "");
    list.setFilter("status", v.startsWith("_") ? "" : v);
  };
  return (
    <>
      <PageHeader title="Tasks" subtitle="Project tasks, soonest due first. Change the status as you work — the project manager sees it at once." />
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row sm:items-center">
          {seeAll && (
            <div className="flex gap-1">
              <Button size="sm" variant={mine ? "primary" : "secondary"} onClick={() => list.setFilter("mine", "true")}>My tasks</Button>
              <Button size="sm" variant={!mine ? "primary" : "secondary"} onClick={() => list.setFilter("mine", "")}>All projects</Button>
            </div>
          )}
          <Input placeholder="Search task or project…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-xs" />
          <Select value={statusValue} onChange={(e) => setStatus(e.target.value)} className="sm:w-48" aria-label="Status">
            <option value="_open">Not done</option>
            <option value="_overdue">Overdue</option>
            <option value="">All</option>
            {TASK_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : list.rows.length === 0 ? (
          <div className="p-6"><EmptyState icon={<ListChecks className="size-8" />} title={mine ? "No tasks for you here" : "No tasks match"} body="Tasks are created on each project's Tasks tab." /></div>
        ) : <TaskList tasks={list.rows} showProject onChanged={() => { qc.invalidateQueries({ queryKey: ["/tasks"] }); qc.invalidateQueries({ queryKey: ["/projects"] }); }} />}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
