"use client";

import { Suspense } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useQueryClient } from "@tanstack/react-query";
import { ListChecks } from "lucide-react";
import { Button, Card, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { TASK_STATUSES, TaskList } from "@/components/projects/common";
import { TasksByEmployee } from "@/components/projects/tasks-by-employee";
import { useAuth } from "@/lib/auth";
import { useList } from "@/lib/hooks";

/** My tasks across projects (everyone), all tasks the user can see (project team / managers), and — for people who
 *  see every project (Administrator, Director, Manager) — every employee's tasks. */
function TasksPage() {
  const { can, me } = useAuth();
  const qc = useQueryClient();
  const router = useRouter();
  const pathname = usePathname();
  const seeAll = can("site_work.read");
  const seeEveryone = me?.permissions["site_work.read"] === "all";
  const view = useSearchParams().get("view");
  const byEmployee = seeEveryone && view === "employee";
  const list = useList<any>("/tasks", { filters: { mine: "true", open_only: "true" } });
  const mine = list.filters.mine === "true";
  const statusValue = list.filters.status || (list.filters.overdue === "true" ? "_overdue" : list.filters.open_only === "true" ? "_open" : "");
  const setStatus = (v: string) => {
    list.setFilter("open_only", v === "_open" ? "true" : "");
    list.setFilter("overdue", v === "_overdue" ? "true" : "");
    list.setFilter("status", v.startsWith("_") ? "" : v);
  };
  const show = (view: "mine" | "all" | "employee") => {
    if (view === "employee") return router.replace(`${pathname}?view=employee`);
    if (byEmployee) router.replace(pathname);
    list.setFilter("mine", view === "mine" ? "true" : "");
  };
  return (
    <>
      <PageHeader title="Tasks" subtitle={byEmployee ? "Every employee's tasks across all projects. Click a name to see the tasks." : "Project tasks, soonest due first. Change the status as you work — the project manager sees it at once."} />
      {seeAll && (
        <div className="mb-3 flex flex-wrap gap-1">
          <Button size="sm" variant={!byEmployee && mine ? "primary" : "secondary"} onClick={() => show("mine")}>My tasks</Button>
          <Button size="sm" variant={!byEmployee && !mine ? "primary" : "secondary"} onClick={() => show("all")}>All projects</Button>
          {seeEveryone && <Button size="sm" variant={byEmployee ? "primary" : "secondary"} onClick={() => show("employee")}>By employee</Button>}
        </div>
      )}
      {byEmployee ? <TasksByEmployee /> : (
        <Card padded={false}>
          <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row sm:items-center">
            <Input placeholder="Search task or project…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-xs" />
            <Select value={statusValue} onChange={(e) => setStatus(e.target.value)} className="sm:w-48" aria-label="Status">
              <option value="_open">Not done</option>
              <option value="_overdue">Overdue</option>
              <option value="">All</option>
              {TASK_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </Select>
          </div>
          {list.isLoading ? <Spinner /> : list.rows.length === 0 ? (
            <div className="p-6"><EmptyState icon={<ListChecks className="size-8" />} title={mine ? "No tasks for you here" : "No tasks match"} body="Tasks are created on each project's Tasks tab." /></div>
          ) : <TaskList tasks={list.rows} showProject onChanged={() => { qc.invalidateQueries({ queryKey: ["/tasks"] }); qc.invalidateQueries({ queryKey: ["/projects"] }); }} />}
          {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
        </Card>
      )}
    </>
  );
}

export default function Page() {
  return <Suspense><TasksPage /></Suspense>;
}
