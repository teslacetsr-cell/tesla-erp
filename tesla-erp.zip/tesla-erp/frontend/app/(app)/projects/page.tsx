"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Briefcase, Plus } from "lucide-react";
import { Button, Card, DataTable, EmptyState, Input, PageHeader, Pagination, Select, Spinner } from "@/components/ui";
import { MiniStat } from "@/components/crm/common";
import { PROJECT_STATUSES, ProgressBar, ProjectStatus } from "@/components/projects/common";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";
import { useList } from "@/lib/hooks";

export default function ProjectsPage() {
  const router = useRouter();
  const { can } = useAuth();
  const list = useList<any>("/projects", { filters: { open_only: "true" } });
  const summary = useQuery({ queryKey: ["/projects/summary"], queryFn: () => api<any>("/projects/summary"), select: (r) => r.data });
  const s = summary.data;
  const statusValue = list.filters.status || (list.filters.open_only === "true" ? "_open" : "");
  const setStatus = (v: string) => { list.setFilter("open_only", v === "_open" ? "true" : ""); list.setFilter("status", v.startsWith("_") ? "" : v); };
  return (
    <>
      <PageHeader title="Projects" subtitle="Execution of sales orders: team, tasks, site reports and BOQ tracking."
        actions={can("project.create") && <Link href="/projects/new"><Button icon={<Plus className="size-4" />}>New project</Button></Link>} />
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <MiniStat label="Active" value={s?.active} onClick={() => setStatus("active")} active={statusValue === "active"} />
        <MiniStat label="Past target date" value={s?.late} tone="red" />
        <MiniStat label="Overdue tasks" value={s?.overdue_tasks} tone="amber" />
        <MiniStat label="Open project value" value={s ? inr(s.contract_value, 0) : undefined} />
      </div>
      <Card padded={false}>
        <div className="flex flex-col gap-2 border-b border-ink-100 p-3 sm:flex-row">
          <Input placeholder="Search project, number, customer…" value={list.q} onChange={(e) => list.setQ(e.target.value)} className="sm:max-w-sm" />
          <Select value={statusValue} onChange={(e) => setStatus(e.target.value)} className="sm:w-52" aria-label="Status">
            <option value="_open">Open projects</option>
            <option value="">All statuses</option>
            {PROJECT_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
        </div>
        {list.isLoading ? <Spinner /> : (
          <DataTable rows={list.rows} sort={list.sort} onSort={list.setSort} onRowClick={(r) => router.push(`/projects/view?id=${r.id}`)}
            empty={<EmptyState icon={<Briefcase className="size-8" />} title={list.q ? "No projects match your search" : "No projects here"} body="Create a project from a sales order." />}
            columns={[
              { key: "n", header: "Project", sortKey: "project_number", cell: (r) => <div><p className="font-medium text-ink-900">{r.name}</p><p className="text-xs text-ink-500">{r.project_number}{r.so_number ? ` · ${r.so_number}` : ""}</p></div> },
              { key: "c", header: "Customer", cell: (r) => r.customer?.name },
              { key: "pm", header: "Project manager", hideOnMobile: true, cell: (r) => r.project_manager ?? "—" },
              { key: "e", header: "Target", sortKey: "target_end_date", hideOnMobile: true, cell: (r) => <span className={r.late ? "font-medium text-brand-700" : ""}>{date(r.target_end_date)}</span> },
              { key: "p", header: "Progress", sortKey: "progress_pct", cell: (r) => <div className="w-24"><p className="num text-xs text-ink-600">{r.progress_pct}%</p><ProgressBar value={r.progress_pct} /></div> },
              { key: "v", header: "Contract", sortKey: "contract_value", className: "text-right", hideOnMobile: true, cell: (r) => <span className="num">{inr(r.contract_value, 0)}</span> },
              { key: "s", header: "Status", sortKey: "status", cell: (r) => <ProjectStatus status={r.status} /> },
            ]} />
        )}
        {list.meta && list.meta.total > 0 && <Pagination page={list.page} pageSize={list.meta.page_size} total={list.meta.total} onPage={list.setPage} />}
      </Card>
    </>
  );
}
