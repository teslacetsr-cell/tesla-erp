"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Button, ErrorNote, Field, Input } from "@/components/ui";
import { useAuth } from "@/lib/auth";

function LoginForm() {
  const { login, me, loading } = useAuth();
  const router = useRouter();
  const params = useSearchParams();
  const [ident, setIdent] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  useEffect(() => {
    if (!loading && me) router.replace(me.must_change_password ? "/change-password" : params.get("next") || "/dashboard");
  }, [loading, me, router, params]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await login(ident, password);
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="w-full max-w-sm space-y-4">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Sign in</h1>
        <p className="mt-1 text-sm text-ink-500">Use your ERP username or work email.</p>
      </div>
      {params.get("expired") && !error && (
        <p className="rounded-md bg-ink-50 px-3 py-2 text-sm text-ink-600">Your session ended. Please sign in again.</p>
      )}
      <ErrorNote error={error} />
      <Field label="Username or email">
        <Input autoFocus autoComplete="username" value={ident} onChange={(e) => setIdent(e.target.value)} required />
      </Field>
      <Field label="Password">
        <Input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
      </Field>
      <Button type="submit" className="w-full" loading={busy}>
        Sign in
      </Button>
      <p className="text-xs text-ink-500">Forgotten your password? Ask an administrator to reset it.</p>
    </form>
  );
}

export default function LoginPage() {
  return (
    <main className="grid min-h-dvh lg:grid-cols-[1fr_1.1fr]">
      <section className="relative hidden overflow-hidden bg-brand-600 lg:flex lg:flex-col lg:justify-between lg:p-12">
        <div className="absolute -right-40 -top-40 size-[520px] rounded-full border-[40px] border-white/10" />
        <div className="absolute -bottom-52 -left-24 size-[460px] rounded-full border-[28px] border-white/10" />
        <div className="relative flex items-center gap-3 text-white">
          <img src="/brand/tce-logo-192.png" alt="" className="size-12 rounded-full ring-2 ring-white/60" />
          <div>
            <p className="text-lg font-semibold leading-tight">Tesla Consulting Engineers</p>
            <p className="text-sm text-white/80">Enterprise Resource Planning</p>
          </div>
        </div>
        <div className="relative text-white">
          <p className="max-w-md text-4xl font-semibold leading-tight tracking-tight">Empowering Safety, Protecting Lives.</p>
          <p className="mt-4 max-w-md text-white/80">
            Lightning &amp; surge protection · Electrical safety · Solar EPC · EV charging · Testing &amp; AMC
          </p>
        </div>
        <p className="relative text-xs text-white/60">© {new Date().getFullYear()} Tesla Consulting Engineers</p>
      </section>
      <section className="flex flex-col items-center justify-center gap-8 px-6 py-12">
        <div className="flex items-center gap-3 lg:hidden">
          <img src="/brand/tce-logo-192.png" alt="TCE" className="size-14" />
          <div>
            <p className="font-semibold">Tesla Consulting Engineers</p>
            <p className="text-sm text-ink-500">ERP</p>
          </div>
        </div>
        <Suspense>
          <LoginForm />
        </Suspense>
      </section>
    </main>
  );
}
