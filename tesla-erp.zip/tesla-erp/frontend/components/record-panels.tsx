"use client";

import { useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { FileText, History, Image as ImageIcon, Trash2, Upload } from "lucide-react";
import { Badge, Button, Card, EmptyState, Select, Spinner, useConfirm, useToast } from "@/components/ui";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { bytes, dateTime, titleCase } from "@/lib/format";

export const CATEGORIES = ["agreement", "drawing", "certificate", "test_report", "site_photo", "report", "customer_document", "supplier_document", "po", "quotation", "invoice", "bill", "receipt", "other"];

type Doc = { id: string; version: number; file_name: string; category: string; size_bytes: number; content_type: string; uploaded_at: string };

export function DocumentsPanel({ entityType, entityId, canEdit, defaultCategory = "other" }: {
  entityType: string;
  entityId: string;
  canEdit: boolean;
  defaultCategory?: string;
}) {
  const key = ["/documents", entityType, entityId];
  const { data, isLoading } = useQuery({
    queryKey: key,
    queryFn: () => api<{ data: Doc[] }>("/documents", { params: { entity_type: entityType, entity_id: entityId } }),
  });
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const input = useRef<HTMLInputElement>(null);
  const [category, setCategory] = useState(defaultCategory);
  const [busy, setBusy] = useState(false);
  const [replaceId, setReplaceId] = useState<string | null>(null);

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true);
    try {
      for (const f of Array.from(files)) {
        const form = new FormData();
        form.append("entity_type", entityType);
        form.append("entity_id", entityId);
        form.append("category", category);
        if (replaceId) form.append("replaces", replaceId);
        form.append("file", f);
        await api("/documents", { method: "POST", form });
      }
      toast(replaceId ? "New version uploaded" : "Uploaded");
      qc.invalidateQueries({ queryKey: key }); qc.invalidateQueries({ queryKey: ["/document-library"] });
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setBusy(false);
      setReplaceId(null);
      if (input.current) input.current.value = "";
    }
  }

  return (
    <Card
      title="Documents"
      padded={false}
      actions={
        canEdit && (
          <div className="flex items-center gap-2">
            <Select value={category} onChange={(e) => setCategory(e.target.value)} className="h-8 w-40 text-[13px]">
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>{titleCase(c)}</option>
              ))}
            </Select>
            <Button size="sm" icon={<Upload className="size-3.5" />} loading={busy} onClick={() => { setReplaceId(null); input.current?.click(); }}>
              Upload
            </Button>
            <input ref={input} type="file" multiple className="sr-only" onChange={(e) => upload(e.target.files)}
              accept=".pdf,.jpg,.jpeg,.png,.webp,.heic,.docx,.xlsx,.pptx,.dwg,.csv,.txt" />
          </div>
        )
      }
    >
      {isLoading ? (
        <Spinner />
      ) : !data?.data.length ? (
        <EmptyState icon={<FileText className="size-8" />} title="No documents" body="PDF, images, Office files and DWG drawings up to 25 MB. Files are kept in secure storage, never on the app server." />
      ) : (
        <ul className="divide-y divide-ink-100">
          {data.data.map((d) => (
            <li key={d.id} className="flex items-center gap-3 px-4 py-2.5">
              {d.content_type.startsWith("image/") ? <ImageIcon className="size-5 text-ink-400" /> : <FileText className="size-5 text-ink-400" />}
              <button className="min-w-0 flex-1 text-left" onClick={() => download(`/documents/${d.id}/content`, d.file_name)}>
                <p className="truncate text-sm font-medium text-ink-900 hover:text-brand-700">{d.file_name}</p>
                <p className="text-xs text-ink-500">
                  {titleCase(d.category)} · {bytes(d.size_bytes)} · {dateTime(d.uploaded_at)}
                </p>
              </button>
              {d.version > 1 && <Badge tone="blue">v{d.version}</Badge>}
              {canEdit && (
                <>
                  <Button size="sm" variant="ghost" title="Upload a new version" onClick={() => { setReplaceId(d.id); setCategory(d.category); input.current?.click(); }}>
                    New version
                  </Button>
                  <Button size="sm" variant="ghost" aria-label="Remove" onClick={async () => {
                    if (await confirm({ title: "Remove document?", body: `“${d.file_name}” will be hidden from this record. The file is retained in storage for recovery.`, confirmLabel: "Remove" })) {
                      await api(`/documents/${d.id}`, { method: "DELETE" });
                      qc.invalidateQueries({ queryKey: key }); qc.invalidateQueries({ queryKey: ["/document-library"] });
                    }
                  }}>
                    <Trash2 className="size-4 text-ink-400" />
                  </Button>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

type Log = { id: number; occurred_at: string; user_name: string | null; action: string; entity_type: string; entity_label: string | null; summary: string | null; changes: Record<string, { old: unknown; new: unknown }> | null };

export function HistoryPanel({ entityType, entityId }: { entityType: string; entityId: string }) {
  const { can } = useAuth();
  const { data, isLoading } = useQuery({
    queryKey: ["/audit-logs", entityType, entityId],
    queryFn: () => api<{ data: Log[] }>("/audit-logs", { params: { entity_id: entityId, page_size: 50 } }),
    enabled: can("audit.read"),
  });
  if (!can("audit.read")) return <EmptyState title="History is visible to administrators and directors." />;
  if (isLoading) return <Spinner />;
  if (!data?.data.length) return <EmptyState icon={<History className="size-8" />} title="No history yet" />;
  return <AuditList logs={data.data} />;
}

export function AuditList({ logs, showEntity = false }: { logs: Log[]; showEntity?: boolean }) {
  return (
    <ol className="space-y-3">
      {logs.map((l) => (
        <li key={l.id} className="rounded-lg border border-ink-200 bg-white px-4 py-3">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <p className="text-sm">
              <span className="font-medium">{l.user_name ?? "System"}</span>{" "}
              <span className="text-ink-600">{titleCase(l.action).toLowerCase()}</span>
              {showEntity && (
                <span className="text-ink-600">
                  {" "}{titleCase(l.entity_type).toLowerCase()}
                  {l.entity_label && <span className="text-ink-900"> · {l.entity_label}</span>}
                </span>
              )}
            </p>
            <span className="text-xs text-ink-400">{dateTime(l.occurred_at)}</span>
          </div>
          {l.summary && <p className="mt-1 text-sm text-ink-600">{l.summary}</p>}
          {l.changes && Object.keys(l.changes).length > 0 && (
            <table className="mt-2 w-full text-xs">
              <tbody>
                {Object.entries(l.changes).map(([field, c]) => (
                  <tr key={field} className="border-t border-ink-100">
                    <td className="w-40 py-1 pr-3 font-medium text-ink-600">{titleCase(field)}</td>
                    <td className="py-1 pr-3 text-ink-500 line-through decoration-ink-300">{fmt(c.old)}</td>
                    <td className="py-1 text-ink-900">{fmt(c.new)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </li>
      ))}
    </ol>
  );
}

function fmt(v: unknown): string {
  if (v === null || v === undefined || v === "") return "—";
  if (typeof v === "object") return JSON.stringify(v);
  return String(v);
}
