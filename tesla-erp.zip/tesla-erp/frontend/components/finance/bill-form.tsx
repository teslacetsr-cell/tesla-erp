"use client";

import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle } from "lucide-react";
import { Button, Card, ErrorNote, Field, Input, Select, Textarea } from "@/components/ui";
import { blankLine, lineProblems, LinesEditor, preview, toPayload, toRows, TotalsBox, type LineRow } from "@/components/lines-editor";
import { useProjectOptions, useSuppliers } from "@/components/purchase/common";
import { api, ApiError, type Page } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { qty } from "@/lib/format";

const trim = (v: any) => { const s = String(v ?? ""); return s.includes(".") ? s.replace(/0+$/, "").replace(/\.$/, "") : s; };
const today = () => new Date(Date.now() + 5.5 * 3600_000).toISOString().slice(0, 10);

/** Supplier invoice entered against its PO (3-way match with what the GRNs accepted) or directly (services, rent…). */
export function BillForm({ initial, poId, onSubmit, onCancel, submitLabel }: {
  initial?: any; poId?: string | null; onSubmit: (body: any) => Promise<void>; onCancel: () => void; submitLabel: string;
}) {
  const { can } = useAuth();
  const suppliers = useSuppliers();
  const projects = useProjectOptions(can("project.read"));
  const ledgers = useQuery({ queryKey: ["/finance/bill-ledgers"], queryFn: () => api<any>("/finance/bill-ledgers"), select: (r) => r.data as any[], staleTime: 5 * 60_000 });
  const company = useQuery({ queryKey: ["/company"], queryFn: () => api<any>("/company"), select: (r) => r.data, staleTime: 10 * 60_000 });
  const [h, setH] = useState({
    supplier_id: initial?.supplier_id ?? "", supplier_invoice_no: initial?.supplier_invoice_no ?? "", supplier_invoice_date: initial?.supplier_invoice_date ?? today(),
    due_date: initial?.due_date ?? "", purchase_order_id: initial?.purchase_order?.id ?? poId ?? "", project_id: initial?.project?.id ?? "",
    account_id: initial?.account?.id ?? "", notes: initial?.notes ?? "", special_discount: initial && Number(initial.special_discount) ? trim(initial.special_discount) : "",
  });
  const billable = useQuery({ queryKey: ["/purchase-orders", h.purchase_order_id, "billable"], queryFn: () => api<any>(`/purchase-orders/${h.purchase_order_id}/billable`), select: (r) => r.data, enabled: !!h.purchase_order_id });
  const pos = useQuery({
    queryKey: ["/purchase-orders", "for-bill", h.supplier_id],
    queryFn: () => api<Page<any>>("/purchase-orders", { params: { supplier_id: h.supplier_id, page_size: 100 } }),
    select: (r) => r.data.filter((p: any) => ["approved", "sent", "partially_received", "received", "closed"].includes(p.status) || p.id === h.purchase_order_id),
    enabled: !!h.supplier_id && can("purchase_order.read"),
  });
  const sup = useQuery({ queryKey: ["/suppliers", h.supplier_id], queryFn: () => api<any>(`/suppliers/${h.supplier_id}`), select: (r) => r.data, enabled: !!h.supplier_id });
  const [poQty, setPoQty] = useState<Record<string, { qty: string; rate: string }>>(() =>
    Object.fromEntries((initial?.items ?? []).filter((i: any) => i.po_item_id).map((i: any) => [i.po_item_id, { qty: trim(i.quantity), rate: trim(i.rate) }])));
  const [extra, setExtra] = useState<LineRow[]>(() => (initial ? toRows(initial.items.filter((i: any) => !i.po_item_id)) : poId ? [] : [blankLine()]));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof h) => (e: { target: { value: string } }) => setH({ ...h, [k]: e.target.value });
  // from a PO: supplier and project follow the order; default every received-not-billed quantity
  useEffect(() => {
    const b = billable.data;
    if (!b) return;
    setH((x) => ({ ...x, supplier_id: x.supplier_id || b.supplier.id, project_id: x.project_id || b.purchase_order.project_id || "" }));
    if (!initial && !Object.keys(poQty).length)
      setPoQty(Object.fromEntries(b.lines.filter((l: any) => Number(l.to_bill_qty) > 0).map((l: any) => [l.po_item_id, { qty: trim(l.to_bill_qty), rate: trim(l.rate) }])));
  }, [billable.data]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!h.account_id && ledgers.data?.length) setH((x) => ({ ...x, account_id: (ledgers.data!.find((l) => l.default) ?? ledgers.data![0]).id }));
  }, [ledgers.data, h.account_id]);
  const lines: any[] = h.purchase_order_id ? billable.data?.lines ?? [] : [];
  const poRows: LineRow[] = lines.filter((l) => Number(poQty[l.po_item_id]?.qty || 0) > 0).map((l) => ({
    ...blankLine(), item_id: l.item_id, description: l.description, hsn_sac: l.hsn_sac ?? "", quantity: poQty[l.po_item_id].qty, unit: l.unit,
    rate: poQty[l.po_item_id].rate || trim(l.rate), discount_pct: trim(l.discount_pct), tax_rate: trim(l.tax_rate), links: { po_item_id: l.po_item_id },
  }));
  const all = [...poRows, ...extra];
  const interState = !!(sup.data?.state_code && company.data?.state_code && sup.data.state_code !== company.data.state_code);
  const calc = preview(all, interState, Number(h.special_discount) || 0, true);
  const diffs = lines.filter((l) => {
    const v = poQty[l.po_item_id];
    return v && (Number(v.qty || 0) > Number(l.to_bill_qty) + 1e-9 || Number(v.rate || l.rate) > Number(l.rate) + 0.0001);
  });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!h.supplier_id) return setError(new Error("Choose the supplier."));
    if (!h.supplier_invoice_no.trim()) return setError(new Error("Enter the supplier's invoice number."));
    if (!all.length) return setError(new Error("Add at least one line."));
    const problem = lineProblems(extra);
    if (problem) return setError(new Error(problem));
    const v = (s: string) => (s.trim() === "" ? null : s.trim());
    setBusy(true);
    try {
      await onSubmit({
        supplier_id: h.supplier_id, supplier_invoice_no: h.supplier_invoice_no.trim(), supplier_invoice_date: h.supplier_invoice_date,
        due_date: v(h.due_date), purchase_order_id: v(h.purchase_order_id), project_id: v(h.project_id), account_id: v(h.account_id),
        notes: v(h.notes), special_discount: v(h.special_discount) ?? "0", items: toPayload(all),
      });
    } catch (err) {
      setError(err);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } finally { setBusy(false); }
  }

  return (
    <form onSubmit={submit} className="space-y-5">
      <ErrorNote error={error} />
      {initial?.last_rejection && <p className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900"><b>Returned by the approver:</b> {initial.last_rejection}</p>}
      <Card title="Supplier's invoice">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Supplier" required className="sm:col-span-2" hint={sup.data?.state_code ? `${sup.data.state ?? sup.data.state_code} · ${interState ? "IGST" : "CGST + SGST"}` : undefined}>
            <Select value={h.supplier_id} onChange={(e) => { setH({ ...h, supplier_id: e.target.value, purchase_order_id: "" }); setPoQty({}); }} disabled={!!poId && !initial}>
              <option value="">— Choose —</option>
              {(suppliers.data ?? []).map((s) => <option key={s.id} value={s.id}>{s.supplier_name}{s.city ? ` · ${s.city}` : ""}</option>)}
            </Select>
          </Field>
          <Field label="Supplier's invoice no." required><Input value={h.supplier_invoice_no} onChange={set("supplier_invoice_no")} /></Field>
          <Field label="Invoice date" required><Input type="date" value={h.supplier_invoice_date} onChange={set("supplier_invoice_date")} /></Field>
          <Field label="Purchase order" className="sm:col-span-2" hint="Lines are matched to what was received">
            <Select value={h.purchase_order_id} onChange={(e) => { setH({ ...h, purchase_order_id: e.target.value }); setPoQty({}); }} disabled={!h.supplier_id}>
              <option value="">— No PO (services, rent…) —</option>
              {(pos.data ?? []).map((p: any) => <option key={p.id} value={p.id}>{p.display_number ?? p.po_number}{p.project ? ` · ${p.project.number}` : ""}</option>)}
            </Select>
          </Field>
          <Field label="Due date" hint="Blank = supplier's credit days"><Input type="date" value={h.due_date} onChange={set("due_date")} /></Field>
          <Field label="Book to ledger">
            <Select value={h.account_id} onChange={set("account_id")}>{(ledgers.data ?? []).map((l) => <option key={l.id} value={l.id}>{l.name}{l.cost_head ? " (project cost)" : ""}</option>)}</Select>
          </Field>
          <Field label="Project" className="sm:col-span-2" hint="Subcontract / labour bills for a project become project cost">
            <Select value={h.project_id} onChange={set("project_id")}>
              <option value="">— Not for a project —</option>
              {(projects.data ?? []).map((p) => <option key={p.id} value={p.id}>{p.project_number} · {p.name}</option>)}
            </Select>
          </Field>
        </div>
      </Card>
      {h.purchase_order_id && (
        <Card title={`Lines from ${billable.data?.purchase_order?.po_number ?? "the PO"}`} actions={<span className="text-xs text-ink-500">Billing more than received, or above the PO rate, needs approval</span>}>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-sm">
              <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
                <th className="px-2 py-2">Item</th><th className="px-2 py-2 text-right">Ordered</th><th className="px-2 py-2 text-right">Received</th>
                <th className="px-2 py-2 text-right">Billed</th><th className="px-2 py-2 text-right">To bill</th><th className="w-28 px-2 py-2 text-right">Qty billed</th><th className="w-32 px-2 py-2 text-right">Rate</th></tr></thead>
              <tbody>{lines.map((l) => {
                const v = poQty[l.po_item_id] ?? { qty: "", rate: "" };
                const over = Number(v.qty || 0) > Number(l.to_bill_qty) + 1e-9;
                const dear = Number(v.rate || l.rate) > Number(l.rate) + 0.0001;
                return (
                  <tr key={l.po_item_id} className="border-b border-ink-100 align-top">
                    <td className="px-2 py-2"><p>{l.description}</p><p className="text-xs text-ink-500">PO rate {trim(l.rate)}{Number(l.discount_pct) ? ` −${Number(l.discount_pct)}%` : ""} · GST {Number(l.tax_rate)}%</p></td>
                    <td className="num px-2 py-2 text-right">{qty(l.ordered_qty)}</td>
                    <td className="num px-2 py-2 text-right text-emerald-700">{qty(l.received_qty)}</td>
                    <td className="num px-2 py-2 text-right text-ink-500">{qty(l.billed_qty)}</td>
                    <td className="num px-2 py-2 text-right font-medium">{qty(l.to_bill_qty)}</td>
                    <td className="px-2 py-1.5"><Input inputMode="decimal" className={`num h-8 text-right ${over ? "border-amber-500" : ""}`} aria-label={`Qty billed, ${l.description}`} value={v.qty} onChange={(e) => setPoQty({ ...poQty, [l.po_item_id]: { ...v, qty: e.target.value } })} /></td>
                    <td className="px-2 py-1.5"><Input inputMode="decimal" className={`num h-8 text-right ${dear ? "border-amber-500" : ""}`} aria-label={`Rate, ${l.description}`} value={v.rate || trim(l.rate)} onChange={(e) => setPoQty({ ...poQty, [l.po_item_id]: { ...v, rate: e.target.value } })} /></td>
                  </tr>
                );
              })}</tbody>
            </table>
          </div>
          {diffs.length > 0 && <p className="mt-3 flex items-center gap-1.5 text-sm text-amber-800"><AlertTriangle className="size-4" /> {diffs.length} line(s) differ from the PO / GRN — the bill will go for approval when posted.</p>}
        </Card>
      )}
      <Card title={h.purchase_order_id ? "Other charges (freight, not on the PO…)" : "Items"}>
        {h.purchase_order_id && !extra.length ? <Button type="button" size="sm" variant="secondary" onClick={() => setExtra([blankLine()])}>Add a line not on the PO</Button>
          : <LinesEditor rows={extra} onChange={setExtra} gstRates={["0", "5", "12", "18", "28"]} interState={interState} price="purchase_price" />}
        <div className="mt-5 grid gap-4 border-t border-ink-100 pt-4 lg:grid-cols-[1fr_380px]">
          <div className="space-y-4">
            <Field label="Special discount (₹)" className="max-w-xs"><Input inputMode="decimal" className="num" value={h.special_discount} onChange={set("special_discount")} placeholder="0" /></Field>
            <Field label="Notes"><Textarea rows={2} value={h.notes} onChange={set("notes")} /></Field>
          </div>
          <TotalsBox interState={interState} t={{ gross: calc.gross, lineDiscount: calc.lineDiscount, special: calc.special, taxable: calc.taxable, cgst: calc.cgst, sgst: calc.sgst, igst: calc.igst, roundOff: calc.roundOff, grand: calc.grand }} />
        </div>
      </Card>
      <div className="sticky bottom-0 -mx-4 flex justify-end gap-2 border-t border-ink-200 bg-white/95 px-4 py-3 backdrop-blur sm:static sm:mx-0 sm:border-0 sm:bg-transparent sm:p-0">
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
        <Button type="submit" loading={busy}>{submitLabel}</Button>
      </div>
    </form>
  );
}
