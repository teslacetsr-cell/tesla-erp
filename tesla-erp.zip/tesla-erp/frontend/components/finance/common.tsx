"use client";

import { useQuery } from "@tanstack/react-query";
import { Wand2 } from "lucide-react";
import { Badge, Button, Input } from "@/components/ui";
import { api, type Page } from "@/lib/api/client";
import { date, inr, titleCase } from "@/lib/format";

type Tone = "green" | "red" | "grey" | "amber" | "blue";

export const INVOICE_STATUSES: [string, string, Tone][] = [["draft", "Draft", "grey"], ["issued", "Issued", "blue"], ["cancelled", "Cancelled", "grey"]];
export const PAYMENT_STATUSES: [string, string, Tone][] = [["unpaid", "Unpaid", "amber"], ["partially_paid", "Part paid", "blue"], ["paid", "Paid", "green"]];
export const BILL_STATUSES: [string, string, Tone][] = [["draft", "Draft", "grey"], ["pending_approval", "Pending approval", "amber"], ["posted", "Posted", "blue"], ["cancelled", "Cancelled", "grey"]];
export const EXPENSE_STATUSES: [string, string, Tone][] = [["draft", "Draft", "grey"], ["submitted", "Waiting for approval", "amber"], ["approved", "Approved — to pay", "blue"], ["paid", "Paid", "green"], ["rejected", "Rejected", "red"], ["cancelled", "Cancelled", "grey"]];
export const MODES: [string, string][] = [["neft", "NEFT"], ["rtgs", "RTGS"], ["imps", "IMPS"], ["upi", "UPI"], ["cheque", "Cheque"], ["cash", "Cash"], ["dd", "Demand draft"], ["card", "Card"], ["other", "Other"]];
export const BILL_TYPES: [string, string][] = [["regular", "Tax invoice"], ["running", "Running (RA) bill"], ["final", "Final bill"], ["service", "Service invoice"]];

function pick(set: [string, string, Tone][], v: string) {
  const s = set.find(([k]) => k === v);
  return <Badge tone={s?.[2] ?? "grey"}>{s?.[1] ?? titleCase(v)}</Badge>;
}
export const InvoiceStatus = ({ status }: { status: string }) => pick(INVOICE_STATUSES, status);
export const PayStatus = ({ status }: { status: string }) => pick(PAYMENT_STATUSES, status);
export const BillStatus = ({ status }: { status: string }) => pick(BILL_STATUSES, status);
export const ExpenseStatus = ({ status }: { status: string }) => pick(EXPENSE_STATUSES, status);

/** Invoice status that also tells whether it is paid / overdue. */
export function InvoiceBadges({ r }: { r: any }) {
  if (r.status !== "issued") return <InvoiceStatus status={r.status} />;
  return (
    <span className="flex flex-wrap gap-1">
      <PayStatus status={r.payment_status} />
      {r.overdue && <Badge tone="red">Overdue</Badge>}
    </span>
  );
}

export type OpenDoc = { id: string; number: string; date: string; due: string | null; total: string; balance: string };
export type Alloc = Record<string, { amount: string; tds: string }>;

/** Open invoices of a customer (or bills of a supplier) to allocate money to. */
export function useOpenDocs(kind: "customer" | "supplier", partyId: string | null | undefined) {
  return useQuery({
    queryKey: [kind === "customer" ? "/invoices" : "/supplier-invoices", "open", partyId],
    queryFn: () => api<Page<any>>(kind === "customer" ? "/invoices" : "/supplier-invoices", {
      params: { [kind === "customer" ? "customer_id" : "supplier_id"]: partyId!, outstanding: true, page_size: 200, sort: kind === "customer" ? "invoice_date" : "supplier_invoice_date" },
    }),
    enabled: !!partyId,
    select: (r): OpenDoc[] => r.data.map((d: any) => kind === "customer"
      ? { id: d.id, number: d.invoice_number, date: d.invoice_date, due: d.due_date, total: d.grand_total, balance: d.balance }
      : { id: d.id, number: `${d.bill_number} (${d.supplier_invoice_no})`, date: d.supplier_invoice_date, due: d.due_date, total: d.grand_total, balance: d.balance }),
  });
}

const n = (v: string | undefined) => Number(v || 0);

export function allocTotals(alloc: Alloc) {
  return Object.values(alloc).reduce((s, a) => ({ amount: s.amount + n(a.amount), tds: s.tds + n(a.tds) }), { amount: 0, tds: 0 });
}

export function allocPayload(alloc: Alloc) {
  return Object.entries(alloc).filter(([, a]) => n(a.amount) + n(a.tds) > 0).map(([id, a]) => ({ document_id: id, amount: a.amount || "0", tds: a.tds || "0" }));
}

/** Allocate money (and TDS) across open documents, oldest first. */
export function AllocationTable({ docs, alloc, onChange, available, tdsAvailable, emptyText }: {
  docs: OpenDoc[]; alloc: Alloc; onChange: (a: Alloc) => void; available: number; tdsAvailable: number; emptyText: string;
}) {
  const t = allocTotals(alloc);
  const autofill = () => {
    let money = available, tds = tdsAvailable;
    const next: Alloc = {};
    for (const d of docs) {
      const bal = n(d.balance);
      const useTds = Math.min(tds, bal);
      const useMoney = Math.min(money, bal - useTds);
      if (useTds + useMoney > 0) next[d.id] = { amount: useMoney ? useMoney.toFixed(2) : "", tds: useTds ? useTds.toFixed(2) : "" };
      money -= useMoney; tds -= useTds;
      if (money <= 0 && tds <= 0) break;
    }
    onChange(next);
  };
  if (!docs.length) return <p className="py-3 text-sm text-ink-500">{emptyText}</p>;
  const set = (id: string, k: "amount" | "tds", v: string) => onChange({ ...alloc, [id]: { amount: alloc[id]?.amount ?? "", tds: alloc[id]?.tds ?? "", [k]: v } });
  return (
    <div>
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="text-sm text-ink-600">Allocated <b className="num">{inr(t.amount + t.tds)}</b>{available + tdsAvailable - t.amount - t.tds > 0.004 && <> · <span className="num">{inr(available + tdsAvailable - t.amount - t.tds)}</span> stays on account (advance)</>}</p>
        <Button type="button" size="sm" variant="secondary" icon={<Wand2 className="size-3.5" />} onClick={autofill}>Oldest first</Button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] text-sm">
          <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
            <th className="px-2 py-2">Document</th><th className="px-2 py-2">Date</th><th className="px-2 py-2">Due</th>
            <th className="px-2 py-2 text-right">Total</th><th className="px-2 py-2 text-right">Balance</th>
            <th className="w-32 px-2 py-2 text-right">Amount</th><th className="w-28 px-2 py-2 text-right">TDS</th></tr></thead>
          <tbody>{docs.map((d) => {
            const over = n(alloc[d.id]?.amount) + n(alloc[d.id]?.tds) > n(d.balance) + 0.004;
            return (
              <tr key={d.id} className="border-b border-ink-100">
                <td className="px-2 py-1.5 font-medium">{d.number}</td><td className="px-2 py-1.5">{date(d.date)}</td>
                <td className={`px-2 py-1.5 ${d.due && d.due < new Date().toISOString().slice(0, 10) ? "text-brand-700" : ""}`}>{date(d.due)}</td>
                <td className="num px-2 py-1.5 text-right">{inr(d.total)}</td><td className="num px-2 py-1.5 text-right">{inr(d.balance)}</td>
                <td className="px-2 py-1.5"><Input inputMode="decimal" className={`num h-8 text-right ${over ? "border-brand-500" : ""}`} aria-label={`Amount for ${d.number}`} value={alloc[d.id]?.amount ?? ""} onChange={(e) => set(d.id, "amount", e.target.value)} /></td>
                <td className="px-2 py-1.5"><Input inputMode="decimal" className="num h-8 text-right" aria-label={`TDS for ${d.number}`} value={alloc[d.id]?.tds ?? ""} onChange={(e) => set(d.id, "tds", e.target.value)} disabled={tdsAvailable <= 0} /></td>
              </tr>
            );
          })}</tbody>
        </table>
      </div>
    </div>
  );
}

export function useDashboard(enabled = true) {
  return useQuery({ queryKey: ["/finance/dashboard"], queryFn: () => api<any>("/finance/dashboard"), select: (r) => r.data, enabled, staleTime: 30_000 });
}
