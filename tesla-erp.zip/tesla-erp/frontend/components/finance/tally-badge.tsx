"use client";

import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { dateTime } from "@/lib/format";

const LOOK: Record<string, { tone: "green" | "amber" | "red" | "grey" | "blue"; text: string }> = {
  queued: { tone: "blue", text: "Tally: waiting to send" },
  updating: { tone: "blue", text: "Tally: sending a change" },
  in_tally: { tone: "green", text: "In Tally" },
  failed: { tone: "red", text: "Tally: not accepted" },
  cancelled: { tone: "grey", text: "Tally: cancelled" },
};

/** Small badge showing whether an ERP document has reached Tally. Only for people who can see Tally Sync. */
export function TallyBadge({ entityType, entityId }: { entityType: string; entityId?: string | null }) {
  const { can } = useAuth();
  const allowed = can("tally.read") && !!entityId;
  const { data } = useQuery({
    queryKey: ["/tally/doc-status", entityType, entityId],
    queryFn: () => api<any>("/tally/doc-status", { params: { entity_type: entityType, entity_id: entityId! } }),
    select: (x) => x.data,
    enabled: allowed,
    staleTime: 15_000,
  });
  if (!allowed || !data?.state) return null;
  const look = LOOK[data.state] ?? { tone: "grey" as const, text: `Tally: ${data.state}` };
  const title = data.state === "failed" ? data.last_error : data.in_tally_at ? `Reached Tally ${dateTime(data.in_tally_at)}` : undefined;
  return (
    <Link href={data.state === "failed" ? "/finance/tally?tab=queue&status=failed" : "/finance/tally?tab=queue"} title={title ?? undefined} className="inline-flex">
      <Badge tone={look.tone}>{look.text}</Badge>
    </Link>
  );
}
