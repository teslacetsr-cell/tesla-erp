"use client";

import Link from "next/link";
import { inr } from "@/lib/format";

function Tile({ label, value, sub, href, tone }: { label: string; value: string; sub?: string; href?: string; tone?: "red" | "amber" | "green" }) {
  const body = (
    <div className="rounded-lg border border-ink-200 bg-white p-4 shadow-xs transition-colors hover:border-ink-300">
      <p className="text-xs uppercase tracking-wide text-ink-500">{label}</p>
      <p className={`num mt-1 text-2xl font-semibold ${tone === "red" ? "text-brand-700" : tone === "amber" ? "text-amber-700" : tone === "green" ? "text-emerald-700" : "text-ink-900"}`}>{value}</p>
      {sub && <p className="mt-0.5 text-xs text-ink-500">{sub}</p>}
    </div>
  );
  return href ? <Link href={href}>{body}</Link> : body;
}

/** Accounts dashboard tiles (Spec §33): receivables, payables, invoices, payments, expenses, GST. */
export function AccountsTiles({ d }: { d: any }) {
  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      <Tile label="Receivable" value={inr(d.receivable, 0)} sub={`${inr(d.receivable_overdue, 0)} overdue${Number(d.retention) ? ` · ${inr(d.retention, 0)} retention` : ""}`} href="/finance/receivables" tone={Number(d.receivable_overdue) ? "red" : undefined} />
      <Tile label="Collected this month" value={inr(d.collected_month, 0)} sub={`Billed ${inr(d.invoiced_month, 0)} (incl. GST)`} href="/finance/receipts" tone="green" />
      {"payable" in d && <Tile label="Payable" value={inr(d.payable, 0)} sub={`${inr(d.payable_overdue, 0)} overdue · paid ${inr(d.paid_month, 0)} this month`} href="/finance/payables" />}
      <Tile label="Expenses to pay" value={inr(d.expenses_to_pay, 0)} sub={`${inr(d.expenses_pending_approval, 0)} waiting for approval`} href="/finance/expenses" tone={Number(d.expenses_to_pay) ? "amber" : undefined} />
      {"gst_payable_month" in d && <Tile label="GST payable (this month)" value={inr(d.gst_payable_month, 0)} sub="Output less input, before set-off" href="/finance/reports" />}
      {"bank_movement" in d && <Tile label="Bank (via ERP)" value={inr(d.bank_movement, 0)} sub={`Cash ${inr(d.cash_movement, 0)} · movements recorded here`} />}
      <Tile label="Customer advances" value={inr(d.customer_advances, 0)} sub="Received, not yet allocated" href="/finance/receipts" />
      <Tile label="Draft invoices" value={String(d.draft_invoices)} sub={"bills_pending_approval" in d ? `${d.bills_pending_approval} supplier bill(s) waiting for approval` : undefined} href="/sales/invoices" />
    </div>
  );
}
