"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button, Card, ErrorNote, Field, Input, Select, Textarea } from "@/components/ui";
import { useProjectOptions } from "@/components/purchase/common";
import { api } from "@/lib/api/client";

const today = () => new Date(Date.now() + 5.5 * 3600_000).toISOString().slice(0, 10);
const trim = (v: any) => { const s = String(v ?? ""); return s.includes(".") ? s.replace(/0+$/, "").replace(/\.$/, "") : s; };

export function useExpenseOptions() {
  return useQuery({ queryKey: ["/expenses/options"], queryFn: () => api<any>("/expenses/options"), select: (r) => r.data, staleTime: 60_000 });
}

/** One expense: what, when, how much, for which project. The bill is attached on the next screen. */
export function ExpenseForm({ initial, onSubmit, onCancel, submitLabel }: { initial?: any; onSubmit: (body: any) => Promise<void>; onCancel: () => void; submitLabel: string }) {
  const opts = useExpenseOptions();
  const projects = useProjectOptions();
  const [v, setV] = useState({
    employee_id: initial?.employee_id ?? "", category_id: initial?.category_id ?? "", project_id: initial?.project_id ?? "",
    expense_date: initial?.expense_date ?? today(), amount: initial ? trim(initial.amount) : "", description: initial?.description ?? "", bill_reference: initial?.bill_reference ?? "",
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV({ ...v, [k]: e.target.value });
  const cat = opts.data?.categories.find((c: any) => c.id === v.category_id);
  const others = opts.data?.employees ?? [];
  return (
    <form className="space-y-5" onSubmit={async (e) => {
      e.preventDefault();
      setError(null);
      if (!v.category_id) return setError(new Error("Choose the category."));
      if (cat?.needs_project && !v.project_id) return setError(new Error(`${cat.name} expenses must be for a project.`));
      if (!(Number(v.amount) > 0)) return setError(new Error("Enter the amount."));
      if (v.description.trim().length < 3) return setError(new Error("Say what the expense was for."));
      setBusy(true);
      try {
        await onSubmit({ employee_id: v.employee_id || null, category_id: v.category_id, project_id: v.project_id || null, expense_date: v.expense_date,
          amount: v.amount, description: v.description.trim(), bill_reference: v.bill_reference.trim() || null });
      } catch (err) { setError(err); } finally { setBusy(false); }
    }}>
      <ErrorNote error={error} />
      {opts.data && !opts.data.me && !others.length && <p className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900">Your login is not linked to an employee record yet. Ask HR to link it before claiming expenses.</p>}
      <Card>
        <div className="grid gap-4 sm:grid-cols-2">
          {others.length > 0 && (
            <Field label="Employee" className="sm:col-span-2" hint="Accounts can enter a claim for someone else">
              <Select value={v.employee_id} onChange={set("employee_id")}>
                <option value="">{opts.data?.me ? `Me (${opts.data.me.name})` : "— Choose —"}</option>
                {others.filter((x: any) => x.id !== opts.data?.me?.id).map((x: any) => <option key={x.id} value={x.id}>{x.name} · {x.code}</option>)}
              </Select>
            </Field>
          )}
          <Field label="Category" required>
            <Select value={v.category_id} onChange={set("category_id")}>
              <option value="">— Choose —</option>
              {(opts.data?.categories ?? []).map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
          </Field>
          <Field label="Date of expense" required><Input type="date" max={today()} value={v.expense_date} onChange={set("expense_date")} /></Field>
          <Field label="Amount (₹)" required hint="Including any GST on the bill"><Input inputMode="decimal" className="num" value={v.amount} onChange={set("amount")} /></Field>
          <Field label="Project" required={!!cat?.needs_project}>
            <Select value={v.project_id} onChange={set("project_id")}>
              <option value="">— Not for a project —</option>
              {(projects.data ?? []).map((p) => <option key={p.id} value={p.id}>{p.project_number} · {p.name}</option>)}
            </Select>
          </Field>
          <Field label="What was it for?" required className="sm:col-span-2"><Textarea rows={2} value={v.description} onChange={set("description")} placeholder="e.g. Bus fare Thrissur → Kochi for earth-pit testing at Sunrise Clinic" /></Field>
          <Field label="Bill / ticket no."><Input value={v.bill_reference} onChange={set("bill_reference")} /></Field>
          {cat && <p className="self-end pb-2 text-xs text-ink-500">{cat.needs_receipt ? "Attach a photo or PDF of the bill on the next screen before submitting." : "No bill needed for this category."}</p>}
        </div>
      </Card>
      <div className="flex justify-end gap-2">
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
        <Button type="submit" loading={busy}>{submitLabel}</Button>
      </div>
    </form>
  );
}
