"use client";

import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button, Card, ErrorNote, Field, Input, Select, Textarea } from "@/components/ui";
import { CustomerPicker, type CustomerRef } from "@/components/crm/common";
import { allocPayload, AllocationTable, allocTotals, MODES, useOpenDocs, type Alloc } from "@/components/finance/common";
import { useProjectOptions, useSuppliers } from "@/components/purchase/common";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { inr } from "@/lib/format";

const today = () => new Date(Date.now() + 5.5 * 3600_000).toISOString().slice(0, 10);

/** A customer receipt or a supplier payment: who, how, how much (and TDS), and which open documents it settles. */
export function MoneyForm({ kind, partyId, docId, onSubmit, onCancel }: {
  kind: "receipt" | "payment"; partyId?: string | null; docId?: string | null; onSubmit: (body: any) => Promise<void>; onCancel: () => void;
}) {
  const { can } = useAuth();
  const isReceipt = kind === "receipt";
  const suppliers = useSuppliers();
  const projects = useProjectOptions(isReceipt && can("project.read"));
  const preCustomer = useQuery({ queryKey: ["/customers", partyId], queryFn: () => api<any>(`/customers/${partyId}`), select: (r) => r.data, enabled: isReceipt && !!partyId });
  const [customer, setCustomer] = useState<CustomerRef | null>(null);
  const [supplierId, setSupplierId] = useState(!isReceipt ? partyId ?? "" : "");
  useEffect(() => { if (preCustomer.data && !customer) setCustomer({ id: preCustomer.data.id, name: preCustomer.data.customer_name, code: preCustomer.data.customer_code }); }, [preCustomer.data, customer]);
  const party = isReceipt ? customer?.id : supplierId;
  const docs = useOpenDocs(isReceipt ? "customer" : "supplier", party);
  const [h, setH] = useState({ date: today(), mode: "neft", reference_no: "", instrument_date: "", bank_name: "", amount: "", tds_amount: "", project_id: "", notes: "" });
  const [alloc, setAlloc] = useState<Alloc>({});
  const [seeded, setSeeded] = useState(false);
  // coming from an invoice / bill: put its balance in
  useEffect(() => {
    if (seeded || !docId || !docs.data) return;
    const d = docs.data.find((x) => x.id === docId);
    if (d) { setH((x) => ({ ...x, amount: Number(d.balance).toFixed(2) })); setAlloc({ [d.id]: { amount: Number(d.balance).toFixed(2), tds: "" } }); }
    setSeeded(true);
  }, [docs.data, docId, seeded]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof h) => (e: { target: { value: string } }) => setH({ ...h, [k]: e.target.value });
  const amount = Number(h.amount || 0), tds = Number(h.tds_amount || 0);
  const t = allocTotals(alloc);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!party) return setError(new Error(isReceipt ? "Choose the customer." : "Choose the supplier."));
    if (!(amount + tds > 0)) return setError(new Error(isReceipt ? "Enter the amount received." : "Enter the amount paid."));
    if (t.amount + t.tds > amount + tds + 0.004) return setError(new Error("You have allocated more than the total."));
    if (t.tds > tds + 0.004) return setError(new Error("The TDS allocated is more than the TDS entered."));
    const v = (s: string) => (s.trim() === "" ? null : s.trim());
    setBusy(true);
    try {
      await onSubmit(isReceipt
        ? { customer_id: party, receipt_date: h.date, mode: h.mode, reference_no: v(h.reference_no), instrument_date: v(h.instrument_date), bank_name: v(h.bank_name), amount: h.amount || "0", tds_amount: h.tds_amount || "0", project_id: v(h.project_id), notes: v(h.notes), allocations: allocPayload(alloc) }
        : { supplier_id: party, payment_date: h.date, mode: h.mode, reference_no: v(h.reference_no), bank_name: v(h.bank_name), amount: h.amount || "0", tds_amount: h.tds_amount || "0", notes: v(h.notes), allocations: allocPayload(alloc) });
    } catch (err) { setError(err); window.scrollTo({ top: 0, behavior: "smooth" }); } finally { setBusy(false); }
  }

  return (
    <form onSubmit={submit} className="space-y-5">
      <ErrorNote error={error} />
      <Card title={isReceipt ? "Received from" : "Paid to"}>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {isReceipt ? (
            <Field label="Customer" required className="sm:col-span-2"><CustomerPicker value={customer} onChange={(c) => { setCustomer(c); setAlloc({}); }} /></Field>
          ) : (
            <Field label="Supplier" required className="sm:col-span-2">
              <Select value={supplierId} onChange={(e) => { setSupplierId(e.target.value); setAlloc({}); }}>
                <option value="">— Choose —</option>
                {(suppliers.data ?? []).map((s) => <option key={s.id} value={s.id}>{s.supplier_name}{s.city ? ` · ${s.city}` : ""}</option>)}
              </Select>
            </Field>
          )}
          <Field label="Date" required><Input type="date" max={today()} value={h.date} onChange={set("date")} /></Field>
          <Field label="Mode"><Select value={h.mode} onChange={set("mode")}>{MODES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          <Field label={h.mode === "cheque" || h.mode === "dd" ? "Cheque / DD no." : "UTR / reference"}><Input value={h.reference_no} onChange={set("reference_no")} /></Field>
          {isReceipt && (h.mode === "cheque" || h.mode === "dd") && <Field label="Cheque date"><Input type="date" value={h.instrument_date} onChange={set("instrument_date")} /></Field>}
          <Field label="Bank"><Input value={h.bank_name} onChange={set("bank_name")} /></Field>
          {isReceipt && (
            <Field label="Project" hint="For an advance against a project">
              <Select value={h.project_id} onChange={set("project_id")}>
                <option value="">—</option>
                {(projects.data ?? []).filter((p) => !customer || p.customer?.id === customer.id || p.customer_id === customer.id).map((p) => <option key={p.id} value={p.id}>{p.project_number} · {p.name}</option>)}
              </Select>
            </Field>
          )}
        </div>
      </Card>
      <Card title="Amount">
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label={isReceipt ? "Amount received (₹)" : "Amount paid (₹)"} required hint={isReceipt ? "What reached the bank / cash" : "What left the bank / cash"}>
            <Input inputMode="decimal" className="num" value={h.amount} onChange={set("amount")} /></Field>
          <Field label="TDS (₹)" hint={isReceipt ? "Deducted by the customer (Form 26AS)" : "Deducted by us, payable to the government"}>
            <Input inputMode="decimal" className="num" value={h.tds_amount} onChange={set("tds_amount")} placeholder="0" /></Field>
          <div className="self-end pb-2 text-sm text-ink-600">Total settled: <b className="num">{inr(amount + tds)}</b></div>
        </div>
      </Card>
      <Card title={isReceipt ? "Against invoices" : "Against bills"}>
        {!party ? <p className="text-sm text-ink-500">Choose the {isReceipt ? "customer" : "supplier"} first.</p> : (
          <AllocationTable docs={docs.data ?? []} alloc={alloc} onChange={setAlloc} available={amount} tdsAvailable={tds}
            emptyText={isReceipt ? "No outstanding invoices — the whole amount is recorded as an advance." : "No unpaid bills — the whole amount is recorded as an advance."} />
        )}
        <Field label="Notes" className="mt-4"><Textarea rows={2} value={h.notes} onChange={set("notes")} /></Field>
      </Card>
      <div className="sticky bottom-0 -mx-4 flex justify-end gap-2 border-t border-ink-200 bg-white/95 px-4 py-3 backdrop-blur sm:static sm:mx-0 sm:border-0 sm:bg-transparent sm:p-0">
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
        <Button type="submit" loading={busy}>{isReceipt ? "Save receipt" : "Save payment"}</Button>
      </div>
    </form>
  );
}

/** Allocate what is left on an existing receipt / payment. */
export function AllocateDialogBody({ kind, partyId, free, tdsFree, onSubmit, onCancel }: {
  kind: "customer" | "supplier"; partyId: string; free: number; tdsFree: number; onSubmit: (allocations: any[]) => Promise<void>; onCancel: () => void;
}) {
  const docs = useOpenDocs(kind, partyId);
  const [alloc, setAlloc] = useState<Alloc>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const t = allocTotals(alloc);
  return (
    <div className="space-y-3">
      <ErrorNote error={error} />
      <p className="text-sm text-ink-600">{inr(free)} is on account{tdsFree ? ` (of which TDS ${inr(tdsFree)})` : ""}.</p>
      <AllocationTable docs={docs.data ?? []} alloc={alloc} onChange={setAlloc} available={free - tdsFree} tdsAvailable={tdsFree} emptyText="Nothing outstanding to allocate to." />
      <div className="flex justify-end gap-2">
        <Button variant="secondary" onClick={onCancel}>Back</Button>
        <Button loading={busy} disabled={t.amount + t.tds <= 0} onClick={async () => {
          setBusy(true); setError(null);
          try { await onSubmit(allocPayload(alloc)); } catch (e) { setError(e); } finally { setBusy(false); }
        }}>Allocate</Button>
      </div>
    </div>
  );
}
