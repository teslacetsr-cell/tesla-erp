"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button, Card, Checkbox, ErrorNote, Field, Input, Select, Textarea } from "@/components/ui";
import { CustomerPicker, useCustomerDetail, type CustomerRef } from "@/components/crm/common";
import { blankLine, lineProblems, LinesEditor, preview, toPayload, toRows, TotalsBox, type LineRow } from "@/components/lines-editor";
import { BILL_TYPES } from "@/components/finance/common";
import { api, ApiError } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { inr, qty } from "@/lib/format";

const today = () => new Date(Date.now() + 5.5 * 3600_000).toISOString().slice(0, 10);
const trim = (v: any) => { const s = String(v ?? ""); return s.includes(".") ? s.replace(/0+$/, "").replace(/\.$/, "") : s; };

/** Sales invoice: billed against a sales order (quantities up to what is left to bill, at the order's rates) and/or
 * free lines; or a standalone invoice for a customer. */
export function InvoiceForm({ initial, soId, onSubmit, onCancel, submitLabel }: {
  initial?: any; soId?: string | null; onSubmit: (body: any) => Promise<void>; onCancel: () => void; submitLabel: string;
}) {
  const { can } = useAuth();
  const orderId = initial?.sales_order?.id ?? soId ?? null;
  const billable = useQuery({ queryKey: ["/sales-orders", orderId, "billable"], queryFn: () => api<any>(`/sales-orders/${orderId}/billable`), select: (r) => r.data, enabled: !!orderId });
  const defaults = useQuery({ queryKey: ["/quotations/defaults"], queryFn: () => api<any>("/quotations/defaults"), select: (r) => r.data, enabled: can("quotation.create") });
  const company = useQuery({ queryKey: ["/company"], queryFn: () => api<any>("/company"), select: (r) => r.data, staleTime: 10 * 60_000 });
  const gstRates: string[] = defaults.data?.gst_rates ?? ["0", "5", "12", "18", "28"];
  const [customer, setCustomer] = useState<CustomerRef | null>(initial ? { id: initial.customer_id, name: initial.customer } : null);
  const detail = useCustomerDetail(customer?.id);
  const [h, setH] = useState({
    invoice_date: initial?.invoice_date ?? today(), due_date: initial?.due_date ?? "", bill_type: initial?.bill_type ?? (orderId ? "running" : "regular"),
    subject: initial?.subject ?? "", customer_po_number: initial?.customer_po_number ?? "", customer_po_date: initial?.customer_po_date ?? "",
    site_id: initial?.site_id ?? "", payment_terms: initial?.payment_terms ?? "", notes: initial?.notes ?? "",
    special_discount: initial && Number(initial.special_discount) ? trim(initial.special_discount) : "",
    retention_pct: initial && Number(initial.retention_pct) ? trim(initial.retention_pct) : "", reverse_charge: initial?.reverse_charge ?? false,
  });
  // order lines: quantity to bill now, keyed by order line
  const [billQty, setBillQty] = useState<Record<string, string>>(() =>
    Object.fromEntries((initial?.items ?? []).filter((i: any) => i.so_item_id).map((i: any) => [i.so_item_id, trim(i.quantity)])));
  const [extra, setExtra] = useState<LineRow[]>(() => (initial ? toRows(initial.items.filter((i: any) => !i.so_item_id)) : orderId ? [] : [blankLine()]));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof h) => (e: { target: { value: string } }) => setH({ ...h, [k]: e.target.value });
  const so = billable.data?.sales_order;
  const lines: any[] = billable.data?.lines ?? [];
  const orderRows: LineRow[] = lines.filter((l) => Number(billQty[l.so_item_id] || 0) > 0).map((l) => ({
    ...blankLine(), section: l.section ?? "", item_id: l.item_id, description: l.description, hsn_sac: l.hsn_sac ?? "",
    quantity: billQty[l.so_item_id], unit: l.unit, rate: trim(l.rate), discount_pct: trim(l.discount_pct), tax_rate: trim(l.tax_rate),
    technical_specification: l.technical_specification ?? "", remarks: l.remarks ?? "", links: { so_item_id: l.so_item_id },
  }));
  const site = detail.data?.sites?.find((s: any) => s.id === h.site_id);
  const pos = so?.place_of_supply ?? site?.state_code ?? detail.data?.state_code;
  const interState = so ? so.inter_state : !!(pos && company.data?.state_code && pos !== company.data.state_code);
  const all = [...orderRows, ...extra];
  const calc = preview(all, interState, Number(h.special_discount) || 0, true);
  const retention = Math.round(calc.grand * (Number(h.retention_pct) || 0)) / 100;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!orderId && !customer) return setError(new Error("Choose the customer."));
    if (!all.length) return setError(new Error(orderId ? "Enter the quantity to bill on at least one order line." : "Add at least one line."));
    for (const l of lines) {
      const q = Number(billQty[l.so_item_id] || 0);
      if (q > Number(l.balance_qty) + 1e-9)
        return setError(new Error(`'${l.description.slice(0, 50)}': only ${qty(l.balance_qty)} ${l.unit} is left to bill.`));
    }
    const problem = lineProblems(extra);
    if (problem) return setError(new Error(problem));
    const v = (s: string) => (s.trim() === "" ? null : s.trim());
    setBusy(true);
    try {
      await onSubmit({
        customer_id: orderId ? null : customer!.id, sales_order_id: orderId, project_id: initial?.project?.id ?? billable.data?.project?.id ?? null,
        site_id: orderId ? null : v(h.site_id), invoice_date: h.invoice_date, due_date: v(h.due_date), bill_type: h.bill_type, subject: v(h.subject),
        customer_po_number: v(h.customer_po_number), customer_po_date: v(h.customer_po_date), reverse_charge: h.reverse_charge,
        payment_terms: v(h.payment_terms), notes: v(h.notes), special_discount: v(h.special_discount) ?? "0", retention_pct: v(h.retention_pct) ?? "0",
        items: toPayload(all),
      });
    } catch (err) {
      setError(err instanceof ApiError && err.status === 422 ? new Error(err.message || "Some values are not valid.") : err);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } finally { setBusy(false); }
  }

  return (
    <form onSubmit={submit} className="space-y-5">
      <ErrorNote error={error} />
      <Card title="Bill to">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {orderId ? (
            <div className="sm:col-span-2">
              <p className="text-[13px] font-medium text-ink-700">Customer</p>
              <p className="mt-1 text-sm">{billable.data?.customer?.name ?? "…"}</p>
              <p className="text-xs text-ink-500">Order {so?.so_number}{billable.data?.project ? ` · project ${billable.data.project.number}` : ""} · {interState ? "IGST" : "CGST + SGST"}</p>
            </div>
          ) : (
            <>
              <Field label="Customer" required className="sm:col-span-2"><CustomerPicker value={customer} onChange={(c) => { setCustomer(c); setH({ ...h, site_id: "" }); }} /></Field>
              <Field label="Site / ship to" hint={pos ? `Place of supply: state ${pos} · ${interState ? "IGST" : "CGST + SGST"}` : undefined}>
                <Select value={h.site_id} onChange={set("site_id")} disabled={!customer}>
                  <option value="">— Billing address —</option>
                  {detail.data?.sites?.map((s: any) => <option key={s.id} value={s.id}>{s.site_name}</option>)}
                </Select>
              </Field>
            </>
          )}
          <Field label="Bill type"><Select value={h.bill_type} onChange={set("bill_type")}>{BILL_TYPES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          <Field label="Invoice date" required hint="Numbered when issued"><Input type="date" value={h.invoice_date} max={today()} onChange={set("invoice_date")} /></Field>
          <Field label="Due date" hint="Blank = customer's credit days"><Input type="date" value={h.due_date} onChange={set("due_date")} /></Field>
          <Field label="Customer PO no." hint={so?.customer_po_number ? `Order: ${so.customer_po_number}` : undefined}><Input value={h.customer_po_number} onChange={set("customer_po_number")} placeholder={so?.customer_po_number ?? ""} /></Field>
          <Field label="Customer PO date"><Input type="date" value={h.customer_po_date} onChange={set("customer_po_date")} /></Field>
          <Field label="Subject" className="sm:col-span-2"><Input value={h.subject} onChange={set("subject")} placeholder={so?.subject ?? "e.g. LPS works — RA bill 2"} /></Field>
        </div>
      </Card>
      {orderId && (
        <Card title="Order lines" actions={<span className="text-xs text-ink-500">Rates, discounts and GST stay as ordered</span>}>
          {billable.isLoading ? <p className="text-sm text-ink-500">Loading…</p> : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] text-sm">
                <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
                  <th className="px-2 py-2">#</th><th className="px-2 py-2">Item</th><th className="px-2 py-2 text-right">Rate</th>
                  <th className="px-2 py-2 text-right">Ordered</th><th className="px-2 py-2 text-right">Billed</th><th className="px-2 py-2 text-right">Left</th>
                  <th className="w-32 px-2 py-2 text-right">Bill now</th></tr></thead>
                <tbody>{lines.map((l) => (
                  <tr key={l.so_item_id} className="border-b border-ink-100 align-top">
                    <td className="px-2 py-2 text-ink-500">{l.line_no}</td>
                    <td className="px-2 py-2"><p>{l.description}</p><p className="text-xs text-ink-500">{[l.section, l.hsn_sac && `HSN ${l.hsn_sac}`, `GST ${Number(l.tax_rate)}%`].filter(Boolean).join(" · ")}</p></td>
                    <td className="num px-2 py-2 text-right">{inr(l.rate)}{Number(l.discount_pct) ? <span className="block text-xs text-ink-500">−{Number(l.discount_pct)}%</span> : null}</td>
                    <td className="num px-2 py-2 text-right">{qty(l.ordered_qty)} {l.unit}</td>
                    <td className="num px-2 py-2 text-right text-ink-500">{qty(l.billed_qty)}</td>
                    <td className="num px-2 py-2 text-right font-medium">{qty(l.balance_qty)}</td>
                    <td className="px-2 py-1.5"><div className="flex items-center gap-1">
                      <Input inputMode="decimal" className="num h-8 text-right" aria-label={`Bill now, line ${l.line_no}`} value={billQty[l.so_item_id] ?? ""} onChange={(e) => setBillQty({ ...billQty, [l.so_item_id]: e.target.value })} />
                      <button type="button" className="text-xs text-brand-700 hover:underline" onClick={() => setBillQty({ ...billQty, [l.so_item_id]: trim(l.balance_qty) })}>all</button>
                    </div></td>
                  </tr>))}</tbody>
              </table>
            </div>
          )}
          <div className="mt-3 flex gap-2">
            <Button type="button" size="sm" variant="secondary" onClick={() => setBillQty(Object.fromEntries(lines.map((l) => [l.so_item_id, Number(l.balance_qty) > 0 ? trim(l.balance_qty) : ""])))}>Bill everything left</Button>
            <Button type="button" size="sm" variant="ghost" onClick={() => setBillQty({})}>Clear</Button>
          </div>
        </Card>
      )}
      <Card title={orderId ? "Other lines (not on the order)" : "Items"}>
        {orderId && !extra.length ? (
          <Button type="button" size="sm" variant="secondary" onClick={() => setExtra([blankLine()])}>Add a line not on the order</Button>
        ) : <LinesEditor rows={extra} onChange={setExtra} gstRates={gstRates} interState={interState} />}
        <div className="mt-5 grid gap-4 border-t border-ink-100 pt-4 lg:grid-cols-[1fr_380px]">
          <div className="grid max-w-md gap-4 sm:grid-cols-2">
            <Field label="Special discount (₹)"><Input inputMode="decimal" className="num" value={h.special_discount} onChange={set("special_discount")} placeholder="0" /></Field>
            <Field label="Retention %" hint={retention ? `${inr(retention)} held by the customer` : "Held until defects liability ends"}><Input inputMode="decimal" className="num" value={h.retention_pct} onChange={set("retention_pct")} placeholder="0" /></Field>
            <Checkbox label="Tax payable on reverse charge" checked={h.reverse_charge} onChange={(e) => setH({ ...h, reverse_charge: e.target.checked })} />
          </div>
          <TotalsBox interState={interState} t={{ gross: calc.gross, lineDiscount: calc.lineDiscount, special: calc.special, taxable: calc.taxable, cgst: calc.cgst, sgst: calc.sgst, igst: calc.igst, roundOff: calc.roundOff, grand: calc.grand }} />
        </div>
      </Card>
      <Card title="Terms">
        <div className="grid gap-4 lg:grid-cols-2">
          <Field label="Payment terms" hint="Blank = the order's / customer's terms"><Textarea rows={3} value={h.payment_terms} onChange={set("payment_terms")} placeholder={so?.payment_terms ?? ""} /></Field>
          <Field label="Notes on the invoice"><Textarea rows={3} value={h.notes} onChange={set("notes")} /></Field>
        </div>
      </Card>
      <div className="sticky bottom-0 -mx-4 flex justify-end gap-2 border-t border-ink-200 bg-white/95 px-4 py-3 backdrop-blur sm:static sm:mx-0 sm:border-0 sm:bg-transparent sm:p-0">
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
        <Button type="submit" loading={busy}>{submitLabel}</Button>
      </div>
    </form>
  );
}
