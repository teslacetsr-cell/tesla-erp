"use client";

import Link from "next/link";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Download } from "lucide-react";
import { Button, Card, EmptyState, ErrorNote, Field, Input, PageHeader, Spinner } from "@/components/ui";
import { api, download } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { inr } from "@/lib/format";

/** Receivables or payables by party and age (by due date), with links to each party's statement. */
export function AgeingPage({ kind }: { kind: "receivables" | "payables" }) {
  const { can } = useAuth();
  const [asOf, setAsOf] = useState("");
  const party = kind === "receivables" ? "customer" : "supplier";
  const q = useQuery({ queryKey: [`/finance/${kind}`, asOf], queryFn: () => api<any>(`/finance/${kind}`, { params: { as_of: asOf || undefined } }), select: (r) => r.data });
  const d = q.data;
  const cols: [string, string][] = d ? [...d.buckets.map((b: any) => [b.key, b.label] as [string, string]), ...(kind === "receivables" ? [["retention", "Retention"] as [string, string]] : []), ["outstanding", "Outstanding"], ["advance", "Advance"], ["net", "Net"]] : [];
  return (
    <>
      <PageHeader title={kind === "receivables" ? "Receivables" : "Payables"}
        subtitle={kind === "receivables" ? "What customers owe, by how overdue it is. Retention held back is shown on its own, not as overdue." : "What we owe suppliers, by how overdue it is."}
        actions={can(`${kind === "receivables" ? "receivable" : "payable"}.export`) && <Button variant="secondary" icon={<Download className="size-4" />} onClick={() => download(`/finance/${kind}/export`, `${kind}.xlsx`, { as_of: asOf || undefined })}>Export</Button>} />
      <Card padded={false}>
        <div className="flex items-end gap-3 border-b border-ink-100 p-3">
          <Field label="As of" className="w-44"><Input type="date" value={asOf} onChange={(e) => setAsOf(e.target.value)} /></Field>
        </div>
        {q.isLoading ? <Spinner /> : q.error ? <ErrorNote error={q.error} /> : !d.rows.length ? <EmptyState title="Nothing outstanding" /> : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px] text-sm">
              <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
                <th className="px-3 py-2">{party === "customer" ? "Customer" : "Supplier"}</th>
                {cols.map(([k, l]) => <th key={k} className={`px-3 py-2 text-right ${k === "net" ? "text-ink-800" : ""}`}>{l}</th>)}</tr></thead>
              <tbody>
                {d.rows.map((r: any) => (
                  <tr key={r[`${party}_id`]} className="border-b border-ink-100">
                    <td className="px-3 py-2"><Link className="font-medium text-brand-700 hover:underline" href={`/finance/statement?type=${party}&id=${r[`${party}_id`]}`}>{r[party]}</Link>
                      <span className="block text-xs text-ink-500">{r.invoices ?? r.bills} open {party === "customer" ? "invoice(s)" : "bill(s)"}</span></td>
                    {cols.map(([k]) => <td key={k} className={`num px-3 py-2 text-right ${["d61_90", "d90"].includes(k) && Number(r[k]) ? "text-brand-700" : ""} ${k === "net" ? "font-semibold" : ""}`}>{Number(r[k]) ? inr(r[k], 0) : <span className="text-ink-300">—</span>}</td>)}
                  </tr>
                ))}
                <tr className="bg-ink-50 font-semibold">
                  <td className="px-3 py-2">Total</td>
                  {cols.map(([k]) => <td key={k} className="num px-3 py-2 text-right">{k === "net" ? inr(Number(d.totals.outstanding) - Number(d.totals.advance), 0) : inr(d.totals[k], 0)}</td>)}
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}
