"use client";

import { useState } from "react";
import { Badge, Button, ErrorNote, Field, Input, Modal, Select, Textarea } from "@/components/ui";
import { istToday } from "@/components/projects/common";
import { api } from "@/lib/api/client";

type Tone = "green" | "red" | "grey" | "amber" | "blue";
export const LEAVE_STATUSES: [string, string, Tone][] = [
  ["pending", "Waiting for approval", "amber"], ["approved", "Approved", "green"], ["rejected", "Rejected", "red"], ["cancelled", "Cancelled", "grey"],
];
export function LeaveStatus({ status }: { status: string }) {
  const s = LEAVE_STATUSES.find(([k]) => k === status);
  return <Badge tone={s?.[2] ?? "grey"}>{s?.[1] ?? status}</Badge>;
}

export const ATT_STATUSES: [string, string][] = [
  ["present", "Present"], ["half_day", "Half day"], ["absent", "Absent"], ["on_leave", "On leave"], ["on_duty", "On duty (away)"],
  ["holiday", "Holiday"], ["weekly_off", "Weekly off"],
];
export const ATT_STYLE: Record<string, string> = {
  present: "bg-emerald-100 text-emerald-800", on_duty: "bg-emerald-100 text-emerald-800", half_day: "bg-amber-100 text-amber-800",
  absent: "bg-brand-100 text-brand-800", on_leave: "bg-sky-100 text-sky-800", holiday: "bg-violet-100 text-violet-800",
  weekly_off: "bg-ink-100 text-ink-500",
};
export const attLabel = (s: string | null) => ATT_STATUSES.find(([k]) => k === s)?.[1] ?? "Not marked";

export const thisMonth = () => istToday().slice(0, 7);
export function shiftMonth(m: string, by: number) {
  const [y, mo] = m.split("-").map(Number);
  const d = new Date(Date.UTC(y, mo - 1 + by, 1));
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
}
export const monthName = (m: string) => new Date(`${m}-01T00:00:00`).toLocaleDateString("en-IN", { month: "long", year: "numeric" });
export const time = (iso: string | null) => (iso ? new Date(iso).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Kolkata" }) : "—");

export function MonthPicker({ value, onChange }: { value: string; onChange: (m: string) => void }) {
  return (
    <div className="flex items-center gap-1">
      <Button size="sm" variant="ghost" aria-label="Previous month" onClick={() => onChange(shiftMonth(value, -1))}>‹</Button>
      <span className="min-w-32 text-center text-sm font-medium">{monthName(value)}</span>
      <Button size="sm" variant="ghost" aria-label="Next month" disabled={value >= thisMonth()} onClick={() => onChange(shiftMonth(value, 1))}>›</Button>
    </div>
  );
}

/** One employee's month as a calendar. `row` is a register row; `onDay` makes days clickable (HR marking). */
export function AttendanceCalendar({ row, onDay }: { row: any; onDay?: (cell: any) => void }) {
  const first = new Date(`${row.days[0].date}T00:00:00`);
  const pad = (first.getDay() + 6) % 7; // Monday first
  const today = istToday();
  return (
    <div>
      <div className="grid grid-cols-7 gap-1 text-center text-[11px] text-ink-500">{["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => <span key={d}>{d}</span>)}</div>
      <div className="mt-1 grid grid-cols-7 gap-1">
        {Array.from({ length: pad }).map((_, i) => <span key={`p${i}`} />)}
        {row.days.map((c: any) => {
          const future = c.date > today;
          const cls = c.status ? ATT_STYLE[c.status] : future ? "text-ink-300" : "bg-white text-ink-400 ring-1 ring-inset ring-ink-200";
          const El = onDay && !future ? "button" : "div";
          return (
            <El key={c.date} type={El === "button" ? "button" : undefined} onClick={El === "button" ? () => onDay!(c) : undefined}
              title={`${c.date}: ${attLabel(c.status)}${c.in ? ` · in ${time(c.in)}` : ""}${c.out ? ` · out ${time(c.out)}` : ""}${c.project ? ` · ${c.project}` : ""}`}
              className={`flex h-12 flex-col items-center justify-center rounded text-xs ${cls} ${c.date === today ? "outline outline-2 outline-brand-500" : ""}`}>
              <span className="font-medium">{Number(c.date.slice(8))}</span>
              <span className="text-[10px]">{c.code}{c.located ? " ⦿" : ""}</span>
            </El>
          );
        })}
      </div>
    </div>
  );
}

export function Totals({ t }: { t: any }) {
  if (!t) return null;
  return (
    <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm">
      <span>Present <b className="num">{t.present}</b></span><span>Leave <b className="num">{t.leave}</b></span>
      <span>Absent <b className="num">{t.absent}</b></span><span>Holidays <b className="num">{t.holiday}</b></span>
      <span>Weekly off <b className="num">{t.weekly_off}</b></span>
      {Number(t.unmarked) > 0 && <span className="text-amber-700">Not marked <b className="num">{t.unmarked}</b></span>}
    </div>
  );
}

export function BalancesTable({ balances }: { balances: any[] }) {
  return (
    <table className="w-full text-sm">
      <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
        <th className="py-1.5">Leave</th><th className="py-1.5 pl-2 text-right">Quota</th><th className="py-1.5 pl-2 text-right">Taken</th><th className="py-1.5 pl-2 text-right">Pend.</th><th className="py-1.5 pl-2 text-right">Left</th></tr></thead>
      <tbody>{balances.map((b) => (
        <tr key={b.code} className="border-b border-ink-100">
          <td className="py-1.5">{b.name} <span className="text-xs text-ink-500">{b.code}{!b.paid ? " · unpaid" : ""}</span></td>
          <td className="num py-1.5 pl-2 text-right">{b.quota != null ? Number(b.quota) + Number(b.adjustments) : "—"}</td>
          <td className="num py-1.5 pl-2 text-right">{Number(b.taken)}</td>
          <td className="num py-1.5 pl-2 text-right">{Number(b.pending) || ""}</td>
          <td className="num py-1.5 pl-2 text-right font-semibold">{b.available != null ? Number(b.available) : "No limit"}</td>
        </tr>))}</tbody>
    </table>
  );
}

export function ApplyLeaveDialog({ types, onClose, onSaved, employeeId }: {
  types: { id: string; code: string; name: string; allow_half_day: boolean }[]; onClose: () => void; onSaved: (r: any) => void; employeeId?: string;
}) {
  const [v, setV] = useState({ leave_type_id: types[0]?.id ?? "", from_date: istToday(), to_date: istToday(), half_day: "none", reason: "" });
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  const t = types.find((x) => x.id === v.leave_type_id);
  const single = v.from_date === v.to_date;
  return (
    <Modal open onClose={onClose} title="Apply for leave"
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setError(null); setBusy(true);
        try {
          const r = await api<any>("/leave-requests", { body: { ...v, half_day: single ? v.half_day : "none", employee_id: employeeId ?? null } });
          onSaved(r.data); onClose();
        } catch (e) { setError(e); } finally { setBusy(false); }
      }}>Apply</Button></>}>
      <ErrorNote error={error} />
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Leave type" required className="sm:col-span-2"><Select value={v.leave_type_id} onChange={(e) => setV({ ...v, leave_type_id: e.target.value })}>{types.map((x) => <option key={x.id} value={x.id}>{x.name} ({x.code})</option>)}</Select></Field>
        <Field label="From" required><Input type="date" value={v.from_date} onChange={(e) => setV({ ...v, from_date: e.target.value, to_date: e.target.value > v.to_date ? e.target.value : v.to_date })} /></Field>
        <Field label="To" required><Input type="date" min={v.from_date} value={v.to_date} onChange={(e) => setV({ ...v, to_date: e.target.value })} /></Field>
        {single && t?.allow_half_day && (
          <Field label="Duration" className="sm:col-span-2"><Select value={v.half_day} onChange={(e) => setV({ ...v, half_day: e.target.value })}>
            <option value="none">Full day</option><option value="first">First half</option><option value="second">Second half</option></Select></Field>
        )}
        <Field label="Reason" required className="sm:col-span-2"><Textarea rows={2} value={v.reason} onChange={(e) => setV({ ...v, reason: e.target.value })} /></Field>
      </div>
      <p className="mt-2 text-xs text-ink-500">Sundays (your weekly off) and holidays inside the dates are not counted. The request goes to your reporting manager.</p>
    </Modal>
  );
}

export function AdjustDialog({ emp, year, types, onClose, onSaved }: { emp: { employee_id: string; name: string }; year: number; types: any[]; onClose: () => void; onSaved: () => void }) {
  const [v, setV] = useState({ leave_type_id: types[0]?.id ?? "", days: "", reason: "" });
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  return (
    <Modal open onClose={onClose} title={`Adjust leave · ${emp.name} · ${year}`}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setError(null); setBusy(true);
        try { await api("/leave-adjustments", { body: { ...v, employee_id: emp.employee_id, year } }); onSaved(); onClose(); } catch (e) { setError(e); } finally { setBusy(false); }
      }}>Save</Button></>}>
      <ErrorNote error={error} />
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Leave type"><Select value={v.leave_type_id} onChange={(e) => setV({ ...v, leave_type_id: e.target.value })}>{types.map((t) => <option key={t.id} value={t.id}>{t.name} ({t.code})</option>)}</Select></Field>
        <Field label="Days (+ add / − remove)" required><Input inputMode="decimal" value={v.days} onChange={(e) => setV({ ...v, days: e.target.value })} placeholder="e.g. 5 or -2" /></Field>
        <Field label="Reason" required className="sm:col-span-2"><Input value={v.reason} onChange={(e) => setV({ ...v, reason: e.target.value })} placeholder="Carried forward from last year" /></Field>
      </div>
    </Modal>
  );
}
