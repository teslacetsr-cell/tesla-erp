"use client";

import type { FieldDef } from "@/components/record-form";
import { useAuth } from "@/lib/auth";
import { useOptions } from "@/lib/hooks";

/** Fields of the basic employee form, shared by the employee list and the employee profile. */
export function useEmployeeFields(selfId?: string): FieldDef[] {
  const { can } = useAuth();
  const depts = useOptions("/departments");
  const desigs = useOptions("/designations");
  const divs = useOptions("/divisions");
  const emps = useOptions("/employees");
  const users = useOptions("/users", can("user.read"));
  const opt = (rows: any[] | undefined, label: (r: any) => string): [string, string][] => [["", "—"], ...(rows ?? []).map((r) => [r.id, label(r)] as [string, string])];
  // Point the user at the right screen when a list is empty, instead of a dropdown with nothing in it.
  const empty = (q: { data?: any[]; isLoading: boolean }, what: string) =>
    !q.isLoading && !q.data?.length ? `No ${what} yet — add them in Administration → Masters → ${what.charAt(0).toUpperCase() + what.slice(1)}` : undefined;
  return [
    { name: "full_name", label: "Full name", required: true, span: 2 },
    { name: "employee_code", label: "Employee code", hint: "Leave blank to auto-number", upper: true },
    { name: "date_of_joining", label: "Date of joining (YYYY-MM-DD)" },
    { name: "email", label: "Work email" }, { name: "phone", label: "Phone" },
    { name: "department_id", label: "Department", type: "select", options: opt(depts.data, (d) => d.name), hint: empty(depts, "departments") },
    { name: "designation_id", label: "Designation", type: "select", options: opt(desigs.data, (d) => d.name), hint: empty(desigs, "designations") },
    { name: "division_id", label: "Division", type: "select", options: opt(divs.data, (d) => d.name), hint: empty(divs, "business divisions") },
    { name: "reports_to_id", label: "Reports to (line manager)", type: "select", options: opt((emps.data ?? []).filter((e: any) => e.id !== selfId), (e) => `${e.full_name} (${e.employee_code})`), hint: "Approves this person's leave and other line-manager steps" },
    ...(can("user.read") ? [{ name: "user_id", label: "ERP user login", type: "select" as const, options: opt(users.data, (u) => `${u.full_name} (${u.username})`) }] : []),
    { name: "is_active", label: "Active", type: "checkbox" },
  ];
}
