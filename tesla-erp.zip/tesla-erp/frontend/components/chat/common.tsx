"use client";

import clsx from "clsx";
import { Briefcase, Hash, Users } from "lucide-react";
import { Fragment, type ReactNode } from "react";

export type ChannelRow = {
  id: string;
  kind: "company" | "group" | "direct" | "project";
  name: string;
  description: string | null;
  project_id: string | null;
  unread: number;
  last_message_at: string | null;
  last_message: { sender: string; text: string; mine: boolean } | null;
  member_count: number;
};

export type Member = { id: string; full_name: string; username: string; is_active: boolean };

export type ChannelDetail = {
  id: string;
  kind: ChannelRow["kind"];
  name: string;
  description: string | null;
  project_id: string | null;
  created_by: string | null;
  members: Member[];
  can_rename: boolean;
  can_archive: boolean;
  can_add_members: boolean;
  can_remove_members: boolean;
  can_leave: boolean;
};

export type Attachment = {
  id: string;
  file_name: string;
  content_type: string;
  size_bytes: number;
  is_image: boolean;
  has_thumb: boolean;
  width: number | null;
  height: number | null;
};

export type Msg = {
  id: number;
  channel_id: string;
  sender_id: string;
  sender_name: string;
  body: string;
  deleted: boolean;
  created_at: string;
  edited_at: string | null;
  mentions: string[];
  reply_to: { id: number; sender_name: string; body: string; deleted: boolean } | null;
  attachments: Attachment[];
  can_edit: boolean;
  can_delete: boolean;
};

export type Person = { id: string; full_name: string; username: string; me: boolean };

/** Demo names carry the role in brackets — "Anil Kumar (Sales)". Show the person, not the bracket. */
export const shortName = (n: string) => n.replace(/\s*\(.*\)\s*$/, "");

export function initials(name: string) {
  return shortName(name).split(/\s+/).filter(Boolean).map((p) => p[0]).slice(0, 2).join("").toUpperCase() || "?";
}

const TONES = [
  "bg-sky-100 text-sky-800", "bg-emerald-100 text-emerald-800", "bg-amber-100 text-amber-800",
  "bg-violet-100 text-violet-800", "bg-rose-100 text-rose-800", "bg-teal-100 text-teal-800", "bg-orange-100 text-orange-800",
];
function tone(seed: string) {
  let h = 0;
  for (const c of seed) h = (h * 31 + c.charCodeAt(0)) | 0;
  return TONES[Math.abs(h) % TONES.length];
}

export function Avatar({ name, seed, size = "md", kind }: { name: string; seed?: string; size?: "sm" | "md"; kind?: ChannelRow["kind"] }) {
  const cls = clsx("flex shrink-0 items-center justify-center rounded-full font-semibold",
    size === "sm" ? "size-8 text-[11px]" : "size-10 text-xs");
  if (kind === "company") return <span className={clsx(cls, "bg-brand-600 text-white")}><Hash className="size-4" /></span>;
  if (kind === "group") return <span className={clsx(cls, tone(seed ?? name))}><Users className="size-4" /></span>;
  if (kind === "project") return <span className={clsx(cls, tone(seed ?? name))}><Briefcase className="size-4" /></span>;
  return <span className={clsx(cls, tone(seed ?? name))}>{initials(name)}</span>;
}

const IST = "Asia/Kolkata";
export const clock = (iso: string) =>
  new Date(iso).toLocaleTimeString("en-IN", { timeZone: IST, hour: "numeric", minute: "2-digit", hour12: true });

function istDay(d: Date) {
  return d.toLocaleDateString("en-CA", { timeZone: IST });
}

export function dayLabel(iso: string) {
  const d = new Date(iso);
  const today = new Date();
  const yesterday = new Date(Date.now() - 86_400_000);
  if (istDay(d) === istDay(today)) return "Today";
  if (istDay(d) === istDay(yesterday)) return "Yesterday";
  return d.toLocaleDateString("en-IN", { timeZone: IST, day: "2-digit", month: "short", year: "numeric" });
}

export const sameDay = (a: string, b: string) => istDay(new Date(a)) === istDay(new Date(b));

/** Short time for the channel list: "4:05 pm" today, "Yesterday", or "05 Oct". */
export function listTime(iso: string | null) {
  if (!iso) return "";
  const l = dayLabel(iso);
  if (l === "Today") return clock(iso);
  if (l === "Yesterday") return l;
  return new Date(iso).toLocaleDateString("en-IN", { timeZone: IST, day: "2-digit", month: "short" });
}

const URL_RE = /(https?:\/\/[^\s<>"']+[^\s<>"'.,;:!?)\]])/g;

/** Message text: line breaks kept, links clickable, @mentions of channel members highlighted. */
export function RichText({ text, names, highlight }: { text: string; names: string[]; highlight?: string }) {
  const parts: ReactNode[] = [];
  const mentionRe = names.length
    ? new RegExp(`(@(?:${names.map((n) => n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).sort((a, b) => b.length - a.length).join("|")}))`, "g")
    : null;
  text.split(URL_RE).forEach((chunk, i) => {
    if (i % 2 === 1) {
      parts.push(<a key={`u${i}`} href={chunk} target="_blank" rel="noopener noreferrer" className="break-all text-sky-700 underline underline-offset-2 hover:text-sky-900">{chunk}</a>);
      return;
    }
    const pieces = mentionRe ? chunk.split(mentionRe) : [chunk];
    pieces.forEach((p, j) => {
      if (mentionRe && j % 2 === 1) parts.push(<span key={`m${i}-${j}`} className="rounded bg-brand-50 px-0.5 font-medium text-brand-700">{p}</span>);
      else if (highlight && p) parts.push(<Fragment key={`t${i}-${j}`}>{mark(p, highlight)}</Fragment>);
      else if (p) parts.push(<Fragment key={`t${i}-${j}`}>{p}</Fragment>);
    });
  });
  return <span className="whitespace-pre-wrap break-words">{parts}</span>;
}

function mark(text: string, q: string): ReactNode {
  const i = text.toLowerCase().indexOf(q.toLowerCase());
  if (i < 0) return text;
  return <>{text.slice(0, i)}<mark className="rounded bg-amber-200 px-0.5">{text.slice(i, i + q.length)}</mark>{mark(text.slice(i + q.length), q)}</>;
}
