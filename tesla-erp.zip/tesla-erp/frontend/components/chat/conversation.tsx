"use client";

import clsx from "clsx";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowDown, ArrowLeft, Camera, Copy, CornerUpLeft, Download, FileText, Info, Loader2, MoreHorizontal, Paperclip,
  Pencil, Search, Send, Trash2, X,
} from "lucide-react";
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Spinner, useConfirm, useToast } from "@/components/ui";
import { api, download, objectUrl, uploadWithProgress } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { bytes } from "@/lib/format";
import { compress } from "@/lib/image";
import {
  Avatar, clock, dayLabel, RichText, sameDay, shortName, type Attachment, type ChannelDetail, type ChannelRow, type Msg,
} from "./common";
import { MembersDialog } from "./dialogs";

const POLL_MS = 4000;
const MAX_LEN = 4000;
const MAX_FILES = 10;

type MessagesResp = { data: Msg[]; meta: { has_older: boolean; server_time: string; last_read_id: number; last_message_id: number } };

/* ------------------------------------------------------------------ images & files */
function useObjectUrl(path: string | null) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!path) return;
    let u: string | null = null;
    let live = true;
    objectUrl(path).then((x) => { u = x; if (live) setUrl(x); else URL.revokeObjectURL(x); }).catch(() => live && setUrl(null));
    return () => { live = false; if (u) URL.revokeObjectURL(u); };
  }, [path]);
  return url;
}

function ImageThumb({ a, onOpen, single }: { a: Attachment; onOpen: (a: Attachment) => void; single: boolean }) {
  const url = useObjectUrl(`/chat/attachments/${a.id}${a.has_thumb ? "?thumb=true" : "?inline=true"}`);
  const ratio = a.width && a.height ? a.width / a.height : 4 / 3;
  return (
    <button type="button" onClick={() => onOpen(a)} title={a.file_name}
      className={clsx("block overflow-hidden rounded-lg border border-ink-200 bg-ink-100", single ? "max-w-[280px]" : "size-28 sm:size-32")}
      style={single ? { aspectRatio: String(Math.min(Math.max(ratio, 0.6), 2)), width: 280 } : undefined}>
      {url ? <img src={url} alt={a.file_name} className="size-full object-cover" /> : <span className="flex size-full items-center justify-center"><Loader2 className="size-4 animate-spin text-ink-400" /></span>}
    </button>
  );
}

function FileChip({ a }: { a: Attachment }) {
  const [busy, setBusy] = useState(false);
  return (
    <button type="button" disabled={busy}
      onClick={async () => { setBusy(true); try { await download(`/chat/attachments/${a.id}`, a.file_name); } finally { setBusy(false); } }}
      className="flex max-w-full items-center gap-2 rounded-lg border border-ink-200 bg-white px-2.5 py-2 text-left hover:border-ink-300 hover:bg-ink-50">
      <span className="flex size-8 shrink-0 items-center justify-center rounded bg-ink-100 text-ink-600">
        {busy ? <Loader2 className="size-4 animate-spin" /> : <FileText className="size-4" />}
      </span>
      <span className="min-w-0">
        <span className="block truncate text-[13px] font-medium text-ink-900">{a.file_name}</span>
        <span className="block text-[11px] text-ink-500">{bytes(a.size_bytes)} · Download</span>
      </span>
    </button>
  );
}

function Viewer({ a, onClose }: { a: Attachment; onClose: () => void }) {
  const url = useObjectUrl(`/chat/attachments/${a.id}?inline=true`);
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", k);
    return () => document.removeEventListener("keydown", k);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black/90" onClick={onClose}>
      <div className="flex items-center gap-2 px-3 py-2 text-white" onClick={(e) => e.stopPropagation()}>
        <p className="min-w-0 flex-1 truncate text-sm">{a.file_name}</p>
        <button className="rounded p-2 hover:bg-white/10" aria-label="Download" onClick={() => download(`/chat/attachments/${a.id}`, a.file_name)}><Download className="size-5" /></button>
        <button className="rounded p-2 hover:bg-white/10" aria-label="Close" onClick={onClose}><X className="size-5" /></button>
      </div>
      <div className="flex min-h-0 flex-1 items-center justify-center p-3">
        {url ? <img src={url} alt={a.file_name} className="max-h-full max-w-full rounded object-contain" onClick={(e) => e.stopPropagation()} /> : <Loader2 className="size-6 animate-spin text-white" />}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ one message */
function MessageItem({ m, mine, showHead, names, showSender, highlight, onReply, onEdit, onDelete, onJump, onOpen }: {
  m: Msg; mine: boolean; showHead: boolean; names: string[]; showSender: boolean; highlight: boolean;
  onReply: () => void; onEdit: () => void; onDelete: () => void; onJump: (id: number) => void; onOpen: (a: Attachment) => void;
}) {
  const [menu, setMenu] = useState(false);
  const [up, setUp] = useState(false);
  const optBtn = useRef<HTMLButtonElement>(null);
  const toast = useToast();
  const images = m.attachments.filter((a) => a.is_image);
  const files = m.attachments.filter((a) => !a.is_image);
  return (
    <div id={`msg-${m.id}`} className={clsx("group flex gap-2 px-3 sm:px-4", showHead ? "mt-3" : "mt-0.5", mine && "flex-row-reverse")}>
      {!mine && showSender && <div className="w-8 shrink-0">{showHead && <Avatar name={m.sender_name} seed={m.sender_id} size="sm" />}</div>}
      <div className={clsx("flex min-w-0 max-w-[85%] flex-col sm:max-w-[70%]", mine ? "items-end" : "items-start")}>
        {showHead && (
          <p className={clsx("mb-0.5 px-1 text-[11px] text-ink-500", mine && "text-right")}>
            {!mine && showSender && <span className="mr-1.5 font-semibold text-ink-800">{shortName(m.sender_name)}</span>}
            {clock(m.created_at)}
          </p>
        )}
        <div className={clsx("relative flex items-start gap-1", mine && "flex-row-reverse")}>
          <div className={clsx(
            "min-w-0 rounded-2xl px-3 py-2 text-sm leading-relaxed transition-colors",
            m.deleted ? "border border-dashed border-ink-200 bg-transparent italic text-ink-400"
              : mine ? "bg-brand-50 text-ink-900 ring-1 ring-brand-100" : "bg-white text-ink-900 ring-1 ring-ink-200",
            highlight && "ring-2 ring-amber-400",
          )}>
            {m.deleted ? "Message deleted" : (<>
              {m.reply_to && (
                <button type="button" onClick={() => onJump(m.reply_to!.id)}
                  className="mb-1.5 block w-full rounded-md border-l-2 border-brand-400 bg-ink-50 px-2 py-1 text-left text-xs text-ink-600 hover:bg-ink-100">
                  <span className="block font-semibold text-ink-700">{shortName(m.reply_to.sender_name)}</span>
                  <span className={clsx("line-clamp-2", m.reply_to.deleted && "italic")}>{m.reply_to.body}</span>
                </button>
              )}
              {images.length > 0 && (
                <div className={clsx("mb-1 flex flex-wrap gap-1.5", mine && "justify-end")}>
                  {images.map((a) => <ImageThumb key={a.id} a={a} single={images.length === 1} onOpen={onOpen} />)}
                </div>
              )}
              {files.length > 0 && <div className="mb-1 flex flex-col gap-1.5">{files.map((a) => <FileChip key={a.id} a={a} />)}</div>}
              {m.body && <RichText text={m.body} names={names} />}
              {m.edited_at && <span className="ml-1.5 text-[10px] text-ink-400">(edited)</span>}
            </>)}
          </div>
          {!m.deleted && (
            <div className="relative self-center">
              <button ref={optBtn} type="button" aria-label="Message options"
                onClick={() => { setUp((optBtn.current?.getBoundingClientRect().bottom ?? 0) > window.innerHeight - 220); setMenu(!menu); }} onBlur={() => setTimeout(() => setMenu(false), 150)}
                className="rounded-full p-1 text-ink-400 opacity-60 hover:bg-ink-100 hover:text-ink-700 sm:opacity-0 sm:group-hover:opacity-100 sm:focus:opacity-100">
                <MoreHorizontal className="size-4" />
              </button>
              {menu && (
                <div onClick={() => setMenu(false)} className={clsx("absolute z-20 w-40", up ? "bottom-7" : "top-7", "rounded-lg border border-ink-200 bg-white p-1 text-sm shadow-lg", mine ? "right-0" : "left-0")}>
                  <MenuItem icon={<CornerUpLeft className="size-4" />} label="Reply" onClick={onReply} />
                  {m.body && <MenuItem icon={<Copy className="size-4" />} label="Copy text" onClick={() => { navigator.clipboard?.writeText(m.body).then(() => toast("Copied")); }} />}
                  {m.can_edit && <MenuItem icon={<Pencil className="size-4" />} label="Edit" onClick={onEdit} />}
                  {m.can_delete && <MenuItem icon={<Trash2 className="size-4" />} label="Delete" danger onClick={onDelete} />}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function MenuItem({ icon, label, onClick, danger }: { icon: React.ReactNode; label: string; onClick: () => void; danger?: boolean }) {
  return (
    <button type="button" onMouseDown={(e) => { e.preventDefault(); onClick(); }}
      className={clsx("flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-left hover:bg-ink-100", danger ? "text-brand-700" : "text-ink-800")}>
      {icon} {label}
    </button>
  );
}

/* ------------------------------------------------------------------ composer */
type Pending = { key: string; file: File; preview: string | null; progress: number; id?: string; error?: string };

function Composer({ channel, members, replyTo, editing, onCancelReply, onCancelEdit, onSent, disabled }: {
  channel: ChannelDetail; members: { id: string; full_name: string }[]; replyTo: Msg | null; editing: Msg | null;
  onCancelReply: () => void; onCancelEdit: () => void; onSent: (m: Msg) => void; disabled?: string | null;
}) {
  const { me } = useAuth();
  const toast = useToast();
  const [text, setText] = useState("");
  const [pending, setPending] = useState<Pending[]>([]);
  const [sending, setSending] = useState(false);
  const [mention, setMention] = useState<{ q: string; start: number; index: number } | null>(null);
  const [dragging, setDragging] = useState(false);
  const area = useRef<HTMLTextAreaElement>(null);
  const fileIn = useRef<HTMLInputElement>(null);
  const camIn = useRef<HTMLInputElement>(null);
  const draftKey = `chat-draft-${channel.id}`;

  // drafts survive switching conversations (per browser)
  useEffect(() => {
    try { setText(sessionStorage.getItem(draftKey) ?? ""); } catch { setText(""); }
    setPending([]);
  }, [draftKey]);
  useEffect(() => { if (!editing) { try { sessionStorage.setItem(draftKey, text); } catch { /* ignore */ } } }, [text, draftKey, editing]);
  useEffect(() => { if (editing) { setText(editing.body); area.current?.focus(); } }, [editing]);
  useEffect(() => { if (replyTo) area.current?.focus(); }, [replyTo]);
  useLayoutEffect(() => {
    const t = area.current;
    if (!t) return;
    t.style.height = "auto";
    t.style.height = Math.min(t.scrollHeight, 160) + "px";
  }, [text]);

  const restoreDraft = () => { try { setText(sessionStorage.getItem(draftKey) ?? ""); } catch { setText(""); } };
  const others = members.filter((m) => m.id !== me?.id);
  const suggestions = mention ? others.filter((m) => m.full_name.toLowerCase().includes(mention.q.toLowerCase())).slice(0, 6) : [];

  const addFiles = useCallback(async (list: File[]) => {
    if (!list.length) return;
    if (editing) { toast("Files cannot be added while editing a message.", "error"); return; }
    const room = MAX_FILES - pending.length;
    if (room <= 0) { toast(`Up to ${MAX_FILES} files per message.`, "error"); return; }
    const items: Pending[] = list.slice(0, room).map((f) => ({
      key: `${Date.now()}-${Math.random()}`, file: f, progress: 0,
      preview: f.type.startsWith("image/") && f.type !== "image/heic" ? URL.createObjectURL(f) : null,
    }));
    setPending((p) => [...p, ...items]);
    for (const it of items) {
      try {
        const file = await compress(it.file);
        const form = new FormData();
        form.append("file", file);
        const r = await uploadWithProgress<{ data: Attachment }>(`/chat/channels/${channel.id}/attachments`, form,
          (f) => setPending((p) => p.map((x) => x.key === it.key ? { ...x, progress: f } : x)));
        setPending((p) => p.map((x) => x.key === it.key ? { ...x, id: r.data.id, progress: 1 } : x));
      } catch (e: any) {
        setPending((p) => p.map((x) => x.key === it.key ? { ...x, error: e.message ?? "Upload failed" } : x));
      }
    }
  }, [channel.id, editing, pending.length, toast]);

  const uploading = pending.some((p) => !p.id && !p.error);
  const ready = pending.filter((p) => p.id);
  const canSend = !sending && !uploading && (text.trim().length > 0 || ready.length > 0) && text.length <= MAX_LEN;

  async function submit() {
    if (!canSend) return;
    const body = text.trim();
    const mention_ids = others.filter((m) => body.toLowerCase().includes(`@${m.full_name.toLowerCase()}`)).map((m) => m.id);
    setSending(true);
    try {
      if (editing) {
        const r = await api<{ data: Msg }>(`/chat/channels/${channel.id}/messages/${editing.id}`, { method: "PUT", body: { body, mention_ids } });
        onSent(r.data);
        onCancelEdit();
        restoreDraft();
      } else {
        const r = await api<{ data: Msg }>(`/chat/channels/${channel.id}/messages`, {
          method: "POST", body: { body, reply_to_id: replyTo?.id ?? null, attachment_ids: ready.map((p) => p.id), mention_ids },
        });
        pending.forEach((p) => p.preview && URL.revokeObjectURL(p.preview));
        setPending([]);
        setText("");
        onCancelReply();
        onSent(r.data);
      }
    } catch (e: any) {
      toast(e.message ?? "Could not send. Check the connection and try again.", "error");
    } finally {
      setSending(false);
      area.current?.focus();
    }
  }

  function onChange(v: string, caret: number) {
    setText(v);
    const before = v.slice(0, caret);
    const m = /(^|\s)@([^@\n]{0,40})$/.exec(before);
    if (m && others.some((o) => o.full_name.toLowerCase().includes(m[2].toLowerCase()))) setMention({ q: m[2], start: caret - m[2].length - 1, index: 0 });
    else setMention(null);
  }

  function pick(name: string) {
    if (!mention || !area.current) return;
    const caret = area.current.selectionStart;
    const v = text.slice(0, mention.start) + `@${name} ` + text.slice(caret);
    setText(v);
    setMention(null);
    const pos = mention.start + name.length + 2;
    requestAnimationFrame(() => { area.current?.focus(); area.current?.setSelectionRange(pos, pos); });
  }

  if (disabled) return <div className="border-t border-ink-200 bg-white px-4 py-3 text-center text-sm text-ink-500">{disabled}</div>;

  return (
    <div className={clsx("relative border-t border-ink-200 bg-white px-2 pb-2 pt-2 sm:px-3", dragging && "ring-2 ring-inset ring-brand-300")}
      onDragOver={(e) => { if (e.dataTransfer.types.includes("Files")) { e.preventDefault(); setDragging(true); } }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => { e.preventDefault(); setDragging(false); addFiles(Array.from(e.dataTransfer.files)); }}>
      {(replyTo || editing) && (
        <div className="mb-2 flex items-start gap-2 rounded-md border-l-2 border-brand-500 bg-ink-50 px-2.5 py-1.5 text-xs">
          {editing ? <Pencil className="mt-0.5 size-3.5 text-brand-600" /> : <CornerUpLeft className="mt-0.5 size-3.5 text-brand-600" />}
          <div className="min-w-0 flex-1">
            <p className="font-semibold text-ink-800">{editing ? "Editing your message" : `Replying to ${shortName(replyTo!.sender_name)}`}</p>
            {!editing && <p className="truncate text-ink-600">{replyTo!.body || "📎 Attachment"}</p>}
          </div>
          <button type="button" aria-label="Cancel" className="rounded p-0.5 text-ink-500 hover:bg-ink-200"
            onClick={() => { if (editing) { onCancelEdit(); restoreDraft(); } else onCancelReply(); }}><X className="size-3.5" /></button>
        </div>
      )}
      {pending.length > 0 && (
        <div className="mb-2 flex gap-2 overflow-x-auto pb-1">
          {pending.map((p) => (
            <div key={p.key} className="relative w-24 shrink-0">
              <div className={clsx("flex h-20 items-center justify-center overflow-hidden rounded-md border bg-ink-50", p.error ? "border-brand-300" : "border-ink-200")}>
                {p.preview ? <img src={p.preview} alt="" className="size-full object-cover" /> : <FileText className="size-6 text-ink-400" />}
              </div>
              <p className="mt-0.5 truncate text-[10px] text-ink-600" title={p.file.name}>{p.error ?? p.file.name}</p>
              {!p.id && !p.error && (
                <div className="absolute inset-x-1 bottom-5 h-1 overflow-hidden rounded bg-white/80">
                  <div className="h-full bg-brand-600 transition-all" style={{ width: `${Math.round(p.progress * 100)}%` }} />
                </div>
              )}
              <button type="button" aria-label={`Remove ${p.file.name}`} className="absolute -right-1 -top-1 rounded-full bg-ink-800 p-0.5 text-white"
                onClick={() => { if (p.preview) URL.revokeObjectURL(p.preview); setPending((x) => x.filter((y) => y.key !== p.key)); }}>
                <X className="size-3" />
              </button>
            </div>
          ))}
        </div>
      )}
      {mention && suggestions.length > 0 && (
        <div className="absolute bottom-full left-2 z-20 mb-1 w-72 max-w-[calc(100%-1rem)] rounded-lg border border-ink-200 bg-white p-1 shadow-lg">
          {suggestions.map((s, i) => (
            <button key={s.id} type="button" onMouseDown={(e) => { e.preventDefault(); pick(s.full_name); }}
              className={clsx("flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm", i === mention.index ? "bg-brand-50" : "hover:bg-ink-100")}>
              <Avatar name={s.full_name} seed={s.id} size="sm" /> {s.full_name}
            </button>
          ))}
        </div>
      )}
      <div className="flex items-end gap-1">
        <button type="button" aria-label="Attach files or photos" title="Attach files or photos" disabled={!!editing}
          onClick={() => fileIn.current?.click()} className="rounded-full p-2 text-ink-500 hover:bg-ink-100 hover:text-ink-800 disabled:opacity-40">
          <Paperclip className="size-5" />
        </button>
        <button type="button" aria-label="Take a photo" title="Take a photo" disabled={!!editing}
          onClick={() => camIn.current?.click()} className="rounded-full p-2 text-ink-500 hover:bg-ink-100 hover:text-ink-800 disabled:opacity-40 md:hidden">
          <Camera className="size-5" />
        </button>
        <input ref={fileIn} type="file" multiple className="sr-only" tabIndex={-1}
          accept="image/jpeg,image/png,image/webp,image/heic,.pdf,.docx,.xlsx,.pptx,.dwg,.csv,.txt"
          onChange={(e) => { addFiles(Array.from(e.target.files ?? [])); e.target.value = ""; }} />
        <input ref={camIn} type="file" accept="image/*" capture="environment" className="sr-only" tabIndex={-1}
          onChange={(e) => { addFiles(Array.from(e.target.files ?? [])); e.target.value = ""; }} />
        <textarea
          ref={area}
          rows={1}
          value={text}
          aria-label="Message"
          placeholder={`Message ${channel.kind === "direct" ? shortName(channel.name) : channel.name}`}
          onChange={(e) => onChange(e.target.value, e.target.selectionStart)}
          onPaste={(e) => {
            const files = Array.from(e.clipboardData.files ?? []);
            if (files.length) { e.preventDefault(); addFiles(files); }
          }}
          onKeyDown={(e) => {
            if (mention && suggestions.length) {
              if (e.key === "ArrowDown" || e.key === "ArrowUp") {
                e.preventDefault();
                const d = e.key === "ArrowDown" ? 1 : -1;
                setMention({ ...mention, index: (mention.index + d + suggestions.length) % suggestions.length });
                return;
              }
              if (e.key === "Enter" || e.key === "Tab") { e.preventDefault(); pick(suggestions[mention.index].full_name); return; }
              if (e.key === "Escape") { setMention(null); return; }
            }
            if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); submit(); }
            if (e.key === "Escape" && editing) { onCancelEdit(); restoreDraft(); }
          }}
          className="max-h-40 min-h-10 flex-1 resize-none rounded-2xl border border-ink-200 bg-ink-50 px-3.5 py-2 text-sm leading-6 placeholder:text-ink-400 focus:border-brand-600 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-100"
        />
        <button type="button" aria-label={editing ? "Save" : "Send"} title={editing ? "Save (Enter)" : "Send (Enter)"} disabled={!canSend} onClick={submit}
          className="flex size-10 shrink-0 items-center justify-center rounded-full bg-brand-600 text-white shadow-sm hover:bg-brand-700 disabled:bg-ink-200 disabled:text-ink-400">
          {sending || uploading ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
        </button>
      </div>
      <p className="mt-1 hidden px-12 text-[11px] text-ink-400 sm:block">
        Enter to send · Shift + Enter for a new line · @ to mention someone · drop or paste photos here
        {text.length > MAX_LEN - 500 && <span className={clsx("float-right", text.length > MAX_LEN && "font-semibold text-brand-700")}>{text.length}/{MAX_LEN}</span>}
      </p>
    </div>
  );
}

/* ------------------------------------------------------------------ search */
function SearchPanel({ channelId, names, onPick, onClose }: { channelId: string; names: string[]; onPick: (id: number) => void; onClose: () => void }) {
  const [q, setQ] = useState("");
  const [deb, setDeb] = useState("");
  useEffect(() => { const t = setTimeout(() => setDeb(q.trim()), 300); return () => clearTimeout(t); }, [q]);
  const { data, isFetching } = useQuery({
    queryKey: ["/chat/search", channelId, deb],
    queryFn: () => api<{ data: Msg[] }>(`/chat/channels/${channelId}/search`, { params: { q: deb } }),
    enabled: deb.length >= 2,
  });
  return (
    <div className="flex max-h-[60%] flex-col border-b border-ink-200 bg-white">
      <div className="flex items-center gap-2 px-3 py-2">
        <Search className="size-4 text-ink-400" />
        <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search this conversation"
          className="h-8 flex-1 bg-transparent text-sm focus:outline-none" />
        {isFetching && <Loader2 className="size-4 animate-spin text-ink-400" />}
        <button type="button" aria-label="Close search" onClick={onClose} className="rounded p-1 text-ink-500 hover:bg-ink-100"><X className="size-4" /></button>
      </div>
      {deb.length >= 2 && (
        <ul className="overflow-y-auto border-t border-ink-100">
          {data && !data.data.length && <li className="px-4 py-3 text-sm text-ink-500">No messages match “{deb}”.</li>}
          {data?.data.map((m) => (
            <li key={m.id}>
              <button type="button" onClick={() => onPick(m.id)} className="block w-full px-4 py-2 text-left hover:bg-brand-50">
                <span className="block text-[11px] text-ink-500"><b className="text-ink-700">{shortName(m.sender_name)}</b> · {dayLabel(m.created_at)} {clock(m.created_at)}</span>
                <span className="line-clamp-2 text-sm text-ink-800"><RichText text={m.body} names={names} highlight={deb} /></span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ the conversation pane */
export function Conversation({ channelId, focusId, row, onBack, onGone }: {
  channelId: string; focusId: number | null; row: ChannelRow | undefined; onBack: () => void; onGone: () => void;
}) {
  const { me } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const detail = useQuery({
    queryKey: ["/chat/channel", channelId],
    queryFn: () => api<{ data: ChannelDetail }>(`/chat/channels/${channelId}`).then((r) => r.data),
  });
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [hasOlder, setHasOlder] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [firstUnread, setFirstUnread] = useState<number | null>(null);
  const [replyTo, setReplyTo] = useState<Msg | null>(null);
  const [editing, setEditing] = useState<Msg | null>(null);
  const [viewer, setViewer] = useState<Attachment | null>(null);
  const [searching, setSearching] = useState(false);
  const [info, setInfo] = useState(false);
  const [flash, setFlash] = useState<number | null>(null);
  const [atBottom, setAtBottom] = useState(true);
  const [newBelow, setNewBelow] = useState(0);
  const box = useRef<HTMLDivElement>(null);
  const since = useRef<string | null>(null);
  const readUpTo = useRef(0);
  const stickBottom = useRef(true);
  const keepOffset = useRef<number | null>(null);
  const scrollTarget = useRef<number | null>(null);
  const hasGap = useRef(false); // loaded "around" a message: newer messages exist below what is shown

  const merge = useCallback((incoming: Msg[]) => {
    if (!incoming.length) return;
    setMsgs((cur) => {
      const map = new Map(cur.map((m) => [m.id, m]));
      for (const m of incoming) map.set(m.id, m);
      return Array.from(map.values()).sort((a, b) => a.id - b.id);
    });
  }, []);

  const load = useCallback(async (around: number | null) => {
    setLoading(true);
    setError(null);
    try {
      const r = await api<MessagesResp>(`/chat/channels/${channelId}/messages`, { params: around ? { around_id: around } : {} });
      setMsgs(r.data);
      setHasOlder(r.meta.has_older);
      since.current = r.meta.server_time;
      readUpTo.current = r.meta.last_read_id;
      const unreadFirst = r.data.find((m) => m.id > r.meta.last_read_id && m.sender_id !== me?.id);
      setFirstUnread(unreadFirst?.id ?? null);
      hasGap.current = !!around && (r.data.at(-1)?.id ?? 0) < r.meta.last_message_id;
      scrollTarget.current = around ?? unreadFirst?.id ?? null;
      stickBottom.current = !scrollTarget.current;
      if (around) { setFlash(around); setTimeout(() => setFlash(null), 2500); }
    } catch (e: any) {
      if (e.status === 403 || e.status === 404) onGone();
      setError(e.message ?? "Could not load messages.");
    } finally {
      setLoading(false);
    }
  }, [channelId, me?.id, onGone]);

  useEffect(() => {
    setMsgs([]); setReplyTo(null); setEditing(null); setSearching(false); setNewBelow(0);
    load(focusId);
  }, [channelId, focusId, load]);

  // polling for new and changed messages
  useEffect(() => {
    let stop = false;
    const tick = async () => {
      if (document.visibilityState !== "visible" || loading || hasGap.current) return;
      const last = msgs.at(-1)?.id ?? 0;
      try {
        const r = await api<MessagesResp>(`/chat/channels/${channelId}/messages`, { params: { after_id: last, since: since.current ?? undefined } });
        if (stop) return;
        since.current = r.meta.server_time;
        const fresh = r.data.filter((m) => m.id > last);
        if (fresh.length) {
          const el = box.current;
          const near = !el || el.scrollHeight - el.scrollTop - el.clientHeight < 120;
          stickBottom.current = near;
          if (!near) setNewBelow((n) => n + fresh.filter((m) => m.sender_id !== me?.id).length);
        }
        merge(r.data);
      } catch { /* the next tick tries again */ }
    };
    const t = setInterval(tick, POLL_MS);
    return () => { stop = true; clearInterval(t); };
  }, [channelId, msgs, loading, merge, me?.id]);

  // scrolling: keep position when older messages are added, follow the bottom when new ones arrive
  useLayoutEffect(() => {
    const el = box.current;
    if (!el) return;
    if (keepOffset.current !== null) {
      el.scrollTop = el.scrollHeight - keepOffset.current;
      keepOffset.current = null;
    } else if (scrollTarget.current) {
      const t = document.getElementById(`msg-${scrollTarget.current}`);
      if (t) { t.scrollIntoView({ block: "center" }); scrollTarget.current = null; }
    } else if (stickBottom.current) {
      el.scrollTop = el.scrollHeight;
    }
    setAtBottom(el.scrollHeight - el.scrollTop - el.clientHeight < 60);
  }, [msgs]);

  // mark read when the newest message is on screen
  const markRead = useCallback(async () => {
    const last = msgs.at(-1)?.id ?? 0;
    if (!last || last <= readUpTo.current || document.visibilityState !== "visible" || hasGap.current) return;
    readUpTo.current = last;
    try {
      await api(`/chat/channels/${channelId}/read`, { method: "POST", body: { last_id: last } });
      qc.setQueryData<{ data: ChannelRow[]; meta: { unread: number } }>(["/chat/channels"], (old) => {
        if (!old) return old;
        const data = old.data.map((c) => c.id === channelId ? { ...c, unread: 0 } : c);
        return { ...old, data, meta: { ...old.meta, unread: data.reduce((s, c) => s + c.unread, 0) } };
      });
    } catch { readUpTo.current = 0; }
  }, [msgs, channelId, qc]);
  useEffect(() => { if (atBottom) markRead(); }, [atBottom, markRead]);
  useEffect(() => {
    const v = () => atBottom && markRead();
    document.addEventListener("visibilitychange", v);
    return () => document.removeEventListener("visibilitychange", v);
  }, [atBottom, markRead]);

  async function loadOlder() {
    if (!hasOlder || loadingOlder || !msgs.length) return;
    setLoadingOlder(true);
    try {
      const r = await api<MessagesResp>(`/chat/channels/${channelId}/messages`, { params: { before_id: msgs[0].id } });
      const el = box.current;
      keepOffset.current = el ? el.scrollHeight - el.scrollTop : null;
      stickBottom.current = false;
      setHasOlder(r.meta.has_older);
      merge(r.data);
    } finally {
      setLoadingOlder(false);
    }
  }

  function onScroll() {
    const el = box.current;
    if (!el) return;
    if (el.scrollTop < 120) loadOlder();
    const bottom = el.scrollHeight - el.scrollTop - el.clientHeight < 60;
    setAtBottom(bottom);
    if (bottom) setNewBelow(0);
    if (bottom && hasGap.current) { hasGap.current = false; load(null); }
  }

  function jump(id: number) {
    const el = document.getElementById(`msg-${id}`);
    if (el) {
      el.scrollIntoView({ block: "center", behavior: "smooth" });
      setFlash(id);
      setTimeout(() => setFlash(null), 2500);
    } else load(id);
  }

  function toBottom() {
    if (hasGap.current) { hasGap.current = false; load(null); return; }
    const el = box.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
    setNewBelow(0);
  }

  async function remove(m: Msg) {
    const theirs = m.sender_id !== me?.id;
    if (!(await confirm({
      title: "Delete message?",
      body: theirs ? `This removes ${shortName(m.sender_name)}'s message for everyone. It is recorded in the audit log.` : "Everyone will see “Message deleted” instead.",
      confirmLabel: "Delete",
    }))) return;
    try {
      const r = await api<{ data: Msg }>(`/chat/channels/${channelId}/messages/${m.id}`, { method: "DELETE" });
      merge([r.data]);
    } catch (e: any) {
      toast(e.message ?? "Could not delete.", "error");
    }
  }

  const ch = detail.data;
  const names = useMemo(() => (ch?.members ?? []).map((m) => m.full_name), [ch]);
  const showSender = ch?.kind !== "direct";
  const directGone = ch?.kind === "direct" && ch.members.some((m) => m.id !== me?.id && !m.is_active);
  const subtitle = !ch ? "" : ch.kind === "direct" ? "Direct message" : ch.kind === "company" ? `Everyone · ${ch.members.length} people`
    : `${ch.members.length} ${ch.members.length === 1 ? "member" : "members"}${ch.kind === "project" ? " · project team" : ""}`;

  return (
    <div className="relative flex h-full min-h-0 flex-col bg-ink-50/60">
      <header className="flex items-center gap-2 border-b border-ink-200 bg-white px-2 py-2 sm:px-3">
        <button type="button" onClick={onBack} aria-label="Back to conversations" className="rounded p-1.5 text-ink-600 hover:bg-ink-100 md:hidden">
          <ArrowLeft className="size-5" />
        </button>
        <Avatar name={ch?.name ?? row?.name ?? ""} seed={ch?.kind === "direct" ? ch.members.find((m) => m.id !== me?.id)?.id : channelId} kind={ch?.kind ?? row?.kind} size="sm" />
        <button type="button" className="min-w-0 flex-1 text-left" onClick={() => setInfo(true)}>
          <p className="truncate text-sm font-semibold text-ink-900">{ch?.name ?? row?.name ?? "…"}</p>
          <p className="truncate text-xs text-ink-500">{ch?.description && ch.kind !== "project" ? ch.description : subtitle}</p>
        </button>
        <button type="button" aria-label="Search messages" title="Search messages" onClick={() => setSearching((s) => !s)}
          className={clsx("rounded p-2 hover:bg-ink-100", searching ? "text-brand-700" : "text-ink-600")}><Search className="size-4.5" /></button>
        <button type="button" aria-label="Conversation details" title="Members and details" onClick={() => setInfo(true)}
          className="rounded p-2 text-ink-600 hover:bg-ink-100"><Info className="size-4.5" /></button>
      </header>
      {searching && <SearchPanel channelId={channelId} names={names} onClose={() => setSearching(false)} onPick={(id) => { setSearching(false); jump(id); }} />}
      <div ref={box} onScroll={onScroll} className="min-h-0 flex-1 overflow-y-auto overscroll-contain pb-3" data-testid="chat-messages">
        {loading ? <Spinner label="Loading messages…" /> : error ? (
          <p className="p-6 text-center text-sm text-brand-700">{error}</p>
        ) : (<>
          {hasOlder ? (
            <div className="flex justify-center py-3">{loadingOlder ? <Loader2 className="size-4 animate-spin text-ink-400" /> :
              <button type="button" className="text-xs font-medium text-brand-700 hover:underline" onClick={loadOlder}>Load older messages</button>}</div>
          ) : (
            <div className="px-6 pb-2 pt-8 text-center">
              <p className="text-sm font-medium text-ink-700">{ch?.kind === "direct" ? `This is the start of your conversation with ${shortName(ch.name)}.` : `Welcome to ${ch?.name ?? "the conversation"}.`}</p>
              {ch?.kind === "company" && <p className="mt-1 text-xs text-ink-500">Everyone in the company can read this channel.</p>}
            </div>
          )}
          {msgs.map((m, i) => {
            const prev = msgs[i - 1];
            const newDay = !prev || !sameDay(prev.created_at, m.created_at);
            const head = newDay || !prev || prev.sender_id !== m.sender_id || new Date(m.created_at).getTime() - new Date(prev.created_at).getTime() > 5 * 60_000 || m.id === firstUnread;
            return (
              <div key={m.id}>
                {newDay && (
                  <div className="my-3 flex items-center gap-3 px-4">
                    <span className="h-px flex-1 bg-ink-200" /><span className="text-[11px] font-medium text-ink-500">{dayLabel(m.created_at)}</span><span className="h-px flex-1 bg-ink-200" />
                  </div>
                )}
                {m.id === firstUnread && (
                  <div className="my-2 flex items-center gap-3 px-4">
                    <span className="h-px flex-1 bg-brand-300" /><span className="text-[11px] font-semibold text-brand-700">New messages</span><span className="h-px flex-1 bg-brand-300" />
                  </div>
                )}
                <MessageItem m={m} mine={m.sender_id === me?.id} showHead={head} names={names} showSender={showSender} highlight={flash === m.id}
                  onReply={() => { setEditing(null); setReplyTo(m); }}
                  onEdit={() => { setReplyTo(null); setEditing(m); }}
                  onDelete={() => remove(m)} onJump={jump} onOpen={setViewer} />
              </div>
            );
          })}
        </>)}
      </div>
      {(!atBottom || newBelow > 0) && !loading && (
        <button type="button" onClick={toBottom}
          className="absolute bottom-24 right-4 z-10 flex items-center gap-1 rounded-full border border-ink-200 bg-white px-3 py-1.5 text-xs font-medium text-ink-700 shadow-md hover:bg-ink-50">
          <ArrowDown className="size-3.5" /> {newBelow > 0 ? `${newBelow} new` : "Latest"}
        </button>
      )}
      {ch && (
        <Composer channel={ch} members={ch.members} replyTo={replyTo} editing={editing}
          disabled={directGone ? "This person no longer has an active login." : null}
          onCancelReply={() => setReplyTo(null)} onCancelEdit={() => setEditing(null)}
          onSent={(m) => {
            stickBottom.current = true;
            if (hasGap.current) { hasGap.current = false; load(null); } else merge([m]);
            readUpTo.current = Math.max(readUpTo.current, m.id);
            qc.invalidateQueries({ queryKey: ["/chat/channels"] });
          }} />
      )}
      {viewer && <Viewer a={viewer} onClose={() => setViewer(null)} />}
      {info && ch && <MembersDialog channel={ch} onClose={() => setInfo(false)} onLeft={() => { setInfo(false); onGone(); }} />}
    </div>
  );
}
