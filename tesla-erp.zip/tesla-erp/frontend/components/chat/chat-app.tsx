"use client";

import clsx from "clsx";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { MessageCircle, MessageSquarePlus, Plus, Search, Users } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { EmptyState, ErrorNote, Spinner } from "@/components/ui";
import { api } from "@/lib/api/client";
import { Avatar, listTime, shortName, type ChannelRow } from "./common";
import { Conversation } from "./conversation";
import { NewDirectDialog, NewGroupDialog } from "./dialogs";

const LIST_POLL_MS = 5000;

function ChannelList({ rows, active, onOpen }: { rows: ChannelRow[]; active: string | null; onOpen: (id: string) => void }) {
  return (
    <ul className="divide-y divide-ink-100">
      {rows.map((c) => (
        <li key={c.id}>
          <button type="button" onClick={() => onOpen(c.id)} data-testid={`channel-${c.kind}`}
            className={clsx("flex w-full items-center gap-3 px-3 py-2.5 text-left", c.id === active ? "bg-brand-50" : "hover:bg-ink-50")}>
            <Avatar name={c.name} seed={c.kind === "direct" ? c.name : c.id} kind={c.kind} />
            <span className="min-w-0 flex-1">
              <span className="flex items-baseline gap-2">
                <span className={clsx("min-w-0 flex-1 truncate text-sm", c.unread ? "font-semibold text-ink-900" : "font-medium text-ink-800")}>{c.kind === "direct" ? shortName(c.name) : c.name}</span>
                <span className={clsx("shrink-0 text-[11px]", c.unread ? "font-semibold text-brand-700" : "text-ink-400")}>{listTime(c.last_message_at)}</span>
              </span>
              <span className="flex items-center gap-2">
                <span className={clsx("min-w-0 flex-1 truncate text-xs", c.unread ? "text-ink-800" : "text-ink-500")}>
                  {c.last_message ? `${c.last_message.mine ? "You" : c.kind === "direct" ? "" : shortName(c.last_message.sender)}${c.last_message.mine || c.kind !== "direct" ? ": " : ""}${c.last_message.text}`
                    : c.kind === "company" ? "Everyone in the company" : "No messages yet"}
                </span>
                {c.unread > 0 && <span className="num flex min-w-5 items-center justify-center rounded-full bg-brand-600 px-1.5 text-[11px] font-semibold leading-5 text-white">{c.unread > 99 ? "99+" : c.unread}</span>}
              </span>
            </span>
          </button>
        </li>
      ))}
    </ul>
  );
}

export function ChatApp() {
  const params = useSearchParams();
  const router = useRouter();
  const qc = useQueryClient();
  const active = params.get("c");
  const focus = params.get("m") ? Number(params.get("m")) : null;
  const [filter, setFilter] = useState("");
  const [menu, setMenu] = useState(false);
  const [dm, setDm] = useState(false);
  const [group, setGroup] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const list = useQuery({
    queryKey: ["/chat/channels"],
    queryFn: () => api<{ data: ChannelRow[]; meta: { unread: number } }>("/chat/channels"),
    refetchInterval: LIST_POLL_MS,
    staleTime: 0,
  });
  const rows = (list.data?.data ?? []).filter((c) => c.name.toLowerCase().includes(filter.toLowerCase()));

  const open = useCallback((id: string | null, replace = false) => {
    const url = id ? `/chat?c=${id}` : "/chat";
    if (replace) router.replace(url); else router.push(url);
  }, [router]);

  // desktop: open the company channel when nothing is selected
  useEffect(() => {
    if (active || !list.data?.data.length) return;
    if (window.matchMedia("(min-width: 768px)").matches) open(list.data.data[0].id, true);
  }, [active, list.data, open]);

  useEffect(() => {
    const close = (e: MouseEvent) => menuRef.current && !menuRef.current.contains(e.target as Node) && setMenu(false);
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const row = list.data?.data.find((c) => c.id === active);
  const gone = useCallback(() => {
    qc.invalidateQueries({ queryKey: ["/chat/channels"] });
    open(null, true);
  }, [qc, open]);

  return (
    <div className="-mx-4 -my-6 flex h-[calc(100dvh-59px)] overflow-hidden bg-white sm:-mx-6 md:mx-0 md:my-0 md:h-[calc(100dvh-59px-3rem)] md:rounded-xl md:border md:border-ink-200 md:shadow-sm">
      <aside className={clsx("flex w-full min-w-0 flex-col border-r border-ink-200 md:w-80 md:shrink-0", active && "hidden md:flex")}>
        <div className="flex items-center gap-2 border-b border-ink-200 px-3 py-2.5">
          <h1 className="flex-1 text-base font-semibold text-ink-900">Chat</h1>
          <div className="relative" ref={menuRef}>
            <button type="button" onClick={() => setMenu(!menu)} aria-label="New conversation" title="New conversation"
              className="flex items-center gap-1 rounded-md bg-brand-600 px-2.5 py-1.5 text-[13px] font-medium text-white hover:bg-brand-700">
              <Plus className="size-4" /> New
            </button>
            {menu && (
              <div className="absolute right-0 top-9 z-30 w-52 rounded-lg border border-ink-200 bg-white p-1 shadow-lg">
                <button type="button" className="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-left text-sm hover:bg-ink-100" onClick={() => { setMenu(false); setDm(true); }}>
                  <MessageSquarePlus className="size-4 text-ink-500" /> Message a person
                </button>
                <button type="button" className="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-left text-sm hover:bg-ink-100" onClick={() => { setMenu(false); setGroup(true); }}>
                  <Users className="size-4 text-ink-500" /> New group
                </button>
              </div>
            )}
          </div>
        </div>
        <div className="border-b border-ink-100 px-3 py-2">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-ink-400" />
            <input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Find a conversation" aria-label="Find a conversation"
              className="h-8 w-full rounded-md border border-ink-200 bg-ink-50 pl-8 pr-2 text-sm placeholder:text-ink-400 focus:border-brand-600 focus:bg-white focus:outline-none" />
          </div>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto">
          {list.isLoading ? <Spinner /> : list.error ? <div className="p-3"><ErrorNote error={list.error} /></div> : (
            <ChannelList rows={rows} active={active} onOpen={(id) => open(id)} />
          )}
          {list.data && !rows.length && <p className="px-4 py-6 text-center text-sm text-ink-500">No conversations match.</p>}
        </div>
      </aside>
      <section className={clsx("min-w-0 flex-1", !active && "hidden md:block")}>
        {active ? (
          <Conversation key={active} channelId={active} focusId={focus} row={row} onBack={() => open(null)} onGone={gone} />
        ) : (
          <EmptyState icon={<MessageCircle className="size-10" />} title="Pick a conversation"
            body="Chat with the whole team in Tesla Team, message one person directly, or start a group." />
        )}
      </section>
      <NewDirectDialog open={dm} onClose={() => setDm(false)} onOpened={(id) => { setDm(false); open(id); }} />
      <NewGroupDialog open={group} onClose={() => setGroup(false)} onOpened={(id) => { setGroup(false); open(id); }} />
    </div>
  );
}
