"use client";

import clsx from "clsx";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, LogOut, Pencil, Search, Trash2, UserMinus, UserPlus } from "lucide-react";
import { useMemo, useState } from "react";
import { Button, ErrorNote, Field, Input, Modal, useConfirm, useToast } from "@/components/ui";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { Avatar, type ChannelDetail, type Person } from "./common";

export function usePeople() {
  return useQuery({
    queryKey: ["/chat/people"],
    queryFn: () => api<{ data: Person[] }>("/chat/people").then((r) => r.data),
    staleTime: 5 * 60_000,
  });
}

/** Searchable list of colleagues; single pick (onPick) or multi-select (selected/onToggle). */
function PeopleList({ exclude = [], selected, onToggle, onPick }: {
  exclude?: string[]; selected?: Set<string>; onToggle?: (id: string) => void; onPick?: (p: Person) => void;
}) {
  const { data, error } = usePeople();
  const [q, setQ] = useState("");
  const rows = useMemo(() => (data ?? []).filter((p) => !p.me && !exclude.includes(p.id)
    && (p.full_name.toLowerCase().includes(q.toLowerCase()) || p.username.toLowerCase().includes(q.toLowerCase()))), [data, q, exclude]);
  return (
    <div>
      <div className="relative mb-2">
        <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-ink-400" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name" className="pl-8" aria-label="Search people" />
      </div>
      <ErrorNote error={error} />
      <ul className="max-h-72 overflow-y-auto rounded-md border border-ink-100">
        {rows.map((p) => {
          const on = selected?.has(p.id);
          return (
            <li key={p.id}>
              <button type="button" onClick={(e) => { e.preventDefault(); if (onPick) onPick(p); else onToggle?.(p.id); }}
                className={clsx("flex w-full items-center gap-2.5 px-3 py-2 text-left text-sm hover:bg-ink-50", on && "bg-brand-50")}>
                <Avatar name={p.full_name} seed={p.id} size="sm" />
                <span className="min-w-0 flex-1"><span className="block truncate font-medium text-ink-900">{p.full_name}</span>
                  <span className="block text-xs text-ink-500">{p.username}</span></span>
                {selected && <span className={clsx("flex size-5 items-center justify-center rounded border", on ? "border-brand-600 bg-brand-600 text-white" : "border-ink-300")}>{on && <Check className="size-3.5" />}</span>}
              </button>
            </li>
          );
        })}
        {data && !rows.length && <li className="px-3 py-4 text-center text-sm text-ink-500">Nobody found.</li>}
      </ul>
    </div>
  );
}

export function NewDirectDialog({ open, onClose, onOpened }: { open: boolean; onClose: () => void; onOpened: (id: string) => void }) {
  const toast = useToast();
  const qc = useQueryClient();
  return (
    <Modal open={open} onClose={onClose} title="Message a person">
      <PeopleList onPick={async (p) => {
        try {
          const r = await api<{ data: ChannelDetail }>("/chat/direct", { method: "POST", body: { user_id: p.id } });
          qc.invalidateQueries({ queryKey: ["/chat/channels"] });
          onOpened(r.data.id);
        } catch (e: any) { toast(e.message, "error"); }
      }} />
    </Modal>
  );
}

export function NewGroupDialog({ open, onClose, onOpened }: { open: boolean; onClose: () => void; onOpened: (id: string) => void }) {
  const [name, setName] = useState("");
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<unknown>(null);
  const qc = useQueryClient();
  const toggle = (id: string) => setSel((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  async function create() {
    setBusy(true); setErr(null);
    try {
      const r = await api<{ data: ChannelDetail }>("/chat/channels", { method: "POST", body: { name, member_ids: Array.from(sel) } });
      qc.invalidateQueries({ queryKey: ["/chat/channels"] });
      setName(""); setSel(new Set());
      onOpened(r.data.id);
    } catch (e) { setErr(e); } finally { setBusy(false); }
  }
  return (
    <Modal open={open} onClose={onClose} title="New group"
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button>
        <Button loading={busy} disabled={!name.trim()} onClick={create}>Create group{sel.size ? ` (${sel.size + 1})` : ""}</Button></>}>
      <div className="space-y-3">
        <ErrorNote error={err} />
        <Field label="Group name" required><Input value={name} maxLength={120} onChange={(e) => setName(e.target.value)} placeholder="e.g. ABC Hospital site team" /></Field>
        <div>
          <p className="mb-1 text-[13px] font-medium text-ink-700">Add people</p>
          <PeopleList selected={sel} onToggle={toggle} />
        </div>
      </div>
    </Modal>
  );
}

export function MembersDialog({ channel, onClose, onLeft }: { channel: ChannelDetail; onClose: () => void; onLeft: () => void }) {
  const { me } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [adding, setAdding] = useState(false);
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [renaming, setRenaming] = useState(false);
  const [name, setName] = useState(channel.name);
  const [busy, setBusy] = useState(false);
  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["/chat/channel", channel.id] });
    qc.invalidateQueries({ queryKey: ["/chat/channels"] });
  };
  async function run(fn: () => Promise<unknown>, ok?: string) {
    setBusy(true);
    try { await fn(); refresh(); if (ok) toast(ok); return true; } catch (e: any) { toast(e.message, "error"); return false; } finally { setBusy(false); }
  }
  const title = channel.kind === "company" ? channel.name : channel.kind === "direct" ? "Direct message" : channel.name;
  return (
    <Modal open onClose={onClose} title={title}>
      <div className="space-y-4">
        {channel.description && channel.kind !== "direct" && <p className="text-sm text-ink-600">{channel.description}</p>}
        {renaming ? (
          <div className="flex items-end gap-2">
            <Field label="Group name" className="flex-1"><Input value={name} maxLength={120} onChange={(e) => setName(e.target.value)} /></Field>
            <Button loading={busy} disabled={!name.trim()} onClick={async () => { if (await run(() => api(`/chat/channels/${channel.id}`, { method: "PUT", body: { name, description: channel.description } }), "Renamed")) setRenaming(false); }}>Save</Button>
          </div>
        ) : null}
        <div>
          <div className="mb-1.5 flex items-center justify-between">
            <p className="text-[13px] font-semibold text-ink-700">{channel.members.length} {channel.members.length === 1 ? "member" : "members"}</p>
            {channel.can_add_members && !adding && <Button size="sm" variant="secondary" icon={<UserPlus className="size-3.5" />} onClick={() => setAdding(true)}>Add people</Button>}
          </div>
          {adding ? (
            <div className="space-y-2">
              <PeopleList exclude={channel.members.map((m) => m.id)} selected={sel}
                onToggle={(id) => setSel((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; })} />
              <div className="flex justify-end gap-2">
                <Button variant="secondary" size="sm" onClick={() => { setAdding(false); setSel(new Set()); }}>Cancel</Button>
                <Button size="sm" loading={busy} disabled={!sel.size} onClick={async () => {
                  if (await run(() => api(`/chat/channels/${channel.id}/members`, { method: "POST", body: { user_ids: Array.from(sel) } }), "Added")) { setAdding(false); setSel(new Set()); }
                }}>Add {sel.size || ""}</Button>
              </div>
            </div>
          ) : (
            <ul className="max-h-72 divide-y divide-ink-100 overflow-y-auto rounded-md border border-ink-100">
              {channel.members.map((m) => (
                <li key={m.id} className="flex items-center gap-2.5 px-3 py-2">
                  <Avatar name={m.full_name} seed={m.id} size="sm" />
                  <span className="min-w-0 flex-1 text-sm">
                    <span className="block truncate font-medium text-ink-900">{m.full_name}{m.id === me?.id && " (you)"}</span>
                    <span className="block text-xs text-ink-500">{m.is_active ? m.username : "No longer active"}{m.id === channel.created_by && channel.kind === "group" ? " · created the group" : ""}</span>
                  </span>
                  {channel.can_remove_members && m.id !== me?.id && (
                    <button type="button" aria-label={`Remove ${m.full_name}`} title="Remove from group" className="rounded p-1.5 text-ink-400 hover:bg-ink-100 hover:text-brand-700"
                      onClick={async () => {
                        if (await confirm({ title: "Remove from group?", body: `${m.full_name} will no longer see this group.`, confirmLabel: "Remove" }))
                          run(() => api(`/chat/channels/${channel.id}/members/${m.id}`, { method: "DELETE" }), "Removed");
                      }}><UserMinus className="size-4" /></button>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="flex flex-wrap gap-2 border-t border-ink-100 pt-3">
          {channel.can_rename && !renaming && <Button size="sm" variant="secondary" icon={<Pencil className="size-3.5" />} onClick={() => setRenaming(true)}>Rename</Button>}
          {channel.can_leave && (
            <Button size="sm" variant="secondary" icon={<LogOut className="size-3.5" />} onClick={async () => {
              if (!(await confirm({ title: "Leave this conversation?", body: channel.kind === "project" ? "You can rejoin from the project page." : "Someone in the group can add you back.", confirmLabel: "Leave" }))) return;
              if (await run(() => api(`/chat/channels/${channel.id}/leave`, { method: "POST" }), "You left the conversation")) onLeft();
            }}>Leave</Button>
          )}
          {channel.can_archive && (
            <Button size="sm" variant="danger" icon={<Trash2 className="size-3.5" />} onClick={async () => {
              if (!(await confirm({ title: "Close this group?", body: "The group disappears for everyone. Messages are kept for records.", confirmLabel: "Close group" }))) return;
              if (await run(() => api(`/chat/channels/${channel.id}`, { method: "DELETE" }), "Group closed")) onLeft();
            }}>Close group</Button>
          )}
        </div>
      </div>
    </Modal>
  );
}
