"use client";

import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, Download, FileSpreadsheet } from "lucide-react";
import { Button, ErrorNote, Modal, useToast } from "@/components/ui";
import { api, download } from "@/lib/api/client";

type Report = { rows: number; valid: number; errors: { row: number; field: string; message: string }[]; created: number; committed: boolean };

/** Excel import: download template → upload → validation report (nothing saved) → import all-or-nothing. */
export function ImportDialog({ open, onClose, base, noun }: { open: boolean; onClose: () => void; base: string; noun: string }) {
  const [file, setFile] = useState<File | null>(null);
  const [report, setReport] = useState<Report | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const qc = useQueryClient();
  const toast = useToast();

  async function run(dryRun: boolean) {
    if (!file) return;
    setBusy(true);
    setError(null);
    try {
      const form = new FormData();
      form.append("file", file);
      const r = await api<{ data: Report }>(`${base}/import`, { method: "POST", form, params: { dry_run: dryRun } });
      setReport(r.data);
      if (r.data.committed) {
        qc.invalidateQueries({ queryKey: [base] });
        toast(`Imported ${r.data.created} ${noun}`);
        close();
      }
    } catch (e) {
      setError(e);
    } finally {
      setBusy(false);
    }
  }
  function close() {
    setFile(null);
    setReport(null);
    setError(null);
    onClose();
  }
  const canImport = report && report.errors.length === 0 && report.valid > 0;
  return (
    <Modal
      open={open}
      onClose={close}
      title={`Import ${noun} from Excel`}
      wide
      footer={
        <>
          <Button variant="secondary" onClick={close}>Cancel</Button>
          {canImport ? (
            <Button onClick={() => run(false)} loading={busy}>Import {report!.valid} {noun}</Button>
          ) : (
            <Button onClick={() => run(true)} loading={busy} disabled={!file}>Check file</Button>
          )}
        </>
      }
    >
      <div className="space-y-4 text-sm">
        <ol className="list-decimal space-y-1 pl-5 text-ink-600">
          <li>
            Download the template and fill one {noun.replace(/s$/, "")} per row.{" "}
            <button className="inline-flex items-center gap-1 font-medium text-brand-700 hover:underline" onClick={() => download(`${base}/import-template`, "template.xlsx")}>
              <Download className="size-3.5" /> Template
            </button>
          </li>
          <li>Upload it and press <b>Check file</b>. Nothing is saved at this step.</li>
          <li>If every row is valid, press <b>Import</b>. If any row has an error, nothing is imported.</li>
        </ol>
        <label className="flex cursor-pointer items-center gap-3 rounded-lg border-2 border-dashed border-ink-200 px-4 py-5 hover:border-brand-300">
          <FileSpreadsheet className="size-6 text-ink-400" />
          <span className="flex-1 text-ink-700">{file ? file.name : "Choose an .xlsx file"}</span>
          <input
            type="file"
            accept=".xlsx"
            className="sr-only"
            onChange={(e) => {
              setFile(e.target.files?.[0] ?? null);
              setReport(null);
            }}
          />
        </label>
        <ErrorNote error={error} />
        {report && (
          <div>
            <p className="mb-2 flex items-center gap-1.5">
              {report.errors.length === 0 ? <CheckCircle2 className="size-4 text-emerald-600" /> : null}
              {report.rows} rows read · <b>{report.valid}</b> valid · <b className={report.errors.length ? "text-brand-700" : ""}>{report.errors.length}</b> problems
            </p>
            {report.errors.length > 0 && (
              <div className="max-h-64 overflow-y-auto rounded-md border border-ink-200">
                <table className="w-full text-xs">
                  <thead className="bg-ink-50 text-left text-ink-500">
                    <tr>
                      <th className="px-3 py-1.5">Row</th>
                      <th className="px-3 py-1.5">Column</th>
                      <th className="px-3 py-1.5">Problem</th>
                    </tr>
                  </thead>
                  <tbody>
                    {report.errors.map((e, i) => (
                      <tr key={i} className="border-t border-ink-100">
                        <td className="num px-3 py-1.5">{e.row}</td>
                        <td className="px-3 py-1.5">{e.field}</td>
                        <td className="px-3 py-1.5">{e.message}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </Modal>
  );
}
