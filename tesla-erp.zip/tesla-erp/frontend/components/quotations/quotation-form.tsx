"use client";

import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowDown, ArrowUp, BookOpen, Plus, Trash2, UserPlus } from "lucide-react";
import { QuickCustomerDialog } from "@/components/customers/quick-customer";
import { Button, Card, ErrorNote, Field, Input, Select, Textarea } from "@/components/ui";
import { CustomerPicker, peopleOptions, useCustomerDetail, useDivisionOptions, usePeople, type CustomerRef } from "@/components/crm/common";
import { blankLine, lineProblems, LinesEditor, preview, toPayload, toRows, TotalsBox, type LineRow } from "@/components/lines-editor";
import { api, ApiError, type Page } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";

type Term = { id: string; category: string; title: string; text: string; is_default: boolean };

export type QuotationPrefill = {
  customer?: CustomerRef | null;
  enquiry?: { id: string; enquiry_number: string; subject: string; site_id: string | null; contact_id: string | null; division_id: string | null; sales_person_id: string | null } | null;
  boq?: { id: string; boq_number: string; title: string; items: any[]; site_id: string | null; division_id: string | null } | null;
};

function LibraryPicker({ terms, category, onPick, label = "From library" }: { terms: Term[]; category: string | string[]; onPick: (text: string) => void; label?: string }) {
  const cats = Array.isArray(category) ? category : [category];
  const list = terms.filter((t) => cats.includes(t.category));
  if (!list.length) return null;
  return (
    <Select value="" onChange={(e) => { const t = list.find((x) => x.id === e.target.value); if (t) onPick(t.text); }} className="h-8 w-auto text-[13px]" aria-label={label}>
      <option value="">{label}…</option>
      {list.map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}
    </Select>
  );
}

export function QuotationForm({ initial, prefill, onSubmit, submitLabel, onCancel }: {
  initial?: any;                 // quotation detail when editing a draft
  prefill?: QuotationPrefill;    // when creating from an enquiry / BOQ / customer
  onSubmit: (values: Record<string, any>) => Promise<void>;
  submitLabel: string;
  onCancel?: () => void;
}) {
  const { me, can } = useAuth();
  const cur = initial?.current;
  const defaults = useQuery({ queryKey: ["/quotations/defaults"], queryFn: () => api<any>("/quotations/defaults"), select: (r) => r.data, enabled: !initial });
  const termsQ = useQuery({
    queryKey: ["/quotation-terms", "options"],
    queryFn: () => api<Page<Term>>("/quotation-terms", { params: { page_size: 200, is_active: true, sort: "sort_order" } }),
    select: (r) => r.data, enabled: can("quotation_term.read"),
  });
  const company = useQuery({ queryKey: ["/company"], queryFn: () => api<any>("/company"), select: (r) => r.data, staleTime: 10 * 60_000 });
  const gstRates: string[] = defaults.data?.gst_rates ?? ["0", "5", "12", "18", "28"];

  const enquiry = prefill?.enquiry ?? (initial?.enquiry_id ? { id: initial.enquiry_id, enquiry_number: initial.enquiry_number } as any : null);
  const [newCustomer, setNewCustomer] = useState(false);
  const [customer, setCustomer] = useState<CustomerRef | null>(initial?.customer ? { id: initial.customer.id, name: initial.customer.name, code: initial.customer.code, city: initial.customer.city } : prefill?.customer ?? null);
  const [h, setH] = useState({
    subject: initial?.subject ?? prefill?.boq?.title ?? prefill?.enquiry?.subject ?? "",
    site_id: initial?.site_id ?? prefill?.boq?.site_id ?? prefill?.enquiry?.site_id ?? "",
    contact_id: initial?.contact_id ?? prefill?.enquiry?.contact_id ?? "",
    division_id: initial?.division_id ?? prefill?.boq?.division_id ?? prefill?.enquiry?.division_id ?? "",
    sales_person_id: initial?.sales_person_id ?? prefill?.enquiry?.sales_person_id ?? "",
    quotation_date: cur?.quotation_date ?? "",
    valid_until: cur?.valid_until ?? "",
    kind_attention: cur?.kind_attention ?? "",
    intro_text: cur?.intro_text ?? "",
    payment_terms: cur?.payment_terms ?? "",
    delivery_terms: cur?.delivery_terms ?? "",
    warranty: cur?.warranty ?? "",
    technical_notes: cur?.technical_notes ?? "",
    special_discount: cur?.special_discount && Number(cur.special_discount) ? String(Number(cur.special_discount)) : "",
  });
  const [terms, setTerms] = useState<string[]>(cur?.terms ?? []);
  const [rows, setRows] = useState<LineRow[]>(() => cur ? toRows(cur.items) : prefill?.boq ? toRows(prefill.boq.items) : [blankLine()]);
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  const [seeded, setSeeded] = useState(!!initial);

  // New quotation: start from the default terms in the library.
  useEffect(() => {
    if (seeded || !defaults.data) return;
    setH((x) => ({ ...x, payment_terms: x.payment_terms || defaults.data.payment_terms || "", delivery_terms: x.delivery_terms || defaults.data.delivery_terms || "", warranty: x.warranty || defaults.data.warranty || "" }));
    setTerms((t) => (t.length ? t : defaults.data.terms ?? []));
    setSeeded(true);
  }, [defaults.data, seeded]);

  const detail = useCustomerDetail(customer?.id);
  const sales = usePeople("sales");
  const divisions = useDivisionOptions();
  const site = detail.data?.sites?.find((s: any) => s.id === h.site_id);
  const pos = site?.state_code || detail.data?.state_code || null;
  const interState = !!(pos && company.data?.state_code && pos !== company.data.state_code);
  const calc = preview(rows, interState, Number(h.special_discount) || 0, true);
  const set = (k: keyof typeof h) => (e: { target: { value: string } }) => setH({ ...h, [k]: e.target.value });
  const ownOnly = me?.permissions["quotation.update"] === "own";
  const lockedCustomer = !!enquiry || !!initial?.quotation_number;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!customer) return setError(new Error("Choose the customer."));
    if (!h.subject.trim()) return setError(new Error("Enter a subject."));
    const problem = lineProblems(rows);
    if (problem) return setError(new Error(problem));
    const n = (v: string) => (v.trim() === "" ? null : v.trim());
    setBusy(true);
    try {
      await onSubmit({
        customer_id: customer.id, enquiry_id: enquiry?.id ?? null, boq_id: initial?.boq_id ?? prefill?.boq?.id ?? null,
        subject: h.subject.trim(), site_id: n(h.site_id), contact_id: n(h.contact_id), division_id: n(h.division_id),
        sales_person_id: n(h.sales_person_id), quotation_date: n(h.quotation_date), valid_until: n(h.valid_until),
        kind_attention: n(h.kind_attention), intro_text: n(h.intro_text), payment_terms: n(h.payment_terms),
        delivery_terms: n(h.delivery_terms), warranty: n(h.warranty), technical_notes: n(h.technical_notes),
        special_discount: n(h.special_discount) ?? "0", terms: terms.map((t) => t.trim()).filter(Boolean), items: toPayload(rows),
      });
    } catch (err) {
      setError(err instanceof ApiError && err.status === 422 ? new Error(err.message || "Some values are not valid.") : err);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } finally { setBusy(false); }
  }

  const library = termsQ.data ?? [];
  return (
    <form onSubmit={submit} className="space-y-5">
      <ErrorNote error={error} />
      {cur?.last_rejection && <p className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900"><b>Returned by the approver:</b> {cur.last_rejection}</p>}
      <QuickCustomerDialog open={newCustomer} onClose={() => setNewCustomer(false)} onCreated={(c) => { setCustomer(c); setH({ ...h, site_id: "", contact_id: "" }); }} />
      <Card title="Customer & project">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Customer" required className="sm:col-span-2" hint={enquiry ? `From enquiry ${enquiry.enquiry_number}` : initial?.quotation_number ? "A numbered quotation keeps its customer." : undefined}>
            <div className="flex gap-2">
              <div className="flex-1"><CustomerPicker value={customer} disabled={lockedCustomer} onChange={(c) => { setCustomer(c); setH({ ...h, site_id: "", contact_id: "" }); }} /></div>
              {!lockedCustomer && can("customer.create") && <Button type="button" variant="secondary" icon={<UserPlus className="size-4" />} onClick={() => setNewCustomer(true)}>New</Button>}
            </div>
          </Field>
          <Field label="Subject / project" required className="sm:col-span-2"><Input value={h.subject} onChange={set("subject")} placeholder="e.g. Lightning protection for main block" /></Field>
          <Field label="Site" hint={pos ? `Place of supply: state ${pos} · ${interState ? "IGST" : "CGST + SGST"}` : undefined}>
            <Select value={h.site_id} onChange={set("site_id")} disabled={!customer}>
              <option value="">— Customer's billing address —</option>
              {detail.data?.sites?.map((s: any) => <option key={s.id} value={s.id}>{s.site_name}</option>)}
            </Select>
          </Field>
          <Field label="Contact person">
            <Select value={h.contact_id} onChange={(e) => { const c = detail.data?.contacts?.find((x: any) => x.id === e.target.value); setH({ ...h, contact_id: e.target.value, kind_attention: h.kind_attention || c?.name || "" }); }} disabled={!customer}>
              <option value="">—</option>
              {detail.data?.contacts?.map((c: any) => <option key={c.id} value={c.id}>{c.name}{c.designation ? ` · ${c.designation}` : ""}</option>)}
            </Select>
          </Field>
          <Field label="Business division">
            <Select value={h.division_id} onChange={set("division_id")}>{divisions.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</Select>
          </Field>
          <Field label="Salesperson">
            <Select value={h.sales_person_id} onChange={set("sales_person_id")}>{peopleOptions(sales.data, ownOnly ? "— Me —" : "— Not assigned —").map(([v, l]) => <option key={v} value={v}>{l}</option>)}</Select>
          </Field>
          <Field label="Quotation date" hint="Blank = today"><Input type="date" value={h.quotation_date} onChange={set("quotation_date")} /></Field>
          <Field label="Valid until" hint={`Blank = ${defaults.data?.validity_days ?? 30} days`}><Input type="date" value={h.valid_until} onChange={set("valid_until")} /></Field>
          <Field label="Kind attention" className="sm:col-span-2"><Input value={h.kind_attention} onChange={set("kind_attention")} /></Field>
        </div>
      </Card>

      <Card title="Items" actions={prefill?.boq && <span className="text-xs text-ink-500">Copied from {prefill.boq.boq_number}</span>}>
        <LinesEditor rows={rows} onChange={setRows} gstRates={gstRates} interState={interState} />
        <div className="mt-5 grid gap-4 border-t border-ink-100 pt-4 lg:grid-cols-[1fr_380px]">
          <Field label="Special discount (₹, on the whole quotation)" hint="Spread over the lines in proportion to their value, before GST." className="max-w-xs">
            <Input inputMode="decimal" className="num" value={h.special_discount} onChange={set("special_discount")} placeholder="0" />
          </Field>
          <TotalsBox interState={interState} t={{ gross: calc.gross, lineDiscount: calc.lineDiscount, special: calc.special, taxable: calc.taxable, cgst: calc.cgst, sgst: calc.sgst, igst: calc.igst, roundOff: calc.roundOff, grand: calc.grand }} />
        </div>
      </Card>

      <Card title="Commercial terms">
        <div className="grid gap-4 lg:grid-cols-3">
          {([["payment_terms", "Payment", "payment"], ["delivery_terms", "Delivery", "delivery"], ["warranty", "Warranty", "warranty"]] as const).map(([k, label, cat]) => (
            <div key={k}>
              <div className="mb-1 flex items-center justify-between gap-2"><span className="text-[13px] font-medium text-ink-700">{label}</span>
                <LibraryPicker terms={library} category={cat} onPick={(t) => setH({ ...h, [k]: t })} /></div>
              <Textarea rows={4} value={h[k]} onChange={set(k)} />
            </div>
          ))}
        </div>
      </Card>

      <Card title="Covering note & technical specifications">
        <div className="grid gap-4 lg:grid-cols-2">
          <Field label="Opening paragraph" hint="Blank = “With reference to your enquiry…, we are pleased to submit our offer as below.”"><Textarea rows={4} value={h.intro_text} onChange={set("intro_text")} /></Field>
          <Field label="Technical specifications" hint="Standards, makes, scope notes — printed after the commercial terms."><Textarea rows={4} value={h.technical_notes} onChange={set("technical_notes")} /></Field>
        </div>
      </Card>

      <Card title="Terms and conditions" actions={<div className="flex gap-2">
        <LibraryPicker terms={library} category={["general", "validity"]} onPick={(t) => setTerms([...terms, t])} label="Add from library" />
        <Button type="button" size="sm" variant="secondary" icon={<Plus className="size-3.5" />} onClick={() => setTerms([...terms, ""])}>Add clause</Button>
      </div>}>
        {terms.length === 0 ? <p className="text-sm text-ink-500"><BookOpen className="mr-1 inline size-4" />No terms. Add clauses from the library or write your own.</p> : (
          <ol className="space-y-2">
            {terms.map((t, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="w-5 pt-2 text-right text-sm text-ink-500">{i + 1}.</span>
                <Textarea rows={2} value={t} onChange={(e) => setTerms(terms.map((x, j) => (j === i ? e.target.value : x)))} className="flex-1" aria-label={`Clause ${i + 1}`} />
                <div className="flex flex-col">
                  <Button type="button" variant="ghost" size="sm" aria-label="Move up" disabled={i === 0} onClick={() => { const n = [...terms]; [n[i - 1], n[i]] = [n[i], n[i - 1]]; setTerms(n); }}><ArrowUp className="size-3.5" /></Button>
                  <Button type="button" variant="ghost" size="sm" aria-label="Move down" disabled={i === terms.length - 1} onClick={() => { const n = [...terms]; [n[i + 1], n[i]] = [n[i], n[i + 1]]; setTerms(n); }}><ArrowDown className="size-3.5" /></Button>
                </div>
                <Button type="button" variant="ghost" size="sm" aria-label="Remove clause" onClick={() => setTerms(terms.filter((_, j) => j !== i))}><Trash2 className="size-3.5 text-ink-400" /></Button>
              </li>
            ))}
          </ol>
        )}
      </Card>

      <div className="sticky bottom-0 -mx-4 flex justify-end gap-2 border-t border-ink-200 bg-white/95 px-4 py-3 backdrop-blur sm:static sm:mx-0 sm:border-0 sm:bg-transparent sm:p-0">
        {onCancel && <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>}
        <Button type="submit" loading={busy}>{submitLabel}</Button>
      </div>
    </form>
  );
}
