"use client";

import { Badge } from "@/components/ui";

type Tone = "green" | "red" | "grey" | "amber" | "blue";
export const QUOTATION_STATUSES: [string, string, Tone][] = [
  ["draft", "Draft", "grey"], ["pending_approval", "Pending approval", "amber"], ["approved", "Approved", "blue"],
  ["sent", "Sent", "blue"], ["negotiation", "Negotiation", "amber"], ["accepted", "Accepted", "green"],
  ["rejected", "Rejected", "red"], ["expired", "Expired", "grey"], ["cancelled", "Cancelled", "grey"],
];

export function QuotationStatus({ status }: { status: string }) {
  const s = QUOTATION_STATUSES.find(([v]) => v === status);
  return <Badge tone={s?.[2] ?? "grey"}>{s?.[1] ?? status}</Badge>;
}
