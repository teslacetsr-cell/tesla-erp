"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Button, ErrorNote, Field, Input, Modal, Textarea, useToast } from "@/components/ui";
import { api } from "@/lib/api/client";
import { inr } from "@/lib/format";

/** Accepted quotation → sales order: the accepted revision's lines, prices, taxes and terms are copied exactly. */
export function SalesOrderDialog({ q, open, onClose, again }: { q: any; open: boolean; onClose: () => void; again?: boolean }) {
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const [v, setV] = useState({ so_date: "", customer_po_number: "", customer_po_date: "", expected_completion: "", notes: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV({ ...v, [k]: e.target.value });
  const n = (s: string) => (s.trim() ? s.trim() : null);
  return (
    <Modal open={open} onClose={onClose} title={again ? `Place order again — ${q.display_number}` : `Sales order from ${q.display_number}`}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setBusy(true);
        try {
          const r = await api<any>(`/quotations/${q.id}/sales-order`, { body: { so_date: n(v.so_date), customer_po_number: n(v.customer_po_number),
            customer_po_date: n(v.customer_po_date), expected_completion: n(v.expected_completion), notes: n(v.notes) } });
          toast(`Sales order ${r.data.so_number} created`);
          qc.invalidateQueries({ queryKey: ["/quotations"] });
          qc.invalidateQueries({ queryKey: ["/sales-orders"] });
          onClose();
          router.push(`/sales/orders/view?id=${r.data.id}`);
        } catch (e) { setError(e); } finally { setBusy(false); }
      }}>{again ? "Place order again" : "Create sales order"}</Button></>}>
      <div className="space-y-3">
        <ErrorNote error={error} />
        {again && <p className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900">The earlier order was cancelled and stays on record. This creates a new order with a new number from the same accepted revision.</p>}
        <p className="text-sm text-ink-600">Every line, price, discount, GST and term of <b>R{q.accepted_revision_no}</b> ({inr(q.grand_total, 0)}) is copied and locked.</p>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Order date" hint="Blank = today"><Input type="date" value={v.so_date} onChange={set("so_date")} /></Field>
          <Field label="Expected completion"><Input type="date" value={v.expected_completion} onChange={set("expected_completion")} /></Field>
          <Field label="Customer PO number"><Input value={v.customer_po_number} onChange={set("customer_po_number")} /></Field>
          <Field label="Customer PO date"><Input type="date" value={v.customer_po_date} onChange={set("customer_po_date")} /></Field>
        </div>
        <Field label="Notes"><Textarea rows={2} value={v.notes} onChange={set("notes")} /></Field>
      </div>
    </Modal>
  );
}

