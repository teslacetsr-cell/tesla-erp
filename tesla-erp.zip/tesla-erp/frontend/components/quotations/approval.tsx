"use client";

import { useState } from "react";
import { CheckCircle2, Circle, Clock, XCircle } from "lucide-react";
import { Button, Field, Modal, Textarea, useToast } from "@/components/ui";
import { api } from "@/lib/api/client";
import { dateTime, inr } from "@/lib/format";

export type ApprovalReq = {
  entity_type?: string;
  id: string; entity_label: string; entity_name: string; href: string | null; amount: string; policy_name: string;
  steps: string[]; current_step: number; status: string; requested_by: string | null; requested_at: string;
  decided_at: string | null; can_decide: boolean;
  actions: { step_no: number; role_code: string; decision: string; user: string | null; comment: string | null; acted_at: string }[];
};

const role = (c: string) => c.replace(/_/g, " ").toLowerCase().replace(/\b\w/g, (x) => x.toUpperCase());

/** The chain Sales → Manager → Director with who decided what, and when. */
export function ApprovalSteps({ req }: { req: ApprovalReq }) {
  return (
    <ol className="space-y-2">
      <li className="flex items-start gap-2 text-sm">
        <CheckCircle2 className="mt-0.5 size-4 text-ink-400" />
        <span>Submitted by <b>{req.requested_by}</b> <span className="text-ink-500">· {dateTime(req.requested_at)} · {req.entity_type === "leave_request" ? "" : `${inr(req.amount, 0)}${["expense", "material_issue"].includes(req.entity_type ?? "") ? "" : " before GST"} · `}{req.policy_name}</span></span>
      </li>
      {req.steps.map((r, i) => {
        const act = [...req.actions].reverse().find((a) => a.step_no === i && a.decision !== "withdrawn");
        const current = req.status === "pending" && i === req.current_step;
        const Icon = act?.decision === "approved" ? CheckCircle2 : act?.decision === "rejected" ? XCircle : current ? Clock : Circle;
        const color = act?.decision === "approved" ? "text-emerald-600" : act?.decision === "rejected" ? "text-brand-600" : current ? "text-amber-600" : "text-ink-300";
        return (
          <li key={i} className="flex items-start gap-2 text-sm">
            <Icon className={`mt-0.5 size-4 shrink-0 ${color}`} />
            <span>
              <b>{role(r)}</b>{" "}
              {act ? <span className="text-ink-600">— {act.decision} by {act.user} · {dateTime(act.acted_at)}</span>
                : current ? <span className="text-amber-700">— waiting</span> : req.status === "withdrawn" ? <span className="text-ink-500">— withdrawn</span> : <span className="text-ink-400">— not reached</span>}
              {act?.comment && <span className="block text-ink-700">“{act.comment}”</span>}
            </span>
          </li>
        );
      })}
    </ol>
  );
}

export function DecideButtons({ req, onDone }: { req: ApprovalReq; onDone: () => void }) {
  const [mode, setMode] = useState<"approved" | "rejected" | null>(null);
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const toast = useToast();
  if (!req.can_decide) return null;
  return (
    <>
      <div className="flex flex-wrap gap-2">
        <Button onClick={() => { setMode("approved"); setComment(""); setError(null); }}>Approve</Button>
        <Button variant="danger" onClick={() => { setMode("rejected"); setComment(""); setError(null); }}>Reject</Button>
      </div>
      <Modal open={mode !== null} onClose={() => setMode(null)} title={mode === "approved" ? `Approve as ${role(req.steps[req.current_step])}` : "Reject and return to the requester"}
        footer={<><Button variant="secondary" onClick={() => setMode(null)}>Cancel</Button>
          <Button variant={mode === "rejected" ? "danger" : "primary"} loading={busy} onClick={async () => {
            if (mode === "rejected" && !comment.trim()) return setError("Say what needs to change.");
            setBusy(true);
            try {
              await api(`/approvals/${req.id}/decide`, { body: { decision: mode, comment: comment.trim() || null } });
              toast(mode === "approved" ? "Approved" : "Returned to the requester");
              setMode(null);
              onDone();
            } catch (e: any) { setError(e.message); } finally { setBusy(false); }
          }}>{mode === "approved" ? "Approve" : "Reject"}</Button></>}>
        <p className="mb-3 text-sm text-ink-700">{req.entity_name} <b>{req.entity_label}</b>{req.entity_type === "leave_request" ? "" : ` · ${inr(req.amount, 0)}${["expense", "material_issue"].includes(req.entity_type ?? "") ? "" : " before GST"}`}</p>
        <Field label={mode === "rejected" ? "Reason (required)" : "Comment (optional)"} error={error ?? undefined}>
          <Textarea rows={3} value={comment} onChange={(e) => setComment(e.target.value)} />
        </Field>
      </Modal>
    </>
  );
}
