"use client";

import Link from "next/link";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Undo2, Wallet } from "lucide-react";
import { Badge, Button, Card, EmptyState, ErrorNote, Field, Input, Modal, Pagination, Select, Spinner, Textarea, useToast } from "@/components/ui";
import { COST_HEADS, headLabel } from "@/components/costing/common";
import { istToday } from "@/components/projects/common";
import { ReasonDialog } from "@/components/purchase/common";
import { api } from "@/lib/api/client";
import { date, inr, qty } from "@/lib/format";

const SOURCE: Record<string, [string, (id: string) => string | null]> = {
  material_issue: ["Material issue", (id) => `/inventory/issues/view?id=${id}`],
  material_return: ["Material return", (id) => `/inventory/issues/view?id=${id}`],
  expense: ["Expense claim", (id) => `/finance/expenses/view?id=${id}`],
  supplier_invoice: ["Supplier bill", (id) => `/finance/bills/view?id=${id}`],
  labour_attendance: ["Staff attendance", () => null],
  manual: ["Manual entry", () => null],
};

function Money({ v, strong }: { v: string | null | undefined; strong?: boolean }) {
  return v == null ? <span className="text-ink-400">—</span> : <span className={`num ${strong ? "font-semibold" : ""} ${Number(v) < 0 ? "text-brand-700" : ""}`}>{inr(v, 0)}</span>;
}

export function CostsTab({ prj, onChanged }: { prj: any; onChanged: () => void }) {
  const qc = useQueryClient();
  const toast = useToast();
  const [page, setPage] = useState(1);
  const [head, setHead] = useState("");
  const [adding, setAdding] = useState(false);
  const [budget, setBudget] = useState(false);
  const [reversing, setReversing] = useState<string | null>(null);
  const pf = useQuery({ queryKey: ["/projects", prj.id, "profitability"], queryFn: () => api<any>(`/projects/${prj.id}/profitability`), select: (r) => r.data });
  const costs = useQuery({ queryKey: ["/projects", prj.id, "costs", page, head], queryFn: () => api<any>(`/projects/${prj.id}/costs`, { params: { page, page_size: 25, head } }) });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/projects", prj.id] }); onChanged(); };
  if (pf.isLoading || !pf.data) return <Spinner />;
  const d = pf.data;
  return (
    <div className="space-y-4">
      <div className="grid gap-3 md:grid-cols-2">
        {(["estimated", "actual"] as const).map((k) => (
          <Card key={k} title={k === "estimated" ? "Estimated (contract & budget)" : "Actual so far (billed & cost ledger)"}>
            <dl className="grid grid-cols-4 gap-2 text-sm">
              <div><dt className="text-xs text-ink-500">Revenue</dt><dd><Money v={d[k].revenue} /></dd></div>
              <div><dt className="text-xs text-ink-500">Cost</dt><dd><Money v={d[k].cost} /></dd></div>
              <div><dt className="text-xs text-ink-500">Profit</dt><dd><Money v={d[k].profit} strong /></dd></div>
              <div><dt className="text-xs text-ink-500">Margin</dt><dd className="num">{d[k].margin_pct != null ? `${d[k].margin_pct}%` : "—"}</dd></div>
            </dl>
          </Card>
        ))}
      </div>
      <Card title="Cost by head" padded={false} actions={<div className="flex gap-2">
        {d.can.budget && <Button size="sm" variant="secondary" onClick={() => setBudget(true)}>Set budget</Button>}
        {d.can.add_cost && <Button size="sm" icon={<Plus className="size-3.5" />} onClick={() => setAdding(true)}>Add cost</Button>}
      </div>}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
              <th className="px-3 py-2">Head</th><th className="px-3 py-2 text-right">Estimated</th><th className="px-3 py-2 text-right">Actual</th>
              <th className="px-3 py-2 text-right">Left in budget</th><th className="px-3 py-2">Used</th></tr></thead>
            <tbody>{d.heads.map((r: any) => {
              const used = Number(r.used_pct ?? 0);
              return (
                <tr key={r.head} className="border-b border-ink-100">
                  <td className="px-3 py-2">{headLabel(r.head)}{r.head === "material" && d.material_from_boq && <span className="ml-1 text-xs text-ink-500">(estimate from BOQ{d.uncosted_lines ? `, ${d.uncosted_lines} line(s) unpriced` : ""})</span>}</td>
                  <td className="px-3 py-2 text-right"><Money v={r.estimated} /></td>
                  <td className="px-3 py-2 text-right"><Money v={r.actual} strong /></td>
                  <td className="px-3 py-2 text-right"><Money v={r.variance} /></td>
                  <td className="w-40 px-3 py-2">{r.used_pct != null && (
                    <div className="flex items-center gap-2"><div className="h-1.5 flex-1 rounded bg-ink-100"><div className={`h-1.5 rounded ${used > 100 ? "bg-brand-600" : used > 85 ? "bg-amber-500" : "bg-emerald-600"}`} style={{ width: `${Math.min(used, 100)}%` }} /></div><span className="num text-xs">{Math.round(used)}%</span></div>
                  )}</td>
                </tr>
              );
            })}</tbody>
          </table>
        </div>
        {d.cost_to_date_pct != null && <p className="border-t border-ink-100 px-3 py-2 text-xs text-ink-500">{d.cost_to_date_pct}% of the estimated cost has been spent; work installed is {prj.financials.work_done_pct ?? 0}% of the BOQ value.</p>}
      </Card>
      <Card title="Cost ledger" padded={false} actions={
        <Select value={head} onChange={(e) => { setHead(e.target.value); setPage(1); }} className="w-40" aria-label="Cost head">
          <option value="">All heads</option>{COST_HEADS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
        </Select>}>
        {costs.isLoading ? <Spinner /> : !costs.data?.data.length ? (
          <EmptyState icon={<Wallet className="size-8" />} title="No costs yet" body="Material issues, approved expenses, supplier bills booked to the project, staff labour from attendance and manual entries appear here." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
                <th className="px-3 py-2">Date</th><th className="px-3 py-2">Head</th><th className="px-3 py-2">Details</th><th className="px-3 py-2 text-right">Amount</th><th className="px-3 py-2" /></tr></thead>
              <tbody>{costs.data.data.map((e: any) => {
                const [label, href] = SOURCE[e.source_type] ?? [e.source_type, () => null];
                const link = e.source_id ? href(e.source_id) : null;
                return (
                  <tr key={e.id} className={`border-b border-ink-100 align-top ${e.reversed || e.reverses_id ? "text-ink-500" : ""}`}>
                    <td className="whitespace-nowrap px-3 py-2">{date(e.cost_date)}</td>
                    <td className="px-3 py-2">{headLabel(e.cost_head)}</td>
                    <td className="px-3 py-2"><p>{e.description}</p>
                      <p className="text-xs text-ink-500">{link ? <Link href={link} className="text-brand-700 hover:underline">{label} {e.source_number}</Link> : `${label}${e.source_number ? ` ${e.source_number}` : ""}`}
                        {e.party ? ` · ${e.party}` : ""}{e.quantity ? ` · ${qty(e.quantity)} ${e.unit ?? ""}` : ""}{e.created_by ? ` · ${e.created_by}` : ""}
                        {e.reversed && <Badge tone="grey">reversed</Badge>}{e.reverses_id && <Badge tone="grey">reversal</Badge>}</p></td>
                    <td className="px-3 py-2 text-right"><Money v={e.amount} /></td>
                    <td className="px-3 py-2 text-right">{e.can_reverse && <Button size="sm" variant="ghost" icon={<Undo2 className="size-3.5" />} onClick={() => setReversing(e.id)}>Reverse</Button>}</td>
                  </tr>
                );
              })}</tbody>
            </table>
          </div>
        )}
        {costs.data?.meta?.total > 0 && <Pagination page={page} pageSize={costs.data.meta.page_size} total={costs.data.meta.total} onPage={setPage} />}
      </Card>
      {adding && <AddCost prj={prj} onClose={() => setAdding(false)} onSaved={() => { toast("Cost added"); refresh(); }} />}
      {budget && <BudgetDialog prj={prj} heads={d.heads} fromBoq={d.material_from_boq} onClose={() => setBudget(false)} onSaved={() => { toast("Budget saved"); refresh(); }} />}
      <ReasonDialog open={!!reversing} title="Reverse this cost entry?" label="Reason" required confirmLabel="Reverse" onClose={() => setReversing(null)}
        onSubmit={async (reason) => { await api(`/project-costs/${reversing}/reverse`, { body: { reason } }); toast("Reversed"); refresh(); }} />
    </div>
  );
}

function AddCost({ prj, onClose, onSaved }: { prj: any; onClose: () => void; onSaved: () => void }) {
  const [v, setV] = useState({ cost_head: "labour", cost_date: istToday(), amount: "", description: "", quantity: "", unit: "", party: "", reference: "" });
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  return (
    <Modal open onClose={onClose} title={`Add cost to ${prj.project_number}`}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setError(null); setBusy(true);
        try {
          await api(`/projects/${prj.id}/costs`, { body: { ...v, quantity: v.quantity.trim() || null, unit: v.unit.trim() || null, party: v.party.trim() || null, reference: v.reference.trim() || null } });
          onSaved(); onClose();
        } catch (e) { setError(e); } finally { setBusy(false); }
      }}>Add</Button></>}>
      <ErrorNote error={error} />
      <p className="mb-3 text-xs text-ink-500">For costs that don&apos;t come through the ERP elsewhere — a labour contractor&apos;s muster roll, a subcontractor paid outside a supplier bill, travel. Material comes from material issues; expenses and bills post here on their own.</p>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Head" required><Select value={v.cost_head} onChange={(e) => setV({ ...v, cost_head: e.target.value })}>{COST_HEADS.filter(([k]) => k !== "material").map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
        <Field label="Date" required><Input type="date" max={istToday()} value={v.cost_date} onChange={(e) => setV({ ...v, cost_date: e.target.value })} /></Field>
        <Field label="Amount (₹)" required><Input inputMode="decimal" className="num" value={v.amount} onChange={(e) => setV({ ...v, amount: e.target.value })} /></Field>
        <Field label="Paid to / party"><Input value={v.party} onChange={(e) => setV({ ...v, party: e.target.value })} /></Field>
        <Field label="Quantity"><Input inputMode="decimal" value={v.quantity} onChange={(e) => setV({ ...v, quantity: e.target.value })} /></Field>
        <Field label="Unit" hint="e.g. man-days"><Input value={v.unit} onChange={(e) => setV({ ...v, unit: e.target.value })} /></Field>
        <Field label="Reference" hint="bill or muster-roll no."><Input value={v.reference} onChange={(e) => setV({ ...v, reference: e.target.value })} /></Field>
        <Field label="Description" required className="sm:col-span-2"><Textarea rows={2} value={v.description} onChange={(e) => setV({ ...v, description: e.target.value })} /></Field>
      </div>
    </Modal>
  );
}

function BudgetDialog({ prj, heads, fromBoq, onClose, onSaved }: { prj: any; heads: any[]; fromBoq: boolean; onClose: () => void; onSaved: () => void }) {
  const [v, setV] = useState<Record<string, string>>(() => Object.fromEntries(heads.map((h) => [h.head, h.head === "material" && fromBoq ? "" : h.estimated ?? ""])));
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  return (
    <Modal open onClose={onClose} title={`Cost budget · ${prj.project_number}`}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={async () => {
        setError(null); setBusy(true);
        try { await api(`/projects/${prj.id}/budget`, { method: "PUT", body: Object.fromEntries(Object.entries(v).map(([k, x]) => [k, x.trim() || null])) }); onSaved(); onClose(); }
        catch (e) { setError(e); } finally { setBusy(false); }
      }}>Save</Button></>}>
      <ErrorNote error={error} />
      <p className="mb-3 text-xs text-ink-500">Leave material blank to use the BOQ estimate (approved quantities × purchase price). Blank heads have no budget.</p>
      <div className="grid gap-3 sm:grid-cols-2">
        {COST_HEADS.map(([k, l]) => <Field key={k} label={`${l} (₹)`}><Input inputMode="decimal" className="num" value={v[k] ?? ""} onChange={(e) => setV({ ...v, [k]: e.target.value })} /></Field>)}
      </div>
    </Modal>
  );
}
