"use client";

import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge, Button, Card, ErrorNote, Field, Input, Select, Textarea } from "@/components/ui";
import { istToday } from "@/components/projects/common";
import { newRow, QtyLines, qtyProblems, splitSerials, useProjectOptions, WarehouseSelect, type QtyRow } from "@/components/purchase/common";
import { api } from "@/lib/api/client";
import { qty } from "@/lib/format";

type Tone = "green" | "red" | "grey" | "amber" | "blue";
export const ISSUE_STATUSES: [string, string, Tone][] = [
  ["draft", "Draft", "grey"], ["pending_approval", "Waiting for approval", "amber"], ["posted", "Posted", "green"],
  ["cancelled", "Cancelled", "grey"],
];
export const COST_HEADS: [string, string][] = [["material", "Material"], ["labour", "Labour"], ["subcontract", "Subcontract"], ["travel", "Travel"], ["other", "Other"]];
export const headLabel = (h: string) => COST_HEADS.find(([k]) => k === h)?.[1] ?? h;
export function IssueStatus({ status }: { status: string }) {
  const s = ISSUE_STATUSES.find(([k]) => k === status);
  return <Badge tone={s?.[2] ?? "grey"}>{s?.[1] ?? status}</Badge>;
}

type Pick = { quantity: string; batch_no?: string; serials?: string };

/** Material issue (to a project) or return (from a project) form. BOQ lines first, then any other items. */
export function IssueForm({ kind, initial, projectId, onSubmit, onCancel, canSubmit = true }: {
  kind: "issue" | "return"; initial?: any; projectId?: string | null; canSubmit?: boolean;
  onSubmit: (body: any, submit: boolean) => Promise<void>; onCancel: () => void;
}) {
  const projects = useProjectOptions();
  const [h, setH] = useState({
    project_id: initial?.project?.id ?? projectId ?? "", warehouse_id: initial?.warehouse?.id ?? "",
    issue_date: initial?.issue_date ?? istToday(), issued_to: initial?.issued_to ?? "", notes: initial?.notes ?? "",
  });
  const [picks, setPicks] = useState<Record<string, Pick>>(() => {
    const m: Record<string, Pick> = {};
    for (const l of initial?.lines ?? []) {
      const key = kind === "return" ? l.item_id : l.project_boq_line_id;
      if (key) m[key] = { quantity: l.quantity, batch_no: l.batch_no ?? "", serials: (l.serial_nos ?? []).join("\n") };
    }
    return m;
  });
  const [extra, setExtra] = useState<QtyRow[]>(() => kind === "issue" ? (initial?.lines ?? []).filter((l: any) => !l.project_boq_line_id).map((l: any) =>
    newRow({ item_id: l.item_id, item_code: l.item_code, description: l.item_name, unit: l.unit, quantity: l.quantity, serial: l.serial, batch: l.batch,
      batch_no: l.batch_no ?? "", serials: (l.serial_nos ?? []).join("\n") })) : []);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<unknown>(null);
  const src = useQuery({
    queryKey: ["/projects", h.project_id, kind === "issue" ? "issuable" : "returnable", h.warehouse_id],
    queryFn: () => api<any>(`/projects/${h.project_id}/${kind === "issue" ? "issuable" : "returnable"}`, { params: kind === "issue" && h.warehouse_id ? { warehouse_id: h.warehouse_id } : {} }),
    enabled: !!h.project_id, select: (r) => r.data,
  });
  useEffect(() => {
    if (src.data?.warehouse && !h.warehouse_id) setH((x) => ({ ...x, warehouse_id: src.data.warehouse.id }));
  }, [src.data, h.warehouse_id]);
  const lines: any[] = src.data?.lines ?? [];
  const keyOf = (l: any) => (kind === "return" ? l.item_id : l.boq_line_id);
  const set = (k: string, p: Partial<Pick>) => setPicks((m) => ({ ...m, [k]: { ...(m[k] ?? { quantity: "" }), ...p } }));
  const chosen = useMemo(() => lines.filter((l) => Number(picks[keyOf(l)]?.quantity) > 0), [lines, picks]); // eslint-disable-line react-hooks/exhaustive-deps

  async function save(submit: boolean) {
    setError(null);
    if (!h.project_id) return setError(new Error("Choose the project."));
    for (const l of chosen) {
      const p = picks[keyOf(l)];
      const q = Number(p.quantity);
      if (l.serial && splitSerials(p.serials).length !== q) return setError(new Error(`${l.item_name}: enter ${q} serial number(s).`));
      if (l.batch && !p.batch_no?.trim()) return setError(new Error(`${l.item_name}: enter the batch number.`));
      if (kind === "return" && q > Number(l.net_qty)) return setError(new Error(`${l.item_name}: only ${qty(l.net_qty)} ${l.unit} was issued to this project.`));
    }
    const prob = extra.length ? qtyProblems(extra, { requireItem: true }) : null;
    if (prob) return setError(new Error(prob));
    const body = {
      project_id: h.project_id, warehouse_id: h.warehouse_id || null, issue_date: h.issue_date,
      issued_to: h.issued_to.trim() || null, notes: h.notes.trim() || null,
      lines: [
        ...chosen.map((l) => {
          const p = picks[keyOf(l)];
          return { item_id: l.item_id, quantity: p.quantity.trim(), project_boq_line_id: kind === "issue" ? l.boq_line_id : null,
            batch_no: p.batch_no?.trim() || null, serial_nos: splitSerials(p.serials) };
        }),
        ...extra.map((x) => ({ item_id: x.item_id, quantity: x.quantity.trim(), batch_no: x.batch_no?.trim() || null, serial_nos: splitSerials(x.serials) })),
      ],
    };
    if (!body.lines.length) return setError(new Error(kind === "issue" ? "Enter the quantity to issue against at least one line." : "Enter the quantity coming back for at least one item."));
    setBusy(submit ? "submit" : "draft");
    try { await onSubmit(body, submit); } catch (e) { setError(e); window.scrollTo({ top: 0, behavior: "smooth" }); } finally { setBusy(null); }
  }

  return (
    <div className="space-y-5">
      <ErrorNote error={error} />
      <Card title={kind === "issue" ? "Project and store" : "Project and receiving store"}>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Project" required>
            <Select value={h.project_id} disabled={!!initial} onChange={(e) => { setH({ ...h, project_id: e.target.value, warehouse_id: "" }); setPicks({}); }}>
              <option value="">— Choose —</option>
              {(projects.data ?? []).map((p: any) => <option key={p.id} value={p.id}>{p.project_number} · {p.name}</option>)}
            </Select>
          </Field>
          <Field label={kind === "issue" ? "From store" : "Back to store"} hint="The project's site store when it has one, else the main store.">
            <WarehouseSelect value={h.warehouse_id} onChange={(v) => setH({ ...h, warehouse_id: v })} blank="— Default —" />
          </Field>
          <Field label="Date"><Input type="date" max={istToday()} value={h.issue_date} onChange={(e) => setH({ ...h, issue_date: e.target.value })} /></Field>
          <Field label={kind === "issue" ? "Issued to (site engineer / supervisor)" : "Returned by"}><Input value={h.issued_to} onChange={(e) => setH({ ...h, issued_to: e.target.value })} /></Field>
          <Field label="Notes" className="sm:col-span-2"><Textarea rows={2} value={h.notes} onChange={(e) => setH({ ...h, notes: e.target.value })} /></Field>
        </div>
      </Card>
      {h.project_id && (
        <Card padded={false} title={kind === "issue" ? "Against the project BOQ" : "Material at the project"}>
          {src.isLoading ? <p className="p-4 text-sm text-ink-500">Loading…</p> : lines.length === 0 ? (
            <p className="p-4 text-sm text-ink-500">{kind === "issue" ? "This project's BOQ has no stock items. Add other items below." : "Nothing has been issued to this project yet."}</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
                  <th className="px-3 py-2">Item</th>
                  {kind === "issue" ? <><th className="px-3 py-2 text-right">BOQ</th><th className="px-3 py-2 text-right">Issued</th><th className="px-3 py-2 text-right">Left</th><th className="px-3 py-2 text-right">In store</th></>
                    : <><th className="px-3 py-2 text-right">Net issued</th><th className="px-3 py-2 text-right">Avg cost</th></>}
                  <th className="px-3 py-2 text-right">{kind === "issue" ? "Issue now" : "Return now"}</th>
                </tr></thead>
                <tbody>{lines.map((l) => {
                  const k = keyOf(l);
                  const p = picks[k];
                  const q = Number(p?.quantity) || 0;
                  const over = kind === "issue" && q > Number(l.left_qty);
                  const short = kind === "issue" && l.available != null && q > Number(l.available);
                  return (
                    <tr key={k} className="border-b border-ink-100 align-top">
                      <td className="px-3 py-2"><p>{l.item_name}</p><p className="text-xs text-ink-500">{l.item_code}{l.line_no ? ` · BOQ line ${l.line_no}` : ""}</p>
                        {q > 0 && (l.serial || l.batch) && (
                          <div className="mt-2 space-y-1">
                            {l.batch && <Input placeholder="Batch no." aria-label={`Batch, ${l.item_name}`} value={p?.batch_no ?? ""} onChange={(e) => set(k, { batch_no: e.target.value })} />}
                            {l.serial && <Textarea rows={2} placeholder={`${q} serial number(s)`} aria-label={`Serials, ${l.item_name}`} value={p?.serials ?? ""} onChange={(e) => set(k, { serials: e.target.value })} />}
                          </div>
                        )}
                      </td>
                      {kind === "issue" ? <>
                        <td className="num px-3 py-2 text-right">{qty(l.approved_qty)}</td>
                        <td className="num px-3 py-2 text-right">{qty(l.issued_qty)}</td>
                        <td className="num px-3 py-2 text-right font-medium">{qty(l.left_qty)}</td>
                        <td className={`num px-3 py-2 text-right ${Number(l.available) <= 0 ? "text-brand-700" : ""}`}>{l.available != null ? qty(l.available) : "—"}</td>
                      </> : <>
                        <td className="num px-3 py-2 text-right">{qty(l.net_qty)} {l.unit}</td>
                        <td className="num px-3 py-2 text-right">{l.avg_cost ?? "—"}</td>
                      </>}
                      <td className="px-3 py-2 text-right">
                        <Input inputMode="decimal" className="num ml-auto w-24 text-right" aria-label={`Quantity, ${l.item_name}`} value={p?.quantity ?? ""} onChange={(e) => set(k, { quantity: e.target.value })} />
                        {over && <p className="mt-0.5 text-[11px] text-amber-700">More than the BOQ — needs approval</p>}
                        {short && <p className="mt-0.5 text-[11px] text-brand-700">Not enough in this store</p>}
                      </td>
                    </tr>
                  );
                })}</tbody>
              </table>
            </div>
          )}
        </Card>
      )}
      {h.project_id && kind === "issue" && (
        <Card title="Other items (not in the BOQ)">
          <p className="mb-2 text-xs text-ink-500">Items outside the BOQ always go for approval before stock moves.</p>
          <QtyLines rows={extra} onChange={setExtra} tracking requireItem />
        </Card>
      )}
      <div className="flex justify-end gap-2">
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
        {kind === "issue" && <Button type="button" variant="secondary" loading={busy === "draft"} onClick={() => save(false)}>Save draft</Button>}
        {canSubmit && <Button type="button" loading={busy === "submit"} onClick={() => save(true)}>{kind === "issue" ? "Issue material" : "Post return"}</Button>}
      </div>
    </div>
  );
}
