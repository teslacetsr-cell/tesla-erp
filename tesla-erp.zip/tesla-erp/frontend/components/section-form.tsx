"use client";

import { useEffect, useState } from "react";
import { useForm, type UseFormReturn } from "react-hook-form";
import { Button, Card, Checkbox, ErrorNote, Field, Input, Select, Textarea } from "@/components/ui";
import { applyServerErrors, clean, SelectInput } from "@/components/forms";
import { ApiError } from "@/lib/api/client";
import { GST_STATES } from "@/lib/format";
import type { FieldDef } from "@/components/record-form";

export type Section = { title: string; fields: (FieldDef & { cols?: 1 | 2 | 3 | 4 })[]; columns?: 2 | 3 | 4 };

/** Full-page form made of titled sections. Server validation errors land on the matching fields. */
export function SectionForm({ sections, initial, onSubmit, submitLabel, onCancel, extra, gstinAutofill }: {
  sections: Section[];
  initial?: Record<string, any>;
  onSubmit: (values: Record<string, any>) => Promise<void>;
  submitLabel: string;
  onCancel?: () => void;
  extra?: (form: UseFormReturn<any>) => React.ReactNode;
  gstinAutofill?: boolean;
}) {
  const all = sections.flatMap((s) => s.fields);
  const defaults = Object.fromEntries(
    all.map((f) => [f.name, initial?.[f.name] ?? (f.type === "checkbox" ? (f.name === "is_active" ? true : false) : f.type === "select" ? f.options?.[0]?.[0] ?? "" : "")]),
  );
  const form = useForm({ defaultValues: defaults });
  const [error, setError] = useState<unknown>(null);
  const e = form.formState.errors as Record<string, { message?: string }>;

  const gstin = form.watch("gstin") as string | undefined;
  useEffect(() => {
    if (!gstinAutofill) return;
    const g = gstin?.toUpperCase();
    if (g && /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(g)) {
      form.setValue("state_code", g.slice(0, 2));
      if ("pan" in defaults) form.setValue("pan", g.slice(2, 12));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gstin]);

  const submit = form.handleSubmit(async (v) => {
    setError(null);
    try {
      const values = clean(v);
      if (values.state_code) values.state = GST_STATES.find(([c]) => c === values.state_code)?.[1] ?? values.state ?? null;
      await onSubmit(values);
    } catch (err) {
      applyServerErrors(form, err);
      setError(err instanceof ApiError && err.status === 422 ? new Error("Please correct the highlighted fields.") : err);
    }
  });

  return (
    <form onSubmit={submit} className="space-y-5">
      <ErrorNote error={error} />
      {extra?.(form)}
      {sections.map((s) => (
        <Card key={s.title} title={s.title}>
          <div className={s.columns === 2 ? "grid gap-4 sm:grid-cols-2" : s.columns === 4 ? "grid gap-4 sm:grid-cols-2 lg:grid-cols-4" : "grid gap-4 sm:grid-cols-2 lg:grid-cols-3"}>
            {s.fields.map((f) => {
              const reg = f.type === "select" ? ({} as ReturnType<typeof form.register>) : form.register(f.name, f.required ? { required: `${f.label} is required` } : undefined);
              const span = f.cols === 4 ? "sm:col-span-2 lg:col-span-4" : f.cols === 3 ? "sm:col-span-2 lg:col-span-3" : f.cols === 2 || f.span === 2 ? "sm:col-span-2" : "";
              if (f.type === "checkbox") return <div key={f.name} className={`flex items-end pb-2 ${span}`}><Checkbox label={f.label} {...reg} /></div>;
              return (
                <Field key={f.name} label={f.label} required={f.required} error={e[f.name]?.message} hint={f.hint} className={span}>
                  {f.type === "select" ? (
                    <SelectInput control={form.control} name={f.name as any} options={f.options ?? []} required={f.required} label={f.label} />
                  ) : f.type === "state" ? (
                    <Select {...reg}>
                      <option value="">Select state…</option>
                      {GST_STATES.map(([c, n]) => <option key={c} value={c}>{n} ({c})</option>)}
                    </Select>
                  ) : f.type === "textarea" ? (
                    <Textarea rows={3} {...reg} />
                  ) : (
                    <Input {...reg} inputMode={f.type === "number" ? "decimal" : undefined} className={f.upper ? "uppercase" : f.type === "number" ? "num" : undefined} />
                  )}
                </Field>
              );
            })}
          </div>
        </Card>
      ))}
      <div className="flex justify-end gap-2">
        {onCancel && <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>}
        <Button type="submit" loading={form.formState.isSubmitting}>{submitLabel}</Button>
      </div>
    </form>
  );
}
