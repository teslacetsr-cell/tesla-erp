"use client";

import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Plus, Trash2 } from "lucide-react";
import { Button, Card, ErrorNote, Field, Input, Select, Textarea } from "@/components/ui";
import { blankLine, lineProblems, LinesEditor, preview, toPayload, toRows, TotalsBox, type LineRow } from "@/components/lines-editor";
import { useProjectOptions, useSuppliers, useWarehouses, WarehouseSelect } from "@/components/purchase/common";
import { api, ApiError } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";

const DEFAULT_TERMS = [
  "Quote our PO number on your invoice and delivery challan.",
  "Material is subject to inspection on receipt; rejected material will be returned at your cost.",
  "Serial numbers of serial-numbered equipment must be listed on the delivery challan.",
];

/** Purchase order: supplier, deliver-to store, priced lines with GST (IGST when the supplier is in another state). */
export function PurchaseOrderForm({ initial, prefill, onSubmit, onCancel, submitLabel }: {
  initial?: any; prefill?: { pr: any } | null; onSubmit: (body: any) => Promise<void>; onCancel: () => void; submitLabel: string;
}) {
  const { can } = useAuth();
  const projects = useProjectOptions(can("project.read"));
  const suppliers = useSuppliers();
  const whs = useWarehouses();
  const pr = prefill?.pr;
  const company = useQuery({ queryKey: ["/company"], queryFn: () => api<any>("/company"), select: (r) => r.data, staleTime: 10 * 60_000 });
  const defaults = useQuery({ queryKey: ["/quotations/defaults"], queryFn: () => api<any>("/quotations/defaults"), select: (r) => r.data, enabled: can("quotation.create") });
  const gstRates: string[] = defaults.data?.gst_rates ?? ["0", "5", "12", "18", "28"];
  const [h, setH] = useState({
    supplier_id: initial?.supplier?.id ?? pr?.lines?.find((l: any) => l.suggested_supplier_id)?.suggested_supplier_id ?? "",
    contact_id: initial?.contact_id ?? "", project_id: initial?.project?.id ?? pr?.project?.id ?? "",
    warehouse_id: initial?.warehouse?.id ?? pr?.warehouse?.id ?? "", delivery_address: initial?.delivery_address ?? "",
    expected_delivery: initial?.expected_delivery ?? pr?.required_by ?? "", supplier_quote_ref: initial?.supplier_quote_ref ?? "",
    payment_terms: initial?.payment_terms ?? "", delivery_terms: initial?.delivery_terms ?? "", warranty: initial?.warranty ?? "",
    notes: initial?.notes ?? "", special_discount: initial && Number(initial.special_discount) ? String(Number(initial.special_discount)) : "",
  });
  const [terms, setTerms] = useState<string[]>(initial?.terms ?? DEFAULT_TERMS);
  const [rows, setRows] = useState<LineRow[]>(() => {
    if (initial) return toRows(initial.items);
    if (pr) return pr.lines.filter((l: any) => Number(l.remaining_qty) > 0).map((l: any) => ({
      ...blankLine(), item_id: l.item_id, description: l.description, unit: l.unit, quantity: String(Number(l.remaining_qty)),
      rate: Number(l.estimated_rate) ? String(Number(l.estimated_rate)) : "", links: { pr_line_id: l.id, project_boq_line_id: l.project_boq_line_id },
    }));
    return [blankLine()];
  });
  const sup = useQuery({ queryKey: ["/suppliers", h.supplier_id], queryFn: () => api<any>(`/suppliers/${h.supplier_id}`), select: (r) => r.data, enabled: !!h.supplier_id });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof h) => (e: { target: { value: string } }) => setH({ ...h, [k]: e.target.value });
  // default the delivery store: the project's site store, else the main store
  useEffect(() => {
    if (h.warehouse_id || !whs.data?.length) return;
    const main = whs.data.find((w) => w.code === "MAIN") ?? whs.data[0];
    setH((x) => ({ ...x, warehouse_id: main.id }));
  }, [whs.data, h.warehouse_id]);
  useEffect(() => {
    if (!initial && sup.data) setH((x) => ({ ...x, payment_terms: x.payment_terms || sup.data.payment_terms || "" }));
  }, [sup.data, initial]);
  const interState = !!(sup.data?.state_code && company.data?.state_code && sup.data.state_code !== company.data.state_code);
  const calc = preview(rows, interState, Number(h.special_discount) || 0, true);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!h.supplier_id) return setError(new Error("Choose the supplier."));
    if (!h.warehouse_id) return setError(new Error("Choose where the goods are delivered."));
    const problem = lineProblems(rows);
    if (problem) return setError(new Error(problem));
    const n = (v: string) => (v.trim() === "" ? null : v.trim());
    setBusy(true);
    try {
      await onSubmit({
        supplier_id: h.supplier_id, contact_id: n(h.contact_id), project_id: n(h.project_id), warehouse_id: h.warehouse_id,
        delivery_address: n(h.delivery_address), expected_delivery: n(h.expected_delivery), supplier_quote_ref: n(h.supplier_quote_ref),
        payment_terms: n(h.payment_terms), delivery_terms: n(h.delivery_terms), warranty: n(h.warranty), notes: n(h.notes),
        special_discount: n(h.special_discount) ?? "0", terms: terms.map((t) => t.trim()).filter(Boolean), items: toPayload(rows),
      });
    } catch (err) {
      setError(err instanceof ApiError && err.status === 422 ? new Error(err.message || "Some values are not valid.") : err);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } finally { setBusy(false); }
  }
  return (
    <form onSubmit={submit} className="space-y-5">
      <ErrorNote error={error} />
      {initial?.last_rejection && <p className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900"><b>Returned by the approver:</b> {initial.last_rejection}</p>}
      <Card title="Supplier & delivery">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Supplier" required className="sm:col-span-2" hint={sup.data?.state_code ? `${sup.data.state ?? sup.data.state_code} · ${interState ? "IGST" : "CGST + SGST"}` : undefined}>
            <Select value={h.supplier_id} onChange={(e) => setH({ ...h, supplier_id: e.target.value, contact_id: "" })}>
              <option value="">— Choose —</option>
              {(suppliers.data ?? []).map((s) => <option key={s.id} value={s.id}>{s.supplier_name}{s.city ? ` · ${s.city}` : ""}</option>)}
            </Select>
          </Field>
          <Field label="Kind attention">
            <Select value={h.contact_id} onChange={set("contact_id")} disabled={!sup.data}>
              <option value="">—</option>
              {sup.data?.contacts?.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
          </Field>
          <Field label="Supplier's quotation ref."><Input value={h.supplier_quote_ref} onChange={set("supplier_quote_ref")} /></Field>
          <Field label="Project" className="sm:col-span-2">
            <Select value={h.project_id} onChange={set("project_id")}>
              <option value="">— Not for a project —</option>
              {(projects.data ?? []).map((p) => <option key={p.id} value={p.id}>{p.project_number} · {p.name}</option>)}
            </Select>
          </Field>
          <Field label="Deliver to" required><WarehouseSelect value={h.warehouse_id} onChange={(v) => setH({ ...h, warehouse_id: v })} /></Field>
          <Field label="Delivery by"><Input type="date" value={h.expected_delivery} onChange={set("expected_delivery")} /></Field>
          <Field label="Delivery address" hint="Blank = the store's address" className="sm:col-span-2 lg:col-span-4"><Input value={h.delivery_address} onChange={set("delivery_address")} /></Field>
        </div>
      </Card>
      <Card title="Items" actions={pr && <span className="text-xs text-ink-500">From {pr.pr_number}</span>}>
        <LinesEditor rows={rows} onChange={setRows} gstRates={gstRates} interState={interState} price="purchase_price" />
        <div className="mt-5 grid gap-4 border-t border-ink-100 pt-4 lg:grid-cols-[1fr_380px]">
          <Field label="Special discount (₹, on the whole order)" className="max-w-xs"><Input inputMode="decimal" className="num" value={h.special_discount} onChange={set("special_discount")} placeholder="0" /></Field>
          <TotalsBox interState={interState} t={{ gross: calc.gross, lineDiscount: calc.lineDiscount, special: calc.special, taxable: calc.taxable, cgst: calc.cgst, sgst: calc.sgst, igst: calc.igst, roundOff: calc.roundOff, grand: calc.grand }} />
        </div>
      </Card>
      <Card title="Terms">
        <div className="grid gap-4 lg:grid-cols-3">
          <Field label="Payment" hint="Blank = the supplier's terms"><Textarea rows={3} value={h.payment_terms} onChange={set("payment_terms")} /></Field>
          <Field label="Delivery"><Textarea rows={3} value={h.delivery_terms} onChange={set("delivery_terms")} /></Field>
          <Field label="Warranty"><Textarea rows={3} value={h.warranty} onChange={set("warranty")} /></Field>
        </div>
        <div className="mt-4">
          <div className="mb-1 flex items-center justify-between"><span className="text-[13px] font-medium text-ink-700">Terms and conditions</span>
            <Button type="button" size="sm" variant="secondary" icon={<Plus className="size-3.5" />} onClick={() => setTerms([...terms, ""])}>Add clause</Button></div>
          <ol className="space-y-2">
            {terms.map((t, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="w-5 pt-2 text-right text-sm text-ink-500">{i + 1}.</span>
                <Textarea rows={1} className="flex-1" aria-label={`Clause ${i + 1}`} value={t} onChange={(e) => setTerms(terms.map((x, j) => (j === i ? e.target.value : x)))} />
                <Button type="button" variant="ghost" size="sm" aria-label="Remove clause" onClick={() => setTerms(terms.filter((_, j) => j !== i))}><Trash2 className="size-3.5 text-ink-400" /></Button>
              </li>
            ))}
          </ol>
        </div>
        <Field label="Internal notes" className="mt-4"><Textarea rows={2} value={h.notes} onChange={set("notes")} /></Field>
      </Card>
      <div className="sticky bottom-0 -mx-4 flex justify-end gap-2 border-t border-ink-200 bg-white/95 px-4 py-3 backdrop-blur sm:static sm:mx-0 sm:border-0 sm:bg-transparent sm:p-0">
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
        <Button type="submit" loading={busy}>{submitLabel}</Button>
      </div>
    </form>
  );
}
