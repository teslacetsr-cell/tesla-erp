"use client";

import { useState } from "react";
import { Plus, UserPlus, X } from "lucide-react";
import { Badge, Button, Card, ErrorNote, Field, Input, Select, Textarea } from "@/components/ui";
import { newRow, QtyLines, qtyProblems, useProjectOptions, useSuppliers, WarehouseSelect, type QtyRow } from "@/components/purchase/common";
import { useAuth } from "@/lib/auth";

type NewSupplier = { supplier_name: string; phone: string; email: string };

/** Suppliers to invite: from the supplier master, or typed in (they are added to the master on save). */
export function SupplierChooser({ chosen, onChosen, fresh, onFresh, exclude = [], emptyText = "No suppliers yet — add two or three to compare." }: {
  chosen: { id: string; name: string }[]; onChosen: (v: { id: string; name: string }[]) => void;
  fresh: NewSupplier[]; onFresh: (v: NewSupplier[]) => void; exclude?: string[]; emptyText?: string;
}) {
  const suppliers = useSuppliers();
  const { can } = useAuth();
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState<NewSupplier>({ supplier_name: "", phone: "", email: "" });
  const options = (suppliers.data ?? []).filter((s) => !chosen.some((c) => c.id === s.id) && !exclude.includes(s.id));
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        {chosen.map((s) => (
          <span key={s.id} className="inline-flex items-center gap-1 rounded-full border border-ink-200 bg-white py-1 pl-3 pr-1 text-sm">
            {s.name}
            <button type="button" className="rounded-full p-0.5 text-ink-400 hover:bg-ink-100 hover:text-ink-700" aria-label={`Remove ${s.name}`}
              onClick={() => onChosen(chosen.filter((x) => x.id !== s.id))}><X className="size-3.5" /></button>
          </span>
        ))}
        {fresh.map((s, i) => (
          <span key={`n${i}`} className="inline-flex items-center gap-1 rounded-full border border-dashed border-brand-300 bg-brand-50 py-1 pl-3 pr-1 text-sm">
            {s.supplier_name} <Badge tone="red">new</Badge>
            <button type="button" className="rounded-full p-0.5 text-ink-400 hover:bg-ink-100 hover:text-ink-700" aria-label={`Remove ${s.supplier_name}`}
              onClick={() => onFresh(fresh.filter((_, j) => j !== i))}><X className="size-3.5" /></button>
          </span>
        ))}
        {!chosen.length && !fresh.length && <span className="text-sm text-ink-500">{emptyText}</span>}
      </div>
      <div className="flex flex-col gap-2 sm:flex-row">
        <Select aria-label="Add a supplier" value="" className="sm:max-w-sm" onChange={(e) => {
          const s = options.find((x) => x.id === e.target.value);
          if (s) onChosen([...chosen, { id: s.id, name: s.supplier_name }]);
        }}>
          <option value="">Add a supplier from the master…</option>
          {options.map((s) => <option key={s.id} value={s.id}>{s.supplier_name}{s.city ? ` · ${s.city}` : ""}</option>)}
        </Select>
        {can("supplier.create") && <Button type="button" variant="secondary" icon={<UserPlus className="size-4" />} onClick={() => setAdding(!adding)}>New supplier</Button>}
      </div>
      {adding && (
        <div className="grid gap-2 rounded-md border border-ink-200 bg-ink-50/50 p-3 sm:grid-cols-[1fr_10rem_14rem_auto] sm:items-end">
          <Field label="Supplier name" required><Input value={draft.supplier_name} onChange={(e) => setDraft({ ...draft, supplier_name: e.target.value })} /></Field>
          <Field label="Phone"><Input inputMode="tel" value={draft.phone} onChange={(e) => setDraft({ ...draft, phone: e.target.value })} /></Field>
          <Field label="Email"><Input type="email" value={draft.email} onChange={(e) => setDraft({ ...draft, email: e.target.value })} /></Field>
          <Button type="button" icon={<Plus className="size-4" />} disabled={draft.supplier_name.trim().length < 2} onClick={() => {
            onFresh([...fresh, { supplier_name: draft.supplier_name.trim(), phone: draft.phone.trim(), email: draft.email.trim() }]);
            setDraft({ supplier_name: "", phone: "", email: "" }); setAdding(false);
          }}>Add</Button>
        </div>
      )}
    </div>
  );
}

export const freshPayload = (fresh: NewSupplier[]) => fresh.map((s) => ({ supplier_name: s.supplier_name, phone: s.phone || null, email: s.email || null }));

/** RFQ header, lines and suppliers. `initial` is an RFQ from the API (edit). */
export function RfqForm({ initial, onSubmit, onCancel, submitLabel }: {
  initial?: any; onSubmit: (body: any) => Promise<void>; onCancel: () => void; submitLabel: string;
}) {
  const { can } = useAuth();
  const projects = useProjectOptions(can("project.read"));
  const [h, setH] = useState({
    project_id: initial?.project?.id ?? "", warehouse_id: initial?.warehouse?.id ?? "", due_date: initial?.due_date ?? "",
    required_by: initial?.required_by ?? "", delivery_location: initial?.delivery_location ?? "", contact_person: initial?.contact_person ?? "",
    terms: initial?.terms ?? "", notes: initial?.notes ?? "", compare_on: initial?.compare_on ?? "net",
  });
  const [rows, setRows] = useState<QtyRow[]>(() => initial?.lines?.length
    ? initial.lines.map((l: any) => newRow({ item_id: l.item_id, item_code: l.item_code, description: l.description, unit: l.unit,
      quantity: String(Number(l.quantity)), extra: { id: l.id, pr_line_id: l.pr_line_id, mr_line_id: l.mr_line_id, specification: l.specification ?? "",
        required_by: l.required_by, remarks: l.remarks } }))
    : [newRow()]);
  const [chosen, setChosen] = useState<{ id: string; name: string }[]>(() => (initial?.quotations ?? []).map((q: any) => ({ id: q.supplier.id, name: q.supplier.name })));
  const [fresh, setFresh] = useState<NewSupplier[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof h) => (e: { target: { value: string } }) => setH({ ...h, [k]: e.target.value });
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const p = qtyProblems(rows);
    if (p) return setError(new Error(p));
    setBusy(true);
    try {
      await onSubmit({
        project_id: h.project_id || null, warehouse_id: h.warehouse_id || null, due_date: h.due_date || null, required_by: h.required_by || null,
        delivery_location: h.delivery_location.trim() || null, contact_person: h.contact_person.trim() || null, terms: h.terms.trim() || null,
        notes: h.notes.trim() || null, compare_on: h.compare_on,
        lines: rows.map((r) => ({ id: r.extra?.id || null, item_id: r.item_id, description: r.description.trim(), unit: r.unit || "NOS",
          quantity: r.quantity.trim(), specification: (r.extra?.specification ?? "").trim() || null, required_by: r.extra?.required_by || null,
          pr_line_id: r.extra?.pr_line_id || null, mr_line_id: r.extra?.mr_line_id || null, remarks: r.extra?.remarks || null })),
        supplier_ids: chosen.map((s) => s.id), new_suppliers: freshPayload(fresh),
      });
    } catch (err) { setError(err); window.scrollTo({ top: 0, behavior: "smooth" }); } finally { setBusy(false); }
  }
  return (
    <form onSubmit={submit} className="space-y-5">
      <ErrorNote error={error} />
      <Card title="Request for quotation">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Project" className="sm:col-span-2">
            <Select value={h.project_id} onChange={set("project_id")}>
              <option value="">— Not for a project —</option>
              {(projects.data ?? []).map((p) => <option key={p.id} value={p.id}>{p.project_number} · {p.name}</option>)}
            </Select>
          </Field>
          <Field label="Deliver to (store)"><WarehouseSelect value={h.warehouse_id} onChange={(v) => setH({ ...h, warehouse_id: v })} blank="—" /></Field>
          <Field label="Compare on">
            <Select value={h.compare_on} onChange={set("compare_on")}>
              <option value="net">Value before GST (GST credit)</option>
              <option value="total">Value including GST</option>
            </Select>
          </Field>
          <Field label="Quotes due by"><Input type="date" value={h.due_date} onChange={set("due_date")} /></Field>
          <Field label="Material needed by"><Input type="date" value={h.required_by} onChange={set("required_by")} /></Field>
          <Field label="Contact for suppliers" className="sm:col-span-2"><Input value={h.contact_person} onChange={set("contact_person")} placeholder="Name, phone, email (defaults to you)" /></Field>
          <Field label="Delivery location" className="sm:col-span-2" hint="Site or store address printed on the RFQ"><Textarea rows={2} value={h.delivery_location} onChange={set("delivery_location")} /></Field>
          <Field label="Terms for suppliers" className="sm:col-span-2"><Textarea rows={2} value={h.terms} onChange={set("terms")} placeholder="e.g. Rates F.O.R. site, test certificates with supply" /></Field>
          <Field label="Internal notes" className="sm:col-span-2 lg:col-span-4"><Input value={h.notes} onChange={set("notes")} /></Field>
        </div>
      </Card>
      <Card title="Items to be quoted">
        <QtyLines rows={rows} onChange={setRows} extraCol={(r) => (
          <Input className="h-9 w-40 text-[13px] sm:w-52" placeholder="Specification / make" aria-label="Specification" value={r.extra?.specification ?? ""}
            onChange={(e) => setRows(rows.map((x) => (x.key === r.key ? { ...x, extra: { ...x.extra, specification: e.target.value } } : x)))} />
        )} />
      </Card>
      <Card title="Suppliers to ask">
        <SupplierChooser chosen={chosen} onChosen={setChosen} fresh={fresh} onFresh={setFresh} />
      </Card>
      <div className="flex justify-end gap-2">
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
        <Button type="submit" loading={busy}>{submitLabel}</Button>
      </div>
    </form>
  );
}
