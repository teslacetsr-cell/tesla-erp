"use client";

import { useState } from "react";
import { Button, Card, ErrorNote, Field, Input, Select, Textarea } from "@/components/ui";
import { istToday } from "@/components/projects/common";
import { ADJ_REASONS, newRow, QtyLines, qtyProblems, splitSerials, WarehouseSelect, type QtyRow } from "@/components/purchase/common";
import { inr } from "@/lib/format";

/** Opening stock or a correction. Positive quantities add stock at the unit cost; negative remove at average cost. */
export function AdjustmentForm({ initial, onSubmit, onCancel, submitLabel }: {
  initial?: any; onSubmit: (body: any) => Promise<void>; onCancel: () => void; submitLabel: string;
}) {
  const [h, setH] = useState({ adjustment_date: initial?.adjustment_date ?? istToday(), warehouse_id: initial?.warehouse?.id ?? "",
    reason_type: initial?.reason_type ?? "count_correction", reason: initial?.reason ?? "" });
  const [rows, setRows] = useState<QtyRow[]>(() => initial?.lines?.map((l: any) => newRow({
    item_id: l.item.id, item_code: l.item.code, description: l.item.name, unit: l.item.unit, serial: l.item.serial, batch: l.item.batch,
    quantity: String(Number(l.quantity)), rate: l.unit_cost !== null ? String(Number(l.unit_cost)) : "", batch_no: l.batch_no ?? "",
    expiry_date: l.expiry_date ?? "", serials: l.serial_nos.join("\n") })) ?? []);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const opening = h.reason_type === "opening";
  const added = rows.reduce((n, r) => n + (Number(r.quantity) > 0 ? Number(r.quantity) * (Number(r.rate) || 0) : 0), 0);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!h.warehouse_id) return setError(new Error("Choose the warehouse."));
    if (h.reason.trim().length < 5) return setError(new Error("Explain the adjustment (at least 5 characters)."));
    const p = rows.length ? qtyProblems(rows, { requireItem: true, signed: !opening }) : null;
    if (p) return setError(new Error(p));
    setBusy(true);
    try {
      await onSubmit({ ...h, reason: h.reason.trim(), lines: rows.map((r) => ({ item_id: r.item_id, quantity: r.quantity.trim(),
        unit_cost: Number(r.quantity) > 0 && (r.rate ?? "").trim() ? r.rate!.trim() : null, batch_no: r.batch_no?.trim() || null,
        expiry_date: r.expiry_date || null, serial_nos: splitSerials(r.serials) })) });
    } catch (err) { setError(err); window.scrollTo({ top: 0, behavior: "smooth" }); } finally { setBusy(false); }
  }
  return (
    <form onSubmit={submit} className="space-y-5">
      <ErrorNote error={error} />
      {initial?.last_rejection && <p className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900"><b>Returned by the approver:</b> {initial.last_rejection}</p>}
      <Card title="Adjustment">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Warehouse" required><WarehouseSelect value={h.warehouse_id} onChange={(v) => setH({ ...h, warehouse_id: v })} blank="— Choose —" /></Field>
          <Field label="Type"><Select value={h.reason_type} onChange={(e) => setH({ ...h, reason_type: e.target.value })}>{ADJ_REASONS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          <Field label="Date"><Input type="date" max={istToday()} value={h.adjustment_date} onChange={(e) => setH({ ...h, adjustment_date: e.target.value })} /></Field>
          <Field label="Reason" required className="sm:col-span-2 lg:col-span-4"><Textarea rows={2} value={h.reason} onChange={(e) => setH({ ...h, reason: e.target.value })} placeholder="e.g. Physical count on 30 Sep: 2 air terminals short" /></Field>
        </div>
      </Card>
      <Card title="Items" actions={<span className="num text-sm text-ink-600">Added value {inr(added, 0)}</span>}>
        <p className="mb-3 text-xs text-ink-500">{opening ? "Opening stock: enter the quantity and unit cost of each item (before GST). Many items? Save the draft, then import from Excel." : "Positive quantity adds stock at the unit cost you enter; negative removes it at the current average cost."}</p>
        <QtyLines rows={rows} onChange={setRows} tracking requireItem signed={!opening} rate rateLabel="Unit cost ₹" />
      </Card>
      <div className="flex justify-end gap-2">
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
        <Button type="submit" loading={busy}>{submitLabel}</Button>
      </div>
    </form>
  );
}
