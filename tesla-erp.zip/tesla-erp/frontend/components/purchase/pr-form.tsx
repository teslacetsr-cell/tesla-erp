"use client";

import { useState } from "react";
import { Button, Card, ErrorNote, Field, Input, Select, Textarea } from "@/components/ui";
import { PRIORITY_OPTIONS } from "@/components/projects/common";
import { newRow, QtyLines, qtyProblems, useProjectOptions, useSuppliers, WarehouseSelect, type QtyRow } from "@/components/purchase/common";
import { useAuth } from "@/lib/auth";
import { inr } from "@/lib/format";

/** Purchase request: from material request lines or entered directly; approval follows the rules. */
export function PurchaseRequestForm({ initial, prefill, onSubmit, onCancel, submitLabel }: {
  initial?: any; prefill?: { mr: any } | null; onSubmit: (body: any) => Promise<void>; onCancel: () => void; submitLabel: string;
}) {
  const { can } = useAuth();
  const projects = useProjectOptions(can("project.read"));
  const suppliers = useSuppliers();
  const mr = prefill?.mr;
  const [h, setH] = useState({
    project_id: initial?.project?.id ?? mr?.project?.id ?? "", warehouse_id: initial?.warehouse?.id ?? mr?.warehouse?.id ?? "",
    required_by: initial?.required_by ?? mr?.required_by ?? "", priority: initial?.priority ?? mr?.priority ?? "normal",
    notes: initial?.notes ?? (mr ? `From ${mr.mr_number}${mr.purpose ? `: ${mr.purpose}` : ""}` : ""),
  });
  const [rows, setRows] = useState<QtyRow[]>(() => {
    if (initial) return initial.lines.map((l: any) => newRow({ item_id: l.item_id, item_code: l.item_code, description: l.description, unit: l.unit,
      quantity: String(Number(l.quantity)), rate: String(Number(l.estimated_rate)),
      extra: { mr_line_id: l.mr_line_id, mr_number: l.mr_number, project_boq_line_id: l.project_boq_line_id, suggested_supplier_id: l.suggested_supplier_id ?? "" } }));
    if (mr) return mr.lines.filter((l: any) => Number(l.remaining_qty) > 0).map((l: any) => newRow({ item_id: l.item_id, item_code: l.item_code,
      description: l.description, unit: l.unit, quantity: String(Number(l.remaining_qty)), rate: "",
      extra: { mr_line_id: l.id, mr_number: mr.mr_number, project_boq_line_id: l.project_boq_line_id, suggested_supplier_id: "" } }));
    return [newRow({ rate: "" })];
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof h) => (e: { target: { value: string } }) => setH({ ...h, [k]: e.target.value });
  const total = rows.reduce((n, r) => n + (Number(r.quantity) || 0) * (Number(r.rate) || 0), 0);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const p = qtyProblems(rows);
    if (p) return setError(new Error(p));
    setBusy(true);
    try {
      await onSubmit({
        project_id: h.project_id || null, warehouse_id: h.warehouse_id || null, required_by: h.required_by || null, priority: h.priority,
        notes: h.notes.trim() || null,
        lines: rows.map((r) => ({ item_id: r.item_id, description: r.description.trim(), unit: r.unit || "NOS", quantity: r.quantity.trim(),
          estimated_rate: (r.rate ?? "").trim() || "0", mr_line_id: r.extra?.mr_line_id || null,
          project_boq_line_id: r.extra?.project_boq_line_id || null, suggested_supplier_id: r.extra?.suggested_supplier_id || null })),
      });
    } catch (err) { setError(err); window.scrollTo({ top: 0, behavior: "smooth" }); } finally { setBusy(false); }
  }
  return (
    <form onSubmit={submit} className="space-y-5">
      <ErrorNote error={error} />
      {initial?.last_rejection && <p className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900"><b>Returned by the approver:</b> {initial.last_rejection}</p>}
      <Card title="Request">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Project" className="sm:col-span-2">
            <Select value={h.project_id} onChange={set("project_id")}>
              <option value="">— Not for a project —</option>
              {(projects.data ?? []).map((p) => <option key={p.id} value={p.id}>{p.project_number} · {p.name}</option>)}
            </Select>
          </Field>
          <Field label="Deliver to"><WarehouseSelect value={h.warehouse_id} onChange={(v) => setH({ ...h, warehouse_id: v })} blank="—" /></Field>
          <Field label="Needed by"><Input type="date" value={h.required_by} onChange={set("required_by")} /></Field>
          <Field label="Priority"><Select value={h.priority} onChange={set("priority")}>{PRIORITY_OPTIONS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          <Field label="Notes" className="sm:col-span-2 lg:col-span-3"><Textarea rows={2} value={h.notes} onChange={set("notes")} /></Field>
        </div>
      </Card>
      <Card title="Items to buy" actions={<span className="num text-sm text-ink-600">Estimated {inr(total, 0)}</span>}>
        <QtyLines rows={rows} onChange={setRows} rate extraCol={(r) => (
          <div className="flex flex-col gap-1">
            <Select className="h-9 w-44 text-[13px]" aria-label="Suggested supplier" value={r.extra?.suggested_supplier_id ?? ""}
              onChange={(e) => setRows(rows.map((x) => (x.key === r.key ? { ...x, extra: { ...x.extra, suggested_supplier_id: e.target.value } } : x)))}>
              <option value="">Supplier (optional)…</option>
              {(suppliers.data ?? []).map((s) => <option key={s.id} value={s.id}>{s.supplier_name}</option>)}
            </Select>
            {r.extra?.mr_number && <span className="text-[11px] text-ink-500">From {r.extra.mr_number}</span>}
          </div>
        )} />
        <p className="mt-3 text-xs text-ink-500">The estimated value decides who approves (Administration → Approval rules). The purchase order sets the real price.</p>
      </Card>
      <div className="flex justify-end gap-2">
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
        <Button type="submit" loading={busy}>{submitLabel}</Button>
      </div>
    </form>
  );
}
