"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, Ban, FileSpreadsheet, FileText, PencilLine, Sparkles, Trash2, Upload } from "lucide-react";
import { Badge, Button, Card, Checkbox, ErrorNote, Field, Input, Select, Textarea, useConfirm, useToast } from "@/components/ui";
import { QuoteStatus } from "@/components/purchase/rfq-common";
import { PoStatus } from "@/components/purchase/common";
import { DocumentsPanel } from "@/components/record-panels";
import { api, download } from "@/lib/api/client";
import { date, inr, qty } from "@/lib/format";

type QLine = { rfq_line_id: string; not_quoted: boolean; unit_rate: string; discount_pct: string; gst_pct: string; make: string; delivery_days: string; remarks: string };
type Head = { quote_ref: string; quote_date: string; valid_until: string; payment_terms: string; delivery_period: string; freight_included: boolean;
  freight_amount: string; warranty: string; gst_inclusive: boolean; notes: string };
export type Prefill = { header: Partial<Record<keyof Head, any>>; lines: any[]; errors: { row?: number; line_no?: number; message: string }[]; warnings: { line_no?: number; message: string }[]; source: "excel" | "ai" | "manual"; document?: { file_name: string } };

const s = (v: any) => (v === null || v === undefined ? "" : String(v));
const num = (v: string) => { const n = Number(String(v).replace(/,/g, "")); return Number.isFinite(n) ? n : 0; };
const AI_NOTE = "AI reading is not set up (ask the administrator to add ANTHROPIC_API_KEY).";

export function lineCalc(qtyV: number, l: QLine, inclusive: boolean) {
  if (l.not_quoted || l.unit_rate.trim() === "") return { taxable: 0, gst: 0 };
  const amount = qtyV * num(l.unit_rate);
  const net = amount - amount * num(l.discount_pct) / 100;
  const g = num(l.gst_pct);
  const taxable = inclusive ? net * 100 / (100 + g) : net;
  return { taxable, gst: inclusive ? net - taxable : taxable * g / 100 };
}

/** Rates grid for one supplier: manual entry, or reviewing what Excel / AI read before it is saved. */
export function QuoteEditor({ rfq, q, prefill, onSaved, onCancel }: { rfq: any; q: any; prefill?: Prefill | null; onSaved: (r: any) => void; onCancel: () => void }) {
  const toast = useToast();
  const ph = prefill?.header ?? {};
  const pick = <K extends keyof Head>(k: K, fallback: Head[K]): Head[K] => (ph[k] !== undefined && ph[k] !== null && ph[k] !== "" ? ph[k] : fallback);
  const [h, setH] = useState<Head>({
    quote_ref: pick("quote_ref", s(q.quote_ref)), quote_date: pick("quote_date", s(q.quote_date)), valid_until: pick("valid_until", s(q.valid_until)),
    payment_terms: pick("payment_terms", s(q.payment_terms)), delivery_period: pick("delivery_period", s(q.delivery_period)),
    freight_included: ph.freight_included ?? q.freight_included, freight_amount: s(ph.freight_amount ?? (Number(q.freight_amount) ? Number(q.freight_amount) : "")),
    warranty: pick("warranty", s(q.warranty)), gst_inclusive: ph.gst_inclusive ?? q.gst_inclusive, notes: s(q.notes),
  });
  const existing = Object.fromEntries((q.lines ?? []).map((x: any) => [x.rfq_line_id, x]));
  const given = Object.fromEntries((prefill?.lines ?? []).map((x: any) => [x.rfq_line_id, x]));
  const [lines, setLines] = useState<QLine[]>(() => rfq.lines.map((l: any) => {
    const x = given[l.id] ?? existing[l.id];
    return { rfq_line_id: l.id, not_quoted: x ? !!x.not_quoted : false, unit_rate: x?.unit_rate ? String(Number(x.unit_rate)) : "",
      discount_pct: x ? String(Number(x.discount_pct)) : "0", gst_pct: x ? String(Number(x.gst_pct)) : "18", make: s(x?.make),
      delivery_days: s(x?.delivery_days), remarks: s(x?.remarks) };
  }));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const setL = (i: number, patch: Partial<QLine>) => setLines(lines.map((l, j) => (j === i ? { ...l, ...patch } : l)));
  const sums = lines.reduce((t, l, i) => { const c = lineCalc(num(rfq.lines[i].quantity), l, h.gst_inclusive); return { taxable: t.taxable + c.taxable, gst: t.gst + c.gst }; }, { taxable: 0, gst: 0 });
  const freight = h.freight_included ? 0 : num(h.freight_amount);
  const warnByLine = Object.fromEntries((prefill?.warnings ?? []).filter((w) => w.line_no).map((w) => [w.line_no, w.message]));
  async function save() {
    setError(null);
    setBusy(true);
    try {
      const r = await api<any>(`/rfqs/${rfq.id}/quotations/${q.id}`, { method: "PUT", body: {
        quote_ref: h.quote_ref || null, quote_date: h.quote_date || null, valid_until: h.valid_until || null, payment_terms: h.payment_terms || null,
        delivery_period: h.delivery_period || null, freight_included: h.freight_included, freight_amount: h.freight_included ? "0" : (h.freight_amount.replace(/,/g, "") || "0"),
        warranty: h.warranty || null, gst_inclusive: h.gst_inclusive, notes: h.notes || null, source: prefill?.source ?? "manual", row_version: q.row_version,
        lines: lines.map((l) => ({ rfq_line_id: l.rfq_line_id, not_quoted: l.not_quoted || l.unit_rate.trim() === "",
          unit_rate: l.not_quoted || l.unit_rate.trim() === "" ? null : l.unit_rate.replace(/,/g, "").trim(), discount_pct: l.discount_pct.trim() || "0",
          gst_pct: l.gst_pct || "18", make: l.make.trim() || null, delivery_days: l.delivery_days.trim() ? Number(l.delivery_days) : null, remarks: l.remarks.trim() || null })),
      } });
      toast(`Quotation of ${q.supplier.name} saved`);
      onSaved(r.data);
    } catch (e) { setError(e); } finally { setBusy(false); }
  }
  const rates: string[] = rfq.gst_rates?.length ? rfq.gst_rates.map((r: string) => String(Number(r))) : ["0", "5", "12", "18", "28"];
  return (
    <div className="space-y-4 rounded-md border border-brand-200 bg-brand-50/30 p-3">
      {prefill && prefill.source !== "manual" && (
        <p className="flex items-start gap-2 rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-900">
          <AlertTriangle className="mt-0.5 size-4 shrink-0" />
          <span>{prefill.source === "ai" ? "Read by AI" : "Read from the Excel file"}{prefill.document ? ` (${prefill.document.file_name})` : ""}. Check every rate against the supplier's document, correct anything wrong, then save. Nothing is saved yet.</span>
        </p>
      )}
      {prefill?.warnings?.filter((w) => !w.line_no).map((w, i) => <p key={i} className="text-xs text-amber-800">{w.message}</p>)}
      <ErrorNote error={error} />
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Field label="Their quotation no."><Input value={h.quote_ref} onChange={(e) => setH({ ...h, quote_ref: e.target.value })} /></Field>
        <Field label="Quotation date"><Input type="date" value={h.quote_date} onChange={(e) => setH({ ...h, quote_date: e.target.value })} /></Field>
        <Field label="Valid until"><Input type="date" value={h.valid_until} onChange={(e) => setH({ ...h, valid_until: e.target.value })} /></Field>
        <Field label="Payment terms"><Input value={h.payment_terms} onChange={(e) => setH({ ...h, payment_terms: e.target.value })} /></Field>
        <Field label="Delivery period"><Input value={h.delivery_period} onChange={(e) => setH({ ...h, delivery_period: e.target.value })} placeholder="e.g. 2 weeks from PO" /></Field>
        <Field label="Warranty"><Input value={h.warranty} onChange={(e) => setH({ ...h, warranty: e.target.value })} /></Field>
        <div className="flex flex-col gap-2 pt-5">
          <Checkbox label="Freight included" checked={h.freight_included} onChange={(e) => setH({ ...h, freight_included: e.target.checked })} />
          <Checkbox label="Rates include GST" checked={h.gst_inclusive} onChange={(e) => setH({ ...h, gst_inclusive: e.target.checked })} />
        </div>
        {!h.freight_included && <Field label="Freight extra (₹)"><Input inputMode="decimal" className="num text-right" value={h.freight_amount} onChange={(e) => setH({ ...h, freight_amount: e.target.value })} /></Field>}
      </div>
      <div className="overflow-x-auto rounded-md border border-ink-200 bg-white">
        <table className="w-full min-w-[980px] text-sm">
          <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
            <th className="px-2 py-2">#</th><th className="px-2 py-2">Item</th><th className="px-2 py-2 text-right">Qty</th><th className="px-2 py-2">Unit rate ₹</th>
            <th className="px-2 py-2">Disc %</th><th className="px-2 py-2">GST %</th><th className="px-2 py-2">Make</th><th className="px-2 py-2">Days</th>
            <th className="px-2 py-2">Remarks</th><th className="px-2 py-2">Not quoted</th><th className="px-2 py-2 text-right">Value before GST</th></tr></thead>
          <tbody>{lines.map((l, i) => {
            const rl = rfq.lines[i];
            const c = lineCalc(num(rl.quantity), l, h.gst_inclusive);
            const nq = l.not_quoted;
            return (
              <tr key={l.rfq_line_id} className="border-b border-ink-100 align-top">
                <td className="px-2 py-2 text-ink-500">{rl.line_no}</td>
                <td className="px-2 py-2"><p className="max-w-[16rem] text-ink-900">{rl.description}</p>{warnByLine[rl.line_no] && <p className="text-[11px] text-amber-700">{warnByLine[rl.line_no]}</p>}</td>
                <td className="num px-2 py-2 text-right whitespace-nowrap">{qty(rl.quantity)} {rl.unit}</td>
                <td className="px-2 py-1.5"><Input inputMode="decimal" disabled={nq} className="num w-28 text-right" aria-label={`Unit rate, line ${rl.line_no}`} value={l.unit_rate} onChange={(e) => setL(i, { unit_rate: e.target.value })} /></td>
                <td className="px-2 py-1.5"><Input inputMode="decimal" disabled={nq} className="num w-16 text-right" aria-label={`Discount, line ${rl.line_no}`} value={l.discount_pct} onChange={(e) => setL(i, { discount_pct: e.target.value })} /></td>
                <td className="px-2 py-1.5"><Select disabled={nq} className="w-20" aria-label={`GST, line ${rl.line_no}`} value={String(Number(l.gst_pct))} onChange={(e) => setL(i, { gst_pct: e.target.value })}>
                  {(rates.includes(String(Number(l.gst_pct))) ? rates : [...rates, String(Number(l.gst_pct))]).map((r) => <option key={r} value={r}>{r}</option>)}</Select></td>
                <td className="px-2 py-1.5"><Input disabled={nq} className="w-28" aria-label={`Make, line ${rl.line_no}`} value={l.make} onChange={(e) => setL(i, { make: e.target.value })} /></td>
                <td className="px-2 py-1.5"><Input inputMode="numeric" disabled={nq} className="num w-16 text-right" aria-label={`Delivery days, line ${rl.line_no}`} value={l.delivery_days} onChange={(e) => setL(i, { delivery_days: e.target.value.replace(/\D/g, "") })} /></td>
                <td className="px-2 py-1.5"><Input className="w-36" aria-label={`Remarks, line ${rl.line_no}`} value={l.remarks} onChange={(e) => setL(i, { remarks: e.target.value })} /></td>
                <td className="px-2 py-2 text-center"><input type="checkbox" className="size-4 accent-brand-600" aria-label={`Not quoted, line ${rl.line_no}`} checked={nq} onChange={(e) => setL(i, { not_quoted: e.target.checked })} /></td>
                <td className="num px-2 py-2 text-right">{nq || !l.unit_rate ? <span className="text-ink-400">—</span> : inr(c.taxable)}</td>
              </tr>
            );
          })}</tbody>
          <tfoot className="text-sm">
            <tr><td colSpan={10} className="px-2 py-1 text-right text-ink-600">Value before GST</td><td className="num px-2 py-1 text-right">{inr(sums.taxable)}</td></tr>
            <tr><td colSpan={10} className="px-2 py-1 text-right text-ink-600">GST</td><td className="num px-2 py-1 text-right">{inr(sums.gst)}</td></tr>
            {freight > 0 && <tr><td colSpan={10} className="px-2 py-1 text-right text-ink-600">Freight</td><td className="num px-2 py-1 text-right">{inr(freight)}</td></tr>}
            <tr className="font-semibold"><td colSpan={10} className="px-2 py-1 text-right">Total</td><td className="num px-2 py-1 text-right">{inr(sums.taxable + sums.gst + freight)}</td></tr>
          </tfoot>
        </table>
      </div>
      <Field label="Notes"><Textarea rows={2} value={h.notes} onChange={(e) => setH({ ...h, notes: e.target.value })} /></Field>
      <div className="flex justify-end gap-2">
        <Button variant="secondary" onClick={onCancel}>Cancel</Button>
        <Button loading={busy} onClick={save}>Save quotation</Button>
      </div>
    </div>
  );
}

/** One supplier on the RFQ: outputs to send, their reply (Excel / file / AI / manual) and the attachments. */
export function QuotationCard({ rfq, q, onChanged }: { rfq: any; q: any; onChanged: () => void }) {
  const toast = useToast();
  const confirm = useConfirm();
  const can = rfq.can;
  const [mode, setMode] = useState<"view" | "edit">("view");
  const [prefill, setPrefill] = useState<Prefill | null>(null);
  const [report, setReport] = useState<Prefill | null>(null);
  const [busy, setBusy] = useState<"" | "excel" | "ai">("");
  const excelInput = useRef<HTMLInputElement>(null);
  const aiInput = useRef<HTMLInputElement>(null);
  const qc = useQueryClient();
  const docsChanged = () => qc.invalidateQueries({ queryKey: ["/documents", "vendor_quotation", q.id] });
  const code = q.supplier.code;

  async function uploadExcel(f: File | undefined) {
    if (!f) return;
    setBusy("excel"); setReport(null);
    try {
      const form = new FormData(); form.append("file", f);
      const r = await api<any>(`/rfqs/${rfq.id}/quotations/${q.id}/import`, { method: "POST", form });
      if (r.data.saved) { toast(`Rates of ${q.supplier.name} read from the Excel file and saved`); docsChanged(); onChanged(); }
      else setReport({ ...r.data, source: "excel" });
    } catch (e: any) { toast(e.message, "error"); } finally { setBusy(""); if (excelInput.current) excelInput.current.value = ""; }
  }
  async function readAi(f: File | undefined) {
    if (!f) return;
    setBusy("ai");
    try {
      const form = new FormData(); form.append("file", f);
      const r = await api<any>(`/rfqs/${rfq.id}/quotations/${q.id}/ai-read`, { method: "POST", form });
      setPrefill({ ...r.data, source: "ai" }); setMode("edit"); docsChanged();
    } catch (e: any) { toast(e.message, "error"); } finally { setBusy(""); if (aiInput.current) aiInput.current.value = ""; }
  }
  const received = q.status === "received";
  return (
    <Card title={<span className="flex flex-wrap items-center gap-2">{q.supplier.name} <QuoteStatus status={q.status} />{!q.invited && <Badge tone="blue">added later</Badge>}{q.source && <Badge>{q.source === "ai" ? "read by AI" : q.source === "excel" ? "Excel" : "manual"}</Badge>}</span>}
      actions={can.export && (
        <div className="flex flex-wrap gap-1.5">
          <Button size="sm" variant="secondary" icon={<FileText className="size-3.5" />} onClick={() => download(`/rfqs/${rfq.id}/pdf`, `RFQ-${code}.pdf`, { quotation_id: q.id }).then(onChanged).catch((e) => toast(e.message, "error"))}>RFQ PDF</Button>
          <Button size="sm" variant="secondary" icon={<FileSpreadsheet className="size-3.5" />} onClick={() => download(`/rfqs/${rfq.id}/quotations/${q.id}/template`, `RFQ-${code}.xlsx`).then(onChanged).catch((e) => toast(e.message, "error"))}>Excel form</Button>
        </div>
      )}>
      <div className="space-y-3">
        <p className="text-xs text-ink-500">{[q.supplier.code, q.supplier.city, q.supplier.phone, q.supplier.email].filter(Boolean).join(" · ")}</p>
        {received && (
          <div className="grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2 lg:grid-cols-4">
            <span><span className="text-ink-500">Ref:</span> {q.quote_ref ?? "—"}{q.quote_date ? ` · ${date(q.quote_date)}` : ""}</span>
            <span><span className="text-ink-500">Before GST:</span> <span className="num">{inr(q.taxable)}</span></span>
            <span><span className="text-ink-500">Freight:</span> {q.freight_included ? "included" : inr(q.freight_amount)}</span>
            <span className="font-medium"><span className="text-ink-500">Total:</span> <span className="num">{inr(q.grand_total)}</span></span>
            <span><span className="text-ink-500">Payment:</span> {q.payment_terms ?? "—"}</span>
            <span><span className="text-ink-500">Delivery:</span> {q.delivery_period ?? "—"}</span>
            <span><span className="text-ink-500">Valid until:</span> {date(q.valid_until)}</span>
            <span><span className="text-ink-500">Lines quoted:</span> {q.lines.filter((x: any) => !x.not_quoted).length} of {rfq.lines.length}</span>
          </div>
        )}
        {q.purchase_order && <p className="text-sm">Purchase order: <Link className="text-brand-700 hover:underline" href={`/purchase/orders/view?id=${q.purchase_order.id}`}>{q.purchase_order.po_number ?? "Draft PO"}</Link> <PoStatus status={q.purchase_order.status} /></p>}
        {can.quote && mode === "view" && (
          <div className="flex flex-wrap gap-2">
            <Button size="sm" icon={<Upload className="size-3.5" />} loading={busy === "excel"} onClick={() => excelInput.current?.click()}>Upload filled Excel form</Button>
            <Button size="sm" variant="secondary" icon={<PencilLine className="size-3.5" />} onClick={() => { setPrefill(null); setMode("edit"); }}>{received ? "Edit rates" : "Enter rates"}</Button>
            {rfq.ai_enabled
              ? <Button size="sm" variant="secondary" icon={<Sparkles className="size-3.5" />} loading={busy === "ai"} onClick={() => aiInput.current?.click()}>Read quotation with AI</Button>
              : <span className="self-center text-xs text-ink-400" title={AI_NOTE}><Sparkles className="mr-1 inline size-3" />{AI_NOTE}</span>}
            {q.status === "awaited" && <Button size="sm" variant="ghost" icon={<Ban className="size-3.5" />} onClick={async () => {
              try { await api(`/rfqs/${rfq.id}/quotations/${q.id}/decline`, { method: "POST" }); onChanged(); } catch (e: any) { toast(e.message, "error"); }
            }}>Did not quote</Button>}
            {can.add_supplier && q.status !== "received" && <Button size="sm" variant="ghost" icon={<Trash2 className="size-3.5" />} onClick={async () => {
              if (!(await confirm({ title: `Remove ${q.supplier.name}?`, body: "The supplier is taken off this RFQ.", confirmLabel: "Remove" }))) return;
              try { await api(`/rfqs/${rfq.id}/quotations/${q.id}`, { method: "DELETE" }); onChanged(); } catch (e: any) { toast(e.message, "error"); }
            }}>Remove</Button>}
            <input ref={excelInput} type="file" accept=".xlsx" className="sr-only" aria-label={`Filled Excel form of ${q.supplier.name}`} onChange={(e) => uploadExcel(e.target.files?.[0])} />
            <input ref={aiInput} type="file" accept=".pdf,.jpg,.jpeg,.png,.webp,.xlsx" className="sr-only" aria-label={`Quotation file of ${q.supplier.name} for AI`} onChange={(e) => readAi(e.target.files?.[0])} />
          </div>
        )}
        {report && (
          <div className="rounded-md border border-brand-200 bg-brand-50 p-3 text-sm">
            <p className="mb-1 font-medium text-brand-800">The Excel file has problems — nothing was saved.</p>
            <ul className="mb-2 list-disc space-y-0.5 pl-5 text-brand-800">{report.errors.map((e, i) => <li key={i}>{e.message}</li>)}</ul>
            <div className="flex gap-2">
              <Button size="sm" variant="secondary" onClick={() => { setPrefill(report); setReport(null); setMode("edit"); }}>Load into the grid and correct</Button>
              <Button size="sm" variant="ghost" onClick={() => setReport(null)}>Dismiss</Button>
            </div>
          </div>
        )}
        {mode === "edit" && <QuoteEditor rfq={rfq} q={q} prefill={prefill} onCancel={() => { setMode("view"); setPrefill(null); }}
          onSaved={() => { setMode("view"); setPrefill(null); onChanged(); }} />}
        {received && mode === "view" && (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <thead><tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
                <th className="px-2 py-1.5">#</th><th className="px-2 py-1.5">Item</th><th className="px-2 py-1.5 text-right">Rate</th><th className="px-2 py-1.5 text-right">Disc %</th>
                <th className="px-2 py-1.5 text-right">GST %</th><th className="px-2 py-1.5">Make</th><th className="px-2 py-1.5 text-right">Value before GST</th></tr></thead>
              <tbody>{rfq.lines.map((l: any) => {
                const x = q.lines.find((y: any) => y.rfq_line_id === l.id);
                return (
                  <tr key={l.id} className="border-b border-ink-100">
                    <td className="px-2 py-1.5 text-ink-500">{l.line_no}</td><td className="px-2 py-1.5">{l.description}</td>
                    {!x || x.not_quoted ? <td colSpan={5} className="px-2 py-1.5 text-ink-400">not quoted{x?.remarks ? ` — ${x.remarks}` : ""}</td> : <>
                      <td className="num px-2 py-1.5 text-right">{inr(x.unit_rate)}</td><td className="num px-2 py-1.5 text-right">{Number(x.discount_pct) || ""}</td>
                      <td className="num px-2 py-1.5 text-right">{Number(x.gst_pct)}</td><td className="px-2 py-1.5">{x.make ?? ""}</td>
                      <td className="num px-2 py-1.5 text-right">{inr(x.taxable)}</td></>}
                  </tr>
                );
              })}</tbody>
            </table>
          </div>
        )}
        <DocumentsPanel entityType="vendor_quotation" entityId={q.id} canEdit={!!can.quote} defaultCategory="quotation" />
      </div>
    </Card>
  );
}
