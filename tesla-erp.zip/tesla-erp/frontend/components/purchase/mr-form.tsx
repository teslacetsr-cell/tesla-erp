"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button, Card, ErrorNote, Field, Input, Select, Textarea } from "@/components/ui";
import { PRIORITY_OPTIONS } from "@/components/projects/common";
import { newRow, QtyLines, qtyProblems, useProjectOptions, WarehouseSelect, type QtyRow } from "@/components/purchase/common";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";

/** Material request: what the site or store needs, optionally against project BOQ lines. */
export function MaterialRequestForm({ initial, projectId, onSubmit, onCancel, submitLabel }: {
  initial?: any; projectId?: string | null; onSubmit: (body: any) => Promise<void>; onCancel: () => void; submitLabel: string;
}) {
  const { can } = useAuth();
  const projects = useProjectOptions(can("project.read"));
  const [h, setH] = useState({
    project_id: initial?.project?.id ?? projectId ?? "", warehouse_id: initial?.warehouse?.id ?? "", required_by: initial?.required_by ?? "",
    priority: initial?.priority ?? "normal", purpose: initial?.purpose ?? "",
  });
  const [rows, setRows] = useState<QtyRow[]>(() => initial?.lines?.map((l: any) => newRow({
    item_id: l.item_id, item_code: l.item_code, description: l.description, unit: l.unit, quantity: String(Number(l.quantity)),
    extra: { project_boq_line_id: l.project_boq_line_id ?? "" }, remarks: l.remarks ?? "" })) ?? [newRow()]);
  const boq = useQuery({ queryKey: ["/projects", h.project_id, "boq"], queryFn: () => api<any>(`/projects/${h.project_id}/boq`), select: (r) => r.data as any[], enabled: !!h.project_id });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof h) => (e: { target: { value: string } }) => setH({ ...h, [k]: e.target.value });
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const p = qtyProblems(rows);
    if (p) return setError(new Error(p));
    setBusy(true);
    try {
      await onSubmit({
        project_id: h.project_id || null, warehouse_id: h.warehouse_id || null, required_by: h.required_by || null, priority: h.priority,
        purpose: h.purpose.trim() || null,
        lines: rows.map((r) => ({ item_id: r.item_id, description: r.description.trim(), unit: r.unit || "NOS", quantity: r.quantity.trim(),
          project_boq_line_id: r.extra?.project_boq_line_id || null, remarks: r.remarks?.trim() || null })),
      });
    } catch (err) { setError(err); window.scrollTo({ top: 0, behavior: "smooth" }); } finally { setBusy(false); }
  }
  return (
    <form onSubmit={submit} className="space-y-5">
      <ErrorNote error={error} />
      <Card title="Request">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Project" className="sm:col-span-2">
            <Select value={h.project_id} onChange={set("project_id")}>
              <option value="">— Not for a project (store stock) —</option>
              {(projects.data ?? []).map((p) => <option key={p.id} value={p.id}>{p.project_number} · {p.name}</option>)}
            </Select>
          </Field>
          <Field label="Deliver to" hint={h.project_id ? "Blank = the project's site store" : undefined}>
            <WarehouseSelect value={h.warehouse_id} onChange={(v) => setH({ ...h, warehouse_id: v })} blank="—" />
          </Field>
          <Field label="Needed by"><Input type="date" value={h.required_by} onChange={set("required_by")} /></Field>
          <Field label="Priority"><Select value={h.priority} onChange={set("priority")}>{PRIORITY_OPTIONS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          <Field label="Purpose / notes" className="sm:col-span-2 lg:col-span-3"><Textarea rows={2} value={h.purpose} onChange={set("purpose")} /></Field>
        </div>
      </Card>
      <Card title="Items needed">
        <QtyLines rows={rows} onChange={setRows} extraCol={h.project_id && boq.data?.length ? (r) => (
          <Select className="h-9 w-44 text-[13px]" aria-label="Project BOQ line" value={r.extra?.project_boq_line_id ?? ""}
            onChange={(e) => setRows(rows.map((x) => (x.key === r.key ? { ...x, extra: { ...x.extra, project_boq_line_id: e.target.value } } : x)))}>
            <option value="">BOQ line…</option>
            {boq.data!.map((b) => <option key={b.id} value={b.id}>{b.line_no}. {b.description.slice(0, 40)}</option>)}
          </Select>
        ) : undefined} />
      </Card>
      <div className="flex justify-end gap-2">
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
        <Button type="submit" loading={busy}>{submitLabel}</Button>
      </div>
    </form>
  );
}
