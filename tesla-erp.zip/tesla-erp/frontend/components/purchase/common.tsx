"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PackageSearch, Plus, ShieldCheck, Trash2 } from "lucide-react";
import { Badge, Button, Card, Field, Input, Modal, Select, Textarea } from "@/components/ui";
import { ItemSearch, Popover, type ItemHit } from "@/components/lines-editor";
import { ApprovalSteps, DecideButtons } from "@/components/quotations/approval";
import { api, type Page } from "@/lib/api/client";
import { titleCase } from "@/lib/format";

type Tone = "green" | "red" | "grey" | "amber" | "blue";
export const MR_STATUSES: [string, string, Tone][] = [
  ["draft", "Draft", "grey"], ["submitted", "Submitted", "amber"], ["in_progress", "In progress", "blue"],
  ["closed", "Closed", "green"], ["rejected", "Rejected", "red"], ["cancelled", "Cancelled", "grey"],
];
export const PR_STATUSES: [string, string, Tone][] = [
  ["draft", "Draft", "grey"], ["pending_approval", "Pending approval", "amber"], ["approved", "Approved", "blue"],
  ["partially_ordered", "Partly ordered", "blue"], ["ordered", "Ordered", "green"], ["closed", "Closed", "grey"],
  ["cancelled", "Cancelled", "grey"],
];
export const PO_STATUSES: [string, string, Tone][] = [
  ["draft", "Draft", "grey"], ["pending_approval", "Pending approval", "amber"], ["approved", "Approved", "blue"],
  ["sent", "Sent", "blue"], ["partially_received", "Partly received", "amber"], ["received", "Received", "green"],
  ["closed", "Closed", "grey"], ["cancelled", "Cancelled", "grey"],
];
export const TRANSFER_STATUSES: [string, string, Tone][] = [["draft", "Draft", "grey"], ["posted", "Posted", "green"], ["cancelled", "Cancelled", "grey"]];
export const ADJ_STATUSES: [string, string, Tone][] = [
  ["draft", "Draft", "grey"], ["pending_approval", "Pending approval", "amber"], ["posted", "Posted", "green"], ["cancelled", "Cancelled", "grey"],
];
export const ADJ_REASONS: [string, string][] = [
  ["opening", "Opening stock"], ["count_correction", "Stock count correction"], ["damage", "Damaged"], ["loss", "Lost / stolen"],
  ["found", "Found / excess"], ["other", "Other"],
];
export const STOCK_STATUS: Record<string, [string, Tone]> = { ok: ["In stock", "green"], reorder: ["Reorder", "amber"], low: ["Below minimum", "red"], out: ["Out of stock", "red"] };
export const TXN_TYPES: Record<string, string> = {
  opening: "Opening", grn: "GRN", transfer_in: "Transfer in", transfer_out: "Transfer out", adjustment_in: "Adjustment +",
  adjustment_out: "Adjustment −", issue: "Issue", return: "Return",
};

function pick(set: [string, string, Tone][], v: string) {
  const s = set.find(([k]) => k === v);
  return <Badge tone={s?.[2] ?? "grey"}>{s?.[1] ?? titleCase(v)}</Badge>;
}
export const MrStatus = ({ status }: { status: string }) => pick(MR_STATUSES, status);
export const PrStatus = ({ status }: { status: string }) => pick(PR_STATUSES, status);
export const PoStatus = ({ status }: { status: string }) => pick(PO_STATUSES, status);
export const TransferStatus = ({ status }: { status: string }) => pick(TRANSFER_STATUSES, status);
export const AdjStatus = ({ status }: { status: string }) => pick(ADJ_STATUSES, status);
export function StockBadge({ status }: { status: string }) {
  const [l, t] = STOCK_STATUS[status] ?? [status, "grey" as Tone];
  return <Badge tone={t}>{l}</Badge>;
}

export function useWarehouses() {
  return useQuery({
    queryKey: ["/warehouses", "options"],
    queryFn: () => api<Page<any>>("/warehouses", { params: { page_size: 200, is_active: true } }),
    select: (r) => r.data as { id: string; code: string; name: string; warehouse_type: string }[],
    staleTime: 60_000,
  });
}

export function WarehouseSelect({ value, onChange, blank, exclude, ariaLabel }: { value: string; onChange: (v: string) => void; blank?: string; exclude?: string; ariaLabel?: string }) {
  const whs = useWarehouses();
  return (
    <Select value={value} onChange={(e) => onChange(e.target.value)} aria-label={ariaLabel}>
      {blank !== undefined && <option value="">{blank}</option>}
      {(whs.data ?? []).filter((w) => w.id !== exclude).map((w) => <option key={w.id} value={w.id}>{w.name}{w.warehouse_type === "site" ? " (site)" : ""}</option>)}
    </Select>
  );
}

export function useSuppliers() {
  return useQuery({
    queryKey: ["/suppliers", "options"],
    queryFn: () => api<Page<any>>("/suppliers", { params: { page_size: 200, status: "active", sort: "supplier_name" } }),
    select: (r) => r.data as any[],
    staleTime: 60_000,
  });
}

/* ------------------------------------------------------------------ simple quantity lines (MR, PR, transfer, adjustment) */
export type QtyRow = {
  key: string; item_id: string | null; item_code?: string | null; description: string; unit: string; quantity: string;
  rate?: string; batch_no?: string; expiry_date?: string; serials?: string; serial?: boolean; batch?: boolean;
  remarks?: string; extra?: Record<string, any>;
};
let n = 0;
export const newRow = (p: Partial<QtyRow> = {}): QtyRow => ({ key: `q${Date.now().toString(36)}${(n++).toString(36)}`, item_id: null, description: "", unit: "NOS", quantity: "", ...p });
export const rowFromItem = (i: ItemHit, rateFrom?: "purchase_price"): Partial<QtyRow> => ({
  item_id: i.id, item_code: i.item_code, description: i.item_name, unit: i.unit, serial: !!i.serial_number_required, batch: !!i.batch_required,
  ...(rateFrom ? { rate: i.purchase_price ? String(Number(i.purchase_price)) : "" } : {}),
});
export const splitSerials = (s?: string) => (s ?? "").split(/[\n,;]+/).map((x) => x.trim()).filter(Boolean);

export function QtyLines({ rows, onChange, rate, rateLabel = "Est. rate ₹", tracking, requireItem, signed, extraCol }: {
  rows: QtyRow[]; onChange: (r: QtyRow[]) => void; rate?: boolean; rateLabel?: string; tracking?: boolean; requireItem?: boolean;
  signed?: boolean; extraCol?: (r: QtyRow) => React.ReactNode;
}) {
  const [picker, setPicker] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const set = (key: string, patch: Partial<QtyRow>) => onChange(rows.map((r) => (r.key === key ? { ...r, ...patch } : r)));
  return (
    <div className="space-y-2">
      {rows.length === 0 && <p className="py-4 text-center text-sm text-ink-500">No lines yet.</p>}
      {rows.map((r, i) => (
        <div key={r.key} className="rounded-md border border-ink-200 p-2">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-[1.5rem_minmax(12rem,1fr)_6rem_5rem_auto] sm:items-start">
            <span className="hidden pt-2 text-xs text-ink-500 sm:block">{i + 1}</span>
            <div className="relative col-span-2 sm:col-span-1">
              <div className="flex gap-1">
                <Input value={r.description} readOnly={requireItem} placeholder={requireItem ? "Pick an item →" : "Item or description"} aria-label={`Line ${i + 1} description`}
                  onChange={(e) => set(r.key, { description: e.target.value, ...(requireItem ? {} : {}) })} onClick={() => requireItem && setPicker(r.key)} />
                <Button type="button" variant="ghost" size="sm" className="h-9 shrink-0" aria-label="Pick from item master" onClick={() => setPicker(picker === r.key ? null : r.key)}><PackageSearch className="size-4" /></Button>
              </div>
              <Popover open={picker === r.key} onClose={() => setPicker(null)}>
                <ItemSearch autoFocus onPick={(it) => { set(r.key, rowFromItem(it, rate ? "purchase_price" : undefined)); setPicker(null); }} />
              </Popover>
              <p className="mt-0.5 text-[11px] text-ink-400">{r.item_code ? `${r.item_code}${r.serial ? " · serial-numbered" : ""}${r.batch ? " · batch-tracked" : ""}` : requireItem ? "" : "Free text (not in the item master)"}</p>
            </div>
            <label className="block"><span className="block text-[11px] text-ink-500 sm:hidden">Qty</span>
              <Input inputMode="decimal" className="num text-right" aria-label={`Quantity, line ${i + 1}`} value={r.quantity} placeholder={signed ? "+ / −" : ""} onChange={(e) => set(r.key, { quantity: e.target.value })} /></label>
            <label className="block"><span className="block text-[11px] text-ink-500 sm:hidden">Unit</span>
              <Input value={r.unit} readOnly={!!r.item_id} aria-label={`Unit, line ${i + 1}`} onChange={(e) => set(r.key, { unit: e.target.value.toUpperCase() })} /></label>
            <div className="col-span-2 flex items-start justify-end gap-2 sm:col-span-1">
              {rate && (
                <label className="block w-28"><span className="block text-[11px] text-ink-500 sm:hidden">{rateLabel}</span>
                  <Input inputMode="decimal" className="num text-right" aria-label={`${rateLabel}, line ${i + 1}`} placeholder={rateLabel} value={r.rate ?? ""} onChange={(e) => set(r.key, { rate: e.target.value })} /></label>
              )}
              {extraCol?.(r)}
              <Button type="button" variant="ghost" size="sm" className="h-9" aria-label="Delete line" onClick={() => onChange(rows.filter((x) => x.key !== r.key))}><Trash2 className="size-3.5 text-ink-400" /></Button>
            </div>
          </div>
          {tracking && (r.serial || r.batch) && (
            <div className="mt-2 grid gap-2 sm:ml-8 sm:grid-cols-3">
              {r.batch && <Input placeholder="Batch no." aria-label={`Batch, line ${i + 1}`} value={r.batch_no ?? ""} onChange={(e) => set(r.key, { batch_no: e.target.value })} />}
              {r.batch && <Input type="date" aria-label={`Expiry, line ${i + 1}`} value={r.expiry_date ?? ""} onChange={(e) => set(r.key, { expiry_date: e.target.value })} />}
              {r.serial && (
                <label className="sm:col-span-3"><span className="text-[11px] text-ink-500">Serial numbers — one per line or comma-separated ({splitSerials(r.serials).length} of {Math.abs(Number(r.quantity) || 0)})</span>
                  <Textarea rows={2} aria-label={`Serial numbers, line ${i + 1}`} value={r.serials ?? ""} onChange={(e) => set(r.key, { serials: e.target.value })} /></label>
              )}
            </div>
          )}
        </div>
      ))}
      <div className="relative flex flex-wrap gap-2">
        {!requireItem && <Button type="button" size="sm" variant="secondary" icon={<Plus className="size-3.5" />} onClick={() => onChange([...rows, newRow()])}>Add line</Button>}
        <Button type="button" size="sm" variant="secondary" icon={<PackageSearch className="size-3.5" />} onClick={() => setAdding(!adding)}>Add from item master</Button>
        <Popover open={adding} onClose={() => setAdding(false)}>
          <ItemSearch autoFocus onPick={(it) => { onChange([...rows, newRow(rowFromItem(it, rate ? "purchase_price" : undefined))]); setAdding(false); }} />
        </Popover>
      </div>
    </div>
  );
}

export function qtyProblems(rows: QtyRow[], opts: { requireItem?: boolean; signed?: boolean } = {}): string | null {
  if (!rows.length) return "Add at least one line.";
  for (const [i, r] of rows.entries()) {
    if (opts.requireItem && !r.item_id) return `Line ${i + 1}: pick the item from the item master.`;
    if (!r.description.trim()) return `Line ${i + 1}: enter the item.`;
    const q = Number(r.quantity);
    if (!r.quantity.trim() || Number.isNaN(q) || q === 0 || (!opts.signed && q < 0)) return `Line ${i + 1}: enter the quantity.`;
    if (r.serial && q > 0 && splitSerials(r.serials).length !== Math.abs(q) && opts.requireItem) return `Line ${i + 1}: enter ${Math.abs(q)} serial number(s).`;
  }
  return null;
}

/* ------------------------------------------------------------------ approvals & reasons */
export function ApprovalCard({ approval, onDone }: { approval: any; onDone: () => void }) {
  if (!approval) return null;
  return (
    <Card className="mb-4 border-amber-300" title={<span className="flex items-center gap-2"><ShieldCheck className="size-4 text-amber-600" /> Waiting for approval · step {approval.current_step + 1} of {approval.steps.length}</span>}>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <ApprovalSteps req={approval} />
        <DecideButtons req={approval} onDone={onDone} />
      </div>
    </Card>
  );
}

export function ApprovalHistory({ approvals }: { approvals: any[] }) {
  if (!approvals?.length) return <Card><p className="text-sm text-ink-500">No approvals yet. Rules are in Administration → Approval rules.</p></Card>;
  return (
    <div className="space-y-3">
      {approvals.map((a) => (
        <Card key={a.id} title={<span className="flex items-center gap-2">{a.policy_name} <Badge tone={a.status === "approved" ? "green" : a.status === "rejected" ? "red" : a.status === "pending" ? "amber" : "grey"}>{a.status}</Badge></span>}>
          <ApprovalSteps req={a} />
        </Card>
      ))}
    </div>
  );
}

export function ReasonDialog({ open, title, label, required, confirmLabel, onClose, onSubmit }: {
  open: boolean; title: string; label: string; required?: boolean; confirmLabel: string; onClose: () => void; onSubmit: (reason: string) => Promise<void>;
}) {
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  return (
    <Modal open={open} onClose={onClose} title={title}
      footer={<><Button variant="secondary" onClick={onClose}>Back</Button><Button loading={busy} onClick={async () => {
        if (required && !text.trim()) return setError("This is required.");
        setBusy(true);
        try { await onSubmit(text.trim()); setText(""); onClose(); } catch (e: any) { setError(e.message); } finally { setBusy(false); }
      }}>{confirmLabel}</Button></>}>
      <Field label={label} error={error ?? undefined}><Textarea rows={3} value={text} onChange={(e) => setText(e.target.value)} /></Field>
    </Modal>
  );
}

export function useProjectOptions(enabled = true) {
  return useQuery({
    queryKey: ["/projects", "options"],
    queryFn: () => api<Page<any>>("/projects", { params: { page_size: 200, open_only: true } }),
    select: (r) => r.data as any[],
    enabled,
    staleTime: 60_000,
  });
}
