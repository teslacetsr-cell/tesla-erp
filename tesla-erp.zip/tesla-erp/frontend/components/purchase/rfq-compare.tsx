"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import clsx from "clsx";
import { FileSpreadsheet, FileText, PackagePlus, Save, Sparkles, Trophy } from "lucide-react";
import { Badge, Button, Card, EmptyState, ErrorNote, Field, Input, Modal, Spinner, useToast } from "@/components/ui";
import { WarehouseSelect } from "@/components/purchase/common";
import { api, download } from "@/lib/api/client";
import { date, inr, qty } from "@/lib/format";

const AI_NOTE = "AI reading is not set up (ask the administrator to add ANTHROPIC_API_KEY).";

/** Lines × suppliers with L1 per line and overall, the buyer's choice per line, exports and purchase orders. */
export function ComparisonPanel({ rfq, onChanged }: { rfq: any; onChanged: () => void }) {
  const toast = useToast();
  const qc = useQueryClient();
  const key = ["/rfqs", rfq.id, "comparison", rfq.row_version];
  const { data: cmp, isLoading, error } = useQuery({ queryKey: key, queryFn: () => api<any>(`/rfqs/${rfq.id}/comparison`), select: (r) => r.data });
  const [sel, setSel] = useState<Record<string, string>>({});
  const [remarks, setRemarks] = useState<Record<string, string>>({});
  const [common, setCommon] = useState("");
  const [busy, setBusy] = useState<"" | "save" | "ai">("");
  const [err, setErr] = useState<unknown>(null);
  const [summary, setSummary] = useState<string | null>(null);
  const [poOpen, setPoOpen] = useState(false);
  useEffect(() => {
    if (!cmp) return;
    setSel(Object.fromEntries(cmp.lines.map((l: any) => [l.id, l.selected_quotation_id ?? ""])));
    setRemarks(Object.fromEntries(cmp.lines.map((l: any) => [l.id, l.selection_remark ?? ""])));
  }, [cmp]);
  if (isLoading) return <Spinner />;
  if (error || !cmp) return <ErrorNote error={error} />;
  if (!cmp.suppliers.length) return <Card><EmptyState title="No quotation recorded yet" body="Record the suppliers' rates on the Vendor quotations tab; the comparison builds itself." /></Card>;
  const editable = !!rfq.can.compare;
  const net = cmp.rfq.compare_on === "net";
  const sups = cmp.suppliers;
  const name = Object.fromEntries(sups.map((s: any) => [s.quotation_id, s.supplier.name]));
  const notL1 = (l: any) => !!sel[l.id] && !l.l1.includes(sel[l.id]);
  // live totals of the current (unsaved) choice
  let chosenValue = 0;
  const chosenSup = new Set<string>();
  for (const l of cmp.lines) {
    const c = sel[l.id] && l.cells[sel[l.id]];
    if (c) { chosenValue += Number(net ? c.taxable : c.total); chosenSup.add(sel[l.id]); }
  }
  for (const s of sups) if (chosenSup.has(s.quotation_id) && !s.freight_included) chosenValue += Number(s.freight_amount);
  const lowTotal = Math.min(...sups.filter((s: any) => s.rank === 1).map((s: any) => Number(s.basis_total)));

  function awardAll(qid: string) {
    setSel(Object.fromEntries(cmp.lines.map((l: any) => [l.id, l.cells[qid] ? qid : sel[l.id] ?? ""])));
  }
  async function save() {
    setErr(null);
    const missing = cmp.lines.filter((l: any) => notL1(l) && !(remarks[l.id] ?? "").trim() && !common.trim());
    if (missing.length) return setErr(new Error(`Give the reason for not choosing the lowest (L1) quotation on line ${missing.map((l: any) => l.line_no).join(", ")}.`));
    setBusy("save");
    try {
      await api(`/rfqs/${rfq.id}/selection`, { method: "PUT", body: { row_version: rfq.row_version, lines: cmp.lines.map((l: any) => ({
        rfq_line_id: l.id, quotation_id: sel[l.id] || null,
        remark: (remarks[l.id] ?? "").trim() || (notL1(l) ? common.trim() : "") || null })) } });
      toast("Supplier choice saved");
      onChanged();
    } catch (e) { setErr(e); } finally { setBusy(""); }
  }
  async function aiSummary() {
    setBusy("ai");
    try { setSummary((await api<any>(`/rfqs/${rfq.id}/ai-summary`, { method: "POST" })).data.text); }
    catch (e: any) { toast(e.message, "error"); } finally { setBusy(""); }
  }
  const dl = (path: string, name: string) => download(path, name).catch((e) => toast(e.message, "error"));
  const th = "px-2 py-2 text-left text-xs font-medium uppercase tracking-wide text-ink-500";
  const sticky = "sticky left-0 z-10 bg-white";
  return (
    <div className="space-y-4">
      <Card title={<span className="flex items-center gap-2"><Trophy className="size-4 text-emerald-600" /> Comparison · L1 on value {net ? "before GST" : "including GST"}</span>}
        actions={<div className="flex flex-wrap gap-1.5">
          {rfq.can.export && <Button size="sm" variant="secondary" icon={<FileSpreadsheet className="size-3.5" />} onClick={() => dl(`/rfqs/${rfq.id}/comparison/xlsx`, "comparison.xlsx")}>Excel</Button>}
          {rfq.can.export && <Button size="sm" variant="secondary" icon={<FileText className="size-3.5" />} onClick={() => dl(`/rfqs/${rfq.id}/comparison/pdf`, "comparison.pdf")}>PDF</Button>}
          {rfq.ai_enabled ? (rfq.can.ai && <Button size="sm" variant="secondary" icon={<Sparkles className="size-3.5" />} loading={busy === "ai"} onClick={aiSummary}>AI summary</Button>)
            : <span className="self-center text-xs text-ink-400" title={AI_NOTE}>AI summary: not set up</span>}
        </div>}>
        <div className="grid gap-3 text-sm sm:grid-cols-3">
          <div><p className="text-xs uppercase tracking-wide text-ink-500">Your choice</p><p className="num text-lg font-semibold">{inr(chosenValue)}</p></div>
          <div><p className="text-xs uppercase tracking-wide text-ink-500">Sum of L1 per line</p><p className="num text-lg">{inr(cmp.l1_value)}</p></div>
          <div><p className="text-xs uppercase tracking-wide text-ink-500">Saving vs last purchase prices</p><p className={clsx("num text-lg", Number(cmp.savings_vs_last) < 0 && "text-brand-700")}>{inr(cmp.savings_vs_last)}</p></div>
        </div>
        {cmp.awaited.length > 0 && <p className="mt-2 text-xs text-ink-500">No quotation from: {cmp.awaited.map((a: any) => a.supplier?.name).join(", ")}</p>}
        {summary && <div className="mt-3 rounded-md border border-sky-200 bg-sky-50 p-3 text-sm text-sky-900"><p className="mb-1 flex items-center gap-1 text-xs font-medium uppercase tracking-wide"><Sparkles className="size-3" /> AI suggestion — the decision is yours</p>{summary}</div>}
      </Card>
      <ErrorNote error={err} />
      <Card padded={false}>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-sm" style={{ minWidth: `${560 + sups.length * 190}px` }}>
            <thead>
              <tr className="border-b border-ink-200 bg-ink-50/60 align-bottom">
                <th className={clsx(th, sticky, "bg-ink-50 w-8")}>#</th>
                <th className={clsx(th, "min-w-[14rem]")}>Item</th>
                <th className={clsx(th, "text-right")}>Qty</th>
                <th className={clsx(th, "text-right")}>Last price</th>
                {sups.map((s: any) => (
                  <th key={s.quotation_id} className={clsx(th, "min-w-[11rem] text-right normal-case")}>
                    <p className="text-sm font-semibold normal-case tracking-normal text-ink-900">{s.supplier.name}</p>
                    <p className="mt-0.5 flex justify-end gap-1">{s.rank ? <Badge tone={s.rank === 1 ? "green" : "grey"}>L{s.rank}</Badge> : <Badge tone="amber">{s.quoted_lines}/{cmp.lines.length} lines</Badge>}</p>
                    {editable && <button type="button" className="mt-1 text-xs font-medium text-brand-700 hover:underline" onClick={() => awardAll(s.quotation_id)}>Award all</button>}
                  </th>
                ))}
                <th className={clsx(th, "min-w-[12rem]")}>Reason (if not L1)</th>
              </tr>
            </thead>
            <tbody>
              {cmp.lines.map((l: any) => (
                <tr key={l.id} className="border-b border-ink-100 align-top">
                  <td className={clsx(sticky, "px-2 py-2 text-ink-500")}>{l.line_no}</td>
                  <td className="px-2 py-2"><p className="text-ink-900">{l.description}</p>{l.item_code && <p className="text-xs text-ink-500">{l.item_code}</p>}
                    {editable && <label className="mt-1 inline-flex items-center gap-1 text-xs text-ink-500"><input type="radio" name={`sel-${l.id}`} checked={!sel[l.id]} onChange={() => setSel({ ...sel, [l.id]: "" })} /> do not order now</label>}</td>
                  <td className="num px-2 py-2 text-right whitespace-nowrap">{qty(l.quantity)} {l.unit}</td>
                  <td className="num px-2 py-2 text-right text-xs text-ink-600">{l.last_price ? <><p>{inr(l.last_price.rate)}</p><p className="text-ink-400" title={l.last_price.supplier}>{l.last_price.po_number} · {date(l.last_price.po_date)}</p></> : "—"}</td>
                  {sups.map((s: any) => {
                    const c = l.cells[s.quotation_id];
                    const isL1 = l.l1.includes(s.quotation_id);
                    const chosen = sel[l.id] === s.quotation_id;
                    if (!c) return <td key={s.quotation_id} className="px-2 py-2 text-right text-xs text-ink-400">not quoted</td>;
                    return (
                      <td key={s.quotation_id} className={clsx("px-2 py-2 text-right", isL1 && "bg-emerald-50", chosen && "ring-2 ring-inset ring-brand-500")}>
                        <label className={clsx("block", editable && "cursor-pointer")}>
                          <span className="flex items-center justify-end gap-1.5">
                            {isL1 && <Badge tone="green">L1</Badge>}
                            {editable && <input type="radio" name={`sel-${l.id}`} aria-label={`Choose ${s.supplier.name} for line ${l.line_no}`} checked={chosen} onChange={() => setSel({ ...sel, [l.id]: s.quotation_id })} />}
                          </span>
                          <span className="num block text-xs text-ink-600">{inr(c.unit_rate)}{Number(c.discount_pct) ? ` −${Number(c.discount_pct)}%` : ""} · GST {Number(c.gst_pct)}%</span>
                          <span className="num block text-xs text-ink-500">net {inr(c.net_rate)}</span>
                          <span className="num block font-semibold text-ink-900">{inr(net ? c.taxable : c.total)}</span>
                          {(c.make || c.delivery_days !== null) && <span className="block text-[11px] text-ink-500">{[c.make, c.delivery_days !== null ? `${c.delivery_days} days` : null].filter(Boolean).join(" · ")}</span>}
                        </label>
                      </td>
                    );
                  })}
                  <td className="px-2 py-2">
                    {editable ? <Input className={clsx("h-8 text-[13px]", notL1(l) && !(remarks[l.id] ?? "").trim() && !common.trim() && "border-amber-400")} aria-label={`Reason, line ${l.line_no}`}
                      placeholder={notL1(l) ? "Required: why not L1?" : ""} value={remarks[l.id] ?? ""} onChange={(e) => setRemarks({ ...remarks, [l.id]: e.target.value })} />
                      : <span className="text-xs text-amber-800">{l.selection_remark ?? ""}</span>}
                    {!editable && l.selected_quotation_id && <p className="text-xs text-ink-600">→ {name[l.selected_quotation_id]}</p>}
                  </td>
                </tr>
              ))}
            </tbody>
            <tbody className="text-xs">
              {([
                ["Value before GST", (s: any) => inr(s.taxable)], ["GST", (s: any) => inr(s.gst)],
                ["Freight", (s: any) => (s.freight_included ? "included" : inr(s.freight_amount))], ["Total incl. GST + freight", (s: any) => inr(s.grand_total)],
                ["Compared total", (s: any) => <b>{inr(s.basis_total)}</b>], ["Quotation", (s: any) => [s.quote_ref, s.quote_date ? date(s.quote_date) : null].filter(Boolean).join(" · ") || "—"],
                ["Payment terms", (s: any) => s.payment_terms ?? "—"], ["Delivery", (s: any) => s.delivery_period ?? "—"],
                ["Valid until", (s: any) => date(s.valid_until)], ["Warranty", (s: any) => s.warranty ?? "—"],
                ["Rates include GST", (s: any) => (s.gst_inclusive ? "Yes" : "No")],
              ] as [string, (s: any) => React.ReactNode][]).map(([label, fn]) => (
                <tr key={label} className="border-b border-ink-100 bg-ink-50/40">
                  <td className={clsx(sticky, "bg-ink-50")} /><td colSpan={3} className="px-2 py-1.5 font-medium text-ink-700">{label}</td>
                  {sups.map((s: any) => <td key={s.quotation_id} className={clsx("px-2 py-1.5 text-right", label === "Compared total" && s.rank === 1 && Number(s.basis_total) === lowTotal && "bg-emerald-100")}>{fn(s)}</td>)}
                  <td />
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      {editable && (
        <Card>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <Field label="Reason for every line not given to L1 (unless the line has its own)" className="flex-1">
              <Input value={common} onChange={(e) => setCommon(e.target.value)} placeholder="e.g. Approved make of the consultant; single delivery" />
            </Field>
            <Button icon={<Save className="size-4" />} loading={busy === "save"} onClick={save}>Save choice</Button>
            {rfq.can.create_po && <Button icon={<PackagePlus className="size-4" />} onClick={() => setPoOpen(true)}>Create purchase orders</Button>}
          </div>
          {rfq.status === "compared" && !rfq.can.create_po && <p className="mt-2 text-xs text-ink-500">Purchase orders are created by users who can create them.</p>}
          {rfq.status !== "compared" && <p className="mt-2 text-xs text-ink-500">Save the choice, then create one purchase order per chosen supplier.</p>}
        </Card>
      )}
      {rfq.purchase_orders.length > 0 && (
        <Card title="Purchase orders from this comparison">
          <ul className="space-y-1 text-sm">{rfq.purchase_orders.map((p: any) => <li key={p.id}><Link className="text-brand-700 hover:underline" href={`/purchase/orders/view?id=${p.id}`}>{p.po_number ?? "Draft PO"}</Link> · {p.supplier} · <span className="num">{inr(p.grand_total)}</span></li>)}</ul>
        </Card>
      )}
      <CreatePosDialog open={poOpen} rfq={rfq} onClose={() => setPoOpen(false)} onDone={() => { setPoOpen(false); qc.invalidateQueries({ queryKey: ["/purchase-orders"] }); onChanged(); }} />
    </div>
  );
}

function CreatePosDialog({ open, rfq, onClose, onDone }: { open: boolean; rfq: any; onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const [wh, setWh] = useState(rfq.warehouse?.id ?? "");
  const [when, setWhen] = useState(rfq.required_by ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const suppliers = new Set(rfq.lines.map((l: any) => l.selected_quotation_id).filter(Boolean)).size;
  return (
    <Modal open={open} onClose={onClose} title="Create purchase orders"
      footer={<><Button variant="secondary" onClick={onClose}>Back</Button><Button loading={busy} onClick={async () => {
        setBusy(true); setError(null);
        try {
          const r = await api<any>(`/rfqs/${rfq.id}/create-orders`, { body: { warehouse_id: wh || null, expected_delivery: when || null, row_version: rfq.row_version } });
          toast(`${r.data.purchase_orders.length} draft purchase order(s) created — submit them for approval`);
          onDone();
        } catch (e) { setError(e); } finally { setBusy(false); }
      }}>Create {suppliers} draft PO{suppliers === 1 ? "" : "s"}</Button></>}>
      <div className="space-y-3">
        <ErrorNote error={error} />
        <p className="text-sm text-ink-700">One draft purchase order per chosen supplier, at the quoted rates{rfq.purchase_request ? `, linked to ${rfq.purchase_request.number}` : ""}. They go through the usual approval.</p>
        <Field label="Deliver to (store)"><WarehouseSelect value={wh} onChange={setWh} blank="Main store" /></Field>
        <Field label="Expected delivery"><Input type="date" value={when} onChange={(e) => setWhen(e.target.value)} /></Field>
      </div>
    </Modal>
  );
}
