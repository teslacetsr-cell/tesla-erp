"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Scale } from "lucide-react";
import { Badge, Button, Card, useToast } from "@/components/ui";
import { api, type Page } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, titleCase } from "@/lib/format";

type Tone = "green" | "red" | "grey" | "amber" | "blue";
export const RFQ_STATUSES: [string, string, Tone][] = [
  ["draft", "Draft", "grey"], ["sent", "Sent to suppliers", "blue"], ["quotes_received", "Quotes received", "amber"],
  ["compared", "Compared", "blue"], ["closed", "Closed — PO created", "green"], ["cancelled", "Cancelled", "grey"],
];
export const QUOTE_STATUSES: [string, string, Tone][] = [["awaited", "Awaited", "grey"], ["received", "Received", "green"], ["declined", "Did not quote", "red"]];

function pick(set: [string, string, Tone][], v: string) {
  const s = set.find(([k]) => k === v);
  return <Badge tone={s?.[2] ?? "grey"}>{s?.[1] ?? titleCase(v)}</Badge>;
}
export const RfqStatus = ({ status }: { status: string }) => pick(RFQ_STATUSES, status);
export const QuoteStatus = ({ status }: { status: string }) => pick(QUOTE_STATUSES, status);

/** "Get vendor quotations" on a purchase request or material request: makes a draft RFQ with its open lines. */
export function GetQuotesButton({ source, id, variant = "secondary" }: { source: "pr" | "mr"; id: string; variant?: "primary" | "secondary" }) {
  const router = useRouter();
  const toast = useToast();
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  return (
    <Button variant={variant} icon={<Scale className="size-4" />} loading={busy} onClick={async () => {
      setBusy(true);
      try {
        const r = await api<any>("/rfqs", { body: source === "pr" ? { purchase_request_id: id } : { material_request_id: id } });
        qc.invalidateQueries({ queryKey: ["/rfqs"] });
        toast("Draft RFQ created — choose the suppliers");
        router.push(`/purchase/rfqs/view?id=${r.data.id}`);
      } catch (e: any) { toast(e.message, "error"); setBusy(false); }
    }}>Get vendor quotations</Button>
  );
}

/** The RFQs made from a purchase / material request, with links to their comparison. */
export function RfqLinks({ source, id }: { source: "pr" | "mr"; id: string }) {
  const { can } = useAuth();
  const q = useQuery({
    enabled: can("rfq.read"),
    queryKey: ["/rfqs", source, id],
    queryFn: () => api<Page<any>>("/rfqs", { params: { [source === "pr" ? "purchase_request_id" : "material_request_id"]: id, page_size: 50 } }),
    select: (r) => r.data,
  });
  if (!q.data?.length) return null;
  return (
    <Card title="Vendor quotations">
      <ul className="space-y-1.5 text-sm">
        {q.data.map((r) => (
          <li key={r.id} className="flex flex-wrap items-center gap-2">
            <Link href={`/purchase/rfqs/view?id=${r.id}`} className="font-medium text-brand-700 hover:underline">{r.display_number}</Link>
            <RfqStatus status={r.status} />
            <span className="text-ink-500">{r.received_count} of {r.suppliers.length} quote(s) · {date(r.rfq_date)}</span>
            {r.received_count > 0 && <Link href={`/purchase/rfqs/view?id=${r.id}&tab=compare`} className="text-brand-700 hover:underline">Comparison sheet</Link>}
          </li>
        ))}
      </ul>
    </Card>
  );
}
