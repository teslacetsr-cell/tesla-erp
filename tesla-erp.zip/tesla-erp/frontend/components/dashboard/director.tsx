"use client";

import Link from "next/link";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, Landmark, ShieldCheck, Wallet } from "lucide-react";
import { Card } from "@/components/ui";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { date, inr } from "@/lib/format";

type Month = { month: string; short: string; order_intake: string; billed: string; billed_gross: string; collected: string };
type Stage = { stage: string; label: string; count: number; value: string; note?: string; href: string };
type Project = {
  id: string; project_number: string; name: string; customer: string; status: string; progress_pct: number;
  contract_value: string; billed: string; cost: string; profit: string; margin_pct: string | null;
  estimated_margin_pct: string | null; late: boolean; target_end_date: string | null;
};
type Director = {
  as_of: string; fy: { start: string; end: string; label: string };
  funnel: Stage[]; months: Month[];
  totals: { order_intake: string; billed: string; billed_gross: string; collected: string; collection_pct: string | null };
  receivables: Record<string, string>; payables: { outstanding: string; advance: string; net: string };
  cash: { bank: string; cash: string; total: string; receivable: string; payable: string };
  top_projects: Project[];
  approvals: { total: number; mine: number; oldest_days: number | null; by_type: Record<string, number> };
};

/** ₹ in lakh / crore for chart labels: 1,25,00,000 → "₹1.25 Cr", 4,50,000 → "₹4.5 L". */
export function compactInr(v: string | number): string {
  const n = Number(v);
  const a = Math.abs(n);
  if (a >= 1e7) return `₹${(n / 1e7).toFixed(a >= 1e9 ? 0 : 2).replace(/\.?0+$/, "")} Cr`;
  if (a >= 1e5) return `₹${(n / 1e5).toFixed(1).replace(/\.0$/, "")} L`;
  if (a >= 1e3) return `₹${(n / 1e3).toFixed(0)}k`;
  return `₹${n.toFixed(0)}`;
}

function niceMax(v: number): number {
  if (v <= 0) return 1;
  const p = 10 ** Math.floor(Math.log10(v));
  return [1, 2, 2.5, 5, 10].map((m) => m * p).find((m) => m >= v) ?? v;
}

/** Grouped monthly bars in inline SVG (no chart library). Hover a month to read its figures. */
function MonthBars({ months, series }: { months: Month[]; series: { key: keyof Month; label: string; className: string; swatch: string }[] }) {
  const [hover, setHover] = useState<number | null>(null);
  const max = niceMax(Math.max(0, ...months.flatMap((m) => series.map((s) => Number(m[s.key])))));
  const W = 720, H = 220, L = 52, B = 24, T = 8;
  const plotW = W - L - 8, plotH = H - B - T;
  const slot = plotW / months.length;
  const bw = Math.min(16, (slot - 8) / series.length);
  const y = (v: number) => T + plotH - (v / max) * plotH;
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => f * max);
  const h = hover !== null ? months[hover] : null;
  return (
    <div>
      <div className="mb-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-ink-600">
        {series.map((s) => <span key={String(s.key)} className="flex items-center gap-1.5"><span className={`size-2.5 rounded-sm ${s.swatch}`} />{s.label}</span>)}
        <span className="ml-auto min-h-4 text-ink-700">
          {h ? <><span className="font-medium">{h.month}:</span> {series.map((s) => `${s.label} ${inr(h[s.key], 0)}`).join(" · ")}</> : "Point at a month for the figures"}
        </span>
      </div>
      <div className="overflow-x-auto">
        <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full min-w-[560px]" role="img"
          aria-label={`Monthly ${series.map((s) => s.label).join(" and ")}`} onMouseLeave={() => setHover(null)}>
          {ticks.map((t) => (
            <g key={t}>
              <line x1={L} x2={W - 8} y1={y(t)} y2={y(t)} className="stroke-ink-100" strokeWidth={1} />
              <text x={L - 6} y={y(t) + 3} textAnchor="end" className="fill-ink-400 text-[10px]">{compactInr(t)}</text>
            </g>
          ))}
          {months.map((m, i) => {
            const x0 = L + i * slot + (slot - bw * series.length) / 2;
            return (
              <g key={m.month} onMouseEnter={() => setHover(i)} onFocus={() => setHover(i)} tabIndex={0}>
                <rect x={L + i * slot} y={T} width={slot} height={plotH} className={hover === i ? "fill-ink-50" : "fill-transparent"} />
                {series.map((s, j) => {
                  const v = Math.max(0, Number(m[s.key]));
                  return <rect key={String(s.key)} x={x0 + j * bw} y={y(v)} width={bw - 2} height={Math.max(0, T + plotH - y(v))} rx={2} className={s.className}><title>{`${m.month} — ${s.label}: ${inr(m[s.key], 0)}`}</title></rect>;
                })}
                <text x={L + i * slot + slot / 2} y={H - 8} textAnchor="middle" className="fill-ink-500 text-[10px]">{m.short}</text>
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
}

function Funnel({ stages }: { stages: Stage[] }) {
  const max = Math.max(1, ...stages.map((s) => s.count));
  return (
    <div className="space-y-2.5">
      {stages.map((s, i) => {
        const prev = i > 0 ? stages[i - 1].count : null;
        const conv = prev ? Math.round((s.count / prev) * 100) : null;
        return (
          <Link key={s.stage} href={s.href} className="group grid grid-cols-[7.5rem_1fr_auto] items-center gap-3 text-sm">
            <span className="text-ink-700 group-hover:text-brand-700">{s.label}</span>
            <span className="h-6 overflow-hidden rounded bg-ink-50">
              <span className="flex h-full items-center rounded bg-brand-600/85 px-2 text-xs font-semibold text-white" style={{ width: `${Math.max(6, (s.count / max) * 100)}%` }}>{s.count}</span>
            </span>
            <span className="num w-28 text-right text-xs text-ink-600">{compactInr(s.value)}{conv !== null && <span className="block text-[11px] text-ink-400">{conv}% of previous</span>}{s.note && conv === null && <span className="block text-[11px] text-ink-400">{s.note}</span>}</span>
          </Link>
        );
      })}
    </div>
  );
}

const AGE: [string, string, string][] = [
  ["not_due", "Not yet due", "bg-emerald-500"], ["d0_30", "1–30 days", "bg-amber-300"], ["d31_60", "31–60", "bg-amber-500"],
  ["d61_90", "61–90", "bg-brand-400"], ["d90", "Over 90", "bg-brand-700"],
];

function Ageing({ r }: { r: Record<string, string> }) {
  const total = AGE.reduce((n, [k]) => n + Math.max(0, Number(r[k])), 0);
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <p className="num text-2xl font-semibold text-ink-900">{inr(r.outstanding, 0)}</p>
        <p className="text-xs text-ink-500"><span className="font-medium text-brand-700">{inr(r.overdue, 0)}</span> overdue</p>
      </div>
      <div className="mt-3 flex h-3 overflow-hidden rounded-full bg-ink-100" role="img" aria-label="Receivables by age">
        {total > 0 && AGE.map(([k, label, cls]) => Number(r[k]) > 0 && <span key={k} className={cls} style={{ width: `${(Number(r[k]) / total) * 100}%` }} title={`${label}: ${inr(r[k], 0)}`} />)}
      </div>
      <dl className="mt-3 grid grid-cols-2 gap-x-6 gap-y-1 text-xs">
        {AGE.map(([k, label, cls]) => (
          <div key={k} className="flex items-center justify-between gap-2"><dt className="flex items-center gap-1.5 text-ink-600"><span className={`size-2 rounded-full ${cls}`} />{label}</dt><dd className="num text-ink-800">{compactInr(r[k])}</dd></div>
        ))}
        {Number(r.retention) > 0 && <div className="flex justify-between gap-2"><dt className="text-ink-600">Retention</dt><dd className="num">{compactInr(r.retention)}</dd></div>}
        {Number(r.advance) > 0 && <div className="flex justify-between gap-2"><dt className="text-ink-600">Advances</dt><dd className="num">−{compactInr(r.advance)}</dd></div>}
      </dl>
      <Link href="/reports/view?key=receivables_ageing" className="mt-3 inline-block text-xs font-medium text-brand-700 hover:underline">Receivables ageing report</Link>
    </div>
  );
}

function Mini({ icon: Icon, label, value, sub, href, tone }: { icon: typeof Wallet; label: string; value: string; sub?: string; href?: string; tone?: string }) {
  const inner = (
    <div className="h-full rounded-lg border border-ink-200 bg-white p-4 hover:border-brand-300">
      <p className="flex items-center gap-1.5 text-xs text-ink-500"><Icon className="size-3.5" /> {label}</p>
      <p className={`num mt-1 text-2xl font-semibold ${tone ?? "text-ink-900"}`}>{value}</p>
      {sub && <p className="mt-0.5 text-xs text-ink-500">{sub}</p>}
    </div>
  );
  return href ? <Link href={href}>{inner}</Link> : inner;
}

/** Director / Manager dashboard (Spec §33): one call to /dashboard/director. */
export function DirectorDashboard() {
  const { can } = useAuth();
  const { data, isLoading, error } = useQuery({
    queryKey: ["/dashboard/director"],
    queryFn: () => api<{ data: Director }>("/dashboard/director"),
    select: (r) => r.data,
    enabled: can("dashboard.read"),
    staleTime: 60_000,
  });
  if (!can("dashboard.read")) return null;
  if (isLoading) return <div className="mb-6 h-72 animate-pulse rounded-lg bg-ink-100/60" aria-label="Loading the dashboard" />;
  if (error || !data) return null;
  const t = data.totals;
  const a = data.approvals;
  return (
    <div className="mb-8 space-y-4">
      <div className="flex items-baseline justify-between">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-ink-500">Company · {data.fy.label}</h2>
        <span className="text-xs text-ink-400">as on {date(data.as_of)}</span>
      </div>
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Mini icon={Landmark} label="Bank & cash (in the ERP books)" value={inr(data.cash.total, 0)} sub={`Bank ${compactInr(data.cash.bank)} · Cash ${compactInr(data.cash.cash)}`} href="/finance/reports" />
        <Mini icon={Wallet} label="To receive (net of advances)" value={inr(data.cash.receivable, 0)} sub={`To pay suppliers ${inr(data.cash.payable, 0)}`} href="/finance/receivables" />
        <Mini icon={Wallet} label={`Collected this year`} value={inr(t.collected, 0)} sub={`of ${inr(t.billed_gross, 0)} billed${t.collection_pct ? ` · ${Number(t.collection_pct).toFixed(0)}%` : ""}`} href="/reports/view?key=billing_vs_collections" tone="text-emerald-700" />
        <Mini icon={ShieldCheck} label="Approvals pending" value={String(a.total)} sub={`${a.mine} waiting for you${a.oldest_days ? ` · oldest ${a.oldest_days} day(s)` : ""}`} href="/approvals" tone={a.mine ? "text-amber-700" : undefined} />
      </div>
      <div className="grid gap-4 xl:grid-cols-[1fr_380px]">
        <Card title="Order intake and billing by month (before GST)" actions={<span className="num text-xs text-ink-500">Orders {compactInr(t.order_intake)} · Billed {compactInr(t.billed)}</span>}>
          <MonthBars months={data.months} series={[
            { key: "order_intake", label: "Orders received", className: "fill-ink-300", swatch: "bg-ink-300" },
            { key: "billed", label: "Billed", className: "fill-brand-600", swatch: "bg-brand-600" },
          ]} />
        </Card>
        <Card title="Sales funnel this year" actions={<Link href="/reports/view?key=lead_conversion" className="text-xs font-medium text-brand-700 hover:underline">Conversion report</Link>}>
          <Funnel stages={data.funnel} />
        </Card>
      </div>
      <div className="grid gap-4 xl:grid-cols-[1fr_380px]">
        <Card title="Billed vs collected by month (with GST)" actions={<Link href="/reports/view?key=billing_vs_collections" className="text-xs font-medium text-brand-700 hover:underline">Report</Link>}>
          <MonthBars months={data.months} series={[
            { key: "billed_gross", label: "Billed", className: "fill-brand-600", swatch: "bg-brand-600" },
            { key: "collected", label: "Collected", className: "fill-emerald-600", swatch: "bg-emerald-600" },
          ]} />
        </Card>
        <Card title="Receivables ageing">
          <Ageing r={data.receivables} />
        </Card>
      </div>
      <Card title="Top 10 open projects by value" padded={false} actions={<Link href="/projects/profitability" className="text-xs font-medium text-brand-700 hover:underline">Profitability</Link>}>
        {data.top_projects.length === 0 ? <p className="px-4 py-6 text-sm text-ink-500">No open projects.</p> : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead><tr className="border-b border-ink-200 bg-ink-50/60 text-left text-xs uppercase tracking-wide text-ink-500">
                <th className="px-4 py-2 font-medium">Project</th><th className="px-3 py-2 text-right font-medium">Contract</th>
                <th className="px-3 py-2 text-right font-medium">Billed</th><th className="px-3 py-2 text-right font-medium">Cost so far</th>
                <th className="px-3 py-2 text-right font-medium">Margin</th><th className="px-4 py-2 font-medium">Progress</th>
              </tr></thead>
              <tbody>
                {data.top_projects.map((p) => {
                  const m = p.margin_pct === null ? null : Number(p.margin_pct);
                  return (
                    <tr key={p.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50/50">
                      <td className="px-4 py-2">
                        <Link href={`/projects/view?id=${p.id}`} className="font-medium text-ink-900 hover:text-brand-700">{p.name}</Link>
                        <span className="block text-xs text-ink-500">{p.project_number} · {p.customer}{p.late && <span className="ml-1 inline-flex items-center gap-0.5 text-brand-700"><AlertTriangle className="size-3" /> past target</span>}</span>
                      </td>
                      <td className="num px-3 py-2 text-right">{compactInr(p.contract_value)}</td>
                      <td className="num px-3 py-2 text-right">{compactInr(p.billed)}</td>
                      <td className="num px-3 py-2 text-right">{compactInr(p.cost)}</td>
                      <td className={`num px-3 py-2 text-right font-medium ${m === null ? "text-ink-400" : m < 0 ? "text-brand-700" : m < 10 ? "text-amber-700" : "text-emerald-700"}`}
                        title={p.estimated_margin_pct ? `Estimated ${Number(p.estimated_margin_pct).toFixed(1)}%` : undefined}>
                        {m === null ? "—" : `${m.toFixed(1)}%`}
                      </td>
                      <td className="px-4 py-2">
                        <span className="flex items-center gap-2"><span className="h-1.5 w-20 overflow-hidden rounded-full bg-ink-100"><span className="block h-full bg-brand-600" style={{ width: `${p.progress_pct}%` }} /></span><span className="num text-xs text-ink-600">{p.progress_pct}%</span></span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
