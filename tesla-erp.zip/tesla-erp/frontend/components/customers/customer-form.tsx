"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle } from "lucide-react";
import { Button, Card, ErrorNote, Field, Input, Select, Textarea } from "@/components/ui";
import { AddressFields, applyServerErrors, clean, useGstinAutofill } from "@/components/forms";
import { api, ApiError } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";

export const CUSTOMER_TYPES = ["company", "hospital", "government", "builder", "consultant", "contractor", "institution", "individual", "other"];

export type CustomerValues = Record<string, any>;

const EMPTY: CustomerValues = {
  customer_code: "", customer_name: "", customer_type: "company", company_name: "", gstin: "", pan: "", phone: "",
  email: "", website: "", address_line1: "", address_line2: "", city: "", district: "", state: "", state_code: "",
  pincode: "", country: "India", default_payment_terms: "", credit_limit: "", credit_days: "",
  assigned_sales_person_id: "", status: "active", notes: "",
};

type Dup = { id: string; customer_code: string; customer_name: string; city: string | null; reasons: string[] };

export function CustomerForm({
  initial,
  onSubmit,
  submitLabel,
  onCancel,
}: {
  initial?: CustomerValues;
  onSubmit: (values: CustomerValues, allowDuplicate: boolean) => Promise<void>;
  submitLabel: string;
  onCancel?: () => void;
}) {
  const { me } = useAuth();
  const form = useForm<CustomerValues>({ defaultValues: { ...EMPTY, ...stripNulls(initial) } });
  const { register, handleSubmit, formState, watch } = form;
  const e = formState.errors as Record<string, { message?: string }>;
  const [error, setError] = useState<unknown>(null);
  const [dupGstin, setDupGstin] = useState<string | null>(null);
  useGstinAutofill(form);

  const salesPeople = useQuery({
    queryKey: ["/customers/sales-people"],
    queryFn: () => api<{ data: { id: string; name: string }[] }>("/customers/sales-people"),
    select: (r) => r.data,
  });
  const ownScope = me?.permissions["customer.update"] === "own";

  // Live duplicate hints as the user types the name / GSTIN / phone.
  const [name, gstin, phone] = [watch("customer_name"), watch("gstin"), watch("phone")];
  const [dups, setDups] = useState<Dup[]>([]);
  useEffect(() => {
    const t = setTimeout(async () => {
      if ((name?.length ?? 0) < 3 && !gstin && !phone) return setDups([]);
      try {
        const r = await api<{ data: Dup[] }>("/customers/duplicate-check", {
          params: { name, gstin: gstin?.length === 15 ? gstin : undefined, phone, exclude: initial?.id },
        });
        setDups(r.data);
      } catch {
        setDups([]);
      }
    }, 400);
    return () => clearTimeout(t);
  }, [name, gstin, phone, initial?.id]);

  const submit = handleSubmit(async (values) => {
    setError(null);
    try {
      const body = clean({ ...values });
      if (ownScope && initial) body.assigned_sales_person_id = initial.assigned_sales_person_id ?? null;
      await onSubmit(body, dupGstin === values.gstin);
    } catch (err) {
      if (err instanceof ApiError && err.code === "DUPLICATE_GSTIN") setDupGstin(values.gstin);
      applyServerErrors(form, err);
      setError(err);
    }
  });

  return (
    <form onSubmit={submit} className="space-y-5">
      <ErrorNote error={error} />
      {dupGstin && (
        <p className="text-sm text-ink-600">
          If this really is a separate customer with the same GSTIN (e.g. another unit), press <b>{submitLabel}</b> again to save anyway.
        </p>
      )}
      {dups.length > 0 && (
        <div className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900">
          <p className="flex items-center gap-1.5 font-medium">
            <AlertTriangle className="size-4" /> Possible duplicates — check before creating a new customer
          </p>
          <ul className="mt-1 space-y-0.5">
            {dups.slice(0, 4).map((d) => (
              <li key={d.id}>
                <a href={`/customers/view?id=${d.id}`} target="_blank" className="underline">
                  {d.customer_name}
                </a>{" "}
                <span className="text-amber-800">
                  ({d.customer_code}
                  {d.city ? `, ${d.city}` : ""}) — {d.reasons.join(", ")}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <Card title="Customer">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Customer name" required error={e.customer_name?.message} className="sm:col-span-2">
            <Input autoFocus {...register("customer_name", { required: "Customer name is required" })} />
          </Field>
          <Field label="Type" error={e.customer_type?.message}>
            <Select {...register("customer_type")}>
              {CUSTOMER_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t.charAt(0).toUpperCase() + t.slice(1)}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Legal / company name" error={e.company_name?.message} className="sm:col-span-2">
            <Input {...register("company_name")} />
          </Field>
          <Field label="Customer code" hint="Leave blank to auto-number" error={e.customer_code?.message}>
            <Input {...register("customer_code")} />
          </Field>
          <Field label="GSTIN" hint="State and PAN fill in automatically" error={e.gstin?.message}>
            <Input className="uppercase" maxLength={15} {...register("gstin")} />
          </Field>
          <Field label="PAN" error={e.pan?.message}>
            <Input className="uppercase" maxLength={10} {...register("pan")} />
          </Field>
          <Field label="Status" error={e.status?.message}>
            <Select {...register("status")}>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="blocked">Blocked</option>
            </Select>
          </Field>
          {initial?.is_prospect === true && (
            <label className="flex items-start gap-2 rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-900 sm:col-span-2 lg:col-span-3">
              <input type="checkbox" className="mt-0.5" {...register("is_prospect")} />
              <span>Still a prospect (saved from a lead; details to be completed). Entering the GSTIN, or clearing this tick, makes it a regular customer.</span>
            </label>
          )}
          <Field label="Phone" error={e.phone?.message}>
            <Input type="tel" {...register("phone")} />
          </Field>
          <Field label="Email" error={e.email?.message}>
            <Input type="email" {...register("email")} />
          </Field>
          <Field label="Website" error={e.website?.message}>
            <Input {...register("website")} />
          </Field>
        </div>
      </Card>

      <Card title="Billing address">
        <AddressFields form={form} />
      </Card>

      <Card title="Commercial">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Payment terms" error={e.default_payment_terms?.message} className="sm:col-span-2">
            <Input {...register("default_payment_terms")} placeholder="e.g. 50% advance, balance against delivery" />
          </Field>
          <Field label="Credit limit (₹)" error={e.credit_limit?.message}>
            <Input inputMode="decimal" className="num" {...register("credit_limit")} />
          </Field>
          <Field label="Credit days" error={e.credit_days?.message}>
            <Input inputMode="numeric" className="num" {...register("credit_days")} />
          </Field>
          <Field label="Salesperson" error={e.assigned_sales_person_id?.message} className="sm:col-span-2"
            hint={ownScope && !initial ? "Customers you create are assigned to you" : undefined}>
            <Select {...register("assigned_sales_person_id")} disabled={ownScope && !!initial}>
              <option value="">— Unassigned —</option>
              {salesPeople.data?.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Notes" error={e.notes?.message} className="sm:col-span-2 lg:col-span-4">
            <Textarea rows={3} {...register("notes")} />
          </Field>
        </div>
      </Card>

      <div className="flex justify-end gap-2">
        {onCancel && (
          <Button type="button" variant="secondary" onClick={onCancel}>
            Cancel
          </Button>
        )}
        <Button type="submit" loading={formState.isSubmitting}>
          {submitLabel}
        </Button>
      </div>
    </form>
  );
}

function stripNulls(v?: CustomerValues) {
  if (!v) return {};
  return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, x === null ? "" : x]));
}
