"use client";

import { useEffect, useState } from "react";
import { AlertTriangle } from "lucide-react";
import { Button, ErrorNote, Field, Input, Modal, Select } from "@/components/ui";
import { CUSTOMER_TYPES } from "@/components/customers/customer-form";
import type { CustomerRef } from "@/components/crm/common";
import { api, ApiError } from "@/lib/api/client";
import { GST_STATES } from "@/lib/format";

type Dup = { id: string; customer_code: string; customer_name: string; city: string | null; reasons: string[] };

/** Create a customer without leaving the quotation: the essentials only (the full record can be completed later),
 * with the same duplicate check as the customer screen — and a one-click "use this one" for a match. */
export function QuickCustomerDialog({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: (c: CustomerRef) => void }) {
  const blank = { customer_name: "", customer_type: "company", phone: "", email: "", gstin: "", address_line1: "", city: "", state_code: "", pincode: "" };
  const [v, setV] = useState(blank);
  const [dups, setDups] = useState<Dup[]>([]);
  const [dupGstin, setDupGstin] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  useEffect(() => { if (open) { setV(blank); setDups([]); setError(null); setDupGstin(false); } }, [open]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    const t = setTimeout(async () => {
      if (v.customer_name.length < 3 && !v.phone && v.gstin.length !== 15) return setDups([]);
      try {
        const r = await api<{ data: Dup[] }>("/customers/duplicate-check", { params: { name: v.customer_name, phone: v.phone || undefined, gstin: v.gstin.length === 15 ? v.gstin : undefined } });
        setDups(r.data);
      } catch { setDups([]); }
    }, 350);
    return () => clearTimeout(t);
  }, [v.customer_name, v.phone, v.gstin]);
  // GSTIN gives the state
  useEffect(() => {
    if (v.gstin.length >= 2 && /^[0-9]{2}/.test(v.gstin) && !v.state_code) setV((x) => ({ ...x, state_code: v.gstin.slice(0, 2) }));
  }, [v.gstin, v.state_code]);
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV({ ...v, [k]: k === "gstin" ? e.target.value.toUpperCase() : e.target.value });
  const fe = error instanceof ApiError ? error.fieldErrors() : {};

  async function save() {
    setError(null);
    if (v.customer_name.trim().length < 2) return setError(new Error("Enter the customer's name."));
    if (!v.state_code) return setError(new Error("Choose the state — it decides CGST + SGST or IGST."));
    setBusy(true);
    try {
      const body: Record<string, any> = Object.fromEntries(Object.entries(v).map(([k, x]) => [k, typeof x === "string" && x.trim() === "" ? null : typeof x === "string" ? x.trim() : x]));
      const st = GST_STATES.find(([c]) => c === v.state_code);
      if (st) body.state = st[1];
      const r = await api<any>("/customers", { body, params: dupGstin ? { allow_duplicate: true } : undefined });
      onCreated({ id: r.data.id, name: r.data.customer_name, code: r.data.customer_code, city: r.data.city });
      onClose();
    } catch (e) {
      if (e instanceof ApiError && e.code === "DUPLICATE_GSTIN") setDupGstin(true);
      setError(e);
    } finally { setBusy(false); }
  }

  return (
    <Modal open={open} onClose={onClose} title="New customer" wide
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={save}>{dupGstin ? "Save anyway" : "Create customer"}</Button></>}>
      <div className="space-y-4">
        <ErrorNote error={error instanceof ApiError && error.status === 422 ? new Error("Please correct the highlighted fields.") : error} />
        {dups.length > 0 && (
          <div className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900">
            <p className="flex items-center gap-1.5 font-medium"><AlertTriangle className="size-4" /> This customer may already exist</p>
            <ul className="mt-1 space-y-1">
              {dups.slice(0, 4).map((d) => (
                <li key={d.id} className="flex flex-wrap items-center gap-2">
                  <span>{d.customer_name} <span className="text-amber-800">({d.customer_code}{d.city ? `, ${d.city}` : ""}) — {d.reasons.join(", ")}</span></span>
                  <Button size="sm" variant="secondary" onClick={() => { onCreated({ id: d.id, name: d.customer_name, code: d.customer_code, city: d.city }); onClose(); }}>Use this one</Button>
                </li>
              ))}
            </ul>
          </div>
        )}
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Customer name" required error={fe.customer_name} className="sm:col-span-2"><Input autoFocus value={v.customer_name} onChange={set("customer_name")} /></Field>
          <Field label="Type"><Select value={v.customer_type} onChange={set("customer_type")}>{CUSTOMER_TYPES.map((t) => <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>)}</Select></Field>
          <Field label="GSTIN" error={fe.gstin} hint="Sets the state (and GST type on the quotation)"><Input className="uppercase" maxLength={15} value={v.gstin} onChange={set("gstin")} /></Field>
          <Field label="Phone" error={fe.phone}><Input value={v.phone} onChange={set("phone")} /></Field>
          <Field label="Email" error={fe.email}><Input type="email" value={v.email} onChange={set("email")} /></Field>
          <Field label="Address" className="sm:col-span-2"><Input value={v.address_line1} onChange={set("address_line1")} /></Field>
          <Field label="City"><Input value={v.city} onChange={set("city")} /></Field>
          <Field label="State" required hint="Decides CGST + SGST or IGST" error={fe.state_code}>
            <Select value={v.state_code} onChange={set("state_code")}>
              <option value="">— Choose —</option>
              {GST_STATES.map(([c, n]) => <option key={c} value={c}>{n} ({c})</option>)}
            </Select>
          </Field>
          <Field label="PIN code" error={fe.pincode}><Input inputMode="numeric" maxLength={6} value={v.pincode} onChange={set("pincode")} /></Field>
        </div>
        <p className="text-xs text-ink-500">Contacts, sites, credit terms and the rest can be added later on the customer's page.</p>
      </div>
    </Modal>
  );
}
