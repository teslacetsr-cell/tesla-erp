"use client";

import { useOptions } from "@/lib/hooks";
import type { Section } from "@/components/section-form";

/** Item form sections; select options come from the category/brand/unit/GST masters. */
export function useItemSections(enabled = true): { sections: Section[] | null } {
  const cats = useOptions("/item-categories", enabled);
  const brands = useOptions("/brands", enabled);
  const units = useOptions("/units", enabled);
  const taxes = useOptions("/tax-rates", enabled);
  if (!cats.data || !brands.data || !units.data || !taxes.data) return { sections: null };
  return {
    sections: [
      {
        title: "Item",
        fields: [
          { name: "item_name", label: "Item name", required: true, span: 2 },
          { name: "item_code", label: "Item code", hint: "Leave blank to auto-number", upper: true },
          { name: "item_type", label: "Type", type: "select", options: [["goods", "Goods"], ["service", "Service"]] },
          { name: "category_id", label: "Category", type: "select", required: true, options: [["", "Select…"], ...cats.data.map((c: any) => [c.id, c.name] as [string, string])] },
          { name: "brand_id", label: "Brand", type: "select", options: [["", "—"], ...brands.data.map((b: any) => [b.id, b.name] as [string, string])] },
          { name: "model", label: "Model / part number" },
          { name: "unit_id", label: "Unit", type: "select", required: true, options: [["", "Select…"], ...units.data.map((u: any) => [u.id, `${u.code} — ${u.name}`] as [string, string])] },
          { name: "is_active", label: "Active", type: "checkbox" },
          { name: "description", label: "Description", type: "textarea" },
        ],
      },
      {
        title: "Tax & pricing",
        columns: 4,
        fields: [
          { name: "hsn_sac", label: "HSN / SAC", hint: "4–8 digits" },
          { name: "tax_rate_id", label: "GST rate", type: "select", options: [["", "—"], ...taxes.data.map((t: any) => [t.id, t.name] as [string, string])] },
          { name: "purchase_price", label: "Purchase price (₹)", type: "number" },
          { name: "selling_price", label: "Selling price (₹)", type: "number" },
        ],
      },
      {
        title: "Stock control",
        columns: 4,
        fields: [
          { name: "minimum_stock", label: "Minimum stock", type: "number" },
          { name: "reorder_level", label: "Reorder level", type: "number" },
          { name: "serial_number_required", label: "Track serial numbers", type: "checkbox" },
          { name: "batch_required", label: "Track batches", type: "checkbox" },
          { name: "technical_specification", label: "Technical specification", type: "textarea", cols: 4 },
        ],
      },
    ],
  };
}

export function itemPayload(v: Record<string, any>) {
  const out = { ...v };
  for (const k of ["minimum_stock", "reorder_level"]) if (out[k] === null) out[k] = "0";
  return out;
}
