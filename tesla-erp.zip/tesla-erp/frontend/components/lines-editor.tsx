"use client";

import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowDown, ArrowUp, ChevronDown, ChevronRight, Copy, PackageSearch, Plus, Trash2 } from "lucide-react";
import { Button, Input, Select, Textarea } from "@/components/ui";
import { api, type Page } from "@/lib/api/client";
import { inr } from "@/lib/format";

export type LineRow = {
  key: string; section: string; item_id: string | null; description: string; technical_specification: string;
  hsn_sac: string; quantity: string; unit: string; rate: string; discount_pct: string; tax_rate: string; remarks: string;
  links?: Record<string, string | null>;  // e.g. the purchase-request line a PO line comes from
};

let seq = 0;
const newKey = () => `l${Date.now().toString(36)}${(seq++).toString(36)}`;

export function blankLine(section = "", taxRate = "18"): LineRow {
  return { key: newKey(), section, item_id: null, description: "", technical_specification: "", hsn_sac: "", quantity: "1",
    unit: "NOS", rate: "", discount_pct: "0", tax_rate: taxRate, remarks: "" };
}

/** From the API (stored lines) to editable rows. */
export function toRows(items: any[] | undefined): LineRow[] {
  return (items ?? []).map((i) => ({
    key: newKey(), section: i.section ?? "", item_id: i.item_id ?? null, description: i.description ?? "",
    technical_specification: i.technical_specification ?? "", hsn_sac: i.hsn_sac ?? "", quantity: trimNum(i.quantity),
    unit: i.unit ?? "NOS", rate: trimNum(i.rate), discount_pct: trimNum(i.discount_pct ?? "0"), tax_rate: trimNum(i.tax_rate ?? "18"),
    remarks: i.remarks ?? "",
    links: i.pr_line_id || i.project_boq_line_id ? { pr_line_id: i.pr_line_id ?? null, project_boq_line_id: i.project_boq_line_id ?? null } : undefined,
  }));
}

function trimNum(v: any): string {
  const s = String(v ?? "");
  return s.includes(".") ? s.replace(/0+$/, "").replace(/\.$/, "") : s;
}

/** Rows to the API payload (blank optional fields become null). */
export function toPayload(rows: LineRow[]) {
  return rows.map((r) => ({
    section: r.section.trim() || null, item_id: r.item_id, description: r.description.trim(),
    technical_specification: r.technical_specification.trim() || null, hsn_sac: r.hsn_sac.trim() || null,
    quantity: r.quantity.trim(), unit: r.unit.trim() || "NOS", rate: r.rate.trim() || "0",
    discount_pct: r.discount_pct.trim() || "0", tax_rate: r.tax_rate, remarks: r.remarks.trim() || null,
    ...(r.links ?? {}),
  }));
}

export function lineProblems(rows: LineRow[]): string | null {
  for (const [i, r] of rows.entries()) {
    if (!r.description.trim()) return `Line ${i + 1}: enter a description.`;
    if (!(Number(r.quantity) > 0)) return `Line ${i + 1}: quantity must be more than 0.`;
    if (r.rate.trim() === "" || Number.isNaN(Number(r.rate)) || Number(r.rate) < 0) return `Line ${i + 1}: enter a rate.`;
    const d = Number(r.discount_pct || 0);
    if (Number.isNaN(d) || d < 0 || d > 100) return `Line ${i + 1}: discount must be 0–100 %.`;
  }
  return null;
}

// Preview of the server calculation (app/core/gst.py). The server's figures are the ones saved and printed.
const r2 = (x: number) => Math.round((x + Number.EPSILON) * 100) / 100;
export type Preview = { gross: number; lineDiscount: number; special: number; taxable: number; cgst: number; sgst: number; igst: number; roundOff: number; grand: number; lines: { amount: number; taxable: number }[] };

export function preview(rows: LineRow[], interState: boolean, special = 0, roundTotal = true): Preview {
  const base = rows.map((r) => {
    const amount = r2((Number(r.quantity) || 0) * (Number(r.rate) || 0));
    const disc = r2(amount * (Number(r.discount_pct) || 0) / 100);
    return { amount, disc, net: amount - disc, rate: Number(r.tax_rate) || 0 };
  });
  const netTotal = base.reduce((s, b) => s + b.net, 0);
  const sp = Math.min(Math.max(special || 0, 0), netTotal);
  const shares = base.map((b) => (netTotal ? r2(sp * b.net / netTotal) : 0));
  if (sp && base.length) {
    const big = base.reduce((bi, b, i) => (b.net > base[bi].net ? i : bi), 0);
    shares[big] = r2(shares[big] + sp - shares.reduce((a, b) => a + b, 0));
  }
  let cgst = 0, sgst = 0, igst = 0;
  const lines = base.map((b, i) => {
    const taxable = r2(b.net - shares[i]);
    if (interState) igst += r2(taxable * b.rate / 100);
    else { const half = r2(taxable * b.rate / 200); cgst += half; sgst += half; }
    return { amount: b.amount, taxable };
  });
  const taxable = r2(lines.reduce((s, l) => s + l.taxable, 0));
  const before = r2(taxable + cgst + sgst + igst);
  const grand = roundTotal ? Math.round(before) : before;
  return { gross: r2(base.reduce((s, b) => s + b.amount, 0)), lineDiscount: r2(base.reduce((s, b) => s + b.disc, 0)), special: sp,
    taxable, cgst: r2(cgst), sgst: r2(sgst), igst: r2(igst), roundOff: r2(grand - before), grand, lines };
}

export type ItemHit = { id: string; item_code: string; item_name: string; unit: string; gst_rate: string | null; selling_price: string | null; purchase_price?: string | null; hsn_sac: string | null; technical_specification: string | null; item_type?: string; serial_number_required?: boolean; batch_required?: boolean };

export function ItemSearch({ onPick, autoFocus, placeholder = "Search item master…" }: { onPick: (i: ItemHit) => void; autoFocus?: boolean; placeholder?: string }) {
  const [q, setQ] = useState("");
  const [debounced, setDebounced] = useState("");
  useEffect(() => { const t = setTimeout(() => setDebounced(q.trim()), 200); return () => clearTimeout(t); }, [q]);
  const res = useQuery({
    queryKey: ["/items", "picker", debounced],
    queryFn: () => api<Page<ItemHit>>("/items", { params: { q: debounced, page_size: 8, is_active: true } }),
  });
  return (
    <div className="w-80 max-w-[calc(100vw-3rem)] rounded-md border border-ink-200 bg-white p-2 shadow-lg">
      <Input autoFocus={autoFocus} value={q} onChange={(e) => setQ(e.target.value)} placeholder={placeholder} />
      <ul className="mt-1 max-h-64 overflow-y-auto">
        {res.data?.data.length === 0 && <li className="px-2 py-2 text-sm text-ink-500">No items found.</li>}
        {res.data?.data.map((i) => (
          <li key={i.id}>
            <button type="button" className="w-full rounded px-2 py-1.5 text-left hover:bg-brand-50" onClick={() => onPick(i)}>
              <span className="block text-sm text-ink-900">{i.item_name}</span>
              <span className="block text-xs text-ink-500">{i.item_code} · {i.unit}{i.selling_price ? ` · ${inr(i.selling_price)}` : ""}{i.gst_rate ? ` · GST ${Number(i.gst_rate)}%` : ""}</span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function fromItem(i: ItemHit, section: string, fallbackRate: string, price: "selling_price" | "purchase_price" = "selling_price"): LineRow {
  const p = i[price];
  return { ...blankLine(section, fallbackRate), item_id: i.id, description: i.item_name, unit: i.unit,
    rate: p ? trimNum(p) : "", tax_rate: i.gst_rate ? trimNum(i.gst_rate) : fallbackRate,
    hsn_sac: i.hsn_sac ?? "", technical_specification: i.technical_specification ?? "" };
}

export function Popover({ open, onClose, children, align = "left" }: { open: boolean; onClose: () => void; children: React.ReactNode; align?: "left" | "right" }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && onClose();
    const esc = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", esc);
    return () => { document.removeEventListener("mousedown", close); document.removeEventListener("keydown", esc); };
  }, [open, onClose]);
  if (!open) return null;
  return <div ref={ref} className={`absolute z-30 mt-1 ${align === "right" ? "right-0" : "left-0"}`}>{children}</div>;
}

const UNITS = ["NOS", "M", "KG", "SET", "LOT", "JOB", "SQM", "RMT", "LS"];

export function LinesEditor({ rows, onChange, gstRates, interState, readOnly, price = "selling_price" }: {
  rows: LineRow[];
  onChange: (rows: LineRow[]) => void;
  gstRates: string[];
  interState: boolean;
  readOnly?: boolean;
  price?: "selling_price" | "purchase_price";  // which item-master price fills the rate
}) {
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [picker, setPicker] = useState<string | null>(null);
  const [addPicker, setAddPicker] = useState(false);
  const calc = preview(rows, interState, 0, false);
  const defaultRate = gstRates.includes("18") ? "18" : gstRates[gstRates.length - 1] ?? "18";
  const sections = Array.from(new Set(rows.map((r) => r.section).filter(Boolean)));
  const set = (key: string, patch: Partial<LineRow>) => onChange(rows.map((r) => (r.key === key ? { ...r, ...patch } : r)));
  const move = (i: number, d: number) => {
    const j = i + d;
    if (j < 0 || j >= rows.length) return;
    const next = [...rows];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };
  const lastSection = rows[rows.length - 1]?.section ?? "";
  const rateOptions = Array.from(new Set([...gstRates, ...rows.map((r) => r.tax_rate)])).sort((a, b) => Number(a) - Number(b));

  return (
    <div>
      <datalist id="tce-line-units">{UNITS.map((u) => <option key={u} value={u} />)}</datalist>
      <datalist id="tce-line-sections">{sections.map((s) => <option key={s} value={s} />)}</datalist>
      <div className="hidden grid-cols-[1.5rem_minmax(12rem,1fr)_5rem_4.75rem_6.5rem_4.5rem_5.25rem_8.5rem_8.75rem] gap-2 border-b border-ink-200 px-2 pb-2 text-xs font-medium uppercase tracking-wide text-ink-500 lg:grid">
        <span>#</span><span>Description</span><span className="text-right">Qty</span><span>Unit</span><span className="text-right">Rate ₹</span>
        <span className="text-right">Disc %</span><span>GST %</span><span className="text-right">Amount ₹</span><span />
      </div>
      {rows.length === 0 && <p className="px-2 py-6 text-center text-sm text-ink-500">No lines yet. Add a line, pick from the item master, or import from Excel.</p>}
      {rows.map((r, i) => {
        const heading = r.section && r.section !== rows[i - 1]?.section;
        const bad = !r.description.trim() || !(Number(r.quantity) > 0);
        return (
          <div key={r.key}>
            {heading && <p className="mt-3 px-2 py-1 text-xs font-semibold uppercase tracking-wide text-brand-700">{r.section}</p>}
            <div className={`grid grid-cols-2 gap-2 border-b border-ink-100 px-2 py-2 sm:grid-cols-4 lg:grid-cols-[1.5rem_minmax(12rem,1fr)_5rem_4.75rem_6.5rem_4.5rem_5.25rem_8.5rem_8.75rem] lg:items-start ${bad && !readOnly ? "bg-brand-50/30" : ""}`}>
              <span className="col-span-2 pt-2 text-xs text-ink-500 sm:col-span-4 lg:col-span-1">{i + 1}</span>
              <div className="relative col-span-2 sm:col-span-4 lg:col-span-1">
                <div className="flex gap-1">
                  <Textarea rows={1} value={r.description} readOnly={readOnly} placeholder="Description" aria-label={`Line ${i + 1} description`}
                    onChange={(e) => set(r.key, { description: e.target.value })} className="min-h-9 py-1.5" />
                  {!readOnly && (
                    <Button type="button" variant="ghost" size="sm" className="h-9 shrink-0" title="Pick from item master" aria-label="Pick from item master"
                      onClick={() => setPicker(picker === r.key ? null : r.key)}>
                      <PackageSearch className="size-4" />
                    </Button>
                  )}
                </div>
                <Popover open={picker === r.key} onClose={() => setPicker(null)}>
                  <ItemSearch autoFocus onPick={(it) => { onChange(rows.map((x) => (x.key === r.key ? { ...fromItem(it, x.section, defaultRate, price), key: x.key, links: x.links, quantity: x.quantity, discount_pct: x.discount_pct, remarks: x.remarks } : x))); setPicker(null); }} />
                </Popover>
                {r.item_id && <p className="mt-0.5 text-[11px] text-ink-400">From item master</p>}
              </div>
              <Field2 label="Qty"><Input inputMode="decimal" className="num text-right" value={r.quantity} readOnly={readOnly} onChange={(e) => set(r.key, { quantity: e.target.value })} aria-label="Quantity" /></Field2>
              <Field2 label="Unit"><Input list="tce-line-units" className="!px-2" value={r.unit} readOnly={readOnly} onChange={(e) => set(r.key, { unit: e.target.value.toUpperCase() })} aria-label="Unit" /></Field2>
              <Field2 label="Rate ₹"><Input inputMode="decimal" className="num text-right" value={r.rate} readOnly={readOnly} onChange={(e) => set(r.key, { rate: e.target.value })} aria-label="Rate" /></Field2>
              <Field2 label="Disc %"><Input inputMode="decimal" className="num text-right" value={r.discount_pct} readOnly={readOnly} onChange={(e) => set(r.key, { discount_pct: e.target.value })} aria-label="Discount percent" /></Field2>
              <Field2 label="GST %">
                <Select value={r.tax_rate} disabled={readOnly} onChange={(e) => set(r.key, { tax_rate: e.target.value })} aria-label="GST rate" className="!pl-2 !pr-6">
                  {rateOptions.map((g) => <option key={g} value={g}>{g}</option>)}
                </Select>
              </Field2>
              <Field2 label="Amount ₹"><p className="num h-9 truncate pt-2 text-right text-sm font-medium">{inr(calc.lines[i]?.taxable ?? 0)}</p></Field2>
              <div className="col-span-2 flex items-start justify-end gap-0.5 sm:col-span-4 lg:col-span-1">
                <Button type="button" variant="ghost" size="sm" className="!px-1.5" aria-label="More details" title="Section, HSN, specification, remarks" onClick={() => setOpen({ ...open, [r.key]: !open[r.key] })}>
                  {open[r.key] ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
                </Button>
                {!readOnly && (
                  <>
                    <Button type="button" variant="ghost" size="sm" className="!px-1.5" aria-label="Move up" onClick={() => move(i, -1)} disabled={i === 0}><ArrowUp className="size-3.5" /></Button>
                    <Button type="button" variant="ghost" size="sm" className="!px-1.5" aria-label="Move down" onClick={() => move(i, 1)} disabled={i === rows.length - 1}><ArrowDown className="size-3.5" /></Button>
                    <Button type="button" variant="ghost" size="sm" className="!px-1.5" aria-label="Duplicate" onClick={() => { const n = [...rows]; n.splice(i + 1, 0, { ...r, key: newKey() }); onChange(n); }}><Copy className="size-3.5" /></Button>
                    <Button type="button" variant="ghost" size="sm" className="!px-1.5" aria-label="Delete line" onClick={() => onChange(rows.filter((x) => x.key !== r.key))}><Trash2 className="size-3.5 text-ink-400" /></Button>
                  </>
                )}
              </div>
              {open[r.key] && (
                <div className="col-span-2 grid gap-2 rounded-md bg-ink-50 p-2 sm:col-span-4 sm:grid-cols-3 lg:col-span-9 lg:ml-8">
                  <label className="text-xs text-ink-600">Section / group
                    <Input list="tce-line-sections" value={r.section} readOnly={readOnly} onChange={(e) => set(r.key, { section: e.target.value })} placeholder="e.g. External LPS" />
                  </label>
                  <label className="text-xs text-ink-600">HSN / SAC
                    <Input inputMode="numeric" value={r.hsn_sac} readOnly={readOnly} onChange={(e) => set(r.key, { hsn_sac: e.target.value })} />
                  </label>
                  <label className="text-xs text-ink-600">Remarks
                    <Input value={r.remarks} readOnly={readOnly} onChange={(e) => set(r.key, { remarks: e.target.value })} />
                  </label>
                  <label className="text-xs text-ink-600 sm:col-span-3">Technical specification
                    <Textarea rows={2} value={r.technical_specification} readOnly={readOnly} onChange={(e) => set(r.key, { technical_specification: e.target.value })} />
                  </label>
                </div>
              )}
            </div>
          </div>
        );
      })}
      {!readOnly && (
        <div className="relative mt-3 flex flex-wrap gap-2">
          <Button type="button" variant="secondary" size="sm" icon={<Plus className="size-3.5" />} onClick={() => onChange([...rows, blankLine(lastSection, defaultRate)])}>Add line</Button>
          <Button type="button" variant="secondary" size="sm" icon={<PackageSearch className="size-3.5" />} onClick={() => setAddPicker(!addPicker)}>Add from item master</Button>
          <Popover open={addPicker} onClose={() => setAddPicker(false)}>
            <ItemSearch autoFocus onPick={(it) => { onChange([...rows, fromItem(it, lastSection, defaultRate, price)]); setAddPicker(false); }} />
          </Popover>
        </div>
      )}
    </div>
  );
}

function Field2({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block min-w-0">
      <span className="mb-0.5 block text-[11px] text-ink-500 lg:hidden">{label}</span>
      {children}
    </label>
  );
}

/** Totals block (preview while editing, or the saved figures). */
export function TotalsBox({ t, interState, taxSummary }: {
  t: { gross: number | string; lineDiscount?: number | string; special?: number | string; taxable: number | string; cgst: number | string; sgst: number | string; igst: number | string; roundOff?: number | string; grand: number | string };
  interState: boolean;
  taxSummary?: { rate: string; cgst: string; sgst: string; igst: string }[];
}) {
  const row = (label: string, v: number | string | undefined, strong = false, minus = false) =>
    v === undefined || (Number(v) === 0 && !strong && label !== "Taxable value") ? null : (
      <div className={`flex justify-between gap-6 py-1 ${strong ? "border-t border-ink-300 pt-2 text-base font-semibold" : "text-sm"}`}>
        <span className={strong ? "text-ink-900" : "text-ink-600"}>{label}</span>
        <span className="num">{minus ? "− " : ""}{inr(Math.abs(Number(v)))}</span>
      </div>
    );
  return (
    <div className="ml-auto w-full max-w-sm">
      {row("Total", t.gross)}
      {row("Less: discount", t.lineDiscount, false, true)}
      {row("Less: special discount", t.special, false, true)}
      {row("Taxable value", t.taxable)}
      {taxSummary && taxSummary.length > 0
        ? taxSummary.map((s) => interState
          ? <div key={s.rate}>{row(`IGST @ ${s.rate} %`, s.igst)}</div>
          : <div key={s.rate}>{row(`CGST @ ${Number(s.rate) / 2} %`, s.cgst)}{row(`SGST @ ${Number(s.rate) / 2} %`, s.sgst)}</div>)
        : interState ? row("IGST", t.igst) : <>{row("CGST", t.cgst)}{row("SGST", t.sgst)}</>}
      {t.roundOff !== undefined && Number(t.roundOff) !== 0 && (
        <div className="flex justify-between gap-6 py-1 text-sm"><span className="text-ink-600">Round off</span><span className="num">{Number(t.roundOff) > 0 ? "+ " : "− "}{inr(Math.abs(Number(t.roundOff)))}</span></div>
      )}
      {row("Grand total", t.grand, true)}
    </div>
  );
}

/** Read-only priced lines, grouped by section (saved documents). */
export function LinesTable({ items }: { items: any[] }) {
  let section: string | null | undefined;
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[720px] text-sm">
        <thead>
          <tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wide text-ink-500">
            <th className="px-2 py-2 font-medium">#</th><th className="px-2 py-2 font-medium">Description</th><th className="px-2 py-2 font-medium">HSN/SAC</th>
            <th className="px-2 py-2 text-right font-medium">Qty</th><th className="px-2 py-2 font-medium">Unit</th><th className="px-2 py-2 text-right font-medium">Rate ₹</th>
            <th className="px-2 py-2 text-right font-medium">Disc %</th><th className="px-2 py-2 text-right font-medium">GST %</th><th className="px-2 py-2 text-right font-medium">Amount ₹</th>
          </tr>
        </thead>
        <tbody>
          {items.map((it, i) => {
            const head = it.section && it.section !== section;
            section = it.section;
            return (
              <FragmentRow key={it.id ?? i} head={head ? it.section : null}>
                <tr className="border-b border-ink-100 align-top">
                  <td className="px-2 py-2 text-ink-500">{i + 1}</td>
                  <td className="px-2 py-2">
                    <p className="font-medium text-ink-900">{it.description}</p>
                    {it.technical_specification && <p className="whitespace-pre-line text-xs text-ink-500">{it.technical_specification}</p>}
                    {it.remarks && <p className="text-xs italic text-ink-500">{it.remarks}</p>}
                  </td>
                  <td className="px-2 py-2 text-xs text-ink-600">{it.hsn_sac ?? ""}</td>
                  <td className="num px-2 py-2 text-right">{Number(it.quantity).toLocaleString("en-IN", { maximumFractionDigits: 3 })}</td>
                  <td className="px-2 py-2">{it.unit}</td>
                  <td className="num px-2 py-2 text-right">{inr(it.rate)}</td>
                  <td className="num px-2 py-2 text-right">{Number(it.discount_pct) ? Number(it.discount_pct) : ""}</td>
                  <td className="num px-2 py-2 text-right">{Number(it.tax_rate)}</td>
                  <td className="num px-2 py-2 text-right font-medium">{inr(it.taxable)}</td>
                </tr>
              </FragmentRow>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function FragmentRow({ head, children }: { head: string | null; children: React.ReactNode }) {
  return (
    <>
      {head && <tr><td colSpan={9} className="bg-ink-50 px-2 py-1.5 text-xs font-semibold uppercase tracking-wide text-brand-700">{head}</td></tr>}
      {children}
    </>
  );
}
