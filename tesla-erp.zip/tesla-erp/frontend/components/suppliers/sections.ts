import type { Section } from "@/components/section-form";

export const SUPPLIER_SECTIONS: Section[] = [
  {
    title: "Supplier",
    fields: [
      { name: "supplier_name", label: "Supplier name", required: true, span: 2 },
      { name: "supplier_code", label: "Supplier code", hint: "Leave blank to auto-number" },
      { name: "supplies", label: "Supplies", hint: "e.g. SPDs, earthing material, cables", span: 2 },
      { name: "status", label: "Status", type: "select", options: [["active", "Active"], ["inactive", "Inactive"], ["blocked", "Blocked"]] },
      { name: "gstin", label: "GSTIN", upper: true, hint: "State and PAN fill in automatically" },
      { name: "pan", label: "PAN", upper: true },
      { name: "rating", label: "Rating (0–5)", type: "number" },
      { name: "phone", label: "Phone" },
      { name: "email", label: "Email" },
      { name: "website", label: "Website" },
    ],
  },
  {
    title: "Registered address",
    columns: 2,
    fields: [
      { name: "address_line1", label: "Address line 1", span: 2 },
      { name: "address_line2", label: "Address line 2", span: 2 },
      { name: "city", label: "City" },
      { name: "district", label: "District" },
      { name: "state_code", label: "State", type: "state" },
      { name: "pincode", label: "PIN code" },
    ],
  },
  {
    title: "Terms",
    fields: [
      { name: "payment_terms", label: "Payment terms", span: 2 },
      { name: "credit_days", label: "Credit days", type: "number" },
      { name: "notes", label: "Notes", type: "textarea" },
    ],
  },
];
