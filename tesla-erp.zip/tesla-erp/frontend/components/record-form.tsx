"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { Button, Card, Checkbox, DataTable, EmptyState, ErrorNote, Field, Input, Modal, Select, Textarea, useConfirm, useToast, type Column } from "@/components/ui";
import { applyServerErrors, clean, SelectInput } from "@/components/forms";
import { api, ApiError } from "@/lib/api/client";
import { GST_STATES } from "@/lib/format";

export type FieldDef = {
  name: string;
  label: string;
  type?: "text" | "select" | "checkbox" | "textarea" | "state" | "number";
  options?: [string, string][];
  required?: boolean;
  span?: 1 | 2;
  hint?: string;
  upper?: boolean;
};

/** A modal form built from field definitions; used for child records and simple masters. */
export function RecordForm({ fields, initial, onSave, onClose, title, open }: {
  fields: FieldDef[];
  initial: Record<string, any> | null;
  onSave: (values: Record<string, any>) => Promise<void>;
  onClose: () => void;
  title: string;
  open: boolean;
}) {
  const defaults = Object.fromEntries(fields.map((f) => [f.name, initial?.[f.name] ??
    (f.type === "checkbox" ? f.name === "is_active" : f.type === "select" ? f.options?.[0]?.[0] ?? "" : "")]));
  const form = useForm({ values: defaults });
  const [error, setError] = useState<unknown>(null);
  // Start clean every time the dialog opens: nothing typed and cancelled last time carries over.
  useEffect(() => {
    if (open) { form.reset(defaults); setError(null); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);
  const e = form.formState.errors as Record<string, { message?: string }>;
  const submit = form.handleSubmit(async (v) => {
    setError(null);
    try {
      const values = clean(v);
      for (const f of fields) if (f.upper && typeof values[f.name] === "string") values[f.name] = values[f.name].trim().toUpperCase();
      // a blank number field takes the server's default (e.g. display order 100, no limit) instead of being sent empty
      for (const f of fields) if (f.type === "number" && values[f.name] == null) delete values[f.name];
      const s = fields.find((f) => f.type === "state");
      if (s && values[s.name]) values.state = GST_STATES.find(([c]) => c === values[s.name])?.[1] ?? null;
      await onSave(values);
    } catch (err) {
      applyServerErrors(form, err);
      setError(err);
    }
  });
  return (
    <Modal open={open} onClose={onClose} title={title} wide={fields.length > 6}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button onClick={submit} loading={form.formState.isSubmitting}>Save</Button></>}>
      <form onSubmit={submit} className="space-y-4">
        <ErrorNote error={error} />
        <div className="grid gap-4 sm:grid-cols-2">
          {fields.map((f) => {
            const reg = f.type === "select" ? ({} as ReturnType<typeof form.register>) : form.register(f.name, f.required ? { required: `${f.label} is required` } : undefined);
            const span = f.span === 2 || f.type === "textarea" ? "sm:col-span-2" : "";
            if (f.type === "checkbox") return <div key={f.name} className={span}><Checkbox label={f.label} {...reg} /></div>;
            return (
              <Field key={f.name} label={f.label} required={f.required} error={e[f.name]?.message} hint={f.hint} className={span}>
                {f.type === "select" ? (
                  <SelectInput control={form.control} name={f.name as any} options={f.options ?? []} required={f.required} label={f.label} />
                ) : f.type === "state" ? (
                  <Select {...reg}>
                    <option value="">Select state…</option>
                    {GST_STATES.map(([c, n]) => <option key={c} value={c}>{n} ({c})</option>)}
                  </Select>
                ) : f.type === "textarea" ? (
                  <Textarea rows={3} {...reg} />
                ) : (
                  <Input {...reg} inputMode={f.type === "number" ? "decimal" : undefined} className={f.upper ? "uppercase" : undefined} />
                )}
              </Field>
            );
          })}
        </div>
      </form>
    </Modal>
  );
}

/** List + add/edit/delete for a record's child collection (contacts, sites, addresses, bank accounts). */
export function ChildEditor<T extends { id: string; row_version: number }>({ title, noun, rows, columns, fields, basePath, canEdit, onChanged }: {
  title: string;
  noun: string;
  rows: T[];
  columns: Column<T>[];
  fields: FieldDef[];
  basePath: string;
  canEdit: boolean;
  onChanged: () => void;
}) {
  const [editing, setEditing] = useState<T | "new" | null>(null);
  const toast = useToast();
  const confirm = useConfirm();
  const actions: Column<T> = {
    key: "_actions", header: "", className: "w-24 text-right", cell: (r) => canEdit && (
      <div className="flex justify-end gap-1" onClick={(e) => e.stopPropagation()}>
        <Button size="sm" variant="ghost" aria-label="Edit" onClick={() => setEditing(r)}><Pencil className="size-3.5" /></Button>
        <Button size="sm" variant="ghost" aria-label="Delete" onClick={async () => {
          if (!(await confirm({ title: `Delete ${noun}?`, body: "This cannot be undone. The change is recorded in the audit log.", confirmLabel: "Delete" }))) return;
          try {
            await api(`${basePath}/${r.id}`, { method: "DELETE" });
            toast(`${noun.charAt(0).toUpperCase() + noun.slice(1)} deleted`);
            onChanged();
          } catch (e: any) { toast(e.message, "error"); }
        }}><Trash2 className="size-3.5" /></Button>
      </div>
    ),
  };
  return (
    <Card title={title} padded={false} actions={canEdit && <Button size="sm" icon={<Plus className="size-3.5" />} onClick={() => setEditing("new")}>Add {noun}</Button>}>
      <DataTable rows={rows} columns={[...columns, actions]} onRowClick={canEdit ? (r) => setEditing(r) : undefined}
        empty={<EmptyState title={`No ${noun}s yet`} />} />
      <RecordForm
        open={editing !== null}
        title={editing === "new" ? `Add ${noun}` : `Edit ${noun}`}
        fields={fields}
        initial={editing === "new" ? null : editing}
        onClose={() => setEditing(null)}
        onSave={async (values) => {
          if (editing === "new") await api(basePath, { body: values });
          else if (editing) await api(`${basePath}/${editing.id}`, { method: "PUT", body: { ...values, row_version: editing.row_version } });
          toast("Saved");
          setEditing(null);
          onChanged();
        }}
      />
    </Card>
  );
}
