"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { Button, Card, ErrorNote, Field, Input, Textarea } from "@/components/ui";
import { applyServerErrors, clean, SelectInput } from "@/components/forms";
import { CustomerPicker, peopleOptions, SOURCES, useDivisionOptions, usePeople, type CustomerRef } from "@/components/crm/common";
import { ApiError } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";

const EMPTY = {
  title: "", company_name: "", contact_name: "", contact_phone: "", contact_email: "", city: "", source: "phone",
  division_id: "", requirement: "", estimated_value: "", probability: "", expected_closing_date: "", sales_person_id: "",
  notes: "",
};

export function LeadForm({ initial, onSubmit, submitLabel, onCancel }: {
  initial?: Record<string, any>;
  onSubmit: (values: Record<string, any>) => Promise<void>;
  submitLabel: string;
  onCancel?: () => void;
}) {
  const { me } = useAuth();
  const defaults = { ...EMPTY, ...Object.fromEntries(Object.entries(initial ?? {}).filter(([k, v]) => k in EMPTY && v !== null).map(([k, v]) => [k, String(v)])) };
  const form = useForm({ defaultValues: defaults });
  const { register, handleSubmit, formState, control } = form;
  const e = formState.errors as Record<string, { message?: string }>;
  const [error, setError] = useState<unknown>(null);
  const [customer, setCustomer] = useState<CustomerRef | null>(initial?.customer ? { id: initial.customer.id, name: initial.customer.name, code: initial.customer.code, city: initial.customer.city } : null);
  const [mode, setMode] = useState<"existing" | "prospect">(initial && !initial.customer ? "prospect" : initial?.customer ? "existing" : "prospect");
  const sales = usePeople("sales");
  const divisions = useDivisionOptions();
  const ownOnly = me?.permissions["lead.update"] === "own";

  const submit = handleSubmit(async (v) => {
    setError(null);
    const values: Record<string, any> = clean(v);
    if (mode === "existing") {
      if (!customer) return setError(new Error("Choose the customer, or switch to “New prospect”."));
      values.customer_id = customer.id;
      for (const k of ["company_name", "contact_name", "contact_phone", "contact_email", "city"]) values[k] = null;
    } else values.customer_id = null;
    for (const k of ["probability"]) values[k] = values[k] === null ? null : Number(values[k]);
    try {
      await onSubmit(values);
    } catch (err) {
      applyServerErrors(form, err);
      setError(err instanceof ApiError && err.status === 422 && Object.keys(err.fieldErrors()).some((k) => k in EMPTY) ? new Error("Please correct the highlighted fields.") : err);
    }
  });

  return (
    <form onSubmit={submit} className="space-y-5">
      <ErrorNote error={error} />
      <Card title="What does the customer want?">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Title" required error={e.title?.message} className="sm:col-span-2" hint="A short summary, e.g. “LPS for hospital main block”">
            <Input {...register("title", { required: "Title is required" })} />
          </Field>
          <Field label="Requirement details" error={e.requirement?.message} className="sm:col-span-2">
            <Textarea rows={3} {...register("requirement")} />
          </Field>
          <Field label="Business division" error={e.division_id?.message}>
            <SelectInput control={control} name="division_id" options={divisions} />
          </Field>
          <Field label="Source" error={e.source?.message}>
            <SelectInput control={control} name="source" options={SOURCES} />
          </Field>
        </div>
      </Card>

      <Card title="Who is it for?">
        <div className="mb-4 inline-flex rounded-md border border-ink-200 p-0.5 text-sm">
          {(["prospect", "existing"] as const).map((m) => (
            <button key={m} type="button" onClick={() => setMode(m)}
              className={`rounded px-3 py-1.5 ${mode === m ? "bg-brand-600 text-white" : "text-ink-600 hover:bg-ink-100"}`}>
              {m === "prospect" ? "New prospect" : "Existing customer"}
            </button>
          ))}
        </div>
        {mode === "existing" ? (
          <Field label="Customer" required hint="The lead is linked to this customer record — no duplicate is created.">
            <CustomerPicker value={customer} onChange={setCustomer} />
          </Field>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Company / organisation" error={e.company_name?.message}>
              <Input {...register("company_name")} />
            </Field>
            <Field label="Contact person" error={e.contact_name?.message}>
              <Input {...register("contact_name")} />
            </Field>
            <Field label="Phone" error={e.contact_phone?.message}>
              <Input type="tel" inputMode="tel" {...register("contact_phone")} />
            </Field>
            <Field label="Email" error={e.contact_email?.message}>
              <Input type="email" {...register("contact_email")} />
            </Field>
            <Field label="City" error={e.city?.message}>
              <Input {...register("city")} />
            </Field>
            <p className="self-end pb-2 text-xs text-ink-500">When this lead becomes an enquiry, a customer record is made from these details — after checking it doesn’t already exist.</p>
          </div>
        )}
      </Card>

      <Card title="Pipeline">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Estimated value (₹)" error={e.estimated_value?.message}>
            <Input inputMode="decimal" className="num" {...register("estimated_value")} />
          </Field>
          <Field label="Probability (%)" error={e.probability?.message}>
            <Input inputMode="numeric" className="num" {...register("probability", { pattern: { value: /^(100|[1-9]?[0-9])?$/, message: "0 to 100" } })} />
          </Field>
          <Field label="Expected closing" error={e.expected_closing_date?.message}>
            <Input type="date" {...register("expected_closing_date")} />
          </Field>
          <Field label="Salesperson" error={e.sales_person_id?.message} hint={ownOnly ? "Leave blank to own it yourself" : undefined}>
            <SelectInput control={control} name="sales_person_id" options={peopleOptions(sales.data, ownOnly ? "— Me —" : "— Not assigned —")} />
          </Field>
          <Field label="Internal notes" error={e.notes?.message} className="sm:col-span-2 lg:col-span-4">
            <Textarea rows={2} {...register("notes")} />
          </Field>
        </div>
      </Card>

      <div className="flex justify-end gap-2">
        {onCancel && <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>}
        <Button type="submit" loading={formState.isSubmitting}>{submitLabel}</Button>
      </div>
    </form>
  );
}
