"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Button, Card, ErrorNote, Field, Input, Modal, Select, Textarea } from "@/components/ui";
import { applyServerErrors, clean, SelectInput } from "@/components/forms";
import { CustomerPicker, peopleOptions, SOURCES, useDivisionOptions, usePeople, type CustomerRef } from "@/components/crm/common";
import { ApiError } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { GST_STATES } from "@/lib/format";

const EMPTY = {
  title: "", company_name: "", contact_name: "", contact_phone: "", contact_email: "", city: "", source: "phone",
  division_id: "", requirement: "", estimated_value: "", probability: "", expected_closing_date: "", sales_person_id: "",
  notes: "", gstin: "", address_line1: "", state_code: "", pincode: "",
};
// Details that belong to the customer record only (the server writes them to the customer, not the lead).
const CUSTOMER_FIELDS = ["gstin", "address_line1", "state_code", "pincode"] as const;
const NEW_CUSTOMER_FIELDS = ["company_name", "contact_name", "contact_phone", "contact_email", "city", ...CUSTOMER_FIELDS];

type Candidate = { id: string; customer_code: string; customer_name: string; city: string | null; gstin: string | null; reasons: string[] };

export function LeadForm({ initial, onSubmit, submitLabel, onCancel }: {
  initial?: Record<string, any>;
  /** Throw the ApiError on failure; a POSSIBLE_DUPLICATE_CUSTOMER error opens the "is this the same customer?" choice. */
  onSubmit: (values: Record<string, any>, opts: { allowDuplicate: boolean }) => Promise<void>;
  submitLabel: string;
  onCancel?: () => void;
}) {
  const { me } = useAuth();
  const linked = initial?.customer as Record<string, any> | null | undefined;
  // A lead whose customer is still a prospect is edited as "new customer" details (they update that same record).
  const prospectLinked = !!linked?.is_prospect;
  const fromCustomer = prospectLinked ? Object.fromEntries(CUSTOMER_FIELDS.map((k) => [k, linked?.[k] ?? ""])) : {};
  const defaults = {
    ...EMPTY,
    ...Object.fromEntries(Object.entries(initial ?? {}).filter(([k, v]) => k in EMPTY && v !== null).map(([k, v]) => [k, String(v)])),
    ...fromCustomer,
  };
  const form = useForm({ defaultValues: defaults });
  const { register, handleSubmit, formState, control, watch, setValue } = form;
  const e = formState.errors as Record<string, { message?: string }>;
  const [error, setError] = useState<unknown>(null);
  const [customer, setCustomer] = useState<CustomerRef | null>(linked && !prospectLinked ? { id: linked.id, name: linked.name, code: linked.code, city: linked.city } : null);
  const [mode, setMode] = useState<"existing" | "prospect">(linked && !prospectLinked ? "existing" : "prospect");
  const [dups, setDups] = useState<{ values: Record<string, any>; candidates: Candidate[] } | null>(null);
  const [busy, setBusy] = useState(false);
  const sales = usePeople("sales");
  const divisions = useDivisionOptions();
  const ownOnly = me?.permissions["lead.update"] === "own";
  const canCreateCustomer = !!me?.permissions["customer.create"];

  // A valid-looking GSTIN fills the state.
  const gstin = watch("gstin")?.toUpperCase();
  useEffect(() => {
    if (gstin && /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(gstin)) setValue("state_code", gstin.slice(0, 2));
  }, [gstin, setValue]);

  async function send(values: Record<string, any>, allowDuplicate: boolean) {
    setError(null);
    setBusy(true);
    try {
      await onSubmit(values, { allowDuplicate });
      setDups(null);
    } catch (err) {
      if (err instanceof ApiError && err.code === "POSSIBLE_DUPLICATE_CUSTOMER") {
        setDups({ values, candidates: ((err.details as any)?.candidates ?? []) as Candidate[] });
      } else {
        setDups(null);
        applyServerErrors(form, err);
        setError(err);
      }
    } finally {
      setBusy(false);
    }
  }

  const submit = handleSubmit(async (v) => {
    const values: Record<string, any> = clean(v);
    if (mode === "existing") {
      if (!customer) return setError(new Error("Choose the customer, or switch to “New customer”."));
      values.customer_id = customer.id;
      for (const k of NEW_CUSTOMER_FIELDS) values[k] = null;
    } else values.customer_id = null;
    if (values.gstin) values.gstin = String(values.gstin).toUpperCase();
    values.state = values.state_code ? GST_STATES.find(([c]) => c === values.state_code)?.[1] ?? null : null;
    for (const k of ["probability"]) values[k] = values[k] === null ? null : Number(values[k]);
    await send(values, false);
  });

  function pickCandidate(c: Candidate) {
    setMode("existing");
    setCustomer({ id: c.id, name: c.customer_name, code: c.customer_code, city: c.city });
    const values: Record<string, any> = { ...dups!.values, customer_id: c.id };
    for (const k of NEW_CUSTOMER_FIELDS) values[k] = null;
    void send(values, false);
  }

  return (
    <form onSubmit={submit} className="space-y-5">
      <ErrorNote error={error} />
      <Card title="What does the customer want?">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Title" required error={e.title?.message} className="sm:col-span-2" hint="A short summary, e.g. “LPS for hospital main block”">
            <Input {...register("title", { required: "Title is required" })} />
          </Field>
          <Field label="Requirement details" error={e.requirement?.message} className="sm:col-span-2">
            <Textarea rows={3} {...register("requirement")} />
          </Field>
          <Field label="Business division" error={e.division_id?.message}>
            <SelectInput control={control} name="division_id" options={divisions} />
          </Field>
          <Field label="Source" error={e.source?.message}>
            <SelectInput control={control} name="source" options={SOURCES} />
          </Field>
        </div>
      </Card>

      <Card title="Who is it for?">
        <div className="mb-4 inline-flex rounded-md border border-ink-200 p-0.5 text-sm">
          {(["prospect", "existing"] as const).map((m) => (
            <button key={m} type="button" onClick={(ev) => { ev.preventDefault(); setMode(m); }}
              className={`rounded px-3 py-1.5 ${mode === m ? "bg-brand-600 text-white" : "text-ink-600 hover:bg-ink-100"}`}>
              {m === "prospect" ? "New customer" : "Existing customer"}
            </button>
          ))}
        </div>
        {mode === "existing" ? (
          <Field label="Customer" required hint="The lead is linked to this customer record — no duplicate is created.">
            <CustomerPicker value={customer} onChange={setCustomer} />
          </Field>
        ) : (
          <div className="space-y-3">
            {prospectLinked && (
              <p className="rounded-md bg-ink-50 px-3 py-2 text-sm text-ink-700">
                Saved as customer <b>{linked?.code}</b> (prospect). Changes here update that customer record.
              </p>
            )}
            {!prospectLinked && !canCreateCustomer && (
              <p className="rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-800">You cannot add new customers. Choose “Existing customer”, or ask a manager.</p>
            )}
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Company / organisation" error={e.company_name?.message}>
                <Input {...register("company_name")} />
              </Field>
              <Field label="Contact person" error={e.contact_name?.message}>
                <Input {...register("contact_name")} />
              </Field>
              <Field label="Phone" error={e.contact_phone?.message}>
                <Input type="tel" inputMode="tel" {...register("contact_phone")} />
              </Field>
              <Field label="Email" error={e.contact_email?.message}>
                <Input type="email" {...register("contact_email")} />
              </Field>
              <Field label="Address" error={e.address_line1?.message} className="sm:col-span-2">
                <Input {...register("address_line1")} />
              </Field>
              <Field label="City" error={e.city?.message}>
                <Input {...register("city")} />
              </Field>
              <Field label="State" error={e.state_code?.message}>
                <Select {...register("state_code")}>
                  <option value="">Select state…</option>
                  {GST_STATES.map(([code, name]) => <option key={code} value={code}>{name}</option>)}
                </Select>
              </Field>
              <Field label="PIN code" error={e.pincode?.message}>
                <Input inputMode="numeric" maxLength={6} {...register("pincode")} />
              </Field>
              <Field label="GSTIN" error={e.gstin?.message} hint="If known. A customer with the same GSTIN is used instead of adding a new one.">
                <Input className="uppercase" maxLength={15} {...register("gstin")} />
              </Field>
            </div>
            {!prospectLinked && (
              <p className="text-xs text-ink-500">These details are saved as a customer record with its own customer code (marked “prospect” until the GSTIN and other details are completed), so you can use it again for enquiries and quotations. Existing customers are checked first.</p>
            )}
          </div>
        )}
      </Card>

      <Card title="Pipeline">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Estimated value (₹)" error={e.estimated_value?.message}>
            <Input inputMode="decimal" className="num" {...register("estimated_value")} />
          </Field>
          <Field label="Probability (%)" error={e.probability?.message}>
            <Input inputMode="numeric" className="num" {...register("probability", { pattern: { value: /^(100|[1-9]?[0-9])?$/, message: "0 to 100" } })} />
          </Field>
          <Field label="Expected closing" error={e.expected_closing_date?.message}>
            <Input type="date" {...register("expected_closing_date")} />
          </Field>
          <Field label="Salesperson" error={e.sales_person_id?.message} hint={ownOnly ? "Leave blank to own it yourself" : undefined}>
            <SelectInput control={control} name="sales_person_id" options={peopleOptions(sales.data, ownOnly ? "— Me —" : "— Not assigned —")} />
          </Field>
          <Field label="Internal notes" error={e.notes?.message} className="sm:col-span-2 lg:col-span-4">
            <Textarea rows={2} {...register("notes")} />
          </Field>
        </div>
      </Card>

      <div className="flex justify-end gap-2">
        {onCancel && <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>}
        <Button type="submit" loading={busy || formState.isSubmitting}>{submitLabel}</Button>
      </div>

      <Modal open={!!dups} onClose={() => setDups(null)} title="Is this an existing customer?" wide>
        {dups && (
          <div className="space-y-4">
            <p className="text-sm text-ink-700">A customer that looks the same is already saved. Use it so the customer is not duplicated:</p>
            <ul className="divide-y divide-ink-100 rounded-md border border-ink-200">
              {dups.candidates.map((d) => (
                <li key={d.id} className="flex flex-col gap-2 px-3 py-2.5 sm:flex-row sm:items-center">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium">{d.customer_name} <span className="text-ink-500">· {d.customer_code}</span></p>
                    <p className="text-xs text-ink-500">{[d.city, d.gstin, d.reasons.join(", ")].filter(Boolean).join(" · ")}</p>
                  </div>
                  <Button type="button" size="sm" loading={busy} onClick={(ev) => { ev.preventDefault(); pickCandidate(d); }}>Use this customer</Button>
                </li>
              ))}
            </ul>
            <div className="flex flex-col-reverse justify-between gap-2 sm:flex-row">
              <Button type="button" variant="secondary" onClick={(ev) => { ev.preventDefault(); setDups(null); }}>Back to the form</Button>
              <Button type="button" variant="secondary" loading={busy} onClick={(ev) => { ev.preventDefault(); void send(dups.values, true); }}>No — save as a new customer</Button>
            </div>
          </div>
        )}
      </Modal>
    </form>
  );
}
