"use client";

import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, X } from "lucide-react";
import { Badge, Button, Field, Modal, Select, Textarea } from "@/components/ui";
import { api, type Page } from "@/lib/api/client";
import { titleCase } from "@/lib/format";

type Tone = "green" | "red" | "grey" | "amber" | "blue";

export const LEAD_STATUSES: [string, string, Tone][] = [
  ["new", "New", "blue"], ["contacted", "Contacted", "blue"], ["qualified", "Qualified", "amber"],
  ["site_visit", "Site visit", "amber"], ["quotation", "Quotation", "amber"], ["negotiation", "Negotiation", "amber"],
  ["won", "Won", "green"], ["lost", "Lost", "grey"],
];
export const ENQUIRY_STATUSES: [string, string, Tone][] = [
  ["open", "Open", "blue"], ["site_visit", "Site visit", "amber"], ["evaluation", "Technical evaluation", "amber"],
  ["quoted", "Quoted", "amber"], ["won", "Won", "green"], ["lost", "Lost", "grey"], ["cancelled", "Cancelled", "grey"],
];
export const VISIT_STATUSES: [string, string, Tone][] = [
  ["scheduled", "Scheduled", "blue"], ["completed", "Completed", "green"], ["cancelled", "Cancelled", "grey"],
];
export const SOURCES: [string, string][] = [
  ["phone", "Phone call"], ["email", "Email"], ["whatsapp", "WhatsApp"], ["website", "Website"], ["walk_in", "Walk-in"],
  ["referral", "Referral"], ["existing_customer", "Existing customer"], ["exhibition", "Exhibition"],
  ["social_media", "Social media"], ["tender", "Tender"], ["other", "Other"],
];
export const PRIORITIES: [string, string][] = [["low", "Low"], ["normal", "Normal"], ["high", "High"], ["urgent", "Urgent"]];

const SETS = { lead: LEAD_STATUSES, enquiry: ENQUIRY_STATUSES, visit: VISIT_STATUSES };

export function CrmStatus({ kind, status }: { kind: keyof typeof SETS; status: string }) {
  const s = SETS[kind].find(([v]) => v === status);
  return <Badge tone={s?.[2] ?? "grey"}>{s?.[1] ?? titleCase(status)}</Badge>;
}

export const sourceLabel = (s: string | null | undefined) => (s ? SOURCES.find(([v]) => v === s)?.[1] ?? titleCase(s) : "—");

export function PriorityBadge({ priority }: { priority: string }) {
  if (priority === "normal") return null;
  return <Badge tone={priority === "urgent" ? "red" : priority === "high" ? "amber" : "grey"}>{titleCase(priority)}</Badge>;
}

/** Active users for pickers: "sales" (Sales/Managers/Directors), "engineer" (engineers/PMs/managers) or "any". */
export function usePeople(kind: "sales" | "engineer" | "any", enabled = true) {
  return useQuery({
    queryKey: ["/crm/people", kind],
    queryFn: () => api<{ data: { id: string; name: string }[] }>("/crm/people", { params: { kind } }),
    select: (r) => r.data,
    staleTime: 5 * 60_000,
    enabled,
  });
}

export const peopleOptions = (rows: { id: string; name: string }[] | undefined, blank = "— Not assigned —"): [string, string][] =>
  [["", blank], ...(rows ?? []).map((p) => [p.id, p.name] as [string, string])];

export function useDivisionOptions() {
  const q = useQuery({
    queryKey: ["/divisions", "options"],
    queryFn: () => api<Page<any>>("/divisions", { params: { page_size: 200, is_active: true } }),
    select: (r) => r.data,
    staleTime: 5 * 60_000,
  });
  return [["", "—"], ...(q.data ?? []).map((d: any) => [d.id, d.name] as [string, string])] as [string, string][];
}

export type CustomerRef = { id: string; name: string; code?: string; city?: string | null };

/** Search-as-you-type customer picker (the customer list can be long, so it is not a plain dropdown). */
export function CustomerPicker({ value, onChange, invalid, disabled, placeholder = "Search customer by name, code, phone…" }: {
  value: CustomerRef | null;
  onChange: (c: CustomerRef | null) => void;
  invalid?: boolean;
  disabled?: boolean;
  placeholder?: string;
}) {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [debounced, setDebounced] = useState("");
  const box = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(q.trim()), 200);
    return () => clearTimeout(t);
  }, [q]);
  useEffect(() => {
    const close = (e: MouseEvent) => box.current && !box.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);
  const results = useQuery({
    queryKey: ["/customers", "picker", debounced],
    queryFn: () => api<Page<any>>("/customers", { params: { q: debounced, page_size: 8, status: "active" } }),
    enabled: open,
  });

  if (value)
    return (
      <div className="flex h-9 items-center justify-between gap-2 rounded-md border border-ink-200 bg-ink-50 px-3 text-sm">
        <span className="truncate">
          <span className="font-medium text-ink-900">{value.name}</span>
          {value.code && <span className="text-ink-500"> · {value.code}</span>}
          {value.city && <span className="text-ink-500"> · {value.city}</span>}
        </span>
        {!disabled && (
          <button type="button" onClick={(e) => { e.preventDefault(); onChange(null); }} className="rounded p-0.5 text-ink-400 hover:bg-ink-200 hover:text-ink-700" aria-label="Change customer">
            <X className="size-4" />
          </button>
        )}
      </div>
    );
  return (
    <div ref={box} className="relative">
      <Search className="pointer-events-none absolute left-2.5 top-2.5 size-4 text-ink-400" />
      <input
        value={q}
        disabled={disabled}
        onChange={(e) => { setQ(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        placeholder={placeholder}
        className={`h-9 w-full rounded-md border bg-white pl-8 pr-3 text-sm shadow-xs focus:border-brand-600 focus:outline-none focus:ring-2 focus:ring-brand-100 ${invalid ? "border-brand-500" : "border-ink-200"}`}
      />
      {open && (
        <ul className="absolute z-30 mt-1 max-h-72 w-full overflow-y-auto rounded-md border border-ink-200 bg-white py-1 shadow-lg">
          {results.isLoading && <li className="px-3 py-2 text-sm text-ink-500">Searching…</li>}
          {results.data?.data.length === 0 && <li className="px-3 py-2 text-sm text-ink-500">No customers found.</li>}
          {results.data?.data.map((c: any) => (
            <li key={c.id}>
              <button
                type="button"
                className="w-full px-3 py-2 text-left text-sm hover:bg-brand-50"
                onClick={(e) => { e.preventDefault(); onChange({ id: c.id, name: c.customer_name, code: c.customer_code, city: c.city }); setQ(""); setOpen(false); }}
              >
                <span className="font-medium text-ink-900">{c.customer_name}</span>
                <span className="block text-xs text-ink-500">{[c.customer_code, c.city, c.phone, c.is_prospect ? "Prospect" : null].filter(Boolean).join(" · ")}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/** Sites and contacts of the chosen customer, for dependent dropdowns. */
export function useCustomerDetail(customerId: string | null | undefined) {
  return useQuery({
    queryKey: ["/customers", customerId],
    queryFn: () => api<{ data: any }>(`/customers/${customerId}`),
    select: (r) => r.data,
    enabled: !!customerId,
  });
}

/** Change a status; asks for the reason when marking Lost. */
export function StatusDialog({ open, onClose, statuses, current, onSubmit, title }: {
  open: boolean;
  onClose: () => void;
  statuses: [string, string, Tone][];
  current: string;
  onSubmit: (status: string, lostReason: string | null) => Promise<void>;
  title: string;
}) {
  const [status, setStatus] = useState(current);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => { if (open) { setStatus(current); setReason(""); setError(null); } }, [open, current]);
  return (
    <Modal open={open} onClose={onClose} title={title}
      footer={<>
        <Button variant="secondary" onClick={onClose}>Cancel</Button>
        <Button loading={busy} disabled={status === current} onClick={async () => {
          if (status === "lost" && !reason.trim()) return setError("Say why it was lost.");
          setBusy(true);
          try { await onSubmit(status, status === "lost" ? reason.trim() : null); onClose(); }
          catch (e: any) { setError(e.message); }
          finally { setBusy(false); }
        }}>Save</Button>
      </>}>
      <div className="space-y-4">
        <Field label="Status">
          <Select value={status} onChange={(e) => setStatus(e.target.value)}>
            {statuses.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
        </Field>
        {status === "lost" && (
          <Field label="Why was it lost?" required error={error ?? undefined} hint="Price, competitor, budget, timing… This feeds the win/loss report.">
            <Textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} maxLength={300} />
          </Field>
        )}
        {error && status !== "lost" && <p className="text-sm text-brand-700">{error}</p>}
      </div>
    </Modal>
  );
}

/** Small stat tile used on CRM lists and the dashboard. */
export function MiniStat({ label, value, tone = "ink", onClick, active }: { label: string; value: number | string | undefined; tone?: "ink" | "red" | "amber"; onClick?: () => void; active?: boolean }) {
  const color = tone === "red" ? "text-brand-700" : tone === "amber" ? "text-amber-700" : "text-ink-900";
  return (
    <button type="button" onClick={onClick} disabled={!onClick}
      className={`rounded-lg border bg-white px-4 py-3 text-left transition-colors ${active ? "border-brand-400 ring-2 ring-brand-100" : "border-ink-200"} ${onClick ? "hover:border-brand-300" : "cursor-default"}`}>
      <p className="text-xs text-ink-500">{label}</p>
      <p className={`num mt-1 text-2xl font-semibold tracking-tight ${color}`}>{value ?? "–"}</p>
    </button>
  );
}
