"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { Button, Card, ErrorNote, Field, Input, Textarea } from "@/components/ui";
import { applyServerErrors, clean, SelectInput } from "@/components/forms";
import {
  CustomerPicker,
  peopleOptions,
  PRIORITIES,
  SOURCES,
  useCustomerDetail,
  useDivisionOptions,
  usePeople,
  type CustomerRef,
} from "@/components/crm/common";
import { ApiError } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";

const EMPTY = {
  subject: "", description: "", site_id: "", contact_id: "", division_id: "", enquiry_date: "", required_by: "",
  source: "", priority: "normal", estimated_value: "", sales_person_id: "",
};

export function EnquiryForm({ initial, onSubmit, submitLabel, onCancel, customerLocked }: {
  initial?: Record<string, any>;
  onSubmit: (values: Record<string, any>) => Promise<void>;
  submitLabel: string;
  onCancel?: () => void;
  customerLocked?: boolean;
}) {
  const { me } = useAuth();
  const defaults = { ...EMPTY, ...Object.fromEntries(Object.entries(initial ?? {}).filter(([k, v]) => k in EMPTY && v !== null).map(([k, v]) => [k, String(v)])) };
  const form = useForm({ defaultValues: defaults });
  const { register, handleSubmit, formState, control } = form;
  const e = formState.errors as Record<string, { message?: string }>;
  const [error, setError] = useState<unknown>(null);
  const [customer, setCustomer] = useState<CustomerRef | null>(initial?.customer ? { id: initial.customer.id, name: initial.customer.name, code: initial.customer.code, city: initial.customer.city } : null);
  const detail = useCustomerDetail(customer?.id);
  const sales = usePeople("sales");
  const divisions = useDivisionOptions();
  const ownOnly = me?.permissions["enquiry.update"] === "own";
  const sites: [string, string][] = [["", "— No specific site —"], ...(detail.data?.sites ?? []).filter((s: any) => s.is_active || s.id === defaults.site_id).map((s: any) => [s.id, [s.site_name, s.city].filter(Boolean).join(", ")] as [string, string])];
  const contacts: [string, string][] = [["", "—"], ...(detail.data?.contacts ?? []).filter((c: any) => c.is_active || c.id === defaults.contact_id).map((c: any) => [c.id, [c.name, c.designation].filter(Boolean).join(" · ")] as [string, string])];

  const submit = handleSubmit(async (v) => {
    setError(null);
    if (!customer) return setError(new Error("Choose the customer."));
    const values: Record<string, any> = { ...clean(v), customer_id: customer.id, lead_id: initial?.lead_id ?? null };
    try {
      await onSubmit(values);
    } catch (err) {
      applyServerErrors(form, err);
      setError(err);
    }
  });

  return (
    <form onSubmit={submit} className="space-y-5">
      <ErrorNote error={error} />
      <Card title="Customer">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Customer" required className="sm:col-span-2" hint={customerLocked ? "The customer cannot change once site visits are recorded." : undefined}>
            <CustomerPicker value={customer} disabled={customerLocked} onChange={(c) => { setCustomer(c); form.setValue("site_id", ""); form.setValue("contact_id", ""); }} />
          </Field>
          <Field label="Site" error={e.site_id?.message} hint={customer && !detail.data?.sites?.length ? "This customer has no sites yet — add them on the customer record." : undefined}>
            <SelectInput control={control} name="site_id" options={sites} disabled={!customer} />
          </Field>
          <Field label="Contact person" error={e.contact_id?.message}>
            <SelectInput control={control} name="contact_id" options={contacts} disabled={!customer} />
          </Field>
        </div>
      </Card>
      <Card title="Enquiry">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Subject" required error={e.subject?.message} className="sm:col-span-2 lg:col-span-4">
            <Input {...register("subject", { required: "Subject is required" })} />
          </Field>
          <Field label="Description / scope" error={e.description?.message} className="sm:col-span-2 lg:col-span-4">
            <Textarea rows={4} {...register("description")} />
          </Field>
          <Field label="Enquiry date" error={e.enquiry_date?.message} hint="Blank = today">
            <Input type="date" {...register("enquiry_date")} />
          </Field>
          <Field label="Required by" error={e.required_by?.message}>
            <Input type="date" {...register("required_by")} />
          </Field>
          <Field label="Priority" error={e.priority?.message}>
            <SelectInput control={control} name="priority" options={PRIORITIES} />
          </Field>
          <Field label="Source" error={e.source?.message}>
            <SelectInput control={control} name="source" options={[["", "—"], ...SOURCES]} />
          </Field>
          <Field label="Business division" error={e.division_id?.message}>
            <SelectInput control={control} name="division_id" options={divisions} />
          </Field>
          <Field label="Estimated value (₹)" error={e.estimated_value?.message}>
            <Input inputMode="decimal" className="num" {...register("estimated_value")} />
          </Field>
          <Field label="Salesperson" error={e.sales_person_id?.message} className="sm:col-span-2">
            <SelectInput control={control} name="sales_person_id" options={peopleOptions(sales.data, ownOnly ? "— Me —" : "— Not assigned —")} />
          </Field>
        </div>
      </Card>
      <div className="flex justify-end gap-2">
        {onCancel && <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>}
        <Button type="submit" loading={formState.isSubmitting}>{submitLabel}</Button>
      </div>
    </form>
  );
}
