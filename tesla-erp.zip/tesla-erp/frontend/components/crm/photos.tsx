"use client";

import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Camera, ImagePlus, Trash2 } from "lucide-react";
import { Button, Card, EmptyState, Spinner, useConfirm, useToast } from "@/components/ui";
import { api, objectUrl } from "@/lib/api/client";

type Doc = { id: string; file_name: string; category: string; content_type: string; title: string | null };

/** Phone photos are 3–8 MB. Shrink to ≤ 1600 px JPEG in the browser before upload: faster on mobile data,
 *  and still plenty for a report. Files the browser cannot decode (e.g. some HEIC) are sent unchanged. */
async function compress(file: File): Promise<File> {
  if (!file.type.startsWith("image/") || file.size < 400_000) return file;
  try {
    const bitmap = await createImageBitmap(file, { imageOrientation: "from-image" } as ImageBitmapOptions);
    const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bitmap.width * scale);
    canvas.height = Math.round(bitmap.height * scale);
    canvas.getContext("2d")!.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/jpeg", 0.82));
    if (!blob || blob.size >= file.size) return file;
    return new File([blob], file.name.replace(/\.[^.]+$/, "") + ".jpg", { type: "image/jpeg" });
  } catch {
    return file;
  }
}

function Thumb({ doc, onOpen }: { doc: Doc; onOpen: (url: string) => void }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let u: string | null = null;
    objectUrl(`/documents/${doc.id}/content?inline=true`).then((x) => { u = x; setUrl(x); }).catch(() => setUrl(null));
    return () => { if (u) URL.revokeObjectURL(u); };
  }, [doc.id]);
  return (
    <button type="button" onClick={() => url && onOpen(url)} className="block aspect-[4/3] w-full overflow-hidden rounded-md border border-ink-200 bg-ink-100">
      {url ? <img src={url} alt={doc.file_name} className="size-full object-cover" /> : <span className="flex size-full items-center justify-center text-xs text-ink-400">…</span>}
    </button>
  );
}

export function PhotoPanel({ visitId, canEdit }: { visitId: string; canEdit: boolean }) {
  const key = ["/documents", "site_visit", visitId];
  const { data, isLoading } = useQuery({
    queryKey: key,
    queryFn: () => api<{ data: Doc[] }>("/documents", { params: { entity_type: "site_visit", entity_id: visitId } }),
    select: (r) => r.data.filter((d) => d.category === "site_photo" && d.content_type.startsWith("image/")),
  });
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const camera = useRef<HTMLInputElement>(null);
  const gallery = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [viewer, setViewer] = useState<string | null>(null);

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    const list = Array.from(files);
    try {
      for (const [i, f] of list.entries()) {
        setBusy(`Uploading ${i + 1} of ${list.length}…`);
        const form = new FormData();
        form.append("entity_type", "site_visit");
        form.append("entity_id", visitId);
        form.append("category", "site_photo");
        form.append("file", await compress(f));
        await api("/documents", { method: "POST", form });
      }
      toast(list.length === 1 ? "Photo added" : `${list.length} photos added`);
    } catch (e: any) {
      toast(e.message ?? "Upload failed — check the connection and try again.", "error");
    } finally {
      setBusy(null);
      qc.invalidateQueries({ queryKey: key });
      for (const r of [camera, gallery]) if (r.current) r.current.value = "";
    }
  }

  return (
    <Card title={`Photos${data?.length ? ` (${data.length})` : ""}`}
      actions={canEdit && (
        <div className="flex gap-2">
          <Button size="sm" icon={<Camera className="size-3.5" />} loading={!!busy} onClick={() => camera.current?.click()}>Take photo</Button>
          <Button size="sm" variant="secondary" icon={<ImagePlus className="size-3.5" />} disabled={!!busy} onClick={() => gallery.current?.click()}>From gallery</Button>
          <input ref={camera} type="file" accept="image/*" capture="environment" className="sr-only" onChange={(e) => upload(e.target.files)} />
          <input ref={gallery} type="file" accept="image/jpeg,image/png,image/webp,image/heic" multiple className="sr-only" onChange={(e) => upload(e.target.files)} />
        </div>
      )}>
      {busy && <p className="mb-3 text-sm text-ink-600">{busy}</p>}
      {isLoading ? <Spinner /> : !data?.length ? (
        <EmptyState icon={<Camera className="size-8" />} title="No photos yet" body="Photos are shrunk on the phone before upload and appear on the visit report." />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {data.map((d) => (
            <div key={d.id} className="group relative">
              <Thumb doc={d} onOpen={setViewer} />
              {canEdit && (
                <button type="button" aria-label="Remove photo" className="absolute right-1.5 top-1.5 rounded bg-white/90 p-1 text-ink-500 shadow-sm hover:text-brand-700"
                  onClick={async () => {
                    if (!(await confirm({ title: "Remove photo?", body: "It is removed from the visit and the report. The file is kept in storage for recovery.", confirmLabel: "Remove" }))) return;
                    await api(`/documents/${d.id}`, { method: "DELETE" });
                    qc.invalidateQueries({ queryKey: key });
                  }}>
                  <Trash2 className="size-3.5" />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
      {viewer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4" onClick={() => setViewer(null)}>
          <img src={viewer} alt="" className="max-h-full max-w-full rounded" />
        </div>
      )}
    </Card>
  );
}
