"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AlarmClock, CheckCircle2, Mail, MessageCircle, Phone, StickyNote, Trash2, Users } from "lucide-react";
import { Badge, Button, Card, EmptyState, ErrorNote, Field, Input, Modal, Spinner, Textarea, useConfirm, useToast } from "@/components/ui";
import { applyServerErrors, clean, SelectInput } from "@/components/forms";
import { peopleOptions, usePeople } from "@/components/crm/common";
import { api } from "@/lib/api/client";
import { useAuth } from "@/lib/auth";
import { dateTime } from "@/lib/format";

export const KINDS: [string, string][] = [["call", "Call"], ["meeting", "Meeting"], ["email", "Email"], ["whatsapp", "WhatsApp"], ["note", "Note"]];
const ICON: Record<string, typeof Phone> = { call: Phone, meeting: Users, email: Mail, whatsapp: MessageCircle, note: StickyNote, follow_up: AlarmClock };

export type Activity = {
  id: string; kind: string; subject: string; notes: string | null; activity_at: string; due_at: string | null;
  assigned_to: string | null; assigned_to_id: string | null; done_at: string | null; done_by: string | null; outcome: string | null;
  created_by: string | null; created_by_id: string | null; enquiry_id: string | null; lead_id: string | null;
  parent?: { type: string; number: string; title: string; party?: string; href: string };
};

/** Local date-time for <input type="datetime-local">, in IST. */
function localInput(d: Date) {
  const ist = new Date(d.getTime() + 5.5 * 3600_000);
  return ist.toISOString().slice(0, 16);
}

export function isOverdue(a: Activity) {
  return !a.done_at && a.due_at && new Date(a.due_at).getTime() < Date.now();
}

export function DoneButton({ a, onDone }: { a: Activity; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [outcome, setOutcome] = useState("");
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  return (
    <>
      <Button size="sm" variant="secondary" icon={<CheckCircle2 className="size-3.5" />} onClick={() => { setOutcome(""); setOpen(true); }}>Done</Button>
      <Modal open={open} onClose={() => setOpen(false)} title="Mark follow-up done"
        footer={<><Button variant="secondary" onClick={() => setOpen(false)}>Cancel</Button>
          <Button loading={busy} onClick={async () => {
            setBusy(true);
            try { await api(`/crm/activities/${a.id}/done`, { body: { outcome: outcome.trim() || null } }); toast("Follow-up done"); setOpen(false); onDone(); }
            catch (e: any) { toast(e.message, "error"); } finally { setBusy(false); }
          }}>Mark done</Button></>}>
        <p className="mb-3 text-sm text-ink-700">{a.subject}</p>
        <Field label="Outcome (optional)" hint="e.g. Survey fixed for Monday; Sent revised offer"><Input value={outcome} onChange={(e) => setOutcome(e.target.value)} maxLength={300} /></Field>
      </Modal>
    </>
  );
}

export function ActivityPanel({ leadId, enquiryId, canEdit }: { leadId?: string; enquiryId?: string; canEdit: boolean }) {
  const { me } = useAuth();
  const params = leadId ? { lead_id: leadId } : { enquiry_id: enquiryId };
  const key = ["/crm/activities", params];
  const { data, isLoading } = useQuery({ queryKey: key, queryFn: () => api<{ data: Activity[] }>("/crm/activities", { params }), select: (r) => r.data });
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [adding, setAdding] = useState<"activity" | "follow_up" | null>(null);
  const refresh = () => { qc.invalidateQueries({ queryKey: ["/crm/activities"] }); qc.invalidateQueries({ queryKey: ["/crm/follow-ups"] }); qc.invalidateQueries({ queryKey: ["/crm/summary"] }); };
  const open = (data ?? []).filter((a) => a.kind === "follow_up" && !a.done_at).sort((a, b) => (a.due_at ?? "").localeCompare(b.due_at ?? ""));
  const history = (data ?? []).filter((a) => !(a.kind === "follow_up" && !a.done_at));

  return (
    <div className="space-y-4">
      <Card title="Open follow-ups" padded={false}
        actions={canEdit && <div className="flex gap-2">
          <Button size="sm" variant="secondary" onClick={() => setAdding("activity")}>Log activity</Button>
          <Button size="sm" icon={<AlarmClock className="size-3.5" />} onClick={() => setAdding("follow_up")}>Add follow-up</Button>
        </div>}>
        {isLoading ? <Spinner /> : open.length === 0 ? <EmptyState title="No open follow-ups" body="Add one so the next step isn't forgotten." /> : (
          <ul className="divide-y divide-ink-100">
            {open.map((a) => (
              <li key={a.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                <AlarmClock className={`size-4 ${isOverdue(a) ? "text-brand-600" : "text-ink-400"}`} />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-ink-900">{a.subject}</p>
                  <p className="text-xs text-ink-500">
                    Due {dateTime(a.due_at)}{a.assigned_to && ` · ${a.assigned_to}`}
                    {isOverdue(a) && <span className="ml-2"><Badge tone="red">Overdue</Badge></span>}
                  </p>
                  {a.notes && <p className="mt-1 whitespace-pre-line text-sm text-ink-600">{a.notes}</p>}
                </div>
                {(canEdit || a.assigned_to_id === me?.id) && <DoneButton a={a} onDone={refresh} />}
              </li>
            ))}
          </ul>
        )}
      </Card>
      <Card title="Activity" padded={false}>
        {isLoading ? <Spinner /> : history.length === 0 ? <EmptyState title="No activity logged yet" /> : (
          <ol className="divide-y divide-ink-100">
            {history.map((a) => {
              const Icon = ICON[a.kind] ?? StickyNote;
              const mine = a.created_by_id === me?.id;
              return (
                <li key={a.id} className="flex gap-3 px-4 py-3">
                  <Icon className="mt-0.5 size-4 shrink-0 text-ink-400" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm"><span className="font-medium text-ink-900">{a.subject}</span>
                      {a.kind === "follow_up" && <span className="ml-2"><Badge tone="green">Follow-up done</Badge></span>}
                      {a.enquiry_id && leadId && <span className="ml-2"><Badge>Enquiry</Badge></span>}
                    </p>
                    <p className="text-xs text-ink-500">
                      {a.kind === "follow_up" ? `Done ${dateTime(a.done_at)} by ${a.done_by ?? "—"}` : `${dateTime(a.activity_at)} · ${a.created_by ?? "—"}`}
                    </p>
                    {a.notes && <p className="mt-1 whitespace-pre-line text-sm text-ink-700">{a.notes}</p>}
                    {a.outcome && <p className="mt-1 text-sm text-ink-700"><span className="text-ink-500">Outcome:</span> {a.outcome}</p>}
                  </div>
                  {(canEdit || mine) && (
                    <Button size="sm" variant="ghost" aria-label="Delete" onClick={async () => {
                      if (!(await confirm({ title: "Delete this entry?", body: "It is removed from the timeline. The deletion is recorded in the audit log.", confirmLabel: "Delete" }))) return;
                      try { await api(`/crm/activities/${a.id}`, { method: "DELETE" }); refresh(); } catch (e: any) { toast(e.message, "error"); }
                    }}><Trash2 className="size-4 text-ink-400" /></Button>
                  )}
                </li>
              );
            })}
          </ol>
        )}
      </Card>
      <AddActivity mode={adding} onClose={() => setAdding(null)} parent={params} onSaved={() => { setAdding(null); refresh(); }} />
    </div>
  );
}

function AddActivity({ mode, onClose, parent, onSaved }: { mode: "activity" | "follow_up" | null; onClose: () => void; parent: Record<string, string | undefined>; onSaved: () => void }) {
  const { me } = useAuth();
  const people = usePeople("any", mode === "follow_up");
  const form = useForm({ defaultValues: { kind: "call", subject: "", notes: "", activity_at: "", due_at: "", assigned_to_id: "" } });
  useEffect(() => {
    if (!mode) return;
    // Tomorrow's date *in India*, at 10:00 IST (= 04:30 UTC).
    const tomorrow = new Date(Date.now() + 5.5 * 3600_000 + 86400_000);
    tomorrow.setUTCHours(4, 30, 0, 0);
    form.reset({ kind: "call", subject: "", notes: "", activity_at: localInput(new Date()), due_at: localInput(tomorrow), assigned_to_id: me?.id ?? "" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode]);
  const [error, setError] = useState<unknown>(null);
  const e = form.formState.errors as Record<string, { message?: string }>;
  const submit = form.handleSubmit(async (v) => {
    setError(null);
    const values: Record<string, any> = clean(v);
    const body: Record<string, any> = { ...parent, subject: values.subject, notes: values.notes };
    if (mode === "follow_up") Object.assign(body, { kind: "follow_up", due_at: `${values.due_at}:00+05:30`, assigned_to_id: values.assigned_to_id });
    else Object.assign(body, { kind: values.kind, activity_at: `${values.activity_at}:00+05:30` });
    try { await api("/crm/activities", { body }); onSaved(); }
    catch (err) { applyServerErrors(form, err); setError(err); }
  });
  return (
    <Modal open={mode !== null} onClose={onClose} title={mode === "follow_up" ? "Add follow-up" : "Log activity"}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={form.formState.isSubmitting} onClick={submit}>Save</Button></>}>
      <form onSubmit={submit} className="space-y-4">
        <ErrorNote error={error} />
        {mode === "activity" && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Type"><SelectInput control={form.control} name="kind" options={KINDS} /></Field>
            <Field label="When"><Input type="datetime-local" {...form.register("activity_at")} /></Field>
          </div>
        )}
        <Field label={mode === "follow_up" ? "What needs doing" : "Summary"} required error={e.subject?.message}>
          <Input {...form.register("subject", { required: "Required" })} placeholder={mode === "follow_up" ? "e.g. Call to fix survey date" : "e.g. Discussed scope with Mr. Joseph"} />
        </Field>
        {mode === "follow_up" && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Due" required><Input type="datetime-local" {...form.register("due_at", { required: "Required" })} /></Field>
            <Field label="Assigned to"><SelectInput control={form.control} name="assigned_to_id" options={peopleOptions(people.data, "— Me —")} /></Field>
          </div>
        )}
        <Field label="Notes"><Textarea rows={3} {...form.register("notes")} /></Field>
      </form>
    </Modal>
  );
}
