"use client";

import { useEffect, useRef, useState } from "react";
import { useFieldArray, useForm } from "react-hook-form";
import { useQuery } from "@tanstack/react-query";
import { Crosshair, History, Plus, Trash2, WifiOff } from "lucide-react";
import { Button, Card, ErrorNote, Field, Input, Textarea } from "@/components/ui";
import { applyServerErrors, clean, SelectInput } from "@/components/forms";
import { CustomerPicker, peopleOptions, useCustomerDetail, usePeople, type CustomerRef } from "@/components/crm/common";
import { api, ApiError } from "@/lib/api/client";
import { dateTime } from "@/lib/format";

type Measurement = { label: string; value: string; unit: string };
type Values = {
  site_id: string; site_location: string; visit_date: string; visit_time: string; engineer_id: string; purpose: string;
  observations: string; requirements: string; recommendations: string; measurements: Measurement[];
  customer_rep_name: string; customer_rep_designation: string; customer_rep_phone: string; follow_up_date: string;
  latitude: string; longitude: string; location_accuracy_m: string;
};

const todayIST = () => new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" });
const UNITS = ["m", "m²", "mm", "Ω", "V", "A", "kW", "kVA", "nos", "%"];

function toValues(v?: Record<string, any>): Values {
  const s = (x: any) => (x === null || x === undefined ? "" : String(x));
  return {
    site_id: s(v?.site_id), site_location: s(v?.site_location), visit_date: s(v?.visit_date) || todayIST(),
    visit_time: s(v?.visit_time), engineer_id: s(v?.engineer_id), purpose: s(v?.purpose), observations: s(v?.observations),
    requirements: s(v?.requirements), recommendations: s(v?.recommendations),
    measurements: (v?.measurements ?? []).map((m: any) => ({ label: s(m.label), value: s(m.value), unit: s(m.unit) })),
    customer_rep_name: s(v?.customer_rep_name), customer_rep_designation: s(v?.customer_rep_designation),
    customer_rep_phone: s(v?.customer_rep_phone), follow_up_date: s(v?.follow_up_date), latitude: s(v?.latitude),
    longitude: s(v?.longitude), location_accuracy_m: s(v?.location_accuracy_m),
  };
}

// Drafts live in this browser only (localStorage). Sites often have no signal: nothing typed is lost if the save
// fails, the tab is closed or the phone locks. Photos are uploaded separately once the visit exists.
const DRAFT_PREFIX = "tce:visit-draft:";
type Draft = { savedAt: string; values: Values; customer: CustomerRef | null };
function readDraft(key: string): Draft | null {
  try { const raw = localStorage.getItem(DRAFT_PREFIX + key); return raw ? JSON.parse(raw) : null; } catch { return null; }
}
function writeDraft(key: string, d: Draft) {
  try { localStorage.setItem(DRAFT_PREFIX + key, JSON.stringify(d)); } catch { /* storage full or blocked */ }
}
export function clearVisitDraft(key: string) {
  try { localStorage.removeItem(DRAFT_PREFIX + key); } catch { /* ignore */ }
}

export function VisitForm({ initial, enquiry, draftKey, onSubmit, submitLabel, onCancel }: {
  initial?: Record<string, any>;
  enquiry?: { id: string; enquiry_number: string; customer: CustomerRef; site_id?: string | null } | null;
  draftKey: string;
  onSubmit: (values: Record<string, any>) => Promise<void>;
  submitLabel: string;
  onCancel?: () => void;
}) {
  const start = toValues(initial ?? (enquiry ? { site_id: enquiry.site_id } : undefined));
  const form = useForm<Values>({ defaultValues: start });
  const { register, handleSubmit, formState, control, watch, setValue, reset } = form;
  const measurements = useFieldArray({ control, name: "measurements" });
  const e = formState.errors as Record<string, { message?: string }>;
  const [error, setError] = useState<unknown>(null);
  const [offline, setOffline] = useState(false);
  const initialCustomer: CustomerRef | null = enquiry?.customer ?? (initial?.customer ? { id: initial.customer.id, name: initial.customer.name, code: initial.customer.code, city: initial.customer.city } : null);
  const [customer, setCustomer] = useState<CustomerRef | null>(initialCustomer);
  const detail = useCustomerDetail(customer?.id);
  const engineers = usePeople("engineer");
  const options = useQuery({ queryKey: ["/crm/options"], queryFn: () => api<{ data: any }>("/crm/options"), select: (r) => r.data, staleTime: 60_000 });
  const gpsEnabled = options.data?.gps_enabled !== false;
  const [locating, setLocating] = useState(false);
  const [draft, setDraft] = useState<Draft | null>(null);
  const dirty = useRef(false);

  // Offer an unsaved draft from this device (only if it is newer than the saved record).
  useEffect(() => {
    const d = readDraft(draftKey);
    if (d && (!initial?.updated_at || new Date(d.savedAt) > new Date(initial.updated_at))) setDraft(d);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [draftKey]);
  // Autosave while typing.
  useEffect(() => {
    const sub = watch(() => { dirty.current = true; });
    const t = setInterval(() => {
      if (!dirty.current) return;
      dirty.current = false;
      writeDraft(draftKey, { savedAt: new Date().toISOString(), values: form.getValues(), customer });
    }, 1500);
    return () => { sub.unsubscribe(); clearInterval(t); };
  }, [watch, draftKey, customer, form]);

  const sites: [string, string][] = [["", "— Not a saved site —"], ...(detail.data?.sites ?? []).filter((s: any) => s.is_active || s.id === start.site_id).map((s: any) => [s.id, [s.site_name, s.city].filter(Boolean).join(", ")] as [string, string])];
  const lat = watch("latitude");

  function locate() {
    if (!navigator.geolocation) return setError(new Error("This browser cannot read the location."));
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setValue("latitude", pos.coords.latitude.toFixed(6), { shouldDirty: true });
        setValue("longitude", pos.coords.longitude.toFixed(6), { shouldDirty: true });
        setValue("location_accuracy_m", String(Math.round(pos.coords.accuracy)), { shouldDirty: true });
        setLocating(false);
      },
      (err) => {
        setLocating(false);
        setError(new Error(err.code === err.PERMISSION_DENIED ? "Location permission was refused. Allow location for this site in the browser settings." : "Could not get the location. Try again in the open, away from buildings."));
      },
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 },
    );
  }

  const submit = handleSubmit(async (v) => {
    setError(null);
    setOffline(false);
    if (!enquiry && !customer) return setError(new Error("Choose the customer."));
    const values: Record<string, any> = clean({ ...v, measurements: undefined });
    values.measurements = v.measurements.filter((m) => m.label.trim() && m.value.trim()).map((m) => ({ label: m.label.trim(), value: m.value.trim(), unit: m.unit.trim() || null }));
    values.enquiry_id = enquiry?.id ?? initial?.enquiry_id ?? null;
    values.customer_id = enquiry ? null : customer?.id;
    values.location_accuracy_m = values.location_accuracy_m ? Number(values.location_accuracy_m) : null;
    if (!gpsEnabled) { values.latitude = null; values.longitude = null; values.location_accuracy_m = null; }
    writeDraft(draftKey, { savedAt: new Date().toISOString(), values: v, customer });
    try {
      await onSubmit(values);
      clearVisitDraft(draftKey);
    } catch (err) {
      if (!(err instanceof ApiError)) { setOffline(true); return; } // network failure — the draft is kept
      applyServerErrors(form, err);
      setError(err.status === 422 ? new Error("Please correct the highlighted fields.") : err);
    }
  });

  return (
    <form onSubmit={submit} className="space-y-5">
      {draft && (
        <div className="flex flex-col gap-2 rounded-md border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-900 sm:flex-row sm:items-center">
          <History className="size-4 shrink-0" />
          <span>Unsaved changes from this device, {dateTime(draft.savedAt)}.</span>
          <span className="flex gap-2 sm:ml-auto">
            <Button type="button" size="sm" onClick={() => { reset(draft.values); if (!enquiry) setCustomer(draft.customer); setDraft(null); }}>Restore</Button>
            <Button type="button" size="sm" variant="secondary" onClick={() => { clearVisitDraft(draftKey); setDraft(null); }}>Discard</Button>
          </span>
        </div>
      )}
      {offline && (
        <div className="flex items-start gap-2 rounded-md border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-900">
          <WifiOff className="mt-0.5 size-4 shrink-0" />
          <span><b>No connection.</b> Everything you typed is saved on this device. Tap <b>{submitLabel}</b> again when you have signal.</span>
        </div>
      )}
      <ErrorNote error={error} />

      <Card title="Visit">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Customer" required className="sm:col-span-2" hint={enquiry ? `From enquiry ${enquiry.enquiry_number}` : undefined}>
            <CustomerPicker value={customer} disabled={!!enquiry || !!initial} onChange={(c) => { setCustomer(c); setValue("site_id", ""); }} />
          </Field>
          <Field label="Customer site" error={e.site_id?.message} className="sm:col-span-2">
            <SelectInput control={control} name="site_id" options={sites} disabled={!customer} />
          </Field>
          <Field label="Site location / address" error={e.site_location?.message} className="sm:col-span-2 lg:col-span-4" hint="Blank = the chosen site's address (or the customer's)">
            <Input {...register("site_location")} />
          </Field>
          <Field label="Visit date" required error={e.visit_date?.message}>
            <Input type="date" {...register("visit_date", { required: "Visit date is required" })} />
          </Field>
          <Field label="Time" error={e.visit_time?.message}>
            <Input type="time" {...register("visit_time")} />
          </Field>
          <Field label="Engineer" error={e.engineer_id?.message} className="sm:col-span-2">
            <SelectInput control={control} name="engineer_id" options={peopleOptions(engineers.data)} />
          </Field>
          <Field label="Purpose" error={e.purpose?.message} className="sm:col-span-2 lg:col-span-4">
            <Input {...register("purpose")} placeholder="e.g. Survey for lightning protection" />
          </Field>
        </div>
      </Card>

      <Card title="Findings">
        <div className="space-y-4">
          <Field label="Observations" error={e.observations?.message}><Textarea rows={4} {...register("observations")} /></Field>
          <Field label="Customer requirements" error={e.requirements?.message}><Textarea rows={3} {...register("requirements")} /></Field>
          <div>
            <p className="mb-1 text-[13px] font-medium text-ink-700">Measurements</p>
            <div className="space-y-2">
              {measurements.fields.map((m, i) => (
                <div key={m.id} className="grid grid-cols-[1fr_5.5rem_4.5rem_auto] gap-2 sm:grid-cols-[1fr_8rem_6rem_auto]">
                  <Input placeholder="What (e.g. Earth pit 1)" {...register(`measurements.${i}.label`)} aria-label="Measurement" />
                  <Input placeholder="Value" inputMode="decimal" className="num" {...register(`measurements.${i}.value`)} aria-label="Value" />
                  <Input placeholder="Unit" list="tce-units" {...register(`measurements.${i}.unit`)} aria-label="Unit" />
                  <Button type="button" variant="ghost" size="sm" aria-label="Remove" onClick={() => measurements.remove(i)}><Trash2 className="size-4 text-ink-400" /></Button>
                </div>
              ))}
              <datalist id="tce-units">{UNITS.map((u) => <option key={u} value={u} />)}</datalist>
              <Button type="button" variant="secondary" size="sm" icon={<Plus className="size-3.5" />} onClick={() => measurements.append({ label: "", value: "", unit: "" })}>Add measurement</Button>
            </div>
          </div>
          <Field label="Recommendations" error={e.recommendations?.message}><Textarea rows={3} {...register("recommendations")} /></Field>
        </div>
      </Card>

      <Card title="Customer representative & follow-up">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Name" error={e.customer_rep_name?.message}><Input {...register("customer_rep_name")} /></Field>
          <Field label="Designation" error={e.customer_rep_designation?.message}><Input {...register("customer_rep_designation")} /></Field>
          <Field label="Phone" error={e.customer_rep_phone?.message}><Input type="tel" inputMode="tel" {...register("customer_rep_phone")} /></Field>
          <Field label="Follow-up date" error={e.follow_up_date?.message} hint="Creates a follow-up task when the visit is completed">
            <Input type="date" {...register("follow_up_date")} />
          </Field>
        </div>
      </Card>

      {gpsEnabled && (
        <Card title="GPS location (optional)">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <Button type="button" variant="secondary" icon={<Crosshair className="size-4" />} loading={locating} onClick={locate}>
              {lat ? "Update location" : "Use my current location"}
            </Button>
            {lat ? (
              <p className="text-sm text-ink-700">
                <span className="num">{watch("latitude")}, {watch("longitude")}</span>
                {watch("location_accuracy_m") && <span className="text-ink-500"> · ±{watch("location_accuracy_m")} m</span>}
                <button type="button" className="ml-3 text-brand-700 hover:underline" onClick={() => { setValue("latitude", ""); setValue("longitude", ""); setValue("location_accuracy_m", ""); }}>Remove</button>
              </p>
            ) : <p className="text-sm text-ink-500">Stand at the site and tap the button. The coordinates go on the visit report.</p>}
          </div>
        </Card>
      )}

      <div className="sticky bottom-0 -mx-4 flex justify-end gap-2 border-t border-ink-200 bg-white/95 px-4 py-3 backdrop-blur sm:static sm:mx-0 sm:border-0 sm:bg-transparent sm:p-0">
        {onCancel && <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>}
        <Button type="submit" loading={formState.isSubmitting}>{submitLabel}</Button>
      </div>
    </form>
  );
}
