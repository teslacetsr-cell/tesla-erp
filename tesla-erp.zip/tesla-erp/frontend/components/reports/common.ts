import { BarChart3, Boxes, Briefcase, ShoppingCart, UserSquare2, Users, Wallet, type LucideIcon } from "lucide-react";
import { date as fmtDate, inr, qty } from "@/lib/format";

export type ColType = "text" | "date" | "money" | "qty" | "int" | "pct";
export type ReportColumn = { key: string; label: string; type: ColType; width: number };
export type FilterOption = { value: string; label: string; hint?: string | null };
export type ReportFilter = {
  name: string;
  type: "daterange" | "date" | "month" | "select";
  label: string;
  keys: string[];
  source?: string;
  options?: FilterOption[];
  default: Record<string, string>;
};
export type ReportDef = { key: string; title: string; group: string; description: string; filters: ReportFilter[]; columns: ReportColumn[] };
export type ReportGroup = { group: string; reports: ReportDef[] };
export type ReportResult = {
  key: string;
  title: string;
  columns: ReportColumn[];
  rows: Record<string, any>[];
  totals: Record<string, any>;
  filters_applied: Record<string, string>;
  filters_label: string;
  row_count: number;
  truncated: boolean;
};

export const GROUP_ICONS: Record<string, LucideIcon> = {
  "Sales & CRM": Users,
  Projects: Briefcase,
  Purchase: ShoppingCart,
  Inventory: Boxes,
  Finance: Wallet,
  HR: UserSquare2,
};
export const groupIcon = (g: string) => GROUP_ICONS[g] ?? BarChart3;

export const NUMERIC: ColType[] = ["money", "qty", "int", "pct"];

export function cellText(type: ColType, v: any): string {
  if (v === null || v === undefined || v === "") return "";
  switch (type) {
    case "money":
      return inr(v);
    case "qty":
      return qty(v);
    case "int":
      return Number(v).toLocaleString("en-IN");
    case "pct":
      return `${Number(v).toFixed(2)}%`;
    case "date":
      return fmtDate(v);
    default:
      return String(v);
  }
}

/* ------------------------------------------------------------------ periods (financial year: April–March, IST) */
const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

function todayIST(): Date {
  const s = new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" }); // YYYY-MM-DD
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d);
}

export function presets(): { label: string; from: string; to: string }[] {
  const t = todayIST();
  const y = t.getFullYear();
  const m = t.getMonth();
  const fy = m >= 3 ? y : y - 1;
  return [
    { label: "This month", from: iso(new Date(y, m, 1)), to: iso(new Date(y, m + 1, 0)) },
    { label: "Last month", from: iso(new Date(y, m - 1, 1)), to: iso(new Date(y, m, 0)) },
    { label: "This FY", from: iso(new Date(fy, 3, 1)), to: iso(new Date(fy + 1, 2, 31)) },
    { label: "Last FY", from: iso(new Date(fy - 1, 3, 1)), to: iso(new Date(fy, 2, 31)) },
  ];
}
