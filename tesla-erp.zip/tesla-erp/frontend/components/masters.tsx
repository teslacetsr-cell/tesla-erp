"use client";

import type { FieldDef } from "@/components/record-form";
import type { Column } from "@/components/ui";
import { StatusBadge } from "@/components/ui";
import { date } from "@/lib/format";

export type MasterDef = {
  kind: string;
  title: string;
  noun: string;
  path: string;
  perm: string;
  description: string;
  fields: FieldDef[] | ((opts: Record<string, [string, string][]>) => FieldDef[]);
  columns: Column<any>[];
  optionSources?: Record<string, { path: string; label: (r: any) => string }>;
};

const active: Column<any> = { key: "active", header: "Status", cell: (r) => <StatusBadge status={r.is_active} /> };

export const MASTERS: MasterDef[] = [
  {
    kind: "divisions", title: "Business divisions", noun: "division", path: "/divisions", perm: "division",
    description: "Lightning protection, Solar EPC, EV charging… Transactions are tagged with a division for reporting.",
    fields: [{ name: "code", label: "Code", required: true, upper: true }, { name: "name", label: "Name", required: true },
      { name: "description", label: "Description", type: "textarea" }, { name: "is_active", label: "Active", type: "checkbox" }],
    columns: [{ key: "c", header: "Code", cell: (r) => <span className="font-mono text-xs">{r.code}</span> }, { key: "n", header: "Name", cell: (r) => r.name }, active],
  },
  {
    kind: "departments", title: "Departments", noun: "department", path: "/departments", perm: "org_master",
    description: "Organisation departments for employees.",
    fields: [{ name: "code", label: "Code", required: true, upper: true }, { name: "name", label: "Name", required: true }, { name: "is_active", label: "Active", type: "checkbox" }],
    columns: [{ key: "c", header: "Code", cell: (r) => <span className="font-mono text-xs">{r.code}</span> }, { key: "n", header: "Name", cell: (r) => r.name }, active],
  },
  {
    kind: "designations", title: "Designations", noun: "designation", path: "/designations", perm: "org_master",
    description: "Job titles for employees.",
    fields: [{ name: "name", label: "Name", required: true, span: 2 }, { name: "is_active", label: "Active", type: "checkbox" }],
    columns: [{ key: "n", header: "Name", cell: (r) => r.name }, active],
  },
  {
    kind: "quotation-terms", title: "Quotation terms library", noun: "clause", path: "/quotation-terms", perm: "quotation_term",
    description: "Standard payment, delivery, warranty and general clauses picked into quotations. Default ones are added to every new quotation.",
    fields: [
      { name: "category", label: "Category", type: "select", options: [["payment", "Payment"], ["delivery", "Delivery"], ["warranty", "Warranty"], ["validity", "Validity"], ["general", "General term"]] },
      { name: "title", label: "Short name", required: true },
      { name: "text", label: "Text", type: "textarea", required: true },
      { name: "sort_order", label: "Order", type: "number", hint: "Lower numbers come first" },
      { name: "is_default", label: "Add to new quotations by default", type: "checkbox" },
      { name: "is_active", label: "Active", type: "checkbox" },
    ],
    columns: [
      { key: "c", header: "Category", cell: (r) => r.category.charAt(0).toUpperCase() + r.category.slice(1) },
      { key: "t", header: "Clause", cell: (r) => <div><p className="font-medium">{r.title}</p><p className="line-clamp-2 text-xs text-ink-500">{r.text}</p></div> },
      { key: "d", header: "Default", cell: (r) => (r.is_default ? "Yes" : "") },
      active,
    ],
  },
  {
    kind: "item-categories", title: "Item categories", noun: "category", path: "/item-categories", perm: "item",
    description: "Lightning Protection, Surge Protection, Earthing, Solar, EV Charging…",
    fields: [{ name: "code", label: "Code", required: true, upper: true }, { name: "name", label: "Name", required: true }, { name: "is_active", label: "Active", type: "checkbox" }],
    columns: [{ key: "c", header: "Code", cell: (r) => <span className="font-mono text-xs">{r.code}</span> }, { key: "n", header: "Name", cell: (r) => r.name }, active],
  },
  {
    kind: "brands", title: "Brands", noun: "brand", path: "/brands", perm: "item", description: "Manufacturers such as DEHN.",
    fields: [{ name: "name", label: "Name", required: true, span: 2 }, { name: "is_active", label: "Active", type: "checkbox" }],
    columns: [{ key: "n", header: "Name", cell: (r) => r.name }, active],
  },
  {
    kind: "units", title: "Units of measure", noun: "unit", path: "/units", perm: "item",
    description: "NOS, M, KG… A unit can be a multiple of a base unit (1 roll = 50 m).",
    optionSources: { base: { path: "/units", label: (u) => `${u.code} — ${u.name}` } },
    fields: (o) => [
      { name: "code", label: "Code", required: true, upper: true }, { name: "name", label: "Name", required: true },
      { name: "decimals", label: "Decimal places", type: "select", options: [["0", "0 (whole numbers)"], ["1", "1"], ["2", "2"], ["3", "3"]] },
      { name: "base_unit_id", label: "Multiple of (base unit)", type: "select", options: [["", "— This is a base unit —"], ...(o.base ?? [])] },
      { name: "factor", label: "Factor", type: "number", hint: "How many base units in one of this unit" },
      { name: "is_active", label: "Active", type: "checkbox" },
    ],
    columns: [{ key: "c", header: "Code", cell: (r) => <span className="font-mono text-xs">{r.code}</span> }, { key: "n", header: "Name", cell: (r) => r.name },
      { key: "f", header: "Conversion", cell: (r) => (r.factor ? `= ${Number(r.factor)} base units` : "Base unit") }, active],
  },
  {
    kind: "tax-rates", title: "GST rates", noun: "GST rate", path: "/tax-rates", perm: "tax_rate",
    description: "GST rates are data with effective dates — never hard-coded. CGST/SGST are half the rate; IGST is the full rate.",
    fields: [{ name: "code", label: "Code", required: true, upper: true, hint: "e.g. GST18" }, { name: "name", label: "Name", required: true },
      { name: "rate", label: "GST %", type: "number", required: true }, { name: "cess_rate", label: "Cess %", type: "number" },
      { name: "effective_from", label: "Effective from (YYYY-MM-DD)", required: true }, { name: "effective_to", label: "Effective to (YYYY-MM-DD)" },
      { name: "is_active", label: "Active", type: "checkbox" }],
    columns: [{ key: "c", header: "Code", cell: (r) => <span className="font-mono text-xs">{r.code}</span> }, { key: "n", header: "Name", cell: (r) => r.name },
      { key: "r", header: "Rate", cell: (r) => <span className="num">{Number(r.rate)}%</span> },
      { key: "e", header: "Effective", cell: (r) => `${date(r.effective_from)} → ${r.effective_to ? date(r.effective_to) : "open"}` }, active],
  },
  {
    kind: "warehouses", title: "Warehouses", noun: "warehouse", path: "/warehouses", perm: "warehouse",
    description: "Stores and project site stores. Stock is tracked per warehouse from Phase 5.",
    fields: [{ name: "code", label: "Code", required: true, upper: true }, { name: "name", label: "Name", required: true },
      { name: "warehouse_type", label: "Type", type: "select", options: [["main", "Main store"], ["site", "Project site store"], ["transit", "In transit"], ["service", "Service van / kit"]] },
      { name: "address", label: "Address", type: "textarea" }, { name: "is_active", label: "Active", type: "checkbox" }],
    columns: [{ key: "c", header: "Code", cell: (r) => <span className="font-mono text-xs">{r.code}</span> }, { key: "n", header: "Name", cell: (r) => r.name },
      { key: "t", header: "Type", cell: (r) => r.warehouse_type }, active],
  },
];
