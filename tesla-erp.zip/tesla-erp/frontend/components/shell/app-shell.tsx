"use client";

import clsx from "clsx";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Bell, ChevronDown, KeyRound, LogOut, Menu, MessageCircle, X } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Spinner } from "@/components/ui";
import { NAV, type NavGroup } from "./nav";
import { NotificationBell } from "./notifications";
import { GlobalSearch } from "./search";

function visible(group: NavGroup, can: (c: string) => boolean) {
  if (group.href) return !group.perm || can(group.perm);
  return group.items.some((i) => i.phase || !i.perm || can(i.perm));
}

const ALL_HREFS = NAV.flatMap((g) => [g.href, ...g.items.map((i) => i.href)]).filter((h): h is string => !!h);

function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const { can } = useAuth();
  const path = usePathname();
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const matches = (href: string) => { const h = href.split("?")[0].replace(/\/$/, ""); return path === h || path.startsWith(h + "/"); };
  // the most specific item wins, so "Finance → Overview" (/finance) is not lit on /finance/receipts
  const isActive = (href: string) => matches(href) && !ALL_HREFS.some((h) => h.split("?")[0].length > href.split("?")[0].length && matches(h));

  return (
    <nav className="flex h-full flex-col">
      <Link href="/dashboard" onClick={onNavigate} className="flex items-center gap-2.5 px-4 pb-4 pt-4">
        <img src="/brand/tce-logo-64.png" alt="TCE" className="size-9" />
        <div className="leading-tight">
          <p className="text-[13px] font-semibold text-ink-900">Tesla Consulting</p>
          <p className="text-[13px] font-semibold text-ink-900">Engineers</p>
        </div>
      </Link>
      <div className="flex-1 space-y-0.5 overflow-y-auto px-2 pb-6">
        {NAV.filter((g) => visible(g, can)).map((g) => {
          const Icon = g.icon;
          if (g.href) {
            const disabled = !!g.phase;
            return disabled ? (
              <div key={g.label} className="flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm text-ink-400" title={`Coming in Phase ${g.phase}`}>
                <Icon className="size-4" /> {g.label}
                <span className="ml-auto text-[10px] font-medium uppercase">P{g.phase}</span>
              </div>
            ) : (
              <Link
                key={g.label}
                href={g.href}
                onClick={onNavigate}
                className={clsx(
                  "flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm font-medium",
                  isActive(g.href) ? "bg-brand-50 text-brand-700" : "text-ink-700 hover:bg-ink-100",
                )}
              >
                <Icon className="size-4" /> {g.label}
              </Link>
            );
          }
          const items = g.items.filter((i) => i.phase || !i.perm || can(i.perm));
          const groupActive = items.some((i) => !i.phase && isActive(i.href));
          const expanded = open[g.label] ?? (groupActive || items.some((i) => !i.phase));
          return (
            <div key={g.label}>
              <button
                onClick={() => setOpen((o) => ({ ...o, [g.label]: !expanded }))}
                className={clsx(
                  "flex w-full items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm font-medium hover:bg-ink-100",
                  groupActive ? "text-ink-900" : "text-ink-700",
                )}
              >
                <Icon className={clsx("size-4", groupActive && "text-brand-600")} /> {g.label}
                <ChevronDown className={clsx("ml-auto size-3.5 text-ink-400 transition-transform", !expanded && "-rotate-90")} />
              </button>
              {expanded && (
                <div className="mb-1 ml-[18px] border-l border-ink-200 pl-2">
                  {items.map((i) =>
                    i.phase ? (
                      <div key={i.href} className="flex items-center rounded-md px-2.5 py-1 text-[13px] text-ink-400" title={`Coming in Phase ${i.phase}`}>
                        {i.label}
                        <span className="ml-auto text-[10px] font-medium uppercase">P{i.phase}</span>
                      </div>
                    ) : (
                      <Link
                        key={i.href}
                        href={i.href}
                        onClick={onNavigate}
                        className={clsx(
                          "relative block rounded-md px-2.5 py-1 text-[13px]",
                          isActive(i.href) ? "bg-brand-50 font-medium text-brand-700" : "text-ink-600 hover:bg-ink-100 hover:text-ink-900",
                        )}
                      >
                        {isActive(i.href) && <span className="absolute -left-[9px] top-1 bottom-1 w-0.5 rounded bg-brand-600" />}
                        {i.label}
                      </Link>
                    ),
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </nav>
  );
}

/** Chat icon with the number of unread chat messages. The count rides on the notification poll (every minute);
 *  while the chat page is open its own 5-second poll of the channel list is fresher, so the newer of the two wins. */
function ChatButton() {
  const { can } = useAuth();
  const path = usePathname();
  const notes = useQuery<{ meta: { chat_unread?: number } }>({ queryKey: ["/notifications"], enabled: false });
  const chans = useQuery<{ meta: { unread?: number } }>({ queryKey: ["/chat/channels"], enabled: false });
  if (!can("chat.use")) return null;
  const fromChat = chans.dataUpdatedAt > notes.dataUpdatedAt;
  const unread = (fromChat ? chans.data?.meta.unread : notes.data?.meta.chat_unread) ?? 0;
  const here = path === "/chat" || path.startsWith("/chat/");
  return (
    <Link href="/chat" className={clsx("relative rounded-md p-2 hover:bg-ink-100", here ? "text-brand-700" : "text-ink-600")}
      aria-label={`Team chat${unread ? ` (${unread} unread)` : ""}`} title="Team chat">
      <MessageCircle className="size-5" />
      {unread > 0 && <span className="num absolute right-1 top-1 flex min-w-4 items-center justify-center rounded-full bg-brand-600 px-1 text-[10px] font-semibold leading-4 text-white">{unread > 99 ? "99+" : unread}</span>}
    </Link>
  );
}

function UserMenu() {
  const { me, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const router = useRouter();
  if (!me) return null;
  const initials = me.full_name.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} onBlur={() => setTimeout(() => setOpen(false), 150)} className="flex items-center gap-2 rounded-md p-1 hover:bg-ink-100">
        <span className="flex size-8 items-center justify-center rounded-full bg-brand-600 text-xs font-semibold text-white">{initials}</span>
        <span className="hidden text-left leading-tight md:block">
          <span className="block text-[13px] font-medium text-ink-900">{me.full_name}</span>
          <span className="block text-[11px] text-ink-500">{me.roles.map((r) => r.replace("_", " ").toLowerCase()).join(", ")}</span>
        </span>
      </button>
      {open && (
        <div className="absolute right-0 top-11 z-40 w-52 rounded-lg border border-ink-200 bg-white p-1 shadow-lg">
          <button onMouseDown={() => router.push("/account/notifications")} className="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-sm hover:bg-ink-100">
            <Bell className="size-4 text-ink-500" /> Notification settings
          </button>
          <button onMouseDown={() => router.push("/change-password")} className="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-sm hover:bg-ink-100">
            <KeyRound className="size-4 text-ink-500" /> Change password
          </button>
          <button onMouseDown={logout} className="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-sm text-brand-700 hover:bg-brand-50">
            <LogOut className="size-4" /> Sign out
          </button>
        </div>
      )}
    </div>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const { me, loading } = useAuth();
  const router = useRouter();
  const path = usePathname();
  const [drawer, setDrawer] = useState(false);

  useEffect(() => {
    if (loading) return;
    if (!me) router.replace(`/login?next=${encodeURIComponent(path)}`);
    else if (me.must_change_password) router.replace("/change-password");
  }, [loading, me, router, path]);

  if (loading || !me || me.must_change_password) return <Spinner label="Opening TCE ERP…" />;

  return (
    <div className="min-h-dvh bg-ink-50/50">
      <div className="fixed inset-x-0 top-0 z-30 h-[3px] bg-brand-600" />
      <aside className="fixed inset-y-0 left-0 z-20 hidden w-60 border-r border-ink-200 bg-white pt-[3px] lg:block">
        <Sidebar />
      </aside>
      {drawer && (
        <div className="fixed inset-0 z-40 lg:hidden" onClick={() => setDrawer(false)}>
          <div className="absolute inset-0 bg-ink-900/40" />
          <aside className="absolute inset-y-0 left-0 w-72 bg-white shadow-xl" onClick={(e) => e.stopPropagation()}>
            <button className="absolute right-2 top-3 rounded p-1.5 text-ink-500 hover:bg-ink-100" onClick={() => setDrawer(false)} aria-label="Close menu">
              <X className="size-5" />
            </button>
            <Sidebar onNavigate={() => setDrawer(false)} />
          </aside>
        </div>
      )}
      <div className="lg:pl-60">
        <header className="sticky top-[3px] z-10 flex h-14 items-center gap-3 border-b border-ink-200 bg-white/95 px-4 backdrop-blur">
          <button className="rounded p-1.5 text-ink-600 hover:bg-ink-100 lg:hidden" onClick={() => setDrawer(true)} aria-label="Open menu">
            <Menu className="size-5" />
          </button>
          <GlobalSearch />
          <div className="ml-auto flex items-center gap-1">
            <ChatButton />
            <NotificationBell />
            <UserMenu />
          </div>
        </header>
        <main className="mx-auto max-w-[1400px] px-4 py-6 sm:px-6">{children}</main>
      </div>
    </div>
  );
}
