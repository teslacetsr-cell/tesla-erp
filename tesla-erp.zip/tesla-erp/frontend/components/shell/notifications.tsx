"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { api } from "@/lib/api/client";
import { dateTime } from "@/lib/format";

type Note = { id: string; title: string; body: string | null; link: string | null; created_at: string; read: boolean };

/** In-app notifications (approvals now; more events in later phases). Checks every minute. */
export function NotificationBell() {
  const [open, setOpen] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  const router = useRouter();
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["/notifications"],
    queryFn: () => api<{ data: Note[]; meta: { unread: number } }>("/notifications", { params: { limit: 12 } }),
    refetchInterval: 60_000,
  });
  useEffect(() => {
    const close = (e: MouseEvent) => box.current && !box.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);
  const unread = data?.meta.unread ?? 0;
  const refresh = () => qc.invalidateQueries({ queryKey: ["/notifications"] });

  return (
    <div className="relative" ref={box}>
      <button onClick={() => setOpen(!open)} className="relative rounded-md p-2 text-ink-600 hover:bg-ink-100" aria-label={`Notifications${unread ? ` (${unread} unread)` : ""}`}>
        <Bell className="size-5" />
        {unread > 0 && <span className="num absolute right-1 top-1 flex min-w-4 items-center justify-center rounded-full bg-brand-600 px-1 text-[10px] font-semibold leading-4 text-white">{unread > 9 ? "9+" : unread}</span>}
      </button>
      {open && (
        <div className="absolute right-0 top-11 z-40 w-[22rem] max-w-[calc(100vw-2rem)] rounded-lg border border-ink-200 bg-white shadow-lg">
          <div className="flex items-center justify-between border-b border-ink-100 px-3 py-2">
            <p className="text-sm font-semibold">Notifications</p>
            {unread > 0 && <button className="text-xs font-medium text-brand-700 hover:underline" onClick={async () => { await api("/notifications/read-all", { method: "POST" }); refresh(); }}>Mark all read</button>}
          </div>
          <ul className="max-h-96 divide-y divide-ink-100 overflow-y-auto">
            {!data?.data.length && <li className="px-3 py-6 text-center text-sm text-ink-500">Nothing yet.</li>}
            {data?.data.map((n) => (
              <li key={n.id}>
                <button className={`block w-full px-3 py-2.5 text-left hover:bg-brand-50 ${n.read ? "" : "bg-brand-50/40"}`}
                  onClick={async () => {
                    setOpen(false);
                    if (!n.read) { await api(`/notifications/${n.id}/read`, { method: "POST" }); refresh(); }
                    if (n.link) router.push(n.link);
                  }}>
                  <span className="flex items-start gap-2">
                    {!n.read && <span className="mt-1.5 size-2 shrink-0 rounded-full bg-brand-600" />}
                    <span className="min-w-0">
                      <span className="block text-sm font-medium text-ink-900">{n.title}</span>
                      {n.body && <span className="block text-xs text-ink-600">{n.body}</span>}
                      <span className="block text-[11px] text-ink-400">{dateTime(n.created_at)}</span>
                    </span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
