import {
  BarChart3,
  Boxes,
  Briefcase,
  ClipboardList,
  FileText,
  LayoutDashboard,
  Settings2,
  ShoppingCart,
  Users,
  Wallet,
  Wrench,
  UserSquare2,
  ShieldCheck,
  type LucideIcon,
} from "lucide-react";

export type NavItem = { label: string; href: string; perm?: string; phase?: number };
export type NavGroup = { label: string; icon: LucideIcon; items: NavItem[]; href?: string; perm?: string; phase?: number };

/** Main navigation (Spec §41). Items from later phases are shown greyed so everyone can see the roadmap. */
export const NAV: NavGroup[] = [
  { label: "Dashboard", icon: LayoutDashboard, href: "/dashboard", items: [] },
  { label: "Approvals", icon: ShieldCheck, href: "/approvals", perm: "quotation.approve|quotation.create|purchase_request.approve|purchase_order.approve|stock_adjustment.approve|purchase_request.create|purchase_order.create|stock_adjustment.create", items: [] },
  {
    label: "CRM", icon: Users, items: [
      { label: "Customers", href: "/customers", perm: "customer.read" },
      { label: "Leads", href: "/crm/leads", perm: "lead.read" },
      { label: "Enquiries", href: "/crm/enquiries", perm: "enquiry.read" },
      { label: "Site Visits", href: "/crm/site-visits", perm: "site_visit.read" },
      { label: "Follow-ups", href: "/crm/follow-ups", perm: "lead.read|enquiry.read" },
    ],
  },
  {
    label: "Sales", icon: FileText, items: [
      { label: "Quotations", href: "/sales/quotations", perm: "quotation.read" },
      { label: "Sales Orders", href: "/sales/orders", perm: "sales_order.read" },
      { label: "Invoices", href: "/sales/invoices", phase: 7 },
    ],
  },
  {
    label: "Projects", icon: Briefcase, items: [
      { label: "Projects", href: "/projects", perm: "project.read" },
      { label: "Tasks", href: "/projects/tasks" },
      { label: "BOQ", href: "/projects/boq", perm: "boq.read" },
      { label: "Site Reports", href: "/projects/site-reports", perm: "site_work.read" },
    ],
  },
  {
    label: "Purchase", icon: ShoppingCart, items: [
      { label: "Suppliers", href: "/suppliers", perm: "supplier.read" },
      { label: "Material Requests", href: "/purchase/material-requests", perm: "material_request.read" },
      { label: "Purchase Requests", href: "/purchase/requests", perm: "purchase_request.read" },
      { label: "Purchase Orders", href: "/purchase/orders", perm: "purchase_order.read" },
      { label: "GRN", href: "/purchase/grn", perm: "grn.read" },
    ],
  },
  {
    label: "Inventory", icon: Boxes, items: [
      { label: "Items", href: "/items", perm: "item.read" },
      { label: "Warehouses", href: "/admin/masters/view?kind=warehouses", perm: "warehouse.read" },
      { label: "Stock", href: "/inventory/stock", perm: "stock.read" },
      { label: "Transfers", href: "/inventory/transfers", perm: "stock_transfer.read" },
      { label: "Adjustments", href: "/inventory/adjustments", perm: "stock_adjustment.read" },
      { label: "Material Issues", href: "/inventory/issues", phase: 6 },
    ],
  },
  {
    label: "Finance", icon: Wallet, items: [
      { label: "Receivables", href: "/finance/receivables", phase: 7 },
      { label: "Payables", href: "/finance/payables", phase: 7 },
      { label: "Expenses", href: "/finance/expenses", phase: 7 },
      { label: "Payments", href: "/finance/payments", phase: 7 },
      { label: "GST", href: "/admin/masters/view?kind=tax-rates", perm: "tax_rate.read" },
    ],
  },
  {
    label: "Service", icon: Wrench, items: [
      { label: "Service Requests", href: "/service/requests", phase: 9 },
      { label: "AMC", href: "/service/amc", phase: 9 },
      { label: "Service Reports", href: "/service/reports", phase: 9 },
    ],
  },
  {
    label: "HR", icon: UserSquare2, items: [
      { label: "Employees", href: "/hr/employees", perm: "employee.read" },
      { label: "Departments", href: "/admin/masters/view?kind=departments", perm: "org_master.read" },
      { label: "Designations", href: "/admin/masters/view?kind=designations", perm: "org_master.read" },
      { label: "Attendance", href: "/hr/attendance", phase: 8 },
      { label: "Leave", href: "/hr/leave", phase: 8 },
    ],
  },
  { label: "Reports", icon: BarChart3, href: "/reports", phase: 10, items: [] },
  { label: "Documents", icon: ClipboardList, href: "/documents", phase: 10, items: [] },
  {
    label: "Administration", icon: Settings2, items: [
      { label: "Users", href: "/admin/users", perm: "user.read" },
      { label: "Roles", href: "/admin/roles", perm: "role.read" },
      { label: "Company", href: "/admin/company", perm: "company.read" },
      { label: "Masters", href: "/admin/masters", perm: "item.read|org_master.read|division.read|warehouse.read|tax_rate.read|quotation_term.read" },
      { label: "Approval rules", href: "/admin/approval-rules", perm: "approval_policy.read" },
      { label: "Settings", href: "/admin/settings", perm: "settings.read" },
      { label: "Audit Logs", href: "/admin/audit-logs", perm: "audit.read" },
    ],
  },
];
