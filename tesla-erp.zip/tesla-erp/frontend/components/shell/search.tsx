"use client";

import clsx from "clsx";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Clock, CornerDownLeft, Search, X } from "lucide-react";
import { api } from "@/lib/api/client";
import { Spinner } from "@/components/ui";

type Hit = { id: string; title: string; subtitle: string; href: string };
type Group = { type: string; label: string; items: Hit[] };
type Recent = { q?: string; title?: string; href?: string; label?: string };

const KEY = "tce.search.recent";
const loadRecent = (): Recent[] => {
  try { return JSON.parse(localStorage.getItem(KEY) || "[]").slice(0, 8); } catch { return []; }
};
const saveRecent = (r: Recent) => {
  try {
    const list = [r, ...loadRecent().filter((x) => (r.href ? x.href !== r.href : x.q !== r.q))].slice(0, 8);
    localStorage.setItem(KEY, JSON.stringify(list));
  } catch { /* private window: no recent list */ }
};

/** Global search (top bar; Ctrl K / ⌘K): every kind of record the user may open, grouped, keyboard navigable. */
export function GlobalSearch() {
  const [q, setQ] = useState("");
  const [debounced, setDebounced] = useState("");
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const [recent, setRecent] = useState<Recent[]>([]);
  const router = useRouter();
  const ref = useRef<HTMLInputElement>(null);
  const box = useRef<HTMLDivElement>(null);
  const [isMac, setIsMac] = useState(false);

  useEffect(() => {
    setIsMac(/Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent));
    const t = setTimeout(() => setDebounced(q.trim()), 200);
    return () => clearTimeout(t);
  }, [q]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        ref.current?.focus();
        ref.current?.select();
        setOpen(true);
      }
    };
    const onDown = (e: MouseEvent) => { if (box.current && !box.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("keydown", onKey);
    document.addEventListener("mousedown", onDown);
    return () => { document.removeEventListener("keydown", onKey); document.removeEventListener("mousedown", onDown); };
  }, []);
  useEffect(() => { if (open) setRecent(loadRecent()); }, [open]);

  const { data, isFetching } = useQuery({
    queryKey: ["search", debounced],
    queryFn: () => api<{ data: Group[] }>("/search", { params: { q: debounced } }),
    enabled: debounced.length >= 2,
    staleTime: 30_000,
  });
  const searching = debounced.length >= 2;
  const groups = searching ? data?.data ?? [] : [];
  // one flat list for the arrow keys
  const flat = useMemo(() => {
    if (searching) return groups.flatMap((g) => g.items.map((i) => ({ ...i, label: g.label })));
    return recent.map((r, i) => ({ id: `r${i}`, title: r.title ?? r.q ?? "", subtitle: r.label ?? "Recent search", href: r.href ?? "", q: r.q, label: r.label ?? "" }));
  }, [searching, groups, recent]);
  useEffect(() => setActive(0), [debounced, open]);

  const go = (hit: { href: string; title: string; label?: string; q?: string }) => {
    if (!hit.href && hit.q) { setQ(hit.q); ref.current?.focus(); return; }
    if (searching) { saveRecent({ q: debounced }); saveRecent({ title: hit.title, href: hit.href, label: hit.label }); }
    setOpen(false);
    setQ("");
    ref.current?.blur();
    router.push(hit.href);
  };
  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") { e.preventDefault(); setOpen(true); setActive((a) => Math.min(a + 1, Math.max(flat.length - 1, 0))); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setActive((a) => Math.max(a - 1, 0)); }
    else if (e.key === "Enter" && flat[active]) { e.preventDefault(); go(flat[active] as any); }
    else if (e.key === "Escape") { setOpen(false); ref.current?.blur(); }
  };
  useEffect(() => {
    box.current?.querySelector(`[data-idx="${active}"]`)?.scrollIntoView({ block: "nearest" });
  }, [active]);

  let idx = -1;
  return (
    <div className="relative w-full max-w-md" ref={box}>
      <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-ink-400" />
      <input
        ref={ref}
        value={q}
        onChange={(e) => { setQ(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        onKeyDown={onKeyDown}
        placeholder="Search customers, projects, invoices, POs…"
        aria-label="Search the ERP"
        role="combobox"
        aria-expanded={open}
        aria-controls="global-search-results"
        aria-activedescendant={open && flat[active] ? `gs-${active}` : undefined}
        className="h-9 w-full rounded-md border border-ink-200 bg-ink-50 pl-8 pr-14 text-sm placeholder:text-ink-400 focus:border-brand-600 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-100"
      />
      {q ? (
        <button type="button" aria-label="Clear search" onClick={(e) => { e.preventDefault(); setQ(""); ref.current?.focus(); }} className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-ink-400 hover:bg-ink-100 hover:text-ink-700">
          <X className="size-4" />
        </button>
      ) : (
        <kbd className="pointer-events-none absolute right-2 top-1/2 hidden -translate-y-1/2 rounded border border-ink-200 bg-white px-1.5 text-[10px] text-ink-500 sm:block">{isMac ? "⌘ K" : "Ctrl K"}</kbd>
      )}
      {open && (searching || recent.length > 0) && (
        <div id="global-search-results" role="listbox" className="absolute left-0 right-0 top-11 z-40 max-h-[70vh] overflow-y-auto rounded-lg border border-ink-200 bg-white p-1 shadow-lg sm:w-[30rem]">
          {!searching ? (
            <div className="py-1">
              <p className="flex items-center justify-between px-2 py-1 text-[11px] font-semibold uppercase tracking-wide text-ink-400">
                Recent
                <button type="button" className="font-medium normal-case tracking-normal text-brand-700 hover:underline" onClick={(e) => { e.preventDefault(); try { localStorage.removeItem(KEY); } catch { /* ignore */ } setRecent([]); }}>Clear</button>
              </p>
              {flat.map((r, i) => (
                <button key={r.id} id={`gs-${i}`} data-idx={i} role="option" aria-selected={i === active} type="button"
                  onMouseEnter={() => setActive(i)} onClick={(e) => { e.preventDefault(); go(r as any); }}
                  className={clsx("flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left", i === active && "bg-brand-50")}>
                  <Clock className="size-3.5 shrink-0 text-ink-400" />
                  <span className="min-w-0 flex-1 truncate text-sm text-ink-800">{r.title}</span>
                  <span className="shrink-0 text-[11px] text-ink-400">{r.subtitle}</span>
                </button>
              ))}
            </div>
          ) : isFetching && !data ? (
            <Spinner label="Searching…" />
          ) : groups.length ? (
            groups.map((g) => (
              <div key={g.type} className="py-1">
                <p className="px-2 py-1 text-[11px] font-semibold uppercase tracking-wide text-ink-400">{g.label}</p>
                {g.items.map((i) => {
                  idx += 1;
                  const n = idx;
                  return (
                    <button key={i.id} id={`gs-${n}`} data-idx={n} role="option" aria-selected={n === active} type="button"
                      onMouseEnter={() => setActive(n)} onClick={(e) => { e.preventDefault(); go({ ...i, label: g.label }); }}
                      className={clsx("flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left", n === active && "bg-brand-50")}>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm text-ink-900">{i.title}</span>
                        <span className="block truncate text-xs text-ink-500">{i.subtitle}</span>
                      </span>
                      {n === active && <CornerDownLeft className="size-3.5 shrink-0 text-ink-400" />}
                    </button>
                  );
                })}
              </div>
            ))
          ) : (
            <p className="px-3 py-4 text-sm text-ink-500">No matches for “{debounced}”. Try a number, a name or part of it.</p>
          )}
          {searching && groups.length > 0 && (
            <p className="hidden border-t border-ink-100 px-2 pt-1.5 text-[11px] text-ink-400 sm:block">↑ ↓ to move · Enter to open · Esc to close</p>
          )}
        </div>
      )}
    </div>
  );
}
