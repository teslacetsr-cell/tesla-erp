"use client";

import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button, Card, Checkbox, ErrorNote, Field, Input, Select, Spinner, useToast } from "@/components/ui";
import { api } from "@/lib/api/client";
import { date, inr } from "@/lib/format";

/** Project → Incentive tab: category, client type, tender, EI & KSEB scope, subsidy milestone and the team per role. */
export function ProjectIncentiveTab({ projectId }: { projectId: string }) {
  const qc = useQueryClient();
  const toast = useToast();
  const q = useQuery({ queryKey: ["/projects", projectId, "incentive"], queryFn: () => api<any>(`/projects/${projectId}/incentive`).then((r) => r.data) });
  const [f, setF] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    if (q.data) setF({ ...q.data, team: Object.fromEntries(q.data.roles.map((r: any) => [r.id, r.choice])) });
  }, [q.data]);
  if (q.error) return <ErrorNote error={q.error} />;
  if (!f) return <Spinner />;
  const ro = !f.can_edit;
  const today = new Date().toISOString().slice(0, 10);

  async function save() {
    setSaving(true);
    try {
      await api(`/projects/${projectId}/incentive`, { method: "PUT", body: {
        category_code: f.category_code || null, is_govt: f.is_govt, from_tender: f.from_tender, ei_kseb: f.ei_kseb,
        subsidy_done: f.subsidy_done, subsidy_date: f.subsidy_done ? f.subsidy_date || null : null, team: f.team } });
      await qc.invalidateQueries({ queryKey: ["/projects", projectId, "incentive"] });
      await qc.invalidateQueries({ queryKey: ["/incentives"] });
      toast("Incentive settings saved");
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card title="Incentive settings" actions={!ro && <Button size="sm" loading={saving} onClick={save}>Save</Button>}>
        {!f.saved && <p className="mb-3 rounded bg-amber-50 px-3 py-2 text-xs text-amber-800">Not saved yet — Govt and Tender below are taken from the client and the enquiry. Choose a category and save.</p>}
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Project category">
            <Select disabled={ro} value={f.category_code ?? ""} onChange={(e) => setF({ ...f, category_code: e.target.value })}>
              <option value="">Not set</option>{f.categories.map((c: any) => <option key={c.code} value={c.code}>{c.name}</option>)}
            </Select>
          </Field>
          <Field label="Contract value (before GST)"><p className="num pt-2 text-sm">{Number(f.contract_value) ? inr(f.contract_value, 0) : <span className="text-ink-400">not set — the sum of bills is used</span>}</p></Field>
          <Checkbox disabled={ro} label="Government client" checked={f.is_govt} onChange={(e) => setF({ ...f, is_govt: e.target.checked })} />
          <Checkbox disabled={ro} label="Came from a tender" checked={f.from_tender} onChange={(e) => setF({ ...f, from_tender: e.target.checked })} />
          <Checkbox disabled={ro} label="EI & KSEB documentation in our scope" checked={f.ei_kseb} onChange={(e) => setF({ ...f, ei_kseb: e.target.checked })} />
          <div />
          <Checkbox disabled={ro} label="Subsidy received & final documents submitted" checked={f.subsidy_done} onChange={(e) => setF({ ...f, subsidy_done: e.target.checked, subsidy_date: f.subsidy_date || new Date().toISOString().slice(0, 10) })} />
          {f.subsidy_done && <Field label="Date"><Input disabled={ro} type="date" value={f.subsidy_date ?? ""} onChange={(e) => setF({ ...f, subsidy_date: e.target.value })} /></Field>}
        </div>
      </Card>
      <Card title="Who earns on this project">
        {f.roles.length === 0 ? <p className="text-sm text-ink-500">No incentive roles set up.</p> : (
          <div className="grid gap-3 sm:grid-cols-2">
            {f.roles.map((r: any) => (
              <Field key={r.id} label={r.name}>
                <Select disabled={ro} value={f.team[r.id] ?? "all"} onChange={(e) => setF({ ...f, team: { ...f.team, [r.id]: e.target.value } })}>
                  <option value="all">All in role{r.employees.filter((m: any) => m.active).length > 1 ? " (shared)" : ""}</option>
                  <option value="none">Nobody</option>
                  {r.employees.filter((m: any) => m.active).map((m: any) => <option key={m.id} value={m.id}>{m.name}{m.eligible_from && m.eligible_from > today ? ` (earns from ${date(m.eligible_from)})` : ""}</option>)}
                </Select>
              </Field>
            ))}
          </div>
        )}
        <p className="mt-3 text-xs text-ink-500">“All in role” shares the amount equally between everyone active in the role who has completed the qualifying period after joining.</p>
      </Card>
    </div>
  );
}
