"use client";

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { api } from "@/lib/api/client";
import { useToast } from "@/components/ui";

export const CRITERIA_LABEL: Record<string, string> = {
  quality: "Quality", timeliness: "Timeliness", follow_up: "Follow-up", teamwork: "Teamwork", learning: "Learning",
};

export function thisMonth(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function shiftMonth(ym: string, by: number): string {
  const [y, m] = ym.split("-").map(Number);
  const d = new Date(y, m - 1 + by, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function monthLabel(ym: string, short = false): string {
  const [y, m] = ym.split("-").map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString("en-IN", { month: short ? "short" : "long", year: short ? "2-digit" : "numeric" });
}

export function MonthPicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="inline-flex items-center rounded-md border border-ink-200 bg-white shadow-sm">
      <button className="px-2 py-1.5 text-ink-500 hover:text-ink-800" onClick={() => onChange(shiftMonth(value, -1))} aria-label="Previous month"><ChevronLeft className="size-4" /></button>
      <input type="month" value={value} onChange={(e) => e.target.value && onChange(e.target.value)} className="border-0 bg-transparent px-1 py-1 text-sm focus:ring-0" />
      <button className="px-2 py-1.5 text-ink-500 hover:text-ink-800" onClick={() => onChange(shiftMonth(value, 1))} aria-label="Next month"><ChevronRight className="size-4" /></button>
    </div>
  );
}

/** GET an incentive endpoint (cached under ["/incentives", ...]). */
export function useInc<T = any>(path: string, params?: Record<string, string | number | undefined>, enabled = true) {
  return useQuery({
    queryKey: ["/incentives", path, params],
    queryFn: () => api<{ data: T }>(path, { params: params as any }).then((r) => r.data),
    enabled,
  });
}

/** Run a write that returns fresh data; refresh every incentive view. */
export function useAct() {
  const qc = useQueryClient();
  const toast = useToast();
  const [busy, setBusy] = useState<string | null>(null);
  async function run(key: string, fn: () => Promise<any>, ok?: string) {
    setBusy(key);
    try {
      const r = await fn();
      await qc.invalidateQueries({ queryKey: ["/incentives"] });
      if (ok) toast(ok);
      return r;
    } catch (e: any) {
      toast(e.message, "error");
      return null;
    } finally {
      setBusy(null);
    }
  }
  return { run, busy };
}

export function Kpi({ label, value, sub, tone }: { label: string; value: React.ReactNode; sub?: React.ReactNode; tone?: "red" | "amber" }) {
  return (
    <div className="rounded-lg border border-ink-200 bg-white px-4 py-3">
      <p className="text-xs text-ink-500">{label}</p>
      <p className={`num mt-0.5 text-lg font-semibold ${tone === "red" ? "text-brand-700" : tone === "amber" ? "text-amber-700" : "text-ink-900"}`}>{value}</p>
      {sub && <p className="mt-0.5 text-xs text-ink-500">{sub}</p>}
    </div>
  );
}

export function rateText(basis: string, rate: string) {
  return basis === "pct" ? `${rate}%` : `₹${Number(rate).toLocaleString("en-IN")}`;
}
