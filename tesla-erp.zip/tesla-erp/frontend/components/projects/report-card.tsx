"use client";

import Link from "next/link";
import { useState } from "react";
import { Camera, Pencil, Trash2 } from "lucide-react";
import { Button, Card, useConfirm } from "@/components/ui";
import { PhotoPanel } from "@/components/crm/photos";
import { SiteReportForm } from "@/components/projects/common";
import { api } from "@/lib/api/client";
import { date, qty } from "@/lib/format";

/** One daily site report: work done, manpower, installation recorded, hindrances and photos. */
export function ReportCard({ r, onChanged, showProject = false, lines }: { r: any; onChanged: () => void; showProject?: boolean; lines?: any[] }) {
  const confirm = useConfirm();
  const [photos, setPhotos] = useState(false);
  const [editing, setEditing] = useState(false);
  if (editing && lines)
    return <Card title={`Edit report · ${date(r.report_date)}`}><SiteReportForm projectId={r.project_id} lines={lines} report={r} onCancel={() => setEditing(false)} onDone={() => { setEditing(false); onChanged(); }} /></Card>;
  return (
    <Card title={<span className="flex flex-wrap items-center gap-2">{date(r.report_date)}{showProject && <Link href={`/projects/view?id=${r.project_id}&tab=reports`} className="text-sm font-normal text-brand-700 hover:underline">{r.project_number} · {r.project_name}</Link>}</span>}
      actions={<div className="flex gap-1">
        <Button size="sm" variant="secondary" icon={<Camera className="size-3.5" />} onClick={() => setPhotos(!photos)}>{photos ? "Hide photos" : "Photos"}</Button>
        {r.can.edit && lines && <Button size="sm" variant="ghost" aria-label="Edit report" onClick={() => setEditing(true)}><Pencil className="size-3.5" /></Button>}
        {r.can.delete && <Button size="sm" variant="ghost" aria-label="Delete report" onClick={async () => {
          if (!(await confirm({ title: "Delete this site report?", body: "Installation it recorded is removed too (quantities go back to remaining).", confirmLabel: "Delete" }))) return;
          await api(`/site-reports/${r.id}`, { method: "DELETE" });
          onChanged();
        }}><Trash2 className="size-3.5 text-ink-400" /></Button>}
      </div>}>
      <div className="space-y-2 text-sm">
        <p className="whitespace-pre-line text-ink-900">{r.work_done}</p>
        <p className="flex flex-wrap gap-x-4 text-xs text-ink-500">
          <span>By {r.reported_by}</span>{r.manpower !== null && <span>Manpower {r.manpower}</span>}{r.weather && <span>{r.weather}</span>}{r.progress_pct !== null && <span>Progress {r.progress_pct}%</span>}
        </p>
        {r.installations.length > 0 && (
          <div className="rounded-md bg-ink-50 px-3 py-2">
            <p className="mb-1 text-xs font-medium text-ink-600">Installed</p>
            <ul className="space-y-0.5">{r.installations.map((i: any) => <li key={i.id}><span className="num font-medium">{qty(i.quantity)} {i.unit}</span> · {i.line_no}. {i.description}{i.location ? ` · ${i.location}` : ""}</li>)}</ul>
          </div>
        )}
        {r.hindrances && <p className="rounded-md border border-amber-200 bg-amber-50 px-3 py-1.5 text-amber-900"><b>Hindrances:</b> {r.hindrances}</p>}
        {r.next_plan && <p className="text-ink-600"><b>Next:</b> {r.next_plan}</p>}
      </div>
      {photos && <div className="mt-3"><PhotoPanel entityType="site_report" visitId={r.id} canEdit={r.can.edit} title="Site photos" emptyBody="Take photos of the work on the phone; they are shrunk before upload." /></div>}
    </Card>
  );
}
