"use client";

import Link from "next/link";
import { Fragment, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronDown, ChevronRight, Download, Users } from "lucide-react";
import { Button, Card, EmptyState, Field, Input, Select, Spinner, useToast } from "@/components/ui";
import { TASK_STATUSES, TaskList } from "@/components/projects/common";
import { api, download, type Page } from "@/lib/api/client";
import { date } from "@/lib/format";

export type EmployeeTaskRow = {
  user_id: string | null; name: string; employee_code: string | null; department: string | null; is_active: boolean;
  open: number; overdue: number; due_this_week: number; blocked: number; done_this_month: number; matching: number; total: number;
};
type Summary = { rows: EmployeeTaskRow[]; totals: Record<string, number>; employees: number; today: string; week_end: string; month_start: string };

type Filters = { employee: string; project_id: string; status: string; due_from: string; due_to: string };
const EMPTY: Filters = { employee: "", project_id: "", status: "", due_from: "", due_to: "" };

/** Filters → query parameters understood by /tasks and /tasks/by-employee. */
function toParams(f: Filters, forPerson?: string | null): Record<string, string | boolean | undefined> {
  const p: Record<string, string | boolean | undefined> = {
    project_id: f.project_id || undefined, due_from: f.due_from || undefined, due_to: f.due_to || undefined,
    open_only: f.status === "_open" || undefined, overdue: f.status === "_overdue" || undefined,
    status: f.status && !f.status.startsWith("_") ? f.status : undefined,
  };
  const who = forPerson !== undefined ? (forPerson ?? "_none") : f.employee;
  if (who === "_none") p.unassigned = true;
  else if (who) p.assigned_to = who;
  return p;
}

const COUNT_COLS: [keyof EmployeeTaskRow, string, string][] = [
  ["open", "Open", ""], ["overdue", "Overdue", "text-brand-700"], ["due_this_week", "Due this week", "text-amber-700"],
  ["blocked", "Blocked", "text-brand-700"], ["done_this_month", "Done this month", "text-emerald-700"],
];

function PersonTasks({ person, filters }: { person: string | null; filters: Filters }) {
  const qc = useQueryClient();
  const params = toParams(filters, person);
  const q = useQuery({
    queryKey: ["/tasks", "by-employee-row", person, params],
    queryFn: () => api<Page<any>>("/tasks", { params: { ...params, page_size: 200, sort: "due_date" } }),
  });
  if (q.isLoading) return <Spinner />;
  const rows = q.data?.data ?? [];
  if (!rows.length) return <p className="px-4 py-3 text-sm text-ink-500">No tasks match the filters.</p>;
  return (
    <>
      <TaskList tasks={rows} showProject onChanged={() => { qc.invalidateQueries({ queryKey: ["/tasks"] }); qc.invalidateQueries({ queryKey: ["/projects"] }); }} />
      {q.data && q.data.meta.total > rows.length && <p className="px-4 py-2 text-xs text-ink-500">Showing the first {rows.length} of {q.data.meta.total}. Use Export for the full list.</p>}
    </>
  );
}

/** Projects → Tasks → By employee: every employee's tasks across all projects (administrators, directors, managers). */
export function TasksByEmployee() {
  const toast = useToast();
  const [f, setF] = useState<Filters>(EMPTY);
  const [open, setOpen] = useState<Set<string>>(new Set());
  const set = (k: keyof Filters, v: string) => setF((x) => ({ ...x, [k]: v }));
  const params = toParams(f);
  const summary = useQuery({
    queryKey: ["/tasks/by-employee", params],
    queryFn: () => api<{ data: Summary }>("/tasks/by-employee", { params }),
    select: (r) => r.data,
  });
  const everyone = useQuery({
    queryKey: ["/tasks/by-employee", "people"],
    queryFn: () => api<{ data: Summary }>("/tasks/by-employee"),
    select: (r) => r.data.rows,
    staleTime: 60_000,
  });
  const projects = useQuery({
    queryKey: ["/projects", "options"],
    queryFn: () => api<Page<any>>("/projects", { params: { page_size: 200, sort: "project_number" } }),
    select: (r) => r.data,
    staleTime: 60_000,
  });
  const people = useMemo(() => [...(everyone.data ?? [])].sort((a, b) => (a.user_id === null ? 1 : b.user_id === null ? -1 : a.name.localeCompare(b.name))), [everyone.data]);
  const filtered = !!(f.project_id || f.status || f.due_from || f.due_to);
  const toggle = (key: string) => setOpen((s) => { const n = new Set(s); if (n.has(key)) n.delete(key); else n.add(key); return n; });
  const data = summary.data;

  return (
    <Card padded={false}>
      <div className="grid gap-3 border-b border-ink-100 p-3 sm:grid-cols-2 lg:grid-cols-6">
        <Field label="Employee" className="lg:col-span-2">
          <Select value={f.employee} onChange={(e) => set("employee", e.target.value)}>
            <option value="">Everyone</option>
            {people.map((p) => <option key={p.user_id ?? "_none"} value={p.user_id ?? "_none"}>{p.name}{p.employee_code ? ` (${p.employee_code})` : ""}</option>)}
          </Select>
        </Field>
        <Field label="Project" className="lg:col-span-2">
          <Select value={f.project_id} onChange={(e) => set("project_id", e.target.value)}>
            <option value="">All projects</option>
            {(projects.data ?? []).map((p: any) => <option key={p.id} value={p.id}>{p.project_number} · {p.name}</option>)}
          </Select>
        </Field>
        <Field label="Status" className="lg:col-span-2">
          <Select value={f.status} onChange={(e) => set("status", e.target.value)}>
            <option value="">Any status</option>
            <option value="_open">Not done</option>
            <option value="_overdue">Overdue only</option>
            {TASK_STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </Select>
        </Field>
        <Field label="Due from" className="lg:col-span-2"><Input type="date" value={f.due_from} onChange={(e) => set("due_from", e.target.value)} /></Field>
        <Field label="Due to" className="lg:col-span-2"><Input type="date" value={f.due_to} onChange={(e) => set("due_to", e.target.value)} /></Field>
        <div className="flex items-end gap-2 lg:col-span-2">
          <Button variant="secondary" onClick={() => setF(EMPTY)} disabled={JSON.stringify(f) === JSON.stringify(EMPTY)}>Clear</Button>
          <Button variant="secondary" icon={<Download className="size-4" />} onClick={async () => {
            try { await download("/tasks/by-employee/export", "tasks-by-employee.xlsx", params as any); }
            catch (e: any) { toast(e.message, "error"); }
          }}>Export to Excel</Button>
        </div>
      </div>
      {data && (
        <p className="border-b border-ink-100 px-4 py-2 text-xs text-ink-500">
          {data.employees} {data.employees === 1 ? "person" : "people"} · “Due this week” is up to Sunday {date(data.week_end)} · “Done this month” is since {date(data.month_start)}. Click a name to see their tasks.
        </p>
      )}
      {summary.isLoading ? <Spinner /> : !data || data.rows.length === 0 ? (
        <div className="p-6"><EmptyState icon={<Users className="size-8" />} title="No tasks match" body="Change the filters, or add tasks on each project's Tasks tab." /></div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-ink-50 text-left text-xs uppercase tracking-wide text-ink-500">
              <tr>
                <th className="px-4 py-2 font-medium">Employee</th>
                {COUNT_COLS.map(([k, label]) => (
                  <th key={k} className={`px-3 py-2 text-right font-medium ${k === "open" || k === "overdue" ? "" : "hidden sm:table-cell"}`}>{label}</th>
                ))}
                {filtered && <th className="px-3 py-2 text-right font-medium">Matching</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-100">
              {data.rows.map((r) => {
                const key = r.user_id ?? "_none";
                const isOpen = open.has(key);
                return (
                  <Fragment key={key}>
                    <tr className="cursor-pointer hover:bg-ink-50" onClick={() => toggle(key)} aria-expanded={isOpen}>
                      <td className="px-4 py-2.5">
                        <span className="flex items-start gap-1.5">
                          {isOpen ? <ChevronDown className="mt-0.5 size-4 shrink-0 text-ink-400" /> : <ChevronRight className="mt-0.5 size-4 shrink-0 text-ink-400" />}
                          <span>
                            <span className={`font-medium ${r.user_id ? "text-ink-900" : "italic text-ink-600"}`}>{r.name}</span>
                            <span className="block text-xs text-ink-500">{[r.employee_code, r.department, r.is_active ? null : "Login disabled"].filter(Boolean).join(" · ") || " "}</span>
                          </span>
                        </span>
                      </td>
                      {COUNT_COLS.map(([k, , tone]) => {
                        const v = r[k] as number;
                        return <td key={k} className={`num px-3 py-2.5 text-right ${k === "open" || k === "overdue" ? "" : "hidden sm:table-cell"} ${v ? `font-medium ${tone || "text-ink-900"}` : "text-ink-300"}`}>{v}</td>;
                      })}
                      {filtered && <td className="num px-3 py-2.5 text-right font-medium">{r.matching}</td>}
                    </tr>
                    {isOpen && (
                      <tr>
                        <td colSpan={COUNT_COLS.length + 1 + (filtered ? 1 : 0)} className="bg-ink-50/60 p-0">
                          <PersonTasks person={r.user_id} filters={f} />
                        </td>
                      </tr>
                    )}
                  </Fragment>
                );
              })}
            </tbody>
            <tfoot className="border-t border-ink-200 bg-ink-50 text-sm">
              <tr>
                <td className="px-4 py-2 font-medium">Total</td>
                {COUNT_COLS.map(([k]) => <td key={k} className={`num px-3 py-2 text-right font-semibold ${k === "open" || k === "overdue" ? "" : "hidden sm:table-cell"}`}>{data.totals[k]}</td>)}
                {filtered && <td className="num px-3 py-2 text-right font-semibold">{data.totals.matching}</td>}
              </tr>
            </tfoot>
          </table>
        </div>
      )}
    </Card>
  );
}

/** Dashboard card (Administrator / Director): the five people with the most overdue tasks. */
export function TasksByEmployeeCard() {
  const q = useQuery({
    queryKey: ["/tasks/by-employee", "top5"],
    queryFn: () => api<{ data: Summary }>("/tasks/by-employee", { params: { limit: 5 } }),
    select: (r) => r.data,
  });
  if (!q.data) return null;
  const rows = q.data.rows.filter((r) => r.open > 0);
  return (
    <Card className="mb-6" title="Tasks by employee" actions={<Link href="/projects/tasks?view=employee" className="text-xs font-medium text-brand-700 hover:underline">Open employee-wise view</Link>} padded={false}>
      {rows.length === 0 ? <p className="px-4 py-3 text-sm text-ink-500">No open tasks.</p> : (
        <table className="w-full text-sm">
          <thead className="text-left text-xs text-ink-500">
            <tr><th className="px-4 py-2 font-medium">Employee</th><th className="px-3 py-2 text-right font-medium">Open</th><th className="px-3 py-2 text-right font-medium">Overdue</th><th className="hidden px-3 py-2 text-right font-medium sm:table-cell">Due this week</th><th className="hidden px-3 py-2 text-right font-medium sm:table-cell">Blocked</th></tr>
          </thead>
          <tbody className="divide-y divide-ink-100">
            {rows.map((r) => (
              <tr key={r.user_id ?? "_none"}>
                <td className="px-4 py-2"><span className={r.user_id ? "text-ink-900" : "italic text-ink-600"}>{r.name}</span></td>
                <td className="num px-3 py-2 text-right">{r.open}</td>
                <td className={`num px-3 py-2 text-right ${r.overdue ? "font-semibold text-brand-700" : "text-ink-300"}`}>{r.overdue}</td>
                <td className={`num hidden px-3 py-2 text-right sm:table-cell ${r.due_this_week ? "text-amber-700" : "text-ink-300"}`}>{r.due_this_week}</td>
                <td className={`num hidden px-3 py-2 text-right sm:table-cell ${r.blocked ? "text-brand-700" : "text-ink-300"}`}>{r.blocked}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </Card>
  );
}
