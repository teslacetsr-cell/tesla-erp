"use client";

import Link from "next/link";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, CalendarClock, CheckCircle2, Circle, CircleDot, Pencil, Trash2, UserRound } from "lucide-react";
import { Badge, Button, ErrorNote, Field, Input, Modal, Select, Textarea, useConfirm, useToast } from "@/components/ui";
import { peopleOptions } from "@/components/crm/common";
import { api } from "@/lib/api/client";
import { date, titleCase } from "@/lib/format";

type Tone = "green" | "red" | "grey" | "amber" | "blue";

export const SO_STATUSES: [string, string, Tone][] = [
  ["confirmed", "Confirmed", "blue"], ["in_progress", "In progress", "amber"], ["completed", "Completed", "green"],
  ["cancelled", "Cancelled", "grey"],
];
export const PROJECT_STATUSES: [string, string, Tone][] = [
  ["planning", "Planning", "grey"], ["active", "Active", "blue"], ["on_hold", "On hold", "amber"],
  ["completed", "Completed", "green"], ["cancelled", "Cancelled", "grey"],
];
export const TASK_STATUSES: [string, string, Tone][] = [
  ["todo", "To do", "grey"], ["in_progress", "In progress", "blue"], ["blocked", "Blocked", "red"], ["done", "Done", "green"],
];
export const ISSUE_SEVERITIES: [string, string, Tone][] = [
  ["low", "Low", "grey"], ["normal", "Normal", "blue"], ["high", "High", "amber"], ["critical", "Critical", "red"],
];
export const ISSUE_STATUSES: [string, string, Tone][] = [["open", "Open", "amber"], ["resolved", "Resolved", "green"], ["closed", "Closed", "grey"]];
export const PRIORITY_OPTIONS: [string, string][] = [["low", "Low"], ["normal", "Normal"], ["high", "High"], ["urgent", "Urgent"]];

function pick(set: [string, string, Tone][], v: string) {
  const s = set.find(([k]) => k === v);
  return <Badge tone={s?.[2] ?? "grey"}>{s?.[1] ?? titleCase(v)}</Badge>;
}
export const SoStatus = ({ status }: { status: string }) => pick(SO_STATUSES, status);
export const ProjectStatus = ({ status }: { status: string }) => pick(PROJECT_STATUSES, status);
export const TaskStatus = ({ status }: { status: string }) => pick(TASK_STATUSES, status);
export const Severity = ({ severity }: { severity: string }) => pick(ISSUE_SEVERITIES, severity);
export const IssueStatus = ({ status }: { status: string }) => pick(ISSUE_STATUSES, status);

export function ProgressBar({ value, tone = "brand", className = "" }: { value: number; tone?: "brand" | "green" | "amber"; className?: string }) {
  const v = Math.max(0, Math.min(100, value || 0));
  const color = tone === "green" ? "bg-emerald-500" : tone === "amber" ? "bg-amber-500" : "bg-brand-600";
  return (
    <div className={`h-1.5 w-full overflow-hidden rounded-full bg-ink-100 ${className}`} role="progressbar" aria-valuenow={v} aria-valuemin={0} aria-valuemax={100}>
      <div className={`h-full rounded-full ${color}`} style={{ width: `${v}%` }} />
    </div>
  );
}

const today = () => new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" });
export { today as istToday };

const STATUS_ICON: Record<string, typeof Circle> = { todo: Circle, in_progress: CircleDot, blocked: AlertTriangle, done: CheckCircle2 };

/* ------------------------------------------------------------------ tasks */
export function TaskDialog({ open, onClose, projectId, task, team, milestones, onSaved }: {
  open: boolean; onClose: () => void; projectId: string; task?: any; team: { id: string; name: string }[];
  milestones: { id: string; name: string }[]; onSaved: () => void;
}) {
  const toast = useToast();
  const [v, setV] = useState(() => ({
    title: task?.title ?? "", description: task?.description ?? "", assigned_to: task?.assigned_to ?? "",
    milestone_id: task?.milestone_id ?? "", start_date: task?.start_date ?? "", due_date: task?.due_date ?? "",
    priority: task?.priority ?? "normal", status: task?.status ?? "todo", blocked_reason: task?.blocked_reason ?? "",
  }));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV({ ...v, [k]: e.target.value });
  const n = (s: string) => (s.trim() ? s.trim() : null);
  async function save() {
    setError(null);
    if (v.title.trim().length < 2) return setError(new Error("Enter the task."));
    setBusy(true);
    try {
      const body: any = { title: v.title.trim(), description: n(v.description), assigned_to: n(v.assigned_to), milestone_id: n(v.milestone_id),
        start_date: n(v.start_date), due_date: n(v.due_date), priority: v.priority };
      if (task) await api(`/tasks/${task.id}`, { method: "PUT", body: { ...body, status: v.status, blocked_reason: n(v.blocked_reason), row_version: task.row_version } });
      else await api(`/projects/${projectId}/tasks`, { body });
      toast(task ? "Task saved" : "Task added");
      onSaved();
      onClose();
    } catch (e) { setError(e); } finally { setBusy(false); }
  }
  return (
    <Modal open={open} onClose={onClose} title={task ? "Edit task" : "New task"}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={save}>{task ? "Save" : "Add task"}</Button></>}>
      <div className="space-y-3">
        <ErrorNote error={error} />
        <Field label="Task" required><Input value={v.title} onChange={set("title")} placeholder="e.g. Fix air terminals on the north parapet" /></Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Assigned to" hint="Assigning puts the person on the project team.">
            <Select value={v.assigned_to} onChange={set("assigned_to")}>{peopleOptions(team).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select>
          </Field>
          <Field label="Milestone">
            <Select value={v.milestone_id} onChange={set("milestone_id")}><option value="">—</option>{milestones.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</Select>
          </Field>
          <Field label="Start"><Input type="date" value={v.start_date} onChange={set("start_date")} /></Field>
          <Field label="Due"><Input type="date" value={v.due_date} onChange={set("due_date")} /></Field>
          <Field label="Priority"><Select value={v.priority} onChange={set("priority")}>{PRIORITY_OPTIONS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          {task && <Field label="Status"><Select value={v.status} onChange={set("status")}>{TASK_STATUSES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>}
        </div>
        {task && v.status === "blocked" && <Field label="What is blocking it?" required><Input value={v.blocked_reason} onChange={set("blocked_reason")} /></Field>}
        <Field label="Details"><Textarea rows={3} value={v.description} onChange={set("description")} /></Field>
      </div>
    </Modal>
  );
}

/** Task rows with a one-tap status change (the assignee can always move their own task). */
export function TaskList({ tasks, showProject = false, onChanged, onEdit }: {
  tasks: any[]; showProject?: boolean; onChanged: () => void; onEdit?: (t: any) => void;
}) {
  const toast = useToast();
  const confirm = useConfirm();
  const [blocking, setBlocking] = useState<any>(null);
  const [reason, setReason] = useState("");
  async function move(t: any, status: string, blocked_reason?: string) {
    try {
      await api(`/tasks/${t.id}/status`, { body: { status, blocked_reason: blocked_reason ?? null } });
      toast(status === "done" ? "Task done" : `Task ${TASK_STATUSES.find(([k]) => k === status)?.[1].toLowerCase()}`);
      onChanged();
    } catch (e: any) { toast(e.message, "error"); }
  }
  return (
    <>
      <ul className="divide-y divide-ink-100">
        {tasks.map((t) => {
          const Icon = STATUS_ICON[t.status] ?? Circle;
          return (
            <li key={t.id} className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center">
              <div className="flex min-w-0 flex-1 items-start gap-2.5">
                <Icon className={`mt-0.5 size-4 shrink-0 ${t.status === "done" ? "text-emerald-600" : t.status === "blocked" ? "text-brand-600" : t.status === "in_progress" ? "text-sky-600" : "text-ink-400"}`} />
                <div className="min-w-0">
                  <p className={`font-medium ${t.status === "done" ? "text-ink-500 line-through" : "text-ink-900"}`}>{t.title}</p>
                  <p className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-ink-500">
                    {showProject && <Link href={`/projects/view?id=${t.project_id}&tab=tasks`} className="text-brand-700 hover:underline">{t.project_number} · {t.project_name}</Link>}
                    <span className="inline-flex items-center gap-1"><UserRound className="size-3" />{t.assignee ?? "Unassigned"}</span>
                    {t.due_date && <span className={`inline-flex items-center gap-1 ${t.overdue ? "font-medium text-brand-700" : ""}`}><CalendarClock className="size-3" />{t.overdue ? "Overdue · " : "Due "}{date(t.due_date)}</span>}
                    {t.milestone && <span>{t.milestone}</span>}
                    {t.priority !== "normal" && <Badge tone={t.priority === "urgent" ? "red" : t.priority === "high" ? "amber" : "grey"}>{titleCase(t.priority)}</Badge>}
                  </p>
                  {t.status === "blocked" && t.blocked_reason && <p className="mt-0.5 text-xs text-brand-700">Blocked: {t.blocked_reason}</p>}
                </div>
              </div>
              <div className="flex shrink-0 flex-wrap items-center gap-1.5 pl-6 sm:pl-0">
                {t.can.status ? (
                  <Select value={t.status} aria-label={`Status of ${t.title}`} className="h-8 w-36 text-[13px]"
                    onChange={(e) => { const s = e.target.value; if (s === "blocked") { setReason(""); setBlocking(t); } else move(t, s); }}>
                    {TASK_STATUSES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
                  </Select>
                ) : <TaskStatus status={t.status} />}
                {onEdit && t.can.edit && <Button size="sm" variant="ghost" aria-label="Edit task" onClick={() => onEdit(t)}><Pencil className="size-3.5" /></Button>}
                {t.can.delete && onEdit && <Button size="sm" variant="ghost" aria-label="Delete task" onClick={async () => {
                  if (!(await confirm({ title: "Delete this task?", body: t.title, confirmLabel: "Delete" }))) return;
                  await api(`/tasks/${t.id}`, { method: "DELETE" });
                  onChanged();
                }}><Trash2 className="size-3.5 text-ink-400" /></Button>}
              </div>
            </li>
          );
        })}
      </ul>
      <Modal open={!!blocking} onClose={() => setBlocking(null)} title="What is blocking the task?"
        footer={<><Button variant="secondary" onClick={() => setBlocking(null)}>Back</Button><Button disabled={!reason.trim()} onClick={async () => { await move(blocking, "blocked", reason.trim()); setBlocking(null); }}>Mark blocked</Button></>}>
        <Field label="Reason" required hint="The project manager is notified."><Textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
      </Modal>
    </>
  );
}

/* ------------------------------------------------------------------ issues */
export function IssueDialog({ open, onClose, projectId, issue, team, onSaved }: {
  open: boolean; onClose: () => void; projectId: string; issue?: any; team: { id: string; name: string }[]; onSaved: () => void;
}) {
  const toast = useToast();
  const [v, setV] = useState(() => ({
    title: issue?.title ?? "", description: issue?.description ?? "", severity: issue?.severity ?? "normal",
    assigned_to: issue?.assigned_to ?? "", status: issue?.status ?? "open", resolution: issue?.resolution ?? "",
  }));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV({ ...v, [k]: e.target.value });
  const n = (s: string) => (s.trim() ? s.trim() : null);
  async function save() {
    setError(null);
    if (v.title.trim().length < 3) return setError(new Error("Describe the issue in a few words."));
    setBusy(true);
    try {
      const body: any = { title: v.title.trim(), description: n(v.description), severity: v.severity, assigned_to: n(v.assigned_to) };
      if (issue) await api(`/issues/${issue.id}`, { method: "PUT", body: { ...body, status: v.status, resolution: n(v.resolution), row_version: issue.row_version } });
      else await api(`/projects/${projectId}/issues`, { body });
      toast(issue ? "Issue saved" : "Issue raised — the project manager is notified");
      onSaved();
      onClose();
    } catch (e) { setError(e); } finally { setBusy(false); }
  }
  return (
    <Modal open={open} onClose={onClose} title={issue ? "Issue" : "Raise an issue"}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={save}>{issue ? "Save" : "Raise issue"}</Button></>}>
      <div className="space-y-3">
        <ErrorNote error={error} />
        <Field label="Issue" required><Input value={v.title} onChange={set("title")} placeholder="e.g. Roof access blocked" /></Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Severity"><Select value={v.severity} onChange={set("severity")}>{ISSUE_SEVERITIES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          <Field label="Assigned to"><Select value={v.assigned_to} onChange={set("assigned_to")}>{peopleOptions(team).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          {issue && <Field label="Status"><Select value={v.status} onChange={set("status")}>{ISSUE_STATUSES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>}
        </div>
        <Field label="Details"><Textarea rows={3} value={v.description} onChange={set("description")} /></Field>
        {issue && v.status !== "open" && <Field label="How was it resolved?" required><Textarea rows={2} value={v.resolution} onChange={set("resolution")} /></Field>}
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------------ site report form */
export function SiteReportForm({ projectId, lines, report, onDone, onCancel }: {
  projectId: string; lines: any[]; report?: any; onDone: (r: any) => void; onCancel: () => void;
}) {
  const qc = useQueryClient();
  const toast = useToast();
  const [v, setV] = useState(() => ({
    report_date: report?.report_date ?? today(), work_done: report?.work_done ?? "", manpower: report?.manpower?.toString() ?? "",
    weather: report?.weather ?? "", hindrances: report?.hindrances ?? "", next_plan: report?.next_plan ?? "",
    progress_pct: report?.progress_pct?.toString() ?? "",
  }));
  const [inst, setInst] = useState<Record<string, { qty: string; location: string }>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV({ ...v, [k]: e.target.value });
  const open = lines.filter((l) => Number(l.remaining_qty) > 0);
  async function save(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (v.work_done.trim().length < 3) return setError(new Error("Describe the work done today."));
    const installations = Object.entries(inst).filter(([, x]) => x.qty.trim() && Number(x.qty) > 0)
      .map(([id, x]) => ({ boq_line_id: id, quantity: x.qty.trim(), location: x.location.trim() || null }));
    for (const i of installations) {
      const l = lines.find((x) => x.id === i.boq_line_id);
      if (l && Number(i.quantity) > Number(l.remaining_qty))
        return setError(new Error(`Line ${l.line_no}: only ${l.remaining_qty} ${l.unit} remain of the approved ${l.approved_qty}.`));
    }
    setBusy(true);
    try {
      const body = { report_date: v.report_date, work_done: v.work_done.trim(), manpower: v.manpower ? Number(v.manpower) : null,
        weather: v.weather.trim() || null, hindrances: v.hindrances.trim() || null, next_plan: v.next_plan.trim() || null,
        progress_pct: v.progress_pct === "" ? null : Number(v.progress_pct), installations: report ? [] : installations };
      const r = report ? await api(`/site-reports/${report.id}`, { method: "PUT", body }) : await api(`/projects/${projectId}/site-reports`, { body });
      toast(report ? "Report saved" : "Site report saved");
      qc.invalidateQueries({ queryKey: ["/projects"] });
      qc.invalidateQueries({ queryKey: ["/site-reports"] });
      onDone(r.data);
    } catch (err) { setError(err); window.scrollTo({ top: 0, behavior: "smooth" }); } finally { setBusy(false); }
  }
  return (
    <form onSubmit={save} className="space-y-4">
      <ErrorNote error={error} />
      <div className="grid gap-3 sm:grid-cols-4">
        <Field label="Date" required><Input type="date" value={v.report_date} max={today()} onChange={set("report_date")} /></Field>
        <Field label="Manpower on site"><Input inputMode="numeric" value={v.manpower} onChange={set("manpower")} placeholder="e.g. 6" /></Field>
        <Field label="Weather"><Input value={v.weather} onChange={set("weather")} placeholder="e.g. Sunny" /></Field>
        <Field label="Overall progress %" hint="Updates the project progress"><Input inputMode="numeric" value={v.progress_pct} onChange={set("progress_pct")} placeholder="0–100" /></Field>
      </div>
      <Field label="Work done" required><Textarea rows={3} value={v.work_done} onChange={set("work_done")} /></Field>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Hindrances" hint="The project manager is notified."><Textarea rows={2} value={v.hindrances} onChange={set("hindrances")} /></Field>
        <Field label="Plan for tomorrow"><Textarea rows={2} value={v.next_plan} onChange={set("next_plan")} /></Field>
      </div>
      {!report && (
        <div>
          <p className="mb-1 text-[13px] font-medium text-ink-700">Installed today</p>
          <p className="mb-2 text-xs text-ink-500">Enter only the lines worked on. The quantity cannot exceed what remains of the approved BOQ.</p>
          {open.length === 0 ? <p className="text-sm text-ink-500">Every BOQ line is fully installed.</p> : (
            <div className="overflow-x-auto rounded-md border border-ink-200">
              <table className="w-full min-w-[560px] text-sm">
                <thead className="bg-ink-50 text-left text-xs text-ink-500"><tr><th className="px-2 py-1.5">#</th><th className="px-2 py-1.5">Item</th><th className="px-2 py-1.5 text-right">Remaining</th><th className="w-28 px-2 py-1.5">Qty today</th><th className="w-40 px-2 py-1.5">Location</th></tr></thead>
                <tbody className="divide-y divide-ink-100">
                  {open.map((l) => (
                    <tr key={l.id}>
                      <td className="px-2 py-1.5 text-ink-500">{l.line_no}</td>
                      <td className="px-2 py-1.5">{l.description}</td>
                      <td className="num px-2 py-1.5 text-right text-ink-600">{l.remaining_qty} {l.unit}</td>
                      <td className="px-2 py-1"><Input inputMode="decimal" className="num h-8" aria-label={`Installed today, line ${l.line_no}`} value={inst[l.id]?.qty ?? ""}
                        onChange={(e) => setInst({ ...inst, [l.id]: { qty: e.target.value, location: inst[l.id]?.location ?? "" } })} /></td>
                      <td className="px-2 py-1"><Input className="h-8" aria-label={`Location, line ${l.line_no}`} value={inst[l.id]?.location ?? ""}
                        onChange={(e) => setInst({ ...inst, [l.id]: { qty: inst[l.id]?.qty ?? "", location: e.target.value } })} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
      <div className="flex justify-end gap-2">
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
        <Button type="submit" loading={busy}>{report ? "Save report" : "Save site report"}</Button>
      </div>
    </form>
  );
}
