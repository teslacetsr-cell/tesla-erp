"use client";

import { useEffect } from "react";
import type { FieldValues, Path, UseFormReturn } from "react-hook-form";
import { Field, Input, Select } from "@/components/ui";
import { ApiError } from "@/lib/api/client";
import { GST_STATES } from "@/lib/format";

/** Push server-side validation errors (422 details) onto the matching form fields. */
export function applyServerErrors<T extends FieldValues>(form: UseFormReturn<T>, err: unknown) {
  const fields = err instanceof ApiError ? Object.entries(err.fieldErrors()) : [];
  for (const [field, message] of fields) {
    form.setError(field as Path<T>, { type: "server", message }, { shouldFocus: false });
  }
  // Bring the problem into view: the first invalid field if there is one, otherwise the error banner.
  if (fields.length) {
    try {
      form.setFocus(fields[0][0] as Path<T>, { shouldSelect: false });
      return;
    } catch {
      /* field not registered on this form */
    }
  }
  if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
}

/** Blank strings become null so optional fields are cleared rather than sent as "". */
export function clean<T extends Record<string, any>>(values: T): T {
  const out: Record<string, any> = {};
  for (const [k, v] of Object.entries(values)) out[k] = typeof v === "string" && v.trim() === "" ? null : v;
  return out as T;
}

export function AddressFields<T extends FieldValues>({ form, prefix = "" }: { form: UseFormReturn<T>; prefix?: string }) {
  const { register, formState, setValue, watch } = form;
  const e = formState.errors as Record<string, { message?: string }>;
  const n = (k: string) => `${prefix}${k}` as Path<T>;
  const stateCode = watch(n("state_code"));
  useEffect(() => {
    const s = GST_STATES.find(([c]) => c === stateCode);
    if (s) setValue(n("state"), s[1] as any);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stateCode]);
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <Field label="Address line 1" error={e[n("address_line1")]?.message} className="sm:col-span-2">
        <Input {...register(n("address_line1"))} />
      </Field>
      <Field label="Address line 2" error={e[n("address_line2")]?.message} className="sm:col-span-2">
        <Input {...register(n("address_line2"))} />
      </Field>
      <Field label="City" error={e[n("city")]?.message}>
        <Input {...register(n("city"))} />
      </Field>
      <Field label="District" error={e[n("district")]?.message}>
        <Input {...register(n("district"))} />
      </Field>
      <Field label="State" error={e[n("state_code")]?.message} hint="Sets the GST place of supply">
        <Select {...register(n("state_code"))}>
          <option value="">Select state…</option>
          {GST_STATES.map(([code, name]) => (
            <option key={code} value={code}>
              {name} ({code})
            </option>
          ))}
        </Select>
      </Field>
      <Field label="PIN code" error={e[n("pincode")]?.message}>
        <Input inputMode="numeric" maxLength={6} {...register(n("pincode"))} />
      </Field>
    </div>
  );
}

/** When a valid-looking GSTIN is typed, derive state and PAN from it (the server re-checks everything). */
export function useGstinAutofill<T extends FieldValues>(form: UseFormReturn<T>) {
  const gstin = (form.watch("gstin" as Path<T>) as string | undefined)?.toUpperCase?.();
  useEffect(() => {
    if (gstin && /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(gstin)) {
      form.setValue("state_code" as Path<T>, gstin.slice(0, 2) as any);
      form.setValue("pan" as Path<T>, gstin.slice(2, 12) as any);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gstin]);
}
