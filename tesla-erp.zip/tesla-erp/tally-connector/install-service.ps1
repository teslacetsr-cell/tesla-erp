<#
.SYNOPSIS
  Installs the TCE Tally Connector so it starts automatically with Windows.

.DESCRIPTION
  Run in an *Administrator* PowerShell from the connector folder (e.g. C:\TCE-Tally-Connector):

      powershell -ExecutionPolicy Bypass -File .\install-service.ps1

  Primary method: a real Windows service via NSSM (free, https://nssm.cc/download). Put nssm.exe
  (from the "win64" folder of the NSSM zip) next to this script, or pass -NssmPath.
  The service starts at boot, restarts automatically 10 s after any exit, and is visible in services.msc
  as "TCE Tally Connector".

  Fallback (no NSSM): -Mode Task registers a Task Scheduler task "At startup, run whether user is
  logged on or not" (as SYSTEM) that restarts every minute on failure.

  The program used is TCE-Tally-Connector.exe if present in the folder, otherwise
  "python connector.py run" (Python 3.11+ must be installed for all users).

.EXAMPLE
  .\install-service.ps1                       # NSSM service (nssm.exe next to the script)
  .\install-service.ps1 -NssmPath C:\Tools\nssm.exe
  .\install-service.ps1 -Mode Task            # Task Scheduler fallback
#>
[CmdletBinding()]
param(
    [ValidateSet("Nssm", "Task")] [string]$Mode = "Nssm",
    [string]$NssmPath = "",
    [string]$InstallDir = $PSScriptRoot,
    [string]$ServiceName = "TCETallyConnector"
)
$ErrorActionPreference = "Stop"

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Please run this script in PowerShell opened with 'Run as administrator'."
}

$InstallDir = (Resolve-Path $InstallDir).Path
$config = Join-Path $InstallDir "connector.ini"
if (-not (Test-Path $config)) {
    throw "connector.ini not found in $InstallDir. Copy connector.example.ini to connector.ini and fill it in first."
}

# Which program to run. The working directory is $InstallDir and the connector finds connector.ini
# next to itself, so the arguments need no paths (avoids quoting problems with native commands).
$exe = Join-Path $InstallDir "TCE-Tally-Connector.exe"
if (Test-Path $exe) {
    $program = $exe
    $arguments = "run"
} else {
    $py = (Get-Command python.exe -ErrorAction SilentlyContinue).Source
    if (-not $py) { $py = (Get-Command py.exe -ErrorAction SilentlyContinue).Source }
    if (-not $py) { throw "Neither TCE-Tally-Connector.exe nor Python was found." }
    $program = $py
    $arguments = "connector.py run"
}

# Quick self-check before installing (does not stop installation on failure).
Write-Host "Running self test..." -ForegroundColor Cyan
if ($program -eq $exe) { & $exe test --config $config } else { & $program (Join-Path $InstallDir 'connector.py') test --config $config }
if ($LASTEXITCODE -ne 0) { Write-Warning "Self test reported problems (see above). Installing anyway; fix them and restart the service." }

$logs = Join-Path $InstallDir "logs"
New-Item -ItemType Directory -Force -Path $logs | Out-Null

if ($Mode -eq "Nssm") {
    if (-not $NssmPath) { $NssmPath = Join-Path $InstallDir "nssm.exe" }
    if (-not (Test-Path $NssmPath)) {
        throw "nssm.exe not found at $NssmPath. Download NSSM from https://nssm.cc/download, copy win64\nssm.exe here, or use -Mode Task."
    }
    $existing = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($existing) {
        Write-Host "Service exists - replacing it." -ForegroundColor Yellow
        & $NssmPath stop $ServiceName | Out-Null
        & $NssmPath remove $ServiceName confirm | Out-Null
    }
    & $NssmPath install $ServiceName $program $arguments
    if ($LASTEXITCODE -ne 0) { throw "nssm install failed" }
    & $NssmPath set $ServiceName AppDirectory $InstallDir | Out-Null
    & $NssmPath set $ServiceName DisplayName "TCE Tally Connector" | Out-Null
    & $NssmPath set $ServiceName Description "Sends ERP accounting entries to TallyPrime on this PC (outbound HTTPS only)." | Out-Null
    & $NssmPath set $ServiceName Start SERVICE_DELAYED_AUTO_START | Out-Null   # wait for network at boot
    & $NssmPath set $ServiceName AppExit Default Restart | Out-Null
    & $NssmPath set $ServiceName AppRestartDelay 10000 | Out-Null
    & $NssmPath set $ServiceName AppThrottle 30000 | Out-Null
    & $NssmPath set $ServiceName AppStopMethodConsole 15000 | Out-Null       # Ctrl+C, let a running job finish
    & $NssmPath set $ServiceName AppStderr (Join-Path $logs "service-errors.log") | Out-Null
    & $NssmPath set $ServiceName AppRotateFiles 1 | Out-Null
    & $NssmPath set $ServiceName AppRotateBytes 1048576 | Out-Null
    & $NssmPath start $ServiceName
    Start-Sleep -Seconds 3
    Get-Service -Name $ServiceName | Format-Table -AutoSize Name, DisplayName, Status
    Write-Host "Installed as Windows service '$ServiceName'. Logs: $logs" -ForegroundColor Green
}
else {
    $taskName = "TCE Tally Connector"
    if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
        Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    }
    $action = New-ScheduledTaskAction -Execute $program -Argument $arguments -WorkingDirectory $InstallDir
    $trigger = New-ScheduledTaskTrigger -AtStartup
    $trigger.Delay = "PT1M"   # give the network a minute at boot
    # SYSTEM = "Run whether user is logged on or not" without storing a password.
    $runAs = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
        -StartWhenAvailable -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) `
        -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $runAs `
        -Settings $settings -Description "TCE Tally Connector (sends ERP entries to TallyPrime)" | Out-Null
    Start-ScheduledTask -TaskName $taskName
    Write-Host "Installed as scheduled task '$taskName' (starts at boot). Logs: $logs" -ForegroundColor Green
}
