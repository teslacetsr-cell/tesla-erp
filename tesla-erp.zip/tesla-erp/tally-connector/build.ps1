<#
.SYNOPSIS
  Builds TCE-Tally-Connector.exe (single file) with PyInstaller and assembles a ready-to-copy folder.

.DESCRIPTION
  Run on a Windows build PC with Python 3.11+ installed ("py" launcher or "python" on PATH):

      powershell -ExecutionPolicy Bypass -File .\build.ps1

  Output: .\dist\TCE-Tally-Connector\  containing the exe, connector.example.ini, the install scripts and README.md.
  Copy that folder to the office PC (e.g. C:\TCE-Tally-Connector).
#>
[CmdletBinding()]
param(
    [string]$Python = ""
)
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

if (-not $Python) {
    if (Get-Command py -ErrorAction SilentlyContinue) { $Python = "py -3" } else { $Python = "python" }
}
function Invoke-Py([string]$Arguments) {
    $cmd = "$Python $Arguments"
    Write-Host "> $cmd"
    cmd /c $cmd
    if ($LASTEXITCODE -ne 0) { throw "Command failed: $cmd" }
}

# Isolated build environment so nothing else on the PC ends up in the exe.
if (-not (Test-Path .\.build-venv)) { Invoke-Py "-m venv .build-venv" }
$venvPy = Join-Path $PSScriptRoot ".build-venv\Scripts\python.exe"
& $venvPy -m pip install --upgrade pip pyinstaller
if ($LASTEXITCODE -ne 0) { throw "pip install pyinstaller failed" }

$pyiArgs = @("--onefile", "--console", "--clean", "--noconfirm", "--name", "TCE-Tally-Connector", "connector.py")
$icon = Join-Path $PSScriptRoot "..\desktop\tce.ico"
if (Test-Path $icon) { $pyiArgs = @("--icon", (Resolve-Path $icon).Path) + $pyiArgs }
& $venvPy -m PyInstaller @pyiArgs
if ($LASTEXITCODE -ne 0) { throw "PyInstaller failed" }

$out = Join-Path $PSScriptRoot "dist\TCE-Tally-Connector"
New-Item -ItemType Directory -Force -Path $out | Out-Null
Copy-Item .\dist\TCE-Tally-Connector.exe $out -Force
foreach ($f in "connector.example.ini", "install-service.ps1", "uninstall-service.ps1", "README.md") {
    Copy-Item (Join-Path $PSScriptRoot $f) $out -Force
}
Write-Host ""
Write-Host "Built: $out" -ForegroundColor Green
& (Join-Path $out "TCE-Tally-Connector.exe") --version
