<#
.SYNOPSIS
  Removes the TCE Tally Connector service (NSSM) and/or scheduled task. Files and logs are kept.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\uninstall-service.ps1
#>
[CmdletBinding()]
param(
    [string]$NssmPath = "",
    [string]$ServiceName = "TCETallyConnector"
)
$ErrorActionPreference = "Stop"

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Please run this script in PowerShell opened with 'Run as administrator'."
}

$removed = $false
if (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) {
    if (-not $NssmPath) { $NssmPath = Join-Path $PSScriptRoot "nssm.exe" }
    if (Test-Path $NssmPath) {
        & $NssmPath stop $ServiceName | Out-Null
        & $NssmPath remove $ServiceName confirm
    } else {
        Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
        sc.exe delete $ServiceName | Out-Null
    }
    Write-Host "Service '$ServiceName' removed." -ForegroundColor Green
    $removed = $true
}

$taskName = "TCE Tally Connector"
if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
    Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    Write-Host "Scheduled task '$taskName' removed." -ForegroundColor Green
    $removed = $true
}

if (-not $removed) { Write-Host "Nothing to remove - the connector was not installed as a service or task." }
Write-Host "connector.ini, the outbox and the logs folder were left in place."
