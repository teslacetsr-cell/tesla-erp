"""End-to-end tests: connector <-> mock TallyPrime <-> fake ERP (all in-process, free ports)."""

from __future__ import annotations

import json
import subprocess
import sys
import urllib.request
from typing import Any

import pytest

import connector
import mock_tally
from conftest import KEY, ROOT, free_port, tally_url

COMPANY = "Tesla Consulting Engineers"


# -- XML builders (shaped like the ERP's, doc §5) ------------------------------------------


def masters_xml(*ledgers: tuple[str, str], action: str = "Create") -> str:
    body = "".join(
        f'<LEDGER NAME="{n}" ACTION="{action}"><NAME.LIST><NAME>{n}</NAME></NAME.LIST><PARENT>{p}</PARENT>'
        f"<PARTYGSTIN>32AAACA1234A1Z5</PARTYGSTIN><LEDSTATENAME>Kerala</LEDSTATENAME>"
        f"<ADDRESS.LIST><ADDRESS>MG Road</ADDRESS></ADDRESS.LIST></LEDGER>"
        for n, p in ledgers)
    return ("<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA>"
            "<REQUESTDESC><REPORTNAME>All Masters</REPORTNAME><STATICVARIABLES>"
            f"<SVCURRENTCOMPANY>{COMPANY}</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC>"
            f'<REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF">{body}</TALLYMESSAGE></REQUESTDATA>'
            "</IMPORTDATA></BODY></ENVELOPE>")


def voucher_xml(number: str, entries: list[tuple[str, str]], vtype: str = "Sales", party: str = "ABC Hospital",
                date: str = "20261007", action: str = "Create") -> str:
    ents = "".join(
        f"<ALLLEDGERENTRIES.LIST><LEDGERNAME>{led}</LEDGERNAME>"
        f"<ISDEEMEDPOSITIVE>{'Yes' if amt.startswith('-') else 'No'}</ISDEEMEDPOSITIVE>"
        f"<AMOUNT>{amt}</AMOUNT></ALLLEDGERENTRIES.LIST>" for led, amt in entries)
    return ("<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA>"
            "<REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME><STATICVARIABLES>"
            f"<SVCURRENTCOMPANY>{COMPANY}</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC>"
            '<REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF">'
            f'<VOUCHER REMOTEID="erp-{number}" VCHTYPE="{vtype}" ACTION="{action}" OBJVIEW="Accounting Voucher View">'
            f"<DATE>{date}</DATE><VOUCHERTYPENAME>{vtype}</VOUCHERTYPENAME><VOUCHERNUMBER>{number}</VOUCHERNUMBER>"
            f"<PARTYLEDGERNAME>{party}</PARTYLEDGERNAME><NARRATION>Test &amp; check</NARRATION>{ents}</VOUCHER>"
            "</TALLYMESSAGE></REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>")


SALES_ENTRIES = [("ABC Hospital", "-118000.00"), ("Sales — Projects &amp; Services", "100000.00"),
                 ("Output GST", "18000.00")]
BASE_LEDGERS = (("ABC Hospital", "Sundry Debtors"), ("Sales — Projects &amp; Services", "Sales Accounts"),
                ("Output GST", "Duties &amp; Taxes"))


def export_xml(ctype: str, static: str = "", extra_tdl: str = "") -> str:
    return ("<ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE>"
            "<ID>TCE Export</ID></HEADER><BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>"
            f"{static}</STATICVARIABLES><TDL><TDLMESSAGE><COLLECTION NAME=\"TCE Export\" ISMODIFY=\"No\">"
            f"<TYPE>{ctype}</TYPE><FETCH>*</FETCH>{'<FILTERS>VchTypeFilter</FILTERS>' if extra_tdl else ''}"
            f"</COLLECTION>{extra_tdl}</TDLMESSAGE></TDL></DESC></BODY></ENVELOPE>")


def post_tally(srv: mock_tally.MockTallyServer, xml: str) -> str:
    res = connector.TallyClient(tally_url(srv), 5).post(xml)
    assert res.ok, res.error
    return res.response or ""


def log_text(c: connector.Connector) -> str:
    return "".join(p.read_text(encoding="utf-8") for p in c.cfg.log_dir.glob("connector.log*"))


# -- connector end-to-end --------------------------------------------------------------


def test_happy_path_master_then_voucher(tally, erp, make_connector):
    j1 = erp.add_job(masters_xml(*BASE_LEDGERS), "Ledgers")
    j2 = erp.add_job(voucher_xml("TCE/2627/0001", SALES_ENTRIES), "Sales TCE/2627/0001")
    j3 = erp.add_job(export_xml("Ledger"), "Ledger balances", kind="export")
    c = make_connector(erp.base_url, tally_url(tally))

    out = c.run_cycle()

    assert out.status == "ok" and out.jobs_leased == 3 and out.jobs_done == 3
    assert [r["job_id"] for r in erp.results] == [j1.id, j2.id, j3.id]
    r1, r2, r3 = (r["body"] for r in erp.results)
    assert r1["ok"] is True and r1["status_code"] == 200 and r1["error"] is None
    assert "<CREATED>3</CREATED>" in r1["response"] and "<ERRORS>0</ERRORS>" in r1["response"]
    assert "<CREATED>1</CREATED>" in r2["response"] and "<LASTVCHID>1</LASTVCHID>" in r2["response"]
    assert '<LEDGER NAME="ABC Hospital"' in r3["response"]
    assert "<CLOSINGBALANCE TYPE=\"Amount\">-118000.00</CLOSINGBALANCE>" in r3["response"]
    assert isinstance(r1["elapsed_ms"], int)
    assert all(j.status == "done" for j in erp.jobs)

    hb = erp.heartbeats[0]
    assert hb["tally_ok"] is True and hb["tally_company"] == COMPANY and hb["agent_version"] == connector.__version__
    assert erp.auth_headers[0] == f"Bearer {KEY}"
    assert erp.user_agents[0] == f"TCE-Tally-Connector/{connector.__version__}"

    state = tally.state.snapshot()
    assert state["ledgers"]["ABC Hospital"]["gstin"] == "32AAACA1234A1Z5"
    assert state["vouchers"][0]["number"] == "TCE/2627/0001"
    assert state["ledgers"]["Sales — Projects & Services"]["closing"] == "100000.00"
    assert not c.cfg.outbox_file.exists()


def test_tally_down_reports_failure_and_retries_later(start_tally, erp, make_connector):
    dead = f"http://127.0.0.1:{free_port()}"
    j1 = erp.add_job(masters_xml(*BASE_LEDGERS), "Ledgers")
    j2 = erp.add_job(voucher_xml("TCE/2627/0001", SALES_ENTRIES), "Sales")
    c = make_connector(erp.base_url, dead)

    out = c.run_cycle()

    assert out.status == "error"
    assert erp.heartbeats[0]["tally_ok"] is False and "Connection refused" in erp.heartbeats[0]["tally_error"]
    # Only the first job is attempted; the rest are left alone so the order is kept.
    assert len(erp.results) == 1
    body = erp.results[0]["body"]
    assert body == {"ok": False, "status_code": None, "response": None,
                    "error": f"Connection refused ({dead})", "elapsed_ms": body["elapsed_ms"]}
    assert j1.status == "pending"
    assert connector.next_sleep(out, 60, 1) == 60 and connector.next_sleep(out, 60, 4) == 300

    # Tally comes back; the ERP hands the jobs out again (simulate lease expiry for job 2).
    srv = start_tally()
    c.tally = connector.TallyClient(tally_url(srv), 5)
    j2.leased_until = 0
    out = c.run_cycle()
    assert out.status == "ok" and out.jobs_done == 2
    assert j1.status == "done" and j2.status == "done" and j1.attempt == 2


def test_tally_timeout(start_tally, erp, make_connector):
    slow = start_tally(delay=2.0)
    erp.add_job(masters_xml(*BASE_LEDGERS), "Ledgers")
    c = make_connector(erp.base_url, tally_url(slow), timeout=0.5)
    c.tally = connector.TallyClient(tally_url(slow), 0.5)
    c.run_cycle()
    body = erp.results[0]["body"]
    assert body["ok"] is False and body["error"].startswith("Timed out after 0.5 s")


def test_erp_down_results_go_to_outbox_and_are_resent_first(tally, erp, make_connector):
    j1 = erp.add_job(masters_xml(*BASE_LEDGERS), "Ledgers")
    j2 = erp.add_job(voucher_xml("TCE/2627/0001", SALES_ENTRIES), "Sales")
    c = make_connector(erp.base_url, tally_url(tally))
    erp.fail_results = True

    out = c.run_cycle()

    assert out.status == "error"
    lines = c.cfg.outbox_file.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1
    stored = json.loads(lines[0])
    assert stored["job_id"] == j1.id and "<CREATED>3</CREATED>" in stored["result"]["response"]
    # Job 2 was not sent to Tally while the ERP was unreachable (order preserved).
    assert tally.state.snapshot()["vouchers"] == []

    # ERP completely unreachable: cycle fails cleanly, outbox untouched.
    erp.fail_all = True
    assert c.run_cycle().status == "error"
    assert len(c.cfg.outbox_file.read_text(encoding="utf-8").splitlines()) == 1

    erp.fail_all = erp.fail_results = False
    j2.leased_until = 0  # lease expired on the ERP side
    out = c.run_cycle()
    assert out.status == "ok"
    assert [r["job_id"] for r in erp.results] == [j1.id, j2.id]  # outbox entry delivered first
    assert not c.cfg.outbox_file.exists()
    assert j1.status == "done" and j2.status == "done"


def test_outbox_survives_restart(tally, erp, make_connector):
    j1 = erp.add_job(masters_xml(*BASE_LEDGERS), "Ledgers")
    c = make_connector(erp.base_url, tally_url(tally))
    erp.fail_results = True
    c.run_cycle()
    erp.fail_results = False
    c2 = connector.Connector(c.cfg)  # fresh process, same files
    assert c2.run_cycle().status == "ok"
    assert erp.results[-1]["job_id"] == j1.id and j1.status == "done"


def test_erp_unreachable_does_not_crash(tally, make_connector):
    c = make_connector(f"http://127.0.0.1:{free_port()}", tally_url(tally))
    out = c.run_cycle()
    assert out.status == "error" and "Connection refused" in out.message


def test_bad_key_401(tally, erp, make_connector):
    erp.add_job(masters_xml(*BASE_LEDGERS), "Ledgers")
    erp.revoked = True
    c = make_connector(erp.base_url, tally_url(tally))
    out = c.run_cycle()
    assert out.status == "auth_error" and "BAD_CONNECTOR_KEY" in out.message
    assert connector.next_sleep(out, 60, 0) == 15 * 60
    assert erp.jobs[0].attempt == 0  # no lease attempted
    text = log_text(c)
    assert "BAD_CONNECTOR_KEY" in text and "Retrying in 15 minutes" in text


def test_disabled_sync_does_not_lease(tally, erp, make_connector):
    erp.add_job(masters_xml(*BASE_LEDGERS), "Ledgers")
    erp.enabled = False
    c = make_connector(erp.base_url, tally_url(tally))
    assert c.run_cycle().status == "ok"
    assert erp.heartbeats and erp.jobs[0].attempt == 0


def test_utf16_tally_reply_is_decoded(start_tally, erp, make_connector):
    srv = start_tally(utf16=True)
    erp.add_job(masters_xml(*BASE_LEDGERS), "Ledgers")
    c = make_connector(erp.base_url, tally_url(srv))
    assert c.run_cycle().status == "ok"
    resp = erp.results[0]["body"]["response"]
    assert resp.startswith("<RESPONSE>") and "<CREATED>3</CREATED>" in resp and "\x00" not in resp
    assert erp.heartbeats[0]["tally_company"] == COMPANY


def test_decode_variants():
    text = "<RESPONSE>Tesla — ok</RESPONSE>"
    assert connector.decode_tally_body(b"\xff\xfe" + text.encode("utf-16-le")) == text
    assert connector.decode_tally_body(b"\xfe\xff" + text.encode("utf-16-be")) == text
    assert connector.decode_tally_body(b"\xef\xbb\xbf" + text.encode()) == text
    assert connector.decode_tally_body(text.encode("utf-16-le")) == text  # BOM-less UTF-16
    assert connector.decode_tally_body(b"<A>x\x00y</A>") == "<A>xy</A>"
    # odd length (truncated) UTF-16 must not blow up
    assert connector.decode_tally_body(b"\xff\xfe" + text.encode("utf-16-le") + b"\x00").startswith("<RESPONSE>")


def test_large_reply_truncated(tally, erp, make_connector, monkeypatch):
    monkeypatch.setattr(connector, "MAX_RESPONSE_BYTES", 100)
    erp.add_job(export_xml("Ledger"), "Ledgers", kind="export")
    c = make_connector(erp.base_url, tally_url(tally))
    c.run_cycle()
    body = erp.results[0]["body"]
    assert body["ok"] is True and body["error"] == "response too large" and len(body["response"]) == 100


def test_duplicate_voucher_error_reaches_erp(tally, erp, make_connector):
    erp.add_job(masters_xml(*BASE_LEDGERS), "Ledgers")
    erp.add_job(voucher_xml("TCE/2627/0001", SALES_ENTRIES), "Sales #1")
    erp.add_job(voucher_xml("TCE/2627/0001", SALES_ENTRIES), "Sales #1 again")
    c = make_connector(erp.base_url, tally_url(tally))
    assert c.run_cycle().status == "ok"
    dup = erp.results[2]["body"]
    assert dup["ok"] is True
    assert "<LINEERROR>Voucher Number 'TCE/2627/0001' already exists!</LINEERROR>" in dup["response"]
    assert "<ERRORS>1</ERRORS>" in dup["response"]
    assert len(tally.state.snapshot()["vouchers"]) == 1


def test_order_is_preserved(tally, erp, make_connector):
    names = [f"Party {i:02d}" for i in range(12)]
    jobs = [erp.add_job(masters_xml((n, "Sundry Debtors")), n) for n in names]
    c = make_connector(erp.base_url, tally_url(tally))
    c.run_cycle()
    assert [r["job_id"] for r in erp.results] == [j.id for j in jobs]
    created = [k for k in tally.state.snapshot()["ledgers"] if k.startswith("Party")]
    assert created == names


def test_full_lease_polls_fast(tally, erp, make_connector):
    for i in range(connector.LEASE_LIMIT + 3):
        erp.add_job(masters_xml((f"L{i}", "Sundry Debtors")), f"L{i}")
    c = make_connector(erp.base_url, tally_url(tally))
    out = c.run_cycle()
    assert out.lease_full and connector.next_sleep(out, 60, 0) == 5
    out = c.run_cycle()
    assert out.jobs_leased == 3 and not out.lease_full and connector.next_sleep(out, 60, 0) == 60


def test_key_never_logged(tmp_path, tally, erp, make_connector):
    erp.add_job(masters_xml(*BASE_LEDGERS), "Ledgers")
    c = make_connector(erp.base_url, tally_url(tally))
    c.run_cycle()
    erp.revoked = True
    c.run_cycle()
    connector.log.info("leak attempt: %s", KEY)  # even an accidental log call is masked
    ini = tmp_path / "connector.ini"
    ini.write_text(f"[connector]\nerp_url = {erp.base_url}\nconnector_key = {KEY}\n"
                   f"tally_url = {tally_url(tally)}\nlog_dir = logs\n", encoding="utf-8")
    proc = subprocess.run([sys.executable, str(ROOT / "connector.py"), "test", "--config", str(ini)],
                          capture_output=True, text=True, timeout=60)
    assert KEY not in proc.stdout + proc.stderr
    text = log_text(c)
    assert text and KEY not in text and connector.mask_key(KEY) in text
    for f in tmp_path.rglob("*"):
        if f.is_file() and f.name != "connector.ini":
            assert KEY not in f.read_text(encoding="utf-8", errors="replace"), f


def test_cli_test_command_report(tmp_path, tally, erp):
    ini = tmp_path / "connector.ini"
    ini.write_text(f"[connector]\nerp_url = {erp.base_url}/api/v1/\nconnector_key = {KEY}\n"
                   f"tally_url = {tally_url(tally)}\n", encoding="utf-8")
    proc = subprocess.run([sys.executable, str(ROOT / "connector.py"), "test", "--config", str(ini)],
                          capture_output=True, text=True, timeout=60)
    assert proc.returncode == 0, proc.stdout + proc.stderr
    assert "[ OK ] TallyPrime is reachable" in proc.stdout and COMPANY in proc.stdout
    assert "[ OK ] ERP accepted the heartbeat" in proc.stdout and "All checks passed." in proc.stdout
    assert (tmp_path / "logs" / "connector.log").is_file()

    erp.revoked = True
    proc = subprocess.run([sys.executable, str(ROOT / "connector.py"), "test", "--config", str(ini)],
                          capture_output=True, text=True, timeout=60)
    assert proc.returncode == 1 and "[FAIL] ERP rejected the connector key" in proc.stdout


def test_cli_once_and_bad_config(tmp_path, tally, erp):
    erp.add_job(masters_xml(*BASE_LEDGERS), "Ledgers")
    ini = tmp_path / "connector.ini"
    ini.write_text(f"[connector]\nerp_url = {erp.base_url}\nconnector_key = {KEY}\ntally_url = {tally_url(tally)}\n",
                   encoding="utf-8")
    proc = subprocess.run([sys.executable, str(ROOT / "connector.py"), "once", "--config", str(ini)],
                          capture_output=True, text=True, timeout=60)
    assert proc.returncode == 0, proc.stderr
    assert erp.jobs[0].status == "done"
    proc = subprocess.run([sys.executable, str(ROOT / "connector.py"), "once", "--config", str(tmp_path / "nope.ini")],
                          capture_output=True, text=True, timeout=60)
    assert proc.returncode == 2 and "Configuration file not found" in proc.stderr


def test_config_parsing(tmp_path):
    ini = tmp_path / "c.ini"
    ini.write_text("﻿[connector]\nerp_url = https://erp.example.com/\nconnector_key = tck_x\n"
                   "timeout_seconds = 30\nverify_tls = false\nlog_dir = L\n", encoding="utf-8")
    cfg = connector.load_config(ini)
    assert cfg.api_base == "https://erp.example.com/api/v1/tally-agent"
    assert cfg.tally_url == "http://localhost:9000" and cfg.timeout_seconds == 30 and cfg.verify_tls is False
    assert cfg.log_dir == tmp_path / "L" and cfg.outbox_file == tmp_path / "outbox.jsonl"
    ini.write_text("[connector]\nerp_url = https://erp.example.com\n", encoding="utf-8")
    with pytest.raises(connector.ConfigError, match="connector_key"):
        connector.load_config(ini)
    assert connector.mask_key(KEY) == "tck_Te…"


def test_run_forever_stops(tally, erp, make_connector):
    import threading
    c = make_connector(erp.base_url, tally_url(tally))
    t = threading.Thread(target=c.run_forever, daemon=True)
    t.start()
    for _ in range(100):
        if erp.heartbeats:
            break
        threading.Event().wait(0.05)
    c.stop_event.set()
    t.join(5)
    assert not t.is_alive() and erp.heartbeats


# -- mock Tally behaviour ----------------------------------------------------------------


def test_mock_validation_errors(tally):
    post_tally(tally, masters_xml(*BASE_LEDGERS))
    r = post_tally(tally, masters_xml(("ABC Hospital", "Sundry Debtors")))
    assert "<LINEERROR>Ledger 'ABC Hospital' already exists!</LINEERROR>" in r and "<ERRORS>1</ERRORS>" in r
    r = post_tally(tally, masters_xml(("ABC Hospital", "Sundry Creditors"), action="Alter"))
    assert "<ALTERED>1</ALTERED>" in r
    assert tally.state.snapshot()["ledgers"]["ABC Hospital"]["parent"] == "Sundry Creditors"
    r = post_tally(tally, voucher_xml("X1", [("Nobody", "-10.00"), ("Cash", "10.00")]))
    assert "Ledger 'Nobody' does not exist!" in r
    r = post_tally(tally, voucher_xml("X2", [("ABC Hospital", "-10.00"), ("Cash", "9.00")]))
    assert "Voucher totals do not match!" in r
    r = post_tally(tally, "<ENVELOPE><broken")
    assert r.startswith("<RESPONSE><LINEERROR>Could not set 'SVCurrentCompany'")
    r = post_tally(tally, masters_xml(*BASE_LEDGERS).replace(COMPANY, "Other Co"))
    assert "Could not set 'SVCurrentCompany' to 'Other Co'" in r


def test_mock_cancel_and_balances(tally):
    post_tally(tally, masters_xml(*BASE_LEDGERS))
    post_tally(tally, voucher_xml("S1", SALES_ENTRIES))
    led = tally.state.snapshot()["ledgers"]
    assert led["ABC Hospital"]["closing"] == "-118000.00"
    r = post_tally(tally, voucher_xml("S1", SALES_ENTRIES, action="Cancel"))
    assert "<CANCELLED>1</CANCELLED>" in r
    s = tally.state.snapshot()
    assert s["vouchers"][0]["cancelled"] is True and s["ledgers"]["ABC Hospital"]["closing"] == "0.00"
    # number still taken after cancellation (like Tally)
    assert "already exists" in post_tally(tally, voucher_xml("S1", SALES_ENTRIES))


def test_mock_voucher_export_filters(tally):
    post_tally(tally, masters_xml(*BASE_LEDGERS))
    post_tally(tally, voucher_xml("S1", SALES_ENTRIES, date="20261001"))
    post_tally(tally, voucher_xml("R1", [("Cash", "-500.00"), ("ABC Hospital", "500.00")], vtype="Receipt",
                                  date="20261005"))
    post_tally(tally, voucher_xml("R2", [("Cash", "-700.00"), ("ABC Hospital", "700.00")], vtype="Receipt",
                                  date="20261020"))
    dates = "<SVFROMDATE>20261001</SVFROMDATE><SVTODATE>20261010</SVTODATE>"
    r = post_tally(tally, export_xml("Voucher", dates))
    assert "<VOUCHERNUMBER>S1</VOUCHERNUMBER>" in r and "<VOUCHERNUMBER>R1</VOUCHERNUMBER>" in r
    assert "R2" not in r and "<GUID" in r and "<ALLLEDGERENTRIES.LIST>" in r
    r = post_tally(tally, export_xml("Voucher", dates + "<SVVCHTYPE>Receipt</SVVCHTYPE>"))
    assert "R1" in r and "<VOUCHERNUMBER>S1</VOUCHERNUMBER>" not in r
    formula = '<SYSTEM TYPE="Formulae" NAME="VchTypeFilter">$VoucherTypeName = "Receipt"</SYSTEM>'
    r = post_tally(tally, export_xml("Voucher", "<SVFROMDATE>1-Oct-2026</SVFROMDATE><SVTODATE>31-Oct-2026</SVTODATE>",
                                     formula))
    assert "R1" in r and "R2" in r and "<VOUCHERNUMBER>S1</VOUCHERNUMBER>" not in r
    assert "<AMOUNT>500.00</AMOUNT>" in r


def test_mock_persistence_seed_and_state(tmp_path, start_tally):
    data = tmp_path / "data.json"
    srv = start_tally(data_file=data, seed=[{"name": "XYZ Ltd", "parent": "Sundry Creditors", "gstin": "29ABC"}])
    post_tally(srv, masters_xml(("New Party", "Sundry Debtors")))
    with urllib.request.urlopen(f"{tally_url(srv)}/_state") as resp:
        state: dict[str, Any] = json.loads(resp.read())
    assert {"Cash", "Profit & Loss A/c", "XYZ Ltd", "New Party"} <= set(state["ledgers"])
    assert "Sundry Debtors" in state["groups"]
    reloaded = mock_tally.TallyState(data)
    assert "New Party" in reloaded.data["ledgers"]


def test_mock_fail_rate_drops_connection(start_tally):
    srv = start_tally(fail_rate=1.0)
    res = connector.TallyClient(tally_url(srv), 5).post(masters_xml(("A", "Sundry Debtors")))
    assert res.ok is False and res.status_code is None and res.error
