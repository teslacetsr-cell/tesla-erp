"""Shared fixtures: an in-process mock TallyPrime and fake ERP on free ports."""

from __future__ import annotations

import socket
import sys
import threading
from pathlib import Path
from typing import Any, Callable, Iterator

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import connector  # noqa: E402
import fake_erp  # noqa: E402
import mock_tally  # noqa: E402

KEY = "tck_TestKey0123456789abcdefghijklmnopqrstuvwxyzAB"


def _start(server: Any) -> threading.Thread:
    t = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
    t.start()
    return t


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture
def start_tally() -> Iterator[Callable[..., mock_tally.MockTallyServer]]:
    servers: list[mock_tally.MockTallyServer] = []

    def factory(**kw: Any) -> mock_tally.MockTallyServer:
        srv = mock_tally.make_server(**kw)
        _start(srv)
        servers.append(srv)
        return srv

    yield factory
    for s in servers:
        s.shutdown()
        s.server_close()


@pytest.fixture
def tally(start_tally: Callable[..., mock_tally.MockTallyServer]) -> mock_tally.MockTallyServer:
    return start_tally()


@pytest.fixture
def erp() -> Iterator[fake_erp.FakeErpServer]:
    srv = fake_erp.make_server(KEY)
    _start(srv)
    yield srv
    srv.shutdown()
    srv.server_close()


@pytest.fixture
def make_connector(tmp_path: Path) -> Callable[..., connector.Connector]:
    def factory(erp_url: str, tally_url: str, timeout: float = 5.0) -> connector.Connector:
        cfg = connector.Config(
            erp_url=erp_url,
            connector_key=KEY,
            tally_url=tally_url,
            timeout_seconds=timeout,
            log_dir=tmp_path / "logs",
            outbox_file=tmp_path / "outbox.jsonl",
        )
        connector.setup_logging(cfg.log_dir, cfg.connector_key, console=False)
        return connector.Connector(cfg)

    return factory


def tally_url(srv: mock_tally.MockTallyServer) -> str:
    return f"http://127.0.0.1:{srv.server_port}"
