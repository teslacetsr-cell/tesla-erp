#!/usr/bin/env python3
"""Minimal fake of the ERP's ``/api/v1/tally-agent/*`` endpoints — test helper only.

Lets the connector be exercised end-to-end without the real ERP::

    python fake_erp.py --port 8800 --key tck_demo_demo_demo_demo_demo_demo --demo
    # then point connector.ini at  erp_url = http://127.0.0.1:8800

``--demo`` queues a ledger master and a sales voucher. ``GET /_state`` shows jobs, results and heartbeats.

Behaviour (a simplification of the real ERP):
* wrong / missing bearer key -> 401 ``BAD_CONNECTOR_KEY``;
* lease returns pending jobs in queue order, reserving each for ``lease_seconds``;
* result ``ok: true`` -> job ``done`` (or ``failed`` when Tally's reply has ``<ERRORS>`` > 0, except the
  "already exists" duplicate case which counts as done); ``ok: false`` -> back to pending (``retry``);
* switches for tests: ``revoked``, ``enabled``, ``fail_results`` (result endpoint answers 503),
  ``fail_all`` (every endpoint answers 503).
"""

from __future__ import annotations

import argparse
import json
import re
import threading
import time
import uuid
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Optional

PREFIX = "/api/v1/tally-agent"


@dataclass
class FakeJob:
    xml: str
    label: str = ""
    kind: str = "import"
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    status: str = "pending"          # pending | done | failed
    attempt: int = 0
    leased_until: float = 0.0
    last_result: Optional[dict[str, Any]] = None


class FakeErpServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, addr: tuple[str, int], key: str, lease_seconds: float = 600.0,
                 poll_seconds: int = 60, quiet: bool = True) -> None:
        super().__init__(addr, _Handler)
        self.key = key
        self.lease_seconds = lease_seconds
        self.poll_seconds = poll_seconds
        self.quiet = quiet
        self.lock = threading.Lock()
        self.jobs: list[FakeJob] = []
        self.results: list[dict[str, Any]] = []      # {"job_id", "label", "body"} in arrival order
        self.heartbeats: list[dict[str, Any]] = []
        self.auth_headers: list[str] = []
        self.user_agents: list[str] = []
        self.revoked = False
        self.enabled = True
        self.fail_results = False
        self.fail_all = False

    def add_job(self, xml: str, label: str = "", kind: str = "import") -> FakeJob:
        job = FakeJob(xml=xml, label=label, kind=kind)
        with self.lock:
            self.jobs.append(job)
        return job

    def job(self, job_id: str) -> Optional[FakeJob]:
        return next((j for j in self.jobs if j.id == job_id), None)

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.server_port}"


def _tally_errors(response: str) -> int:
    m = re.search(r"<ERRORS>(\d+)</ERRORS>", response or "")
    return int(m.group(1)) if m else 0


class _Handler(BaseHTTPRequestHandler):
    server: FakeErpServer
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt: str, *args: Any) -> None:
        if not self.server.quiet:
            super().log_message(fmt, *args)

    def _json(self, code: int, doc: Any) -> None:
        body = json.dumps(doc).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802
        s = self.server
        with s.lock:
            doc = {"jobs": [j.__dict__ for j in s.jobs], "results": s.results, "heartbeats": s.heartbeats}
        self._json(200, doc)

    def do_POST(self) -> None:  # noqa: N802
        s = self.server
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        auth = self.headers.get("Authorization", "")
        s.auth_headers.append(auth)
        s.user_agents.append(self.headers.get("User-Agent", ""))
        if s.fail_all:
            return self._json(503, {"error": {"code": "UNAVAILABLE", "message": "maintenance"}})
        if s.revoked or auth != f"Bearer {s.key}":
            return self._json(401, {"error": {"code": "BAD_CONNECTOR_KEY", "message": "Unknown or revoked key"}})
        try:
            body = json.loads(raw.decode("utf-8") or "{}")
        except json.JSONDecodeError:
            return self._json(422, {"error": {"code": "BAD_JSON", "message": "invalid JSON"}})
        path = self.path.split("?")[0]

        if path == f"{PREFIX}/heartbeat":
            with s.lock:
                s.heartbeats.append(body)
            return self._json(200, {"data": {"poll_seconds": s.poll_seconds, "enabled": s.enabled,
                                             "company": "Tesla Consulting Engineers",
                                             "server_time": time.strftime("%Y-%m-%dT%H:%M:%S+05:30")}})

        if path == f"{PREFIX}/jobs/lease":
            limit = int(body.get("limit") or 20)
            now = time.time()
            out = []
            with s.lock:
                for j in s.jobs:
                    if len(out) >= limit:
                        break
                    if j.status == "pending" and j.leased_until <= now:
                        j.attempt += 1
                        j.leased_until = now + s.lease_seconds
                        out.append({"id": j.id, "kind": j.kind, "label": j.label, "xml": j.xml, "attempt": j.attempt})
            return self._json(200, {"data": out})

        m = re.fullmatch(rf"{PREFIX}/jobs/([^/]+)/result", path)
        if m:
            if s.fail_results:
                return self._json(503, {"error": {"code": "UNAVAILABLE", "message": "try later"}})
            with s.lock:
                job = s.job(m.group(1))
                if job is None:
                    return self._json(404, {"error": {"code": "NOT_FOUND", "message": "no such job"}})
                s.results.append({"job_id": job.id, "label": job.label, "body": body})
                job.last_result = body
                job.leased_until = 0.0
                if not body.get("ok"):
                    job.status, msg = "pending", body.get("error") or "Tally not reachable"
                    status = "retry"
                elif _tally_errors(body.get("response") or "") and "already exists" not in (body.get("response") or ""):
                    job.status = status = "failed"
                    msg = "Tally reported errors"
                else:
                    job.status = status = "done"
                    msg = "ok"
            return self._json(200, {"data": {"status": status, "message": msg}})

        return self._json(404, {"error": {"code": "NOT_FOUND", "message": path}})


def make_server(key: str, port: int = 0, lease_seconds: float = 600.0, poll_seconds: int = 60,
                quiet: bool = True) -> FakeErpServer:
    return FakeErpServer(("127.0.0.1", port), key, lease_seconds, poll_seconds, quiet)


DEMO_LEDGER = """<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA>
<REQUESTDESC><REPORTNAME>All Masters</REPORTNAME><STATICVARIABLES><SVCURRENTCOMPANY>Tesla Consulting Engineers</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC>
<REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF">
<LEDGER NAME="ABC Hospital" ACTION="Create"><NAME.LIST><NAME>ABC Hospital</NAME></NAME.LIST><PARENT>Sundry Debtors</PARENT>
<PARTYGSTIN>32AAACA1234A1Z5</PARTYGSTIN><LEDSTATENAME>Kerala</LEDSTATENAME><ADDRESS.LIST><ADDRESS>MG Road, Kochi</ADDRESS></ADDRESS.LIST></LEDGER>
<LEDGER NAME="Sales — Projects &amp; Services" ACTION="Create"><NAME.LIST><NAME>Sales — Projects &amp; Services</NAME></NAME.LIST><PARENT>Sales Accounts</PARENT></LEDGER>
<LEDGER NAME="Output CGST" ACTION="Create"><PARENT>Duties &amp; Taxes</PARENT></LEDGER>
<LEDGER NAME="Output SGST" ACTION="Create"><PARENT>Duties &amp; Taxes</PARENT></LEDGER>
</TALLYMESSAGE></REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>"""

DEMO_SALES = """<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA>
<REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME><STATICVARIABLES><SVCURRENTCOMPANY>Tesla Consulting Engineers</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC>
<REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF">
<VOUCHER REMOTEID="erp-demo-0001" VCHTYPE="Sales" ACTION="Create" OBJVIEW="Accounting Voucher View">
<DATE>20261007</DATE><VOUCHERTYPENAME>Sales</VOUCHERTYPENAME><VOUCHERNUMBER>TCE/2627/0001</VOUCHERNUMBER>
<PARTYLEDGERNAME>ABC Hospital</PARTYLEDGERNAME><NARRATION>Design consultancy — Phase 1</NARRATION><PERSISTEDVIEW>Accounting Voucher View</PERSISTEDVIEW>
<ALLLEDGERENTRIES.LIST><LEDGERNAME>ABC Hospital</LEDGERNAME><ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE><AMOUNT>-118000.00</AMOUNT>
<BILLALLOCATIONS.LIST><NAME>TCE/2627/0001</NAME><BILLTYPE>New Ref</BILLTYPE><AMOUNT>-118000.00</AMOUNT></BILLALLOCATIONS.LIST></ALLLEDGERENTRIES.LIST>
<ALLLEDGERENTRIES.LIST><LEDGERNAME>Sales — Projects &amp; Services</LEDGERNAME><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><AMOUNT>100000.00</AMOUNT></ALLLEDGERENTRIES.LIST>
<ALLLEDGERENTRIES.LIST><LEDGERNAME>Output CGST</LEDGERNAME><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><AMOUNT>9000.00</AMOUNT></ALLLEDGERENTRIES.LIST>
<ALLLEDGERENTRIES.LIST><LEDGERNAME>Output SGST</LEDGERNAME><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><AMOUNT>9000.00</AMOUNT></ALLLEDGERENTRIES.LIST>
</VOUCHER></TALLYMESSAGE></REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>"""

DEMO_LEDGER_EXPORT = """<ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>TCE Ledgers</ID></HEADER>
<BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT><SVCURRENTCOMPANY>Tesla Consulting Engineers</SVCURRENTCOMPANY></STATICVARIABLES>
<TDL><TDLMESSAGE><COLLECTION NAME="TCE Ledgers" ISMODIFY="No"><TYPE>Ledger</TYPE><FETCH>NAME, PARENT, CLOSINGBALANCE, PARTYGSTIN</FETCH></COLLECTION></TDLMESSAGE></TDL>
</DESC></BODY></ENVELOPE>"""


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Fake ERP tally-agent endpoints (testing only).")
    p.add_argument("--port", type=int, default=8800)
    p.add_argument("--key", required=True, help="the connector key to accept")
    p.add_argument("--poll-seconds", type=int, default=10)
    p.add_argument("--demo", action="store_true", help="queue a ledger master, a sales voucher and a ledger export")
    p.add_argument("--verbose", action="store_true")
    a = p.parse_args(argv)
    srv = make_server(a.key, a.port, poll_seconds=a.poll_seconds, quiet=not a.verbose)
    if a.demo:
        srv.add_job(DEMO_LEDGER, "Ledgers: ABC Hospital etc.")
        srv.add_job(DEMO_SALES, "Sales TCE/2627/0001")
        srv.add_job(DEMO_LEDGER_EXPORT, "Ledger balances", kind="export")
    print(f"Fake ERP on {srv.base_url} (erp_url for connector.ini), {len(srv.jobs)} job(s) queued")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
