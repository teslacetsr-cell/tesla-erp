#!/usr/bin/env python3
"""Mock TallyPrime XML-over-HTTP server — for tests and demos only.

    python mock_tally.py --port 9000 --data mock_tally_data.json [--seed extra_ledgers.json]
                         [--company "Tesla Consulting Engineers"] [--utf16] [--fail-rate 0.2] [--delay 0]

What it understands (a small, tolerant subset of TallyPrime's XML interface):

* ``Import Data`` / REPORTNAME ``All Masters``: ``LEDGER`` (and ``GROUP``) with ACTION Create / Alter / Delete
  (no ACTION = create-or-alter). Creating an existing ledger -> ``Ledger '<name>' already exists!``.
* ``Import Data`` / REPORTNAME ``Vouchers``: ``VOUCHER`` with ACTION Create / Alter / Cancel / Delete.
  Validates ledgers exist, entries sum to zero, voucher number unique per voucher type
  (``Voucher Number '<n>' already exists!``). Updates ledger closing balances (debit negative).
* ``Export`` / ``Collection`` (inline TDL collection ``<TYPE>``, or the collection ID):
  Company, Ledger, Voucher. Vouchers are filtered by ``SVFROMDATE`` / ``SVTODATE`` (``YYYYMMDD`` or
  ``1-Apr-2026``) and by voucher type when any of these name one:
    - static variable ``SVVCHTYPE`` (or ``SVVOUCHERTYPE``),
    - a ``<FILTERS>``/``<FILTER>`` element whose text is a voucher-type name,
    - a TDL formula such as ``<SYSTEM TYPE="Formulae" NAME="X">$VoucherTypeName = "Receipt"</SYSTEM>``
      (several types may be OR-ed).
* ``SVCURRENTCOMPANY`` naming a company other than the loaded one ->
  ``Could not set 'SVCurrentCompany' to '<name>'`` (like Tally when that company is not open).
* Malformed XML -> HTTP 200 ``<RESPONSE><LINEERROR>Could not set 'SVCurrentCompany' …`` (Tally's typical reply).
* ``GET /`` -> ``<RESPONSE>TallyPrime Server is Running</RESPONSE>``; ``GET /_state`` -> JSON dump (test-only).

Use ``make_server()`` to run it in-process (tests do this).
"""

from __future__ import annotations

import argparse
import json
import os
import random
import re
import socket
import threading
import uuid
import xml.etree.ElementTree as ET
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Optional
from xml.sax.saxutils import escape, quoteattr

DEFAULT_COMPANY = "Tesla Consulting Engineers"

# TallyPrime's 28 predefined groups: name -> parent ("Primary" for the 15 primary groups).
STANDARD_GROUPS: dict[str, str] = {
    "Branch / Divisions": "Primary", "Capital Account": "Primary", "Current Assets": "Primary",
    "Current Liabilities": "Primary", "Direct Expenses": "Primary", "Direct Incomes": "Primary",
    "Fixed Assets": "Primary", "Indirect Expenses": "Primary", "Indirect Incomes": "Primary",
    "Investments": "Primary", "Loans (Liability)": "Primary", "Misc. Expenses (ASSET)": "Primary",
    "Purchase Accounts": "Primary", "Sales Accounts": "Primary", "Suspense A/c": "Primary",
    "Bank Accounts": "Current Assets", "Bank OD A/c": "Loans (Liability)", "Cash-in-Hand": "Current Assets",
    "Deposits (Asset)": "Current Assets", "Duties & Taxes": "Current Liabilities",
    "Loans & Advances (Asset)": "Current Assets", "Provisions": "Current Liabilities",
    "Reserves & Surplus": "Capital Account", "Secured Loans": "Loans (Liability)",
    "Stock-in-Hand": "Current Assets", "Sundry Creditors": "Current Liabilities",
    "Sundry Debtors": "Current Assets", "Unsecured Loans": "Loans (Liability)",
}
STANDARD_VOUCHER_TYPES = [
    "Contra", "Credit Note", "Debit Note", "Delivery Note", "Journal", "Memorandum", "Payment",
    "Physical Stock", "Purchase", "Purchase Order", "Receipt", "Receipt Note", "Rejections In",
    "Rejections Out", "Reversing Journal", "Sales", "Sales Order", "Stock Journal",
]
MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}


def _new_state(company: str) -> dict[str, Any]:
    return {
        "company": company,
        "company_guid": str(uuid.uuid4()),
        "groups": dict(STANDARD_GROUPS),
        "ledgers": {
            "Cash": _ledger("Cash", "Cash-in-Hand"),
            "Profit & Loss A/c": _ledger("Profit & Loss A/c", "Primary"),
        },
        "vouchers": [],
        "last_vch_id": 0,
        "last_mid": 0,
    }


def _ledger(name: str, parent: str, **extra: Any) -> dict[str, Any]:
    return {"name": name, "parent": parent, "gstin": extra.get("gstin", ""), "state": extra.get("state", ""),
            "address": extra.get("address", []), "opening": extra.get("opening", "0.00"),
            "closing": extra.get("opening", "0.00")}


def _dec(text: Optional[str]) -> Decimal:
    t = (text or "").strip().replace(",", "")
    # Tally may write amounts with a currency/rate suffix e.g. "1000.00 Dr"; keep it simple.
    m = re.match(r"^-?\d+(\.\d+)?", t)
    if not m:
        return Decimal("0")
    try:
        return Decimal(m.group(0))
    except InvalidOperation:
        return Decimal("0")


def _fmt(amount: Decimal) -> str:
    return f"{amount.quantize(Decimal('0.01')):.2f}"


def parse_tally_date(text: Optional[str]) -> Optional[date]:
    """``20261007`` or ``7-Oct-2026`` / ``7-Oct-26``."""
    t = (text or "").strip()
    if re.fullmatch(r"\d{8}", t):
        try:
            return datetime.strptime(t, "%Y%m%d").date()
        except ValueError:
            return None
    m = re.fullmatch(r"(\d{1,2})[- ]([A-Za-z]{3})[A-Za-z]*[- ](\d{2,4})", t)
    if m and m.group(2).lower() in MONTHS:
        y = int(m.group(3))
        y = y + 2000 if y < 100 else y
        try:
            return date(y, MONTHS[m.group(2).lower()], int(m.group(1)))
        except ValueError:
            return None
    return None


def _text(el: Optional[ET.Element], tag: str, default: str = "") -> str:
    if el is None:
        return default
    found = el.find(tag)
    return (found.text or "").strip() if found is not None and found.text else default


class TallyState:
    """In-memory company data, persisted to a JSON file after every change."""

    def __init__(self, data_file: Optional[Path], company: str = DEFAULT_COMPANY,
                 seed: Optional[list[dict[str, Any]]] = None) -> None:
        self.data_file = data_file
        self.lock = threading.RLock()
        self.request_log: list[str] = []  # TALLYREQUEST/REPORTNAME per request, for tests
        if data_file and data_file.is_file():
            self.data = json.loads(data_file.read_text(encoding="utf-8"))
        else:
            self.data = _new_state(company)
        for item in seed or []:
            name = item.get("name")
            if name and name not in self.data["ledgers"]:
                self.data["ledgers"][name] = _ledger(
                    name, item.get("parent", "Sundry Debtors"), gstin=item.get("gstin", ""),
                    state=item.get("state", ""), address=item.get("address", []),
                    opening=_fmt(_dec(str(item.get("opening", "0")))))
        self.save()

    @property
    def company(self) -> str:
        return self.data["company"]

    def save(self) -> None:
        if not self.data_file:
            return
        tmp = self.data_file.with_suffix(self.data_file.suffix + ".tmp")
        tmp.write_text(json.dumps(self.data, indent=1, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, self.data_file)

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return json.loads(json.dumps(self.data))

    # -- request dispatch ----------------------------------------------------------------

    def handle(self, body: str) -> str:
        try:
            root = ET.fromstring(body)
        except ET.ParseError:
            self.request_log.append("malformed")
            return _error_response("Could not set 'SVCurrentCompany' to ''")
        header = root.find("HEADER")
        request = _text(header, "TALLYREQUEST").lower()
        sv_company = root.find(".//STATICVARIABLES/SVCURRENTCOMPANY")
        with self.lock:
            if sv_company is not None and (sv_company.text or "").strip() \
                    and (sv_company.text or "").strip().lower() != self.company.lower():
                self.request_log.append("wrong-company")
                return _error_response(f"Could not set 'SVCurrentCompany' to '{sv_company.text.strip()}'")
            if request == "import data" or request == "import":
                report = (root.findtext(".//REQUESTDESC/REPORTNAME") or "").strip()
                self.request_log.append(f"import:{report}")
                if report.lower() == "vouchers":
                    out = self._import_vouchers(root)
                else:  # "All Masters" (also tolerate "Masters", "List of Accounts")
                    out = self._import_masters(root)
                self.save()
                return out
            if request == "export" or request == "export data":
                return self._export(root, header)
        self.request_log.append(f"unknown:{request}")
        return "<RESPONSE>Unknown Request, cannot be processed</RESPONSE>"

    # -- masters -------------------------------------------------------------------------

    def _import_masters(self, root: ET.Element) -> str:
        c = _Counts()
        for el in root.iter():
            if el.tag not in ("LEDGER", "GROUP"):
                continue
            name = (el.get("NAME") or _text(el.find("NAME.LIST"), "NAME") or _text(el, "NAME")).strip()
            action = (el.get("ACTION") or "").strip().lower()
            if not name:
                c.error("Name not specified!")
                continue
            if el.tag == "GROUP":
                self._import_group(el, name, action, c)
            else:
                self._import_ledger(el, name, action, c)
        return c.response(self.data)

    def _import_group(self, el: ET.Element, name: str, action: str, c: "_Counts") -> None:
        groups = self.data["groups"]
        if action == "create" and name in groups:
            c.error(f"Group '{name}' already exists!")
            return
        parent = _text(el, "PARENT") or groups.get(name, "Primary")
        if parent != "Primary" and parent not in groups:
            c.error(f"Group '{parent}' does not exist!")
            return
        existed = name in groups
        groups[name] = parent
        self.data["last_mid"] += 1
        c.altered += existed
        c.created += not existed

    def _import_ledger(self, el: ET.Element, name: str, action: str, c: "_Counts") -> None:
        ledgers = self.data["ledgers"]
        exists = name in ledgers
        if action == "delete":
            if not exists:
                c.error(f"Ledger '{name}' does not exist!")
            elif any(not v.get("deleted") and any(e["ledger"] == name for e in v["entries"])
                     for v in self.data["vouchers"]):
                c.error(f"Cannot delete Ledger '{name}' — it has vouchers!")
            else:
                del ledgers[name]
                c.deleted += 1
            return
        if action == "create" and exists:
            c.error(f"Ledger '{name}' already exists!")
            return
        if action == "alter" and not exists:
            c.error(f"Ledger '{name}' does not exist!")
            return
        current = ledgers.get(name) or _ledger(name, "")
        parent = _text(el, "PARENT") or current["parent"]
        if not parent:
            c.error(f"Ledger '{name}': Parent not specified!")
            return
        if parent != "Primary" and parent not in self.data["groups"]:
            c.error(f"Group '{parent}' does not exist!")
            return
        current["parent"] = parent
        if el.find("PARTYGSTIN") is not None:
            current["gstin"] = _text(el, "PARTYGSTIN")
        if el.find("LEDSTATENAME") is not None:
            current["state"] = _text(el, "LEDSTATENAME")
        addr = [(a.text or "").strip() for a in el.findall("ADDRESS.LIST/ADDRESS")]
        if addr:
            current["address"] = addr
        if el.find("OPENINGBALANCE") is not None:
            old_open = _dec(current.get("opening"))
            new_open = _dec(_text(el, "OPENINGBALANCE"))
            current["opening"] = _fmt(new_open)
            current["closing"] = _fmt(_dec(current.get("closing")) - old_open + new_open)
        ledgers[name] = current
        self.data["last_mid"] += 1
        if exists:
            c.altered += 1
        else:
            c.created += 1

    # -- vouchers ------------------------------------------------------------------------

    def _import_vouchers(self, root: ET.Element) -> str:
        c = _Counts()
        for el in root.iter("VOUCHER"):
            self._import_voucher(el, c)
        return c.response(self.data)

    def _find_voucher(self, vtype: str, number: str, remote_id: str) -> Optional[dict[str, Any]]:
        for v in self.data["vouchers"]:
            if v.get("deleted"):
                continue
            if remote_id and v.get("remote_id") == remote_id:
                return v
            if number and v["number"] == number and v["type"].lower() == vtype.lower():
                return v
        return None

    def _apply_balances(self, entries: list[dict[str, str]], sign: int) -> None:
        for e in entries:
            led = self.data["ledgers"].get(e["ledger"])
            if led is not None:
                led["closing"] = _fmt(_dec(led["closing"]) + sign * _dec(e["amount"]))

    def _import_voucher(self, el: ET.Element, c: "_Counts") -> None:
        action = (el.get("ACTION") or "Create").strip().lower()
        vtype = _text(el, "VOUCHERTYPENAME") or (el.get("VCHTYPE") or "").strip()
        number = _text(el, "VOUCHERNUMBER")
        remote_id = (el.get("REMOTEID") or "").strip()

        if action in ("cancel", "delete"):
            v = self._find_voucher(vtype, number, remote_id)
            if v is None:
                c.error(f"Voucher '{number or remote_id}' does not exist!")
                return
            if not v.get("cancelled"):
                self._apply_balances(v["entries"], -1)
            if action == "cancel":
                v["cancelled"] = True
                c.cancelled += 1
            else:
                v["deleted"] = True
                c.deleted += 1
            return

        if not vtype:
            c.error("Voucher Type not specified!")
            return
        if vtype not in STANDARD_VOUCHER_TYPES:
            c.error(f"Voucher Type '{vtype}' does not exist!")
            return
        vdate = parse_tally_date(_text(el, "DATE"))
        if vdate is None:
            c.error(f"Invalid date '{_text(el, 'DATE')}' in voucher!")
            return
        entries: list[dict[str, str]] = []
        for le in list(el.findall("ALLLEDGERENTRIES.LIST")) + list(el.findall("LEDGERENTRIES.LIST")):
            entries.append({
                "ledger": _text(le, "LEDGERNAME"),
                "is_deemed_positive": _text(le, "ISDEEMEDPOSITIVE", "No"),
                "amount": _fmt(_dec(_text(le, "AMOUNT"))),
            })
        for e in entries:
            if e["ledger"] not in self.data["ledgers"]:
                c.error(f"Ledger '{e['ledger']}' does not exist!")
                return
        if not entries or sum((_dec(e["amount"]) for e in entries), Decimal("0")) != 0:
            c.error("Voucher totals do not match!")
            return

        existing = self._find_voucher(vtype, number, remote_id if action == "alter" else "")
        if action == "alter":
            if existing is None:
                c.error(f"Voucher '{number or remote_id}' does not exist!")
                return
            if not existing.get("cancelled"):
                self._apply_balances(existing["entries"], -1)
            target = existing
            c.altered += 1
        else:
            if number and existing is not None:
                c.error(f"Voucher Number '{number}' already exists!")
                return
            self.data["last_vch_id"] += 1
            vid = self.data["last_vch_id"]
            target = {"id": vid, "guid": f"{self.data['company_guid']}-{vid:08x}", "cancelled": False}
            self.data["vouchers"].append(target)
            c.created += 1
        target.update({
            "remote_id": remote_id or target.get("remote_id", ""),
            "type": vtype,
            "number": number,
            "date": vdate.strftime("%Y%m%d"),
            "party": _text(el, "PARTYLEDGERNAME"),
            "narration": _text(el, "NARRATION"),
            "entries": entries,
        })
        self._apply_balances(entries, +1)
        c.last_vch_id = target["id"]

    # -- export --------------------------------------------------------------------------

    def _export(self, root: ET.Element, header: Optional[ET.Element]) -> str:
        coll = root.find(".//TDL/TDLMESSAGE/COLLECTION")
        ctype = _text(coll, "TYPE") if coll is not None else ""
        cid = _text(header, "ID")
        kind = (ctype or cid).lower()
        self.request_log.append(f"export:{ctype or cid}")
        if "compan" in kind:
            body = (f"<COMPANY NAME={quoteattr(self.company)} RESERVEDNAME=\"\">"
                    f"<NAME TYPE=\"String\">{escape(self.company)}</NAME></COMPANY>")
        elif "ledger" in kind or "accounts" in kind:
            body = "".join(self._ledger_xml(led) for led in self.data["ledgers"].values())
        elif "voucher" in kind or "day book" in kind:
            body = "".join(self._voucher_xml(v) for v in self._filter_vouchers(root))
        else:
            return _error_response(f"Could not find Collection '{cid or ctype}'")
        return ("<ENVELOPE><HEADER><VERSION>1</VERSION><STATUS>1</STATUS></HEADER><BODY><DESC></DESC>"
                f"<DATA><COLLECTION>{body}</COLLECTION></DATA></BODY></ENVELOPE>")

    @staticmethod
    def _ledger_xml(led: dict[str, Any]) -> str:
        return (f"<LEDGER NAME={quoteattr(led['name'])} RESERVEDNAME=\"\">"
                f"<PARENT TYPE=\"String\">{escape(led['parent'])}</PARENT>"
                f"<CLOSINGBALANCE TYPE=\"Amount\">{escape(led['closing'])}</CLOSINGBALANCE>"
                f"<PARTYGSTIN TYPE=\"String\">{escape(led.get('gstin', ''))}</PARTYGSTIN>"
                f"<NAME.LIST TYPE=\"String\"><NAME>{escape(led['name'])}</NAME></NAME.LIST></LEDGER>")

    @staticmethod
    def _voucher_xml(v: dict[str, Any]) -> str:
        party_amt = next((e["amount"] for e in v["entries"] if e["ledger"] == v["party"]), None)
        if party_amt is None:
            party_amt = _fmt(sum((_dec(e["amount"]) for e in v["entries"] if _dec(e["amount"]) > 0), Decimal("0")))
        entries = "".join(
            f"<ALLLEDGERENTRIES.LIST><LEDGERNAME>{escape(e['ledger'])}</LEDGERNAME>"
            f"<ISDEEMEDPOSITIVE>{e['is_deemed_positive']}</ISDEEMEDPOSITIVE>"
            f"<AMOUNT>{e['amount']}</AMOUNT></ALLLEDGERENTRIES.LIST>"
            for e in v["entries"])
        return (f"<VOUCHER REMOTEID={quoteattr(v.get('remote_id', ''))} VCHTYPE={quoteattr(v['type'])} "
                f"ACTION=\"Create\" OBJVIEW=\"Accounting Voucher View\">"
                f"<DATE TYPE=\"Date\">{v['date']}</DATE><GUID TYPE=\"String\">{v['guid']}</GUID>"
                f"<VOUCHERTYPENAME>{escape(v['type'])}</VOUCHERTYPENAME>"
                f"<VOUCHERNUMBER>{escape(v['number'])}</VOUCHERNUMBER>"
                f"<PARTYLEDGERNAME>{escape(v['party'])}</PARTYLEDGERNAME>"
                f"<NARRATION>{escape(v['narration'])}</NARRATION>"
                f"<ISCANCELLED>{'Yes' if v.get('cancelled') else 'No'}</ISCANCELLED>"
                f"<AMOUNT>{party_amt}</AMOUNT>{entries}</VOUCHER>")

    def _filter_vouchers(self, root: ET.Element) -> list[dict[str, Any]]:
        sv = root.find(".//STATICVARIABLES")
        d_from = parse_tally_date(_text(sv, "SVFROMDATE"))
        d_to = parse_tally_date(_text(sv, "SVTODATE"))
        types: set[str] = set()
        for tag in ("SVVCHTYPE", "SVVOUCHERTYPE", "SVVOUCHERTYPENAME"):
            if _text(sv, tag):
                types.add(_text(sv, tag).lower())
        for f in list(root.iter("FILTERS")) + list(root.iter("FILTER")):
            for part in re.split(r"[,;]", f.text or ""):
                if part.strip() in STANDARD_VOUCHER_TYPES:
                    types.add(part.strip().lower())
        raw = ET.tostring(root, encoding="unicode")
        for m in re.finditer(r"\$(?:VoucherTypeName|VchType|Parent:VoucherType:\$VoucherTypeName)\s*=\s*"
                             r"(?:\"|&quot;)([^\"&]+)(?:\"|&quot;)", raw, re.IGNORECASE):
            types.add(m.group(1).strip().lower())
        out = []
        for v in self.data["vouchers"]:
            if v.get("deleted"):
                continue
            vd = parse_tally_date(v["date"])
            if d_from and vd and vd < d_from:
                continue
            if d_to and vd and vd > d_to:
                continue
            if types and v["type"].lower() not in types:
                continue
            out.append(v)
        return out


class _Counts:
    def __init__(self) -> None:
        self.created = self.altered = self.deleted = self.cancelled = 0
        self.errors: list[str] = []
        self.last_vch_id = 0

    def error(self, msg: str) -> None:
        self.errors.append(msg)

    def response(self, data: dict[str, Any]) -> str:
        line_errors = "".join(f"<LINEERROR>{escape(e)}</LINEERROR>" for e in self.errors)
        return (f"<RESPONSE>{line_errors}<CREATED>{self.created}</CREATED><ALTERED>{self.altered}</ALTERED>"
                f"<DELETED>{self.deleted}</DELETED><LASTVCHID>{self.last_vch_id}</LASTVCHID>"
                f"<LASTMID>{data.get('last_mid', 0)}</LASTMID><COMBINED>0</COMBINED><IGNORED>0</IGNORED>"
                f"<ERRORS>{len(self.errors)}</ERRORS><CANCELLED>{self.cancelled}</CANCELLED>"
                f"<EXCEPTIONS>0</EXCEPTIONS></RESPONSE>")


def _error_response(msg: str) -> str:
    return (f"<RESPONSE><LINEERROR>{escape(msg)}</LINEERROR><CREATED>0</CREATED><ALTERED>0</ALTERED>"
            "<LASTVCHID>0</LASTVCHID><LASTMID>0</LASTMID><COMBINED>0</COMBINED><IGNORED>0</IGNORED>"
            "<ERRORS>1</ERRORS><CANCELLED>0</CANCELLED><EXCEPTIONS>0</EXCEPTIONS></RESPONSE>")


# --------------------------------------------------------------------------------------
# HTTP server
# --------------------------------------------------------------------------------------


class MockTallyServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, addr: tuple[str, int], state: TallyState, utf16: bool = False,
                 fail_rate: float = 0.0, delay: float = 0.0, quiet: bool = True) -> None:
        super().__init__(addr, _Handler)
        self.state = state
        self.utf16 = utf16
        self.fail_rate = fail_rate
        self.delay = delay
        self.quiet = quiet


class _Handler(BaseHTTPRequestHandler):
    server: MockTallyServer
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt: str, *args: Any) -> None:  # noqa: D401
        if not self.server.quiet:
            super().log_message(fmt, *args)

    def _send(self, body: bytes, ctype: str) -> None:
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_xml(self, text: str) -> None:
        if self.server.utf16:
            self._send(b"\xff\xfe" + text.encode("utf-16-le"), "text/xml; charset=utf-16")
        else:
            self._send(text.encode("utf-8"), "text/xml; charset=utf-8")

    def _maybe_drop(self) -> bool:
        if self.server.fail_rate and random.random() < self.server.fail_rate:
            self.close_connection = True
            try:
                self.connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            return True
        return False

    def do_GET(self) -> None:  # noqa: N802
        if self.path.startswith("/_state"):
            self._send(json.dumps(self.server.state.snapshot(), indent=1).encode("utf-8"), "application/json")
        else:
            self._send_xml("<RESPONSE>TallyPrime Server is Running</RESPONSE>")

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b""
        if self._maybe_drop():
            return
        if self.server.delay:
            threading.Event().wait(self.server.delay)
        if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
            text = raw.decode("utf-16", errors="replace")
        else:
            text = raw.decode("utf-8-sig", errors="replace")
        self._send_xml(self.server.state.handle(text))


def make_server(host: str = "127.0.0.1", port: int = 0, data_file: Optional[Path] = None,
                company: str = DEFAULT_COMPANY, seed: Optional[list[dict[str, Any]]] = None,
                utf16: bool = False, fail_rate: float = 0.0, delay: float = 0.0,
                quiet: bool = True) -> MockTallyServer:
    """Create (not start) a server; ``port=0`` picks a free port (see ``server.server_port``)."""
    state = TallyState(data_file, company, seed)
    return MockTallyServer((host, port), state, utf16=utf16, fail_rate=fail_rate, delay=delay, quiet=quiet)


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Mock TallyPrime XML server (testing only).")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=9000)
    p.add_argument("--data", type=Path, default=Path("mock_tally_data.json"),
                   help="JSON file the company data is loaded from / saved to")
    p.add_argument("--seed", type=Path, help='JSON list of extra ledgers: [{"name":…, "parent":…, "gstin":…}]')
    p.add_argument("--company", default=DEFAULT_COMPANY)
    p.add_argument("--utf16", action="store_true", help="answer in UTF-16 LE with BOM")
    p.add_argument("--fail-rate", type=float, default=0.0, help="fraction (0-1) of POSTs whose connection is dropped")
    p.add_argument("--delay", type=float, default=0.0, help="seconds to wait before answering each POST")
    p.add_argument("--verbose", action="store_true")
    a = p.parse_args(argv)
    seed = json.loads(a.seed.read_text(encoding="utf-8")) if a.seed else None
    srv = make_server(a.host, a.port, a.data, a.company, seed, a.utf16, a.fail_rate, a.delay, quiet=not a.verbose)
    print(f"Mock TallyPrime for '{srv.state.company}' on http://{a.host}:{srv.server_port} (data: {a.data})")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
