#!/usr/bin/env python3
"""TCE Tally Connector — links TallyPrime on an office PC to the cloud ERP.

Implements the agent protocol in ``docs/TALLY_CONNECTOR.md``:

    every cycle:
      probe Tally -> heartbeat
      resend undelivered results from the local outbox (oldest first)
      if enabled: lease up to 20 jobs; for each, in order: POST to Tally, send the result
      sleep poll_seconds (5 s when the lease was full; back-off on errors; 15 min on a bad key)

The connector is deliberately thin: it never builds or interprets Tally XML (apart from
reading the company name out of the heartbeat probe). Standard library only, so it can be
frozen into a single exe with PyInstaller.

Usage::

    python connector.py run    [--config connector.ini]   # forever (what the service runs)
    python connector.py once   [--config connector.ini]   # a single cycle
    python connector.py test   [--config connector.ini]   # human-readable self-check
"""

from __future__ import annotations

import argparse
import configparser
import html
import json
import logging
import logging.handlers
import os
import re
import signal
import socket
import ssl
import sys
import threading
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

__version__ = "1.0.0"
USER_AGENT = f"TCE-Tally-Connector/{__version__}"
API_PREFIX = "/api/v1/tally-agent"

LEASE_LIMIT = 20
DEFAULT_POLL_SECONDS = 60
BACKLOG_POLL_SECONDS = 5           # used when the last lease came back full
MIN_POLL_SECONDS = 5
MAX_POLL_SECONDS = 3600
MAX_BACKOFF_SECONDS = 300          # exponential back-off ceiling (5 minutes)
BAD_KEY_RETRY_SECONDS = 15 * 60    # retry interval after 401 BAD_CONNECTOR_KEY
ERP_TIMEOUT_SECONDS = 30
MAX_RESPONSE_BYTES = 20 * 1024 * 1024  # Tally replies above this are truncated
LOG_MAX_BYTES = 1024 * 1024
LOG_BACKUPS = 5

TALLY_PROBE_XML = (
    "<ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST>"
    "<TYPE>Collection</TYPE><ID>Company List</ID></HEADER>"
    "<BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT></STATICVARIABLES>"
    '<TDL><TDLMESSAGE><COLLECTION NAME="Company List" ISMODIFY="No"><TYPE>Company</TYPE>'
    "<FETCH>NAME</FETCH></COLLECTION></TDLMESSAGE></TDL>"
    "</DESC></BODY></ENVELOPE>"
)

log = logging.getLogger("tce.connector")


# --------------------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------------------


class ConfigError(Exception):
    """The configuration file is missing or invalid (message is user-facing)."""


def app_dir() -> Path:
    """Folder holding the exe (when frozen by PyInstaller) or this script."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


@dataclass
class Config:
    erp_url: str
    connector_key: str
    tally_url: str = "http://localhost:9000"
    timeout_seconds: float = 60.0
    log_dir: Path = field(default_factory=lambda: app_dir() / "logs")
    verify_tls: bool = True
    ca_bundle: Optional[Path] = None
    proxy: Optional[str] = None           # e.g. http://proxy.office.local:8080 ; empty = system default
    outbox_file: Path = field(default_factory=lambda: app_dir() / "outbox.jsonl")
    source: Optional[Path] = None         # the ini file this came from

    @property
    def api_base(self) -> str:
        """``https://erp.example.com`` (or ``…/api/v1``) -> ``https://erp.example.com/api/v1/tally-agent``."""
        base = self.erp_url.strip().rstrip("/")
        for suffix in ("/api/v1/tally-agent", "/api/v1"):
            if base.endswith(suffix):
                base = base[: -len(suffix)]
                break
        return base + API_PREFIX


def mask_key(key: str) -> str:
    """Never log the connector key: keep the first 6 characters only."""
    if not key:
        return "(empty)"
    return key[:6] + "…"


def default_config_path() -> Path:
    return app_dir() / "connector.ini"


def load_config(path: Optional[Path] = None) -> Config:
    path = Path(path) if path else default_config_path()
    if not path.is_file():
        raise ConfigError(
            f"Configuration file not found: {path}\n"
            f"Copy connector.example.ini to connector.ini and fill in erp_url and connector_key."
        )
    parser = configparser.ConfigParser(interpolation=None)
    try:
        parser.read(path, encoding="utf-8-sig")  # tolerate Notepad's BOM
    except configparser.Error as exc:
        raise ConfigError(f"Could not read {path}: {exc}") from exc
    if not parser.has_section("connector"):
        raise ConfigError(f"{path} must contain a [connector] section.")
    sec = parser["connector"]
    base = path.resolve().parent

    def _path(value: str) -> Path:
        p = Path(os.path.expandvars(value.strip()))
        return p if p.is_absolute() else (base / p)

    erp_url = sec.get("erp_url", "").strip()
    key = sec.get("connector_key", "").strip()
    if not erp_url:
        raise ConfigError("erp_url is empty in the configuration file.")
    if not erp_url.lower().startswith(("http://", "https://")):
        raise ConfigError(f"erp_url must start with https:// (got {erp_url!r}).")
    if not key:
        raise ConfigError("connector_key is empty in the configuration file.")
    try:
        timeout = sec.getfloat("timeout_seconds", fallback=60.0)
        verify = sec.getboolean("verify_tls", fallback=True)
    except ValueError as exc:
        raise ConfigError(f"Invalid value in {path}: {exc}") from exc
    if timeout <= 0:
        raise ConfigError("timeout_seconds must be a positive number.")

    ca = sec.get("ca_bundle", "").strip()
    proxy = sec.get("proxy", "").strip()
    log_dir = sec.get("log_dir", "").strip()
    outbox = sec.get("outbox_file", "").strip()
    return Config(
        erp_url=erp_url,
        connector_key=key,
        tally_url=(sec.get("tally_url", "").strip() or "http://localhost:9000").rstrip("/"),
        timeout_seconds=timeout,
        log_dir=_path(log_dir) if log_dir else base / "logs",
        verify_tls=verify,
        ca_bundle=_path(ca) if ca else None,
        proxy=proxy or None,
        outbox_file=_path(outbox) if outbox else base / "outbox.jsonl",
        source=path,
    )


# --------------------------------------------------------------------------------------
# Logging
# --------------------------------------------------------------------------------------


class _SecretFilter(logging.Filter):
    """Belt and braces: replace the key in any log record, however it got there."""

    def __init__(self, secret: str) -> None:
        super().__init__()
        self.secret = secret
        self.masked = mask_key(secret)

    def filter(self, record: logging.LogRecord) -> bool:
        if self.secret and len(self.secret) > 6:
            msg = record.getMessage()
            if self.secret in msg:
                record.msg = msg.replace(self.secret, self.masked)
                record.args = None
        return True


def setup_logging(log_dir: Path, secret: str = "", console: bool = True) -> Path:
    """Rotating file (1 MB x 5) plus console. Safe to call repeatedly (handlers are replaced)."""
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "connector.log"
    for h in list(log.handlers):
        log.removeHandler(h)
        h.close()
    log.setLevel(logging.INFO)
    log.propagate = False
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(message)s")
    flt = _SecretFilter(secret)
    fh = logging.handlers.RotatingFileHandler(
        log_file, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUPS, encoding="utf-8"
    )
    fh.setFormatter(fmt)
    fh.addFilter(flt)
    log.addHandler(fh)
    if console:
        ch = logging.StreamHandler()
        ch.setFormatter(fmt)
        ch.addFilter(flt)
        log.addHandler(ch)
    return log_file


# --------------------------------------------------------------------------------------
# Tally
# --------------------------------------------------------------------------------------


@dataclass
class TallyResult:
    """Exactly the body of ``POST /jobs/{id}/result`` (doc §2.3)."""

    ok: bool
    status_code: Optional[int]
    response: Optional[str]
    error: Optional[str]
    elapsed_ms: int

    def to_json(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "status_code": self.status_code,
            "response": self.response,
            "error": self.error,
            "elapsed_ms": self.elapsed_ms,
        }


def decode_tally_body(raw: bytes) -> str:
    """Decode a Tally reply: UTF-16 when a BOM is present, else UTF-8; strip NUL chars.

    Tally sometimes answers in UTF-16 LE (with BOM) and sometimes in UTF-8. A body whose odd
    bytes are mostly NUL is treated as BOM-less UTF-16 LE.
    """
    if raw.startswith(b"\xff\xfe") or raw.startswith(b"\xfe\xff"):
        if len(raw) % 2:  # a truncated body may end mid code-unit
            raw = raw[:-1]
        text = raw.decode("utf-16", errors="replace")
    elif raw.startswith(b"\xef\xbb\xbf"):
        text = raw[3:].decode("utf-8", errors="replace")
    elif len(raw) >= 4 and raw[1::2].count(0) > len(raw) // 4:
        # BOM-less UTF-16 LE: ASCII text has a NUL in every odd byte. (Such bytes are technically
        # valid UTF-8 too, so this must be checked first.)
        text = raw[: len(raw) - len(raw) % 2].decode("utf-16-le", errors="replace")
    else:
        text = raw.decode("utf-8", errors="replace")
    return text.replace("\x00", "")


def _describe_error(exc: BaseException, url: str, timeout: float) -> str:
    """Short human-readable error, e.g. ``Connection refused (http://localhost:9000)``."""
    reason: Any = exc.reason if isinstance(exc, urllib.error.URLError) else exc
    if isinstance(reason, (socket.timeout, TimeoutError)):
        return f"Timed out after {timeout:g} s ({url})"
    if isinstance(reason, ConnectionRefusedError):
        return f"Connection refused ({url})"
    if isinstance(reason, ConnectionResetError):
        return f"Connection reset by Tally ({url})"
    if isinstance(reason, socket.gaierror):
        return f"Unknown host ({url}): {reason}"
    text = str(reason) or type(reason).__name__
    return f"{type(reason).__name__}: {text} ({url})"


class TallyClient:
    def __init__(self, url: str, timeout: float) -> None:
        self.url = url
        self.timeout = timeout
        # Never route localhost Tally traffic through an office/system proxy.
        self._opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def post(self, xml: str) -> TallyResult:
        start = time.monotonic()
        req = urllib.request.Request(
            self.url,
            data=xml.encode("utf-8"),
            method="POST",
            headers={"Content-Type": "text/xml; charset=utf-8", "User-Agent": USER_AGENT},
        )

        def elapsed() -> int:
            return int((time.monotonic() - start) * 1000)

        status: Optional[int]
        try:
            with self._opener.open(req, timeout=self.timeout) as resp:
                status = resp.status
                raw = resp.read(MAX_RESPONSE_BYTES + 1)
        except urllib.error.HTTPError as exc:  # Tally answered, but not with 200
            status = exc.code
            try:
                raw = exc.read(MAX_RESPONSE_BYTES + 1)
            except Exception:  # noqa: BLE001
                raw = b""
        except Exception as exc:  # noqa: BLE001 — anything else means "not reachable"
            return TallyResult(False, None, None, _describe_error(exc, self.url, self.timeout), elapsed())

        error: Optional[str] = None
        if len(raw) > MAX_RESPONSE_BYTES:
            raw = raw[:MAX_RESPONSE_BYTES]
            error = "response too large"
        text = decode_tally_body(raw)
        ok = status == 200
        if not ok and error is None:
            error = f"Tally returned HTTP {status}"
        return TallyResult(ok, status, text, error, elapsed())


def extract_company_name(text: str) -> Optional[str]:
    """First ``<COMPANY NAME="…">`` (or ``<NAME>…</NAME>``) in a Tally reply."""
    try:
        root = ET.fromstring(text)
        for el in root.iter("COMPANY"):
            if el.get("NAME"):
                return el.get("NAME", "").strip()
        for el in root.iter("NAME"):
            if el.text and el.text.strip():
                return el.text.strip()
    except ET.ParseError:
        pass  # Tally output may contain control characters; fall back to a regex
    m = re.search(r'<COMPANY\b[^>]*\bNAME="([^"]*)"', text) or re.search(r"<NAME\b[^>]*>([^<]+)</NAME>", text)
    return html.unescape(m.group(1)).strip() if m else None


@dataclass
class ProbeResult:
    ok: bool
    error: Optional[str]
    company: Optional[str]


def probe_tally(client: TallyClient) -> ProbeResult:
    res = client.post(TALLY_PROBE_XML)
    if not res.ok:
        return ProbeResult(False, res.error, None)
    body = res.response or ""
    if "<ENVELOPE" not in body and "<RESPONSE" not in body:
        return ProbeResult(False, "Unexpected reply (is this really TallyPrime on that port?)", None)
    company = extract_company_name(body)
    if company is None:
        return ProbeResult(True, "TallyPrime is running but no company is open", None)
    return ProbeResult(True, None, company)


# --------------------------------------------------------------------------------------
# ERP
# --------------------------------------------------------------------------------------


class ErpError(Exception):
    """Base class for ERP call failures."""


class ErpUnavailable(ErpError):
    """Network error, timeout, 5xx or 429 — try again later."""


class ErpAuthError(ErpError):
    """401: the connector key is unknown or revoked."""


class ErpRejected(ErpError):
    """Other 4xx: the ERP refused this particular request (retrying will not help)."""

    def __init__(self, status: int, message: str) -> None:
        super().__init__(message)
        self.status = status


class ErpClient:
    def __init__(self, cfg: Config) -> None:
        self.base = cfg.api_base
        self.key = cfg.connector_key
        ctx = ssl.create_default_context(cafile=str(cfg.ca_bundle) if cfg.ca_bundle else None)
        if not cfg.verify_tls:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        handlers: list[urllib.request.BaseHandler] = [urllib.request.HTTPSHandler(context=ctx)]
        if cfg.proxy:
            handlers.append(urllib.request.ProxyHandler({"http": cfg.proxy, "https": cfg.proxy}))
        # Without an explicit proxy urllib uses the environment / Windows Internet settings.
        self._opener = urllib.request.build_opener(*handlers)

    def post(self, path: str, body: dict[str, Any]) -> Any:
        """POST JSON, return the ``data`` member of the reply."""
        url = self.base + path
        req = urllib.request.Request(
            url,
            data=json.dumps(body).encode("utf-8"),
            method="POST",
            headers={
                "Authorization": f"Bearer {self.key}",
                "User-Agent": USER_AGENT,
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
        )
        try:
            with self._opener.open(req, timeout=ERP_TIMEOUT_SECONDS) as resp:
                payload = resp.read()
        except urllib.error.HTTPError as exc:
            detail = _erp_error_detail(exc)
            if exc.code == 401:
                raise ErpAuthError(detail) from None
            if exc.code in (408, 429) or exc.code >= 500:
                raise ErpUnavailable(f"ERP returned HTTP {exc.code}: {detail}") from None
            raise ErpRejected(exc.code, f"ERP returned HTTP {exc.code}: {detail}") from None
        except Exception as exc:  # noqa: BLE001
            raise ErpUnavailable(_describe_error(exc, self.base, ERP_TIMEOUT_SECONDS)) from None
        try:
            doc = json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ErpUnavailable(f"ERP sent a reply that is not JSON ({url}) — check erp_url / proxy") from None
        if not isinstance(doc, dict) or "data" not in doc:
            raise ErpUnavailable(f"ERP reply has no 'data' member ({url})")
        return doc["data"]

    def heartbeat(self, body: dict[str, Any]) -> dict[str, Any]:
        data = self.post("/heartbeat", body)
        return data if isinstance(data, dict) else {}

    def lease(self, limit: int) -> list[dict[str, Any]]:
        data = self.post("/jobs/lease", {"limit": limit})
        return data if isinstance(data, list) else []

    def result(self, job_id: str, result: dict[str, Any]) -> dict[str, Any]:
        from urllib.parse import quote

        data = self.post(f"/jobs/{quote(str(job_id), safe='')}/result", result)
        return data if isinstance(data, dict) else {}


def _erp_error_detail(exc: urllib.error.HTTPError) -> str:
    try:
        doc = json.loads(exc.read(64 * 1024).decode("utf-8", errors="replace"))
        err = doc.get("error") or {}
        if isinstance(err, dict):
            code, msg = err.get("code"), err.get("message")
            return " ".join(str(x) for x in (code, msg) if x) or exc.reason
        return str(err) or str(doc.get("detail") or exc.reason)
    except Exception:  # noqa: BLE001
        return str(exc.reason)


# --------------------------------------------------------------------------------------
# Outbox — results that could not be delivered yet
# --------------------------------------------------------------------------------------


class Outbox:
    """JSON-lines file; one ``{"job_id", "label", "result", "queued_at"}`` per line."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = threading.Lock()

    def load(self) -> list[dict[str, Any]]:
        if not self.path.is_file():
            return []
        entries: list[dict[str, Any]] = []
        with self._lock, self.path.open("r", encoding="utf-8") as fh:
            for n, line in enumerate(fh, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    if isinstance(entry, dict) and entry.get("job_id") and isinstance(entry.get("result"), dict):
                        entries.append(entry)
                        continue
                except json.JSONDecodeError:
                    pass
                log.warning("Outbox: skipping unreadable line %d in %s", n, self.path)
        return entries

    def append(self, job_id: str, label: str, result: dict[str, Any]) -> None:
        entry = {"job_id": job_id, "label": label, "result": result, "queued_at": time.strftime("%Y-%m-%dT%H:%M:%S")}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._lock, self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
            fh.flush()
            os.fsync(fh.fileno())

    def replace(self, entries: list[dict[str, Any]]) -> None:
        """Atomically rewrite the outbox (delete the file when empty)."""
        with self._lock:
            if not entries:
                self.path.unlink(missing_ok=True)
                return
            tmp = self.path.with_suffix(self.path.suffix + ".tmp")
            with tmp.open("w", encoding="utf-8") as fh:
                for e in entries:
                    fh.write(json.dumps(e, ensure_ascii=False) + "\n")
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, self.path)


# --------------------------------------------------------------------------------------
# The connector
# --------------------------------------------------------------------------------------


@dataclass
class CycleOutcome:
    status: str = "ok"            # "ok" | "error" | "auth_error"
    jobs_leased: int = 0
    jobs_done: int = 0
    lease_full: bool = False
    message: str = ""


def backoff_seconds(failures: int, poll_seconds: float) -> float:
    """Exponential back-off: poll, 2×poll, 4×poll … capped at 5 minutes (or poll, if larger)."""
    n = max(1, failures)
    return min(max(MAX_BACKOFF_SECONDS, poll_seconds), poll_seconds * 2 ** (n - 1))


def next_sleep(outcome: CycleOutcome, poll_seconds: float, failures: int) -> float:
    if outcome.status == "auth_error":
        return BAD_KEY_RETRY_SECONDS
    if outcome.status == "error":
        return backoff_seconds(failures, poll_seconds)
    if outcome.lease_full:
        return BACKLOG_POLL_SECONDS
    return poll_seconds


class Connector:
    def __init__(self, cfg: Config, stop_event: Optional[threading.Event] = None) -> None:
        self.cfg = cfg
        self.tally = TallyClient(cfg.tally_url, cfg.timeout_seconds)
        self.erp = ErpClient(cfg)
        self.outbox = Outbox(cfg.outbox_file)
        self.stop_event = stop_event or threading.Event()
        self.poll_seconds: float = DEFAULT_POLL_SECONDS
        self.host = socket.gethostname()

    # -- one cycle ---------------------------------------------------------------------

    def run_cycle(self) -> CycleOutcome:
        """One full cycle. Never raises (every failure becomes an outcome)."""
        try:
            return self._cycle()
        except ErpAuthError as exc:
            log.error(
                "The ERP rejected the connector key %s (%s). The key was revoked or mistyped: "
                "create a new key in Finance > Tally Sync > Connector and update connector.ini. "
                "Retrying in 15 minutes.",
                mask_key(self.cfg.connector_key), exc,
            )
            return CycleOutcome(status="auth_error", message=str(exc))
        except ErpError as exc:
            log.warning("ERP not reachable: %s", exc)
            return CycleOutcome(status="error", message=str(exc))
        except Exception as exc:  # noqa: BLE001 — never crash
            log.exception("Unexpected error in cycle: %s", exc)
            return CycleOutcome(status="error", message=f"{type(exc).__name__}: {exc}")

    def _cycle(self) -> CycleOutcome:
        probe = probe_tally(self.tally)
        if probe.ok and probe.company:
            log.debug("Tally OK, company %r", probe.company)
        else:
            log.warning("Tally check: %s", probe.error)

        hb = self.erp.heartbeat({
            "agent_version": __version__,
            "host": self.host,
            "tally_url": self.cfg.tally_url,
            "tally_ok": probe.ok,
            "tally_error": probe.error,
            "tally_company": probe.company,
            "tally_version": None,  # not exposed by the probe; reserved
        })
        try:
            poll = float(hb.get("poll_seconds") or DEFAULT_POLL_SECONDS)
        except (TypeError, ValueError):
            poll = DEFAULT_POLL_SECONDS
        self.poll_seconds = min(MAX_POLL_SECONDS, max(MIN_POLL_SECONDS, poll))
        expected = hb.get("company")
        if expected and probe.company and expected.strip().lower() != probe.company.strip().lower():
            log.warning("Tally has company %r open but the ERP expects %r", probe.company, expected)

        # Undelivered results first, oldest first. If that fails the ERP is down: stop here.
        if not self.flush_outbox():
            return CycleOutcome(status="error", message="outbox not delivered")

        if hb.get("enabled", True) is False:
            log.info("Tally sync is switched off in the ERP; not leasing jobs.")
            return CycleOutcome()

        jobs = self.erp.lease(LEASE_LIMIT)
        outcome = CycleOutcome(jobs_leased=len(jobs), lease_full=len(jobs) >= LEASE_LIMIT)
        if jobs:
            log.info("Leased %d job(s)", len(jobs))
        for job in jobs:
            if self.stop_event.is_set():
                log.info("Stopping: remaining leased jobs will be handed out again by the ERP.")
                break
            job_id, xml, label = job.get("id"), job.get("xml"), str(job.get("label") or "")
            if not job_id or not isinstance(xml, str):
                log.warning("Ignoring malformed job from ERP: %r", {k: job.get(k) for k in ("id", "kind", "label")})
                continue
            result = self.tally.post(xml)
            if result.ok:
                log.info("Job %s (%s): Tally answered in %d ms", job_id, label, result.elapsed_ms)
            else:
                log.warning("Job %s (%s): Tally failed — %s", job_id, label, result.error)
            delivered = self._deliver(str(job_id), label, result.to_json())
            if not delivered:
                # The ERP went away: keep the order intact by not touching later jobs.
                outcome.status, outcome.message = "error", "result kept in outbox"
                break
            outcome.jobs_done += 1
            if not result.ok:
                # Tally is unreachable — the remaining jobs would fail too, and order matters.
                # They stay leased and the ERP hands them out again later.
                outcome.status, outcome.message = "error", result.error or "Tally failed"
                break
        return outcome

    def _deliver(self, job_id: str, label: str, result: dict[str, Any]) -> bool:
        """Send one result; on a temporary ERP failure keep it in the outbox. Raises ErpAuthError."""
        try:
            reply = self.erp.result(job_id, result)
            log.info("Job %s (%s): ERP says %s %s", job_id, label, reply.get("status", "?"), reply.get("message") or "")
            return True
        except ErpRejected as exc:
            log.warning("Job %s (%s): ERP refused the result (%s); dropping it.", job_id, label, exc)
            return True
        except ErpAuthError:
            self.outbox.append(job_id, label, result)
            raise
        except ErpError as exc:
            log.warning("Job %s (%s): could not deliver result (%s); saved to outbox.", job_id, label, exc)
            self.outbox.append(job_id, label, result)
            return False

    def flush_outbox(self) -> bool:
        """Resend stored results in order. True when the outbox is empty afterwards."""
        entries = self.outbox.load()
        if not entries:
            return True
        log.info("Resending %d stored result(s)", len(entries))
        remaining = list(entries)
        try:
            while remaining:
                e = remaining[0]
                try:
                    reply = self.erp.result(e["job_id"], e["result"])
                    log.info("Job %s (%s): stored result delivered, ERP says %s",
                             e["job_id"], e.get("label", ""), reply.get("status", "?"))
                except ErpRejected as exc:
                    log.warning("Job %s: ERP refused stored result (%s); dropping it.", e["job_id"], exc)
                except ErpAuthError:
                    raise
                except ErpError as exc:
                    log.warning("Outbox: ERP still not reachable (%s); %d result(s) kept.", exc, len(remaining))
                    return False
                remaining.pop(0)
            return True
        finally:
            if len(remaining) != len(entries):
                self.outbox.replace(remaining)

    # -- forever -------------------------------------------------------------------------

    def run_forever(self) -> None:
        log.info("TCE Tally Connector %s starting (ERP %s, Tally %s, key %s)",
                 __version__, self.cfg.api_base, self.cfg.tally_url, mask_key(self.cfg.connector_key))
        failures = 0
        last_status = "ok"
        while not self.stop_event.is_set():
            outcome = self.run_cycle()
            failures = failures + 1 if outcome.status == "error" else 0
            if outcome.status == "ok" and last_status != "ok":
                log.info("Back to normal.")
            last_status = outcome.status
            delay = next_sleep(outcome, self.poll_seconds, failures)
            if outcome.status != "ok":
                log.info("Next attempt in %d s", delay)
            self._sleep(delay)
        log.info("TCE Tally Connector stopped.")

    def _sleep(self, seconds: float) -> None:
        # Short slices so Ctrl+C / service stop is honoured promptly on Windows too.
        deadline = time.monotonic() + seconds
        while not self.stop_event.is_set():
            left = deadline - time.monotonic()
            if left <= 0:
                break
            self.stop_event.wait(min(1.0, left))


# --------------------------------------------------------------------------------------
# `test` command — human-readable self-check
# --------------------------------------------------------------------------------------


def self_test(cfg: Config, out: Callable[[str], None] = print) -> bool:
    good = True

    def line(ok: Optional[bool], title: str, detail: str = "") -> None:
        mark = {True: "[ OK ]", False: "[FAIL]", None: "[WARN]"}[ok]
        out(f"{mark} {title}" + (f"\n         {detail}" if detail else ""))

    out(f"TCE Tally Connector {__version__} — self test")
    out(f"Config file : {cfg.source}")
    out(f"ERP address : {cfg.api_base}")
    out(f"Tally       : {cfg.tally_url}")
    out(f"Key         : {mask_key(cfg.connector_key)}")
    out(f"Logs        : {cfg.log_dir}")
    out("")

    if re.fullmatch(r"tck_[A-Za-z0-9_-]{20,}", cfg.connector_key):
        line(True, "Connector key looks well-formed")
    else:
        line(None, "Connector key does not look like tck_…",
             "Copy the whole key exactly as shown in the ERP (Finance > Tally Sync > Connector).")
    if not cfg.verify_tls:
        line(None, "verify_tls is off", "HTTPS certificates are not checked. Only use this for testing.")

    probe = probe_tally(TallyClient(cfg.tally_url, min(cfg.timeout_seconds, 15)))
    if probe.ok and probe.company:
        line(True, "TallyPrime is reachable", f"Open company: {probe.company}")
    elif probe.ok:
        line(None, "TallyPrime is running but no company is open", "Open the company in TallyPrime.")
    else:
        good = False
        line(False, "Cannot reach TallyPrime", f"{probe.error}\n         Is TallyPrime open, with Client/Server "
             "set to 'Both' on port 9000 (F1 > Settings > Connectivity)?")

    try:
        hb = ErpClient(cfg).heartbeat({
            "agent_version": __version__, "host": socket.gethostname(), "tally_url": cfg.tally_url,
            "tally_ok": probe.ok, "tally_error": probe.error, "tally_company": probe.company, "tally_version": None,
        })
        line(True, "ERP accepted the heartbeat",
             f"sync enabled: {hb.get('enabled', True)}, poll every {hb.get('poll_seconds', DEFAULT_POLL_SECONDS)} s, "
             f"expected company: {hb.get('company') or '-'}")
        exp = hb.get("company")
        if exp and probe.company and exp.strip().lower() != probe.company.strip().lower():
            line(None, "Company mismatch", f"Tally has '{probe.company}' open; the ERP expects '{exp}'.")
        if hb.get("enabled", True) is False:
            line(None, "Tally sync is switched off in the ERP", "Jobs will not be sent until it is switched on.")
    except ErpAuthError as exc:
        good = False
        line(False, "ERP rejected the connector key", f"{exc}\n         The key was revoked or mistyped. "
             "Create a new key in the ERP and paste it into connector.ini.")
    except ErpError as exc:
        good = False
        line(False, "Cannot reach the ERP", f"{exc}\n         Check the internet connection, erp_url, and any "
             "office proxy/firewall.")

    pending = len(Outbox(cfg.outbox_file).load())
    if pending:
        line(None, f"{pending} result(s) waiting in the outbox", "They are sent automatically on the next cycle.")
    out("")
    out("All checks passed." if good else "Some checks failed — see above.")
    return good


# --------------------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------------------


def _install_stop_handlers(stop: threading.Event) -> None:
    def handler(signum: int, _frame: Any) -> None:
        log.info("Stop requested (signal %s)", signum)
        stop.set()

    for name in ("SIGTERM", "SIGBREAK", "SIGINT"):
        sig = getattr(signal, name, None)
        if sig is not None:
            try:
                signal.signal(sig, handler)
            except (ValueError, OSError):
                pass


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(prog="TCE-Tally-Connector", description="Links TallyPrime to the TCE ERP.")
    parser.add_argument("command", nargs="?", default="run", choices=["run", "once", "test"],
                        help="run = forever (default), once = one cycle, test = self-check")
    parser.add_argument("--config", type=Path, default=None, help="path to connector.ini")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    args = parser.parse_args(argv)

    try:
        cfg = load_config(args.config)
    except ConfigError as exc:
        print(f"Configuration problem: {exc}", file=sys.stderr)
        return 2

    if args.command == "test":
        setup_logging(cfg.log_dir, cfg.connector_key, console=False)
        ok = self_test(cfg)
        log.info("Self test finished: %s", "passed" if ok else "FAILED")
        return 0 if ok else 1

    setup_logging(cfg.log_dir, cfg.connector_key)
    stop = threading.Event()
    connector = Connector(cfg, stop)
    if args.command == "once":
        outcome = connector.run_cycle()
        log.info("Cycle finished: %s (%d leased, %d processed)", outcome.status, outcome.jobs_leased, outcome.jobs_done)
        return 0 if outcome.status == "ok" else 1

    _install_stop_handlers(stop)
    try:
        connector.run_forever()
    except KeyboardInterrupt:
        log.info("Stopped by Ctrl+C.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
