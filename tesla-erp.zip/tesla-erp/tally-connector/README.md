# TCE Tally Connector

A small program that runs on the office PC where **TallyPrime** is installed. It collects accounting entries
(customers, invoices, receipts, payments…) from the **TCE ERP** on the internet and enters them into Tally for you.
It can also read ledger balances and receipts back from Tally so the ERP can show them.

```
TallyPrime (this PC)  ◄──►  TCE Tally Connector (this PC)  ──── internet (HTTPS) ────►  TCE ERP
```

You install it once. After that it runs quietly in the background whenever the PC is on.

---

## Is it safe?

* **It only calls out.** The connector contacts the ERP over an encrypted HTTPS connection, the same way a browser
  does. Nothing on the office router or firewall has to be opened.
* **Tally stays private.** Tally's port 9000 is only used inside this PC (`localhost`). It is never exposed to
  the internet.
* **One revocable key.** The connector proves who it is with a *connector key* created in the ERP. If the PC is
  lost or the key leaks, an ERP administrator revokes it in *Finance → Tally Sync → Connector* and the connector
  stops working immediately. The key is never written to the log files (only its first 6 characters are shown).
* **Nothing is lost.** If the internet or Tally is down, the entries wait safely in the ERP (and in a small local
  "outbox" file) and are sent automatically once everything is back.

---

## 1. Prepare TallyPrime (once)

1. Open TallyPrime and **open the company** *Tesla Consulting Engineers*.
2. Press **F1 (Help) → Settings → Connectivity → Client/Server configuration**:
   * *TallyPrime acts as*: **Both**
   * *Enable ODBC*: **Yes**
   * *Port*: **9000**
   Save, then **restart TallyPrime** once.
3. For each voucher type the ERP sends — **Sales, Credit Note, Receipt, Purchase, Payment, Journal** — go to
   *Alter → Voucher Type → (type)* and set:
   * *Method of voucher numbering*: **Manual**
   * *Prevent duplicates*: **Yes**

   (This stops the same invoice being entered twice.)
4. Keep TallyPrime open with the company loaded whenever you want entries to go through. If Tally is closed,
   entries simply wait until it is open again.

## 2. Get a connector key from the ERP

An ERP administrator opens **Finance → Tally Sync → Connector → Create key**. The key starts with `tck_` and is
shown **only once** — copy it straight into the settings file below.

## 3. Install the connector

### Option A — the ready-made program (recommended)

1. Create the folder `C:\TCE-Tally-Connector` and copy into it:
   `TCE-Tally-Connector.exe`, `connector.example.ini`, `install-service.ps1`, `uninstall-service.ps1`.
2. Download **NSSM** (free) from <https://nssm.cc/download>, open the zip, and copy `win64\nssm.exe` into
   `C:\TCE-Tally-Connector`.
3. Copy `connector.example.ini` to **`connector.ini`** and open it in Notepad. Fill in:
   ```ini
   erp_url = https://erp.yourcompany.com        ; the ERP address you use in the browser
   connector_key = tck_…                        ; the key from step 2
   ```
   Leave the other lines as they are. Save.
4. Check everything works — open *Command Prompt* in the folder and run:
   ```
   TCE-Tally-Connector.exe test
   ```
   You should see `[ OK ]` on every line and **All checks passed.** If not, see *Troubleshooting* below.
5. Install it as a Windows service: right-click **Start → Windows PowerShell (Admin)** and run:
   ```
   cd C:\TCE-Tally-Connector
   powershell -ExecutionPolicy Bypass -File .\install-service.ps1
   ```
   It now starts automatically with Windows and restarts itself if anything goes wrong. You will find it in
   *Services* (`services.msc`) as **TCE Tally Connector**.

   *No NSSM?* Use the Task Scheduler instead (same effect, starts at boot even when nobody is logged in):
   ```
   powershell -ExecutionPolicy Bypass -File .\install-service.ps1 -Mode Task
   ```

To remove it later: `powershell -ExecutionPolicy Bypass -File .\uninstall-service.ps1` (as Administrator).

### Option B — run with Python (for IT staff)

Needs Python 3.11 or newer installed *for all users* (no extra packages). Put `connector.py` and
`connector.ini` in one folder, then:

```
python connector.py test     # self-check
python connector.py once     # run one round and exit
python connector.py run      # run forever (Ctrl+C to stop)
```

`install-service.ps1` also works in this case — it uses `python connector.py run` when no `.exe` is present.
Use `--config C:\path\connector.ini` to keep the settings elsewhere.

### Building the .exe (IT staff)

On a Windows PC with Python 3.11+: `powershell -ExecutionPolicy Bypass -File .\build.ps1`. The ready-to-copy folder
appears in `dist\TCE-Tally-Connector\`.

---

## Day-to-day

* Every minute (the ERP decides the interval) the connector checks Tally, tells the ERP it is alive, and sends
  any waiting entries to Tally — strictly in order (new customers before their invoices).
* The ERP shows the connector's status (last seen, Tally reachable or not) in *Finance → Tally Sync*.
* If there is a big backlog it works through it in batches of 20, every 5 seconds.

### Where are the logs?

`C:\TCE-Tally-Connector\logs\connector.log` (plain text — open with Notepad). Older logs are kept as
`connector.log.1` … `connector.log.5` (1 MB each), so the folder never grows large. If the service itself fails to
start, look in `logs\service-errors.log`.

Results that could not be sent to the ERP yet are kept in `outbox.jsonl`. Do not delete it — it empties itself
once the internet is back.

---

## Troubleshooting

Run `TCE-Tally-Connector.exe test` first: it says in plain words what is wrong.

| What you see (in `test` or the log) | What it means | What to do |
|---|---|---|
| `Cannot reach TallyPrime` … `Connection refused (http://localhost:9000)` | Tally is not open, or its Client/Server setting is off. | Open TallyPrime. Check *F1 → Settings → Connectivity*: **Both**, port **9000**; restart Tally. |
| `TallyPrime is running but no company is open` | Tally is open at the company list. | Open the *Tesla Consulting Engineers* company. |
| `Could not set 'SVCurrentCompany' to '…'` in the ERP's Tally Sync page | A different company is open, or the company name differs. | Open the correct company (the name must match the ERP's setting exactly). |
| `Timed out after 60 s` | Tally is busy (e.g. a report or backup is running) or a firewall blocks port 9000 on this PC. | Wait and it will retry. If it keeps happening, allow TallyPrime in Windows Firewall, or raise `timeout_seconds`. |
| `Unexpected reply (is this really TallyPrime on that port?)` | Another program uses port 9000. | Change Tally's port (e.g. 9001) and set `tally_url = http://localhost:9001`. |
| `ERP rejected the connector key` / `BAD_CONNECTOR_KEY` | The key was revoked, mistyped or replaced. The connector now only retries every 15 minutes. | Create a new key in the ERP, paste it into `connector.ini`, restart the service (*Services → TCE Tally Connector → Restart*). |
| `Cannot reach the ERP` / `Unknown host` / `Connection refused` | No internet, or `erp_url` is wrong. | Open the ERP in a browser on this PC. Check `erp_url` (copy it from the browser address bar). |
| `CERTIFICATE_VERIFY_FAILED` | An office firewall/antivirus inspects HTTPS. | Ask IT for the firewall's certificate (.pem) and set `ca_bundle = C:\…\file.pem`. Do not turn off `verify_tls`. |
| `ERP sent a reply that is not JSON` / HTTP 407 | An office proxy is in the way. | Set `proxy = http://proxyserver:port` in `connector.ini` (ask IT for the address). |
| Entries arrive in the ERP as failed with `Voucher Number '…' already exists!` | That voucher is already in Tally (entered by hand earlier). | Nothing — the ERP treats this as "already in Tally". |
| `Ledger '…' does not exist!` | A ledger used by the voucher is missing in Tally. | The ERP normally creates ledgers first; use *Retry* in the ERP's Tally Sync page, or create the ledger in Tally. |
| The service keeps stopping | The settings file is missing or broken. | Run `TCE-Tally-Connector.exe test` and fix what it reports. |

---

## For developers / testing

* `mock_tally.py` — a pretend TallyPrime for tests and demos:
  `python mock_tally.py --port 9000 --data mock_tally_data.json [--utf16] [--fail-rate 0.2] [--delay 2]`.
  `GET http://localhost:9000/_state` shows its ledgers and vouchers. See the docstring at the top of the file for the
  XML it understands (import of masters/vouchers incl. Cancel, exports of Company/Ledger/Voucher with
  `SVFROMDATE`/`SVTODATE` and voucher-type filters via `SVVCHTYPE`, `<FILTER(S)>` text, or a
  `$VoucherTypeName = "Receipt"` TDL formula).
* `fake_erp.py` — a pretend ERP: `python fake_erp.py --port 8800 --key tck_… --demo`, then set
  `erp_url = http://127.0.0.1:8800` and run `python connector.py once`.
* Tests: `backend/.venv/bin/python -m pytest tally-connector/tests -q` (from the repository root).
* Protocol: `docs/TALLY_CONNECTOR.md`.
