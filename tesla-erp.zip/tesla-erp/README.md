# Tesla Consulting Engineers — ERP

A modular ERP for Tesla Consulting Engineers covering the full lifecycle from enquiry to AMC. It is built phase by phase following `docs/IMPLEMENTATION_PLAN.md`.

**Current status: Phase 5 complete (version 0.7.0)** — CRM (leads, enquiries, site visits, follow-ups), sales (BOQ, quotations with revisions and PDF, approvals, sales orders), projects (team, tasks, milestones, issues, daily site reports, BOQ tracking and installation) and procurement & inventory (material requests, purchase requests, purchase orders, GRN, stock ledger, site stores, transfers, adjustments). See the `docs/PHASE*_REPORT.md` files. The ERP can be deployed three ways:
- **VPS (chosen):** Ubuntu + Docker, PostgreSQL in a container, documents and nightly backups in Cloudflare R2, HTTPS at `erp.teslace.tech`. See **[docs/DEPLOY_VPS.md](docs/DEPLOY_VPS.md)**; the scripts are in `deploy/vps/`.
- **Office server (Windows .exe):** one PC runs everything and the other PCs use the TCE ERP desktop app. Documents and backups are stored on the NAS, and remote access goes through Cloudflare Tunnel. See **[docs/ONPREM.md](docs/ONPREM.md)**.
- **Managed cloud (AWS):** containers with S3 storage — see `docs/runbooks/deployment.md`.

Phase 1 covers the foundation, authentication, roles and permissions, audit, numbering, document storage, and the company, customer, supplier and item masters.

| | |
|---|---|
| Frontend | Next.js 16 · React 19 · TypeScript · Tailwind 4 (`frontend/`) |
| Backend | FastAPI · Pydantic 2 · SQLAlchemy 2 · Alembic (`backend/`) |
| Database | PostgreSQL 16 |
| Files | Cloudflare R2 / any S3-compatible storage (VPS, cloud) or a NAS share (office server) |

## Run it locally

### With Docker (recommended)
```bash
cp .env.example .env
docker compose up --build
```
- App: http://localhost:3000
- API docs: http://localhost:8000/api/docs
- MinIO console: http://localhost:9001
- Mail catcher: http://localhost:8025

### Without Docker
You need PostgreSQL 16, Python 3.11 and Node 22.
```bash
# database: create roles erp_owner / erp_app and database tesla_erp (see database/init/01-roles.sh)
cd backend
python -m venv .venv && . .venv/bin/activate && pip install -r requirements-dev.txt
alembic upgrade head
python -m app.seed demo      # 'core' only in staging/production
uvicorn app.main:app --reload

cd ../frontend
npm install && npm run dev
```

### Sign in
- **Administrator:** `admin` / `ChangeMe@12345`. You must choose a new password at first sign-in.
- **Demo users (development only):** one per role, all with password `Tesla@Demo2026`.
  - director, manager
  - sales1, sales2
  - pm1, engineer1
  - purchase1, store1, accounts1, hr1, employee1

## Tests
```bash
cd backend && pytest -q       # 138 tests against a real PostgreSQL database (tesla_erp_test)
cd frontend && npx tsc --noEmit && npm run build
```
The test suite covers:
- authentication and lockout
- refresh-token rotation and reuse detection
- the permission matrix (every endpoint × 11 roles)
- salesperson data scope
- append-only audit
- numbering: 50 concurrent users, financial-year reset, gap-free rollback, the 16-character GST invoice limit
- document type sniffing, versioning, size limits and the S3 backend
- Excel import/export
- optimistic locking
- migration round-trip

## Windows installer
Build `TCE-ERP-Setup-<version>.exe` in either of two ways:
- In GitHub: **Actions → Windows installer → Run workflow**. It builds on Windows, smoke-tests the setup wizard, the ERP and a backup, then attaches the installer.
- On a Windows PC: run `packaging\windows\build.ps1`.

Installation guide: [docs/ONPREM.md](docs/ONPREM.md).

## Repository layout
```
backend/app/
  core/        config, db session, errors, money, security, Indian validators, CRUD & Excel helpers
  platform/    audit · numbering · documents · settings · jobs  (shared by every module)
  auth/ users/ company/ hr/ customers/ suppliers/ products/ crm/ boq/ quotations/
backend/onprem/       Windows office-server supervisor, setup wizard, backups, NAS, tunnel
deploy/vps/           VPS: production compose, Caddy (HTTPS), server setup, deploy, backup, restore scripts
Dockerfile            single production image: API + web UI
desktop/              TCE ERP desktop app (pywebview)
packaging/windows/    PyInstaller specs, service definition, Inno Setup installer, build & smoke-test scripts
backend/migrations/   Alembic
backend/tests/        pytest
frontend/app/         pages (App Router)
frontend/components/  design system, shell, forms
database/             DB role/init scripts
scripts/              backup & restore drill
docs/                 architecture, plan, ADRs, permissions, runbooks, phase reports
```

## Rules this codebase keeps
- All schema changes go through Alembic migrations.
- No secrets in git.
- Money is never stored or calculated as a float.
- Every change writes an audit record in the same transaction.
- Posted financial records are cancelled or reversed, never deleted.
- Documents live in object storage, never on the app server.
