#!/usr/bin/env bash
# Logical backup of the ERP database (custom format, compressed). Production relies on RDS automated
# backups + point-in-time recovery; this script produces the monthly archive copy and is used for restore drills.
#   DATABASE_OWNER_URL=postgresql://erp_owner:...@host:5432/tesla_erp scripts/backup.sh [output-dir]
set -euo pipefail
: "${DATABASE_OWNER_URL:?set DATABASE_OWNER_URL (owner role, postgresql:// form)}"
OUT_DIR="${1:-./backups}"
mkdir -p "$OUT_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
FILE="$OUT_DIR/tesla_erp_${STAMP}.dump"
pg_dump --format=custom --compress=9 --no-owner --no-privileges --file="$FILE" "$DATABASE_OWNER_URL"
sha256sum "$FILE" > "$FILE.sha256"
echo "Backup written: $FILE ($(du -h "$FILE" | cut -f1))"
echo "Next: copy to s3://<backup-bucket>/monthly/ (S3 Glacier lifecycle)."
