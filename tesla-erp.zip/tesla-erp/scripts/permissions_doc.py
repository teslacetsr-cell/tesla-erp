"""Regenerates docs/PERMISSIONS.md from the permission registry and backend/app/users/default_roles.py.

    cd backend && .venv/bin/python ../scripts/permissions_doc.py
"""
import fnmatch
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

import app.registry  # noqa: F401,E402 - loads every module's permission codes
from app.core.permissions import MODULE_LABELS, REGISTRY  # noqa: E402
from app.users.default_roles import ROLES  # noqa: E402

COLS = [("ADMIN", "Admin"), ("DIRECTOR", "Dir"), ("MANAGER", "Mgr"), ("SALES", "Sales"), ("PROJECT_MANAGER", "PM"),
        ("SITE_ENGINEER", "Site"), ("PURCHASE", "Pur"), ("STORE", "Store"), ("ACCOUNTS", "Acc"), ("HR", "HR"),
        ("EMPLOYEE", "Emp")]
from app.core.permissions import ACTIONS as ORDER  # noqa: E402


def cell(role: str, code: str) -> str:
    for pattern, scope in ROLES[role]["grants"].items():
        if fnmatch.fnmatchcase(code, pattern):
            return "✓" if scope == "all" else scope
    return " "


def main() -> None:
    out = [
        "# Default permission matrix", "",
        "Generated from `backend/app/users/default_roles.py` by `scripts/permissions_doc.py` — the starting grants for the "
        "11 roles in Spec §6.",
        "After first setup, roles are data: an administrator changes them in **Administration → Roles** and every change "
        "is audited.",
        "When an update adds a new module (for example CRM in Phase 2), its permissions are given to Administrator and to "
        "the standard roles as listed below. Grants an administrator changed earlier are never touched.", "",
        "`✓` = allowed on all records · `own` = only records assigned to the user (customers: assigned salesperson; leads "
        "and enquiries: assigned salesperson or creator; site visits: the engineer, the creator, or the salesperson of the "
        "lead/enquiry) · blank = not allowed.", "",
        "Actions follow Spec §6: create, read (View), update (Edit), delete, approve, export, print.", "",
        "| Permission | " + " | ".join(c for _, c in COLS) + " |",
        "|---|" + "---|" * len(COLS),
    ]
    defs = sorted(REGISTRY.values(), key=lambda d: (MODULE_LABELS[d.module], ORDER.index(d.action)))
    for d in defs:
        label = f"{MODULE_LABELS[d.module]} — {d.description.split(' — ')[0]} (`{d.code}`)"
        out.append(f"| {label} | " + " | ".join(cell(r, d.code) for r, _ in COLS) + " |")
    out += ["", "## Role descriptions", ""]
    out += [f"- **{spec['name']}** (`{code}`) — {spec['description']}" for code, spec in ROLES.items()]
    Path(__file__).resolve().parent.parent.joinpath("docs", "PERMISSIONS.md").write_text("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
