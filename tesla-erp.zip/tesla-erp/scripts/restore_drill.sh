#!/usr/bin/env bash
# Restore drill: restore a backup into a scratch database and verify it. Never touches the live database.
#   ADMIN_URL=postgresql://postgres@host:5432/postgres scripts/restore_drill.sh backups/tesla_erp_....dump
set -euo pipefail
: "${ADMIN_URL:?set ADMIN_URL (superuser/admin connection to the server that will host the scratch DB)}"
FILE="${1:?backup file}"
sha256sum -c "$FILE.sha256"
SCRATCH="tesla_erp_restore_$(date -u +%Y%m%d%H%M%S)"
psql "$ADMIN_URL" -qc "CREATE DATABASE $SCRATCH"
SCRATCH_URL="${ADMIN_URL%/*}/$SCRATCH"
pg_restore --no-owner --no-privileges --dbname="$SCRATCH_URL" "$FILE"
echo "Row counts in restored copy ($SCRATCH):"
psql "$SCRATCH_URL" -At -c "
  SELECT 'customers', count(*) FROM customers UNION ALL
  SELECT 'suppliers', count(*) FROM suppliers UNION ALL
  SELECT 'items', count(*) FROM items UNION ALL
  SELECT 'users', count(*) FROM users UNION ALL
  SELECT 'documents', count(*) FROM documents UNION ALL
  SELECT 'audit_logs', count(*) FROM audit_logs UNION ALL
  SELECT 'alembic_version', count(*) FROM alembic_version"
echo "Restore OK. Record the result in docs/runbooks/backup-and-restore.md, then: DROP DATABASE $SCRATCH;"
