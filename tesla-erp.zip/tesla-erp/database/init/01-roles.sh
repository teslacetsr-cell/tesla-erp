#!/bin/bash
# Creates the two database roles (owner for migrations, least-privilege app role) and the database.
set -euo pipefail
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" <<SQL
CREATE ROLE erp_owner LOGIN PASSWORD '${DB_OWNER_PASSWORD}';
CREATE ROLE erp_app LOGIN PASSWORD '${DB_APP_PASSWORD}';
CREATE DATABASE tesla_erp OWNER erp_owner;
SQL
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname tesla_erp <<SQL
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS citext;
GRANT CONNECT ON DATABASE tesla_erp TO erp_app;
SQL
