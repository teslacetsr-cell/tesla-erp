; TCE ERP — Windows installer (Inno Setup 6)
; Built by .github/workflows/windows-installer.yml or packaging/windows/build.ps1:
;   iscc packaging\windows\tce-erp.iss /DAppVersion=0.2.0
; Expects the build to have produced:
;   build\server\  TCE-ERP-Server.exe + _internal\ + pgsql\ + cloudflared.exe + ui\ + TCE-ERP-Service.exe/.xml
;   build\desktop\TCE ERP.exe

#ifndef AppVersion
  #define AppVersion "0.2.0"
#endif
#define AppName "TCE ERP"
#define Publisher "Tesla Consulting Engineers"
#define Port "8080"

[Setup]
AppId={{6E7C2B8A-3F4D-4C1E-9A6B-7D2E5F1C0A91}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#Publisher}
DefaultDirName={autopf}\TCE ERP
DefaultGroupName=TCE ERP
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.17763
OutputDir=..\..\dist
OutputBaseFilename=TCE-ERP-Setup-{#AppVersion}
SetupIconFile=tce.ico
UninstallDisplayIcon={app}\TCE ERP.exe
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes

[Types]
Name: "server";  Description: "Office server — this PC runs the ERP for everyone (plus the desktop app)"
Name: "desktop"; Description: "Desktop app only — connect to the office server"

[Components]
Name: "server";  Description: "TCE ERP server (database, web server, backups, remote access)"; Types: server; Flags: fixed
Name: "desktop"; Description: "TCE ERP desktop app"; Types: server desktop; Flags: fixed

[Files]
Source: "..\..\build\server\*";  DestDir: "{app}\server"; Components: server; Flags: recursesubdirs createallsubdirs ignoreversion
Source: "..\..\build\desktop\TCE ERP.exe"; DestDir: "{app}"; Components: desktop; Flags: ignoreversion
Source: "tce.ico"; DestDir: "{app}"; Flags: ignoreversion

[Dirs]
; Server data (database, config, logs). Kept on uninstall so no business data is ever lost by reinstalling.
Name: "{commonappdata}\TCE-ERP"; Components: server; Flags: uninsneveruninstall

[Icons]
Name: "{autodesktop}\TCE ERP"; Filename: "{app}\TCE ERP.exe"; Components: desktop
Name: "{group}\TCE ERP"; Filename: "{app}\TCE ERP.exe"; Components: desktop
Name: "{group}\TCE ERP — change server address"; Filename: "{app}\TCE ERP.exe"; Parameters: "--server"; Components: desktop
Name: "{group}\TCE ERP server status"; Filename: "{cmd}"; Parameters: "/k ""{app}\server\TCE-ERP-Server.exe"" status"; Components: server
Name: "{group}\TCE ERP server setup page"; Filename: "http://localhost:{#Port}/setup"; Components: server

[Run]
; Server: register and start the Windows service, open the firewall for the office network, open the setup wizard.
Filename: "{app}\server\TCE-ERP-Service.exe"; Parameters: "install"; Components: server; Flags: runhidden waituntilterminated; StatusMsg: "Installing the TCE ERP service..."
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""TCE ERP"""; Components: server; Flags: runhidden waituntilterminated
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""TCE ERP"" dir=in action=allow protocol=TCP localport={#Port} profile=domain,private"; Components: server; Flags: runhidden waituntilterminated; StatusMsg: "Allowing office PCs to connect..."
Filename: "{app}\server\TCE-ERP-Service.exe"; Parameters: "start"; Components: server; Flags: runhidden waituntilterminated; StatusMsg: "Starting the TCE ERP server..."
Filename: "http://localhost:{#Port}/setup"; Description: "Open the server setup page"; Components: server; Flags: postinstall shellexec nowait; Check: not IsConfigured
Filename: "{app}\TCE ERP.exe"; Description: "Open TCE ERP"; Components: desktop; Flags: postinstall nowait skipifsilent unchecked

[UninstallRun]
Filename: "{app}\server\TCE-ERP-Service.exe"; Parameters: "stop"; Components: server; Flags: runhidden waituntilterminated; RunOnceId: "StopSvc"
Filename: "{app}\server\TCE-ERP-Service.exe"; Parameters: "uninstall"; Components: server; Flags: runhidden waituntilterminated; RunOnceId: "DelSvc"
Filename: "{sys}\sc.exe"; Parameters: "stop TCE-ERP-Database"; Components: server; Flags: runhidden waituntilterminated; RunOnceId: "StopDb"
Filename: "{app}\server\pgsql\bin\pg_ctl.exe"; Parameters: "unregister -N TCE-ERP-Database"; Components: server; Flags: runhidden waituntilterminated; RunOnceId: "DelDb"
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""TCE ERP"""; Components: server; Flags: runhidden waituntilterminated; RunOnceId: "DelFw"

[Messages]
FinishedLabel=Setup has installed [name] on your computer.%n%nServer PC: finish the server setup in the page that opens (NAS folder, administrator password, remote access).%nOther PCs: open TCE ERP and enter the server address.

[Code]
function IsConfigured(): Boolean;
var S: AnsiString;
begin
  Result := LoadStringFromFile(ExpandConstant('{commonappdata}\TCE-ERP\config.json'), S) and (Pos('"configured": true', S) > 0);
end;

// Upgrades: stop both services before files are replaced (their programs live in the install folder).
// The ERP service starts the database again when it starts.
function PrepareToInstall(var NeedsRestart: Boolean): String;
var Code: Integer;
begin
  if FileExists(ExpandConstant('{app}\server\TCE-ERP-Service.exe')) then
  begin
    Exec(ExpandConstant('{app}\server\TCE-ERP-Service.exe'), 'stop', '', SW_HIDE, ewWaitUntilTerminated, Code);
    Exec(ExpandConstant('{sys}\sc.exe'), 'stop TCE-ERP-Database', '', SW_HIDE, ewWaitUntilTerminated, Code);
    Sleep(4000);
  end;
  Result := '';
end;
