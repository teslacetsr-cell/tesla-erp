<#
  Builds the TCE ERP Windows installer:  dist\TCE-ERP-Setup-<version>.exe

  Run on a Windows 10/11 PC (or the GitHub Actions Windows runner) from the repository root:
      powershell -ExecutionPolicy Bypass -File packaging\windows\build.ps1 -Version 0.2.0

  Needs: Node.js 22, Python 3.11 (64-bit), Inno Setup 6 (https://jrsoftware.org/isdl.php), internet access.
#>
param(
  [string]$Version = "0.2.0",
  # PostgreSQL 16 Windows x64 binaries (zip) from https://www.enterprisedb.com/download-postgresql-binaries
  [string]$PgZipUrl = "https://sbp.enterprisedb.com/getfile.jsp?fileid=1260572",
  [string]$WinswUrl = "https://github.com/winsw/winsw/releases/download/v2.12.0/WinSW-x64.exe",
  [string]$CloudflaredUrl = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe",
  [switch]$SkipInstaller
)
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$Root = (Resolve-Path "$PSScriptRoot\..\..").Path
$Build = Join-Path $Root "build"
$Cache = Join-Path $Root ".build-cache"
New-Item -ItemType Directory -Force -Path $Build, $Cache | Out-Null

function Step($m) { Write-Host "`n=== $m ===" -ForegroundColor Red }
function Fetch($url, $file) {
  $dest = Join-Path $Cache $file
  if (-not (Test-Path $dest)) { Write-Host "Downloading $url"; Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing }
  return $dest
}

Step "Web UI (static export)"
Push-Location "$Root\frontend"
npm ci --no-audit --no-fund
npm run build:export
Pop-Location

Step "Python build environment"
$Venv = Join-Path $Cache "venv"
if (-not (Test-Path "$Venv\Scripts\python.exe")) { python -m venv $Venv }
& "$Venv\Scripts\python.exe" -m pip install --upgrade pip --quiet
& "$Venv\Scripts\pip.exe" install --quiet -r "$Root\backend\requirements.txt" pyinstaller pywebview

Step "TCE-ERP-Server.exe"
Remove-Item -Recurse -Force "$Build\server", "$Build\desktop" -ErrorAction SilentlyContinue
& "$Venv\Scripts\pyinstaller.exe" "$Root\packaging\windows\server.spec" --noconfirm --distpath $Build --workpath "$Cache\pyi-server"

Step "TCE ERP.exe (desktop app)"
& "$Venv\Scripts\pyinstaller.exe" "$Root\packaging\windows\desktop.spec" --noconfirm --distpath "$Build\desktop" --workpath "$Cache\pyi-desktop"

Step "Embedded PostgreSQL"
$PgZip = Fetch $PgZipUrl "postgresql-windows-x64-binaries.zip"
$PgTmp = Join-Path $Cache "pg-extract"
Remove-Item -Recurse -Force $PgTmp -ErrorAction SilentlyContinue
Expand-Archive -Path $PgZip -DestinationPath $PgTmp
$PgSrc = Get-ChildItem -Path $PgTmp -Directory | Select-Object -First 1
New-Item -ItemType Directory -Force -Path "$Build\server\pgsql" | Out-Null
foreach ($d in "bin", "lib", "share") { Copy-Item -Recurse -Force (Join-Path $PgSrc.FullName $d) "$Build\server\pgsql\$d" }
if (-not (Test-Path "$Build\server\pgsql\bin\pg_ctl.exe")) { throw "PostgreSQL binaries not found in $PgZipUrl - update -PgZipUrl" }
& "$Build\server\pgsql\bin\postgres.exe" --version

Step "Cloudflare Tunnel connector and Windows service wrapper"
Copy-Item -Force (Fetch $CloudflaredUrl "cloudflared.exe") "$Build\server\cloudflared.exe"
Copy-Item -Force (Fetch $WinswUrl "WinSW-x64.exe") "$Build\server\TCE-ERP-Service.exe"
Copy-Item -Force "$Root\packaging\windows\TCE-ERP-Service.xml" "$Build\server\TCE-ERP-Service.xml"

Step "Web UI into the server folder"
Remove-Item -Recurse -Force "$Build\server\ui" -ErrorAction SilentlyContinue
Copy-Item -Recurse -Force "$Root\frontend\out" "$Build\server\ui"

if (-not $SkipInstaller) {
  Step "Installer"
  $Iscc = @("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
  if (-not $Iscc) { throw "Inno Setup 6 not found. Install it from https://jrsoftware.org/isdl.php" }
  & $Iscc "/DAppVersion=$Version" "$Root\packaging\windows\tce-erp.iss"
  Write-Host "`nBuilt: $Root\dist\TCE-ERP-Setup-$Version.exe" -ForegroundColor Green
}
