# PyInstaller spec — "TCE ERP.exe" desktop app (single file, windowed).
# Build from the repository root:  pyinstaller packaging/windows/desktop.spec --noconfirm
ROOT = SPECPATH + "/../.."

a = Analysis(
    [ROOT + "/desktop/tce_erp_desktop.py"],
    datas=[(SPECPATH + "/tce.ico", ".")],
    hiddenimports=["webview.platforms.edgechromium", "clr_loader", "pythonnet"],
    excludes=["tkinter", "PIL", "numpy"],
)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, a.binaries, a.datas, [], name="TCE ERP", console=False, icon=SPECPATH + "/tce.ico")
