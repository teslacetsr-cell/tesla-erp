# PyInstaller spec — TCE-ERP-Server.exe (one folder; PostgreSQL, cloudflared and the web UI are added next to it).
# Build from the repository root:  pyinstaller packaging/windows/server.spec --noconfirm
from PyInstaller.utils.hooks import collect_submodules, collect_data_files

import sys

ROOT = SPECPATH + "/../.."
BACKEND = ROOT + "/backend"
sys.path.insert(0, BACKEND)  # so collect_submodules can find the `app` and `onprem` packages

hidden = (
    collect_submodules("app") + collect_submodules("onprem") + collect_submodules("uvicorn")
    + collect_submodules("sqlalchemy.dialects.postgresql") + collect_submodules("psycopg")
    + collect_submodules("psycopg_binary") + collect_submodules("alembic")
    + ["argon2", "email_validator", "multipart", "python_multipart", "openpyxl", "filetype", "httptools", "jwt"]
)

a = Analysis(
    [SPECPATH + "/server_entry.py"],
    pathex=[BACKEND],
    datas=[
        (BACKEND + "/migrations", "migrations"),
        (BACKEND + "/app/assets", "app/assets"),
        *collect_data_files("alembic"),
    ],
    hiddenimports=hidden,
    excludes=["boto3", "botocore", "moto", "pytest", "tkinter", "PIL"],  # cloud-only / dev-only
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name="TCE-ERP-Server", console=True,
          icon=SPECPATH + "/tce.ico", version=None)
coll = COLLECT(exe, a.binaries, a.datas, name="server")
