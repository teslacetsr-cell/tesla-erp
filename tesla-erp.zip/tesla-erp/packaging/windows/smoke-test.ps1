<#
  Smoke test of the built server on Windows (used by CI after build.ps1):
  first-run setup through the wizard API -> ERP serving -> admin sign-in -> backup to the "NAS" folder.
  Uses a scratch data folder and a local folder as the NAS, and cleans up the database service afterwards.
#>
$ErrorActionPreference = "Stop"
$Root = (Resolve-Path "$PSScriptRoot\..\..").Path
$Server = "$Root\build\server"
$Work = Join-Path $env:RUNNER_TEMP "tce-smoke"
if (-not $env:RUNNER_TEMP) { $Work = Join-Path $env:TEMP "tce-smoke" }
Remove-Item -Recurse -Force $Work -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path "$Work\home", "$Work\nas" | Out-Null

# The database runs as NETWORK SERVICE (like a real install): let it read the program and its data folder.
icacls $Server /grant "*S-1-5-20:(OI)(CI)RX" /T /Q | Out-Null
icacls $Work /grant "*S-1-5-20:(OI)(CI)F" /T /Q | Out-Null

$env:TCE_HOME = "$Work\home"
$proc = Start-Process -FilePath "$Server\TCE-ERP-Server.exe" -ArgumentList "run" -PassThru -NoNewWindow `
  -RedirectStandardOutput "$Work\out.log" -RedirectStandardError "$Work\err.log"
try {
  $base = "http://127.0.0.1:8080"
  for ($i = 0; $i -lt 30; $i++) { try { Invoke-WebRequest "$base/setup" -UseBasicParsing | Out-Null; break } catch { Start-Sleep 2 } }

  $check = Invoke-RestMethod "$base/setup/api/check-nas" -Method Post -ContentType "application/json" -Body (@{ nas_path = "$Work\nas" } | ConvertTo-Json)
  if (-not $check.ok) { throw "NAS check failed: $($check.message)" }

  $body = @{ company_name = "Tesla Consulting Engineers"; nas_path = "$Work\nas"; admin_email = "admin@teslace-demo.in"; admin_password = "Smoke#Test-2026" } | ConvertTo-Json
  Invoke-RestMethod "$base/setup/api/complete" -Method Post -ContentType "application/json" -Body $body | Out-Null
  for ($i = 0; $i -lt 150; $i++) {
    $p = Invoke-RestMethod "$base/setup/api/progress"
    if ($p.error) { throw "Setup failed: $($p.error)" }
    if ($p.finished) { break }
    Start-Sleep 2
  }
  if (-not $p.finished) { throw "Setup did not finish in time" }
  Write-Host "Setup finished: $($p.done -join ', ')"

  $ok = $false
  for ($i = 0; $i -lt 60; $i++) { try { Invoke-WebRequest "$base/healthz" -UseBasicParsing | Out-Null; $ok = $true; break } catch { Start-Sleep 2 } }
  if (-not $ok) { throw "ERP did not start after setup" }
  Start-Sleep 5
  $login = Invoke-RestMethod "$base/api/v1/auth/login" -Method Post -ContentType "application/json" -Body (@{ login = "admin"; password = "Smoke#Test-2026" } | ConvertTo-Json)
  $h = @{ Authorization = "Bearer $($login.data.access_token)" }
  $status = Invoke-RestMethod "$base/api/v1/system/status" -Headers $h
  if (-not $status.data.storage.ok) { throw "Storage not OK: $($status.data.storage.detail)" }
  if (-not $status.data.backup.ok) { throw "First backup missing" }
  $ui = Invoke-WebRequest "$base/login/" -UseBasicParsing
  if ($ui.StatusCode -ne 200) { throw "Web UI not served" }
  $dumps = Get-ChildItem "$Work\nas\backups\daily\*.dump"
  Write-Host "OK - signed in as admin, UI served, backups: $($dumps.Name -join ', ')" -ForegroundColor Green
}
finally {
  Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
  & sc.exe stop TCE-ERP-Database | Out-Null
  Start-Sleep 3
  & "$Server\pgsql\bin\pg_ctl.exe" unregister -N TCE-ERP-Database 2>$null
  Get-Content "$Work\home\logs\server.log" -ErrorAction SilentlyContinue | Select-Object -Last 40
}
