"""PyInstaller entry point for TCE-ERP-Server.exe."""
import multiprocessing
import sys

from onprem.server import main

if __name__ == "__main__":
    multiprocessing.freeze_support()
    sys.exit(main())
