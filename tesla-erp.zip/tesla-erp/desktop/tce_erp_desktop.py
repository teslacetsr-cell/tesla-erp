"""TCE ERP desktop app (Windows): the ERP in its own window, connected to the office server.

First launch (or when the server can't be reached) shows a small connection screen asking for the
server address, e.g. http://tce-erp:8080 — shown on the server's setup page — or, from outside the
office, the remote address such as https://erp.yourcompany.in.

    "TCE ERP.exe"            open the ERP
    "TCE ERP.exe" --server   change the server address
"""
import json
import os
import sys
import threading
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

APP_NAME = "TCE ERP"
DEFAULT_URL = "http://tce-erp:8080"


def data_dir() -> Path:
    base = os.environ.get("APPDATA") or str(Path.home() / ".config")
    d = Path(base) / APP_NAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def load_settings() -> dict:
    f = data_dir() / "desktop.json"
    try:
        return json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save_settings(s: dict) -> None:
    (data_dir() / "desktop.json").write_text(json.dumps(s, indent=2), encoding="utf-8")


def normalise(url: str) -> str:
    url = url.strip().rstrip("/")
    if url and "://" not in url:
        url = "http://" + url
    return url


def check_server(url: str, timeout: float = 4.0) -> tuple[bool, str]:
    """Is there a TCE ERP server at this address?"""
    try:
        with urllib.request.urlopen(f"{url}/healthz", timeout=timeout) as r:  # noqa: S310 - user-entered ERP URL
            ok = r.status == 200 and b'"ok"' in r.read(200)
            return (ok, "Connected.") if ok else (False, "That address answered, but it is not the TCE ERP server.")
    except urllib.error.URLError as exc:
        return False, f"Can't reach {url} ({getattr(exc, 'reason', exc)}). Check the address and that the server PC is on."
    except (OSError, ValueError) as exc:
        return False, f"Can't reach {url}: {exc}"


class Api:
    """Functions the connection screen calls from JavaScript."""

    def __init__(self):
        self.window = None

    def initial(self):
        s = load_settings()
        return {"url": s.get("server_url") or DEFAULT_URL, "recent": s.get("recent", [])}

    def test(self, url):
        url = normalise(url)
        ok, msg = check_server(url)
        return {"ok": ok, "message": msg, "url": url}

    def connect(self, url):
        url = normalise(url)
        ok, msg = check_server(url)
        if not ok:
            return {"ok": False, "message": msg}
        s = load_settings()
        s["server_url"] = url
        s["recent"] = [url] + [u for u in s.get("recent", []) if u != url][:4]
        save_settings(s)
        self.window.load_url(url + "/login/")
        return {"ok": True}


CONNECT_HTML = """<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;font-family:"Segoe UI",system-ui,sans-serif;background:#fff;color:#18181b;display:flex;min-height:100vh}
aside{background:#d90000;color:#fff;width:38%;padding:48px;display:flex;flex-direction:column;justify-content:center}
aside h1{font-size:30px;margin:0 0 8px}aside p{opacity:.85;margin:0}
main{flex:1;display:flex;align-items:center;justify-content:center;padding:32px}
form{width:100%;max-width:420px}h2{margin:0 0 6px;font-size:22px}.help{color:#6b6b75;font-size:14px;margin:0 0 18px}
label{font-size:13px;font-weight:600;display:block;margin-bottom:4px}
input{width:100%;box-sizing:border-box;height:40px;border:1px solid #dcdce0;border-radius:6px;padding:0 12px;font-size:15px}
input:focus{outline:2px solid #ffc5c5;border-color:#d90000}
button{margin-top:14px;background:#d90000;color:#fff;border:0;border-radius:6px;height:40px;padding:0 20px;font-size:15px;font-weight:600;cursor:pointer}
button.link{background:none;color:#b30000;padding:0;height:auto;margin:6px 10px 0 0;font-weight:400;font-size:13px;text-decoration:underline}
#msg{margin-top:12px;font-size:14px}.bad{color:#b30000}.ok{color:#047857}
</style></head><body>
<aside><h1>TCE ERP</h1><p>Tesla Consulting Engineers</p><p style="margin-top:24px">Empowering Safety, Protecting Lives.</p></aside>
<main><form id="f"><h2>Connect to the ERP server</h2>
<p class="help">In the office use the server address shown at setup, e.g. <b>http://tce-erp:8080</b>.
Away from the office use the remote address, e.g. <b>https://erp.yourcompany.in</b>.</p>
<label for="u">Server address</label><input id="u" autofocus>
<div id="recent"></div><button type="submit">Connect</button><div id="msg"></div></form></main>
<script>
const u=document.getElementById('u'),msg=document.getElementById('msg');
function ready(){pywebview.api.initial().then(d=>{u.value=d.url;
 document.getElementById('recent').innerHTML=d.recent.map(r=>`<button type="button" class="link" onclick="u.value='${r}'">${r}</button>`).join('');});}
window.addEventListener('pywebviewready',ready);
document.getElementById('f').onsubmit=e=>{e.preventDefault();msg.className='';msg.textContent='Connecting…';
 pywebview.api.connect(u.value).then(r=>{if(!r.ok){msg.className='bad';msg.textContent=r.message}});};
</script></body></html>"""


def main() -> int:
    try:
        import webview
    except ImportError:  # pragma: no cover - the packaged app always bundles pywebview
        url = load_settings().get("server_url") or DEFAULT_URL
        webbrowser.open(url)
        return 0

    force_choose = "--server" in sys.argv
    url = load_settings().get("server_url")
    reachable = False
    if url and not force_choose:
        reachable, _ = check_server(url, timeout=3)

    api = Api()
    webview.settings["ALLOW_DOWNLOADS"] = True
    webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True
    window = webview.create_window(
        APP_NAME,
        url=(url + "/dashboard/") if reachable else None,
        html=None if reachable else CONNECT_HTML,
        js_api=api,
        width=1400, height=880, min_size=(1024, 680), text_select=True,
    )
    api.window = window
    icon = Path(getattr(sys, "_MEIPASS", Path(__file__).parent)) / "tce.ico"
    try:
        # private_mode=False keeps the sign-in (refresh cookie) between launches, like a normal browser.
        webview.start(private_mode=False, storage_path=str(data_dir() / "webview"),
                      icon=str(icon) if icon.exists() else None)
    except Exception:  # noqa: BLE001 - e.g. WebView2 runtime missing: fall back to the default browser
        threading.Thread(target=webbrowser.open, args=((url or DEFAULT_URL) + "/login/",)).start()
    return 0


if __name__ == "__main__":
    sys.exit(main())
