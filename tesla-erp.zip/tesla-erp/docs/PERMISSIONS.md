# Default permission matrix

Generated from `backend/app/users/default_roles.py` by `scripts/permissions_doc.py` — the starting grants for the 11 roles in Spec §6.
After first setup, roles are data: an administrator changes them in **Administration → Roles** and every change is audited.
When an update adds a new module (for example CRM in Phase 2), its permissions are given to Administrator and to the standard roles as listed below. Grants an administrator changed earlier are never touched.

`✓` = allowed on all records · `own` = only records assigned to the user (customers: assigned salesperson; leads and enquiries: assigned salesperson or creator; site visits: the engineer, the creator, or the salesperson of the lead/enquiry) · blank = not allowed.

Actions follow Spec §6: create, read (View), update (Edit), delete, approve, export, print.

| Permission | Admin | Dir | Mgr | Sales | PM | Site | Pur | Store | Acc | HR | Emp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Approval rules — Create (`approval_policy.create`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Approval rules — View (`approval_policy.read`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Approval rules — Edit (`approval_policy.update`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Approval rules — Delete / deactivate (`approval_policy.delete`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Audit log — View (`audit.read`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Audit log — Export (`audit.export`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| BOQ — Create (`boq.create`) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |
| BOQ — View (`boq.read`) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |
| BOQ — Edit (`boq.update`) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |
| BOQ — Delete / deactivate (`boq.delete`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| BOQ — Export (`boq.export`) | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |
| BOQ — Print (`boq.print`) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |
| Business divisions — Create (`division.create`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Business divisions — View (`division.read`) | ✓ | ✓ | ✓ | ✓ | ✓ |   | ✓ |   | ✓ | ✓ |   |
| Business divisions — Edit (`division.update`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Business divisions — Delete / deactivate (`division.delete`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Company profile — View (`company.read`) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Company profile — Edit (`company.update`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Customers — Create (`customer.create`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |
| Customers — View (`customer.read`) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |
| Customers — Edit (`customer.update`) | ✓ | ✓ | ✓ | own | ✓ |   |   |   | ✓ |   |   |
| Customers — Delete / deactivate (`customer.delete`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Customers — Export (`customer.export`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   | ✓ |   |   |
| Customers — Print (`customer.print`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |
| Departments & designations — Create (`org_master.create`) | ✓ | ✓ |   |   |   |   |   |   |   | ✓ |   |
| Departments & designations — View (`org_master.read`) | ✓ | ✓ | ✓ |   |   |   |   |   |   | ✓ |   |
| Departments & designations — Edit (`org_master.update`) | ✓ | ✓ |   |   |   |   |   |   |   | ✓ |   |
| Departments & designations — Delete / deactivate (`org_master.delete`) | ✓ | ✓ |   |   |   |   |   |   |   | ✓ |   |
| Employees — Create (`employee.create`) | ✓ | ✓ |   |   |   |   |   |   |   | ✓ |   |
| Employees — View (`employee.read`) | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   | ✓ | ✓ |   |
| Employees — Edit (`employee.update`) | ✓ | ✓ |   |   |   |   |   |   |   | ✓ |   |
| Employees — Delete / deactivate (`employee.delete`) | ✓ | ✓ |   |   |   |   |   |   |   | ✓ |   |
| Employees — Export (`employee.export`) | ✓ | ✓ |   |   |   |   |   |   |   | ✓ |   |
| Enquiries — Create (`enquiry.create`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |
| Enquiries — View (`enquiry.read`) | ✓ | ✓ | ✓ | own | ✓ | own |   |   |   |   |   |
| Enquiries — Edit (`enquiry.update`) | ✓ | ✓ | ✓ | own | ✓ |   |   |   |   |   |   |
| Enquiries — Delete / deactivate (`enquiry.delete`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Enquiries — Export (`enquiry.export`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |
| GST / tax rates — Create (`tax_rate.create`) | ✓ | ✓ |   |   |   |   |   |   | ✓ |   |   |
| GST / tax rates — View (`tax_rate.read`) | ✓ | ✓ | ✓ | ✓ | ✓ |   | ✓ |   | ✓ |   |   |
| GST / tax rates — Edit (`tax_rate.update`) | ✓ | ✓ |   |   |   |   |   |   | ✓ |   |   |
| Goods received notes (GRN) — Create (`grn.create`) | ✓ | ✓ | ✓ |   | ✓ | ✓ |   | ✓ |   |   |   |
| Goods received notes (GRN) — View (`grn.read`) | ✓ | ✓ | ✓ |   | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |
| Goods received notes (GRN) — Export (`grn.export`) | ✓ | ✓ | ✓ |   |   |   |   | ✓ | ✓ |   |   |
| Goods received notes (GRN) — Print (`grn.print`) | ✓ | ✓ | ✓ |   | ✓ |   | ✓ | ✓ | ✓ |   |   |
| Items, categories, brands & units — Create (`item.create`) | ✓ | ✓ | ✓ |   |   |   | ✓ | ✓ |   |   |   |
| Items, categories, brands & units — View (`item.read`) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |
| Items, categories, brands & units — Edit (`item.update`) | ✓ | ✓ | ✓ |   |   |   | ✓ | ✓ |   |   |   |
| Items, categories, brands & units — Delete / deactivate (`item.delete`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Items, categories, brands & units — Export (`item.export`) | ✓ | ✓ | ✓ |   |   |   | ✓ |   |   |   |   |
| Leads — Create (`lead.create`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |
| Leads — View (`lead.read`) | ✓ | ✓ | ✓ | own | ✓ |   |   |   |   |   |   |
| Leads — Edit (`lead.update`) | ✓ | ✓ | ✓ | own |   |   |   |   |   |   |   |
| Leads — Delete / deactivate (`lead.delete`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Leads — Export (`lead.export`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |
| Material requests (approve = process: reject or close) — Create (`material_request.create`) | ✓ | ✓ | ✓ |   | ✓ | ✓ |   |   |   |   |   |
| Material requests (approve = process: reject or close) — View (`material_request.read`) | ✓ | ✓ | ✓ |   | ✓ | own | ✓ | ✓ |   |   |   |
| Material requests (approve = process: reject or close) — Edit (`material_request.update`) | ✓ | ✓ | ✓ |   | own | own |   |   |   |   |   |
| Material requests (approve = process: reject or close) — Delete / deactivate (`material_request.delete`) | ✓ | ✓ | ✓ |   | own | own |   |   |   |   |   |
| Material requests (approve = process: reject or close) — Approve (`material_request.approve`) | ✓ | ✓ | ✓ |   |   |   | ✓ | ✓ |   |   |   |
| Project site work (tasks, issues, site reports, installation) — Create (`site_work.create`) | ✓ | ✓ | ✓ |   | own | own |   |   |   |   |   |
| Project site work (tasks, issues, site reports, installation) — View (`site_work.read`) | ✓ | ✓ | ✓ |   | own | own |   |   |   |   |   |
| Project site work (tasks, issues, site reports, installation) — Edit (`site_work.update`) | ✓ | ✓ | ✓ |   | own | own |   |   |   |   |   |
| Project site work (tasks, issues, site reports, installation) — Delete / deactivate (`site_work.delete`) | ✓ | ✓ | ✓ |   | own |   |   |   |   |   |   |
| Projects — Create (`project.create`) | ✓ | ✓ | ✓ |   | ✓ |   |   |   |   |   |   |
| Projects — View (`project.read`) | ✓ | ✓ | ✓ |   | ✓ | own | ✓ | ✓ | ✓ |   |   |
| Projects — Edit (`project.update`) | ✓ | ✓ | ✓ |   | own |   |   |   |   |   |   |
| Projects — Delete / deactivate (`project.delete`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Projects — Export (`project.export`) | ✓ | ✓ | ✓ |   | ✓ |   |   |   | ✓ |   |   |
| Projects — Print (`project.print`) | ✓ | ✓ | ✓ |   | ✓ |   |   |   | ✓ |   |   |
| Purchase orders — Create (`purchase_order.create`) | ✓ | ✓ | ✓ |   |   |   | ✓ |   |   |   |   |
| Purchase orders — View (`purchase_order.read`) | ✓ | ✓ | ✓ |   | ✓ |   | ✓ | ✓ | ✓ |   |   |
| Purchase orders — Edit (`purchase_order.update`) | ✓ | ✓ | ✓ |   |   |   | ✓ |   |   |   |   |
| Purchase orders — Delete / deactivate (`purchase_order.delete`) | ✓ | ✓ | ✓ |   |   |   | ✓ |   |   |   |   |
| Purchase orders — Approve (`purchase_order.approve`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Purchase orders — Export (`purchase_order.export`) | ✓ | ✓ | ✓ |   |   |   | ✓ |   | ✓ |   |   |
| Purchase orders — Print (`purchase_order.print`) | ✓ | ✓ | ✓ |   | ✓ |   | ✓ | ✓ | ✓ |   |   |
| Purchase requests — Create (`purchase_request.create`) | ✓ | ✓ | ✓ |   |   |   | ✓ | ✓ |   |   |   |
| Purchase requests — View (`purchase_request.read`) | ✓ | ✓ | ✓ |   | ✓ |   | ✓ | ✓ | ✓ |   |   |
| Purchase requests — Edit (`purchase_request.update`) | ✓ | ✓ | ✓ |   |   |   | ✓ | ✓ |   |   |   |
| Purchase requests — Delete / deactivate (`purchase_request.delete`) | ✓ | ✓ | ✓ |   |   |   | ✓ | ✓ |   |   |   |
| Purchase requests — Approve (`purchase_request.approve`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Quotation terms library — Create (`quotation_term.create`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Quotation terms library — View (`quotation_term.read`) | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |
| Quotation terms library — Edit (`quotation_term.update`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Quotation terms library — Delete / deactivate (`quotation_term.delete`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Quotations — Create (`quotation.create`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |
| Quotations — View (`quotation.read`) | ✓ | ✓ | ✓ | own | ✓ |   |   |   | ✓ |   |   |
| Quotations — Edit (`quotation.update`) | ✓ | ✓ | ✓ | own |   |   |   |   |   |   |   |
| Quotations — Delete / deactivate (`quotation.delete`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Quotations — Approve (`quotation.approve`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Quotations — Export (`quotation.export`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   | ✓ |   |   |
| Quotations — Print (`quotation.print`) | ✓ | ✓ | ✓ | own | ✓ |   |   |   | ✓ |   |   |
| Roles & permissions — Create (`role.create`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Roles & permissions — View (`role.read`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Roles & permissions — Edit (`role.update`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Roles & permissions — Delete / deactivate (`role.delete`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Sales order prices & terms (change after confirmation) — Edit (`sales_order_commercial.update`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Sales orders — Create (`sales_order.create`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |
| Sales orders — View (`sales_order.read`) | ✓ | ✓ | ✓ | own | ✓ |   |   |   | ✓ |   |   |
| Sales orders — Edit (`sales_order.update`) | ✓ | ✓ | ✓ | own |   |   |   |   |   |   |   |
| Sales orders — Delete / deactivate (`sales_order.delete`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Sales orders — Export (`sales_order.export`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   | ✓ |   |   |
| Sales orders — Print (`sales_order.print`) | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   | ✓ |   |   |
| Settings & numbering — View (`settings.read`) | ✓ | ✓ |   |   |   |   |   |   | ✓ |   |   |
| Settings & numbering — Edit (`settings.update`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Site visits — Create (`site_visit.create`) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |
| Site visits — View (`site_visit.read`) | ✓ | ✓ | ✓ | own | ✓ | own |   |   |   |   |   |
| Site visits — Edit (`site_visit.update`) | ✓ | ✓ | ✓ | own | ✓ | own |   |   |   |   |   |
| Site visits — Delete / deactivate (`site_visit.delete`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Site visits — Print (`site_visit.print`) | ✓ | ✓ | ✓ | own | ✓ | own |   |   |   |   |   |
| Stock adjustments & opening stock — Create (`stock_adjustment.create`) | ✓ | ✓ | ✓ |   |   |   |   | ✓ |   |   |   |
| Stock adjustments & opening stock — View (`stock_adjustment.read`) | ✓ | ✓ | ✓ |   |   |   |   | ✓ | ✓ |   |   |
| Stock adjustments & opening stock — Edit (`stock_adjustment.update`) | ✓ | ✓ | ✓ |   |   |   |   | ✓ |   |   |   |
| Stock adjustments & opening stock — Approve (`stock_adjustment.approve`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Stock balances, stock ledger & serial numbers — View (`stock.read`) | ✓ | ✓ | ✓ |   | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |
| Stock balances, stock ledger & serial numbers — Export (`stock.export`) | ✓ | ✓ | ✓ |   |   |   | ✓ | ✓ | ✓ |   |   |
| Stock transfers between warehouses and site stores — Create (`stock_transfer.create`) | ✓ | ✓ | ✓ |   | ✓ |   |   | ✓ |   |   |   |
| Stock transfers between warehouses and site stores — View (`stock_transfer.read`) | ✓ | ✓ | ✓ |   | ✓ | ✓ |   | ✓ | ✓ |   |   |
| Stock transfers between warehouses and site stores — Edit (`stock_transfer.update`) | ✓ | ✓ | ✓ |   | ✓ |   |   | ✓ |   |   |   |
| Supplier bank details (full account numbers) — View (`supplier_bank.read`) | ✓ | ✓ |   |   |   |   | ✓ |   | ✓ |   |   |
| Supplier bank details (full account numbers) — Edit (`supplier_bank.update`) | ✓ |   |   |   |   |   |   |   | ✓ |   |   |
| Suppliers — Create (`supplier.create`) | ✓ | ✓ | ✓ |   |   |   | ✓ |   |   |   |   |
| Suppliers — View (`supplier.read`) | ✓ | ✓ | ✓ |   | ✓ |   | ✓ | ✓ | ✓ |   |   |
| Suppliers — Edit (`supplier.update`) | ✓ | ✓ | ✓ |   |   |   | ✓ |   | ✓ |   |   |
| Suppliers — Delete / deactivate (`supplier.delete`) | ✓ | ✓ |   |   |   |   | ✓ |   |   |   |   |
| Suppliers — Export (`supplier.export`) | ✓ | ✓ | ✓ |   |   |   | ✓ |   | ✓ |   |   |
| Suppliers — Print (`supplier.print`) | ✓ | ✓ |   |   |   |   | ✓ |   |   |   |   |
| Users — Create (`user.create`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Users — View (`user.read`) | ✓ | ✓ | ✓ |   |   |   |   |   |   | ✓ |   |
| Users — Edit (`user.update`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Users — Delete / deactivate (`user.delete`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Users — Export (`user.export`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Warehouses — Create (`warehouse.create`) | ✓ | ✓ |   |   |   |   |   | ✓ |   |   |   |
| Warehouses — View (`warehouse.read`) | ✓ | ✓ | ✓ |   | ✓ | ✓ | ✓ | ✓ |   |   |   |
| Warehouses — Edit (`warehouse.update`) | ✓ | ✓ |   |   |   |   |   | ✓ |   |   |   |
| Warehouses — Delete / deactivate (`warehouse.delete`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |

## Role descriptions

- **Administrator** (`ADMIN`) — Full access, including users, roles, settings and the audit log.
- **Director** (`DIRECTOR`) — Sees everything; approves; manages masters. No user administration.
- **Manager** (`MANAGER`) — Manages masters and teams; approves within limits.
- **Sales** (`SALES`) — Creates customers; can edit only customers assigned to them.
- **Project Manager** (`PROJECT_MANAGER`) — Runs projects; reads customers, items and suppliers.
- **Site Engineer** (`SITE_ENGINEER`) — Field work: site visits, project tasks and daily site reports on their projects.
- **Purchase** (`PURCHASE`) — Suppliers and items; turns material requests into purchase requests and purchase orders.
- **Store** (`STORE`) — Receives goods (GRN), keeps stock, transfers to site stores, raises stock adjustments.
- **Accounts** (`ACCOUNTS`) — Billing, receivables, payables, GST.
- **HR** (`HR`) — Employees, departments, designations; attendance and leave (from Phase 8).
- **Employee** (`EMPLOYEE`) — Every staff member: own expenses, leave and attendance (later phases).
