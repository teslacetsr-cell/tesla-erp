# Default permission matrix

Generated from `backend/app/users/default_roles.py` by `scripts/permissions_doc.py` — the starting grants for the 11 roles in Spec §6.
After first setup, roles are data: an administrator changes them in **Administration → Roles** and every change is audited.
When an update adds a new module (for example CRM in Phase 2), its permissions are given to Administrator and to the standard roles as listed below. Grants an administrator changed earlier are never touched.

`✓` = allowed on all records · `own` = only records assigned to the user (customers: assigned salesperson; leads and enquiries: assigned salesperson or creator; site visits: the engineer, the creator, or the salesperson of the lead/enquiry) · blank = not allowed.

Actions follow Spec §6: create, read (View), update (Edit), delete, approve, export, print.

| Permission | Admin | Dir | Mgr | Sales | PM | Site | Pur | Store | Acc | HR | Emp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Audit log — View (`audit.read`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Audit log — Export (`audit.export`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Business divisions — Create (`division.create`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Business divisions — View (`division.read`) | ✓ | ✓ | ✓ | ✓ | ✓ |   | ✓ |   | ✓ | ✓ |   |
| Business divisions — Edit (`division.update`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Business divisions — Delete / deactivate (`division.delete`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Company profile — View (`company.read`) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Company profile — Edit (`company.update`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Customers — Create (`customer.create`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |
| Customers — View (`customer.read`) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |
| Customers — Edit (`customer.update`) | ✓ | ✓ | ✓ | own | ✓ |   |   |   | ✓ |   |   |
| Customers — Delete / deactivate (`customer.delete`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Customers — Export (`customer.export`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   | ✓ |   |   |
| Customers — Print (`customer.print`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |
| Departments & designations — Create (`org_master.create`) | ✓ | ✓ |   |   |   |   |   |   |   | ✓ |   |
| Departments & designations — View (`org_master.read`) | ✓ | ✓ | ✓ |   |   |   |   |   |   | ✓ |   |
| Departments & designations — Edit (`org_master.update`) | ✓ | ✓ |   |   |   |   |   |   |   | ✓ |   |
| Departments & designations — Delete / deactivate (`org_master.delete`) | ✓ | ✓ |   |   |   |   |   |   |   | ✓ |   |
| Employees — Create (`employee.create`) | ✓ | ✓ |   |   |   |   |   |   |   | ✓ |   |
| Employees — View (`employee.read`) | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   | ✓ | ✓ |   |
| Employees — Edit (`employee.update`) | ✓ | ✓ |   |   |   |   |   |   |   | ✓ |   |
| Employees — Delete / deactivate (`employee.delete`) | ✓ | ✓ |   |   |   |   |   |   |   | ✓ |   |
| Employees — Export (`employee.export`) | ✓ | ✓ |   |   |   |   |   |   |   | ✓ |   |
| Enquiries — Create (`enquiry.create`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |
| Enquiries — View (`enquiry.read`) | ✓ | ✓ | ✓ | own | ✓ | own |   |   |   |   |   |
| Enquiries — Edit (`enquiry.update`) | ✓ | ✓ | ✓ | own | ✓ |   |   |   |   |   |   |
| Enquiries — Delete / deactivate (`enquiry.delete`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Enquiries — Export (`enquiry.export`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |
| GST / tax rates — Create (`tax_rate.create`) | ✓ | ✓ |   |   |   |   |   |   | ✓ |   |   |
| GST / tax rates — View (`tax_rate.read`) | ✓ | ✓ | ✓ | ✓ | ✓ |   | ✓ |   | ✓ |   |   |
| GST / tax rates — Edit (`tax_rate.update`) | ✓ | ✓ |   |   |   |   |   |   | ✓ |   |   |
| Items, categories, brands & units — Create (`item.create`) | ✓ | ✓ | ✓ |   |   |   | ✓ | ✓ |   |   |   |
| Items, categories, brands & units — View (`item.read`) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |
| Items, categories, brands & units — Edit (`item.update`) | ✓ | ✓ | ✓ |   |   |   | ✓ | ✓ |   |   |   |
| Items, categories, brands & units — Delete / deactivate (`item.delete`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Items, categories, brands & units — Export (`item.export`) | ✓ | ✓ | ✓ |   |   |   | ✓ |   |   |   |   |
| Leads — Create (`lead.create`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |
| Leads — View (`lead.read`) | ✓ | ✓ | ✓ | own | ✓ |   |   |   |   |   |   |
| Leads — Edit (`lead.update`) | ✓ | ✓ | ✓ | own |   |   |   |   |   |   |   |
| Leads — Delete / deactivate (`lead.delete`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Leads — Export (`lead.export`) | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |
| Roles & permissions — Create (`role.create`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Roles & permissions — View (`role.read`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Roles & permissions — Edit (`role.update`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Roles & permissions — Delete / deactivate (`role.delete`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Settings & numbering — View (`settings.read`) | ✓ | ✓ |   |   |   |   |   |   | ✓ |   |   |
| Settings & numbering — Edit (`settings.update`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Site visits — Create (`site_visit.create`) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |
| Site visits — View (`site_visit.read`) | ✓ | ✓ | ✓ | own | ✓ | own |   |   |   |   |   |
| Site visits — Edit (`site_visit.update`) | ✓ | ✓ | ✓ | own | ✓ | own |   |   |   |   |   |
| Site visits — Delete / deactivate (`site_visit.delete`) | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Site visits — Print (`site_visit.print`) | ✓ | ✓ | ✓ | own | ✓ | own |   |   |   |   |   |
| Supplier bank details (full account numbers) — View (`supplier_bank.read`) | ✓ | ✓ |   |   |   |   | ✓ |   | ✓ |   |   |
| Supplier bank details (full account numbers) — Edit (`supplier_bank.update`) | ✓ |   |   |   |   |   |   |   | ✓ |   |   |
| Suppliers — Create (`supplier.create`) | ✓ | ✓ | ✓ |   |   |   | ✓ |   |   |   |   |
| Suppliers — View (`supplier.read`) | ✓ | ✓ | ✓ |   | ✓ |   | ✓ | ✓ | ✓ |   |   |
| Suppliers — Edit (`supplier.update`) | ✓ | ✓ | ✓ |   |   |   | ✓ |   | ✓ |   |   |
| Suppliers — Delete / deactivate (`supplier.delete`) | ✓ | ✓ |   |   |   |   | ✓ |   |   |   |   |
| Suppliers — Export (`supplier.export`) | ✓ | ✓ | ✓ |   |   |   | ✓ |   | ✓ |   |   |
| Suppliers — Print (`supplier.print`) | ✓ | ✓ |   |   |   |   | ✓ |   |   |   |   |
| Users — Create (`user.create`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Users — View (`user.read`) | ✓ | ✓ | ✓ |   |   |   |   |   |   | ✓ |   |
| Users — Edit (`user.update`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Users — Delete / deactivate (`user.delete`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Users — Export (`user.export`) | ✓ |   |   |   |   |   |   |   |   |   |   |
| Warehouses — Create (`warehouse.create`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Warehouses — View (`warehouse.read`) | ✓ | ✓ | ✓ |   | ✓ | ✓ | ✓ | ✓ |   |   |   |
| Warehouses — Edit (`warehouse.update`) | ✓ | ✓ |   |   |   |   |   | ✓ |   |   |   |
| Warehouses — Delete / deactivate (`warehouse.delete`) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |

## Role descriptions

- **Administrator** (`ADMIN`) — Full access, including users, roles, settings and the audit log.
- **Director** (`DIRECTOR`) — Sees everything; approves; manages masters. No user administration.
- **Manager** (`MANAGER`) — Manages masters and teams; approves within limits.
- **Sales** (`SALES`) — Creates customers; can edit only customers assigned to them.
- **Project Manager** (`PROJECT_MANAGER`) — Runs projects; reads customers, items and suppliers.
- **Site Engineer** (`SITE_ENGINEER`) — Field work: site visits, tasks, material requests (from Phase 2).
- **Purchase** (`PURCHASE`) — Maintains suppliers and items; raises purchase orders (from Phase 5).
- **Store** (`STORE`) — Stock, receipts and issues (from Phase 5).
- **Accounts** (`ACCOUNTS`) — Billing, receivables, payables, GST.
- **HR** (`HR`) — Employees, departments, designations; attendance and leave (from Phase 8).
- **Employee** (`EMPLOYEE`) — Every staff member: own expenses, leave and attendance (later phases).
