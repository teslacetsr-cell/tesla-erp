# Changes

## 0.11.1 — 21 Nov 2026

- **Incentives start 3 months after joining.** An employee earns incentives only on bills paid in full, subsidy milestones and monthly rules dated on or after their date of joining + 3 months.
  - Until then, they are left out of *All in role* shares; the others in the role share as before.
  - If they are the one person named on a project, that amount is not paid.
  - Employees without a date of joining in HR count as eligible and are marked *no joining date* in Setup, so fill in joining dates.
- **Setting:** *Incentives → Setup → Eligibility* changes the number of months; 0 means from day one.
- **Display:** *Setup*, the project's *Incentive* tab and *My incentive* show "earns from <date>" for anyone still in the qualifying period.
- **Fix:** when the one person named on a project is no longer active in the role, the amount now goes to the role's active members, as described in `docs/INCENTIVES.md`. Before, it still went to the inactive person.
- **Upgrade:** no database change. Months already approved and locked don't change; draft months recalculate with the new rule.

## 0.11.0 — 21 Nov 2026

### Incentives & performance (new menu: *Incentives*)
Details are in `docs/INCENTIVES.md`.
- **Works from your existing records.** Bills are your sales invoices; a bill counts as paid when receipts (including TDS) and credit notes cover the full amount with GST. The paid date is the date of the receipt that completed it. Amounts are always before GST. Nothing is entered twice.
- **Dashboard:** billed, collected, incentives and welfare fund for the month; outstanding bills; solar subsidy pending; split by project category and by employee.
- **Payment follow-up:** bills not yet paid in full, oldest first, with bills over 60 days highlighted. Buttons: *Enter receipt*, *Paid in full* (confirm by hand until Accounts enters the receipt), *Part paid*, *Not yet*. Solar projects waiting for subsidy have a *Yes, done* button.
- **Project → Incentive tab:** category, Govt client, from tender, EI & KSEB in scope, subsidy done, and who earns on the project per role (*All in role* shared equally, one person, or *Nobody*). Govt and Tender are filled from the client type and the enquiry/lead source until you save.
- **Register:** every employee's lines with base, rate, split and amount. Includes the *All account statements proper* tick (for the accountant), **Approve & lock** (saves a snapshot), **Unlock** (Administrator only), **Mark paid** with a date, Excel / CSV export and a printable PDF statement per employee.
- **Performance:** monthly 1–5 ratings for Quality, Timeliness, Follow-up, Teamwork and Learning, with the average and band beside each person's projects and incentive.
- **Monthly reports:** billing, collections, incentives and welfare fund across the financial year (April–March), by category.
- **Setup:** roles, the people in each role, rules (categories, Govt / Tender / EI & KSEB conditions, when earned, % or fixed ₹), project categories, welfare fund % and **Restore standard rates**. The standard scheme is installed automatically.
- **My incentive** (everyone): your own statement and the year so far. You can't see anyone else's.
- **Permissions:** Administrator and Director change rates, approve, lock and mark paid. Manager and Accounts view and export, and do payment follow-up; Manager also rates performance. Only the Administrator can unlock a month.
- **Upgrade:** migration `0012a` adds ten new tables and changes no existing data. The standard categories, roles and rates are created on deploy. Then assign people to roles in *Incentives → Setup* and set the category on each project.

## 0.10.2 — 21 Nov 2026

- **Travel expense claims need a bill or photo too.** Every category booked to *Travelling & Conveyance* — travel tickets, local conveyance / fuel, food & lodging — now needs a bill, ticket or photo attached before the claim can be submitted. Before this, local conveyance / fuel could be submitted without one. Admins can still change this per category in *Masters → Expense categories*.
- **Take photo:** the claim's *Bill / receipt* tab has a **Take photo** button, which opens the phone camera directly.
- **Upgrade:** migration `0011a` changes the setting on existing categories. Claims already submitted are not affected; drafts need the photo when they are submitted.

## 0.10.0 — 8 Oct 2026

### Phase 10 — Reports, dashboards, notifications, alerts, search
Details are in `docs/PHASE10_REPORT.md`.
- **Reports:** about 35 registers and reports with common filters and Excel and PDF export. Each one shows only what the role may see.
- **Dashboards:** a management dashboard and role dashboards.
- **Notifications:** each person chooses in-app or email, per kind of event. A daily summary email is optional. Email is sent by the worker. WhatsApp/SMS can be plugged in later.
- **Daily alerts:** overdue invoices, bills due, late projects, missing site reports, low stock, overdue tasks, approvals waiting, late POs and overdue vendor quotations. Each alert can be switched on or off and has its own limits.
- **Global search** (Ctrl K) across customers, leads, enquiries, quotations, orders, projects, invoices, POs, items and more.
- **Documents** (new menu): every file you may open, from any record, with search and filters. Company-wide papers (certificates, registrations, agreements) are uploaded here.

### Phase 11 — Tally connector
Details are in `docs/PHASE11_REPORT.md`, with installation steps in `tally-connector/README.md`.
- *Finance → Tally Sync* holds the queue, errors and retry, ledger names, balance checks, connector keys and settings.
- A Windows connector program carries entries to TallyPrime on the office PC. It only calls out, so Tally is never opened to the internet.

### Purchase — quotations from several vendors (RFQ)
- **Creating an RFQ:** from a purchase request or material request, choose *Request quotations* and pick several suppliers.
- **Sending it:** print or send the **RFQ PDF** for each supplier or for all. Each supplier also gets an **Excel reply form** to fill in.
- **Recording quotations:** upload the filled Excel, type the rates, or use **Read with AI**. AI reads a PDF, photo or Excel quotation and fills the rates for you to check; nothing is saved until you confirm. It needs `ANTHROPIC_API_KEY`; without it the button explains that.
- **Comparison sheet:**
  - shows the lowest price (L1) per line and overall, with freight and terms, against the last purchase price;
  - exports to Excel and PDF;
  - can give an AI summary.
- **Ordering:** choose a supplier per line (a reason is asked if it isn't L1). *Create purchase orders* makes one draft PO per chosen supplier.

### Team chat
- Covers a company-wide *Tesla Team* channel, groups, one-to-one messages, and a team room for each project.
- You can send photos (the camera on phones) and files: PDF, Office, drawings.
- Other features: @mentions (with a notification), unread counts, reply, edit within 15 minutes, delete, and search.
- Only members can read a group, direct message or attachment. Administrators and Directors can remove messages.

### Leads save new customers
- A lead entered for a new company now creates the **customer** straight away. It gets the next code (CUS…) and is marked *prospect*.
- The lead's contact, address, state and GSTIN are saved to the customer, so they're there for enquiries, quotations and orders later.
- If the GSTIN already exists, the lead links that customer instead. Look-alike names are offered for linking before a duplicate is made.
- Existing open leads were given their customers on upgrade.

### Employee-wise tasks
- *Projects → Tasks → By employee* (Administrators, Directors, Managers) shows, for each person:
  - open, overdue, blocked and finished tasks;
  - the task list, with filters and Excel export.
- It also has a dashboard card.

### Fixes
- The notification catalogue includes chat mentions and Tally failures, so people can switch them on or off.

### Upgrade
- **Migrations:** `0009b`, `0010n`, `0010l`, `0010t` and `0010c` add new tables and columns and change no existing data. `deploy.sh` runs them.
- **Optional settings** for email and AI. Add them on the server with `./set-env.sh` (`docs/DEPLOY_VPS.md`).

## 0.9.1 — 7 Oct 2026 (fixes from a full test of every screen)

Every screen was opened as each of the 11 roles. Every create, edit and approval flow was run in the browser, from masters through CRM, sales, projects, purchase, stock, finance and HR. These are the problems found and fixed.

### Fixed

**Creating a customer failed with "A record with the same unique value already exists."**
- **Why:** the automatic code (CUS00012 …) landed on a code that had been typed by hand or imported from Excel.
- **Now:** automatic customer, supplier and item codes skip codes that are already taken. Employee codes already did.

**Picking an existing customer did nothing.** This affected new lead, enquiry, site visit, BOQ, quotation, project, direct invoice, receipt, and lead → enquiry.
- **Why:** clicking a name in the search list selected the customer and immediately cleared it again.
- **Now:** the customer is selected.

**Change prices & terms on a sales order** failed once the order had an invoice.
- **Now:** order lines are updated in place, so invoices keep pointing at the right line.
- It is refused, with the reason, when you:
  - reduce a line below what is already on an invoice (issued or draft);
  - remove a line that is on an invoice.
- Lines keep their numbers. New lines are added at the end.

**Masters and address dialogs**
- **Default choice:** a dropdown showing a value (e.g. ledger type *Expense*, term category *Payment*, address type *Shipping*) was saved as empty. It is now saved.
- **Codes in capitals:** codes typed in small letters are saved in capitals ("lc1" → "LC1") instead of being refused.
- **Blank display order:** a quotation term saves with order 100.
- **Cancelled input:** reopening a dialog after *Cancel* no longer shows the text typed before.

**Error messages**
- Validation errors name the field and say what is wrong, e.g. "Please check — Special discount: Enter a number (digits only, no commas)."
- Duplicates say what is duplicated, e.g. "Another customer already has this customer code."

**Invoices**
- A tax invoice can no longer be issued for a customer with no state. Without one, CGST/SGST or IGST can't be decided.
- The invoice form warns about this before you issue.

**Expense claims:** staff without access to Projects (Sales, HR, Employee) can now choose the project on a site expense.

**Notifications:** leave approvals show the number of days, not "₹0.50 before GST". Expense claims and material issues no longer say "before GST".

**Approvals inbox:** each card links to its own document ("Open expense claim", "Open leave request") instead of "Open the quotation".

**Screens no longer request data the role can't see:**
- Users page, for Managers;
- Employees, for Sales;
- an item's page, for Site engineers;
- Stock, for Accounts.

**BOQ:** *Reopen as draft* and *Copy* show an error instead of failing silently.

### Upgrade
There are no database changes. Update as usual (`deploy.sh`). **Settings → System** shows 0.9.1.
