# Changes

## 0.9.1 — 7 Oct 2026 (fixes from a full test of every screen)

Every screen was opened as each of the 11 roles. Every create, edit and approval flow was run in the browser, from masters through CRM, sales, projects, purchase, stock, finance and HR. These are the problems found and fixed.

### Fixed

**Creating a customer failed with "A record with the same unique value already exists."**
- **Why:** the automatic code (CUS00012 …) landed on a code that had been typed by hand or imported from Excel.
- **Now:** automatic customer, supplier and item codes skip codes that are already taken. Employee codes already did.

**Picking an existing customer did nothing.** This affected new lead, enquiry, site visit, BOQ, quotation, project, direct invoice, receipt, and lead → enquiry.
- **Why:** clicking a name in the search list selected the customer and immediately cleared it again.
- **Now:** the customer is selected.

**Change prices & terms on a sales order** failed once the order had an invoice.
- **Now:** order lines are updated in place, so invoices keep pointing at the right line.
- It is refused, with the reason, when you:
  - reduce a line below what is already on an invoice (issued or draft);
  - remove a line that is on an invoice.
- Lines keep their numbers. New lines are added at the end.

**Masters and address dialogs**
- **Default choice:** a dropdown showing a value (e.g. ledger type *Expense*, term category *Payment*, address type *Shipping*) was saved as empty. It is now saved.
- **Codes in capitals:** codes typed in small letters are saved in capitals ("lc1" → "LC1") instead of being refused.
- **Blank display order:** a quotation term saves with order 100.
- **Cancelled input:** reopening a dialog after *Cancel* no longer shows the text typed before.

**Error messages**
- Validation errors name the field and say what is wrong, e.g. "Please check — Special discount: Enter a number (digits only, no commas)."
- Duplicates say what is duplicated, e.g. "Another customer already has this customer code."

**Invoices**
- A tax invoice can no longer be issued for a customer with no state. Without one, CGST/SGST or IGST can't be decided.
- The invoice form warns about this before you issue.

**Expense claims:** staff without access to Projects (Sales, HR, Employee) can now choose the project on a site expense.

**Notifications:** leave approvals show the number of days, not "₹0.50 before GST". Expense claims and material issues no longer say "before GST".

**Approvals inbox:** each card links to its own document ("Open expense claim", "Open leave request") instead of "Open the quotation".

**Screens no longer request data the role can't see:**
- Users page, for Managers;
- Employees, for Sales;
- an item's page, for Site engineers;
- Stock, for Accounts.

**BOQ:** *Reopen as draft* and *Copy* show an error instead of failing silently.

### Upgrade
There are no database changes. Update as usual (`deploy.sh`). **Settings → System** shows 0.9.1.
