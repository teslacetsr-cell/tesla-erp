# Tesla Consulting Engineers ERP — Architecture Assessment & Target Architecture

| | |
|---|---|
| Document | `docs/ERP_ARCHITECTURE.md` |
| Status | **Approved 25 Sep 2026** — Phase 1 implemented |
| Prepared | 25 Sep 2026 |
| Source | ERP Software — Master Development Specification (51 sections) |

---

## 1. Assessment of the current state (Spec §49, steps 1–9)

| # | Item | Finding |
|---|---|---|
| 1 | Repository | **None exists.** The workspace contained no source code, no git repository and no prior ERP project. |
| 2 | Current architecture | None — this is a greenfield build. |
| 3 | Existing database | None. No schema, migrations or data dumps were provided. |
| 4 | Existing authentication | None. |
| 5 | Existing document storage | None. |
| 6 | Deployment method | None. No hosting, CI/CD or cloud account details provided. |
| 7 | Existing features | None in code. Business processes presumably run today on Tally / Excel / email (to be confirmed — see §15 Q1). |
| 8 | Missing features | Everything in the specification. |
| 9 | Technical risks | See §14. The largest are: GST invoice-numbering compliance, financial-year handling, inventory valuation method, labour-cost capture, and data migration from current tools. |

**Consequence:** there is no existing functionality to protect (Spec §48 rule 4), which frees us to establish correct foundations — money types, ledgers, audit, numbering, storage — before any business module exists. That is the main advantage of starting now and the main thing this document locks down.

Tooling available in the build environment: Python 3.11, Node 22, PostgreSQL 16 client, Docker.

---

## 2. Architecture at a glance

```mermaid
flowchart LR
    subgraph Client
      B[Browser / Mobile browser]
    end
    subgraph Edge
      ALB[Load balancer + TLS<br/>HTTPS only]
    end
    subgraph App
      FE[Next.js frontend<br/>React + TS + Tailwind]
      API[FastAPI backend<br/>REST /api/*]
      WK[Background worker<br/>PDFs · emails · reminders]
    end
    subgraph Data
      PG[(PostgreSQL 16<br/>system of record)]
      S3[(S3-compatible storage<br/>documents & PDFs, versioned)]
    end
    B --> ALB
    ALB -->|/| FE
    ALB -->|/api| API
    FE -->|server-side calls| API
    API --> PG
    API --> S3
    WK --> PG
    WK --> S3
    WK -->|SMTP / SES| MAIL[Email]
```

Guiding rule: **the application servers hold no state.** Every byte of business data lives in PostgreSQL or object storage, so any server can be destroyed and redeployed without loss (Spec §38, §50).

---

## 3. Technology decisions

The recommended stack in Spec §3 is adopted without change. Specific choices within it:

| Layer | Choice | Reason |
|---|---|---|
| Frontend | Next.js (App Router), React, TypeScript (strict) | Per spec. |
| Styling / UI | Tailwind CSS + in-house component library on Radix primitives | Accessible primitives; custom look avoids the "generic admin template" feel (Spec §42). |
| Data fetching | TanStack Query | Caching, retries, optimistic updates. |
| Forms | React Hook Form + Zod | Consistent validation across dozens of forms. |
| Tables | TanStack Table | Server-side sort/filter/paginate for registers. |
| API client | Generated from FastAPI's OpenAPI schema (`openapi-typescript`) | Frontend types never drift from backend. |
| Backend | FastAPI, Pydantic v2, SQLAlchemy 2.0 (typed ORM), Alembic | Per spec. |
| Database | PostgreSQL 16 with `pgcrypto`, `pg_trgm`, `citext` | UUIDs, fuzzy search, case-insensitive emails. |
| Password hashing | Argon2id | Current best practice. |
| PDF generation | Jinja2 HTML templates → WeasyPrint | Server-side, deterministic, no headless browser to maintain; full ₹ / Unicode support with embedded Noto fonts. |
| Excel import/export | openpyxl | BOQ import/export, report export. |
| Background jobs | PostgreSQL-backed job queue (`FOR UPDATE SKIP LOCKED`) in a separate worker process | No Redis to operate; jobs commit atomically with the business transaction that created them. Revisit if volume grows. |
| Object storage | S3 in staging/production; MinIO locally | S3-compatible everywhere (Spec §3). |
| Email | SMTP abstraction; Amazon SES in production | Spec §31 "email architecture". |
| Local dev | Docker Compose: postgres, minio, mailpit, backend, worker, frontend | One command to run the whole system. |
| Tests | pytest against real PostgreSQL; Vitest; Playwright for end-to-end | Financial/inventory logic must be tested against the real database, not mocks. |
| CI | GitHub Actions | Lint, type-check, migrations, tests on every push. |

---

## 4. Repository structure

```
tesla-erp/
├── frontend/                 Next.js app
│   ├── app/                  routes (grouped by module: (crm), (sales), (projects) …)
│   ├── components/ui/        design-system primitives (Button, Field, DataTable, …)
│   ├── components/<module>/  module-specific components
│   ├── lib/api/              generated API types + client
│   └── lib/auth/             session handling, permission guards
├── backend/
│   ├── app/
│   │   ├── main.py           app factory, router registration
│   │   ├── core/             config, db session, security, errors, money, pagination
│   │   ├── platform/         cross-cutting services (see §6)
│   │   │   ├── audit/
│   │   │   ├── numbering/
│   │   │   ├── documents/
│   │   │   ├── approvals/
│   │   │   ├── notifications/
│   │   │   ├── jobs/
│   │   │   ├── pdf/
│   │   │   └── search/
│   │   ├── auth/  users/  company/  customers/  suppliers/  products/
│   │   ├── crm/  boq/  quotations/  sales/  projects/  procurement/
│   │   ├── inventory/  finance/  hr/  service/  reports/  dashboards/
│   │   └── each module/
│   │       ├── models.py      SQLAlchemy models
│   │       ├── schemas.py     Pydantic request/response models
│   │       ├── service.py     business logic (the only place rules live)
│   │       ├── router.py      HTTP layer — thin, no business logic
│   │       ├── permissions.py permission codes this module defines
│   │       └── tests/
│   ├── migrations/           Alembic
│   ├── templates/pdf/        Jinja2 PDF templates
│   └── worker.py             background job runner
├── database/                 seed data, SQL helpers, backup/restore scripts
├── docs/                     architecture, plan, ADRs, runbooks
├── scripts/                  dev tooling
├── infra/                    deployment (Terraform / compose files)
└── docker-compose.yml
```

Layering rule inside every module: **router → service → models**. Routers validate input and check permissions; services own business rules and transactions; nothing else touches the database directly. Modules call each other only through service functions, never by reaching into another module's tables.

---

## 5. Cross-cutting data conventions

These apply to every table and are enforced from the first migration.

### 5.1 Standard columns
Every major table: `id UUID PK (gen_random_uuid())`, `created_at`, `updated_at` (`timestamptz`, stored UTC, displayed Asia/Kolkata), `created_by`, `updated_by` (FK → users), and `status` or `is_active` where appropriate (Spec §5).

Editable documents additionally carry `row_version INTEGER` for **optimistic locking**: if two users open the same quotation and both save, the second save is rejected rather than silently overwriting the first.

### 5.2 Money and quantities — never floating point
| Kind | Type |
|---|---|
| Amounts (₹) | `NUMERIC(18,2)` |
| Rates / unit prices | `NUMERIC(18,4)` |
| Quantities | `NUMERIC(18,3)` (cable in metres, strip in kg) |
| Percentages | `NUMERIC(7,4)` |

Python uses `Decimal` throughout with a single rounding policy (ROUND_HALF_UP) in `core/money.py`. The API serialises money as strings so JavaScript never rounds it. The frontend formats in the Indian system (₹5,50,000; lakh/crore) and prints amount-in-words on invoices.

### 5.3 Reference the master, snapshot on issue
Spec §43 says customer data must live once, in the customer master — and it will: quotations, projects and invoices hold a `customer_id` foreign key, never a copy of the customer.

There is one deliberate, narrow exception required by law and good audit practice: **when a document is issued** (quotation sent, invoice finalised, PO released), the legally significant details *as they were at that moment* — billing name, address, GSTIN, place of supply — are frozen into the document. If the customer later changes address, last year's tax invoice must still show the old one. These frozen fields are read-only, are never edited, and are never used as a customer record; the master remains the single source for everything current.

### 5.4 Nothing financial is ever deleted
- Masters (customers, items, suppliers) are **deactivated**, not deleted; hard delete is allowed only if never referenced.
- Transactions (invoices, receipts, GRNs, stock movements) move through `draft → issued/posted → cancelled/void`. A posted document can only be reversed by a new, linked reversing entry.
- Enforced in the database, not just the application: the application's database role has no `DELETE` on ledger tables.

### 5.5 Multi-company and divisions
- `companies` — legal entities (initially Tesla Consulting Engineers only; the model supports more).
- `business_divisions` — Lightning Protection, Solar EPC, EV Charging, AMC, etc.
- Customers, suppliers, items and employees are **shared** across divisions (Spec §2).
- Every transaction carries `company_id` and `division_id`, so reports can be cut by division while the masters stay common.

---

## 6. Platform services (built once, used by every module)

These are the backbone. Building them in Phase 1 — before any business module — means every later module inherits correct behaviour instead of retrofitting it.

### 6.1 Authentication (Spec §3, §37)
- Login with email or username + password (Argon2id).
- **Access token**: short-lived JWT (~15 min), held in memory by the frontend.
- **Refresh token**: long-lived, random, stored only as a hash in `refresh_tokens`, sent as an `HttpOnly; Secure; SameSite=Strict` cookie, **rotated on every use**; reuse of an old token revokes the whole session family (theft detection).
- CSRF protection on the cookie-authenticated refresh/logout endpoints (double-submit token).
- Rate limiting and progressive lockout on login.
- Admin can revoke all sessions of a user instantly (e.g., employee leaves).
- **2FA-ready**: `user_mfa` table and a login step hook exist from day one; TOTP can be switched on later without schema change (Spec §3 "optional 2FA architecture").

### 6.2 Authorisation — roles, permissions and scope (Spec §6)
- Permission code = `module.action`, e.g. `quotation.approve`. Actions are the seven in the spec: `create, read, update, delete, approve, export, print`. (The spec's example also uses `edit`/`view`; these are treated as synonyms of `update`/`read` so there is one vocabulary — see Q9.)
- Each module declares its permission codes in `permissions.py`; a startup sync inserts any new ones, so adding a module never requires hand-editing permission tables.
- Roles are data, not code: the 11 initial roles are seeded, and an admin can create more or adjust grants without a deployment.
- **Data scope** in addition to permissions — a salesperson may have `lead.read` but should see *their own* leads; a project manager sees *their* projects; directors see everything. Scope levels: `own`, `team`, `division`, `all`.
- Enforcement happens in the backend on every request. The frontend hides buttons the user can't use, but that is cosmetics, not security.

### 6.3 Audit log (Spec §32)
- `audit_logs`: who, what entity, which action, **field-level old → new values (JSONB)**, timestamp, IP, user agent, request ID.
- Written by the service layer **inside the same database transaction** as the change — if the change rolls back, so does its audit record; there is no way to change data without the audit entry.
- Append-only, enforced by the database: the app role has `INSERT` + `SELECT` only, plus a trigger that rejects `UPDATE`/`DELETE`. Only Admin/Director can read the full log.
- Also records logins, failed logins, permission changes, exports and prints of financial documents.

### 6.4 Document numbering (Spec §29)
- `document_sequences(company_id, doc_type, period, next_value)`.
- Number allocation locks the sequence row (`SELECT … FOR UPDATE`) **inside the same transaction** that inserts the document. Two concurrent users therefore cannot receive the same number, and a failed save releases its number rather than leaving a gap.
- Numbers are allocated when a document is **issued/finalised**, not when a draft is started — drafts carry a temporary reference. This keeps statutory series (invoices) gap-free.
- Format patterns are configurable per document type (`TCE/QTN/{YYYY}/{SEQ:4}`), so the open questions on financial year and GST length (§14 R1–R2) can be answered by configuration, not code.

### 6.5 Document storage (Spec §28, §38)
- Files live in S3 (MinIO locally), never on the app server's disk.
- `documents` holds metadata: type, entity_type + entity_id, file name, storage key, MIME type, size, SHA-256 hash, version, uploaded_by/at.
- Uploads go **directly from the browser to S3 via short-lived pre-signed URLs** — large site photos don't pass through the API server. The API then verifies the object (size limit, real file type by content sniffing, not by extension) before marking it available.
- Bucket versioning is on; replacing a drawing creates a new version, never overwrites. Issued PDFs (invoices, POs) are written once and additionally protected with S3 Object Lock in production.
- Downloads are via short-lived pre-signed URLs, issued only after a permission check.

### 6.6 Approval engine (Spec §30)
Generic and configurable, not hard-coded per module:
- `approval_policies` — for an entity type (quotation, purchase_order, expense…), conditions (e.g. value > ₹5,00,000, division = Solar) and an ordered list of approver roles.
- `approval_requests` / `approval_steps` — the live workflow instance with each decision, approver, timestamp and comment.
- Any module makes a document approvable by implementing a small interface (value to test, what happens on approve/reject). Thresholds are edited in Settings, not code.

### 6.7 Notifications (Spec §31)
- Business code records an **event** (e.g. `quotation.submitted_for_approval`) in the same transaction as the change (transactional outbox).
- The worker fans events out to channels: in-app (`notifications` table + bell icon) and email now; WhatsApp/SMS later by adding a channel adapter — no business code changes.
- User-level preferences per event type.

### 6.8 Background worker
Runs PDF generation, emails, AMC/service-due reminders, overdue-payment alerts, low-stock checks and nightly housekeeping. Jobs live in a PostgreSQL table, so they survive restarts and are created atomically with the business change that caused them.

### 6.9 Global search (Spec §35)
PostgreSQL full-text search plus trigram similarity across customers, projects, quotations, invoices, POs, employees, items, suppliers and documents. Searching "ABC Hospital" returns grouped results, **filtered by the user's permissions** — a storekeeper searching won't see invoices. A dedicated search engine is unnecessary at this scale.

---

## 7. Domain architecture — the core ledgers

The spec's most important requirements (accurate stock, project cost, profitability, receivables) all come down to one design principle: **balances are derived from immutable ledgers, never typed in.**

```mermaid
flowchart TB
    subgraph Sales
      L[Lead] --> E[Enquiry] --> SV[Site Visit] --> BOQ --> Q[Quotation<br/>revisions R0,R1…]
      Q -->|accepted| SO[Sales Order] --> P[Project]
    end
    subgraph Procurement
      MR[Material Request] --> PR[Purchase Request] --> PO --> GRN --> SI[Supplier Invoice] --> SP[Supplier Payment]
    end
    subgraph Ledgers["Immutable ledgers"]
      STL[(stock_transactions)]
      PCL[(project_cost_entries)]
      ARL[(receivable / payable entries)]
    end
    P --> MR
    GRN -->|stock in| STL
    MI[Material Issue] -->|stock out| STL
    MI -->|material cost| PCL
    EXP[Approved Expense] --> PCL
    LAB[Labour allocation] --> PCL
    SUB[Subcontract bill] --> PCL
    P --> INV[Sales Invoice] --> ARL
    RC[Receipt] --> ARL
    SI --> ARL
    SP --> ARL
    PCL --> PROF[Project Profitability]
    ARL --> PROF
```

### 7.1 Inventory (Spec §19–21)
- `stock_transactions` is the ledger: one row per movement, signed quantity, unit cost, warehouse, item, optional batch/serial, and the source document (GRN, issue, return, transfer, adjustment). Rows are never updated.
- `stock_balances(item, warehouse, batch)` is a **cached projection** updated in the same transaction under a row lock. It can be rebuilt from the ledger at any time; a nightly job verifies they match and alerts if not.
- **Purchases enter stock only via GRN.** The spec lists both `Purchase` and `GRN` as transaction types; counting both would double stock. A PO never moves stock; `Purchase` is reserved for direct purchases without a PO, if that practice exists.
- Negative stock blocked by default (setting, per warehouse). Serial numbers are unique per item across the whole system. Adjustments require `inventory.approve` and a reason.
- Transfers are two linked ledger rows (out of A, into B) in one transaction.
- **Valuation:** weighted average cost is recommended (simple, standard for this kind of business, and what makes "5 SPDs cost ₹80,000" computable). Needs confirmation — Q4.

### 7.2 Project cost and profitability (Spec §20, §24)
- `project_cost_entries` is the project cost ledger: project, cost head (material / labour / subcontract / travel / other), amount, source document. Material issues, approved expenses, subcontract bills and labour allocations each post here; returns post negative entries.
- The material-issue flow follows Spec §44 exactly, in one transaction: validate stock → stock ledger row → update balance → project cost row → audit record → commit; any failure rolls back everything.
- Profitability = invoiced revenue − sum of cost entries, by head; compared with the estimate taken from the approved BOQ/costing. Everything is computed from ledgers, so the dashboard can never disagree with the underlying transactions.

### 7.3 Project BOQ tracking (Spec §17)
For each approved BOQ line: approved, procured (from PO/GRN), issued (from stock ledger), **installed** (from site progress entries) and remaining quantities. Two clarifications:
- "Installed" needs a data source the spec doesn't list — a simple `installation_entries` record made by the site engineer from mobile. Added to Phase 4.
- The spec's example computes Remaining = Approved − Installed (20 − 12 = 8). The dashboard will show that, plus *at site but not installed* (Issued − Installed = 3) and *yet to procure* (Approved − Procured = 0), which are the numbers a PM actually acts on.

### 7.4 Quotations and revisions (Spec §14)
- `quotations` is the header (number, customer, project/site, status, current revision).
- `quotation_revisions` each hold their own complete set of line items, terms, totals and the rendered PDF. Revision R0, R1, R2… appear as `TCE/QTN/2026/0012-R1`.
- **A revision is immutable once sent.** "Edit" on a sent quotation creates a new revision; history is never overwritten.
- Acceptance marks a specific revision as accepted; the Sales Order is created from that revision, and commercial fields on the SO are locked unless the user holds `sales_order.update_commercial`.

### 7.5 BOQ as a shared building block (Spec §13)
A BOQ is a standalone entity reused by quotation, project, procurement and billing, with Excel import (validated row-by-row with an error report before anything is saved) and Excel/PDF export.

### 7.6 Finance and GST (Spec §22–23)
- **Operational finance**: invoices, receipts, supplier invoices, payments, expenses, outstanding and ageing. Every posted financial document also generates balanced `journal_entries`, so the data can be exported to the statutory books later without rework.
- **GST is data-driven, not hard-coded:** `tax_rates` with effective-from/to dates; HSN/SAC on items. Intra- vs inter-state is decided from the company's state vs the **place of supply** (site/customer state) → CGST+SGST or IGST. Line-level tax, document-level round-off to the rupee, all in one tested calculation module.
- Receipts must support **TDS deducted by the customer** and allocation of one receipt across several invoices — common in contracting (Q6).

---

## 8. API design (Spec §40)

- REST, versioned under `/api/v1/…`, plural resource names (`/api/v1/purchase-orders`).
- Workflow transitions are explicit actions, not free-form status edits: `POST /quotations/{id}/submit`, `/approve`, `/send`, `/revise`, `/accept`. This is what makes the audit trail and permissions meaningful.
- Consistent envelopes:
  - Success: `{ "data": …, "meta": { "page": 1, "page_size": 25, "total": 312 } }`
  - Error: `{ "error": { "code": "STOCK_INSUFFICIENT", "message": "…", "details": {…}, "request_id": "…" } }`
- List endpoints: pagination, sorting, filtering (date range, customer, project, employee) with a common helper so every register behaves the same.
- `DELETE` exists only for masters and drafts; on posted documents the API offers `cancel`/`void` instead.
- Idempotency keys on financial `POST`s so a double-click or network retry can't create two receipts.
- OpenAPI schema is the contract; the frontend client is generated from it.

---

## 9. Frontend architecture (Spec §36, §41, §42)

- Next.js App Router; the sidebar in Spec §41 maps one-to-one to route groups. Menu items are hidden when the user lacks the permission.
- Same-origin deployment (`/` → frontend, `/api` → backend behind the load balancer) avoids CORS and keeps auth cookies `SameSite=Strict`.
- A small design system built first: page header, form field, data table, status badge, money input, date picker, file uploader, confirmation dialog, empty/error/loading states. Every module uses these, which is what delivers "consistent forms, consistent buttons" (Spec §42).
- Visual identity: engineering-firm aesthetic — restrained palette from Tesla Consulting Engineers' own logo and colours, dense-but-legible tables for desktop registers, large touch targets on mobile screens. Needs brand assets (Q10).
- **Mobile-first screens** for site engineers (site visit, tasks, progress/installation, photo upload with in-browser compression, material request, service report, attendance, expense). Installable as a PWA; offline drafting for site visits is recommended because sites often have poor signal (Q8).
- Global search in the top bar (Ctrl/⌘ K), and approvals inbox + notifications bell always visible.

---

## 10. Security (Spec §37)

| Control | Implementation |
|---|---|
| Transport | HTTPS only, HSTS; TLS terminated at the load balancer |
| Passwords | Argon2id; minimum length + breached-password check; never logged |
| Sessions | Short access JWT + rotating refresh cookie; revocable |
| Authorisation | Permission + scope checked server-side on every endpoint; tests for each role |
| SQL injection | ORM / bound parameters only; raw SQL forbidden outside reviewed report queries |
| XSS | React escaping; strict Content-Security-Policy; no `dangerouslySetInnerHTML` on user content |
| CSRF | SameSite=Strict cookies + CSRF token on cookie-authenticated endpoints |
| Rate limiting | Login, password reset, search and export endpoints |
| File uploads | Size limits, content-type sniffing, allow-list of types, randomised storage keys, pre-signed URLs; optional ClamAV scan |
| Secrets | Environment variables locally; AWS Secrets Manager in staging/prod; `.env` git-ignored; secret scanning in CI |
| Sensitive fields | Employee bank account numbers, PAN, salary encrypted at the column level; masked in UI unless permitted |
| Personal data | Employee and customer contact data handled with India's DPDP Act in mind: purpose-limited access, audit of who viewed what |
| Database | App connects with a least-privilege role; migrations run with a separate owner role; DB never publicly reachable |
| Headers | CSP, X-Content-Type-Options, frame-ancestors none, Referrer-Policy |

---

## 11. Environments and deployment (Spec §3, §39)

| | Development | Staging | Production |
|---|---|---|---|
| Runs on | Laptop, Docker Compose | AWS (small) | AWS |
| Database | Local Postgres container | RDS PostgreSQL | RDS PostgreSQL, Multi-AZ |
| Storage | MinIO | S3 bucket (staging) | S3 bucket, versioned + Object Lock for issued docs |
| Email | Mailpit (captures all mail) | SES sandbox | SES |
| Data | Seed data (Spec §46) | Anonymised copy / seed | Real |
| Deploy | — | Automatic on merge to `main` | Manual promotion of the same image tested on staging |

**Recommended AWS layout (region ap-south-1, Mumbai — data stays in India):** containers on ECS Fargate (frontend, backend, worker) behind an Application Load Balancer; RDS PostgreSQL; S3; Secrets Manager; SES; CloudWatch logs and alarms. Infrastructure defined as code (Terraform) so staging and production are identical in shape.

A lower-cost alternative for the first year is a single EC2 instance running the same containers with Docker Compose, still using RDS and S3 for all data. Because the app servers are stateless, moving from one to the other later is a redeploy, not a migration (Q11).

Migrations run automatically as a release step before new code takes traffic; every migration is reviewed and must be backward-compatible with the previous release.

---

### 11.0 Production deployment chosen — single VPS (27 Sep 2026)
The deployment runbook is `docs/DEPLOY_VPS.md`; the scripts are in `deploy/vps/`.
- **Server:** one Ubuntu VPS running Docker Compose with:
  - `db`: PostgreSQL 16, with its data in a volume and no published port;
  - `migrate`: runs once per deploy;
  - `api`: one image that serves both the FastAPI backend and the statically exported web UI;
  - `worker`: background jobs;
  - `caddy`: HTTPS for `erp.teslace.in` with automatic Let's Encrypt certificates.
- **Documents:** stored in the Cloudflare R2 bucket `tce-erp-documents` through the S3 API (region `auto`). The SSE request header is disabled because R2 rejects it; R2 encrypts at rest itself.
- **Backups:** a nightly `pg_dump` is verified, then uploaded with a checksum to a **separate** R2 bucket using a backup-only key, with rotation of 30 daily, 12 weekly and 24 monthly copies. The status is shown in Settings → System and warned about on the dashboard. A restore was rehearsed end to end.
- **Hardening:** ufw allows only 22, 80 and 443; fail2ban; key-only SSH; unattended security upgrades; secrets in `.env` with mode 600, never committed.
- **Scaling path:** the same image runs on managed services later (for example RDS plus several app servers) without code changes.

### 11.1 On-premise option — office server (chosen 25 Sep 2026)
Tesla Consulting Engineers chose to run the ERP on an office PC, with one Windows installer. The design is in ADR 011 and the installation guide in `docs/ONPREM.md`.
- **Server PC:** the `TCE ERP Server` Windows service runs the API, the web UI, background jobs and nightly backups, and supervises an embedded PostgreSQL 16 on the PC's own disk.
- **NAS:** documents are stored on the NAS (`\\NAS\TCE-ERP\documents`), and the database is backed up there every night with rotation and checksums.
- **Other PCs:** use the **TCE ERP desktop app**, or any browser, at `http://<server>:8080`.
- **Site engineers:** reach it at `https://erp.<domain>` through a Cloudflare Tunnel. No ports are opened on the router.
- **Same code as the cloud:** `DEPLOYMENT=onprem` switches storage to the NAS and per-request Secure cookies; everything else (permissions, audit, numbering, tests) is identical.

## 12. Backup and recovery (Spec §38)

| Asset | Mechanism | Retention |
|---|---|---|
| Database — continuous | RDS automated backups with point-in-time recovery | 35 days (restore to any second) |
| Database — daily | Automated snapshot (AWS Backup) | 35 days |
| Database — weekly full | Snapshot copied to a second AWS region | 12 weeks |
| Database — monthly archive | Logical dump (`pg_dump`) to S3 Glacier | 7+ years (GST/Companies Act record-keeping) |
| Documents | S3 versioning + cross-region replication; lifecycle to cheaper tiers | Indefinite for issued documents |
| Config / infra | Terraform in git; secrets in Secrets Manager | — |

A backup that has never been restored is not a backup: a **quarterly restore drill** into a scratch environment, with the result recorded, is part of the runbook. Recovery targets proposed: data loss ≤ 5 minutes (RPO), service restored ≤ 4 hours (RTO).

---

## 13. Testing strategy (Spec §45)

- **Unit tests** for pure calculation code: quotation totals, discounts, GST split, round-off, weighted average cost, profitability.
- **Service tests against real PostgreSQL** (each test in a rolled-back transaction) for anything touching ledgers, locking or numbering — including a concurrency test that 50 parallel requests get 50 distinct document numbers.
- **Permission matrix tests**: for each endpoint, every role is tried and the expected allow/deny asserted.
- **Integration flows** from the spec: Quotation → SO → Project; PO → GRN → Inventory; Project → Material Issue → Project Cost; Invoice → Payment → Receivable.
- **End-to-end (Playwright)** on the critical user journeys, desktop and mobile viewport.
- **Migration tests** in CI: upgrade from empty, and upgrade/downgrade the latest migration.
- CI blocks merging on any failure; coverage target ≥ 85% on `service.py` modules of finance, inventory and projects.

---

## 14. Technical and business risks

| # | Risk | Impact | Mitigation |
|---|---|---|---|
| R1 | **GST invoice number length.** Under the CGST Rules, a tax-invoice serial number is limited to 16 characters and must be unique for a financial year. `TCE/INV/2026/0001` is 17 characters. | Non-compliant invoices | Configurable numbering pattern; confirm the invoice format with your CA before Phase 7 (e.g. `TCE/2627/0001`, 13 chars). Quotation/PO/project numbers are not statutory and can stay as specified. |
| R2 | **Calendar year vs financial year.** Spec shows `YYYY`; Indian books and GST run April–March. | Numbering resets at the wrong time; reports misaligned | Sequence "period" configurable; FY recommended for invoices at minimum (Q2). |
| R3 | **E-invoicing / e-way bills.** If aggregate turnover exceeds the e-invoicing threshold, invoices need an IRN from the government portal; goods movements above the value limit need e-way bills. | Invoices not legally valid without IRN | Confirm applicability (Q5); design invoice issue so an IRN step can be inserted; integrate via a GST Suvidha Provider in Phase 7. |
| R4 | **Labour cost has no source** in the spec (no timesheets). | Profitability understated or guesswork | Choose a method (Q3): daily timesheets per project, or monthly allocation of salary by attendance-at-project, or manual labour cost entries. |
| R5 | **Inventory valuation method** not specified. | Project material cost and stock value disputed | Adopt weighted average unless told otherwise (Q4). |
| R6 | **Contracting billing practices** — running-account (RA) bills, advances, retention money, customer TDS — not in spec. | Receivables wrong; invoice module rebuilt later | Confirm (Q6) before Phase 7 design. |
| R7 | **Relationship to Tally / existing accounts.** | Double entry of accounts; mismatched books | Decide whether the ERP is the book of record or feeds Tally (Q1). Journal entries are generated either way. |
| R8 | **Data migration** of customers, items, open projects, opening stock, outstanding invoices. | Go-live without history; opening balances wrong | Import tools with validation reports built alongside each master; opening stock/balances as dated `Opening` entries. |
| R9 | **Scope size.** The spec is a full mid-market ERP. | Long timeline; features half-finished across many modules | Strict phase gates (Spec §47–48). Each phase ships usable, tested functionality before the next starts. |
| R10 | **Adoption by site staff** on phones with weak signal. | Data not captured; dashboards meaningless | Mobile screens designed first for field tasks; offline drafts; photo compression. |
| R11 | **Single-developer / AI-agent continuity.** | Knowledge loss between sessions | Architecture Decision Records in `docs/adr/`, typed code, tests as executable specification. |

---

## 15. Decisions needed from Tesla Consulting Engineers

These do **not** block Phase 1 (except Q2 and Q9, which have safe defaults). They block the phases noted.

| # | Question | Default if not answered | Needed by |
|---|---|---|---|
| Q1 | What do you use today for accounts, stock and quotations (Tally? Excel?) and should the ERP replace Tally or feed it? | Feed Tally via export; ERP is operational system | Phase 7 |
| Q2 | Document numbering by **financial year (Apr–Mar)** or calendar year? | ✅ **Decided: financial year** (25 Sep 2026) | Phase 1 |
| Q3 | How should labour cost reach projects — timesheets, attendance-based allocation, or manual entries? | Manual labour cost entries per project | Phase 6 |
| Q4 | Inventory valuation: weighted average OK? | Weighted average | Phase 5 |
| Q5 | Is Tesla above the e-invoicing turnover threshold? Do you issue e-way bills? | Architecture ready; integration deferred | Phase 7 |
| Q6 | Do you bill projects in stages (RA bills, % milestones), take advances, or have retention money? Do customers deduct TDS? | Support all four | Phase 7 |
| Q7 | Approval thresholds: is "₹5 lakh" before or after GST? | Before GST (taxable value); configurable | Phase 3 |
| Q8 | Is offline use needed on site (no signal), or is "works on a phone browser" enough? | Offline drafts for site visits only | Phase 2 |
| Q9 | Confirm permission verbs `create/read/update/delete/approve/export/print` (spec also uses `edit`/`view`). | ✅ Accepted with plan: edit=update, view=read | Phase 1 |
| Q10 | Logo (vector), brand colours, letterhead and existing quotation/invoice formats to match. | ✅ Logo supplied; **red & white**. Quotation/invoice formats still welcome before Phase 3 | Phase 3 (PDFs) |
| Q11 | AWS: do you have an account? Budget preference — managed (ECS + RDS) or lean (single EC2 + RDS)? | Lean for staging, decide prod before go-live | Before staging deploy |
| Q12 | Approximate numbers: users, projects per year, items in catalogue, warehouses/site stores. | ~50 users, <5 warehouses | Sizing only |
| Q13 | Do engineers carry stock at site stores (per-project warehouses)? | Yes — a site can be a warehouse | Phase 5 |
| Q14 | Existing data to migrate (customers, items, open projects, opening stock, outstanding invoices)? | Import tools per master | Each phase |

---

## 16. Architecture Decision Records

Each significant choice above will be recorded as a short ADR in `docs/adr/` when Phase 1 starts (context → decision → consequences), so future changes are made knowingly. Initial ADRs: 001 stack, 002 money types, 003 ledger-based inventory and cost, 004 snapshot-on-issue, 005 numbering, 006 audit enforcement, 007 auth tokens, 008 Postgres job queue, 009 PDF engine, 010 deployment topology.
