# Phase 7 report — invoices, receipts, expenses, receivables & payables

| | |
|---|---|
| Completed | 1 Oct 2026 (version 0.8.0) |
| Scope | Spec §22 (Finance), §23 (GST), §24 (project billing, collections and costs), §25 (Expenses), §30 (expense approval), §33 (Accounts dashboard), plan Phase 7. Also three requested extras: a new customer from the quotation form, an employee record for every login, and placing an order again after it was cancelled. |
| Tests | 180 backend tests, all passing. New exit tests: invoice GST split and round-off; billing can never exceed the ordered quantity; **Invoice → Receipt → Receivable**, partial then full, with TDS and an advance; a bounced cheque reverses everything; credit notes (partial and full cancellation); **the journal always balances** and cannot be edited or deleted, and the database refuses an unbalanced entry; supplier bill 3-way match with approval; expense claim Employee → Manager → Accounts → Paid, with the cost reaching the project. Frontend type-check and build pass. Browser walkthrough of every new screen with no errors. |
| Upgrade | Migration `0006`: new tables, plus one relaxed constraint. A quotation used to allow only one sales order ever; it now allows one **open** order. It was rehearsed on a 0.7.0 database holding data: nothing existing changed. Every existing login got an employee record, and the new permissions, ledgers, expense categories and approval rules were added. |

**Phase 6 is still to be built.** It covers material issue to projects, the project cost ledger and full profitability. Until then the project page shows billing, collections, labour and expenses as real figures, and material cost as "Phase 6".

## Sales invoices (`Sales → Invoices`)

**Creating an invoice**
- From a **sales order**: *Create invoice* on the order.
  - For each line it shows ordered, already billed and left to bill.
  - You enter what to bill now. *Bill everything left* fills all lines.
  - Rates, discounts and GST stay exactly as ordered.
  - The quantity billed across all issued invoices **can never exceed the order**. Drafts are rechecked when issued.
- **Direct invoices** for a customer: services, testing jobs, and so on.
- **Extra lines** that are not on the order can be added to an order invoice.

**Bill type and retention**
- The bill type can be a tax invoice, a **running (RA) bill** (numbered RA 1, 2, 3… per order), a final bill or a service invoice.
- **Retention %**: the part the customer holds back. It is printed on the invoice. In receivables it is shown separately and never counted as overdue.

**Issuing**
- A draft can be edited, printed (watermarked DRAFT) or discarded.
- *Issue* assigns the next GST number, e.g. `TCE/2627/0001` (16 characters at most). It freezes the customer's and company's details and posts to the books.
- The company's **GSTIN must be set** (Administration → Company) before the first invoice can be issued.

**After issue**
- The invoice is **never edited or deleted**.
- A **credit note** (`TCE/CN/2627/0001`) reduces it. GST is reversed in the invoice's own proportion.
- *Cancel invoice* is a full credit note. It is allowed only when nothing has been received against the invoice; the quantity then becomes billable again.

**Tax invoice PDF** (GST rule 46): both GSTINs, place of supply with state name and code, HSN-wise tax table, reverse charge yes/no, amount in words, the company's bank details and the signature block.

**e-invoice IRN**: if the company is above the e-invoicing limit, generate the IRN on the portal and record it on the invoice (*Record IRN*). It then prints on the PDF.

## Receipts (`Finance → Receipts`)

**Recording money received**
- Record a receipt from a customer by NEFT, RTGS, IMPS, UPI, cheque (with cheque date), cash or DD.
- Enter the **amount received** and the **TDS the customer deducted**.
- Allocate it to one or several of the customer's open invoices: enter amounts per invoice, or press *Oldest first*.
- Money that is **not allocated is an advance**. It can be allocated later with *Allocate to invoices*.

**Corrections**
- *Take off* moves money from an invoice back to on-account.
- *Cancel receipt* (for example, a cheque returned unpaid) releases every invoice it paid and reverses its journal entry. **A receipt is never deleted.**

Each receipt has a receipt PDF.

## Receivables (`Finance → Receivables`)
- Outstanding by customer, aged by due date: not yet due, 1–30, 31–60, 61–90 and over 90 days.
- Retention is shown in its own column. Advances are shown and netted off.
- Choose an *as of* date, or export to Excel.
- Each customer opens a **statement**: every invoice, credit note and receipt with a running balance and opening balance for any period. It is also on the customer's page.

## Supplier bills and payments (`Finance → Supplier Bills / Supplier Payments / Payables`)

**Entering a bill**
- Enter the supplier's invoice against its **purchase order**. For each PO line it shows ordered, received (GRN), already billed and still to bill.
- **3-way match**: a bill that asks for more than was received, has a net rate above the PO, or a different GST rate is listed with each difference. When posted it goes for **approval** (default: Manager).
- Bills **without a PO** are allowed: crane hire, rent, subcontractors.
  - Choose the ledger to book to (Purchases, Subcontract charges, Labour charges, and so on) and the project.
  - Subcontract and labour bills for a project become **project cost**.
- The same supplier invoice number cannot be entered twice.

**After posting**
- A posted bill is cancelled (not deleted), and only after its payments are taken off it.

**Payments**
- Allocated to bills like receipts, with the **TDS we deduct**. Unallocated money is an advance to the supplier.
- Payments can be cancelled with a reason. Directors are notified of each payment.

**Payables**: the same ageing and statements as receivables.

## Expense claims (`Finance → Expenses`) — Spec §25

**The flow:** Employee → Submit → **Manager** → **Accounts** → Paid.

**Making a claim**
- **Every employee** can claim: category, date, amount, what it was for, and project (required for site categories).
- **Attach a photo or PDF of the bill** before submitting. Categories such as local conveyance do not need one.

**Approval and payment**
- Approval uses the approval engine. The default rule is *Manager → Accounts*; change it in Administration → Approval rules. Nobody approves their own claim.
- A rejected claim comes back as a draft with the reason.
- An **approved** claim is booked to its category's ledger and to the **project's cost**. The amount is owed to the employee until Accounts records the payment (mode and reference); the employee is notified.
- Employees see only their own claims. Managers, Accounts and Directors see all.
- The expense report exports to Excel.

**Categories** (Administration → Masters → Expense categories): 8 starter categories, each posting to a ledger. Edit them freely.

## The books
- **Chart of accounts** (Administration → Masters → Ledger accounts) is Tally-shaped: Sundry Debtors, Sundry Creditors, Sales, Output and Input CGST/SGST/IGST, TDS receivable and payable, Bank, Cash, Purchases and expense ledgers.
- A *project cost head* on an expense ledger makes it count as project cost.
- **Every posted document writes a balanced journal entry in the same transaction**: invoice, credit note, receipt, bill, payment, approved expense and expense payment.
  - Cancellations write reversing entries.
  - The application can only add journal rows, never change or delete them.
  - The database refuses any entry whose debits and credits differ.
- **GST & books** (`Finance → GST & Books`):
  - **GST summary** for any period: output GST by rate, less credit notes, input GST from bills, and net payable. This is a working figure for GSTR-3B.
  - The **journal**.
  - The **trial balance**.
  - **Day book for Tally**: an Excel export with the same ledger names and Tally groups. The ERP feeds Tally; it does not replace it (architecture Q1).

## Accounts dashboard (Spec §33)
Shown on `Finance → Overview` and at the top of the dashboard for Accounts and Directors:
- receivable and overdue;
- retention;
- collected and billed this month;
- payable and overdue;
- expenses to pay or waiting for approval;
- GST payable this month;
- bank and cash movements recorded in the ERP;
- customer advances;
- draft invoices and bills waiting for approval;
- a six-month billed-vs-collected chart.

Employees who only claim expenses see a short summary of their own claims.

## Project page
The four "Phase 7" tiles are now real:
- **Billed** (before GST, % of contract);
- **Collected** (with outstanding and advance);
- **Labour & expenses** (labour, subcontract, travel and other, plus claims waiting for approval);
- a **gross profit so far** line.

Material cost stays "Phase 6".

## The three extras

**1. New customer from the quotation form**
- The *New* button next to the customer search opens a short form: name, type, GSTIN, phone, email, address, city, **state** (which decides CGST + SGST or IGST) and PIN.
- It runs the same duplicate check as the customer screen as you type. A match can be picked with **Use this one** instead of creating a duplicate.
- The new customer is selected on the quotation straight away. Contacts, sites and credit terms can be completed later.

**2. Every login is an employee**
- Creating a user creates the employee record (next `TCE0001`-style code). The new-user form asks for department, designation and division.
- If HR already has an unlinked employee with the same email, that record is **linked instead of duplicated**.
- Renaming a user, or changing their email or phone, updates the employee.
- On upgrade, **every existing login without an employee record got one**.
- The built-in `admin` account is a system login, not a person, so it is left out.
- The users list shows each person's employee code.

**3. Customer cancels after accepting, then comes back**
- **Cancel the order** (with the reason). The cancelled order stays on record. The quotation stays *Accepted* and shows the cancelled order.
- **Place order again**: on the cancelled order (or *Place order again* on the quotation) a new sales order is created with a new number from the same accepted revision and prices.
  - The old order links to its replacement.
  - Only one order can be open per quotation at a time. The database enforces this.
- An **accepted quotation can now be cancelled** too, with a required reason, once its order is cancelled. **Reinstate (customer is back)** returns it to Accepted at the same prices, ready for a new order.
- An order that has an issued invoice cannot be cancelled. Cancel the invoice with a credit note first.

## Who does what (defaults — full table in `PERMISSIONS.md`)
| Role | Invoices | Issue / credit notes | Receipts | Supplier bills | Supplier payments | Expenses | Reports |
|---|---|---|---|---|---|---|---|
| Director, Accounts | all | yes | all | all + approve | all | all + approve + pay | receivables, payables, GST & books, ledgers |
| Manager | view/print | — | view | view + approve mismatches | view | own claims; see all; approve | receivables, payables |
| Sales | view/print | — | view | — | — | own claims | receivables |
| Project Manager | view | — | view | — | — | own claims | receivables |
| Purchase | — | — | — | create/edit/post | view | own claims | payables |
| Site Engineer, Store, HR, Employee | — | — | — | — | — | own claims | — |

## Decisions taken (change on request)
- **Tally stays the book of record** (architecture Q1 default). The ERP posts its own journal and exports the day book for Tally.
- **RA bills, advances, retention and customer TDS are all supported** (architecture Q6 default).
- **e-invoicing**: the IRN is recorded by hand for now (Q5). Direct portal integration through a GST Suvidha Provider can be added when needed.
- **Expense amounts are what the employee paid**, including any GST on the bill. Input credit is not claimed on staff expenses.
- **Supplier bills against a PO are booked to Purchases.** Stock is already valued at GRN, so project material cost will come from material issues in Phase 6, not from bills. Bills without a PO can go to any expense ledger and project.

## Upgrading the live server
Use the same steps as before (`DEPLOY_VPS.md` → "Updating the ERP"). The update runs the migration and `seed core` automatically. Then:

1. **Administration → Company**: enter the company **GSTIN**, PAN, address and **bank details**. Invoices cannot be issued without the GSTIN, and the bank details print on every invoice.
2. **Administration → Approval rules**: check the two new rules, *Expense claims* (Manager → Accounts) and *Supplier bills that differ from the PO/GRN* (Manager).
3. **Administration → Masters → Expense categories / Ledger accounts**: adjust the starter lists if you like. Rename the ledgers to match your Tally ledgers so the day book imports cleanly.
4. **HR → Employees**: every login now has an employee record. Fill in each person's department and designation.
5. For invoices already raised outside the ERP, either enter them as invoices (issued with today's numbers) or keep collecting them in Tally until they are settled. Opening balances will be imported at go-live.

## Next
- **Phase 6** (skipped so far): material issue and return against projects, the project cost ledger, and estimated-vs-actual profitability. It completes the "Material cost" figure.
- **Phase 8**: HR.
