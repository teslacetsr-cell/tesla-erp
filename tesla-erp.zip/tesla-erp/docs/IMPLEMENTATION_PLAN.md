# Tesla Consulting Engineers ERP — Implementation Plan

| | |
|---|---|
| Document | `docs/IMPLEMENTATION_PLAN.md` |
| Status | **Approved 25 Sep 2026.** Phase 0 ✅ · Phase 1 ✅ (`PHASE1_REPORT.md`) · Phase 2 ✅ (`PHASE2_REPORT.md`) · Phase 3 ✅ (`PHASE3_REPORT.md`) · Phase 4 ✅ (`PHASE4_REPORT.md`) · Phase 5 ✅ (`PHASE5_REPORT.md`) · Phase 6 ✅ (`PHASE6_REPORT.md`) · Phase 7 ✅ (`PHASE7_REPORT.md`) · Phase 8 ✅ (`PHASE8_REPORT.md`) · Next: Phase 9 (or Phase 11, the Tally connector) |
| Companion | `docs/ERP_ARCHITECTURE.md` (design decisions, risks, open questions) |
| Prepared | 25 Sep 2026 |

---

## 1. How the work is run

The ten phases in Spec §47 are kept, in order. Each phase follows the same loop (Spec §48):

1. **Plan** — short design note for the phase: tables, endpoints, screens, permissions, tests. Open questions for that phase resolved.
2. **Build one module at a time** — migration → models → service + tests → API → screens.
3. **Verify** — full test suite, migration upgrade/downgrade, API contract check, manual walkthrough of the screens on desktop and mobile width.
4. **Demo & accept** — you review on staging with seed data. Phase is closed only on your acceptance.
5. **Tag a release** — `v0.<phase>.0`, with changelog.

**Rules that apply to every phase**
- Every schema change is an Alembic migration; no manual database edits anywhere.
- No secrets in code or git; `.env.example` documents every variable.
- Every feature ships with tests; CI must be green before merge.
- Financial and inventory operations are single database transactions with audit records.
- Posted financial records are never deleted — only cancelled/voided/reversed.
- Nothing already working is removed or changed in behaviour without your explicit approval.

**Definition of Done for any module**
- [ ] Migration applies cleanly from empty and from the previous release
- [ ] Service logic covered by tests against real PostgreSQL
- [ ] Permission matrix tested for all 11 roles
- [ ] Every create/update/state-change writes an audit record
- [ ] API documented in OpenAPI with consistent envelopes and error codes
- [ ] Screens use shared components, work at 360 px width, and confirm destructive actions
- [ ] Seed data extended so the module can be demoed immediately

---

## 2. Adjustments to the phase list — for your approval

Three small changes to Spec §47, each for dependency reasons:

| Change | Why |
|---|---|
| **Audit log, document numbering, document storage and settings move into Phase 1** (spec leaves them unphased). | Every module from Phase 2 onward creates numbered, audited documents with attachments. Building these first means nothing is retrofitted. |
| **Approval engine is built generically in Phase 3** (spec places "Approval" in Phase 3 — kept) and reused by purchase (Phase 5) and expenses (Phase 7). | One configurable engine rather than three hard-coded ones (Spec §30). |
| **Installation entries added to Phase 4.** | Spec §17 tracks "installed quantity" but no table produces it. |
| **Basic in-app notifications arrive with Phase 3** (for approvals); email/reminders/full engine stay in Phase 10. | Approvals are unusable if approvers aren't told. |

---

## 3. Phase 0 — Assessment ✅

- Repository inspected: empty workspace, no existing application → greenfield.
- `docs/ERP_ARCHITECTURE.md` and this plan produced.
- **Exit:** your approval of both documents and answers (or acceptance of defaults) for Q2, Q9, Q10 in the architecture document §15.

---

## 4. Phase 1 — Foundation, identity and masters ✅ (report: `docs/PHASE1_REPORT.md`)

**Goal:** a deployable, secure skeleton where an admin logs in, manages users and roles, and maintains company, customer, supplier and item masters — with audit, numbering and document storage working underneath.

### 1A. Project scaffolding
- Monorepo structure per architecture §4; `docker-compose.yml` running postgres, minio, mailpit, backend, worker, frontend.
- Backend: FastAPI app factory, settings from environment (pydantic-settings), structured JSON logging with request IDs, global error handler producing the standard error envelope, health endpoints (`/healthz`, `/readyz`).
- Core helpers: `Decimal` money module and rounding policy, pagination/sort/filter helper, base model mixin (UUID, timestamps, created_by/updated_by, row_version).
- Alembic configured; first migration enables `pgcrypto`, `pg_trgm`, `citext`; separate DB roles for migrations vs application.
- Frontend: Next.js + TypeScript strict + Tailwind; generated API client; layout shell with sidebar (Spec §41, permission-filtered), top bar with search placeholder and user menu.
- Tooling: ruff + mypy (backend), ESLint + Prettier + tsc (frontend), pre-commit hooks, GitHub Actions CI (lint, type-check, migrations, tests).
- **Accept:** `docker compose up` gives a running app on a fresh machine; CI green on an empty feature.

### 1B. Authentication
- Tables: `users`, `refresh_tokens`, `user_mfa` (unused until 2FA enabled), `password_reset_tokens`.
- Login (email or username), logout, refresh with rotation and reuse detection, password change, admin-initiated password reset, "revoke all sessions".
- Argon2id hashing; login rate limiting and lockout; CSRF token on cookie endpoints; security headers.
- Frontend: login page, session handling, auto-refresh, forced password change on first login.
- **Tests:** correct/incorrect login, lockout, token expiry, refresh rotation, reuse revokes family, CSRF rejection, deactivated user cannot log in.

### 1C. Roles, permissions and scope
- Tables: `roles`, `permissions`, `role_permissions`, `user_roles`, plus scope on role grants.
- Permission registry: modules declare codes; startup sync.
- 11 seeded roles (Spec §6) with a sensible default grant matrix — delivered as a reviewable table in `docs/PERMISSIONS.md` for you to adjust.
- Backend dependency `require("customer.update")` on every route; scope filter helper for list queries.
- Frontend: Users screen (create, deactivate, assign roles, reset password), Roles screen (permission matrix grid per module × action).
- **Tests:** permission matrix across all Phase 1 endpoints × 11 roles.

### 1D. Platform services
- **Audit** — `audit_logs` with DB-enforced append-only; service helper that diffs old/new; Audit Log viewer (filter by user, entity, date) for Admin/Director.
- **Numbering** — `document_sequences` with row-locking allocation, configurable pattern and period (FY/calendar). Concurrency test: 50 parallel allocations → 50 unique, gapless numbers.
- **Documents** — `documents` table, S3/MinIO adapter, pre-signed upload/download, verification of size and real file type, versioning. Reusable upload/attachments component in the UI.
- **Settings** — key/value settings per company (negative stock allowed, numbering patterns, file limits…) with audit.
- **Jobs** — PostgreSQL job table and worker process skeleton (used first by PDF generation in Phase 3).

### 1E. Company and organisation masters
- `companies` (all Spec §7 fields; logo stored via documents service; bank account encrypted), `business_divisions`, `departments`, `designations`.
- `employees` created here (minimal: code, name, department, designation, contact, linked user, active) — owned by the HR module and extended in Phase 8.
- Screens: Company profile, Divisions, Departments, Designations, Employees (basic).

### 1F. Customer master
- `customers`, `customer_contacts`, `customer_addresses`, `customer_sites` — all Spec §8 fields and the 9 customer types.
- Customer code auto-numbered; GSTIN and PAN format validation (GSTIN checksum, and state code derived from GSTIN to pre-fill state); duplicate warning on similar name/GSTIN/phone.
- Assigned salesperson drives data scope for Sales role.
- Screens: customer list (search, filters, export), customer detail with tabs (overview, contacts, addresses, sites, documents, activity/audit) — tabs for quotations/projects/invoices appear as those modules land.
- Excel import with validation report.

### 1G. Supplier master
- `suppliers`, `supplier_contacts`, `supplier_addresses`, `supplier_bank_accounts` (encrypted, masked) — Spec §9. Rating field ready; rating history computed from GRNs later.
- Screens mirror customers; Excel import.

### 1H. Item master
- `items`, `item_categories` (13 seeded, Spec §10), `brands`, `units` (with conversion factors, e.g. roll ↔ metre), `tax_rates` (GST rates with effective dates), `warehouses` (main store + site stores).
- All Spec §10 item fields including HSN/SAC, serial/batch flags, min stock and reorder level. Items can be goods or services.
- Screens: item list with category/brand filters, item detail; Excel import.

### 1I. Seed data (Spec §46)
Admin user (password from environment, forced change on first login), one user per role for testing, Tesla Consulting Engineers company, divisions, ABC Hospital (with a site), DEHN supplier, the 8 sample items with realistic HSN codes and GST rates, main warehouse. (The sample project is seeded in Phase 4, when projects exist.)

### 1J. Staging deployment
- Container images, Terraform for staging (or single-host compose — per Q11), RDS, S3 bucket with versioning, secrets in Secrets Manager, HTTPS.
- Automated backups on from day one; first restore drill documented.

### Phase 1 exit criteria
- [ ] Admin logs in on staging over HTTPS; forced password change works
- [ ] Users, roles and permissions manageable in the UI; a Sales user cannot open Administration
- [ ] Company, divisions, customers (with sites), suppliers, items, warehouses manageable, importable and searchable
- [ ] Every change visible in the audit log with old/new values
- [ ] Files upload to object storage and survive a full redeploy of the app
- [ ] Numbering concurrency test passes
- [ ] All tests green; migrations clean; backup restore drill done once

---

## 5. Phases 2–11

Each phase gets its own detailed design note (like §4 above) before it starts. Summary scope, key rules and exit tests:

### Phase 2 — CRM ✅ (report: `docs/PHASE2_REPORT.md`)
- **Build:** leads (Spec §11 fields & statuses), enquiries, opportunities, activities, follow-ups with due-date reminders (in-app), lead → enquiry → site-visit conversion keeping links; site visit mobile form (Spec §12) with photos, measurements, optional GPS, customer representative; Site Visit Report PDF (first use of the PDF engine and job worker). Offline drafts for site visit if Q8 = yes.
- **Rules:** Sales sees own leads; conversions never duplicate customer data.
- **Exit:** a site engineer on a phone records a visit with photos; PDF generated and stored; sales dashboard stub shows leads by status.

### Phase 3 — BOQ, Quotation, Approval ✅ (report: `docs/PHASE3_REPORT.md`)
- **Build:** BOQ with Excel import/export and PDF; quotations with immutable revisions (R0, R1…), terms library, totals/discount/GST calculation, status workflow (Spec §14); professional quotation PDF on Tesla letterhead; generic approval engine with configurable thresholds (Spec §30); approvals inbox; in-app notifications for approval events.
- **Rules:** a sent revision can never be edited; number `TCE/QTN/YYYY/XXXX` assigned on first issue.
- **Exit tests:** quotation and GST calculation unit tests (intra- and inter-state, discount, round-off); >₹5 lakh quotation routes Sales → Manager → Director; rejected quotation returns to draft with comment; PDF matches approved format.

### Phase 4 — Sales Order, Projects, Project BOQ, Tasks ✅ (report: `docs/PHASE4_REPORT.md`)
- **Build:** SO from accepted revision with commercial fields locked; project from SO (or standalone, with permission); project members, tasks, milestones, issues, progress updates, project documents; project BOQ tracking (approved/procured/issued/installed/remaining); **installation entries** from mobile; project dashboard shell (financial tiles fill in Phases 6–7); seed "ABC Hospital Lightning Protection Project".
- **Exit tests:** integration test Quotation → SO → Project carries every line and value exactly; unauthorised user cannot change SO rates.

### Phase 5 — Procurement and Inventory ✅ (report: `docs/PHASE5_REPORT.md`)
- **Build:** material request → purchase request → approval → PO (`TCE/PO/YYYY/XXXX`, PDF) → GRN (partial receipts, rejected quantity, serial/batch capture) → stock ledger; warehouses incl. site stores; stock balances, transfers, adjustments (approval required); low/out-of-stock warnings; weighted average costing.
- **Rules:** only GRN moves purchased stock; negative stock blocked; serial numbers unique.
- **Exit tests:** PO calculation; integration PO → GRN → Inventory; concurrency test — two simultaneous issues of the last unit, exactly one succeeds; balance rebuilt from ledger equals cached balance.

### Phase 6 — Material Issue, Project Cost, Profitability ✅ (report: `docs/PHASE6_REPORT.md`)
- **Build:** material issue and return against project (Spec §20, §44 atomic flow); project cost ledger with heads; labour cost per decision Q3; subcontract cost entries; profitability view — estimated vs actual by head; project dashboard financial tiles.
- **Exit tests:** integration Project → Material Issue → Project Cost (issue 5 × DEHN SPD → material cost up by exact weighted cost); issue failure mid-way leaves stock, cost and audit all unchanged; profit calculation tests.

### Phase 7 — Invoices, Receipts, Expenses, Receivables & Payables ✅ (report: `docs/PHASE7_REPORT.md`)
- **Build:** sales invoices from project/SO (incl. RA/milestone billing, advances, retention per Q6) with GST-compliant numbering and PDF; credit notes; receipts with multi-invoice allocation and TDS; supplier invoices matched to PO/GRN (3-way match); supplier payments; expense claims with approval (Employee → Manager → Accounts → Paid) posting to project cost; receivable/payable ageing; journal entries for every posted document; Tally export (per Q1); e-invoice IRN hook (per Q5).
- **Rules:** posted invoices can only be cancelled by credit note; no deletes.
- **Exit tests:** invoice GST split and round-off; integration Invoice → Payment → Receivable (partial and full); journal entries always balance; supplier invoice cannot exceed received quantity without approval.
- **Added on request (1 Oct 2026):** new customer from the quotation form; every login gets an employee record; an accepted quotation can be ordered again after its order is cancelled (and cancelled / reinstated itself).

### Phase 8 — HR ✅ (report: `docs/PHASE8_REPORT.md`)
- **Build:** full employee profile (personal, employment, documents, encrypted bank/salary), attendance (mobile check-in, optional GPS), leave types and requests with approval, salary records, project allocation (feeds labour cost if chosen in Q3).
- **Exit:** employee can apply leave and mark attendance on phone; HR sees balances; salary visible only to HR/Director.

### Phase 9 — Service / AMC
- **Build:** service contracts (AMC value, period, frequency, next due), maintenance schedule generation, service tickets (`TCE/SRV/YYYY/XXXX`), engineer assignment, service visits and mobile service report with PDF, closure with customer sign-off, reminders before due dates; warranty tracking of installed serial-numbered items.
- **Exit:** AMC with quarterly frequency generates four scheduled visits and reminders; a completed service report PDF is stored against the customer and contract.

### Phase 10 — Reports, Dashboards, Notifications, Analytics
- **Build:** all registers and reports in Spec §34 with common filters and Excel/PDF export; role dashboards (Spec §33); full notification engine with email channel, user preferences, and scheduled alerts (overdue payments, project delays, low stock, AMC due); global search completed across all entities; WhatsApp/SMS channel adapter interface.
- **Exit:** each report reconciles with the underlying ledger totals (automated reconciliation tests); director dashboard loads under 2 seconds on production-sized seed data.

### Phase 11 — Tally connector (added 7 Oct 2026)
Two-way link between the ERP (on the internet) and TallyPrime (on a PC in the office), so Accounts stop typing the same entry twice.
- **How it connects:** a small **Tally Connector** Windows service on the Tally PC. It talks to Tally locally over Tally's XML interface (`localhost:9000`) and to the ERP **outbound over HTTPS** with its own revocable API key. Nothing is opened on the office router; **Tally's port 9000 is never exposed to the internet.** It polls every 1–5 minutes and queues work while the internet or Tally is down.
- **ERP → Tally (push):** issued sales invoices and credit notes, posted receipts, supplier bills and payments, approved/paid expense claims, as Tally vouchers; new customers and suppliers as ledgers (with GSTIN and state). Each document is pushed once (idempotent by ERP id ↔ Tally GUID / voucher number); Tally's reply (created / altered / error line) is stored against the document.
- **Tally → ERP (pull):** ledger closing balances and outstanding bills for reconciliation, and — only for the entry types the business chooses to keep in Tally — receipts and payments, which arrive in the ERP as *proposed* entries for Accounts to confirm and allocate.
- **One place per entry:** for each voucher type a setting decides where it is entered (ERP or Tally). The other side only receives it. This prevents double counting.
- **ERP screens:** *Finance → Tally Sync* (connector status and last contact, queue with pending / sent / failed per document, retry, error text from Tally); ledger mapping (ERP ledgers, GST rates, cost heads ↔ Tally ledger names, cost centres for projects); a monthly reconciliation of trial-balance and party balances, ERP vs Tally.
- **Needs from you before it starts:** the TallyPrime release and edition, which PC runs Tally (always on in office hours), how many companies are kept in Tally, and today's practice for where receipts and payments are entered.
- **Exit tests:** an issued invoice appears in Tally once, even if the connector retries; a voucher rejected by Tally shows its error and can be retried after fixing the mapping; the connector offline for a day catches up in order; ERP and Tally trial balances reconcile for a test month.

### Go-live readiness (after Phase 7 at earliest, or after Phase 10)
- Production infrastructure provisioned; security review and dependency audit; data migration rehearsed twice on staging with sign-off on opening balances; user training; restore drill on production backups; success criteria in Spec §50 walked through one by one.

---

## 6. Suggested go-live sequencing

The phases are ordered by data dependency, but you don't have to wait for Phase 10 to get value. A realistic path:

| Milestone | After phase | What the business can use |
|---|---|---|
| Pilot 1 | 3 | Customers, CRM, site visits, BOQs, approved quotations with PDFs |
| Pilot 2 | 6 | Projects, purchasing, stock, project cost and profitability |
| Operational go-live | 7 | Billing, collections, expenses — the full commercial cycle |
| Complete | 10 | HR, AMC, full reporting and dashboards |

Parallel running with the current system (Tally/Excel) is recommended for one month after operational go-live.

---

## 7. Decisions recorded

- **7 Oct 2026** — Phases 6 and 8 built (version 0.9.0). Project *Collected* now counts money received against the project's sales order as well as the project (it previously missed receipts against an order invoice), and the dashboard's open order value includes open projects that have no open order. Leave goes to the person's **reporting manager** (new approval step *Line manager*; falls back to the Manager role when nobody is set). **Phase 11 — Tally connector** added to the plan.

- **1 Oct 2026** — Phase 7 built before Phase 6, at your request. Defaults adopted: Q1 the ERP feeds Tally (day-book export); Q5 IRN recorded by hand; Q6 RA bills, advances, retention and customer TDS all supported.
- **25 Sep 2026** — Plan approved including the phase adjustments in §2. Q2: **financial-year numbering**. Q9: permission verbs as proposed. Q10: **red & white** branding with the TCE logo (supplied).

## 8. Originally: immediately after approval

On your go-ahead, Phase 1 begins with 1A (scaffolding) and 1B (authentication), and the first thing you'll see is the running skeleton with login on your machine or on staging. Before starting, please confirm or override the defaults for:

- **Q2** — numbering by financial year (Apr–Mar)?
- **Q9** — permission verbs as proposed?
- **Q10** — send your logo and brand colours (and existing quotation/invoice formats, if any).
- The phase adjustments in §2 above.

The remaining questions in the architecture document §15 can be answered as their phases approach.
