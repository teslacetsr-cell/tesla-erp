# Phase 6 report — material issue, project cost and profitability

| | |
|---|---|
| Completed | 7 Oct 2026 (version 0.9.0, released together with Phase 8) |
| Scope | Spec §20 (material issue to projects), §24 (project costs and profitability), §44 (the atomic issue flow), plan Phase 6. Two fixes asked for on 7 Oct: project *Collected* missed money received against the order, and the dashboard's open order value now includes open projects. |
| Tests | 193 backend tests, all passing (7 new for costing). Exit tests: **issue 5 × DEHN SPD → the project's material cost rises by exactly the weighted average cost**; an issue that fails part-way leaves stock, cost and the audit log unchanged; returns come back at project cost and can't exceed what was issued; a rejected issue goes back to draft; manual costs, budgets and the profit calculation; Collected counts order invoices and project advances; the dashboard's open value includes open projects. Browser walkthrough of every new screen with no errors. |
| Upgrade | Migration `0007`: new tables only (`material_issues`, `material_issue_lines`, `project_cost_entries`, `project_budgets`). Existing approved expenses and supplier bills booked to a project are **not** back-filled into the cost ledger. Projects show cost from 0.9.0 onwards, plus whatever you add as manual entries. |

## Material issues (`Inventory → Material Issues`)

**Issuing material to a project**
1. *Issue material*, then pick the project.
2. The store defaults to the project's **site store** when it has one, otherwise the main store. You can change it.
3. The project's BOQ is listed with, for each line:
   - the approved quantity;
   - the quantity already issued;
   - what is left;
   - what is in the chosen store.
4. Enter *Issue now* against the lines. Serial numbers and batches are asked for where the item needs them.
5. Items **outside the BOQ** can be added under *Other items*.

**When the stock moves**
- *Issue material* checks stock, numbers the slip `TCE/MI/2026-27/0001` and then:
  - posts it straight away when no approval rule applies; or
  - sends it for approval.
- The seeded rule is *All material issues → Project Manager*. Change or remove it in **Administration → Approval rules**. For example, a minimum amount means small issues post without approval.
- Quantities beyond the BOQ are flagged *Over BOQ* so the approver sees them.

**Posting is one step: all or nothing (Spec §44)**
- The stock leaves the store at **weighted average cost**.
- The BOQ line's issued quantity goes up.
- The **project's material cost** rises by exactly that value.
- The audit log records it.
- If anything fails — not enough stock, a serial number already gone, the project closed — **nothing** changes.
- Stock is checked again at approval, so an approval cannot drive stock negative.

**After posting**
- *Return unused* (`TCE/MRN/2026-27/0001`) brings material back to a store.
- The project is credited at the cost it was issued at, never more than was issued.
- The **issue slip / return note PDF** has signature boxes for store, site and approver.
- *Material issues* lists everything, with filters for project, issue or return, and status. It exports to Excel. The tiles show issued this month (net of returns), items waiting for approval and drafts.
- On the project's *Materials* tab, *Issue material* opens the form with the project already chosen.

## Project cost ledger (project → *Costs & profit*)

Every cost a project bears is one line in an append-only ledger. It is never edited or deleted; a mistake is reversed with a reason. Costs reach it from:

| Head | Comes from |
|---|---|
| Material | Material issues (and returns, as negative) |
| Labour | Staff attendance at the site (Phase 8, *Post to projects*); labour-contractor muster rolls entered by hand |
| Subcontract | Supplier bills booked to the project with a cost head; manual entries |
| Travel / other | Approved expense claims for the project; supplier bills; manual entries |

Behaviour:
- **Expense claims** post their cost when approved, and are reversed if the claim is cancelled.
- **Supplier bills** post their cost when posted, if they name a project and a cost head, and are reversed if the bill is cancelled.
- **Add cost**, for a project manager on their project, is for costs that don't come through the ERP elsewhere: a labour contractor, scaffolding hire, a subcontractor paid outside a supplier bill. Material can't be added by hand; it must come through an issue.
- Every line links back to its source document.

## Profitability

**On each project (the *Costs & profit* tab)**
- **Estimated vs actual**:
  - estimated: contract value and budgeted cost;
  - actual: billed (before GST) and cost to date.
  - Each side shows profit and margin.
- **Cost by head**:
  - columns for estimated, actual, left in budget and a used % bar;
  - the material estimate defaults to the **BOQ estimate** (approved quantities × purchase price);
  - *Set budget* overrides any head.
- *x% of the estimated cost has been spent; work installed is y% of the BOQ value*. This is an early warning when cost runs ahead of progress.

**The project's top tiles**
- *Material cost* now shows the real figure.
- *Labour & other costs* splits out labour, subcontract and travel.
- Below the tiles: actual cost so far and gross profit (billed − actual cost).

**Across projects (`Projects → Profitability`)**
- Open or all projects, with:
  - contract, billed, material and other costs;
  - actual cost against the estimate and against progress;
  - gross profit and margin, actual and estimated.
- Exports to Excel.

## Fixes asked for on 7 Oct

**Project *Collected* was missing money received**
- Invoices raised against the project's **sales order**, and receipts against them, were not counted when the invoice had no project on it. They are now counted.
- A receipt allocated to invoices of one project is now tagged with that project.
- When a project is opened from an order that already has invoices or advances, it adopts them.
- *Collected* = received against invoices + advances held. The sub-line shows the advance and what is still outstanding.
- **Direct invoices** (not from an order) now have a **Project** field, so their billing and collections show on the project too.

**Dashboard *Open orders & projects (before GST)***
- It now adds the value of open projects that have no open sales order to the open order value. Projects opened directly, without an order, now count.
- The sales orders page still shows the order-only figure.

## Permissions (new)

| Permission | Who has it by default |
|---|---|
| `material_issue.create / read` (scoped to own projects) | Project managers and site engineers on their projects; Store, Managers and Directors on all projects (Purchase and Accounts can read all) |
| `material_issue.approve` | Project managers, Managers, Directors |
| `project_cost.read / create` (scoped) | Project managers on their projects; Managers and Directors on all; Accounts read all |

The full matrix is in `docs/PERMISSIONS.md`.
