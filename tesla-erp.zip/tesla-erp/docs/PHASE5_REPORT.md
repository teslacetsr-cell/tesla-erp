# Phase 5 report — procurement and inventory

| | |
|---|---|
| Completed | 30 Sep 2026 (version 0.7.0) |
| Scope | Spec §19 (Procurement), §20–§21 (Inventory, stock rules), §30 (approvals for purchase), plan Phase 5 |
| Tests | 161 backend tests, all passing. New exit tests: PO calculation (CGST + SGST and IGST, discounts); PO approval limits; **Material request → PR → PO → GRN → stock** end to end with exact quantities and values; **two people take the last unit at the same moment — exactly one succeeds**; **every balance rebuilt from the ledger equals the cached balance**, and the ledger cannot be changed or deleted by the application; serial numbers unique; negative stock blocked; weighted average cost. Frontend type-check and build pass. Browser walkthrough with no errors, including the site engineer's request on a phone. |
| Upgrade | Additive migration `0005`: new tables plus one new optional column (`warehouses.project_id`). It was rehearsed on a 0.6.0 database holding data: nothing existing changed; new permissions and approval rules were added. |

## The flow
**Material request → purchase request → approval → purchase order → approval → sent → GRN → stock**

| Step | Who (default) | What happens |
|---|---|---|
| **Material request** (`TCE/MR/…`) | Site engineer, PM (from the project's *Materials* tab), or anyone with the permission | List what is needed, optionally against project BOQ lines. Submitting tells the store and purchase team. The request shows how much is already in stock, in all stores and at the delivery store. |
| **Purchase request** (`TCE/PR/…`) | Purchase, Store | Built from material request lines (it cannot ask for more than was requested) or entered directly, with estimated rates and a suggested supplier. Needs approval; the default rule is *Manager*. |
| **Purchase order** (`TCE/PO/…`) | Purchase | From approved request lines or directly. Supplier, deliver-to store (the main store or a project's site store), priced lines with GST, special discount and terms. **CGST + SGST** when the supplier is in Kerala, **IGST** otherwise. PDF on the letterhead. |
| **PO approval** | Manager; above ₹2 lakh, Manager → Director | Your earlier setting *“purchase value needing Director approval”* became this rule. Change it in Administration → Approval rules. |
| **Mark as sent** | Purchase | Downloads the PO PDF to email to the supplier. |
| **GRN** (`TCE/GRN/…`) | Store; also site engineers for deliveries to site | Records what arrived: accepted, rejected with the reason, batch/expiry and serial numbers. Supports partial deliveries. Receiving more than was ordered is blocked. |

- **Short-close:** stops waiting for the rest of an order. The quantities not received go back to the purchase request, so they can be ordered elsewhere.
- **Purchased stock enters only through a GRN.** A purchase order never moves stock.
- **Stock value:** accepted goods enter stock at the PO rate after discounts and before GST (GST is input credit, not stock cost). Rejected goods stay pending on the PO.
- **Projects:** a PO for a project fills the **Procured** column of the project's BOQ tracking.

## Inventory (`Inventory` menu)
- **Stock ledger:** every movement (opening, GRN, transfer in/out, adjustment) is one row with quantity, cost and value, and never changes.
  - The database itself stops the application from editing or deleting ledger rows.
  - Balances are kept in step inside the same transaction.
  - Every night the worker rebuilds all balances from the ledger and tells the administrators if anything differs. **Stock → Check ledger** runs the same check on demand.
- **Weighted average cost** per item per store. Transfers move stock at the source's average cost. When a store runs out of an item, its value goes to exactly zero, so rounding never leaves a residue.
- **Negative stock is blocked.** This is the company setting in Administration → Settings, and can be overridden per warehouse. Taking stock out locks the balance, so two people can never take the same last unit.
- **Serial numbers** are unique per item across the whole company. They are captured on the GRN and follow the item through transfers. **Batches** carry an optional expiry.
- **Site stores:** a project's *Materials* tab has **Create site store**, which makes a warehouse linked to the project. POs can deliver straight to it, and the main store can send stock there with a transfer.
- **Stock page:**
  - quantity, average cost and value per item, in all stores or one;
  - **out of stock**, **below minimum** and **below reorder level** flags, plus Excel export;
  - each item's page shows stock by store, batches, serial numbers in stock, and its ledger with links to every document.
- **Transfers** (`TCE/TRF/…`): from one store to another in one step.
- **Adjustments** (`TCE/ADJ/…`): opening stock, count corrections, damage, loss, found stock.
  - **Every adjustment needs approval**; the default is *Manager*. The person who raised it cannot approve it.
  - **Opening stock can be imported from Excel** (template provided). Every row is checked first, and nothing is imported until the file is clean.

## Dashboard
New tiles:
- material requests to act on;
- approved requests to order;
- POs waiting for approval;
- POs awaiting delivery;
- items out of stock / below reorder level;
- stock value.

## Who does what (defaults — full table in `PERMISSIONS.md`)
| Role | Material requests | Purchase requests | Purchase orders | GRN | Stock / transfers | Adjustments |
|---|---|---|---|---|---|---|
| Director, Manager | all + process | all + approve | all + approve | all | all | all + approve |
| Purchase | view, process | create/edit | create/edit/print/export | view/print | view/export | — |
| Store | view, process | create/edit | view/print | create/print/export | all | create/edit (not approve) |
| Project Manager | create; edit own | view | view/print | receive at site | view; transfers | — |
| Site Engineer | create; see/edit **own** | — | — | receive at site | view | — |
| Accounts | — | view | view/print/export | view/export | view/export | view |

*Process* = reject a material request or close it (for example, "supplied from the main store").

## Decisions taken (change on request)
- **Valuation: weighted average cost per store.** This is question Q4 in the architecture document; the recommended default was adopted.
- **GST is not part of stock cost.** It is recovered as input tax credit.
- **A GRN cannot be edited or cancelled.** A wrong receipt is corrected with an approved stock adjustment, which keeps the audit trail clean. Returns to the supplier (debit notes) come with supplier invoices in Phase 7.
- **PO amendments:** a draft or unsent PO can be withdrawn and edited. After goods have arrived, short-close it and raise a new PO for any change.
- **Warehouse:** a new installation starts with a *Main Store*. Your live server already has its warehouses, so nothing is added there.

## Upgrading the live server
Same steps as before (`DEPLOY_VPS.md` → "Updating the ERP"). After updating:
1. Check **Administration → Approval rules**. There are new rules for purchase requests, purchase orders (with the ₹2 lakh Director limit) and stock adjustments.
2. Enter each store's **opening stock** as an *Opening stock* adjustment (Excel import), and get it approved.
3. Create **site stores** for running projects from each project's *Materials* tab.

## Next: Phase 6
Material issue and return against projects, the project cost ledger, and profitability (estimated vs actual).
