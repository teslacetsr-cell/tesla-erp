# Incentives & performance (0.11.0, eligibility rule 0.11.1)

The module lives inside the ERP, in the *Incentives* menu. It reads the ERP's own employees, customers, projects, sales invoices, receipts and credit notes. It adds only what the ERP did not already hold: the scheme, per-project incentive settings, follow-up confirmations, month snapshots, payouts and ratings.

## How a bill is valued and when it counts

| Question | Answer |
|---|---|
| Which bills? | Issued sales invoices; cancelled invoices are ignored. |
| Bill value | Taxable value (before GST) minus the taxable value of its credit notes. |
| Paid in full | Receipts (TDS counts as received) plus credit notes ≥ the bill total including GST, i.e. the invoice shows *Paid*. Retention must also be received. |
| Paid date | The latest receipt or credit-note date on the bill. That date's month is the month the incentive counts in. |
| Not entered yet? | *Payment follow-up → Paid in full* records a confirmed date. It counts until Accounts enters the receipt, and then the receipt date takes over. |
| Project | The invoice's project, or the project of its sales order. Bills without a project count in billing totals but earn no category incentive. |
| Project value (subsidy rules) | Contract value; if that is 0, the sum of the project's bills. |
| Welfare fund | Welfare % × billing before GST, by bill date (default 0.5%). |

### When each kind of rule is earned
- **billPaid** — every bill of a matching project, in the month it is paid in full.
- **finalPaid** — once per project, when the bill marked *final* is paid in full.
- **subsidy** — once, in the month the project's *Subsidy received & final docs submitted* date falls.
- **monthly** — once a month, % of that month's collections, only when *All account statements proper* is ticked.

**Who receives it:** for each role on each project, the project's team choice decides. *All in role* (the default) shares the amount equally between the role's active members. A named person gets it all; if that person is no longer active, it goes to the role. *Nobody* means no one earns it. Inactive members never receive new amounts.

**Eligibility (from 0.11.1):** an employee earns incentives only **3 months after their date of joining** (HR → employee → *Date of joining*). What counts is the date the incentive is earned: the paid date of the bill, the subsidy date, or the last day of the month for the accountant's monthly rule.
- Before that date, the person is left out of *All in role* shares, and the others share as if they were not in the role.
- If they are the one person named on a project, that amount is not paid to anyone.
- An employee with no date of joining is treated as eligible; *Setup* marks them *no joining date*.
- The period is set in *Incentives → Setup → Eligibility* (setting `incentive.eligible_after_months`, default 3, 0 = from day one). *Restore standard rates* sets it back to 3.
- Approved (locked) months keep their figures.
- *Setup*, the project's *Incentive* tab and *My incentive* show "earns from <date>" for anyone still in the qualifying period.

## Months
- **Draft** months are recalculated live whenever they are opened.
- **Approve & lock** (Administrator / Director) saves every line, the billing and the welfare amount as they are. After that, later changes to bills, projects or rates do not change the month. Follow-up confirmations, subsidy dates and the accounts tick that would land in a locked month are refused.
- **Unlock** (Administrator only) deletes the snapshot and the month goes back to live figures. It is refused while anyone is marked paid out for that month.
- **Mark paid** records the payout date per employee after locking. It records only the date; the money itself goes through payroll or Accounts and no journal entry is made. It can be undone.

## Standard scheme (installed on first deploy; *Setup → Restore standard rates* brings it back)

| Role | Rule | Categories | Conditions | When | Rate |
|---|---|---|---|---|---|
| Assistant Manager – Solar & LP | Solar subsidy received & final docs submitted | Solar project | — | subsidy done | 0.1% of project value |
| Assistant Manager – Solar & LP | Solar final payment received | Solar project | — | each bill paid | 0.1% |
| Assistant Manager – Solar & LP | Documentation-only projects | Solar documentation only | — | each bill paid | 0.05% |
| Assistant Manager – Solar & LP | Electrical & lightning protection | Electrical, Lightning protection | Not Govt | each bill paid | 0.05% |
| Business Development Executive | Consulting-only | Consulting only | — | each bill paid | 5% |
| Business Development Executive | Govt projects | All project categories | Govt, not tender | each bill paid | 0.2% |
| Business Development Executive | Govt projects started from tendering | All project categories | Govt, tender | each bill paid | 0.25% |
| Business Development Executive | Other electrical projects | Electrical | Not Govt | each bill paid | 0.5% |
| Business Development Executive | Lightning protection | Lightning protection | Not Govt | each bill paid | 2% |
| Jr. Engineer – Electrical Designs | Consulting-only | Consulting only | — | each bill paid | 2.5% |
| Jr. Engineer – Electrical Designs | Solar | Solar project | — | each bill paid | 0.05% |
| Jr. Engineer – Electrical Designs | EI & KSEB documentation | All | EI & KSEB in scope | final bill paid | ₹1,000 |
| Project Engineer | Solar | Solar project | — | each bill paid | 0.5% |
| Project Engineer | Other electrical | Electrical | — | each bill paid | 0.1% |
| Project Engineer | Lightning protection | Lightning protection | — | each bill paid | 0.25% |
| Accountant | All account statements proper | All | — | monthly | 0.1% of collections |
| Office Assistant | Solar subsidy received & final docs submitted | Solar project | — | subsidy done | 0.05% of project value |
| Office Assistant | Solar final payment received | Solar project | — | each bill paid | 0.05% |
| Office Assistant | Documentation-only | Solar documentation only | — | each bill paid | 0.025% |
| Office Assistant | Solar completion report only | Solar completion report only | — | each bill paid | 5% |
| Office Assistant | All other billing | Consulting, Electrical, Lightning protection | — | each bill paid | 0.01% |
| Draftsman | Consulting-only | Consulting only | — | each bill paid | 0.5% |
| Draftsman | Solar | Solar project | — | each bill paid | 0.025% |
| Draftsman | EI & KSEB documentation | All | EI & KSEB in scope | final bill paid | ₹250 |

### Reference check (automated, `tests/test_incentives.py` and `tests/test_incentive_engine.py`)
Four bills, all paid in full in the same month, one person per role:
- **A** — private solar ₹5,00,000, EI & KSEB, subsidy done, final bill
- **B** — private lightning protection ₹2,00,000
- **C** — consulting ₹1,00,000
- **D** — Govt electrical from tender ₹10,00,000

Totals: AM ₹1,100 · BDE ₹11,500 · JE ₹3,750 · PE ₹4,000 · OA ₹630 · Draftsman ₹875 · Accountant ₹1,800 (only with *accounts proper* ticked) · Welfare ₹9,000. The API test raises these as real invoices paid by real receipts.

## Decisions taken where the brief left a choice
1. Payment follow-up *records confirmations only*; money is still entered as a receipt in Accounts (a link is on every row).
2. TDS deducted by the client counts as received. Credit notes reduce the bill value before GST.
3. Retention is part of the bill total, so the bill is paid in full only when retention is received too, unless someone confirms it by hand.
4. "Solar final payment received" stays *each bill paid* (every solar bill earns it), as in the reference app.
5. *Mark paid* records the date only, with no journal entry.

Any of 2–4 can be changed in Setup (rules) or by a small code change; ask if a different reading is wanted.

## Permissions
| | Administrator | Director | Manager | Accounts | Everyone |
|---|---|---|---|---|---|
| Dashboard, register, reports, setup (view), export | ✓ | ✓ | ✓ | ✓ | |
| Change rates, roles, categories, welfare %, project incentive settings | ✓ | ✓ | | | |
| Approve & lock, accounts tick, mark paid | ✓ | ✓ | | | |
| Unlock a locked month | ✓ | | | | |
| Payment follow-up | ✓ | ✓ | ✓ | ✓ | |
| Performance ratings | ✓ | ✓ | ✓ | | |
| *My incentive*: own statement only | ✓ | ✓ | ✓ | ✓ | ✓ |

## Database (migration `0012a`, additive)
`incentive_categories`, `incentive_roles`, `incentive_role_members`, `incentive_rules`, `project_incentive_settings`, `incentive_bill_followups`, `incentive_months`, `incentive_lines` (locked snapshot), `incentive_payouts`, `performance_ratings`. No existing table or row is changed. The welfare % is the setting `incentive.welfare_pct`.

## After upgrading
1. *Incentives → Setup*: add the right people to each role (demo data assigns demo staff).
2. On each active project, open the **Incentive** tab, choose the category and check Govt / Tender / EI & KSEB and the team.
3. Open the register for the current month and compare a few lines with your manual sheet before the first *Approve & lock*.
