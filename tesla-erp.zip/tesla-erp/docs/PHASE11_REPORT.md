# Phase 11 report — Tally connector

| | |
|---|---|
| Completed | 8 Oct 2026 (version 0.10.0) |
| Scope | Plan Phase 11: ERP ↔ TallyPrime over the internet without opening Tally to the internet. |
| Tests | The ERP side is covered by backend tests: Tally XML builders and parsers, the agent protocol, the hooks on every finance document, retries and duplicates, reconciliation, and an end-to-end run of the real connector program against a mock TallyPrime. The connector has 24 tests of its own. Browser walkthrough of *Finance → Tally Sync* on desktop and phone found no errors. |
| Not yet tested with real TallyPrime | Everything was tested against `mock_tally.py`, a stand-in that speaks TallyPrime's XML. **Run a pilot on your Tally PC with a copy of your company before switching it on for live books** (see *Going live*). |
| Upgrade | Migration `0010t` adds new tables only. The new permissions `tally.read` and `tally.update` go to Accounts and Directors. Sync is **off** until you switch it on. |

## How it works

```
TallyPrime (office PC, localhost:9000)  ◄──►  TCE Tally Connector (same PC)  ──HTTPS, outbound only──►  ERP
```

- **Outbound only.** The connector only calls out to the ERP over HTTPS. Nothing is opened on the office router, and Tally's port 9000 never faces the internet.
- **The ERP builds the Tally XML.** The connector only carries it to Tally and brings back Tally's reply, so it rarely needs updating.
- **Nothing is lost.** If the internet, the PC or Tally is down, entries wait in the ERP's queue and go through, in order, when everything is back.
- **Each document is sent once.** Re-sending is recognised. A changed or cancelled document is sent again as an alteration or cancellation.

## What goes to Tally

**Vouchers**
- Sales invoices, as *Sales*.
- Credit notes.
- Customer receipts, as *Receipt*.
- Supplier bills, as *Purchase*.
- Supplier payments, as *Payment*.
- Approved and paid expense claims, as *Journal* and *Payment*.

**Masters**
- New customers and suppliers become ledgers, with GSTIN and state.
- A missing ledger is created before the voucher that needs it.
- Projects can be sent as **cost centres**.

**One place per entry**

For each voucher type, *Settings* says where it is entered: in the ERP (sent to Tally) or in Tally (not sent). This stops the same entry being counted twice. A *start date* keeps old documents from being sent.

## Finance → Tally Sync (Accounts, Directors)

- **Status:** whether the connector is online, when it was last seen, whether Tally is reachable, and the company that is open.
- **Queue:** waiting, sent and failed entries, with Tally's own error in plain words (e.g. *Ledger 'Sales - Works Contract' does not exist*). Failed entries have **Retry** and **Cancel**. A *Tally* badge also appears on each invoice, receipt, bill, payment and expense.
- **Ledger names:** map ERP ledgers, GST rates, cost heads and projects to the exact ledger and cost-centre names in your Tally.
- **Check balances:** party and ledger balances compared, ERP against Tally, for a period.
- **Connector keys:** create (shown once), see when each was last used, revoke.
- **Settings:**
  - switch sync on or off;
  - the Tally company name;
  - the start date;
  - voucher types, and where each is entered;
  - polling interval.

Failures are also notified to Accounts ("Tally did not accept an entry").

## Installing the connector (office Tally PC)

Full steps are in `tally-connector/README.md` in the release.

1. In TallyPrime, enable connectivity:
   - Go to *F1 → Settings → Connectivity*.
   - Set *TallyPrime acts as* to **Both** and the port to **9000**.
   - Set voucher numbering to *Manual*, with *Prevent duplicates* on.
2. In the ERP, go to *Finance → Tally Sync → Connector* and click **Create key**. Copy it; it is shown once.
3. On the Tally PC:
   - Copy the `tally-connector` folder to `C:\TCE-Tally-Connector`.
   - Put the ERP address and the key in `connector.ini`.
   - Run `test`, then install it as a Windows service with `install-service.ps1`.
   - It runs with **Python 3.11** (no extra packages). IT can also build a single `.exe` with `build.ps1`.

## Going live — pilot first

1. Back up your Tally data. Make a **copy of the company** in Tally for the pilot, and set the ERP's Tally company name to the copy.
2. In *Settings*:
   - pick a **start date** (e.g. the 1st of next month);
   - send only *Sales* and *Receipt* at first;
   - keep the rest as "entered in Tally".
3. Fill *Ledger names* so the ERP's ledgers match yours exactly (sales, GST output/input, TDS, bank, round-off).
4. Issue a few invoices and receipts. Check them in the Tally copy: amounts, GST split, party, bill-wise details.
5. When they match, switch to the real company and add the other voucher types one at a time.
6. Each month, run **Check balances**.

## Questions still open (answers change settings, not code)

- **TallyPrime release and edition:** confirm it is TallyPrime 2.x or later. The XML used is standard.
- **Company name:** the exact name of the company in Tally, and whether you have more than one.
- **Receipts and payments:** are they entered in the ERP or in Tally today? That decides each voucher type's setting.
