# Phase 1 report — Foundation, identity and masters

| | |
|---|---|
| Completed | 25 Sep 2026 |
| Approved inputs | Plan approved; **financial-year numbering**; **red & white** branding with the TCE logo; phase adjustments in the plan §2 accepted with the plan |
| Tests | 73 backend tests, all passing, against PostgreSQL 16. Frontend type-check and production build pass. |

## What was built

### Platform (used by every later module)
- **Authentication**
  - Sign in with username or email; passwords hashed with Argon2id.
  - Lockout after 5 failures, rate-limited sign-in.
  - Forced password change at first sign-in; admin password reset.
  - Short-lived access token plus a rotating refresh cookie with reuse detection and CSRF protection.
  - Instant "sign out everywhere"; 2FA table ready.
- **Roles and permissions**
  - The 11 roles from the spec, with a module × action matrix editable in the UI (`docs/PERMISSIONS.md`).
  - Data scope: a salesperson edits only their own customers.
  - Safeguards around the Administrator role.
- **Audit log**
  - Field-level old/new values, user, IP and request id, written in the same transaction as the change.
  - Append-only, enforced by a database trigger and by grants.
  - Records sign-ins, failures, exports and imports.
- **Document numbering**
  - Financial-year sequences, e.g. `TCE/QTN/2026-27/0001`.
  - Transaction-safe: 50 parallel users get 50 distinct, gap-free numbers.
  - Formats editable in Settings; tax invoices limited to 16 characters (`TCE/2627/0001`).
- **Document storage**
  - S3 / S3-compatible storage.
  - Real file type detected from the bytes, 25 MB limit, versioning, soft delete.
  - Downloads are permission-checked.
- **Settings:** typed and audited (negative stock off by default, approval thresholds, etc.).
- **Background jobs:** queue in PostgreSQL plus a worker process.
- **Global search** (Ctrl K), filtered by permission.

### Masters
- **Company profile:** GSTIN checksum validation, PAN and state derived from the GSTIN, encrypted bank account, logo.
- **Organisation:** business divisions, departments, designations, and basic employees linked to user logins.
- **Customers**
  - Auto-numbered, with the 9 customer types.
  - Contacts, multiple project sites, additional addresses, documents and history.
  - Duplicate warnings on name, GSTIN and phone; salesperson assignment.
  - Excel template, import (validated, all-or-nothing) and export.
- **Suppliers:** as customers, plus bank accounts encrypted at rest and masked for users without `supplier_bank.read`.
- **Items**
  - Goods and services with category, brand, unit, HSN/SAC and GST rate.
  - Prices, minimum and reorder levels, serial and batch flags.
  - Datasheets; Excel import and export.
- **Reference lists:** units with conversions (1 roll = 50 m), GST rates with effective dates, warehouses (main and site stores).
- **Seed data (Spec §46):** admin, one demo user per role, ABC Hospital (with site and contact), DEHN supplier, and the 8 sample products plus an installation service. The sample project arrives with Phase 4.

### Engineering
- Every table has UUID keys, created/updated at and by, and optimistic locking (`row_version`), so stale saves are rejected.
- Money is stored as NUMERIC and sent over JSON as strings.
- The application connects as a least-privilege database role.
- Security headers are set; the app refuses to start in staging/production with development secrets or local file storage.
- Tooling: Docker Compose (Postgres, MinIO, Mailpit, API, worker, web), Dockerfiles, GitHub Actions CI, backup and restore-drill scripts, ADRs 001–010, runbooks.

## Exit criteria (Implementation Plan §4)
| Criterion | Status |
|---|---|
| Admin logs in; forced password change works | ✅ verified in browser and tests |
| Users, roles and permissions manageable; Sales cannot open Administration | ✅ permission matrix test covers every endpoint × 11 roles |
| Company, divisions, customers (with sites), suppliers, items, warehouses manageable, importable, searchable | ✅ |
| Every change visible in the audit log with old/new values | ✅ |
| Files stored outside the app server and survive redeploy | ✅ S3 path tested (moto); staging on real S3 pending AWS |
| Numbering concurrency test | ✅ 50 parallel allocations |
| Tests green; migrations clean (up, down, `alembic check`) | ✅ |
| Backup restore drill done once | ✅ development database, logged in `runbooks/backup-and-restore.md` |
| Admin logs in **on staging over HTTPS** | ⏳ **Blocked:** needs an AWS account and the hosting choice (Q11). Images, compose file and deploy runbook are ready. |

## Deviations and notes
- **Numbering format:** financial-year numbers read `TCE/QTN/2026-27/0001` rather than the spec's `TCE/QTN/2026/0001`, so the year is unambiguous. Change it in Settings → Document numbering (e.g. `{FYY}` gives `2026`).
- **Tax invoice format:** defaults to `TCE/2627/0001` to satisfy the 16-character GST rule. Please confirm with your CA before Phase 7.
- **Customer billing address:** stored on the customer record itself. The `customer_addresses` table holds only additional addresses (shipping, delivery, office).
- **Bank details:** Purchase staff can view supplier bank details but not edit them. Editing is for Accounts (`supplier_bank.update`), which follows usual payment-fraud controls. You can change this in Roles.
- **Sign-in rate limit:** counted per server process. The durable protection is the account lockout stored in the database.

## Still needed from you
- **Q11 AWS:** do you have an AWS account? For staging, managed hosting (ECS + RDS) or lean (one EC2 + RDS)? Staging deployment is the last open Phase 1 item.
- **Q8:** confirm whether site visits must work offline. This decides the Phase 2 site-visit design.
- **Existing data:** customer, supplier and item lists to import, if you have them (Excel is fine).
