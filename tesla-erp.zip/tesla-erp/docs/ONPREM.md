# TCE ERP — office server installation (Windows)

One PC in the office runs the ERP for everyone. Every other PC gets the **TCE ERP** desktop app, and phones and laptops can use a browser. Documents and backups are stored on your NAS. Site engineers can reach the ERP from outside the office through a free Cloudflare Tunnel.

```
 Office PCs (TCE ERP app) ──┐
 Office Wi-Fi phones ───────┼──►  SERVER PC  (TCE ERP Server service :8080)
                            │       ├─ PostgreSQL database (on the server's own disk)
 Site engineers (4G) ──► Cloudflare ─┤  └─ nightly backup ─────────────┐
                    https://erp.yourcompany.in                         ▼
                                                   NAS  \\NAS\TCE-ERP\documents  (drawings, PDFs, photos)
                                                        \\NAS\TCE-ERP\backups    (daily / weekly / monthly)
```

## 1. What you need

**Server PC**
- Windows 10 or 11, 64-bit.
- 8 GB RAM or more; an SSD with at least 50 GB free.
- Left switched on, with sleep turned off: *Settings → System → Power → Sleep: Never*.
- A fixed IP address. Reserve it in your router's DHCP settings.
- A short PC name, e.g. `TCE-ERP`. Everyone will type it, as in `http://tce-erp:8080`.

**NAS**
- A shared folder, e.g. `TCE-ERP`.
- A NAS user account (e.g. `erp-service`) with read/write access to that folder only.
- RAID and, if the NAS supports it, snapshots or an off-site copy. The NAS then protects the documents and the backups.

**Other PCs:** Windows 10 or 11. The desktop app uses Microsoft Edge WebView2, which Windows already includes.

## 2. Install on the server PC
1. Run `TCE-ERP-Setup-<version>.exe` and choose **Office server**.
2. When installation finishes, the **server setup page** opens in the browser at `http://localhost:8080/setup`. It only opens on this PC.
   1. **Company:** enter the company name.
   2. **NAS folder:** enter the share, e.g. `\\NAS\TCE-ERP` or `\\192.168.1.20\TCE-ERP`, plus the NAS username and password. Press **Test NAS connection**.
   3. **Administrator:** enter your email and a password of at least 10 characters.
   4. **Remote access:** optional; see section 5. You can skip this step now.
3. Press **Set up the server**. Setup takes a minute or two. It creates the database, builds the tables, and takes a first backup to the NAS to prove the NAS works.
4. **Print the recovery key** shown at the end and keep it somewhere safe, not on the NAS.
   - Supplier and company bank account numbers are encrypted with this key.
   - If the server PC is ever lost, a backup restored on a new PC needs this key to read them.
5. The page moves to the sign-in screen. Sign in as **admin** with the password you chose, then create users in **Administration → Users**.

The ERP runs as the Windows service **TCE ERP Server**. It starts automatically with Windows, even before anyone logs on, and restarts itself if it stops.

## 3. Install on the other PCs
Run the same installer and choose **Desktop app only**. Open **TCE ERP** from the desktop and enter the server address shown at the end of setup, e.g. `http://tce-erp:8080`. The app remembers the address.

To change the address later, use the Start menu item **TCE ERP — change server address**.

Phones and tablets on the office Wi-Fi can open the same address in their browser.

## 4. Backups
- **When:** every night at 01:00, and immediately if a whole day passes without a successful backup (for example, the PC was off at 01:00).
- **Where:** `\\NAS\TCE-ERP\backups\daily`.
  - Every backup file has a `.sha256` checksum, and each one is test-read before it is counted as good.
  - Sunday's backup is also copied to `weekly`, and the 1st of the month to `monthly`.
- **How many are kept:** 14 daily, 8 weekly and 24 monthly.
- **Where to check:** **Administration → Settings → System** shows the last backup. The dashboard shows a red warning to administrators if backups stop.
- **Backup on demand:** open *Start → TCE ERP server status* and run `TCE-ERP-Server.exe backup-now` in that window.

Documents are written straight to the NAS, so they don't need a separate backup from the ERP. Protect the NAS itself with RAID plus snapshots or an off-site copy.

**Restoring a backup** (same PC, or a new PC after the old one failed):
1. On a new PC: install the server and complete setup, pointing it at the **same** NAS folder.
2. Open Command Prompt **as administrator** and stop the service with `net stop TCE-ERP`.
3. Run the restore:
   ```
   cd "C:\Program Files\TCE ERP\server"
   TCE-ERP-Server.exe restore "\\NAS\TCE-ERP\backups\daily\tce_erp_20260925_0100.dump" --recovery-key <key from the printout>
   ```
   - The command checks the file's checksum.
   - It asks you to type `RESTORE`.
   - It saves the current data first to `C:\ProgramData\TCE-ERP\before-restore-….dump`, then restores and upgrades the data to the installed version.
   - Leave out `--recovery-key` when restoring on the same PC.
4. Start the service with `net start TCE-ERP`.

A practice restore on a spare PC once a year is good insurance.

## 5. Remote access for site engineers (Cloudflare Tunnel, free)
The tunnel makes the ERP reachable at `https://erp.yourcompany.in` from anywhere. It needs no router port-forwarding and no fixed public IP, and it uses HTTPS automatically. You need a domain name managed in a free Cloudflare account.

1. In the Cloudflare dashboard, go to **Zero Trust → Networks → Tunnels → Create a tunnel** and choose type **Cloudflared**. Name it `tce-erp`.
2. On the *Install connector* step, copy only the **token**: the long text after `--token`. The ERP already includes the connector, so don't install anything.
3. Under **Public hostname**, set:
   - subdomain `erp`;
   - your domain;
   - service **HTTP** `localhost:8080`.
4. Give the token to the ERP in one of two ways:
   - paste it into setup step 4; or
   - later, run as administrator:
     ```
     "C:\Program Files\TCE ERP\server\TCE-ERP-Server.exe" configure --tunnel-token <token> --public-url https://erp.yourcompany.in
     ```
     then `net stop TCE-ERP && net start TCE-ERP`.
5. **Settings → System** shows *Remote access: running*. Site engineers can open the address on their phones, or enter it in the desktop app on a laptop.

Optional extra protection: Cloudflare **Access** can require an email one-time code before the ERP sign-in page appears.

## 6. Everyday administration
| Task | How |
|---|---|
| See health, backups, addresses | ERP **Settings → System**, or *Start → TCE ERP server status* |
| Restart the server | `net stop TCE-ERP` then `net start TCE-ERP` (Command Prompt as administrator) |
| Admin locked out | `TCE-ERP-Server.exe reset-admin-password` prints a temporary password |
| Restore a backup | `TCE-ERP-Server.exe restore <file.dump>` (service stopped) — see section 4 |
| NAS moved or password changed | `TCE-ERP-Server.exe configure --nas-path \\NAS\TCE-ERP --nas-user erp-service --nas-password <pw>`, then restart |
| Update to a new version | Run the new installer on the server PC (data is kept), then on the other PCs |
| Logs | `C:\ProgramData\TCE-ERP\logs\` (`server.log`, `cloudflared.log`) |

Uninstalling never deletes `C:\ProgramData\TCE-ERP`, which holds the database and configuration, or anything on the NAS.

## 7. Where things are
| What | Location |
|---|---|
| Programs | `C:\Program Files\TCE ERP\` |
| Database, configuration, logs | `C:\ProgramData\TCE-ERP\` — the database is on the server's own disk; PostgreSQL must never run from a network share |
| Documents | `\\NAS\TCE-ERP\documents\` |
| Backups | `\\NAS\TCE-ERP\backups\` |
| Office address | `http://<server-name>:8080` |
| Remote address | your tunnel hostname, e.g. `https://erp.yourcompany.in` |

## 8. Security notes
- The database only listens on the server PC itself.
- The ERP port (8080) is opened in Windows Firewall for the *Domain* and *Private* network profiles only. Make sure the office network is set to *Private* on the server.
- Passwords and keys in `config.json` are encrypted with Windows DPAPI for this machine, so a copied file is useless elsewhere.
- Inside the office, traffic is plain HTTP on your own network. Remote traffic is HTTPS end to end to Cloudflare, and sign-in cookies are marked Secure on those connections.
- If you later want HTTPS inside the office too, point office PCs at the tunnel address as well.

## 9. How the installer is built
The installer is built on Windows by `.github/workflows/windows-installer.yml`: in GitHub, choose *Actions → Windows installer → Run workflow* and download the result. Alternatively, run `packaging\windows\build.ps1` on a Windows PC with Node 22, Python 3.11 and Inno Setup 6.

The workflow then installs the server on the build machine and runs a smoke test before publishing the installer. The test goes through the setup wizard, checks that the ERP starts, signs in as admin, and checks for a backup file.
