# Phase 3 report — BOQ, quotations, quotation PDF, approvals

| | |
|---|---|
| Completed | 29 Sep 2026 (version 0.5.0) |
| Scope | Spec §13 (BOQ), §14 (Quotation), §23 (GST calculation), §30 (Approval system), §31 (in-app notifications for approvals) |
| Tests | 138 backend tests, all passing. They include: 17 GST and quotation-calculation unit tests; the full approval chain; revision immutability; BOQ Excel import; the permission matrix with the new endpoints × 11 roles. Frontend type-check and build pass. The browser walkthrough ran with no errors: quotation above ₹5 lakh → Manager → Director → sent → revised to R1; also viewed on a phone screen. |
| Upgrade | Additive migration `0003`: new tables only. It was rehearsed on a 0.4.0 (Phase 2) database holding data. |

## What was built

### GST and totals: one calculation for every document
- **Line:** amount = qty × rate. The line discount % is deducted, then the special discount (spread pro-rata), leaving the taxable value.
- **GST:**
  - **CGST + SGST** (half rate each) when the place of supply is Kerala, the company's state;
  - **IGST** when it is another state.
  - The place of supply is the site's state, or the customer's billing state.
- **Grand total:** rounded to the rupee, with the round-off shown. Amount in words uses the Indian system: "Rupees Four Lakh Twenty Five Thousand … Only".
- **GST rates:** come from the GST master. A rate that is not in the master is rejected, so no rate is hard-coded.
- **Where it's used:** the same module will serve sales orders and invoices in later phases.

### BOQ (`Projects → BOQ`)
- **Numbering:** `TCE/BOQ/2026-27/0001`.
- **Where it comes from:** an enquiry, a customer, or with no customer yet.
- **Lines (Spec §13):** item, description, technical specification, HSN/SAC, qty, unit, rate, discount %, GST %, amount, remarks, grouped under **sections** such as "External LPS" and "Earthing".
- **Line editor:**
  - pick from the item master, which fills the description, unit, rate, GST and HSN;
  - duplicate and reorder lines;
  - totals update as you type.
- **Excel import:** use the template. An item code fills a row from the item master.
  - Every row is checked first; problems are listed by row number and nothing is saved until the file is clean.
  - Imported lines can be added to the existing lines or replace them.
- **Export:** Excel, and **PDF** on letterhead.
- **Final:** marking a BOQ final locks it; reopen it or copy it to change it.

### Quotations (`Sales → Quotations`)
- **Numbering:** `TCE/QTN/2026-27/0001`, given when first submitted. Drafts show as "DRAFT".
- **Revisions:** show as `…/0001-R1`.
- **Where they come from:** an enquiry (customer, site, contact and salesperson filled in), a BOQ (lines copied), or a customer.
- **Contents (Spec §14):**
  - company and customer details, project/site, quotation date and validity, kind attention;
  - BOQ lines, line discounts, special discount, taxes, grand total;
  - payment, delivery and warranty terms, technical specifications, terms and conditions, bank details.
- **Terms library:** in Administration → Masters. Payment, delivery and warranty defaults plus general clauses are pre-filled on new quotations, and more can be added from the library.
- **Workflow (explicit actions, all audited):**
  1. Draft.
  2. **Submit.** Below the approval limit the quotation is **Approved** straight away. Above it, it becomes **Pending approval**.
  3. **Mark as sent.** The revision is **locked for ever**, the customer and company details are frozen into it, and its PDF is filed.
  4. **Negotiation**, then one of **Accepted**, **Rejected (with the customer's reason)** or **Expired**.
- **Revise:** creates R1, R2 and so on from a sent quotation. **Earlier revisions are never changed**, and their filed PDFs are returned exactly as sent.
- **Withdraw:** a pending or approved-but-unsent quotation returns to draft.
- **Expiry:** checked every 30 minutes; quotations past their validity become Expired.
- **Accepting a quotation** marks its enquiry and lead as **Won**. Sending moves the enquiry to *Quoted* and the lead to *Quotation*.
- **Quotation PDF:** on Tesla letterhead, with sections and HSN codes, and CGST/SGST or IGST shown by rate.
  - Also shows: amount in words, commercial terms, technical specifications, numbered terms and conditions, bank details, signature block, and "Page x of y".
  - Unapproved copies carry a **DRAFT** watermark.
  - A sample is attached to the handover message.

### Approvals (`Approvals`; rules in `Administration → Approval rules`)
- **Configurable rules (Spec §30):** "quotations above ₹X before GST, optionally for one division, need these roles in this order".
  - The rule with the highest limit that applies is used.
- **Starting rule:** the spec's own, *Quotations above ₹5,00,000 → Manager → Director*. If the old Phase 1 setting had been changed, its value is used instead.
  - Below the limit, quotations need no approval. Add an "above ₹0 → Manager" rule if every quotation should be checked.
- **Who can decide:**
  - each step is decided by that role;
  - Directors and Administrators may decide any step;
  - **nobody approves their own quotation**.
- **Rejecting:** needs a comment. The quotation goes back to draft, with the comment shown to the salesperson.
- **What you see:**
  - an **approvals inbox**;
  - the step-by-step chain on the quotation, showing who decided, when, and the comment;
  - a **notification bell** that tells the next approver and, at the end, the requester.
- **Approval trail:** the application can add to it but can never delete from it (database permission).
- **Future use:** the same engine will be used for purchase orders (Phase 5) and expenses (Phase 7).

### Who does what (defaults — full table in `PERMISSIONS.md`)
| Role | BOQ | Quotations | Approve | Approval rules |
|---|---|---|---|---|
| Director | all | all | ✓ | edit |
| Manager | all | all | ✓ | view |
| Sales | create/edit | create; see and edit **own** | — | — |
| Project Manager | create/edit | view | — | — |
| Site Engineer | create/edit | — | — | — |
| Accounts | — | view / print / export | — | — |

## Decisions taken (change on request)
- **Approval limit:** compared with the value **before GST** (question Q7 in the architecture document, default adopted).
- **Quotation numbers:** given **on first submission**, so abandoned drafts leave no gaps in the numbering.
- **"Mark as sent" doesn't email the customer yet.** It files the PDF, and you email it yourself. Sending email arrives with the notification engine in Phase 10.
- **The spec's `quotation_versions` table** is implemented as `quotation_revisions` (R0, R1…), which is the same concept.

## Upgrading the live server
Same steps as for Phase 2 (see `DEPLOY_VPS.md` → "Updating the ERP"):
1. Upload the new zip to GitHub.
2. On the server, download it, unzip it over the old code, and run `./deploy.sh`.

The update adds the new tables, the default approval rule, the terms library and the new permissions. Nothing existing is changed. After it:
1. Check **Administration → Approval rules**.
2. Add your company **address and bank details** in Administration → Company, because they print on every quotation.

## Next: Phase 4
- Sales orders from accepted quotations.
- Projects.
- Project BOQ tracking.
- Tasks.
