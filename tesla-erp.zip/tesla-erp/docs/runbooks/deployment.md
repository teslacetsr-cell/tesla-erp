> **Current production deployment: single VPS — see [../DEPLOY_VPS.md](../DEPLOY_VPS.md).** This runbook describes the managed-AWS alternative.

# Runbook — deploy a release

Applies to staging and production. Every release follows the same four steps; nothing is ever changed by hand in a deployed database.

## 1. Before you deploy
- CI is green on the commit (lint, type-check, migrations up/down, `alembic check`, all tests, frontend build).
- The same commit has run on staging and been accepted there.
- Read any new migration in `backend/migrations/versions/`. It must work with the *previous* code version too, because old containers keep serving during the rollout.

## 2. Build
```
docker build -t tesla-erp-api:<git-sha> backend
docker build -t tesla-erp-web:<git-sha> frontend
```
Push both to the container registry (ECR). The worker uses the API image.

## 3. Release step (once per deploy, before new code takes traffic)
Run the API image with the **owner** database credentials:
```
alembic upgrade head && python -m app.seed core
```
`seed core` is idempotent: it registers new permission codes, grants them to Administrator, and creates any missing numbering formats. It never overwrites role changes made in the UI.

## 4. Roll out
Update the `api`, `worker` and `web` services to the new image tag. Health checks: `GET /healthz` (process up) and `GET /readyz` (database reachable).

## Required configuration (staging/production)
| Variable | Notes |
|---|---|
| `ENVIRONMENT` | `staging` or `production` |
| `DATABASE_URL` | app role (`erp_app`) — least privilege |
| `MIGRATION_DATABASE_URL` | owner role — release step only |
| `SECRET_KEY` | ≥ 48 random characters |
| `FIELD_ENCRYPTION_KEY` | Fernet key; **back it up** — without it encrypted bank details cannot be read |
| `COOKIE_SECURE=true`, `TRUST_PROXY_HEADERS=true` | HTTPS behind the load balancer |
| `STORAGE_BACKEND=s3`, `STORAGE_BUCKET`, `STORAGE_REGION=ap-south-1` | the app refuses to start with local storage |

The application refuses to start in staging/production with development secrets, local file storage or insecure cookies.

## Rollback
Redeploy the previous image tag. Migrations are written to be backward-compatible, so the schema does not need to be rolled back; if one ever must be, run `alembic downgrade -1` from the previous release image — after taking a snapshot.
