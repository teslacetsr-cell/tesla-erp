# Runbook — backup and restore

## What is backed up (production)
| Asset | Mechanism | Retention |
|---|---|---|
| Database — continuous | RDS automated backups, point-in-time recovery | 35 days |
| Database — daily | AWS Backup snapshot | 35 days |
| Database — weekly | Snapshot copied to a second region | 12 weeks |
| Database — monthly archive | `scripts/backup.sh` → S3 Glacier | 7+ years |
| Documents & PDFs | S3 versioning + cross-region replication; Object Lock on issued documents | indefinite |
| Encryption key | `FIELD_ENCRYPTION_KEY` in Secrets Manager, replicated to the second region | indefinite |

## Restore drill (quarterly)
A backup that has never been restored is not a backup.
```
DATABASE_OWNER_URL=postgresql://erp_owner:…@host/tesla_erp scripts/backup.sh ./backups
ADMIN_URL=postgresql://postgres:…@scratch-host/postgres scripts/restore_drill.sh ./backups/tesla_erp_<stamp>.dump
```
The drill restores into a new scratch database, verifies the checksum and prints row counts. It never touches the live database. Compare the counts with live, record the result below, then drop the scratch database.

## Point-in-time recovery (real incident)
1. Decide the target time (just before the bad change — the audit log shows exactly when it happened).
2. In RDS, *Restore to point in time* into a **new** instance. Never overwrite the live instance.
3. Point staging at it and verify.
4. Either copy the needed rows back, or switch production's `DATABASE_URL` to the restored instance during a maintenance window.

## Drill log
| Date | Environment | Backup | Result | By |
|---|---|---|---|---|
| 25 Sep 2026 | Development (Phase 1) | `tesla_erp_20260925T082621Z.dump` (128 KB) | Checksum OK; restored to scratch DB; row counts matched live (customers 1, suppliers 1, items 9, users 12, documents 1, audit 5); append-only audit trigger restored | Claude (build) |
