# Phase 8 report — HR: attendance, leave, employee profile, salary

| | |
|---|---|
| Completed | 7 Oct 2026 (version 0.9.0, released together with Phase 6) |
| Scope | Spec §26 (HR) and §30 (leave approval), plan Phase 8. Exit criteria: an employee can apply for leave and mark attendance on the phone; HR sees balances; salary is visible only to HR and Directors. |
| Tests | 193 backend tests, all passing (6 new for HR). Covered: check-in and check-out with location; HR marking and correcting; register export; leave going to the **line manager** (not the Manager role), balances, attendance marked as leave, overlap and quota checks, cancel; fallback to the Manager role, half days, a range with no working days; personal and bank details hidden from colleagues; salary refused to Managers and Accounts, **stored encrypted and never in the audit log**; labour cost posted twice adds only once; employee and HR dashboards. Browser walkthrough (desktop and phone) with no errors. |
| Upgrade | Migration `0008`: new columns on `employees` (all optional) and on `approval_requests`, and new tables (`holidays`, `leave_types`, `leave_adjustments`, `leave_requests`, `attendance`, `salary_records`). Existing employees keep everything they have. The upgrade adds the leave types, this year's and next year's fixed national holidays, the *All leave requests → Line manager* approval rule, and the new permissions for the standard roles. |

## Before staff start using it — HR to do

1. **Set each person's reporting manager.**
   - Where: `HR → Employees`, open the person, *Edit*, then *Reports to*.
   - Leave goes to this person.
   - When nobody is set, leave goes to the **Manager** role. The profile warns about this.
2. **Add the holidays you observe**: Onam, Vishu, Bakrid, Deepavali and the rest. `HR → Holidays`.
   - Only Republic Day, May Day, Independence Day, Gandhi Jayanti and Christmas are pre-loaded.
   - Mark restricted holidays as *optional*; they are not skipped when counting leave.
3. **Check the leave types** in `HR → Leave Types` and change them to your policy. Pre-loaded:
   - CL 12 days;
   - SL 12 days;
   - EL 15 days, carry forward up to 30;
   - LOP: unpaid, no limit.
4. **Opening balances**: `HR → Leave → Balances → Adjust` adds or removes days for a person and year (carry forward, opening balance, encashment) with a reason.
5. **Personal and bank details, and salary records**, per person on their profile. They are needed for labour costing.
6. **Weekly off**: Sunday by default. It can be set per person (for example Saturday & Sunday) in their personal details.

## My Attendance & Leave (`HR → My Attendance & Leave`, for everyone)

Built for the phone.

**Today**
- **Check in / Check out** with one tap.
  - The phone asks once for location. If allowed, the latitude and longitude are saved with the check-in and check-out; if refused, the check-in still works.
  - The location setting is `hr.attendance_gps`.
- *Working at*: pick a project site. The day is then charged to that project as labour.
- *On duty away from office*: client visits and travel.
- Check-out under half of the 8-hour day (`hr.full_day_hours`) makes the day a **half day**.

**This month**
- A calendar of the month: P, ½, L, OD, A, H, WO.
- ⦿ marks days where a location was captured.
- Totals and the days not marked.

**Leave**
- Balance per type: quota, taken, pending, left.
- *Apply leave*:
  - Half days are allowed for single days.
  - Sundays and holidays inside the dates are not counted.
  - Overlapping requests and requests beyond the balance are refused.
  - LOP has no limit.
- *My leave requests* and upcoming holidays.

**My contact details**: personal email, blood group, emergency contact and addresses. The employee can edit these. Bank details and PAN are kept by HR.

The dashboard shows a *My day* line: checked in or not, and pending leave, with a Check in / Check out link.

## Leave approval — the reporting manager

- New approval step **Line manager**. It is available in `Administration → Approval rules` for any document type.
- It goes to the person's *Reports to*. It falls back to the Manager role when nobody is set, or when the line manager is the person themself.
- The line manager does **not** need any approval permission. They see the request in their Approvals inbox and can approve or reject it. They can also open their team's leave afterwards.
- **On approval**, the days are marked *On leave* (or *Half day*) in attendance. A check-in already recorded for that day is not overwritten.
- **On rejection**, the reason is shown to the employee.
- **Cancel**:
  - the employee can cancel a request while it is pending, or an approved leave that has not started yet;
  - HR can cancel any leave;
  - cancelling clears the leave days from attendance.
- HR can also **apply on behalf** of someone, from their profile.

## Attendance (`HR → Attendance`)

**Today**: employees, present, half day, on leave and not marked yet, plus who is on leave until when.

**The register**
- The whole month: one row per person, one cell per day.
- Holidays and Sundays are filled in. Totals for present, leave, absent and not marked.
- Hovering over a cell shows the check-in and check-out times, hours, project and location.
- **HR clicks a day to mark or correct it**: present, half day, absent, on leave, on duty, holiday or weekly off, with a project site and remarks. Check-in times are kept. The audit log records who changed what.
- Excel export.

Staff see only their own row.

## Employee profile (`HR → Employees` → a person)

**Employment**
- Reports to, joined, employment type, confirmation, work location and weekly off.
- Their team (direct reports) and open projects.
- The basic employee form now has **Reports to**.

**Personal & bank details**
- Date of birth, gender, blood group, marital status, personal email, emergency contact, addresses, PAN, and bank name, IFSC, account name and number.
- Visible to HR, Directors and the employee only. Colleagues and managers do not see this card.
- **PAN and the bank account number are stored encrypted.** The audit log records *which* fields changed, never the values.

**Salary (confidential)**
- HR and Directors only. The API refuses everyone else, including Managers and Accounts.
- The **monthly components** are:
  - earnings: basic, HRA, conveyance, special and other allowances;
  - deductions: PF, ESI, professional tax, TDS, other;
  - employer contributions: PF, ESI, gratuity, other.
  - Gross, net and CTC (monthly and annual) are calculated as you type.
- An optional **site labour day rate**.
- A change is a **new record from a date**. Earlier records stay as history.
- The amounts are **stored encrypted** and never written to the audit log.
- This is a salary record, not payroll. Payslips and statutory returns are not part of Phase 8.

**Leave and attendance**: leave balances for the year (with *Apply* and *Adjust* for HR) and this month's attendance totals.

## Labour cost to projects (`HR → Attendance`, bottom card; HR and Directors)

- For the month: the days each person worked at a project site × their day rate.
  - The day rate is the *site labour day rate* if set, otherwise monthly CTC ÷ 26 (`hr.labour_days_per_month`).
  - The figures are totalled **per project**: man-days, people and cost.
- *Post to projects* puts one labour line per project into the project cost ledger (Phase 6), e.g. *Staff labour from attendance, Oct 2026: 8 man-days, 2 people*.
- **Individual pay is never shown on the project.**
- **Posting the month again replaces its figure; it never doubles.** Correct the attendance or salary, then post again.
- People with site days but no salary record are listed, so they can be added.

## HR dashboard

For HR, Managers and Directors:
- tiles for present today, on leave today, not checked in, and leave requests pending;
- for HR and Directors, birthdays in the next two weeks.

## Settings (`Administration → Settings`)

| Setting | Default | Meaning |
|---|---|---|
| `hr.full_day_hours` | 8 | Under half of this between check-in and check-out → half day |
| `hr.attendance_gps` | on | Ask the phone for location at check-in and check-out |
| `hr.labour_days_per_month` | 26 | Divides monthly CTC to get a day rate when no labour day rate is set |

## Permissions (new)

| Permission | Who has it by default |
|---|---|
| `attendance.create`, `attendance.read` (own), `leave_request.create`, `leave_request.read` (own) | Everyone |
| `attendance.*`, `leave_request.*`, `hr_master.*`, `employee_private.*`, `salary.*`, `labour_cost.create` | HR, Directors |
| `attendance.read / export`, `leave_request.read / approve / export` (all), `hr_master.read` | Managers |
| `attendance.read` (all) | Project managers (to see who is on site) |

The full matrix is in `docs/PERMISSIONS.md`.

## Not in Phase 8

- Payroll: payslips, PF/ESI challans, Form 16.
- Employee document uploads (ID proofs, certificates).
- Shift rosters.
- Geofencing check-ins to a site radius. The location is recorded, not enforced.

These can be added when needed.
