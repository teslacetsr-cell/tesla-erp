# Phase 2 report — CRM: leads, enquiries, site visits

| | |
|---|---|
| Completed | 29 Sep 2026 (version 0.4.0) |
| Scope | Spec §11 (CRM) and §12 (Site visit module), plan §Phase 2 |
| Tests | 109 backend tests, all passing, against PostgreSQL 16. These include a permission matrix covering the new endpoints × 11 roles, and an upgrade test that starts from a Phase 1 database. Frontend type-check and production build pass. The browser walkthrough was run on desktop and on a 390 px phone screen. |
| Upgrade | Additive migration `0002` only. It adds four new tables and changes no existing table. Rehearsed on a Phase 1 database holding data; see "Upgrading" below. |

## What was built

### Leads (`/crm/leads`)
- **Numbering:** `TCE/LEAD/2026-27/0001`, by financial year.
- **Fields (Spec §11):**
  - title and requirement;
  - customer, or prospect details (company, contact, phone, email, city) for someone not yet a customer;
  - source and business division;
  - estimated value (₹), probability, expected closing date;
  - salesperson and notes.
- **Statuses:** New → Contacted → Qualified → Site Visit → Quotation → Negotiation → Won / Lost. Marking a lead Lost requires a reason, which feeds the win/loss report later.
- **Stages move forward on their own as work happens:**
  - creating an enquiry moves the lead to Qualified;
  - scheduling a visit moves it to Site Visit;
  - winning the enquiry moves it to Won.

  These automatic moves never go backwards and never touch a closed lead. People can always change the status by hand.
- **Create enquiry (lead → enquiry):** links the lead to exactly one customer record.
  - For a prospect, the ERP first searches for an existing customer with the same phone number or a similar name. If it finds one, it offers "Use this customer" instead of creating a duplicate.
  - A new customer is made only when you confirm, and the contact person is added to it.
  - This follows the spec rule that conversions never duplicate customer data.
- **Other features:** list with status tiles, search and salesperson filter; Excel export; documents; full history.

### Enquiries (`/crm/enquiries`)
- **Numbering:** `TCE/ENQ/2026-27/0001`.
- **Fields:** customer, site and contact person (picked from the customer record), subject and scope, dates, priority, source, division, value, salesperson.
- **Statuses:** Open → Site Visit → Technical Evaluation → Quoted → Won / Lost / Cancelled. Phase 3 will set "Quoted" automatically when a quotation is issued.
- **Where to create one:** from a lead, from the customer page ("Enquiries & visits" tab), or directly.

### Site visits (`/crm/site-visits`) — mobile-first
- **Numbering:** `TCE/SV/2026-27/0001`.
- **Scheduling:** schedule from an enquiry, or for any customer. Pick the engineer, date and time.
- **The report (Spec §12):**
  - purpose, observations, customer requirements;
  - a **measurements table** (e.g. earth-pit resistance 8.4 Ω);
  - recommendations;
  - customer representative on site;
  - follow-up date.
- **Photos:**
  - taken with the phone camera or chosen from the gallery;
  - **shrunk on the phone before upload**, so a 5 MB photo becomes about 300 KB on mobile data;
  - rotation is corrected.
- **GPS location:**
  - optional per visit;
  - one tap records the coordinates and their accuracy, with a Google Maps link;
  - can be switched off for the whole company in **Settings → CRM**.
- **Works with poor signal (Q8 — the recommended default was adopted):**
  - the report form saves itself on the phone every couple of seconds;
  - if a save fails for lack of signal, or the browser closes, the engineer is offered "Restore unsaved changes" next time;
  - photos are uploaded once there is signal.
- **Completing a visit:**
  - requires findings to be recorded;
  - moves the enquiry to Technical Evaluation;
  - turns the follow-up date into a follow-up task for the salesperson.
- **Site Visit Report PDF** on Tesla letterhead:
  - contents: logo and company details; visit details; findings; measurements table; GPS; photo grid; signature blocks for the engineer and the customer representative;
  - filed on the visit automatically, and each regeneration is a new version;
  - fonts are embedded so ₹, Ω, ° and m² print correctly.

### Follow-ups and activity (`/crm/follow-ups`)
- **On every lead and enquiry:** a timeline of calls, meetings, emails, WhatsApp messages and notes, plus **follow-ups** with a due time and an owner.
- **Follow-ups page:**
  - Overdue / Due today / Upcoming / Done;
  - "Mine" or everyone I can see;
  - one-tap **Done** with an outcome.
- **Where follow-ups show up:** the dashboard and the follow-up page show overdue and due-today counts. Email and phone reminders arrive with the notification engine in Phase 10, as planned.

### Dashboard
- A **sales pipeline** (leads by stage), the open pipeline value, open enquiries, visits in the next 7 days, and my follow-ups (Spec §40, sales dashboard).
- Roadmap updated: Phase 2 done.

### Who sees what (defaults — change them in Administration → Roles; full table in `PERMISSIONS.md`)
| Role | Leads | Enquiries | Site visits |
|---|---|---|---|
| Director, Manager | all | all | all |
| Sales | create; see and edit **own** | create; see and edit **own** | create; see visits for **their** leads and enquiries |
| Project Manager | view all | view and edit all | all (except delete) |
| Site Engineer | — | view the enquiries behind **their** visits | create; see and edit visits **assigned to them** |
| Others | — | — | — |

The same rules apply to documents, photos, activities and global search. A salesperson cannot open another salesperson's lead, even with its link.

## Fixed in this release
- **HR → Employees: Division and Designation could not be selected on the live server.**
  - **Cause:** a production database is set up with core data only, which contained no divisions, departments or designations. The dropdowns therefore only showed "—".
  - **Fix:** the standard divisions (Spec §7), departments and designations are now added automatically, but only to a list that is still empty. A list you have already filled in is never changed.
  - **Also:** the HR menu now links to Departments and Designations; HR users can reach Administration → Masters; the form shows a hint when a list is empty; the employee list shows the division.
- **Dropdowns could lose their saved value.** A form opened before its list had loaded could save the field as blank. All dropdowns in all forms now keep their value.
- **Upgrades now give new modules to the standard roles.** Previously only Administrator received new permissions. Existing role changes are still never overwritten.
- **Phone layout:** long names no longer push form fields off the screen.
- **Security header:** the browser policy blocked location access, so the GPS button could never have worked. The ERP now allows it for its own pages only; the camera and microphone stay blocked.
- **Global search:** employee results linked to a page that doesn't exist; they now open HR → Employees. Leads, enquiries and site visits are now searchable (Ctrl K).

## Decisions taken (change any of them on request)
- **Opportunities** are not a separate table. The lead carries value, probability and expected close, so the pipeline and forecast come from leads. This avoids keeping two records in step for the same deal.
- **Activities and follow-ups** share one table (`crm_activities`). A follow-up is an activity with a due time and an owner.
- **Offline (Q8):** drafts of the visit report are kept on the device, as recommended. Full offline use of the whole app was not built.

## Upgrading a live server
Follow the step-by-step guide in `DEPLOY_VPS.md` → "Updating the ERP". In short:
1. Take a backup.
2. Put the new code on the server.
3. Run `./deploy.sh`.

The script backs up the database again, applies migration `0002`, and adds the new numbering formats, permissions and starter lists. Existing customers, suppliers, items, employees, users and settings are untouched. This was rehearsed on a Phase 1 database containing data, including a customised role.

## Next: Phase 3
- BOQ with Excel import and export.
- Quotations with revisions (R0, R1…) and the quotation PDF.
- The approval engine and approvals inbox.
