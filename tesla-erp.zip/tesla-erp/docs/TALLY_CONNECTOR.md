# Tally Connector — design and agent protocol (Phase 11)

The ERP runs on the internet; TallyPrime runs on a Windows PC in the office. A small **Tally Connector** program on
that PC connects the two:

```
 TallyPrime (localhost:9000, XML over HTTP)  ◄──►  Tally Connector (Windows service)  ──HTTPS──►  ERP  /api/v1/tally-agent/*
```

* The connector only makes **outbound** HTTPS calls to the ERP. Nothing is opened on the office router; Tally's port
  9000 is never exposed to the internet.
* The connector is deliberately **thin**: it never builds or parses Tally XML itself. The ERP sends it ready-made
  XML requests; the connector posts each one to Tally and returns Tally's raw reply. All business logic (what to send,
  how to read Tally's answer, retries, duplicates) lives in the ERP, so the connector rarely needs updating.
* When the internet or Tally is down, nothing is lost: jobs stay queued in the ERP and are leased again later.

## 1. Authentication

The ERP administrator creates a **connector key** in *Finance → Tally Sync → Connector*. The key is shown once,
looks like `tck_<43 url-safe chars>`, and is stored in the ERP only as a SHA-256 hash. It can be revoked at any time.
Every agent call sends

```
Authorization: Bearer tck_…
User-Agent: TCE-Tally-Connector/<version>
```

A revoked or unknown key gets `401 {"error": {"code": "BAD_CONNECTOR_KEY", …}}` — the connector must then stop
polling and log the problem (retry once every 15 minutes, not in a tight loop).

## 2. Endpoints (all JSON, all under `https://<erp>/api/v1`)

### 2.1 `POST /tally-agent/heartbeat`
Request:
```json
{"agent_version": "1.0.0", "host": "ACCOUNTS-PC", "tally_url": "http://localhost:9000",
 "tally_ok": true, "tally_error": null, "tally_company": "Tesla Consulting Engineers",
 "tally_version": "TallyPrime 5.1"}
```
`tally_ok` is the result of a cheap probe the connector makes just before (see §3). Response:
```json
{"data": {"poll_seconds": 60, "enabled": true, "company": "Tesla Consulting Engineers", "server_time": "2026-10-08T09:30:00+05:30"}}
```
* `poll_seconds` — how long to sleep between cycles (the ERP may change it).
* `enabled: false` — sync is switched off in the ERP; keep heart-beating but do not lease jobs.
* `company` — the Tally company name the ERP expects (informational; the XML already names it).

### 2.2 `POST /tally-agent/jobs/lease`
Request: `{"limit": 20}`. Response:
```json
{"data": [
  {"id": "6c1f…", "kind": "import", "label": "Sales TCE/2627/0001", "xml": "<ENVELOPE>…</ENVELOPE>", "attempt": 1},
  {"id": "9a2e…", "kind": "export", "label": "Ledger balances", "xml": "<ENVELOPE>…</ENVELOPE>", "attempt": 1}
]}
```
* Jobs are returned **in the order they must be sent** (masters before vouchers). Process them in that order, one at a
  time.
* A leased job is reserved for 10 minutes. If no result arrives, the ERP hands it out again.
* `kind` is informational (`import` = create/alter data in Tally, `export` = read data from Tally). The connector
  treats both the same way.

### 2.3 `POST /tally-agent/jobs/{id}/result`
After posting the job's `xml` to Tally:
```json
{"ok": true, "status_code": 200, "response": "<RESPONSE>…</RESPONSE>", "error": null, "elapsed_ms": 412}
```
* `ok` — Tally answered with HTTP 200 (whatever the content). `response` is Tally's body, **unchanged** (decode as
  UTF-8 if possible, otherwise UTF-16 when the body starts with a BOM; Tally can answer in either).
* If Tally could not be reached or timed out: `{"ok": false, "status_code": null, "response": null,
  "error": "Connection refused (http://localhost:9000)", "elapsed_ms": 30001}` — the ERP keeps the job and retries it
  later.
* Response: `{"data": {"status": "done" | "failed" | "retry", "message": "…"}}`. The connector just logs it.
* Responses larger than 20 MB must be truncated and sent with `"error": "response too large"`.
* An unknown job id gets `404` (the connector drops that result). A result for a job that is already finished
  (e.g. a late result after the lease expired and the job was sent again) is ignored and answered with its status.

### 2.4 Details of the ERP's behaviour (all compatible with the connector as written)
* `ok: false` on a job also puts the *rest of that lease batch* back in the queue straight away (the connector stops
  after a Tally failure, so those jobs were never sent); they are not counted as a try.
* While sync is switched off (`enabled: false`) a lease returns `[]` even if called.
* Each key may make up to 600 calls a minute; unknown keys are limited to 30 attempts a minute per IP. Over the limit
  the ERP answers `429`, which the connector treats as "ERP unavailable" and backs off.
* Job ordering: masters (priority 10) → vouchers, alters and cancels (20) → exports (30), then queue order. A job whose
  prerequisite (the party's ledger, or the voucher an alter/cancel refers to) has not been accepted by Tally yet is held
  back — it is never sent before it can succeed.

## 3. Talking to Tally

* POST the job XML to the Tally URL (default `http://localhost:9000`) with header
  `Content-Type: text/xml; charset=utf-8`, timeout 60 s (configurable).
* Probe used for the heartbeat (`tally_ok`): POST this and expect HTTP 200 with a body containing `<ENVELOPE` or
  `<RESPONSE`:
  ```xml
  <ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>Company List</ID></HEADER>
  <BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT></STATICVARIABLES>
  <TDL><TDLMESSAGE><COLLECTION NAME="Company List" ISMODIFY="No"><TYPE>Company</TYPE><FETCH>NAME</FETCH></COLLECTION></TDLMESSAGE></TDL>
  </DESC></BODY></ENVELOPE>
  ```
  The first `<COMPANY NAME="…">` (or `<NAME>…</NAME>`) in the reply is reported as `tally_company`.

## 4. Connector loop

```
every cycle:
  probe Tally → heartbeat
  if enabled: lease up to 20 jobs; for each in order: post to Tally, send result
              (if a result can't be delivered to the ERP, keep it in a local outbox file and resend first next cycle)
  sleep poll_seconds (default 60; 5 s when the last lease returned 20 jobs, to drain a backlog)
on errors: exponential back-off up to 5 minutes; never crash; log to a rotating file (1 MB × 5)
```

## 5. XML the ERP generates (for reference / the mock Tally)

### Import (vouchers and masters)
```xml
<ENVELOPE>
 <HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER>
 <BODY><IMPORTDATA>
  <REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME>      <!-- "All Masters" for ledgers -->
   <STATICVARIABLES><SVCURRENTCOMPANY>Tesla Consulting Engineers</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC>
  <REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF">
   <VOUCHER REMOTEID="erp-…uuid…" VCHTYPE="Sales" ACTION="Create" OBJVIEW="Accounting Voucher View">
    <DATE>20261007</DATE><VOUCHERTYPENAME>Sales</VOUCHERTYPENAME><VOUCHERNUMBER>TCE/2627/0001</VOUCHERNUMBER>
    <PARTYLEDGERNAME>ABC Hospital</PARTYLEDGERNAME><NARRATION>…</NARRATION><PERSISTEDVIEW>Accounting Voucher View</PERSISTEDVIEW>
    <ALLLEDGERENTRIES.LIST><LEDGERNAME>ABC Hospital</LEDGERNAME><ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE><AMOUNT>-118000.00</AMOUNT>
      <BILLALLOCATIONS.LIST><NAME>TCE/2627/0001</NAME><BILLTYPE>New Ref</BILLTYPE><AMOUNT>-118000.00</AMOUNT></BILLALLOCATIONS.LIST>
    </ALLLEDGERENTRIES.LIST>
    <ALLLEDGERENTRIES.LIST><LEDGERNAME>Sales — Projects &amp; Services</LEDGERNAME><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><AMOUNT>100000.00</AMOUNT></ALLLEDGERENTRIES.LIST>
    …
   </VOUCHER>
  </TALLYMESSAGE></REQUESTDATA>
 </IMPORTDATA></BODY>
</ENVELOPE>
```
Tally sign convention: debit amounts are negative with `ISDEEMEDPOSITIVE` Yes; credits positive with No. Every voucher
balances to zero. Ledger masters:
```xml
<LEDGER NAME="ABC Hospital" ACTION="Create"><NAME.LIST><NAME>ABC Hospital</NAME></NAME.LIST>
 <PARENT>Sundry Debtors</PARENT><ISBILLWISEON>Yes</ISBILLWISEON><AFFECTSSTOCK>No</AFFECTSSTOCK>
 <PARTYGSTIN>32AAACA1234A1Z5</PARTYGSTIN><GSTREGISTRATIONTYPE>Regular</GSTREGISTRATIONTYPE>
 <LEDSTATENAME>Kerala</LEDSTATENAME><COUNTRYOFRESIDENCE>India</COUNTRYOFRESIDENCE>
 <ADDRESS.LIST><ADDRESS>…</ADDRESS></ADDRESS.LIST></LEDGER>
```
Tally's import reply:
```xml
<RESPONSE><CREATED>1</CREATED><ALTERED>0</ALTERED><DELETED>0</DELETED><LASTVCHID>412</LASTVCHID><LASTMID>0</LASTMID>
<COMBINED>0</COMBINED><IGNORED>0</IGNORED><ERRORS>0</ERRORS><CANCELLED>0</CANCELLED><EXCEPTIONS>0</EXCEPTIONS></RESPONSE>
```
On failure `ERRORS` is non-zero and one or more `<LINEERROR>…</LINEERROR>` explain why, e.g.
`Ledger 'ABC Hospital' does not exist!` or `Voucher Number 'TCE/2627/0001' already exists!` (the ERP treats the
latter as "already in Tally" — vouchers are sent with Tally's *Prevent duplicates* numbering).

### Export (reading from Tally)
Collection requests (`<TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE>`) with an inline TDL collection:
* **Ledgers** — `TYPE Ledger`, `FETCH NAME, PARENT, CLOSINGBALANCE, PARTYGSTIN`. Reply: `<LEDGER NAME="…"><PARENT>…</PARENT>
  <CLOSINGBALANCE>-1234.00</CLOSINGBALANCE>…</LEDGER>` elements anywhere under `<ENVELOPE>`. Tally closing balances are
  negative for debit balances.
* **Vouchers** — `TYPE Voucher` with `SVFROMDATE`/`SVTODATE` static variables and a `FILTER` on voucher type
  (Receipt / Payment). `FETCH DATE, GUID, VOUCHERNUMBER, VOUCHERTYPENAME, PARTYLEDGERNAME, NARRATION, AMOUNT,
  ALLLEDGERENTRIES.LIST`. Reply: `<VOUCHER …><DATE>20261005</DATE><GUID>…</GUID>…</VOUCHER>` elements.

## 6. Installing the connector (summary — full steps in `tally-connector/README.md`)
1. In TallyPrime: *F1 Help → Settings → Connectivity → Client/Server configuration*: TallyPrime acts as **Both**,
   port **9000**. Keep the company open.
2. In each voucher type the ERP sends (Sales, Credit Note, Receipt, Purchase, Payment, Journal): numbering
   *Manual*, *Prevent duplicates: Yes*.
3. Install the connector on the same PC (`TCE-Tally-Connector-Setup` or the Python version), paste the ERP address
   and the connector key, and start the service.

## 7. ERP side (Phase 11 — `backend/app/tally/`)

| Piece | What it does |
|---|---|
| `models.py` | `tally_connector_keys` (SHA-256 hash only, last heartbeat), `tally_settings` (one row), `tally_ledger_maps` (name overrides), `tally_jobs` (the queue), `tally_sync_records` (one per document / party: each is pushed once), `tally_reconciliations`. Migration `0010t`. |
| `xml.py` | Pure builders: ledger masters, vouchers (`ALLLEDGERENTRIES.LIST`, bill-wise allocations, cost centres), cancel, the ledger-balance export; readers for Tally's import reply (CREATED / ALTERED / ERRORS / LINEERROR) and ledger exports. Dates `YYYYMMDD`; debit = negative AMOUNT with `ISDEEMEDPOSITIVE` Yes; every voucher must balance or it is not sent. |
| `builders.py` | ERP document → voucher, with exactly the amounts the document posted to the ERP journal. |
| `service.py` | Settings, keys, enqueue / lease (`SELECT … FOR UPDATE SKIP LOCKED`) / result / retry / skip, backfill, reconciliation. |
| `hooks.py` | Called by `app/finance/*` in the same transaction as the document, inside a savepoint: a Tally problem never blocks or rolls back the ERP document. |
| `router.py` | `/api/v1/tally-agent/*` (connector key) and `/api/v1/tally/*` (screen; `tally.read` / `tally.update`, given to Accounts and Director; Admin has all). |

**What is sent, and when** (only for entry types set to *In the ERP — send to Tally*, dated on/after the start date):

| ERP event | Tally voucher | Entries |
|---|---|---|
| Sales invoice issued | **Sales**, number = invoice number | Dr party (bill *New Ref* = invoice no.), Cr sales (cost centre if the project is mapped), Cr output CGST/SGST or IGST (per rate if mapped), round off |
| Credit note | **Credit Note** | Dr sales, Dr output GST (the invoice's own proportion), round off; Cr party *Agst Ref* invoice no. |
| Receipt posted | **Receipt** | Dr bank / cash, Dr TDS receivable; Cr party: *Agst Ref* per invoice (money + TDS), the rest *On Account* |
| Supplier bill posted | **Purchase**, reference = supplier's invoice no. | Dr expense / purchase ledger, Dr input GST, round off; Cr supplier *New Ref* supplier invoice no. |
| Supplier payment | **Payment** | Dr supplier *Agst Ref* bills (+ TDS), rest *On Account*; Cr bank / cash, Cr TDS payable |
| Expense claim approved / paid | **Journal** / **Payment** | Dr expense ledger, Cr employee reimbursements payable / Dr payable, Cr bank or cash |
| Allocation added / taken off a receipt or payment | same voucher, `ACTION="Alter"` | rebuilt in full |
| Receipt, payment, bill or approved claim cancelled | same voucher, `ACTION="Cancel"` — or, if it never reached Tally, the waiting job is simply dropped | |
| First use of a customer / supplier | ledger master under Sundry Debtors / Creditors with GSTIN, state, address (can be switched off) | |

Invoices are never edited or deleted after issue (Phase 7 rule), so a sales voucher is never altered; a cancelled
invoice reaches Tally as its credit note. Remote id of every voucher: `erp-<document type>-<uuid>`.

**Idempotency.** One `tally_sync_records` row per document: the hook queues a document only once. If Tally already has
the voucher number ("Voucher Number … already exists!") or the ledger ("… already exists!"), the job counts as done —
so a connector that retried after a lost reply never duplicates anything.

**Errors.** A Tally `LINEERROR` marks the job *Not accepted* with Tally's words (e.g. `Ledger 'Sales' does not exist!`),
notifies Accounts, and shows a red badge on the document. *Retry* rebuilds the XML from the current ERP data and ledger
mapping, so fixing a ledger name and pressing Retry is enough. *Don't send* takes an entry off the queue (e.g. it was
typed into Tally by hand) without touching the ERP document.

**Reconciliation.** *Check balances* queues an export of every Tally ledger's closing balance; when it returns, the ERP
compares each customer and supplier (from the journal's party lines), the Sundry Debtors / Creditors group totals and
each mapped ledger. Differences are expected for entries before the start date or made only in Tally.

## 8. Administrator's how-to

1. **Create a key** — *Finance → Tally Sync → Status & settings → Create key*. Name it after the PC. Copy the key
   (`tck_…`) at once: it is shown only once. Store it like a password. If it is lost or the PC is replaced, *Revoke* it
   and create a new one.
2. **Install the connector on the Tally PC** (`tally-connector/README.md`): set TallyPrime to act as *Both* on port
   9000, then install the service and fill `connector.ini` with `erp_url = https://<your ERP>` and the key.
   `TCE-Tally-Connector.exe test` checks both sides. Within a minute the ERP shows the connector *Online*, the PC name,
   and whether Tally answered with the right company.
3. **Map ledgers** — *Ledger names* tab. Every ERP ledger is listed with its Tally group; leave the box empty to use the
   ERP name, or type the exact Tally ledger name. Optional: separate GST ledgers per rate, different names for
   particular customers / suppliers, and project → cost centre. On a fresh Tally company, *Send ledger list to Tally*
   creates the ledgers that are missing.
4. **Turn it on** — in *Settings* choose for each kind of entry where it is made (*In the ERP — send to Tally* or *In
   Tally — not sent*; one place only, so nothing is counted twice), set the start date (the day after the last entry
   already in Tally), check the Tally company name, tick *Send entries to Tally* and save. To send entries already made
   since the start date, press *Queue all from start date*.
5. **What to check** — the *Queue* tab (and the red banner) daily: *Not accepted* entries show Tally's reason; fix it
   (usually a ledger name) and press *Retry* or *Retry all not accepted*. Invoices, receipts, bills, payments and claims
   show a small *In Tally* / *Tally: not accepted* badge. Once a month run *Check balances*. If the connector shows
   *Not in contact*, check the Tally PC is on, the service is running, and the internet works — nothing is lost
   meanwhile; the queue catches up in order.
