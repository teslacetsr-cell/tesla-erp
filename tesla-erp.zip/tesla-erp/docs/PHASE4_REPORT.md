# Phase 4 report — sales orders, projects, project BOQ tracking, tasks

| | |
|---|---|
| Completed | 30 Sep 2026 (version 0.6.0) |
| Scope | Spec §15 (Sales order), §16 (Project), §17 (Project BOQ tracking), §18 (Tasks, site work), §40 (project manager dashboard) |
| Tests | 148 backend tests, all passing. New: Quotation → Sales order → Project carries every line, price, GST and total exactly; nobody without the special permission can change order rates (not even the salesperson who owns it); installation can never exceed the approved quantity; order changes flow into the project BOQ; project visibility by team; the assignee moves their own task. Frontend type-check and build pass. Browser walkthrough with no errors: accept → sales order → Director price change with reason → project → task → site report with installation and photo on a phone. |
| Upgrade | Additive migration `0004` (new tables only), rehearsed on a 0.5.0 database holding data: nothing changed, new permissions granted to the standard roles. |
| Also fixed | The logo printed on a **black background** in quotation PDFs. Transparent logos are now placed on white in every PDF. |

## What was built

### Sales orders (`Sales → Sales Orders`)
- **Created from an accepted quotation** with **Create sales order** on the quotation. Numbering `TCE/SO/2026-27/0001`.
- The accepted revision is **copied exactly**: every line, rate, discount, special discount, CGST/SGST/IGST, round-off, grand total, payment/delivery/warranty terms, terms and conditions, and the customer details frozen when the quotation was sent. One order per quotation.
- **Order details** (customer PO number and date, expected completion, notes) can be edited by the salesperson.
- **Prices, quantities and terms are locked.** Only users with *Sales order prices & terms* (Director by default) can change them, through **Change prices & terms**. A reason is mandatory, and the history records old → new totals with the reason. Any running project's BOQ follows the change; lines already installed beyond the new quantity are kept and reported.
- **Status:** Confirmed → In progress (automatically when its project is created) → Completed; or Cancelled with a reason (not while a project runs).
- **Order acknowledgement PDF** on letterhead, Excel export, documents (e.g. the customer's PO scan) and history.

### Projects (`Projects → Projects`)
- **From a sales order** (customer, site, division, target date and BOQ come from the order; contract value = order value before GST) or **without an order** (customer and contract value entered). Numbering `TCE/PRJ/2026-27/0001`.
- **Dashboard tiles:** contract value, **estimated cost** (approved quantities × item purchase prices), **estimated profit and margin**, **work installed** (value and % of BOQ), progress, tasks done/overdue, open issues, target date.
  - Billed, collected, material cost and labour/expenses show as placeholders until Phases 6–7.
- **Status:** Planning → Active → On hold (reason) → Completed; Cancelled (reason). A completed project can be reopened with a reason. The first site report makes a planning project active.
- **Team:** project manager plus members with a role (Site Engineer, Technician…). Giving someone a task adds them to the team.
- **Milestones** with due and completed dates; late ones are highlighted.
- **Documents** (drawings, test reports…) and full history.
- **Project status report PDF**: summary, BOQ tracking, milestones, open tasks and issues.

### Project BOQ tracking and installation
- Every order line becomes a project BOQ line: **approved · procured · issued · installed · remaining**, with a progress bar per line.
  - Procured and issued fill in automatically in Phases 5–6.
- **Installation entries** (date, quantity, location, remarks), from **Record installation** or inside a daily site report.
  - **The installed quantity can never exceed the approved quantity.** This is checked on screen, in the application and by a database constraint.
  - Future dates are refused.
  - Removing an entry (or deleting its site report) returns the quantity to *remaining*.
- **Extra work / variations** can be added as project lines by the project manager; lines from the order change only through the order.
- Excel export of the BOQ tracking sheet.

### Tasks, issues and daily site reports
- **Tasks:** assignee, milestone, start/due dates, priority, status *To do → In progress → Blocked (reason) → Done*.
  - The assignee is notified.
  - The project manager is notified when a task is blocked or done.
  - **Anyone can move their own task**, even a technician with no other project access.
- **`Projects → Tasks`:** *My tasks* for everyone; *All projects* for managers and teams. Overdue tasks are highlighted.
- **Issues:** severity, assignee, open → resolved/closed with the resolution. The project manager is notified.
- **Daily site reports** (built for the phone):
  - date, work done, manpower, weather, hindrances (the PM is notified), plan for tomorrow, overall progress %;
  - the quantities installed today against the BOQ;
  - **photos** taken with the phone camera (shrunk before upload).
- **`Projects → Site Reports`:** every report across your projects, filterable by project and date.

### Dashboard
New tiles: my open tasks, active projects, projects past target date, overdue project tasks, open site issues, orders without a project yet, and open order value.

### Who does what (defaults — full table in `PERMISSIONS.md`)
| Role | Sales orders | Change order prices | Projects | Site work (tasks, reports, installation) |
|---|---|---|---|---|
| Director | all | ✓ | all | all |
| Manager | all | — | all | all |
| Sales | create; see/edit **own**; print | — | — | — |
| Project Manager | view, print | — | create; view all; edit **own** | on **own** projects (incl. delete) |
| Site Engineer | — | — | view **own** (team) | create/edit on **own** projects |
| Accounts | view, print, export | — | view, print, export | — |
| Store | — | — | view | — |
| Everyone | — | — | — | move their **own** tasks |

## Decisions taken (change on request)
- **Contract value = order value before GST.** Profit figures compare like with like, without GST.
- **Estimated cost uses item purchase prices.** Lines without an item or a purchase price are counted and flagged on the tile. Phase 6 replaces the estimate with actual material issues.
- **"Change prices & terms" is Director-only by default.** It can be given to other roles in Administration → Roles (*Sales order prices & terms*).
- **Deleting a project** is allowed only while it is in planning with no site work; otherwise cancel it.

## Upgrading the live server
Same steps as before (`DEPLOY_VPS.md` → "Updating the ERP"): upload the new zip to GitHub, then download, unzip over the old code and run `./deploy.sh` on the server.

The update adds the new tables and permissions and changes nothing existing. Quotation PDFs that were **already sent** stay exactly as filed, so those keep the old black-background logo. Drafts, approved quotations and anything sent from now on print the logo correctly.

## Next: Phase 5
Procurement and inventory: material requests, purchase requests and orders with approval, GRN, stock ledger, warehouses and site stores.
