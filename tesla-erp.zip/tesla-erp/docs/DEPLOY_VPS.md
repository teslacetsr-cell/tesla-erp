# Deploying TCE ERP on a VPS — erp.teslace.in

Your 8 steps, adjusted to how the ERP is built. The ERP is a **Next.js web UI plus a Python (FastAPI) backend**, not a Node.js server. Both are packed into **one Docker image**, so nothing needs installing by hand beyond Docker.

```
 Browser / phone ──HTTPS──► Caddy (automatic certificate for erp.teslace.in)
                              └─► ERP app (API + web UI) ──► PostgreSQL 16 (container, never exposed)
                                        │
                                        ├─► Cloudflare R2 bucket  tce-erp-documents   (drawings, PDFs, photos)
 nightly 01:30 ── backup.sh ────────────┴─► Cloudflare R2 bucket  tce-erp-backups     (database backups)
```

| Your step | What changed |
|---|---|
| 1. Buy VPS | Unchanged. Choose plain **Ubuntu 24.04**. |
| 2. Install Ubuntu + Docker | One script does it, plus the firewall, security updates and SSH hardening (step 8). |
| 3. Install PostgreSQL | **Don't install it on the server.** It runs as a container with its data in a Docker volume, and is never reachable from the internet. |
| 4. Upload the ERP | `git clone` (or upload the zip). The server builds the image itself. |
| 5. Create Cloudflare R2 | Create **two private buckets**, one for documents and one for backups, each with its own key. |
| 6. Modify ERP file storage | **Already done in code:** R2 rejected the encryption header the ERP used to send, which is now switched off for R2. You only enter the R2 details (`init-env.sh` asks for them). |
| 7. Connect erp.teslace.in | One DNS record. HTTPS is issued and renewed automatically. |
| 8. Backups + security | Nightly backups to R2 (checked, rotated, visible in Settings). Firewall, fail2ban, key-only SSH and automatic updates are set up in step 2. |

Time: about an hour. Cost: the VPS (≈ ₹800–1,200/month) plus R2, which is free up to 10 GB.

---

## Step 1 — Buy the VPS
- **Hostinger KVM 2** (2 vCPU, 8 GB RAM, 100 GB disk) is plenty. KVM 1 (4 GB) also works.
- **Operating system:** plain **Ubuntu 24.04 LTS**.
- **Location:** India if offered; otherwise the nearest Asian location.
- **SSH key:** add one at purchase. On Windows, create it by running `ssh-keygen -t ed25519` in PowerShell and pasting the contents of `C:\Users\<you>\.ssh\id_ed25519.pub`. The server then accepts only your key, not passwords.
- Note the server's **IP address**.

## Step 2 — Prepare the server (Ubuntu + Docker + security)
From your PC:
```bash
scp deploy/vps/setup-server.sh root@<server-ip>:/root/
ssh root@<server-ip> "bash /root/setup-server.sh"
```
The script:
- installs updates and turns on automatic security updates;
- sets the India time zone and adds 2 GB of swap;
- installs Docker;
- sets up the firewall to allow only SSH, HTTP and HTTPS;
- sets up fail2ban;
- creates a **deploy** user;
- turns off root and password login, but only if your SSH key works for `deploy`, so you can't lock yourself out.

From now on, log in as: `ssh deploy@<server-ip>`

## Step 3 — PostgreSQL
Nothing to do. PostgreSQL 16 starts as part of the ERP in step 4:
- **Data:** kept in the Docker volume `tce-erp_pgdata`. It survives restarts, rebuilds and updates.
- **Accounts:** the ERP connects with a restricted account; a separate owner account is used for database upgrades.
- **Network:** no database port is open to the internet.

## Step 4 — Put the ERP on the server
**Recommended:** keep the code in a **private GitHub repository**. Updates are then a `git pull`.
```bash
ssh deploy@<server-ip>
git clone https://github.com/<you>/tesla-erp.git ~/tesla-erp
```
For a private repository, GitHub asks for a username and a *personal access token*: GitHub → Settings → Developer settings → Tokens, with read-only *Contents* access.

**Alternative:** upload the zip with `scp tesla-erp.zip deploy@<server-ip>:~`, then run `unzip tesla-erp.zip` on the server.

## Step 5 — Create Cloudflare R2
In the Cloudflare dashboard, open **R2 Object Storage**. Activating R2 asks for a payment method even for the free tier.

1. **Create bucket** `tce-erp-documents`.
   - Location: *Automatic*, or the *Asia-Pacific* hint.
   - Leave **public access off**. Files are only ever served through the ERP, after a permission check.
2. **Create bucket** `tce-erp-backups`, the same way.
3. **Manage R2 API tokens → Create API token**, twice:
   - Token **"tce-erp-documents"**: permission *Object Read & Write*, **only** the bucket `tce-erp-documents`.
   - Token **"tce-erp-backups"**: permission *Object Read & Write*, **only** the bucket `tce-erp-backups`.
   - Each token shows an **Access Key ID** and a **Secret Access Key**. Copy both at once; the secret is shown only once.
4. Note your **Account ID**, shown on the R2 overview page.

Two keys means a leaked documents key cannot touch the backups, and the web app never holds the backup key.

## Step 6 — Configure the ERP for R2
On the server:
```bash
cd ~/tesla-erp/deploy/vps
./init-env.sh
```
It asks for the web address (`erp.teslace.in`), your email and the R2 details from step 5. It then generates all passwords and encryption keys into `deploy/vps/.env`, readable only by the deploy user.

> **Copy `.env` into your password manager now** (`cat .env`). It contains the key that decrypts supplier and company bank account numbers. A restore onto a new server needs the same file.

The script also prints the **first sign-in password** for the user `admin`. The ERP makes you change it at first sign-in.

## Step 7 — Connect erp.teslace.in
1. Wherever `teslace.in`'s DNS is managed (Cloudflare, or your domain registrar), add:
   - **Type** `A`, **Name** `erp`, **Value** `<server-ip>`.
   - On Cloudflare, set the proxy to **DNS only** (grey cloud), so the server can obtain its own certificate.
2. Wait until `ping erp.teslace.in` shows the server's IP. Usually minutes, sometimes up to an hour.
3. Start the ERP:
   ```bash
   ./deploy.sh
   ```
   The first build takes about 5–10 minutes. The script:
   - checks the DNS record;
   - starts PostgreSQL;
   - creates the tables;
   - starts the ERP and Caddy;
   - schedules the nightly backup.
4. Open **https://erp.teslace.in**, sign in as `admin` with the printed password, and choose your own.
5. Then:
   - **Administration → Company:** add the GSTIN, address and bank details.
   - **Administration → Users:** create your staff accounts.

## Step 8 — Backups and security

### Backups (automatic)
- **When:** every night at **01:30**, `backup.sh` runs. Each run:
  1. dumps the database;
  2. **checks the file is a complete, readable backup**;
  3. uploads it to `tce-erp-backups` with a checksum;
  4. rotates the copies.
- **How many are kept:**
  - in R2: 30 daily, 12 weekly (Sundays) and 24 monthly (1st of the month);
  - on the server: 7 days of local copies.
- **Before updates:** a backup is also taken automatically before every update.
- **Documents** are already stored in R2, which is durable storage, so they need no separate backup.
- **Where to check:** **Settings → System** shows the last backup. If a night fails, administrators see a red warning on the dashboard.
- **Commands:**
  - backup by hand: `./backup.sh`
  - list backups: `./restore.sh --list`
  - log: `/var/log/tce-erp-backup.log`

**Restore** (replaces all current data, and saves the current data first):
```bash
./restore.sh --list
./restore.sh daily/tce_erp_20260927_0130.dump
```
**Server lost entirely?**
1. Set up a new VPS (steps 1–2 and 4).
2. Put your saved `.env` back in `deploy/vps/`.
3. Run `./deploy.sh`.
4. Run `./restore.sh <latest backup>`.

The documents are still in R2. **Practise this once** on a spare VPS; it costs a few rupees for an hour.

### Security (already in place)
| Protection | How |
|---|---|
| Firewall | Only ports 22, 80 and 443 are open (ufw). PostgreSQL has no public port. |
| SSH | Key-only, no root login; fail2ban blocks password guessing. |
| Updates | Ubuntu security updates install automatically. |
| HTTPS | Let's Encrypt certificate, auto-renewed; HSTS; HTTP redirects to HTTPS. Requests to the bare IP get nothing. |
| App | Secure, HttpOnly cookies; account lockout; role permissions; append-only audit log with the real client IP. |
| Secrets | `.env` is readable only by the deploy user and is never committed to git. The two R2 keys are each limited to one bucket. |
| Files | Both buckets are private. Downloads go through the ERP's permission check. |

Optional: in Cloudflare, switch the DNS record to **Proxied** (orange cloud) with SSL mode **Full (strict)**. That hides the server's IP and adds DDoS protection. Do it after the first certificate has been issued.

---

## Everyday commands (as `deploy`, in `~/tesla-erp/deploy/vps`)
| Task | Command |
|---|---|
| Health, certificate expiry, last backup, disk | `./status.sh` |
| Update to a new version | `git -C ~/tesla-erp pull && ./deploy.sh` |
| Roll back to the previous version | `docker image ls tce-erp`, then `APP_VERSION=<older tag> docker compose up -d api worker` |
| Live logs | `docker compose logs -f api` |
| Restart the ERP | `docker compose restart api worker` |
| Backup now / list / restore | `./backup.sh` · `./restore.sh --list` · `./restore.sh <key>` |

**Never run** `docker compose down -v`: `-v` deletes the database volume. Plain `docker compose down` is safe.
