# Phase 10 report — Reports, dashboards, notifications, alerts, search

| | |
|---|---|
| Completed | 8 Oct 2026 |
| Scope | Spec §31 (notifications and email), §33 (role dashboards), §34 (registers and reports), §35 (global search); plan Phase 10. Exit criteria: **each report reconciles with the underlying ledger totals** (automated tests); **the director dashboard loads in under 2 seconds on production-sized data** (measured: 0.25 s with 5,000 invoices, 5,000 receipts, 1,000 orders, 300 projects and 3,000 leads). |
| Tests | New: `test_notifications.py` (12), `test_search.py` (5), `test_dashboards.py` (3) and 2 more in `test_reports.py` (every report as every role; GST / sales / stock / payables against the journal). Email is tested against a fake SMTP server: preferences honoured, retries, permanent failure reported, no password in logs. Alerts: right people, once a day, switches and thresholds, digest. Search: own-scope leads, no finance or HR leaks, under 1 s with 5,000 extra leads. Browser walkthrough (desktop and phone) as director, admin, accounts1, sales1, store1 and employee1: no page errors, no failed API calls. |
| Upgrade | Migration `0010n`: two new tables (`notification_preferences`, `alert_runs`) and 11 trigram search indexes. Nothing existing is changed. `app.seed core` adds the new permission `dashboard.read` to Directors and Managers. Email is optional: add the `SMTP_*` settings (below) when ready. |

## Before staff rely on it — administrator to do

1. **Set up email** (optional, but needed for emailed notifications and the daily summary).
   - VPS: add to `deploy/vps/.env` (new servers are asked by `init-env.sh`), then `./deploy.sh`:
     `SMTP_HOST`, `SMTP_PORT` (587), `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM` (`TCE ERP <erp@teslace.tech>`), `SMTP_TLS` (`starttls`; `ssl` for port 465).
   - Gmail / Google Workspace needs an *App password*; Zoho is `smtp.zoho.in`; Hostinger mail is `smtp.hostinger.com`.
   - `APP_BASE_URL` is set from `ERP_DOMAIN` automatically on the VPS, so links in emails open the ERP.
   - Then `Administration → Settings → Email & notifications → Send test email`.
2. **Check the alert settings** in `Administration → Settings → Alerts`: the hour they go out (8 am by default) and each alert's limits.
3. Tell staff about **My notification settings** (the user menu, top right, or *Settings* in the bell).

## Reports (`Reports` in the menu)

Built earlier in this phase and reviewed now. **35 reports** in six groups; each person sees only the ones their role allows.

| Group | Reports |
|---|---|
| Sales & CRM | Lead register · Lead conversion (win / loss, by salesperson or source) · Enquiry register · Site visit register · Follow-up compliance · Quotation register · Sales order register (billed and balance to bill) · Sales by customer · Sales by month |
| Projects | Project status register · Task register (detail or per employee) · Site report register · BOQ vs installed |
| Purchase | Material request register · Purchase request register · Purchase order register · Pending deliveries · GRN register · Purchases by supplier |
| Inventory | Stock summary · Stock movement (opening, in, out, closing) · Low stock (with quantity on order) · Material issue register |
| Finance | Sales register (GSTR-1 style) · Credit note register · Receipt register · Receivables ageing · Payables ageing · Supplier bill register · Supplier payment register · Expense claim register · Billing vs collections by month |
| HR | Leave register · Attendance summary · Headcount |

**Common to every report**
- Filters as each report needs: period (defaults to this month or this financial year), as-on date, month, customer, supplier, project, employee, salesperson, division, warehouse, item, status, source, group by. Bad values are refused with a plain message, not ignored.
- Totals for money and quantity columns; money is exact (never rounded floating point).
- Click a row to open the document. Up to 5,000 rows on screen; the page says when to narrow the filters.
- **Excel** (formatted numbers, the filter line, who and when) and **PDF** (A4 landscape, company header, totals). Every export is in the audit log.
- Record-level rules apply: a salesperson with *own* scope sees only their own leads, enquiries, quotations and orders in the reports too. Expense, leave and attendance registers need company-wide access (each person's own are on their own pages).

**Reconciliation (automated tests)**
- Sales register and credit-note register = the GST summary = the Output CGST / SGST / IGST ledgers; sales less credit notes = the Sales ledger.
- Input GST on supplier bills = the Input GST ledgers.
- Receivables ageing = Finance → Receivables = the Sundry Debtors ledger. Payables ageing = unpaid supplier bills = the Sundry Creditors ledger = the bill register's balance.
- Stock summary = stock balances = the stock ledger; stock movement for all time closes at the same value.
- Receipt register = posted receipts; sales order *billed* = invoices less credit notes.

**Speed fix:** Finance → Receivables / Payables (and the two ageing reports) now read only the figures they need instead of whole invoices with their lines — much faster with thousands of open invoices.

## Management dashboard (Spec §33; Directors and Managers)

At the top of the dashboard, for the current financial year:
- **Bank & cash** in the ERP books; **to receive** (net of advances) and **to pay** suppliers.
- **Collected this year** against billed, with the percentage.
- **Approvals pending**: all, and how many are waiting for you, with the oldest.
- **Order intake and billing by month** (before GST) — bar chart; point at a month to read its figures.
- **Sales funnel**: leads → enquiries → quotations sent → orders this year, with counts, values and conversion from the step before.
- **Billed vs collected by month** (with GST) — bar chart.
- **Receivables ageing**: not yet due, 1–30, 31–60, 61–90, over 90 days, retention and advances.
- **Top 10 open projects by value**: contract, billed, cost so far, margin (red when negative, amber under 10 %), progress, and a flag when past the target date.

The figures are the same as the reports (*Billing vs collections*, *Receivables ageing*, *Lead conversion*) and Projects → Profitability; tests check this. One request (`GET /api/v1/dashboard/director`) loads it all.

Every other role keeps its tiles (accounts, projects, purchase and stores, HR, quotations, sales pipeline, my day).

## Notifications (Spec §31)

**What people are told** — the event catalogue, in six groups:
- *Approvals*: approval needed; your request approved; rejected (any document type, including leave).
- *Projects & tasks*: added to a project; project status changed; task assigned; task blocked / completed (to the PM); site issue raised / resolved; hindrance in a site report.
- *Purchase & stores*: material request submitted / rejected / closed; purchase request ready to order; goods received; material issue to post / posted to your project; stock check difference.
- *Finance*: expense approved (to pay); your expense paid; supplier payment made.
- *HR*: your leave approved / cancelled.
- *Daily alerts*: see below.

**My notification settings** (user menu → *Notification settings*, or *Settings* in the bell):
- For each kind: **In the ERP** (the bell) on or off, and **Email** on or off. *all / none* per group.
- In the ERP is on for everything by default. Email is on by default for approvals, tasks assigned to you, leave decisions and the stock-check warning.
- **Daily summary email**: one email a day with your alerts and anything unread, instead of a separate email for each alert.
- Works on the phone.

**Email**
- Sent by the background worker, never while someone waits. If the mail server is down, it tries again after 1, 2, 4 and 8 minutes, then gives up; `Settings → Email & notifications` shows emails sent, waiting and failed in the last 7 days and the last error.
- Plain text plus a simple branded HTML version, with an *Open in the ERP* link to the exact page and a link to change your settings.
- The SMTP password is read from the server settings only — never stored in the database or written to a log.

**WhatsApp / SMS**: the channel interface is ready (`app/platform/notifications/channels.py`). No provider is connected. Setting `WHATSAPP_PROVIDER=log` or `SMS_PROVIDER=log` switches on a test channel that writes *that* a message would go to a (masked) number, so the settings and wiring can be tried. Connecting a provider (e.g. Meta WhatsApp Cloud API, an Indian SMS gateway with DLT templates) is one new adapter class; no business code changes.

## Daily alerts (`Administration → Settings → Alerts`)

Once a day, at or after the hour set (India time), the worker sends each person **one notification per alert** listing what needs their attention (first four items, then "and N more"), linked to the page where they act.

| Alert | Goes to | Setting(s) |
|---|---|---|
| Customer invoices overdue | Accounts, and the sales person of the order (or the customer's assigned sales person) | `alerts.invoice_overdue`, overdue by more than `alerts.invoice_overdue_days` (0) |
| Supplier bills due | Accounts | `alerts.bill_due`, due within `alerts.bill_due_days` (3) or overdue |
| Projects past target date | The project manager (Managers when none) | `alerts.project_late` |
| No daily site report | The project manager | `alerts.site_report_gap`, for more than `alerts.site_report_days` (3) |
| Low or out-of-stock items | Stores and Purchase | `inventory.low_stock_alerts` |
| Tasks overdue | The person assigned and the project manager | `alerts.task_overdue` |
| Approvals waiting too long (leave and every other request) | Whoever can decide the current step (e.g. the line manager for leave) | `alerts.approval_waiting`, more than `alerts.approval_waiting_days` (2) |
| Purchase orders past delivery date | Purchase and the person who raised the PO | `alerts.po_late`, `alerts.po_late_days` (0) |
| Vendor quotations past reply date | Purchase and the person who sent the RFQ | `alerts.rfq_due` |

- Time: `alerts.run_hour` (8). **Run today's alerts now** in Settings does the same immediately.
- **Once a day only**: each alert records its run for the day, so a restart, a second worker or pressing *Run now* again sends nothing more. The last few days' runs are listed in Settings.
- Whether each alert is also emailed is each person's choice (My notification settings).

## Global search (top bar; `Ctrl K`, `⌘K` on Mac)

- Searches customers, leads, enquiries, site visits, quotations, sales orders, projects, tasks, BOQs, invoices, receipts, suppliers, items, material requests, purchase requests, vendor quotation requests, purchase orders, GRNs, material issues, supplier bills, supplier payments, expense claims and employees — by number, name, customer or supplier name, references (customer PO, supplier invoice number, UTR) and more.
- Results are grouped with labels; an exact or starting document number comes first.
- **Arrow keys** to move, **Enter** to open, **Esc** to close. **Recent searches** and opened results show when the box is empty (kept on that browser only).
- **Only what you may open**: each kind needs its read permission; *own* scope applies (a salesperson finds only their own leads, quotations and orders; an employee only their own expense claims and tasks). Employees are found by name, code and designation only — no personal, bank or salary details.
- Fast as the data grows: trigram indexes on the searched names and numbers.

## Settings and server variables (new)

| Variable | Default | Meaning |
|---|---|---|
| `APP_BASE_URL` | (VPS: `https://ERP_DOMAIN`) | Address used for links in emails |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`, `SMTP_TLS` | empty, 587, –, –, –, `starttls` | Outgoing email; empty host = no email |
| `WHATSAPP_PROVIDER`, `SMS_PROVIDER` | `none` | `log` = test channel that only logs |

Company settings (Administration → Settings → Alerts): listed in the table above.

## Permissions (new)

| Permission | Who has it by default |
|---|---|
| `dashboard.read` — management dashboard | Administrators, Directors, Managers |

Sending a test email and running alerts now need `settings.update` (Administrators); the email status and alert history need `settings.read`. Notification settings are each person's own.

## Not in Phase 10

- A real WhatsApp / SMS provider (the interface and a test channel are ready).
- AMC-due alerts: they come with the Service / AMC module (Phase 9).
- Searching inside uploaded documents (file contents).
- Per-person dashboards that can be rearranged.
