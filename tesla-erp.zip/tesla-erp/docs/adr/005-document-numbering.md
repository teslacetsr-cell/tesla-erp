# ADR 005: Transaction-safe, configurable numbering

**Status:** Accepted — Phase 1, 25 Sep 2026

## Context
Spec §29: two users must never get the same number. Approved 25 Sep 2026: financial-year numbering.

## Decision
document_sequences row per (company, type, period) incremented with INSERT … ON CONFLICT DO UPDATE … RETURNING inside the saving transaction. Patterns are data (numbering_formats) with tokens {FY} {FYS} {FYY} {YYYY} {SEQ:n}; tax invoices are validated to ≤16 characters.

## Consequences
No duplicates, no gaps from failed saves; formats change without code. Numbers are taken at issue, not at draft.
