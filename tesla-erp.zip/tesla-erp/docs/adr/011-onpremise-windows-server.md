# ADR 011: On-premise Windows server with NAS storage

**Status:** Accepted — 25 Sep 2026 (requested by Tesla Consulting Engineers)

## Context
The company asked for the ERP as a Windows .exe with documents on the office network, a desktop app on each PC, and remote access for site engineers.

## Decision
- **One installer, two roles.**
  - **Office server:** `TCE-ERP-Server.exe`, run as the Windows service `TCE-ERP` through WinSW. It supervises:
    - an embedded PostgreSQL 16, registered as the service `TCE-ERP-Database` and running as NETWORK SERVICE;
    - the API and the web UI (a Next.js static export served by the same process);
    - background jobs;
    - nightly backups to the NAS;
    - the optional Cloudflare Tunnel connector.
  - **Desktop app:** `TCE ERP.exe`, built on pywebview / WebView2, pointing at the server.
- **Storage.** A new `filesystem` storage backend writes documents atomically to a NAS share. It is allowed in production when `DEPLOYMENT=onprem`; the `local` backend remains development-only. The database stays on the server's local disk.
- **Credentials.** NAS credentials are registered for the service with `net use`. All secrets are stored with DPAPI (machine scope).
- **First run.** A setup wizard on `http://localhost:8080/setup` (loopback only) collects the NAS folder, the administrator, and the tunnel token. It creates the database, runs migrations, and proves the backup path by taking a backup.
- **Cookies.** Office-network traffic is plain HTTP; remote traffic arrives over HTTPS through the tunnel. The Secure cookie flag is decided per request on-premise. Proxy headers are trusted only from localhost, where the tunnel connector runs.
- **Routes.** Record pages use query parameters (`/customers/view?id=…`) so the UI can be exported as static files.

## Consequences
- **No Node.js, Docker or database installation for the office.** Everything ships in one installer.
- **The office now operates the server.** It must keep the server PC on and protect the NAS.
  - Backups are automatic, checksummed and test-read.
  - Their status is visible in Settings and on the dashboard.
- **The cloud deployment path is unchanged.** Both run from the same codebase. Deployment mode is chosen with `DEPLOYMENT=cloud|onprem`.
- **Windows-specific pieces can only be verified on Windows:** DPAPI, `net use`, the services and the installer. The Windows build pipeline runs an end-to-end smoke test before publishing an installer.
