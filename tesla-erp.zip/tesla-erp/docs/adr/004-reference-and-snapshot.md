# ADR 004: Reference the master; snapshot on issue

**Status:** Accepted — Phase 1, 25 Sep 2026

## Context
Spec §43 forbids copying customer data into modules; tax invoices must show details as at issue.

## Decision
Modules hold foreign keys to masters. When a document is issued, legally significant fields (name, address, GSTIN, place of supply) are frozen onto that document, read-only.

## Consequences
Masters stay the single source of truth for current data; issued documents remain legally correct forever.
