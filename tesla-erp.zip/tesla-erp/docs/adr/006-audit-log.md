# ADR 006: Append-only audit log enforced by the database

**Status:** Accepted — Phase 1, 25 Sep 2026

## Context
Spec §32: audit logs must not be editable by ordinary users.

## Decision
audit_logs written by the service layer in the same transaction as the change, with field-level old/new values. The app DB role has no UPDATE/DELETE/TRUNCATE on it, and a trigger rejects those operations for every role, including the owner.

## Consequences
Tampering requires dropping the trigger with owner credentials, which is itself visible in infrastructure logs.
