# ADR 008: PostgreSQL-backed background jobs

**Status:** Accepted — Phase 1, 25 Sep 2026

## Context
PDFs, email and reminders need background processing (Spec §31).

## Decision
A jobs table claimed with FOR UPDATE SKIP LOCKED by a separate worker process; jobs are enqueued inside the business transaction.

## Consequences
No Redis/broker to run. A job exists if and only if the change that caused it committed. Revisit if volume grows by orders of magnitude.
