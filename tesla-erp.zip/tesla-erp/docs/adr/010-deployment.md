# ADR 010: Stateless containers, managed data services

**Status:** Accepted — Phase 1, 25 Sep 2026

## Context
Spec §38/§50: redeployment must never lose data.

## Decision
Three containers (web, api, worker) from two images; all state in RDS PostgreSQL and S3 (versioned, Object Lock for issued documents). Local storage is refused by configuration outside development.

## Consequences
Any server can be replaced at any time. Topology (ECS Fargate vs single EC2) is a cost decision pending AWS account details (Q11).
