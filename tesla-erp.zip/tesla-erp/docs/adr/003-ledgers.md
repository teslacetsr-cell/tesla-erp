# ADR 003: Balances are derived from immutable ledgers

**Status:** Accepted — Phase 1, 25 Sep 2026

## Context
Stock, project cost and receivables must always reconcile (Spec §19, §24, §44).

## Decision
Stock, project cost and AR/AP (Phases 5–7) are append-only ledger tables; balances are cached projections updated in the same transaction and verifiable by rebuild.

## Consequences
Nothing is ever 'typed in' as a balance. Corrections are reversing entries.
