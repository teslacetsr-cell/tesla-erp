# Architecture Decision Records

Each record: context → decision → consequences. Status of all below: **Accepted (Phase 1)**.

- [001 — Technology stack](001-technology-stack.md)
- [002 — Money and quantities are never floating point](002-money-and-quantities.md)
- [003 — Balances are derived from immutable ledgers](003-ledgers.md)
- [004 — Reference the master; snapshot on issue](004-reference-and-snapshot.md)
- [005 — Transaction-safe, configurable numbering](005-document-numbering.md)
- [006 — Append-only audit log enforced by the database](006-audit-log.md)
- [007 — Short-lived JWT + rotating refresh cookie](007-authentication.md)
- [008 — PostgreSQL-backed background jobs](008-job-queue.md)
- [009 — Server-side PDFs with HTML templates](009-pdf-engine.md)
- [010 — Stateless containers, managed data services](010-deployment.md)
- [011 — On-premise Windows server with NAS storage](011-onpremise-windows-server.md)
