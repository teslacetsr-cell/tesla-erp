# ADR 007: Short-lived JWT + rotating refresh cookie

**Status:** Accepted — Phase 1, 25 Sep 2026

## Context
Spec §3 and §37: JWT/session security, refresh tokens, optional 2FA.

## Decision
15-minute access JWT held in memory; 7-day opaque refresh token stored hashed, sent as HttpOnly SameSite=Strict cookie scoped to /api/v1/auth, rotated on every use with family revocation on reuse; CSRF double-submit on cookie endpoints; session_version on users for instant revocation; Argon2id; lockout after 5 failures; user_mfa table for 2FA.

## Consequences
XSS cannot read the refresh token; a stolen refresh token is detected on reuse; admins can cut a user off instantly.
