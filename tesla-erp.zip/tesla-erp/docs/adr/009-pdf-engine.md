# ADR 009: Server-side PDFs with HTML templates

**Status:** Accepted — Phase 1, 25 Sep 2026

## Context
Quotations, POs, invoices and reports need consistent professional PDFs (Spec §3).

## Decision
Jinja2 HTML/CSS templates rendered by WeasyPrint in the worker (introduced in Phase 2/3), stored write-once in object storage.

## Consequences
Designers can adjust templates with CSS; issued PDFs never change after issue.
