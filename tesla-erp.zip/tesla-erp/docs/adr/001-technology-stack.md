# ADR 001: Technology stack

**Status:** Accepted — Phase 1, 25 Sep 2026

## Context
Spec §3 recommends Next.js/React/TypeScript, FastAPI/Pydantic/SQLAlchemy/Alembic and PostgreSQL.

## Decision
Adopt it unchanged: Next.js 16 (App Router) + Tailwind 4, FastAPI with synchronous SQLAlchemy 2 over psycopg 3, Alembic, PostgreSQL 16.

## Consequences
Synchronous database access keeps row-locking and transaction code simple and is ample for this user count; FastAPI runs sync handlers in a thread pool.
