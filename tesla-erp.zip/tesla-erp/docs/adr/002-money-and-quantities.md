# ADR 002: Money and quantities are never floating point

**Status:** Accepted — Phase 1, 25 Sep 2026

## Context
Rounding errors in invoices, GST and stock value are unacceptable.

## Decision
NUMERIC(18,2) amounts, NUMERIC(18,4) rates, NUMERIC(18,3) quantities, NUMERIC(7,4) percentages; Python Decimal with ROUND_HALF_UP in app/core/money.py; money is serialised to JSON as strings.

## Consequences
JavaScript never sees a float for money. Arithmetic lives in the backend.
