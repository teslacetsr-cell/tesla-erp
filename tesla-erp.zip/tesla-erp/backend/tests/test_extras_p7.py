"""Phase 7 extras: every login gets an employee record; an accepted quotation can be ordered again after its order
is cancelled (and an accepted quotation can be cancelled and reinstated); quick customer creation from a quotation."""
from tests.test_finance import err, get, post
from tests.test_projects import accepted_quote, make_so

API = "/api/v1"


def _user(client, admin_headers, username, email, **kw):
    return post(client, admin_headers, "/users", {"username": username, "email": email, "full_name": kw.pop("name", "New Person"),
                                                 "role_codes": ["EMPLOYEE"], "temporary_password": "Temp@Pass-2026", **kw})


def test_new_user_gets_an_employee_record(client, admin_headers):
    desig = get(client, admin_headers, "/designations", q="Technician")[0]
    u = _user(client, admin_headers, "tech7", "tech7@example.in", name="Kiran Joseph", phone="9847000007",
              designation_id=desig["id"])
    assert u["employee"]["employee_code"].startswith("TCE")
    emp = get(client, admin_headers, f"/employees/{u['employee']['id']}")
    assert (emp["full_name"], emp["email"], emp["user_id"], emp["designation"]) == \
        ("Kiran Joseph", "tech7@example.in", u["id"], "Technician")
    # renaming the login renames the employee
    post_put = client.put(f"{API}/users/{u['id']}", headers=admin_headers, json={
        "email": "tech7@example.in", "full_name": "Kiran K. Joseph", "phone": "9847000007",
        "role_codes": ["EMPLOYEE"], "is_active": True, "row_version": u["row_version"]})
    assert post_put.status_code == 200, post_put.text
    assert get(client, admin_headers, f"/employees/{u['employee']['id']}")["full_name"] == "Kiran K. Joseph"
    # the users list shows the link
    listed = [x for x in get(client, admin_headers, "/users", q="tech7") if x["username"] == "tech7"][0]
    assert listed["employee"]["employee_code"] == u["employee"]["employee_code"]


def test_existing_employee_is_linked_not_duplicated(client, admin_headers):
    emp = post(client, admin_headers, "/employees", {"full_name": "Asha Thomas", "email": "asha@example.in"})
    u = _user(client, admin_headers, "asha", "asha@example.in", name="Asha Thomas")
    assert u["employee"]["id"] == emp["id"]
    rows = get(client, admin_headers, "/employees", q="Asha Thomas")
    assert len(rows) == 1 and rows[0]["user_id"] == u["id"]
    # or an explicit choice; one employee cannot have two logins
    emp2 = post(client, admin_headers, "/employees", {"full_name": "Babu Raj"})
    u2 = _user(client, admin_headers, "babu", "babu.r@example.in", name="Babu Raj", employee_id=emp2["id"])
    assert u2["employee"]["id"] == emp2["id"]
    code = err(client, admin_headers, "/users", {"username": "babu2", "email": "b2@example.in", "full_name": "Babu Raj",
                                                 "role_codes": ["EMPLOYEE"], "temporary_password": "Temp@Pass-2026",
                                                 "employee_id": emp2["id"]})
    assert code == (409, "EMPLOYEE_ALREADY_LINKED")
    assert client.get(f"{API}/users", headers=admin_headers, params={"q": "babu2"}).json()["data"] == []


def test_backfill_gives_old_logins_an_employee(client, admin_headers):
    from sqlalchemy import select

    from app.core.db import SessionLocal
    from app.hr.models import Employee
    from app.hr.service import backfill
    from app.users.models import User

    with SessionLocal() as s:
        u = User(username="legacy", email="legacy@example.in", full_name="Legacy User", password_hash="!")
        s.add(u)
        s.commit()
        company_id = s.scalar(select(__import__("app.company.models", fromlist=["Company"]).Company.id))
        assert backfill(s, company_id, None) == 1
        assert backfill(s, company_id, None) == 0
        s.commit()
        assert s.scalar(select(Employee.full_name).where(Employee.user_id == u.id)) == "Legacy User"
        admin = s.scalar(select(User.id).where(User.username == "admin"))
        assert s.scalar(select(Employee.id).where(Employee.user_id == admin)) is None  # system login, not a person


def test_place_order_again_after_cancellation(client, as_user):
    s = as_user("sales1")
    q = accepted_quote(client, s)
    so1 = make_so(client, s, q)
    r = client.post(f"{API}/sales-orders/{so1['id']}/status", headers=s,
                    json={"status": "cancelled", "reason": "Client put the project on hold"})
    assert r.status_code == 200, r.text
    so1 = r.json()["data"]
    assert so1["can"]["place_again"] is True and so1["replaced_by"] is None
    qd = get(client, s, f"/quotations/{q['id']}")
    assert qd["status"] == "accepted" and qd["sales_order"] is None and qd["can"]["create_sales_order"] is True
    assert [o["so_number"] for o in qd["cancelled_orders"]] == [so1["so_number"]]
    # the client comes back: order the same accepted revision again
    so2 = make_so(client, s, q, customer_po_number="PO-778-R")
    assert so2["so_number"] != so1["so_number"] and so2["grand_total"] == so1["grand_total"]
    assert so2["quotation_id"] == q["id"] and so2["status"] == "confirmed"
    assert get(client, s, f"/sales-orders/{so1['id']}")["replaced_by"]["so_number"] == so2["so_number"]
    # still only one live order at a time
    r = client.post(f"{API}/quotations/{q['id']}/sales-order", headers=s, json={})
    assert r.status_code == 409 and r.json()["error"]["code"] == "SO_EXISTS"


def test_cancel_and_reinstate_accepted_quotation(client, as_user):
    s = as_user("sales1")
    q = accepted_quote(client, s)
    so = make_so(client, s, q)
    # the open order must be cancelled first, and a reason is needed
    r = client.post(f"{API}/quotations/{q['id']}/cancel", headers=s, json={"reason": "Client cancelled"})
    assert r.status_code == 409 and r.json()["error"]["code"] == "SO_ACTIVE"
    post(client, s, f"/sales-orders/{so['id']}/status", {"status": "cancelled", "reason": "Client cancelled"})
    assert err(client, s, f"/quotations/{q['id']}/cancel", {})[1] == "REASON_REQUIRED"
    q = post(client, s, f"/quotations/{q['id']}/cancel", {"reason": "Client cancelled the project"})
    assert q["status"] == "cancelled" and q["can"]["reinstate"] is True and q["can"]["create_sales_order"] is False
    assert get(client, s, f"/sales-orders/{so['id']}")["can"]["place_again"] is False
    q = post(client, s, f"/quotations/{q['id']}/reinstate", {"reason": "Client confirmed again"})
    assert q["status"] == "accepted" and q["accepted_revision_no"] is not None
    so2 = make_so(client, s, q)
    assert so2["status"] == "confirmed"
    # a quotation that was never accepted cannot be reinstated
    from tests.test_quotations import line, new_quote

    q2 = post(client, s, f"/quotations/{new_quote(client, s, [line()])['id']}/cancel", {"reason": "Duplicate"})
    assert err(client, s, f"/quotations/{q2['id']}/reinstate", {})[1] == "NEVER_ACCEPTED"


def test_quick_customer_from_quotation_form(client, as_user):
    """The quotation form's 'New customer' creates through the normal customer API (duplicate check included)."""
    s = as_user("sales1")
    dups = get(client, s, "/customers/duplicate-check", name="ABC Hospital")
    assert dups and dups[0]["customer_name"] == "ABC Hospital"
    c = post(client, s, "/customers", {"customer_name": "Sunrise Clinic", "customer_type": "hospital", "phone": "9847011122",
                                       "city": "Kochi", "state_code": "32"})
    assert c["customer_code"].startswith("CUS") and c["assigned_sales_person_id"]
    from tests.test_quotations import line, new_quote

    q = new_quote(client, s, [line()], customer_id=c["id"])
    assert q["customer"]["id"] == c["id"]
