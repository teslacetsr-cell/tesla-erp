"""Incentive calculation with the four reference bills (policy test cases), one employee in each role, all paid in
full in the same month."""
from datetime import date
from decimal import Decimal as D

from app.incentives import defaults
from app.incentives import engine as E

YM = "2026-11"
PAID = date(2026, 11, 18)
NAMES = {"am": "Asha", "bde": "Biju", "je": "Jithin", "pe": "Pradeep", "acc": "Anju", "oa": "Omana", "dm": "Deepu"}


def scheme():
    rules = [E.Rule(id=i, role_id=r["role"], role_name=r["role"], label=r["label"], trigger=r["trigger"], basis=r["basis"],
                    value=r["value"], categories=tuple(r["categories"]), govt=r["govt"], tender=r["tender"],
                    requires_ei_kseb=r["requires_ei_kseb"]) for i, r in enumerate(defaults.RULES)]
    members = {code: [E.Member(code + "-1", NAMES[code])] for code, _ in defaults.ROLES}
    return rules, members


def bill(no, amount, final=False, paid=PAID):
    return E.Bill(id=no, number=no, bill_date=date(2026, 11, 3), amount=D(amount), final=final, paid_date=paid)


def four_projects():
    return [
        # A) private solar ₹5,00,000, EI & KSEB yes, subsidy done, final bill
        E.Project(id="A", label="A", category="solar", ei_kseb=True, contract_value=D("500000"), subsidy_done=True,
                  subsidy_date=PAID, bills=[bill("A1", "500000", final=True)]),
        # B) private lightning protection ₹2,00,000
        E.Project(id="B", label="B", category="lps", contract_value=D("200000"), bills=[bill("B1", "200000")]),
        # C) consulting only ₹1,00,000
        E.Project(id="C", label="C", category="consulting", contract_value=D("100000"), bills=[bill("C1", "100000")]),
        # D) govt electrical from tender ₹10,00,000, EI & KSEB no
        E.Project(id="D", label="D", category="electrical", is_govt=True, from_tender=True,
                  contract_value=D("1000000"), bills=[bill("D1", "1000000")]),
    ]


def by_role(lines):
    t = E.totals_by_employee(lines)
    return {code: t.get(code + "-1", D(0)) for code, _ in defaults.ROLES}


EXPECTED = {"am": D("1100"), "bde": D("11500"), "je": D("3750"), "pe": D("4000"), "oa": D("630"), "dm": D("875")}


def test_reference_bills_without_accounts_proper():
    rules, members = scheme()
    got = by_role(E.lines_for_month(YM, rules, four_projects(), members, accounts_proper=False))
    assert {k: got[k] for k in EXPECTED} == EXPECTED
    assert got["acc"] == 0


def test_reference_bills_with_accounts_proper_and_welfare():
    rules, members = scheme()
    projects = four_projects()
    got = by_role(E.lines_for_month(YM, rules, projects, members, accounts_proper=True))
    assert {k: got[k] for k in EXPECTED} == EXPECTED
    assert got["acc"] == D("1800")
    billed, by_cat, n = E.billed_in(YM, projects)
    assert (billed, n) == (D("1800000"), 4)
    assert E.welfare(billed, defaults.WELFARE_PCT) == D("9000")


def test_split_nobody_month_and_inactive():
    rules, members = scheme()
    members["pe"] = [E.Member("pe-1", "Pradeep"), E.Member("pe-2", "Prasanth"), E.Member("pe-3", "Old", active=False)]
    projects = four_projects()
    projects[1].team = {"bde": "none"}             # nobody earns the BD share on B
    projects[3].team = {"pe": "pe-2"}              # only Prasanth on D
    lines = E.lines_for_month(YM, rules, projects, members, accounts_proper=False)
    t = E.totals_by_employee(lines)
    # PE: A solar 2,500 and B lps 500 split between the two active PEs; D's 1,000 to Prasanth alone
    assert t["pe-1"] == D("1500") and t["pe-2"] == D("2500") and "pe-3" not in t
    assert t["bde-1"] == D("7500")                 # 11,500 − the 4,000 on B
    assert all(ln.split == 2 for ln in lines if ln.employee_id == "pe-1")
    # a bill paid in another month counts in that month, not this one
    projects[2].bills[0].paid_date = date(2026, 12, 2)
    assert E.totals_by_employee(E.lines_for_month(YM, rules, projects, members, False)).get("je-1") == D("1250")
    assert E.totals_by_employee(E.lines_for_month("2026-12", rules, projects, members, False))["je-1"] == D("2500")


def test_subsidy_uses_bill_sum_when_contract_value_is_zero_and_final_once():
    rules, members = scheme()
    p = E.Project(id="S", label="S", category="solar", ei_kseb=True, subsidy_done=True, subsidy_date=PAID,
                  bills=[bill("S1", "300000"), bill("S2", "100000", final=True, paid=date(2027, 1, 5))])
    lines = E.lines_for_month(YM, rules, [p], members, False)
    sub = [ln for ln in lines if ln.trigger == "subsidy" and ln.employee_id == "am-1"]
    assert sub and sub[0].base == D("400000") and sub[0].amount == D("400")
    assert not [ln for ln in lines if ln.trigger == "finalPaid"]          # final bill not yet paid
    jan = E.lines_for_month("2027-01", rules, [p], members, False)
    assert sum(ln.amount for ln in jan if ln.trigger == "finalPaid" and ln.employee_id == "je-1") == D("1000")


def test_incentives_start_three_months_after_joining():
    rules, members = scheme()
    joined = date(2026, 9, 1)
    eligible = E.add_months(joined, 3)
    assert eligible == date(2026, 12, 1) and E.add_months(date(2026, 11, 30), 3) == date(2027, 2, 28)
    # two project engineers: the senior one and a new joiner still in the qualifying period on 18 Nov
    members["pe"] = [E.Member("pe-1", "Pradeep"), E.Member("pe-2", "New", eligible_from=eligible)]
    members["acc"] = [E.Member("acc-1", "Anju", eligible_from=date(2026, 11, 30))]
    projects = four_projects()
    projects[3].team = {"pe": "pe-2"}                       # the new joiner is the one named on D
    lines = E.lines_for_month(YM, rules, projects, members, accounts_proper=True)
    t = E.totals_by_employee(lines)
    assert "pe-2" not in t                                   # nothing before eligibility …
    assert t["pe-1"] == D("3000")                            # … the senior PE keeps the full A + B share (not split),
    assert not [ln for ln in lines if ln.project_id == "D" and ln.role_id == "pe"]   # and D's named share is not paid
    assert all(ln.split == 1 for ln in lines if ln.employee_id == "pe-1")
    assert t["acc-1"] == D("1800")                           # monthly rule judged on the last day of the month
    # once eligible, the new joiner earns: a December payment on D goes to them
    for b in projects[3].bills:
        b.paid_date = date(2026, 12, 4)
    dec = E.totals_by_employee(E.lines_for_month("2026-12", rules, projects, members, False))
    assert dec["pe-2"] == D("1000")
