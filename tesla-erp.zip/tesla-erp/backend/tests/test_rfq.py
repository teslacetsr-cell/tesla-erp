"""Vendor quotations: RFQ from a purchase / material request, RFQ PDFs and Excel reply forms, reading filled forms,
manual and AI-assisted entry, the comparison (L1 per line and overall, freight, last price), the buyer's choice and
purchase orders split by supplier."""
import io
import json
from decimal import Decimal as D

import pytest
from openpyxl import load_workbook

from tests.test_purchase import API, approve_all, get, item, post, supplier

LINES = [("LP-AT-16", "10"), ("EA-ELEC-3M", "4"), ("EA-GI-50X6", "100")]


def put(client, h, path, body, status=(200,)):
    r = client.put(f"{API}{path}", headers=h, json=body)
    assert r.status_code in status, r.text
    return r.json()["data"]


def approved_pr(client, as_user) -> dict:
    h = as_user("purchase1")
    lines = []
    for code, qty in LINES:
        it = item(client, h, code)
        lines.append({"item_id": it["id"], "description": it["item_name"], "unit": it["unit"], "quantity": qty,
                      "estimated_rate": "1000"})
    pr = post(client, h, "/purchase-requests", {"lines": lines})
    pr = post(client, h, f"/purchase-requests/{pr['id']}/submit")
    approve_all(client, as_user, pr["pr_number"])
    pr = get(client, h, f"/purchase-requests/{pr['id']}")
    assert pr["status"] == "approved"
    return pr


def make_rfq(client, h, pr) -> dict:
    dehn = supplier(client, h)
    return post(client, h, "/rfqs", {
        "purchase_request_id": pr["id"], "supplier_ids": [dehn["id"]], "due_date": "2099-01-31",
        "new_suppliers": [{"supplier_name": "Kerala Electricals", "phone": "9847012345"},
                          {"supplier_name": "Malabar Traders", "email": "sales@malabar-demo.in"}]})


def download(client, h, path) -> bytes:
    r = client.get(f"{API}{path}", headers=h)
    assert r.status_code == 200, r.text
    return r.content


def fill_template(data: bytes, header: dict, rates: dict) -> bytes:
    """Fill a downloaded reply form like a supplier would. rates: {line_no: (rate, disc, gst, make, days)}."""
    wb = load_workbook(io.BytesIO(data))
    ws = wb["Quotation"]
    head = next(r for r in range(1, ws.max_row + 1) if ws.cell(r, 1).value == "Line no")
    for r in range(1, head):
        lbl = ws.cell(r, 1).value
        if lbl in header:
            ws.cell(r, 3).value = header[lbl]
    for r in range(head + 1, ws.max_row + 1):
        no = ws.cell(r, 1).value
        if no in rates:
            for col, v in zip((7, 8, 9, 10, 11), rates[no], strict=True):
                ws.cell(r, col).value = v
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


def upload(client, h, path, data: bytes, name="reply.xlsx", **params):
    return client.post(f"{API}{path}", headers=h, params=params, files={"file": (name, data)})


def by_name(rfq: dict) -> dict:
    return {q["supplier"]["name"]: q for q in rfq["quotations"]}


# ------------------------------------------------------------------ the whole flow
def test_rfq_from_pr_to_purchase_orders(client, as_user):
    h = as_user("purchase1")
    pr = approved_pr(client, as_user)
    rfq = make_rfq(client, h, pr)
    assert rfq["status"] == "draft" and rfq["rfq_number"] is None and rfq["purchase_request"]["id"] == pr["id"]
    assert [ln["pr_line_id"] for ln in rfq["lines"]] == [ln["id"] for ln in pr["lines"]]
    assert [ln["quantity"] for ln in rfq["lines"]] == ["10", "4", "100"]
    assert rfq["lines"][0]["specification"] is None or isinstance(rfq["lines"][0]["specification"], str)
    q = by_name(rfq)
    assert set(q) == {"DEHN India Pvt Ltd", "Kerala Electricals", "Malabar Traders"}
    assert all(x["status"] == "awaited" for x in q.values())
    # the new suppliers are in the supplier master, with codes
    assert get(client, h, "/suppliers", q="Malabar")[0]["supplier_code"].startswith("SUP")

    # outputs: one PDF per supplier, all suppliers in one PDF, and an Excel reply form per supplier
    assert download(client, h, f"/rfqs/{rfq['id']}/pdf")[:4] == b"%PDF"
    dehn, kerala, malabar = q["DEHN India Pvt Ltd"], q["Kerala Electricals"], q["Malabar Traders"]
    assert download(client, h, f"/rfqs/{rfq['id']}/pdf?quotation_id={dehn['id']}")[:4] == b"%PDF"
    t_dehn = download(client, h, f"/rfqs/{rfq['id']}/quotations/{dehn['id']}/template")
    t_kerala = download(client, h, f"/rfqs/{rfq['id']}/quotations/{kerala['id']}/template")
    assert t_dehn[:2] == b"PK" and t_kerala[:2] == b"PK"
    rfq = get(client, h, f"/rfqs/{rfq['id']}")
    assert rfq["rfq_number"].startswith("TCE/RFQ/")  # numbered when it first leaves the office
    ws = load_workbook(io.BytesIO(t_dehn))["Quotation"]
    assert ws.column_dimensions["N"].hidden  # the RFQ line id column

    rfq = post(client, h, f"/rfqs/{rfq['id']}/send", {"row_version": rfq["row_version"]})
    assert rfq["status"] == "sent" and rfq["can"]["quote"]

    # vendor 1 and 2 send back the filled Excel form
    filled = fill_template(t_dehn, {"Your quotation no.": "DEHN/Q/77", "Payment terms": "30 days",
                                    "Freight (Included, or amount extra in ₹)": "Included", "Warranty": "5 years"},
                           {1: (1800, 5, 18, "DEHN", 7), 2: (3000, None, 18, None, 10), 3: (160, 0, 18, None, 10)})
    r = upload(client, h, f"/rfqs/{rfq['id']}/quotations/{dehn['id']}/import", filled)
    assert r.status_code == 200, r.text
    res = r.json()["data"]
    assert res["saved"] and res["errors"] == []
    filled = fill_template(t_kerala, {"Your quotation no.": "KE-12", "Freight (Included, or amount extra in ₹)": "2,500",
                                      "Validity (valid until date, or days)": "30 days"},
                           {1: (1750, 0, 18, "Kingsmen", 5), 2: ("3,100", 0, 18, None, 5), 3: (150, 0, 18, None, 5)})
    res = upload(client, h, f"/rfqs/{rfq['id']}/quotations/{kerala['id']}/import", filled).json()["data"]
    assert res["saved"], res
    # vendor 3 sent a PDF: rates entered by hand; they did not quote the GI strip
    lid = [ln["id"] for ln in rfq["lines"]]
    rfq = put(client, h, f"/rfqs/{rfq['id']}/quotations/{malabar['id']}", {
        "quote_ref": "MT/889", "payment_terms": "Advance", "freight_included": True, "lines": [
            {"rfq_line_id": lid[0], "unit_rate": "1900", "gst_pct": "18"},
            {"rfq_line_id": lid[1], "unit_rate": "2800", "gst_pct": "18", "make": "Generic"},
            {"rfq_line_id": lid[2], "not_quoted": True}]})
    assert rfq["status"] == "quotes_received"
    q = by_name(rfq)
    assert (q["DEHN India Pvt Ltd"]["taxable"], q["DEHN India Pvt Ltd"]["gst"], q["DEHN India Pvt Ltd"]["grand_total"]) \
        == ("45100.00", "8118.00", "53218.00")  # 17100 + 12000 + 16000, GST 18 %
    assert q["DEHN India Pvt Ltd"]["source"] == "excel" and q["DEHN India Pvt Ltd"]["quote_ref"] == "DEHN/Q/77"
    assert q["DEHN India Pvt Ltd"]["lines"][0]["make"] == "DEHN" and q["DEHN India Pvt Ltd"]["warranty"] == "5 years"
    ke = q["Kerala Electricals"]
    assert (ke["freight_included"], ke["freight_amount"], ke["grand_total"]) == (False, "2500.00", "55482.00")
    assert ke["valid_until"] is not None
    # the uploaded file is kept with the supplier's quotation
    docs = get(client, h, "/documents", entity_type="vendor_quotation", entity_id=ke["id"])
    assert len(docs) == 1 and docs[0]["category"] == "quotation"

    # comparison: L1 per line and overall (complete quotations only; freight counted)
    cmp = get(client, h, f"/rfqs/{rfq['id']}/comparison")
    sid = {s["supplier"]["name"]: s["quotation_id"] for s in cmp["suppliers"]}
    l1 = [[next(n for n, i in sid.items() if i == x) for x in ln["l1"]] for ln in cmp["lines"]]
    assert l1 == [["DEHN India Pvt Ltd"], ["Malabar Traders"], ["Kerala Electricals"]]
    ranks = {s["supplier"]["name"]: (s["rank"], s["basis_total"], s["complete"]) for s in cmp["suppliers"]}
    assert ranks == {"DEHN India Pvt Ltd": (1, "45100.00", True), "Kerala Electricals": (2, "47400.00", True),
                     "Malabar Traders": (None, "30200.00", False)}
    # the default choice is L1 per line; the last purchase price is shown (demo PO: 2900 less 5 % = 2755)
    assert [ln["selected_quotation_id"] for ln in cmp["lines"]] == [sid["DEHN India Pvt Ltd"], sid["Malabar Traders"],
                                                                     sid["Kerala Electricals"]]
    assert cmp["lines"][1]["last_price"]["rate"] == "2755.0000"
    assert cmp["lines"][1]["savings_vs_last"] == "-180.00"
    assert cmp["l1_value"] == "43300.00"  # 17100 + 11200 + 15000
    assert download(client, h, f"/rfqs/{rfq['id']}/comparison/xlsx")[:2] == b"PK"
    assert download(client, h, f"/rfqs/{rfq['id']}/comparison/pdf")[:4] == b"%PDF"
    wb = load_workbook(io.BytesIO(download(client, h, f"/rfqs/{rfq['id']}/comparison/xlsx")))
    greens = [c.coordinate for row in wb.active.iter_rows() for c in row if c.fill.fgColor.rgb == "00C6EFCE"]
    assert greens  # L1 cells are green

    # choosing other than L1 needs a remark
    choice = [{"rfq_line_id": lid[0], "quotation_id": sid["Kerala Electricals"]},
              {"rfq_line_id": lid[1], "quotation_id": sid["Malabar Traders"]},
              {"rfq_line_id": lid[2], "quotation_id": sid["Kerala Electricals"]}]
    r = client.put(f"{API}/rfqs/{rfq['id']}/selection", headers=h, json={"lines": choice})
    assert r.status_code == 400 and r.json()["error"]["code"] == "REMARK_REQUIRED"
    assert r.json()["error"]["details"]["line"] == 1
    r = client.put(f"{API}/rfqs/{rfq['id']}/selection", headers=h, json={"lines": [
        {"rfq_line_id": lid[2], "quotation_id": sid["Malabar Traders"]}]})
    assert r.json()["error"]["code"] == "NOT_QUOTED"
    choice[0]["remark"] = "Same supplier as the GI strip; one delivery"
    cmp = put(client, h, f"/rfqs/{rfq['id']}/selection", {"lines": choice})
    assert cmp["rfq"]["status"] == "compared"
    assert cmp["lines"][0]["selection_remark"].startswith("Same supplier")
    assert cmp["selected_value"] == "46200.00"  # Kerala 17500 + 15000 + freight 2500, Malabar 11200

    # one draft PO per chosen supplier, at the quoted rates, linked to the PR lines
    rfq = get(client, h, f"/rfqs/{rfq['id']}")
    out = post(client, h, f"/rfqs/{rfq['id']}/create-orders", {"warehouse_id": get(client, h, "/warehouses", q="MAIN")[0]["id"]})
    pos = {p["supplier"]["name"]: p for p in out["purchase_orders"]}
    assert set(pos) == {"Kerala Electricals", "Malabar Traders"} and out["rfq"]["status"] == "closed"
    ke_po = get(client, h, f"/purchase-orders/{pos['Kerala Electricals']['id']}")
    assert ke_po["status"] == "draft" and ke_po["supplier_quote_ref"] == "KE-12"
    assert [(i["description"][:10], i["quantity"], i["rate"], i["pr_line_id"]) for i in ke_po["items"]] == [
        ("Air Termin", "10.000", "1750.0000", pr["lines"][0]["id"]), ("GI Strip 5", "100.000", "150.0000", pr["lines"][2]["id"]),
        ("Freight / ", "1.000", "2500.0000", None)]
    assert ke_po["taxable"] == "35000.00"
    mt_po = get(client, h, f"/purchase-orders/{pos['Malabar Traders']['id']}")
    assert [(i["rate"], i["pr_line_id"]) for i in mt_po["items"]] == [("2800.0000", pr["lines"][1]["id"])]
    pr = get(client, h, f"/purchase-requests/{pr['id']}")
    assert pr["status"] == "ordered" and {p["id"] for p in pr["purchase_orders"]} == {ke_po["id"], mt_po["id"]}
    # the RFQ is closed; quotations can no longer change
    r = client.put(f"{API}/rfqs/{rfq['id']}/quotations/{malabar['id']}", headers=h,
                   json={"lines": [{"rfq_line_id": lid[0], "unit_rate": "1"}]})
    assert r.json()["error"]["code"] == "RFQ_CLOSED"


def test_invalid_excel_rows_are_reported_and_nothing_saved(client, as_user):
    h = as_user("purchase1")
    rfq = make_rfq(client, h, approved_pr(client, as_user))
    vq = by_name(rfq)["DEHN India Pvt Ltd"]
    t = download(client, h, f"/rfqs/{rfq['id']}/quotations/{vq['id']}/template")
    bad = fill_template(t, {}, {1: ("abc", 0, 18, None, None), 2: (3000, 150, 7, None, "two weeks"), 3: (160, 0, 18, None, -2)})
    res = upload(client, h, f"/rfqs/{rfq['id']}/quotations/{vq['id']}/import", bad).json()["data"]
    assert res["saved"] is False
    msgs = {e["line_no"]: e["message"] for e in res["errors"]}
    assert "unit rate 'abc' is not a number" in msgs[1]
    assert "discount must be between 0 and 100" in msgs[2] and "GST 7 %" in msgs[2]
    assert "delivery days cannot be negative" in msgs[3]
    assert all(e["row"] for e in res["errors"])
    assert by_name(get(client, h, f"/rfqs/{rfq['id']}"))["DEHN India Pvt Ltd"]["status"] == "awaited"
    # an extra row that matches nothing is reported; a reply form of another RFQ is refused
    wb = load_workbook(io.BytesIO(fill_template(t, {}, {1: (100, 0, 18, None, None)})))
    ws = wb["Quotation"]
    ws.append([99, None, "Something we did not ask for", None, "NOS", 1, 50])
    buf = io.BytesIO()
    wb.save(buf)
    res = upload(client, h, f"/rfqs/{rfq['id']}/quotations/{vq['id']}/import", buf.getvalue()).json()["data"]
    assert res["saved"] is False and any("does not match any line" in e["message"] for e in res["errors"])
    other = make_rfq(client, h, approved_pr(client, as_user))
    r = upload(client, h, f"/rfqs/{other['id']}/quotations/{by_name(other)['DEHN India Pvt Ltd']['id']}/import",
               fill_template(t, {}, {1: (100, 0, 18, None, None)}))
    assert r.status_code == 400 and r.json()["error"]["code"] == "WRONG_RFQ"
    r = upload(client, h, f"/rfqs/{rfq['id']}/quotations/{vq['id']}/import", b"not an excel file")
    assert r.json()["error"]["code"] == "INVALID_EXCEL"


# ------------------------------------------------------------------ AI
class FakeResponse:
    def __init__(self, payload: dict, status: int = 200):
        self.status_code, self._payload = status, payload

    def json(self):
        return self._payload


@pytest.fixture
def ai_key(monkeypatch):
    from app.core.config import get_settings

    monkeypatch.setattr(get_settings(), "anthropic_api_key", "sk-ant-test-key")
    calls = []

    def respond(text: str, status: int = 200):
        def fake_post(url, headers=None, json=None, timeout=None):  # noqa: A002
            calls.append({"url": url, "headers": headers, "json": json, "timeout": timeout})
            if status != 200:
                return FakeResponse({"error": {"type": "overloaded_error", "message": "Overloaded"}}, status)
            return FakeResponse({"content": [{"type": "text", "text": text}]})

        from app.purchase import rfq_ai

        monkeypatch.setattr(rfq_ai.httpx, "post", fake_post)

    return respond, calls


def test_ai_reads_a_pdf_quotation_into_a_prefill(client, as_user, ai_key):
    respond, calls = ai_key
    h = as_user("purchase1")
    rfq = make_rfq(client, h, approved_pr(client, as_user))
    assert rfq["ai_enabled"] and rfq["can"]["ai"]
    vq = by_name(rfq)["Malabar Traders"]
    reply = {"supplier_quote_no": "MT/2026/41", "quote_date": "2026-10-05", "validity_days": 15, "payment_terms": "50% advance",
             "delivery": "1 week", "freight": {"included": False, "amount": 1200}, "warranty": None, "rates_include_gst": False,
             "lines": [{"rfq_line_no": 1, "description": "Air terminal 16mm", "unit_rate": 1820.5, "discount_pct": 2, "gst_pct": 18,
                        "make": "Indal", "delivery_days": 7, "remarks": None},
                       {"rfq_line_no": None, "description": "GI Strip 50 x 6 mm", "unit_rate": "155", "gst_pct": 18},
                       {"rfq_line_no": None, "description": "Copper bonded earth electrode 3 m", "unit_rate": None,
                        "remarks": "Regret"}]}
    respond("Here is the data:\n```json\n" + json.dumps(reply) + "\n```")
    pdf = b"%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n"
    r = client.post(f"{API}/rfqs/{rfq['id']}/quotations/{vq['id']}/ai-read", headers=h,
                    files={"file": ("malabar-quote.pdf", pdf, "application/pdf")})
    assert r.status_code == 200, r.text
    res = r.json()["data"]
    call = calls[0]
    assert call["url"] == "https://api.anthropic.com/v1/messages" and call["timeout"] == 120
    assert call["headers"]["x-api-key"] == "sk-ant-test-key" and call["headers"]["anthropic-version"] == "2023-06-01"
    assert call["json"]["model"] and call["json"]["max_tokens"] == 4096
    blocks = call["json"]["messages"][0]["content"]
    assert blocks[0]["type"] == "document" and blocks[0]["source"]["media_type"] == "application/pdf"
    assert "Air Terminal" in blocks[1]["text"] and '"rfq_line_no"' in blocks[1]["text"]
    assert res["header"]["quote_ref"] == "MT/2026/41" and res["header"]["valid_until"] == "2026-10-20"
    assert (res["header"]["freight_included"], res["header"]["freight_amount"]) == (False, "1200")
    lines = {x["line_no"]: x for x in res["lines"]}
    assert (lines[1]["unit_rate"], lines[1]["discount_pct"], lines[1]["make"]) == ("1820.5", "2", "Indal")
    assert lines[3]["unit_rate"] == "155" and lines[3]["not_quoted"] is False  # matched by description
    assert lines[2]["not_quoted"] is True
    # nothing is saved until the buyer reviews it; the file is kept
    after = by_name(get(client, h, f"/rfqs/{rfq['id']}"))["Malabar Traders"]
    assert after["status"] == "awaited"
    assert len(get(client, h, "/documents", entity_type="vendor_quotation", entity_id=vq["id"])) == 1
    # the reviewed pre-fill saves like a manual entry
    body = res["header"] | {"source": "ai", "lines": res["lines"]}
    saved = put(client, h, f"/rfqs/{rfq['id']}/quotations/{vq['id']}", body)
    assert by_name(saved)["Malabar Traders"]["source"] == "ai"
    # the AI summary of the comparison
    respond("Award line 1 to Malabar Traders; DEHN has not quoted yet.")
    text = post(client, h, f"/rfqs/{rfq['id']}/ai-summary")["text"]
    assert text.startswith("Award line 1")
    # a failing AI service gives a clear error, never the key
    respond("", status=529)
    r = client.post(f"{API}/rfqs/{rfq['id']}/quotations/{vq['id']}/ai-read", headers=h,
                    files={"file": ("q.pdf", pdf, "application/pdf")})
    assert r.status_code == 502 and "sk-ant" not in r.text
    respond("I could not find any prices.")
    r = client.post(f"{API}/rfqs/{rfq['id']}/quotations/{vq['id']}/ai-read", headers=h,
                    files={"file": ("q.pdf", pdf, "application/pdf")})
    assert r.status_code == 422 and r.json()["error"]["code"] == "AI_BAD_REPLY"


def test_ai_without_key_is_a_clear_400(client, as_user):
    h = as_user("purchase1")
    rfq = make_rfq(client, h, approved_pr(client, as_user))
    assert rfq["ai_enabled"] is False and rfq["can"]["ai"] is False
    vq = rfq["quotations"][0]
    r = client.post(f"{API}/rfqs/{rfq['id']}/quotations/{vq['id']}/ai-read", headers=h,
                    files={"file": ("q.pdf", b"%PDF-1.4\n%%EOF\n", "application/pdf")})
    assert r.status_code == 400 and r.json()["error"]["code"] == "AI_NOT_CONFIGURED"
    assert "ANTHROPIC_API_KEY" in r.json()["error"]["message"]
    r = client.post(f"{API}/rfqs/{rfq['id']}/ai-summary", headers=h)
    assert r.status_code == 400 and r.json()["error"]["code"] == "AI_NOT_CONFIGURED"


# ------------------------------------------------------------------ other paths
def test_rfq_from_material_request_and_editing(client, as_user):
    h = as_user("purchase1")
    mr = [m for m in get(client, h, "/material-requests") if m["status"] == "in_progress"][0]
    rfq = post(client, h, "/rfqs", {"material_request_id": mr["id"]})
    # only what is still open on the MR (the GI strip; the other lines went on a purchase request)
    assert [(ln["description"][:8], ln["quantity"], ln["pr_line_id"]) for ln in rfq["lines"]] == [("GI Strip", "80", None)]
    assert rfq["material_request"]["id"] == mr["id"] and rfq["warehouse"] is not None
    assert "ABC Hospital" in (rfq["delivery_location"] or "") or rfq["delivery_location"]
    # suppliers can be added (from the master or typed in), edited while draft, and removed while nothing is recorded
    rfq = post(client, h, f"/rfqs/{rfq['id']}/suppliers", {"supplier_id": supplier(client, h)["id"]})
    rfq = post(client, h, f"/rfqs/{rfq['id']}/suppliers", {"new_supplier": {"supplier_name": "Cochin Wires"}})
    assert len(rfq["quotations"]) == 2
    r = client.post(f"{API}/rfqs/{rfq['id']}/suppliers", headers=h, json={"supplier_id": supplier(client, h)["id"]})
    assert r.json()["error"]["code"] == "DUPLICATE_SUPPLIER"
    body = {k: rfq[k] for k in ("due_date", "delivery_location", "contact_person", "terms", "notes", "compare_on", "row_version")}
    body |= {"warehouse_id": rfq["warehouse"]["id"], "supplier_ids": [x["supplier"]["id"] for x in rfq["quotations"]],
             "lines": [{k: ln[k] for k in ("id", "item_id", "description", "unit", "quantity", "mr_line_id")} for ln in rfq["lines"]]
             + [{"description": "Bimetallic connector", "unit": "NOS", "quantity": "20"}], "terms": "Delivery to site."}
    rfq = put(client, h, f"/rfqs/{rfq['id']}", body)
    assert len(rfq["lines"]) == 2 and rfq["terms"] == "Delivery to site."
    cochin = by_name(rfq)["Cochin Wires"]
    rfq = client.delete(f"{API}/rfqs/{rfq['id']}/quotations/{cochin['id']}", headers=h).json()["data"]
    assert len(rfq["quotations"]) == 1
    # a draft that never left the office can be deleted
    assert client.delete(f"{API}/rfqs/{rfq['id']}", headers=h).status_code == 200
    # a closed / unknown source is refused
    r = client.post(f"{API}/rfqs", headers=h, json={"purchase_request_id": get(client, h, "/purchase-requests", status="ordered")[0]["id"]})
    assert r.status_code == 400 and r.json()["error"]["code"] == "PR_NOT_OPEN"


def test_standalone_rfq_compare_on_total_and_gst_inclusive(client, as_user):
    h = as_user("purchase1")
    spd = item(client, h, "DEHN-SPD-T12")
    a = post(client, h, "/suppliers", {"supplier_name": "Alpha Power"})
    b = post(client, h, "/suppliers", {"supplier_name": "Beta Power"})
    rfq = post(client, h, "/rfqs", {"compare_on": "total", "supplier_ids": [a["id"], b["id"]], "lines": [
        {"item_id": spd["id"], "description": spd["item_name"], "unit": "NOS", "quantity": "2"}]})
    q = by_name(rfq)
    lid = rfq["lines"][0]["id"]
    put(client, h, f"/rfqs/{rfq['id']}/quotations/{q['Alpha Power']['id']}",
        {"gst_inclusive": True, "lines": [{"rfq_line_id": lid, "unit_rate": "16520", "gst_pct": "18"}]})
    rfq = put(client, h, f"/rfqs/{rfq['id']}/quotations/{q['Beta Power']['id']}",
              {"lines": [{"rfq_line_id": lid, "unit_rate": "14100", "gst_pct": "18"}]})
    q = by_name(rfq)
    assert q["Alpha Power"]["lines"][0]["net_rate"] == "14000.0000" and q["Alpha Power"]["grand_total"] == "33040.00"
    assert q["Beta Power"]["grand_total"] == "33276.00"
    r = client.put(f"{API}/rfqs/{rfq['id']}/quotations/{q['Beta Power']['id']}", headers=h,
                   json={"lines": [{"rfq_line_id": lid, "unit_rate": "100", "gst_pct": "7"}]})
    assert r.json()["error"]["code"] == "INVALID_GST_RATE"
    cmp = get(client, h, f"/rfqs/{rfq['id']}/comparison")
    assert cmp["lines"][0]["l1"] == [q["Alpha Power"]["id"]]
    # award all to one supplier (with a reason, as it is not L1), then the PO gets the rate before GST
    cmp = put(client, h, f"/rfqs/{rfq['id']}/selection", {"lines": [
        {"rfq_line_id": lid, "quotation_id": q["Beta Power"]["id"], "remark": "Approved vendor of the consultant"}]})
    out = post(client, h, f"/rfqs/{rfq['id']}/create-orders", {})
    po = get(client, h, f"/purchase-orders/{out['purchase_orders'][0]['id']}")
    assert po["supplier"]["name"] == "Beta Power" and po["items"][0]["rate"] == "14100.0000"
    assert po["items"][0]["pr_line_id"] is None and po["warehouse"]["code"] == "MAIN"


def test_permissions(client, as_user):
    pr = approved_pr(client, as_user)
    sales = as_user("sales1")
    assert client.get(f"{API}/rfqs", headers=sales).status_code == 403
    assert client.post(f"{API}/rfqs", headers=sales, json={"purchase_request_id": pr["id"]}).status_code == 403
    rfq = make_rfq(client, as_user("purchase1"), pr)
    assert client.get(f"{API}/rfqs/{rfq['id']}", headers=sales).status_code == 403
    for user in ("store1", "accounts1", "pm1"):
        h = as_user(user)
        assert client.get(f"{API}/rfqs/{rfq['id']}", headers=h).status_code == 200
        assert client.get(f"{API}/rfqs/{rfq['id']}/pdf", headers=h).status_code == 200
        assert client.post(f"{API}/rfqs", headers=h, json={"purchase_request_id": pr["id"]}).status_code == 403
        assert client.put(f"{API}/rfqs/{rfq['id']}/quotations/{rfq['quotations'][0]['id']}", headers=h,
                          json={"lines": [{"rfq_line_id": rfq["lines"][0]["id"], "unit_rate": "1"}]}).status_code == 403
    for user in ("manager", "director"):
        assert client.post(f"{API}/rfqs", headers=as_user(user), json={"purchase_request_id": pr["id"]}).status_code == 201
    # attachments on a supplier's quotation follow the RFQ permissions
    vq = rfq["quotations"][0]
    r = client.post(f"{API}/documents", headers=sales, data={"entity_type": "vendor_quotation", "entity_id": vq["id"],
                                                             "category": "quotation"},
                    files={"file": ("q.pdf", b"%PDF-1.4\n%%EOF\n", "application/pdf")})
    assert r.status_code == 403
    assert D(rfq["lines"][0]["quantity"]) == D("10")
