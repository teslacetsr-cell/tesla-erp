"""Document library: one list of every file a person may open, filtered by each record's own permission rules."""
from tests.test_finance import _cat, get, post

API = "/api/v1"
PDF = b"%PDF-1.4\n%%EOF\n"


def _upload(client, h, entity_type, entity_id, name, category="other"):
    r = client.post(f"{API}/documents", headers=h, data={"entity_type": entity_type, "entity_id": entity_id,
                                                          "category": category},
                    files={"file": (name, PDF, "application/pdf")})
    assert r.status_code == 201, r.text
    return r.json()["data"]


def names(client, h, **params):
    return {r["file_name"]: r for r in get(client, h, "/document-library", **params)["rows"]}


def test_library_lists_only_what_each_person_may_open(client, as_user, admin_headers):
    e = as_user("employee1")
    claim = post(client, e, "/expenses", {"category_id": _cat(client, e, "Courier")["id"], "expense_date": "2026-09-28",
                                          "amount": "300", "description": "Courier of drawings to site"})
    _upload(client, e, "expense", claim["id"], "courier-bill-lib.pdf", "receipt")
    company = get(client, admin_headers, "/document-library")["company_id"]
    _upload(client, admin_headers, "company", company, "gst-certificate-lib.pdf", "certificate")

    mine = names(client, e)
    assert "courier-bill-lib.pdf" in mine
    row = mine["courier-bill-lib.pdf"]
    assert row["entity_kind"] == "Expense claim" and row["href"].startswith("/finance/expenses/view?id=")
    assert row["uploaded_by"] and row["category"] == "receipt"
    # another salesperson cannot see someone else's expense bill; accounts can
    assert "courier-bill-lib.pdf" not in names(client, as_user("sales1"))
    assert "courier-bill-lib.pdf" in names(client, as_user("accounts1"))
    # company papers: visible to those who may read the company record
    assert "gst-certificate-lib.pdf" in names(client, as_user("director"))
    # filters
    assert set(names(client, as_user("accounts1"), category="certificate")) >= {"gst-certificate-lib.pdf"}
    assert "courier-bill-lib.pdf" not in names(client, as_user("accounts1"), category="certificate")
    assert list(names(client, as_user("accounts1"), q="courier-bill-lib")) == ["courier-bill-lib.pdf"]
    assert "courier-bill-lib.pdf" in names(client, e, mine="true")
    assert "gst-certificate-lib.pdf" not in names(client, e, mine="true")
    # asking for a record type the person cannot read is refused
    assert client.get(f"{API}/document-library", headers=e, params={"entity_type": "invoice"}).status_code == 403
    # only people who may change the company record get the company upload button
    assert get(client, admin_headers, "/document-library")["can_upload_company"] is True
    assert get(client, e, "/document-library")["can_upload_company"] is False
