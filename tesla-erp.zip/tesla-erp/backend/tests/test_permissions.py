"""Permission matrix (Spec §45: Permissions). Every protected endpoint × all 11 roles.

Expected results are derived from the declared default grants (app/users/default_roles.py), so this
test proves each endpoint enforces exactly the permission it claims to.
"""
import fnmatch

import pytest

from app.users.default_roles import ROLES
from tests.conftest import login

ROLE_USER = {
    "ADMIN": None, "DIRECTOR": "director", "MANAGER": "manager", "SALES": "sales1", "PROJECT_MANAGER": "pm1",
    "SITE_ENGINEER": "engineer1", "PURCHASE": "purchase1", "STORE": "store1", "ACCOUNTS": "accounts1",
    "HR": "hr1", "EMPLOYEE": "employee1",
}

# (method, path, permission). Read-only probes plus writes that fail validation *after* the permission check.
ENDPOINTS = [
    ("GET", "/api/v1/users", "user.read"),
    ("POST", "/api/v1/users", "user.create"),
    ("GET", "/api/v1/roles", "role.read"),
    ("GET", "/api/v1/permissions", "role.read"),
    ("POST", "/api/v1/roles", "role.create"),
    ("GET", "/api/v1/company", "company.read"),
    ("PUT", "/api/v1/company", "company.update"),
    ("GET", "/api/v1/divisions", "division.read"),
    ("POST", "/api/v1/divisions", "division.create"),
    ("GET", "/api/v1/settings", "settings.read"),
    ("GET", "/api/v1/numbering-formats", "settings.read"),
    ("GET", "/api/v1/departments", "org_master.read"),
    ("POST", "/api/v1/designations", "org_master.create"),
    ("GET", "/api/v1/employees", "employee.read"),
    ("POST", "/api/v1/employees", "employee.create"),
    ("GET", "/api/v1/customers", "customer.read"),
    ("POST", "/api/v1/customers", "customer.create"),
    ("GET", "/api/v1/customers/export", "customer.export"),
    ("GET", "/api/v1/suppliers", "supplier.read"),
    ("POST", "/api/v1/suppliers", "supplier.create"),
    ("GET", "/api/v1/suppliers/export", "supplier.export"),
    ("GET", "/api/v1/items", "item.read"),
    ("POST", "/api/v1/items", "item.create"),
    ("GET", "/api/v1/items/export", "item.export"),
    ("GET", "/api/v1/brands", "item.read"),
    ("GET", "/api/v1/tax-rates", "tax_rate.read"),
    ("POST", "/api/v1/tax-rates", "tax_rate.create"),
    ("GET", "/api/v1/warehouses", "warehouse.read"),
    ("POST", "/api/v1/warehouses", "warehouse.create"),
    ("GET", "/api/v1/audit-logs", "audit.read"),
]


def granted(role: str, perm: str) -> bool:
    return any(fnmatch.fnmatchcase(perm, pattern) for pattern in ROLES[role]["grants"])


@pytest.mark.parametrize("role", list(ROLE_USER))
def test_permission_matrix(client, admin_headers, role):
    headers = admin_headers if role == "ADMIN" else login(client, ROLE_USER[role])
    failures = []
    for method, path, perm in ENDPOINTS:
        r = client.request(method, path, headers=headers, json={} if method in ("POST", "PUT") else None)
        allowed = r.status_code != 403
        if allowed != granted(role, perm):
            failures.append(f"{method} {path} [{perm}] -> {r.status_code}")
        if not allowed:
            assert r.json()["error"]["code"] == "FORBIDDEN"
    assert not failures, f"{role}: " + "; ".join(failures)


def test_every_role_is_covered():
    assert set(ROLE_USER) == set(ROLES) and len(ROLES) == 11


def test_sales_can_edit_own_customer_only(client, as_user):
    h1, h2 = as_user("sales1"), as_user("sales2")
    abc = client.get("/api/v1/customers", headers=h1, params={"q": "ABC"}).json()["data"][0]
    detail = client.get(f"/api/v1/customers/{abc['id']}", headers=h1).json()["data"]
    assert detail["can_edit"] is True
    body = {k: detail[k] for k in ("customer_name", "customer_type", "city", "state_code", "pincode",
                                   "assigned_sales_person_id", "row_version")}
    body["notes"] = "Updated by owner"
    assert client.put(f"/api/v1/customers/{abc['id']}", headers=h1, json=body).status_code == 200
    # sales2 can see it but cannot change it
    detail2 = client.get(f"/api/v1/customers/{abc['id']}", headers=h2).json()["data"]
    assert detail2["can_edit"] is False
    body["row_version"] = detail2["row_version"]
    r = client.put(f"/api/v1/customers/{abc['id']}", headers=h2, json=body)
    assert r.status_code == 403 and r.json()["error"]["code"] == "OUT_OF_SCOPE"
    # …nor add a contact to it
    r = client.post(f"/api/v1/customers/{abc['id']}/contacts", headers=h2, json={"name": "Someone"})
    assert r.status_code == 403


def test_sales_cannot_reassign_customer(client, as_user):
    h1 = as_user("sales1")
    abc = client.get("/api/v1/customers", headers=h1, params={"q": "ABC"}).json()["data"][0]
    d = client.get(f"/api/v1/customers/{abc['id']}", headers=h1).json()["data"]
    sales2 = client.get("/api/v1/auth/me", headers=as_user("sales2")).json()["data"]["id"]
    body = {"customer_name": d["customer_name"], "assigned_sales_person_id": sales2, "row_version": d["row_version"]}
    r = client.put(f"/api/v1/customers/{abc['id']}", headers=h1, json=body)
    assert r.status_code == 403


def test_customer_created_by_sales_is_assigned_to_them(client, as_user):
    h = as_user("sales2")
    r = client.post("/api/v1/customers", headers=h, json={"customer_name": "Sunrise Builders", "customer_type": "builder"})
    assert r.status_code == 201, r.text
    me = client.get("/api/v1/auth/me", headers=h).json()["data"]["id"]
    assert r.json()["data"]["assigned_sales_person_id"] == me
    assert r.json()["data"]["can_edit"] is True


def test_supplier_bank_numbers_masked_without_permission(client, admin_headers, as_user):
    dehn = client.get("/api/v1/suppliers", headers=admin_headers, params={"q": "DEHN"}).json()["data"][0]
    r = client.post(f"/api/v1/suppliers/{dehn['id']}/bank-accounts", headers=admin_headers, json={
        "account_name": "DEHN India Pvt Ltd", "bank_name": "HDFC Bank", "account_number": "50200012345678",
        "ifsc": "HDFC0000123", "is_primary": True})
    assert r.status_code == 201, r.text
    assert r.json()["data"]["account_number"] == "50200012345678"
    # Manager has supplier.read but not supplier_bank.read -> masked
    m = client.get(f"/api/v1/suppliers/{dehn['id']}", headers=as_user("manager")).json()["data"]
    assert m["bank_accounts"][0]["account_number"].endswith("5678")
    assert "50200012345678" not in str(m)
    # Accounts can see it in full
    a = client.get(f"/api/v1/suppliers/{dehn['id']}", headers=as_user("accounts1")).json()["data"]
    assert a["bank_accounts"][0]["account_number"] == "50200012345678"


def test_only_admin_can_grant_admin(client, admin_headers):
    from app.core.db import SessionLocal
    from app.users.models import Role, RolePermission

    # Give the director user.create for this test, then try to create an admin.
    with SessionLocal() as s:
        from app.users.models import Permission
        director = s.query(Role).filter_by(code="DIRECTOR").one()
        perm = s.query(Permission).filter_by(code="user.create").one()
        s.add(RolePermission(role_id=director.id, permission_id=perm.id, scope="all"))
        s.commit()
    h = login(client, "director")
    r = client.post("/api/v1/users", headers=h, json={
        "username": "newadmin", "email": "newadmin@teslace-demo.in", "full_name": "New Admin",
        "role_codes": ["ADMIN"], "temporary_password": "Temporary#Pass2026"})
    assert r.status_code == 403
    r = client.post("/api/v1/users", headers=h, json={
        "username": "newsales", "email": "newsales@teslace-demo.in", "full_name": "New Sales",
        "role_codes": ["SALES"], "temporary_password": "Temporary#Pass2026"})
    assert r.status_code == 201, r.text



def test_last_admin_cannot_be_removed(client, admin_headers):
    me = client.get("/api/v1/auth/me", headers=admin_headers).json()["data"]
    u = client.get(f"/api/v1/users/{me['id']}", headers=admin_headers).json()["data"]
    r = client.put(f"/api/v1/users/{me['id']}", headers=admin_headers, json={
        "email": u["email"], "full_name": u["full_name"], "role_codes": ["DIRECTOR"], "is_active": True,
        "row_version": u["row_version"]})
    assert r.status_code == 400 and r.json()["error"]["code"] == "LAST_ADMIN"


def test_role_edit_changes_access(client, admin_headers, as_user):
    h = as_user("employee1")
    assert client.get("/api/v1/items", headers=h).status_code == 403
    role = next(r for r in client.get("/api/v1/roles", headers=admin_headers).json()["data"] if r["code"] == "EMPLOYEE")
    grants = dict(role["grants"]) | {"item.read": "all"}
    r = client.put(f"/api/v1/roles/{role['id']}", headers=admin_headers, json={
        "name": role["name"], "description": role["description"], "is_active": True, "grants": grants,
        "row_version": role["row_version"]})
    assert r.status_code == 200, r.text
    assert client.get("/api/v1/items", headers=h).status_code == 200
    # Unknown permission and illegal scope are rejected
    bad = client.put(f"/api/v1/roles/{role['id']}", headers=admin_headers, json={
        "name": role["name"], "grants": {"item.read": "own"}, "row_version": r.json()["data"]["row_version"]})
    assert bad.status_code == 400 and bad.json()["error"]["code"] == "SCOPE_NOT_SUPPORTED"
    # ADMIN role is locked
    admin_role = next(x for x in client.get("/api/v1/roles", headers=admin_headers).json()["data"] if x["code"] == "ADMIN")
    r = client.put(f"/api/v1/roles/{admin_role['id']}", headers=admin_headers,
                   json={"name": "Admin X", "grants": {}, "row_version": admin_role["row_version"]})
    assert r.status_code == 400 and r.json()["error"]["code"] == "ROLE_LOCKED"


def test_view_edit_aliases_normalised():
    from app.core.permissions import normalise

    assert normalise("quotation.edit") == "quotation.update"
    assert normalise("quotation.view") == "quotation.read"


def test_api_process_registers_all_permissions_on_its_own():
    """The API must know every permission code without relying on the seed script having been imported."""
    import subprocess
    import sys

    code = "import app.main; from app.core.permissions import REGISTRY; assert len(REGISTRY) > 40, len(REGISTRY)"
    r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, cwd=__file__.rsplit("/tests/", 1)[0])
    assert r.returncode == 0, r.stderr
