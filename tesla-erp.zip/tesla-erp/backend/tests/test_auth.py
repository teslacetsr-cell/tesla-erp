"""Authentication (Spec §45: Authentication)."""
from datetime import UTC, datetime, timedelta

from sqlalchemy import select, text

from app.core.db import SessionLocal
from app.users.models import User
from tests.conftest import ADMIN_PASSWORD, DEMO_PASSWORD, login


def test_login_by_username_and_email(client):
    for ident in ("sales1", "sales1@teslace-demo.in", "SALES1"):
        r = client.post("/api/v1/auth/login", json={"login": ident, "password": DEMO_PASSWORD})
        assert r.status_code == 200, r.text
        body = r.json()["data"]
        assert body["user"]["username"] == "sales1"
        assert body["user"]["permissions"]["customer.update"] == "own"
        assert "tce_refresh" in r.cookies and "tce_csrf" in r.cookies


def test_wrong_password_and_unknown_user_look_identical(client):
    a = client.post("/api/v1/auth/login", json={"login": "sales1", "password": "nope-nope-nope"})
    b = client.post("/api/v1/auth/login", json={"login": "ghost", "password": "nope-nope-nope"})
    assert a.status_code == b.status_code == 401
    assert a.json()["error"]["code"] == b.json()["error"]["code"] == "INVALID_CREDENTIALS"


def test_lockout_after_five_failures_and_counter_survives_rollback(client):
    for _ in range(5):
        client.post("/api/v1/auth/login", json={"login": "sales2", "password": "wrong-password-x"})
    r = client.post("/api/v1/auth/login", json={"login": "sales2", "password": DEMO_PASSWORD})
    assert r.status_code == 401 and r.json()["error"]["code"] == "ACCOUNT_LOCKED"
    with SessionLocal() as s:
        u = s.scalar(select(User).where(User.username == "sales2"))
        assert u.locked_until is not None
        # Failed attempts are audited even though the request failed.
        n = s.execute(text("select count(*) from audit_logs where action='login_failed' and user_id=:u"),
                      {"u": u.id}).scalar()
        assert n == 5


def test_protected_endpoint_requires_token(client):
    assert client.get("/api/v1/customers").status_code == 401
    r = client.get("/api/v1/customers", headers={"Authorization": "Bearer not-a-jwt"})
    assert r.status_code == 401 and r.json()["error"]["code"] == "TOKEN_INVALID"


def test_refresh_rotates_and_requires_csrf(client):
    client.post("/api/v1/auth/login", json={"login": "manager", "password": DEMO_PASSWORD})
    old_refresh = client.cookies.get("tce_refresh")
    csrf = client.cookies.get("tce_csrf")
    assert client.post("/api/v1/auth/refresh").status_code == 403  # no CSRF header
    r = client.post("/api/v1/auth/refresh", headers={"X-CSRF-Token": csrf})
    assert r.status_code == 200, r.text
    assert client.cookies.get("tce_refresh") != old_refresh


def test_refresh_token_reuse_revokes_family(client):
    client.post("/api/v1/auth/login", json={"login": "manager", "password": DEMO_PASSWORD})
    stolen = client.cookies.get("tce_refresh")
    csrf = client.cookies.get("tce_csrf")
    r1 = client.post("/api/v1/auth/refresh", headers={"X-CSRF-Token": csrf})
    assert r1.status_code == 200
    legit = client.cookies.get("tce_refresh")
    # Attacker replays the old token
    client.cookies.set("tce_refresh", stolen, path="/api/v1/auth")
    r2 = client.post("/api/v1/auth/refresh", headers={"X-CSRF-Token": client.cookies.get("tce_csrf")})
    assert r2.status_code == 401 and r2.json()["error"]["code"] == "REFRESH_REUSED"
    # …and the legitimate rotated token is now dead too.
    client.cookies.set("tce_refresh", legit, path="/api/v1/auth")
    r3 = client.post("/api/v1/auth/refresh", headers={"X-CSRF-Token": client.cookies.get("tce_csrf")})
    assert r3.status_code == 401


def test_first_login_forces_password_change(client):
    h = login(client, "admin", ADMIN_PASSWORD)
    r = client.get("/api/v1/customers", headers=h)
    assert r.status_code == 403 and r.json()["error"]["code"] == "PASSWORD_CHANGE_REQUIRED"
    weak = client.post("/api/v1/auth/change-password", headers=h,
                       json={"current_password": ADMIN_PASSWORD, "new_password": "short"})
    assert weak.status_code == 400 and weak.json()["error"]["code"] == "WEAK_PASSWORD"
    r = client.post("/api/v1/auth/change-password", headers=h,
                    json={"current_password": ADMIN_PASSWORD, "new_password": "Thrissur#Lightning42"})
    assert r.status_code == 200, r.text
    new_h = {"Authorization": f"Bearer {r.json()['data']['access_token']}"}
    assert client.get("/api/v1/customers", headers=new_h).status_code == 200
    # The old access token was revoked by the password change.
    assert client.get("/api/v1/auth/me", headers=h).status_code == 401


def test_deactivated_user_is_cut_off_immediately(client, admin_headers):
    h = login(client, "sales2")
    assert client.get("/api/v1/customers", headers=h).status_code == 200
    users = client.get("/api/v1/users", headers=admin_headers, params={"q": "sales2"}).json()["data"]
    u = users[0]
    r = client.put(f"/api/v1/users/{u['id']}", headers=admin_headers, json={
        "email": u["email"], "full_name": u["full_name"], "phone": None, "role_codes": ["SALES"],
        "is_active": False, "row_version": u["row_version"]})
    assert r.status_code == 200, r.text
    assert client.get("/api/v1/customers", headers=h).status_code == 401
    r = client.post("/api/v1/auth/login", json={"login": "sales2", "password": DEMO_PASSWORD})
    assert r.status_code == 401 and r.json()["error"]["code"] == "ACCOUNT_DISABLED"


def test_expired_lock_allows_login(client):
    with SessionLocal() as s:
        u = s.scalar(select(User).where(User.username == "hr1"))
        u.locked_until = datetime.now(UTC) - timedelta(minutes=1)
        s.commit()
    assert client.post("/api/v1/auth/login", json={"login": "hr1", "password": DEMO_PASSWORD}).status_code == 200


def test_passwords_are_hashed_with_argon2(client):
    with SessionLocal() as s:
        hashes = s.scalars(select(User.password_hash)).all()
    assert hashes and all(h.startswith("$argon2id$") for h in hashes)


def test_security_headers(client):
    r = client.get("/healthz")
    assert r.headers["X-Content-Type-Options"] == "nosniff"
    assert r.headers["X-Frame-Options"] == "DENY"
    assert "X-Request-ID" in r.headers
