"""Test fixtures. Tests run against a real PostgreSQL database (tesla_erp_test), connecting as the
least-privileged application role exactly like production — so grants and triggers are exercised too."""
import os
import tempfile

os.environ.update({
    "ENVIRONMENT": "test",
    "DATABASE_URL": os.environ.get("TEST_DATABASE_URL", "postgresql+psycopg://erp_app:dev_app@localhost:5432/tesla_erp_test"),
    "MIGRATION_DATABASE_URL": os.environ.get(
        "TEST_MIGRATION_DATABASE_URL", "postgresql+psycopg://erp_owner:dev_owner@localhost:5432/tesla_erp_test"),
    "STORAGE_BACKEND": "local",
    "STORAGE_LOCAL_PATH": tempfile.mkdtemp(prefix="tce-storage-"),
    "ARGON2_TIME_COST": "1",
    "ARGON2_MEMORY_KIB": "8192",
    "LOGIN_RATE_LIMIT_PER_MINUTE": "1000",
    "SEED_ADMIN_PASSWORD": "Admin@Test-2026",
})

import pytest  # noqa: E402
from alembic import command  # noqa: E402
from alembic.config import Config  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import create_engine, text  # noqa: E402

from app.core.config import get_settings  # noqa: E402

OWNER_URL = get_settings().migration_database_url
ADMIN_PASSWORD = "Admin@Test-2026"
DEMO_PASSWORD = "Tesla@Demo2026"


def _alembic_cfg() -> Config:
    cfg = Config(os.path.join(os.path.dirname(__file__), "..", "alembic.ini"))
    cfg.set_main_option("script_location", os.path.join(os.path.dirname(__file__), "..", "migrations"))
    return cfg


def reset_schema() -> None:
    eng = create_engine(OWNER_URL, isolation_level="AUTOCOMMIT")
    with eng.connect() as c:
        c.execute(text("DROP SCHEMA public CASCADE"))
        c.execute(text("CREATE SCHEMA public"))
    eng.dispose()


@pytest.fixture(scope="session", autouse=True)
def _schema():
    reset_schema()
    command.upgrade(_alembic_cfg(), "head")
    yield


@pytest.fixture(scope="session")
def owner_engine():
    eng = create_engine(OWNER_URL)
    yield eng
    eng.dispose()


@pytest.fixture(autouse=True)
def _clean(owner_engine):
    """Empty every table (as owner, with the audit trigger briefly disabled), then seed core + demo data."""
    with owner_engine.begin() as c:
        tables = [r[0] for r in c.execute(text(
            "select tablename from pg_tables where schemaname='public' and tablename <> 'alembic_version'"))]
        c.execute(text("ALTER TABLE audit_logs DISABLE TRIGGER USER"))
        c.execute(text(f"TRUNCATE {', '.join(tables)} RESTART IDENTITY CASCADE"))
        c.execute(text("ALTER TABLE audit_logs ENABLE TRIGGER USER"))
    from app.auth import deps
    from app.core.db import SessionLocal
    from app.seed import seed_core, seed_demo

    deps.reset_company_cache()
    with SessionLocal() as s:
        company = seed_core(s)
        seed_demo(s, company)
        s.commit()
    yield


@pytest.fixture
def client():
    from app.main import app

    with TestClient(app) as c:
        yield c


def login(client: TestClient, username: str, password: str = DEMO_PASSWORD) -> dict:
    r = client.post("/api/v1/auth/login", json={"login": username, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['data']['access_token']}"}


@pytest.fixture
def admin_headers(client):
    """Logs in as admin and completes the forced first-login password change."""
    from app.core.db import SessionLocal
    from app.users.models import User

    with SessionLocal() as s:
        u = s.query(User).filter_by(username="admin").one()
        u.must_change_password = False
        s.commit()
    return login(client, "admin", ADMIN_PASSWORD)


@pytest.fixture
def as_user(client):
    def _as(username: str) -> dict:
        return login(client, username)

    return _as
