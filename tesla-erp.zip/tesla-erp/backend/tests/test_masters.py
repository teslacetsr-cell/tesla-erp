"""Company, customers, suppliers, items, employees (Spec §45: Customer creation, and masters)."""
import io

from openpyxl import Workbook, load_workbook

from app.core.india import gstin_check_char


def gstin(state: str, pan: str) -> str:
    body = f"{state}{pan}1Z"
    return body + gstin_check_char(body)


# ------------------------------------------------------------------ company
def test_company_profile_update_and_bank_masking(client, admin_headers, as_user):
    c = client.get("/api/v1/company", headers=admin_headers).json()["data"]
    assert c["company_name"] == "Tesla Consulting Engineers" and c["has_logo"] is True
    g = gstin("32", "AAAFT1234K")
    body = {k: c[k] for k in ("company_name", "legal_name", "tagline", "row_version")} | {
        "gstin": g, "address_line1": "Round South", "city": "Thrissur", "pincode": "680001",
        "email": "info@teslace-demo.in", "bank_name": "State Bank of India", "account_number": "00000012345678",
        "ifsc": "SBIN0070123"}
    r = client.put("/api/v1/company", headers=admin_headers, json=body)
    assert r.status_code == 200, r.text
    d = r.json()["data"]
    # PAN, state and state code are derived from the GSTIN
    assert (d["pan"], d["state_code"], d["state"]) == ("AAAFT1234K", "32", "Kerala")
    assert d["account_number"] == "00000012345678"
    sales_view = client.get("/api/v1/company", headers=as_user("sales1")).json()["data"]
    assert sales_view["account_number"].endswith("5678") and "0000001234" not in sales_view["account_number"]
    assert client.get("/api/v1/company/logo", headers=admin_headers).headers["content-type"] == "image/png"


def test_company_rejects_mismatched_pan(client, admin_headers):
    c = client.get("/api/v1/company", headers=admin_headers).json()["data"]
    r = client.put("/api/v1/company", headers=admin_headers, json={
        "company_name": c["company_name"], "legal_name": c["legal_name"], "gstin": gstin("32", "AAAFT1234K"),
        "pan": "BBBBB1111B", "row_version": c["row_version"]})
    assert r.status_code == 422 and "PAN does not match" in r.text


# ------------------------------------------------------------------ customers
def test_customer_create_autonumber_and_validation(client, as_user):
    h = as_user("manager")
    r = client.post("/api/v1/customers", headers=h, json={
        "customer_name": "Kerala State Electricity Board", "customer_type": "government",
        "gstin": gstin("32", "AAAJK1234L"), "phone": "0471 2448999", "email": "ee@kseb-demo.in",
        "city": "Thiruvananthapuram", "pincode": "695004", "credit_limit": "2500000.00"})
    assert r.status_code == 201, r.text
    c = r.json()["data"]
    # seed used CUS00001; the two open demo prospect leads were saved as customers CUS00002–CUS00003
    assert c["customer_code"] == "CUS00004"
    assert c["state"] == "Kerala" and c["pan"] == "AAAJK1234L"
    assert c["credit_limit"] == "2500000.00"  # money is a string, never a float
    bad = client.post("/api/v1/customers", headers=h, json={
        "customer_name": "X Co", "gstin": "32AAAJK1234L1Z0", "pincode": "12345", "customer_type": "alien"})
    assert bad.status_code == 422
    fields = {e["field"] for e in bad.json()["error"]["details"]}
    assert {"gstin", "pincode", "customer_type"} <= fields


def test_auto_code_skips_codes_typed_by_hand(client, as_user):
    """A code typed by hand (or imported) that the counter later reaches must not block new customers."""
    h = as_user("manager")
    nums = []
    for _ in range(2):
        r = client.post("/api/v1/customers", headers=h, json={"customer_name": f"Probe {len(nums)}", "customer_type": "company"})
        assert r.status_code == 201, r.text
        nums.append(int(r.json()["data"]["customer_code"][3:]))
    taken = [f"CUS{n:05d}" for n in (nums[-1] + 1, nums[-1] + 2)]
    for i, code in enumerate(taken):
        r = client.post("/api/v1/customers", headers=h, json={"customer_name": f"Hand coded {i}", "customer_code": code,
                                                              "customer_type": "company"})
        assert r.status_code == 201, r.text
    r = client.post("/api/v1/customers", headers=h, json={"customer_name": "After the gap", "customer_type": "company"})
    assert r.status_code == 201, r.text
    assert r.json()["data"]["customer_code"] == f"CUS{nums[-1] + 3:05d}"
    # the same code typed twice gets a plain message
    r = client.post("/api/v1/customers", headers=h, json={"customer_name": "Again", "customer_code": taken[0],
                                                          "customer_type": "company"})
    assert r.status_code == 409 and "already" in r.json()["error"]["message"]
    # suppliers and items skip taken codes too
    sup = client.post("/api/v1/suppliers", headers=h, json={"supplier_name": "Probe supplier"}).json()["data"]
    n = int(sup["supplier_code"][3:])
    assert client.post("/api/v1/suppliers", headers=h, json={"supplier_name": "Hand", "supplier_code": f"SUP{n + 1:05d}"}).status_code == 201
    nxt = client.post("/api/v1/suppliers", headers=h, json={"supplier_name": "Next"}).json()["data"]["supplier_code"]
    assert nxt == f"SUP{n + 2:05d}"


def test_duplicate_gstin_blocked_unless_confirmed(client, as_user):
    h = as_user("manager")
    g = gstin("33", "AAACM5678Q")
    assert client.post("/api/v1/customers", headers=h, json={"customer_name": "Madurai Mills", "gstin": g}).status_code == 201
    r = client.post("/api/v1/customers", headers=h, json={"customer_name": "Madurai Mills Unit 2", "gstin": g})
    assert r.status_code == 409 and r.json()["error"]["code"] == "DUPLICATE_GSTIN"
    dup = client.get("/api/v1/customers/duplicate-check", headers=h, params={"name": "Madurai Mill", "gstin": g})
    assert dup.json()["data"][0]["reasons"][0] == "same GSTIN"
    r = client.post("/api/v1/customers", headers=h, params={"allow_duplicate": True},
                    json={"customer_name": "Madurai Mills Unit 2", "gstin": g})
    assert r.status_code == 201


def test_similar_name_found_by_duplicate_check(client, as_user):
    h = as_user("manager")
    r = client.get("/api/v1/customers/duplicate-check", headers=h, params={"name": "ABC Hospitals"})
    assert any(d["customer_name"] == "ABC Hospital" for d in r.json()["data"])


def test_customer_sites_contacts_addresses(client, as_user):
    h = as_user("manager")
    cid = client.get("/api/v1/customers", headers=h, params={"q": "ABC"}).json()["data"][0]["id"]
    r = client.post(f"/api/v1/customers/{cid}/sites", headers=h, json={
        "site_name": "ABC Hospital — New Oncology Block", "address_line1": "Kuriachira", "city": "Thrissur",
        "state_code": "32", "pincode": "680006", "latitude": "10.5145", "longitude": "76.2311"})
    assert r.status_code == 201, r.text
    assert r.json()["data"]["state"] == "Kerala"
    r = client.post(f"/api/v1/customers/{cid}/contacts", headers=h,
                    json={"name": "Dr. Priya", "designation": "Medical Superintendent", "is_primary": True})
    assert r.status_code == 201
    r = client.post(f"/api/v1/customers/{cid}/addresses", headers=h,
                    json={"address_type": "delivery", "label": "Stores gate", "city": "Thrissur", "state_code": "32"})
    assert r.status_code == 201
    d = client.get(f"/api/v1/customers/{cid}", headers=h).json()["data"]
    assert len(d["sites"]) == 2 and len(d["addresses"]) == 1
    assert [c["is_primary"] for c in d["contacts"]].count(True) == 1  # only one primary contact
    # search finds the customer through a contact name
    assert client.get("/api/v1/customers", headers=h, params={"q": "Priya"}).json()["meta"]["total"] == 1


def test_optimistic_locking_prevents_lost_update(client, as_user):
    h = as_user("manager")
    cid = client.get("/api/v1/customers", headers=h, params={"q": "ABC"}).json()["data"][0]["id"]
    d = client.get(f"/api/v1/customers/{cid}", headers=h).json()["data"]
    base = {"customer_name": d["customer_name"], "customer_type": d["customer_type"],
            "assigned_sales_person_id": d["assigned_sales_person_id"], "row_version": d["row_version"]}
    assert client.put(f"/api/v1/customers/{cid}", headers=h, json=base | {"notes": "first"}).status_code == 200
    r = client.put(f"/api/v1/customers/{cid}", headers=h, json=base | {"notes": "second, stale"})
    assert r.status_code == 409 and r.json()["error"]["code"] == "STALE_RECORD"


def test_customer_delete_and_in_use(client, admin_headers):
    r = client.post("/api/v1/customers", headers=admin_headers, json={"customer_name": "Temp Customer"})
    cid = r.json()["data"]["id"]
    assert client.delete(f"/api/v1/customers/{cid}", headers=admin_headers).status_code == 200
    # A referenced master cannot be deleted: an item category in use by items
    cats = client.get("/api/v1/item-categories", headers=admin_headers, params={"q": "Surge"}).json()["data"]
    r = client.delete(f"/api/v1/item-categories/{cats[0]['id']}", headers=admin_headers)
    assert r.status_code == 409 and r.json()["error"]["code"] == "IN_USE"


def test_customer_excel_import_is_all_or_nothing(client, as_user):
    h = as_user("manager")
    tpl = client.get("/api/v1/customers/import-template", headers=h)
    assert tpl.status_code == 200
    wb = load_workbook(io.BytesIO(tpl.content))
    ws = wb.active
    headers = [c.value for c in ws[1]]
    ws.delete_rows(2)

    def row(**kw):
        return [kw.get(h.replace(" *", "")) for h in headers]

    ws.append(row(**{"Customer name": "Cochin Port Trust", "Type": "government", "City": "Kochi", "State code": 32,
                     "PIN code": 682009, "Sales person email": "sales2@teslace-demo.in"}))
    ws.append(row(**{"Customer name": "Bad GST Ltd", "GSTIN": "32ABCDE1234F1Z8"}))
    buf = io.BytesIO()
    wb.save(buf)
    files = {"file": ("customers.xlsx", buf.getvalue(), "application/octet-stream")}
    rep = client.post("/api/v1/customers/import", headers=h, params={"dry_run": False}, files=files).json()["data"]
    assert rep["committed"] is False and rep["created"] == 0
    assert rep["errors"][0]["row"] == 3 and rep["errors"][0]["field"] == "gstin"
    # Fix the bad row -> everything imports
    ws.delete_rows(3)
    buf = io.BytesIO()
    wb.save(buf)
    files = {"file": ("customers.xlsx", buf.getvalue(), "application/octet-stream")}
    rep = client.post("/api/v1/customers/import", headers=h, params={"dry_run": False}, files=files).json()["data"]
    assert rep["committed"] is True and rep["created"] == 1
    c = client.get("/api/v1/customers", headers=h, params={"q": "Cochin"}).json()["data"][0]
    assert c["state"] == "Kerala" and c["assigned_sales_person"].startswith("Divya")


def test_customer_export(client, as_user):
    r = client.get("/api/v1/customers/export", headers=as_user("manager"))
    assert r.status_code == 200
    ws = load_workbook(io.BytesIO(r.content)).active
    assert ws.cell(2, 2).value == "ABC Hospital"


# ------------------------------------------------------------------ suppliers
def test_supplier_crud_and_ifsc_validation(client, as_user):
    h = as_user("purchase1")
    r = client.post("/api/v1/suppliers", headers=h, json={
        "supplier_name": "Polycab India Ltd", "supplies": "Cables", "state_code": "24", "rating": "4.2"})
    assert r.status_code == 201, r.text
    s = r.json()["data"]
    assert s["supplier_code"] == "SUP00002" and s["state"] == "Gujarat"
    # Bank details are maintained by Accounts (supplier_bank.update), not Purchase.
    assert client.post(f"/api/v1/suppliers/{s['id']}/bank-accounts", headers=h, json={
        "account_name": "Polycab", "bank_name": "ICICI", "account_number": "123456789012",
        "ifsc": "ICIC0001234"}).status_code == 403
    h = as_user("accounts1")
    bad = client.post(f"/api/v1/suppliers/{s['id']}/bank-accounts", headers=h, json={
        "account_name": "Polycab", "bank_name": "ICICI", "account_number": "123456789012", "ifsc": "ICIC123"})
    assert bad.status_code == 422
    ok = client.post(f"/api/v1/suppliers/{s['id']}/bank-accounts", headers=h, json={
        "account_name": "Polycab", "bank_name": "ICICI", "account_number": "123456789012", "ifsc": "icic0001234"})
    assert ok.status_code == 201 and ok.json()["data"]["ifsc"] == "ICIC0001234"


def test_bank_account_encrypted_at_rest(client, admin_headers, owner_engine):
    from sqlalchemy import text

    sid = client.get("/api/v1/suppliers", headers=admin_headers).json()["data"][0]["id"]
    client.post(f"/api/v1/suppliers/{sid}/bank-accounts", headers=admin_headers, json={
        "account_name": "DEHN", "bank_name": "HDFC", "account_number": "998877665544", "ifsc": "HDFC0000123"})
    with owner_engine.connect() as c:
        raw = c.execute(text("select account_number from supplier_bank_accounts")).scalar()
    assert "998877665544" not in raw and raw.startswith("gAAAA")  # Fernet token
    logs = client.get("/api/v1/audit-logs", headers=admin_headers,
                      params={"entity_type": "supplier_bank_account"}).json()["data"]
    assert "998877665544" not in str(logs)


# ------------------------------------------------------------------ items
def _ref(client, h, path, q):
    return client.get(path, headers=h, params={"q": q}).json()["data"][0]["id"]


def test_item_create_with_gst_and_hsn_rules(client, as_user):
    h = as_user("purchase1")
    cat, unit = _ref(client, h, "/api/v1/item-categories", "Earthing"), _ref(client, h, "/api/v1/units", "NOS")
    gst18 = _ref(client, h, "/api/v1/tax-rates", "GST18")
    r = client.post("/api/v1/items", headers=h, json={
        "item_name": "Earth pit chamber, polyplastic", "category_id": cat, "unit_id": unit, "tax_rate_id": gst18})
    assert r.status_code == 400 and r.json()["error"]["code"] == "HSN_REQUIRED"
    r = client.post("/api/v1/items", headers=h, json={
        "item_name": "Earth pit chamber, polyplastic", "category_id": cat, "unit_id": unit, "tax_rate_id": gst18,
        "hsn_sac": "39269099", "purchase_price": "450.5", "selling_price": "650", "reorder_level": "20"})
    assert r.status_code == 201, r.text
    i = r.json()["data"]
    assert i["item_code"].startswith("ITM") and i["gst_rate"] == "18.0000" and i["selling_price"] == "650.0000"
    svc = client.post("/api/v1/items", headers=h, json={
        "item_name": "Earth resistance testing", "item_type": "service", "category_id": cat, "unit_id": unit,
        "serial_number_required": True})
    assert svc.status_code == 422


def test_item_import_creates_brands(client, as_user):
    h = as_user("purchase1")
    wb = Workbook()
    ws = wb.active
    ws.append(["Item name *", "Category *", "Unit *", "Brand", "HSN/SAC", "GST %", "Selling price"])
    ws.append(["OBO SPD Type 2", "Surge Protection", "NOS", "OBO Bettermann", 85363000, 18, 9500])
    ws.append(["Copper cable 6 sq mm", "Cable", "M", "Polycab", 85444999, 18, 95])
    buf = io.BytesIO()
    wb.save(buf)
    rep = client.post("/api/v1/items/import", headers=h, params={"dry_run": False},
                      files={"file": ("items.xlsx", buf.getvalue(), "application/octet-stream")}).json()["data"]
    assert rep["committed"] and rep["created"] == 2, rep
    brands = [b["name"] for b in client.get("/api/v1/brands", headers=h).json()["data"]]
    assert "OBO Bettermann" in brands and "Polycab" in brands


def test_unit_conversion_rules(client, admin_headers):
    m = _ref(client, admin_headers, "/api/v1/units", "ROLL50")
    r = client.post("/api/v1/units", headers=admin_headers, json={"code": "DRUM", "name": "Drum", "base_unit_id": m,
                                                                  "factor": "500"})
    assert r.status_code == 400 and r.json()["error"]["code"] == "INVALID_UNIT"  # base must be a base unit
    r = client.post("/api/v1/units", headers=admin_headers, json={"code": "DRUM", "name": "Drum", "factor": "500"})
    assert r.status_code == 422


def test_seed_data_matches_spec(client, admin_headers):
    names = {i["item_name"] for i in client.get("/api/v1/items", headers=admin_headers,
                                                params={"page_size": 100}).json()["data"]}
    for expected in ("DEHN SPD", "Air Terminal", "Copper Tape", "GI Strip", "Earth Electrode", "Solar Module",
                     "Solar Inverter", "EV Charger"):
        assert any(expected in n for n in names), expected
    cats = {c["name"] for c in client.get("/api/v1/item-categories", headers=admin_headers,
                                          params={"page_size": 100}).json()["data"]}
    assert len(cats) == 13


# ------------------------------------------------------------------ organisation
def test_employee_autonumber_and_user_link(client, as_user):
    h = as_user("hr1")
    dept = _ref(client, h, "/api/v1/departments", "PROJ")
    r = client.post("/api/v1/employees", headers=h, json={"full_name": "Joseph Antony", "department_id": dept,
                                                          "phone": "+91 98470 12345"})
    assert r.status_code == 201, r.text
    assert r.json()["data"]["employee_code"] == "TCE0012"
    users = client.get("/api/v1/users", headers=h, params={"q": "sales1"}).json()["data"]
    r = client.post("/api/v1/employees", headers=h, json={"full_name": "Duplicate link", "user_id": users[0]["id"]})
    assert r.status_code == 409 and r.json()["error"]["code"] == "USER_ALREADY_LINKED"


def test_global_search_respects_permissions(client, as_user, admin_headers):
    groups = {g["type"] for g in client.get("/api/v1/search", headers=admin_headers, params={"q": "DEHN"}).json()["data"]}
    assert {"supplier", "item"} <= groups
    groups = {g["type"] for g in client.get("/api/v1/search", headers=as_user("sales1"),
                                            params={"q": "DEHN"}).json()["data"]}
    assert "supplier" not in groups and "item" in groups


def test_explicit_nulls_from_the_browser_are_accepted(client, as_user, admin_headers):
    """Forms send null for cleared optional fields; that must never be a server error."""
    h = as_user("manager")
    body = {"customer_name": "Null Test Ltd", "customer_code": None, "company_name": None, "gstin": None, "pan": None,
            "phone": None, "email": None, "website": None, "address_line1": None, "address_line2": None, "city": None,
            "district": None, "state": None, "state_code": None, "pincode": None, "default_payment_terms": None,
            "credit_limit": None, "credit_days": None, "assigned_sales_person_id": None, "notes": None}
    r = client.post("/api/v1/customers", headers=h, json=body)
    assert r.status_code == 201, r.text
    c = client.get("/api/v1/company", headers=admin_headers).json()["data"]
    r = client.put("/api/v1/company", headers=admin_headers, json={k: None for k in (
        "tagline", "gstin", "pan", "address_line1", "address_line2", "city", "state", "state_code", "pincode", "phone",
        "email", "website", "bank_name", "bank_account_name", "account_number", "ifsc", "branch")} | {
        "company_name": c["company_name"], "legal_name": c["legal_name"], "row_version": c["row_version"]})
    assert r.status_code == 200, r.text
    r = client.post("/api/v1/suppliers", headers=h, json={"supplier_name": "Null Supplier", "supplier_code": None,
                                                          "supplies": None, "rating": None, "notes": None})
    assert r.status_code == 201, r.text


# ------------------------------------------------------------------ starter org masters (live-server bug, Sep 2026)
def test_core_seed_gives_divisions_departments_designations(client, owner_engine):
    """A production database is seeded with `core` only. The employee form's Division and Designation lists
    must still have entries to pick — and a list the company has already edited must never be refilled."""
    from sqlalchemy import text

    from app.core.db import SessionLocal
    from app.seed import seed_core

    with owner_engine.begin() as c:  # back to a core-only database: no demo data
        c.execute(text("TRUNCATE employees, business_divisions, departments, designations CASCADE"))
        c.execute(text("INSERT INTO departments (code, name) VALUES ('OPS', 'Operations')"))  # company's own list
    with SessionLocal() as s:
        seed_core(s)
        s.commit()
    from tests.conftest import ADMIN_PASSWORD, login
    with SessionLocal() as s:
        from app.users.models import User
        s.query(User).filter_by(username="admin").one().must_change_password = False
        s.commit()
    h = login(client, "admin", ADMIN_PASSWORD)
    opts = lambda path: client.get(f"/api/v1/{path}", headers=h, params={"page_size": 200, "is_active": True}).json()["data"]  # noqa: E731
    divisions, designations, departments = opts("divisions"), opts("designations"), opts("departments")
    assert {"Solar EPC & Components", "Lightning Protection Systems"} <= {d["name"] for d in divisions}
    assert "Site Engineer" in {d["name"] for d in designations}
    assert [d["name"] for d in departments] == ["Operations"]  # untouched: it already had entries

    body = {"full_name": "Test Person", "division_id": divisions[0]["id"], "designation_id": designations[0]["id"],
            "department_id": departments[0]["id"]}
    e = client.post("/api/v1/employees", headers=h, json=body).json()["data"]
    assert (e["division"], e["designation"], e["department"]) == (divisions[0]["name"], designations[0]["name"], "Operations")
    # running the seed again (every deploy does) adds nothing
    with SessionLocal() as s:
        seed_core(s)
        s.commit()
    assert len(opts("divisions")) == len(divisions)
