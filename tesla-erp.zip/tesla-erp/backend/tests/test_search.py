"""Phase 10: global search across every kind of record, grouped, permission- and scope-respecting, and fast."""
import time

from sqlalchemy import text

from tests.test_finance import get

API = "/api/v1"


def search(client, h, q, **kw) -> dict:
    return {g["type"]: g for g in get(client, h, "/search", q=q, **kw)}


def one(owner_engine, sql, **params):
    with owner_engine.connect() as c:
        return c.execute(text(sql), params).scalar()


def test_director_finds_every_kind_of_record(client, as_user, owner_engine):
    d = as_user("director")
    checks = {
        "customer": "select customer_name from customers limit 1",
        "lead": "select lead_number from leads limit 1",
        "enquiry": "select enquiry_number from enquiries limit 1",
        "site_visit": "select visit_number from site_visits limit 1",
        "boq": "select boq_number from boqs limit 1",
        "quotation": "select quotation_number from quotations where quotation_number is not null limit 1",
        "sales_order": "select so_number from sales_orders limit 1",
        "project": "select project_number from projects limit 1",
        "task": "select title from project_tasks limit 1",
        "material_request": "select mr_number from material_requests where mr_number is not null limit 1",
        "purchase_request": "select pr_number from purchase_requests where pr_number is not null limit 1",
        "purchase_order": "select po_number from purchase_orders where po_number is not null limit 1",
        "grn": "select grn_number from grns limit 1",
        "invoice": "select invoice_number from invoices where invoice_number is not null limit 1",
        "receipt": "select receipt_number from receipts limit 1",
        "supplier_bill": "select supplier_invoice_no from supplier_invoices limit 1",
        "supplier_payment": "select payment_number from supplier_payments limit 1",
        "expense": "select expense_number from expense_claims where expense_number is not null limit 1",
        "employee": "select full_name from employees limit 1",
        "material_issue": "select issue_number from material_issues where issue_number is not null limit 1",
        "supplier": "select supplier_name from suppliers limit 1",
        "item": "select item_code from items limit 1",
    }
    for kind, sql in checks.items():
        q = one(owner_engine, sql)
        assert q, f"no demo {kind}"
        res = search(client, d, q)
        assert kind in res, (kind, q, list(res))
        hit = res[kind]["items"][0]
        assert hit["href"].startswith("/") and "?id=" in hit["href"] and hit["title"], (kind, hit)
        assert set(hit) == {"id", "title", "subtitle", "href"}
    # an exact document number comes first
    inv = one(owner_engine, "select invoice_number from invoices where invoice_number is not null limit 1")
    assert inv in search(client, d, inv)["invoice"]["items"][0]["subtitle"]
    # RFQ by number
    rfq_n = one(owner_engine, "select rfq_number from rfqs where rfq_number is not null limit 1")
    if rfq_n:
        assert "rfq" in search(client, d, rfq_n)


def test_results_grouped_with_labels_limit_and_types(client, as_user):
    d = as_user("director")
    groups = get(client, d, "/search", q="ABC")
    assert len(groups) >= 3 and all(g["label"] and g["items"] for g in groups)
    assert all(len(g["items"]) <= 5 for g in groups)
    only = get(client, d, "/search", q="ABC", types="project,invoice", limit=20)
    assert {g["type"] for g in only} <= {"project", "invoice"}
    assert client.get(f"{API}/search", headers=d, params={"q": "a"}).status_code == 422
    # wildcards are taken literally
    assert get(client, d, "/search", q="%%") == []


def test_sales_own_scope_and_no_finance_or_hr_leaks(client, as_user, owner_engine):
    ids = {u: one(owner_engine, "select id::text from users where username = :u", u=u) for u in ("sales1", "sales2")}
    other = one(owner_engine, "select lead_number from leads where sales_person_id is distinct from cast(:me as uuid) "
                              "and created_by is distinct from cast(:me as uuid) limit 1", me=ids["sales1"])
    mine = one(owner_engine, "select lead_number from leads where sales_person_id = :u or created_by = :u limit 1",
               u=ids["sales1"])
    s1 = as_user("sales1")
    assert other and mine
    assert "lead" not in search(client, s1, other)
    assert "lead" in search(client, s1, mine)
    assert "lead" in search(client, as_user("director"), other)
    # salesperson: no supplier bills, payments, purchase orders, GRNs, stock or expense claims of others
    res = search(client, s1, "DEHN")
    assert not ({"supplier_bill", "supplier_payment", "purchase_order", "grn", "supplier"} & set(res))
    # employees are found by name only — no personal, bank or salary data in the result
    emp = one(owner_engine, "select full_name from employees where pan is not null or bank_account_number is not null "
                            "limit 1") or one(owner_engine, "select full_name from employees limit 1")
    hits = search(client, s1, emp).get("employee", {"items": []})["items"]
    for h in hits:
        assert set(h) == {"id", "title", "subtitle", "href"}
        assert "₹" not in h["subtitle"] and "@" not in h["subtitle"]


def test_employee_and_store_see_only_what_they_may(client, as_user, owner_engine):
    emp = as_user("employee1")
    # an employee finds their own expense claims, not other people's
    others = one(owner_engine, """select e.expense_number from expense_claims e join employees m on m.id = e.employee_id
                                  join users u on u.id = m.user_id where u.username <> 'employee1'
                                  and e.expense_number is not null limit 1""")
    if others:
        assert "expense" not in search(client, emp, others)
    for q in ("ABC", "DEHN", "TCE"):
        found = search(client, emp, q)
        assert set(found) <= {"expense", "task"}            # their own claims and tasks only
        for t in found.get("task", {"items": []})["items"]:
            assert t["href"].startswith("/projects/tasks")      # cannot open the project itself
    store = search(client, as_user("store1"), "ABC")
    assert "invoice" not in store and "receipt" not in store and "quotation" not in store
    inv = one(owner_engine, "select invoice_number from invoices where invoice_number is not null limit 1")
    assert "invoice" not in search(client, as_user("store1"), inv)
    assert "invoice" in search(client, as_user("accounts1"), inv)


def test_search_is_fast_with_many_records(client, as_user, owner_engine):
    with owner_engine.begin() as c:
        c.execute(text("""insert into leads (id, lead_number, title, company_name, source, status, created_at, updated_at,
                                             row_version)
                          select gen_random_uuid(), 'TCE/LD/X/' || g, 'Bulk lead ' || g, 'Company ' || g, 'website', 'new',
                                 now(), now(), 1 from generate_series(1, 5000) g"""))
        c.execute(text("analyze leads"))
    d = as_user("director")
    get(client, d, "/search", q="warm up")
    started = time.perf_counter()
    res = search(client, d, "Bulk lead 4321")
    elapsed = time.perf_counter() - started
    assert res["lead"]["items"][0]["title"] == "Bulk lead 4321"
    assert elapsed < 1.0, elapsed
