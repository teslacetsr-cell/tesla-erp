"""Phase 11 — Tally connector, ERP side: XML builders, the agent protocol (docs/TALLY_CONNECTOR.md §2), hooks,
retry / idempotency, backfill and reconciliation."""
import xml.etree.ElementTree as ET
from datetime import date
from decimal import Decimal as D
from types import SimpleNamespace

import pytest
from sqlalchemy import text

from app.tally import builders as B
from app.tally import xml as X
from tests.test_purchase import supplier

API = "/api/v1"
START = "2026-09-01"
OK_REPLY = ("<RESPONSE><CREATED>1</CREATED><ALTERED>0</ALTERED><DELETED>0</DELETED><LASTVCHID>{id}</LASTVCHID>"
            "<LASTMID>0</LASTMID><COMBINED>0</COMBINED><IGNORED>0</IGNORED><ERRORS>0</ERRORS><CANCELLED>0</CANCELLED>"
            "<EXCEPTIONS>0</EXCEPTIONS></RESPONSE>")


def err_reply(msg: str) -> str:
    return (f"<RESPONSE><LINEERROR>{msg}</LINEERROR><CREATED>0</CREATED><ALTERED>0</ALTERED><LASTVCHID>0</LASTVCHID>"
            "<ERRORS>1</ERRORS><CANCELLED>0</CANCELLED><EXCEPTIONS>0</EXCEPTIONS></RESPONSE>")


# ============================================================================================ XML (pure)
def _amounts(root) -> dict[str, D]:
    v = root if root.tag == "VOUCHER" else root.find(".//VOUCHER")
    out: dict[str, D] = {}
    for le in v.findall("ALLLEDGERENTRIES.LIST"):
        name = le.findtext("LEDGERNAME")
        out[name] = out.get(name, D(0)) + D(le.findtext("AMOUNT"))
        assert le.findtext("ISDEEMEDPOSITIVE") == ("Yes" if D(le.findtext("AMOUNT")) < 0 else "No")
    return out


def test_voucher_xml_well_formed_balanced_dates_and_escaping():
    v = X.Voucher(remote_id="erp-invoice-1", vch_type="Sales", number="TCE/2627/0001", vdate=date(2026, 10, 7),
                  party="A & B <Hospital>", narration="Phase 1 — earthing & LPS",
                  entries=[X.Entry("A & B <Hospital>", D("118000.00"),
                                   bills=[X.BillRef("TCE/2627/0001", "New Ref", D("118000"))]),
                           X.Entry("Sales — Projects & Services", D("-100000")),
                           X.Entry("Output CGST", D("-9000")), X.Entry("Output SGST", D("-9000")),
                           X.Entry("Round Off", D("0"))])
    doc = X.vouchers_envelope("Tesla Consulting Engineers", X.voucher_xml(v))
    root = ET.fromstring(doc)  # well-formed
    assert root.findtext(".//REPORTNAME") == "Vouchers"
    assert root.findtext(".//SVCURRENTCOMPANY") == "Tesla Consulting Engineers"
    vch = root.find(".//VOUCHER")
    assert vch.get("VCHTYPE") == "Sales" and vch.get("ACTION") == "Create" and vch.get("REMOTEID") == "erp-invoice-1"
    assert vch.findtext("DATE") == "20261007" and vch.findtext("VOUCHERNUMBER") == "TCE/2627/0001"
    amounts = _amounts(root)
    assert amounts == {"A & B <Hospital>": D("-118000.00"), "Sales — Projects & Services": D("100000.00"),
                       "Output CGST": D("9000.00"), "Output SGST": D("9000.00")}  # zero round-off dropped
    assert sum(amounts.values()) == 0
    bill = vch.find(".//BILLALLOCATIONS.LIST")
    assert bill.findtext("NAME") == "TCE/2627/0001" and bill.findtext("BILLTYPE") == "New Ref"
    assert bill.findtext("AMOUNT") == "-118000.00"
    with pytest.raises(X.VoucherNotBalanced):
        X.voucher_xml(X.Voucher(remote_id="x", vch_type="Journal", number="1", vdate=date(2026, 10, 1),
                                entries=[X.Entry("A", D("10")), X.Entry("B", D("-9.99"))]))


def test_gst_split_by_rate_and_round_off():
    items = [SimpleNamespace(tax_rate=D("18"), cgst=D("900.01"), sgst=D("900.01"), igst=D(0)),
             SimpleNamespace(tax_rate=D("12"), cgst=D("60.00"), sgst=D("60.00"), igst=D(0)),
             SimpleNamespace(tax_rate=D("18"), cgst=D("90.00"), sgst=D("90.00"), igst=D(0))]
    split = B._split_by_rate(items, "cgst", D("1050.00"))      # header differs from the line sum by 1 paisa
    assert split == {D("18"): D("990.00"), D("12"): D("60.00")} and sum(split.values()) == D("1050.00")
    assert B._split_by_rate(items, "igst", D(0)) == {}
    assert B._share(D("100.00"), {D("18"): D("2"), D("12"): D("1")}) == {D("18"): D("66.67"), D("12"): D("33.33")}
    # a negative round-off on a sales invoice becomes a debit
    v = X.Voucher(remote_id="r", vch_type="Sales", number="N1", vdate=date(2026, 4, 1), party="P",
                  entries=[X.Entry("P", D("1180")), X.Entry("Sales", D("-1000.40")), X.Entry("CGST", D("-90.04")),
                           X.Entry("SGST", D("-90.04")), X.Entry("Round Off", D("0.48"))])
    a = _amounts(ET.fromstring(X.voucher_xml(v)))
    assert a["Round Off"] == D("-0.48") and sum(a.values()) == 0


def test_masters_and_cancel_and_export_xml():
    m = X.LedgerMaster(name="ABC Hospital & Research", parent="Sundry Debtors", gstin="32AAACA1234A1Z5",
                       state="Kerala", address=["MG Road", "Kochi"], pincode="682001", bill_wise=True)
    root = ET.fromstring(X.masters_envelope("TCE", [m, X.LedgerMaster(name="Output CGST", parent="Duties & Taxes",
                                                                        gst_duty_head="Central Tax")]))
    assert root.findtext(".//REPORTNAME") == "All Masters"
    led = root.findall(".//LEDGER")
    assert led[0].get("NAME") == "ABC Hospital & Research" and led[0].findtext("PARENT") == "Sundry Debtors"
    assert led[0].findtext("PARTYGSTIN") == "32AAACA1234A1Z5" and led[0].findtext("LEDSTATENAME") == "Kerala"
    assert [a.text for a in led[0].findall("ADDRESS.LIST/ADDRESS")] == ["MG Road", "Kochi"]
    assert led[0].findtext("ISBILLWISEON") == "Yes" and led[1].findtext("GSTDUTYHEAD") == "Central Tax"
    c = ET.fromstring(X.vouchers_envelope("TCE", X.cancel_voucher_xml("erp-receipt-1", "Receipt", "RCT/1",
                                                                         date(2026, 10, 2), "Cheque bounced")))
    v = c.find(".//VOUCHER")
    assert v.get("ACTION") == "Cancel" and v.findtext("VOUCHERNUMBER") == "RCT/1" and v.findtext("DATE") == "20261002"
    e = ET.fromstring(X.ledger_balances_request("TCE"))
    assert e.findtext(".//TALLYREQUEST") == "Export" and e.findtext(".//COLLECTION/TYPE") == "Ledger"


def test_reading_tally_replies():
    ok = X.parse_import_reply(OK_REPLY.format(id=412))
    assert ok.success and ok.created == 1 and ok.last_vch_id == "412"
    bad = X.parse_import_reply(err_reply("Ledger &apos;ABC Hospital&apos; does not exist!"))
    assert not bad.success and bad.message == "Ledger 'ABC Hospital' does not exist!"
    dup = X.parse_import_reply(err_reply("Voucher Number 'TCE/2627/0001' already exists!"))
    assert dup.success and dup.duplicate_only
    assert not X.parse_import_reply("<html>Server Error</html>").success
    assert not X.parse_import_reply("<RESPONSE><ERRORS>2</ERRORS></RESPONSE>").success
    ledgers = X.parse_ledger_export(
        '<ENVELOPE><BODY><DATA><COLLECTION><LEDGER NAME="A &amp; B" RESERVEDNAME=""><PARENT TYPE="String">Sundry '
        'Debtors</PARENT><CLOSINGBALANCE TYPE="Amount">-1234.50</CLOSINGBALANCE></LEDGER><LEDGER NAME="Sales">'
        '<PARENT>Sales Accounts</PARENT><CLOSINGBALANCE>500.00</CLOSINGBALANCE></LEDGER></COLLECTION></DATA></BODY>'
        '</ENVELOPE>')
    assert [(lb.name, lb.parent, lb.dr_balance) for lb in ledgers] == [("A & B", "Sundry Debtors", D("1234.50")),
                                                                      ("Sales", "Sales Accounts", D("-500.00"))]
    assert X.export_error(err_reply("Could not set 'SVCurrentCompany' to 'X'")).startswith("Could not set")


# ============================================================================================ API helpers
def get(client, h, path, **params):
    r = client.get(f"{API}{path}", headers=h, params=params)
    assert r.status_code == 200, r.text
    return r.json()["data"]


def post(client, h, path, body=None, status=200):
    r = client.post(f"{API}{path}", headers=h, json=body or {})
    assert r.status_code == status, r.text
    return r.json().get("data")


def setup_sync(client, h, types=None, enabled=True, start=START) -> dict:
    st = get(client, h, "/tally/status")["settings"]
    vt = {k: "erp" for k in st["voucher_types"]} if types is None else types
    r = client.put(f"{API}/tally/settings", headers=h, json={
        "enabled": enabled, "poll_seconds": 60, "tally_company": "Tesla Consulting Engineers", "start_date": start,
        "voucher_types": vt, "create_party_ledgers": True, "row_version": st["row_version"]})
    assert r.status_code == 200, r.text
    return r.json()["data"]


def make_key(client, h) -> dict:
    k = post(client, h, "/tally/keys", {"name": "Accounts PC"})
    assert k["key"].startswith("tck_") and len(k["key"]) == 47
    return {"Authorization": f"Bearer {k['key']}", "User-Agent": "TCE-Tally-Connector/1.0.0", "_id": k["id"]}


def agent(client, key, path, body=None, status=200):
    h = {k: v for k, v in key.items() if not k.startswith("_")}
    r = client.post(f"{API}/tally-agent{path}", headers=h, json=body or {})
    assert r.status_code == status, r.text
    return r.json().get("data") if status == 200 else r.json()


def lease(client, key, limit=20):
    return agent(client, key, "/jobs/lease", {"limit": limit})


def result(client, key, job_id, response=None, ok=True, error=None):
    return agent(client, key, f"/jobs/{job_id}/result",
                 {"ok": ok, "status_code": 200 if ok else None, "response": response, "error": error,
                  "elapsed_ms": 12})


def service_invoice(client, as_user, rate="12500", name="Bengaluru Tech Park", state="29") -> dict:
    acc = as_user("accounts1")
    c = post(client, as_user("sales1"), "/customers", {"customer_name": name, "state_code": state}, status=201)
    inv = post(client, acc, "/invoices", {"customer_id": c["id"], "bill_type": "service", "items": [
        {"description": "Earth resistance testing", "hsn_sac": "998346", "quantity": "1", "unit": "JOB",
         "rate": rate, "tax_rate": "18"},
        {"description": "Lightning arrester", "hsn_sac": "85354010", "quantity": "3", "unit": "NOS",
         "rate": "1999.99", "tax_rate": "12"}]}, status=201)
    return post(client, acc, f"/invoices/{inv['id']}/issue")


def jobs(client, h, **params):
    return get(client, h, "/tally/jobs", page_size=200, **params)


# ============================================================================================ permissions & auth
def test_permissions_and_agent_key_auth(client, as_user):
    assert client.get(f"{API}/tally/status", headers=as_user("sales1")).status_code == 403
    assert client.get(f"{API}/tally/status", headers=as_user("pm1")).status_code == 403
    assert client.get(f"{API}/tally/status", headers=as_user("director")).status_code == 200
    acc = as_user("accounts1")
    st = get(client, acc, "/tally/status")
    assert st["settings"]["enabled"] is False and set(st["settings"]["voucher_types"].values()) == {"tally"}
    assert st["connector"] is None
    # no key / wrong key / a user's token
    for hdr in ({}, {"Authorization": "Bearer tck_nope"}, acc):
        r = client.post(f"{API}/tally-agent/heartbeat", headers=hdr, json={})
        assert r.status_code == 401 and r.json()["error"]["code"] == "BAD_CONNECTOR_KEY"
    key = make_key(client, acc)
    hb = agent(client, key, "/heartbeat", {"agent_version": "1.0.0", "host": "ACCOUNTS-PC", "tally_ok": True,
                                          "tally_url": "http://localhost:9000", "tally_company": "Tesla Consulting Engineers"})
    assert hb["enabled"] is False and hb["poll_seconds"] == 60 and hb["company"] == "Tesla Consulting Engineers"
    assert hb["server_time"].endswith("+05:30")
    st = get(client, acc, "/tally/status")
    assert st["connector"]["online"] is True and st["connector"]["host"] == "ACCOUNTS-PC"
    assert st["connector"]["tally_ok"] is True and "key" not in st["keys"][0] and "key_hash" not in st["keys"][0]
    # sync off -> nothing leased
    assert lease(client, key) == []
    # only tally.update may create keys
    assert client.post(f"{API}/tally/keys", headers=as_user("manager"), json={"name": "x"}).status_code == 403
    post(client, acc, f"/tally/keys/{key['_id']}/revoke")
    assert agent(client, key, "/heartbeat", {}, status=401)["error"]["code"] == "BAD_CONNECTOR_KEY"


# ============================================================================================ hooks & queue
def test_issuing_an_invoice_queues_one_voucher_after_its_ledger(client, as_user):
    acc = as_user("accounts1")
    setup_sync(client, acc)
    key = make_key(client, acc)
    inv = service_invoice(client, as_user)
    rows = jobs(client, acc)
    assert [(j["action"], j["status"]) for j in sorted(rows, key=lambda j: j["seq"])] == [
        ("master", "pending"), ("create", "pending")]
    voucher = [j for j in rows if j["action"] == "create"][0]
    assert voucher["label"] == f"Sales {inv['invoice_number']}" and voucher["waiting_for"] == "Ledger: Bengaluru Tech Park"
    full = get(client, acc, f"/tally/jobs/{voucher['id']}")
    root = ET.fromstring(full["xml"])
    amounts = _amounts(root)
    assert sum(amounts.values()) == 0
    assert amounts["Bengaluru Tech Park"] == -D(inv["grand_total"])
    assert amounts["Sales — Projects & Services"] == D(inv["taxable"])
    assert amounts["Output IGST"] == D(inv["igst"]) and "Output CGST" not in amounts  # inter-state
    assert amounts.get("Round Off", D(0)) == D(inv["round_off"])  # credited, like the sales and GST
    assert root.findtext(".//PLACEOFSUPPLY") == "Karnataka"
    assert root.findtext(".//DATE") == inv["invoice_date"].replace("-", "")
    # the hook is idempotent: posting again queues nothing
    from app.core.db import SessionLocal
    from app.tally import service

    with SessionLocal() as s:
        assert service.enqueue_document(s, "invoice", inv["id"]) is None
    # badge
    assert get(client, acc, "/tally/doc-status", entity_type="invoice", entity_id=inv["id"])["state"] == "queued"

    agent(client, key, "/heartbeat", {"tally_ok": True})
    leased = lease(client, key)
    assert [j["label"] for j in leased] == ["Ledger: Bengaluru Tech Park", f"Sales {inv['invoice_number']}"]
    assert leased[0]["kind"] == "import" and leased[0]["attempt"] == 1 and "<LEDGER" in leased[0]["xml"]
    assert lease(client, key) == []  # both reserved
    assert result(client, key, leased[0]["id"], OK_REPLY.format(id=0))["status"] == "done"
    assert result(client, key, leased[1]["id"], OK_REPLY.format(id=77))["status"] == "done"
    # a late duplicate result is ignored
    assert result(client, key, leased[1]["id"], err_reply("boom"))["status"] == "done"
    ds = get(client, acc, "/tally/doc-status", entity_type="invoice", entity_id=inv["id"])
    assert ds["state"] == "in_tally" and ds["in_tally_at"]
    assert get(client, acc, "/tally/status")["counts"]["done"] == 2
    # a second invoice for the same customer does not queue the ledger again
    c_id = inv["customer_id"]
    inv2 = post(client, acc, "/invoices", {"customer_id": c_id, "bill_type": "service", "items": [
        {"description": "AMC visit", "hsn_sac": "998346", "quantity": "1", "unit": "JOB", "rate": "1000",
         "tax_rate": "18"}]}, status=201)
    post(client, acc, f"/invoices/{inv2['id']}/issue")
    assert len(jobs(client, acc, status="pending")) == 1


def test_disabled_voucher_type_or_before_start_date_queues_nothing(client, as_user):
    acc = as_user("accounts1")
    setup_sync(client, acc, types={"sales": "tally", "receipt": "erp"})
    inv = service_invoice(client, as_user)
    assert jobs(client, acc) == []
    assert get(client, acc, "/tally/doc-status", entity_type="invoice", entity_id=inv["id"])["state"] is None
    setup_sync(client, acc, start="2099-01-01")
    service_invoice(client, as_user, name="Later Co")
    assert jobs(client, acc) == []
    # a start date is required once anything is pushed
    st = get(client, acc, "/tally/status")["settings"]
    r = client.put(f"{API}/tally/settings", headers=acc, json={**st, "start_date": None, "voucher_types": {"sales": "erp"}})
    assert r.status_code == 400 and r.json()["error"]["code"] == "START_DATE_REQUIRED"


def test_lease_expiry_hands_the_job_out_again(client, as_user, owner_engine):
    acc = as_user("accounts1")
    setup_sync(client, acc)
    key = make_key(client, acc)
    service_invoice(client, as_user)
    first = lease(client, key)
    assert len(first) == 2 and lease(client, key) == []
    with owner_engine.begin() as c:
        c.execute(text("update tally_jobs set leased_until = now() - interval '1 minute'"))
    again = lease(client, key)
    assert [j["id"] for j in again] == [j["id"] for j in first] and again[0]["attempt"] == 2


def test_tally_down_line_error_retry_and_dependency(client, as_user):
    acc = as_user("accounts1")
    setup_sync(client, acc)
    key = make_key(client, acc)
    inv = service_invoice(client, as_user)
    master, voucher = lease(client, key)
    # Tally not reachable: kept; the rest of the batch is released too
    r = result(client, key, master["id"], ok=False, error="Connection refused (http://localhost:9000)")
    assert r["status"] == "retry"
    pending = jobs(client, acc, status="pending")
    assert len(pending) == 2 and any("Connection refused" in (j["last_error"] or "") for j in pending)
    master, voucher = lease(client, key)
    assert voucher["attempt"] == 1  # it never reached Tally
    # Tally rejects the ledger: the voucher is held back until it is fixed
    r = result(client, key, master["id"], err_reply("Group &apos;Sundry Debtors&apos; does not exist!"))
    assert r["status"] == "failed"
    failed = jobs(client, acc, status="failed")
    assert len(failed) == 1 and failed[0]["last_error"] == "Tally: Group 'Sundry Debtors' does not exist!"
    with_owner_reset = jobs(client, acc, status="leased")
    assert with_owner_reset and with_owner_reset[0]["id"] == voucher["id"]
    result(client, key, voucher["id"], err_reply("Ledger &apos;Bengaluru Tech Park&apos; does not exist!"))
    ds = get(client, acc, "/tally/doc-status", entity_type="invoice", entity_id=inv["id"])
    assert ds["state"] == "failed" and "does not exist" in ds["last_error"]
    # Accounts were told
    assert any("Tally did not accept" in n["title"] for n in get(client, acc, "/notifications"))
    # retry one: only the master comes back; the voucher (failed) stays until retried
    post(client, acc, f"/tally/jobs/{failed[0]['id']}/retry")
    again = lease(client, key)
    assert [j["id"] for j in again] == [master["id"]] and again[0]["attempt"] == 3
    result(client, key, master["id"], OK_REPLY.format(id=0))
    assert post(client, acc, "/tally/jobs/retry-failed")["retried"] == 1
    again = lease(client, key)
    assert [j["id"] for j in again] == [voucher["id"]]
    # Tally already has it (sent by an earlier attempt): counts as done
    r = result(client, key, voucher["id"], err_reply(f"Voucher Number &apos;{inv['invoice_number']}&apos; already exists!"))
    assert r["status"] == "done"
    assert get(client, acc, "/tally/doc-status", entity_type="invoice", entity_id=inv["id"])["state"] == "in_tally"
    # only failed entries can be retried
    r = client.post(f"{API}/tally/jobs/{voucher['id']}/retry", headers=acc)
    assert r.status_code == 400 and r.json()["error"]["code"] == "NOT_FAILED"


def test_master_dependency_holds_vouchers(client, as_user):
    acc = as_user("accounts1")
    setup_sync(client, acc)
    key = make_key(client, acc)
    service_invoice(client, as_user)
    master, _ = lease(client, key, limit=2)
    result(client, key, master["id"], err_reply("Group 'X' does not exist!"))
    # the voucher (lease expired / released) is not handed out while its ledger has failed
    from app.core.db import SessionLocal
    from app.tally.models import TallyJob

    with SessionLocal() as s:
        s.query(TallyJob).filter(TallyJob.status == "leased").update({"status": "pending", "leased_until": None})
        s.commit()
    assert lease(client, key) == []
    waiting = [j for j in jobs(client, acc, status="pending")]
    assert waiting[0]["waiting_for"] == "Ledger: Bengaluru Tech Park"


def test_receipt_alter_and_cancel(client, as_user):
    acc = as_user("accounts1")
    setup_sync(client, acc)
    key = make_key(client, acc)
    inv = service_invoice(client, as_user)
    for j in lease(client, key):
        result(client, key, j["id"], OK_REPLY.format(id=1))
    rc = post(client, acc, "/receipts", {"customer_id": inv["customer_id"], "mode": "neft", "reference_no": "UTR9",
                                         "amount": "5000", "tds_amount": "250", "allocations": [
                                             {"document_id": inv["id"], "amount": "5000", "tds": "250"}]}, status=201)
    (job,) = lease(client, key)
    root = ET.fromstring(job["xml"])
    a = _amounts(root)
    assert a == {"Bank Account": D("-5000.00"), "TDS Receivable": D("-250.00"), "Bengaluru Tech Park": D("5250.00")}
    bills = root.findall(".//BILLALLOCATIONS.LIST")
    assert [(b.findtext("NAME"), b.findtext("BILLTYPE"), b.findtext("AMOUNT")) for b in bills] == [
        (inv["invoice_number"], "Agst Ref", "5250.00")]
    result(client, key, job["id"], OK_REPLY.format(id=2))
    # taking money off the invoice alters the same voucher
    alloc = rc["allocations"][0]["id"]
    post(client, acc, f"/receipts/{rc['id']}/allocations/{alloc}/remove")
    (alter,) = lease(client, key)
    root = ET.fromstring(alter["xml"])
    assert root.find(".//VOUCHER").get("ACTION") == "Alter" and alter["label"].endswith("(changed)")
    assert root.findtext(".//BILLALLOCATIONS.LIST/BILLTYPE") == "On Account"
    result(client, key, alter["id"], OK_REPLY.format(id=2).replace("<CREATED>1", "<CREATED>0").replace(
        "<ALTERED>0", "<ALTERED>1"))
    # cancelling it in the ERP cancels the Tally voucher
    post(client, acc, f"/receipts/{rc['id']}/cancel", {"reason": "Cheque returned unpaid"})
    (cancel,) = lease(client, key)
    v = ET.fromstring(cancel["xml"]).find(".//VOUCHER")
    assert v.get("ACTION") == "Cancel" and v.findtext("VOUCHERNUMBER") == rc["receipt_number"]
    result(client, key, cancel["id"], OK_REPLY.format(id=0))
    assert get(client, acc, "/tally/doc-status", entity_type="receipt", entity_id=rc["id"])["state"] == "cancelled"
    # cancelled before it was ever sent: nothing goes to Tally
    rc2 = post(client, acc, "/receipts", {"customer_id": inv["customer_id"], "mode": "cash", "amount": "100"}, status=201)
    post(client, acc, f"/receipts/{rc2['id']}/cancel", {"reason": "Entered twice"})
    assert lease(client, key) == []
    assert get(client, acc, "/tally/doc-status", entity_type="receipt", entity_id=rc2["id"])["state"] == "cancelled"


def test_bill_payment_expense_and_credit_note_vouchers(client, as_user):
    acc = as_user("accounts1")
    setup_sync(client, acc)
    key = make_key(client, acc)
    dehn = supplier(client, acc)
    bill = post(client, acc, "/supplier-invoices", {"supplier_id": dehn["id"], "supplier_invoice_no": "SVC-77",
                                                    "supplier_invoice_date": "2026-09-30", "items": [
        {"description": "Crane hire", "quantity": "1", "unit": "JOB", "rate": "8000.30", "tax_rate": "18"}]}, status=201)
    bill = post(client, acc, f"/supplier-invoices/{bill['id']}/submit")
    pay = post(client, acc, "/supplier-payments", {"supplier_id": dehn["id"], "mode": "neft", "amount": "5000",
                                                   "tds_amount": "80", "allocations": [
                                                       {"document_id": bill["id"], "amount": "5000", "tds": "80"}]},
               status=201)
    inv = service_invoice(client, as_user)
    cn = post(client, acc, f"/invoices/{inv['id']}/credit-notes", {"reason": "Rate corrected", "taxable": "1000"},
              status=201)
    leased = {j["label"]: j for j in lease(client, key)}
    purchase = ET.fromstring(leased[f"Purchase bill {bill['bill_number']}"]["xml"])
    a = _amounts(purchase)
    assert sum(a.values()) == 0 and a[dehn["supplier_name"]] == D(bill["grand_total"])
    assert purchase.findtext(".//REFERENCE") == "SVC-77" and purchase.find(".//VOUCHER").get("VCHTYPE") == "Purchase"
    gst = sum((v for k, v in a.items() if k.startswith("Input ")), D(0))
    assert a["Purchases"] == -D(bill["taxable"]) and gst == -(D(bill["cgst"]) + D(bill["sgst"]) + D(bill["igst"]))
    payment = ET.fromstring(leased[f"Supplier payment {pay['payment_number']}"]["xml"])
    a = _amounts(payment)
    assert a["TDS Payable"] == D("80.00") and a["Bank Account"] == D("5000.00") and sum(a.values()) == 0
    assert payment.findtext(".//BILLALLOCATIONS.LIST/NAME") == "SVC-77"
    credit = ET.fromstring(leased[f"Credit note {cn['cn_number']}"]["xml"])
    a = _amounts(credit)
    assert sum(a.values()) == 0 and a["Sales — Projects & Services"] == D("-1000.00")
    assert credit.findtext(".//BILLALLOCATIONS.LIST/BILLTYPE") == "Agst Ref"
    assert credit.findtext(".//BILLALLOCATIONS.LIST/NAME") == inv["invoice_number"]
    # expense claim: approved -> Journal, paid -> Payment
    e = as_user("employee1")
    cat = [c for c in get(client, e, "/expenses/options")["categories"] if c["name"].startswith("Local conveyance")][0]
    claim = post(client, e, "/expenses", {"category_id": cat["id"], "expense_date": "2026-10-01", "amount": "300",
                                          "description": "Auto to site"}, status=201)
    number = post(client, e, f"/expenses/{claim['id']}/submit")["expense_number"]
    for who in ("manager", "accounts1"):
        h = as_user(who)
        req = [x for x in get(client, h, "/approvals/inbox") if number in x["entity_label"]]
        post(client, h, f"/approvals/{req[0]['id']}/decide", {"decision": "approved"})
    post(client, acc, f"/expenses/{claim['id']}/pay", {"payment_mode": "cash"})
    exp = {j["label"]: j for j in lease(client, key)}
    j = ET.fromstring(exp[f"Expense {number}"]["xml"])
    assert j.find(".//VOUCHER").get("VCHTYPE") == "Journal"
    assert _amounts(j) == {"Travelling & Conveyance": D("-300.00"), "Employee Reimbursements Payable": D("300.00")}
    p = ET.fromstring(exp[f"Expense payment {number}"]["xml"])
    assert _amounts(p) == {"Employee Reimbursements Payable": D("-300.00"), "Cash in Hand": D("300.00")}


def test_mapping_overrides_names_and_gst_rates(client, as_user):
    acc = as_user("accounts1")
    setup_sync(client, acc)
    key = make_key(client, acc)
    mp = get(client, acc, "/tally/mapping")
    sales = [r for r in mp["accounts"] if r["erp_name"] == "Sales — Projects & Services"][0]
    assert sales["default"] == "Sales — Projects & Services" and sales["tally_name"] is None
    assert not any(r["erp_name"] == "Sundry Debtors" for r in mp["accounts"])
    igst18 = [r for r in mp["gst"] if r["erp_key"] == "output_igst@18"][0]
    assert igst18["default"] == "Output IGST"
    r = client.put(f"{API}/tally/mapping", headers=acc, json={"items": [
        {"kind": "account", "erp_key": sales["erp_key"], "tally_name": "Sales (Works Contract)"},
        {"kind": "gst", "erp_key": "output_igst@18", "tally_name": "IGST Output @18%"}]})
    assert r.status_code == 200 and r.json()["data"]["changed"] == 2
    service_invoice(client, as_user)
    voucher = [j for j in lease(client, key) if j["label"].startswith("Sales")][0]
    a = _amounts(ET.fromstring(voucher["xml"]))
    assert "Sales (Works Contract)" in a and "IGST Output @18%" in a and "Output IGST" in a  # 12% stays default
    # a waiting entry is rebuilt when a name changes
    service_invoice(client, as_user, name="Second Customer")
    waiting = [j for j in jobs(client, acc, status="pending") if j["action"] == "create"][0]
    client.put(f"{API}/tally/mapping", headers=acc, json={"items": [
        {"kind": "account", "erp_key": sales["erp_key"], "tally_name": "Sales WC 2"}]})
    assert "Sales WC 2" in get(client, acc, f"/tally/jobs/{waiting['id']}")["xml"]
    # the ERP ledger list for Tally includes the per-rate ledger
    job = post(client, acc, "/tally/ledgers/push")
    full = get(client, acc, f"/tally/jobs/{job['id']}")
    names = [el.get("NAME") for el in ET.fromstring(full["xml"]).iter("LEDGER")]
    assert "IGST Output @18%" in names and "Sales WC 2" in names and "Sundry Debtors" not in names
    # clearing the name goes back to the default
    client.put(f"{API}/tally/mapping", headers=acc, json={"items": [
        {"kind": "account", "erp_key": sales["erp_key"], "tally_name": ""}]})
    assert [r for r in get(client, acc, "/tally/mapping")["accounts"] if r["erp_key"] == sales["erp_key"]][0][
        "tally_name"] is None


def test_backfill_queues_each_document_once_in_date_order(client, as_user):
    acc = as_user("accounts1")
    # the demo data already has an invoice, receipt, bill, payment and a paid claim; nothing was queued
    assert jobs(client, acc) == []
    setup_sync(client, acc)
    out = post(client, acc, "/tally/backfill", {})
    assert out["queued"] >= 6 and out["by_type"]["invoice"] >= 1 and out["by_type"]["receipt"] >= 1
    assert out["by_type"]["supplier_invoice"] >= 1 and out["by_type"]["expense_payment"] >= 1
    assert post(client, acc, "/tally/backfill", {})["queued"] == 0
    vouchers = sorted((j for j in jobs(client, acc) if j["action"] == "create"), key=lambda j: j["seq"])
    dates = [j["doc_date"] for j in vouchers]
    assert dates == sorted(dates)


def test_reconciliation_compares_erp_and_tally_balances(client, as_user):
    acc = as_user("accounts1")
    setup_sync(client, acc)
    key = make_key(client, acc)
    inv = service_invoice(client, as_user)
    for j in lease(client, key):
        result(client, key, j["id"], OK_REPLY.format(id=1))
    rec = post(client, acc, "/tally/reconciliations")
    assert rec["status"] == "waiting"
    (job,) = lease(client, key)
    assert job["kind"] == "export" and "<TYPE>Ledger</TYPE>" in job["xml"]
    total = D(inv["grand_total"])
    reply = ("<ENVELOPE><BODY><DATA><COLLECTION>"
             f'<LEDGER NAME="Bengaluru Tech Park"><PARENT>Sundry Debtors</PARENT><CLOSINGBALANCE>-{total}</CLOSINGBALANCE></LEDGER>'
             f'<LEDGER NAME="Sales — Projects &amp; Services"><PARENT>Sales Accounts</PARENT><CLOSINGBALANCE>1.00</CLOSINGBALANCE></LEDGER>'
             "</COLLECTION></DATA></BODY></ENVELOPE>")
    assert result(client, key, job["id"], reply)["status"] == "done"
    latest = get(client, acc, "/tally/reconciliations/latest")
    assert latest["status"] == "done" and latest["summary"]["tally_ledgers"] == 2
    rows = {r["erp_name"]: r for r in latest["rows"]}
    party = rows["Bengaluru Tech Park"]
    assert party["status"] == "match" and D(party["erp"]) == total and D(party["tally"]) == total
    sales = rows["Sales — Projects & Services"]
    assert sales["status"] == "different" and D(sales["tally"]) == D("-1.00")
    assert rows["Output IGST"]["status"] == "missing_in_tally"
    # Tally answering with an error marks the run failed
    post(client, acc, "/tally/reconciliations")
    (job,) = lease(client, key)
    assert result(client, key, job["id"], err_reply("Could not set &apos;SVCurrentCompany&apos; to &apos;X&apos;"))["status"] == "failed"
    assert get(client, acc, "/tally/reconciliations/latest")["status"] == "failed"


def test_a_tally_problem_never_blocks_the_erp_document(client, as_user, monkeypatch):
    from app.tally import service

    acc = as_user("accounts1")
    setup_sync(client, acc)

    def boom(*a, **k):
        raise RuntimeError("tally bug")

    monkeypatch.setattr(service, "enqueue_document", boom)
    inv = service_invoice(client, as_user)
    assert inv["status"] == "issued"
    assert jobs(client, acc) == []


def test_skip_takes_an_entry_off_the_queue(client, as_user):
    acc = as_user("accounts1")
    setup_sync(client, acc)
    key = make_key(client, acc)
    inv = service_invoice(client, as_user)
    master = [j for j in jobs(client, acc) if j["action"] == "master"][0]
    post(client, acc, f"/tally/jobs/{master['id']}/skip", {"reason": "Ledger already exists in Tally"})
    leased = lease(client, key)
    assert [j["label"] for j in leased] == [f"Sales {inv['invoice_number']}"]
