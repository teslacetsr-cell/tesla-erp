"""Employee-wise tasks for administrators, directors and managers (Projects → Tasks → By employee)."""
import io
from datetime import timedelta

from openpyxl import load_workbook
from sqlalchemy import select

from app.crm.service import today as ist_today

API = "/api/v1"


def uid(client, h) -> str:
    return client.get(f"{API}/auth/me", headers=h).json()["data"]["id"]


def by_emp(client, h, **params) -> dict:
    r = client.get(f"{API}/tasks/by-employee", headers=h, params=params)
    assert r.status_code == 200, r.text
    return r.json()["data"]


def row_for(data, user_id):
    return next(r for r in data["rows"] if r["user_id"] == user_id)


def demo_project(client, h) -> dict:
    return client.get(f"{API}/projects", headers=h).json()["data"][0]


def test_only_all_scope_users_see_everyones_tasks(client, as_user, admin_headers):
    for h in (admin_headers, as_user("director"), as_user("manager")):
        assert client.get(f"{API}/tasks/by-employee", headers=h).status_code == 200
    for name in ("pm1", "engineer1", "sales1", "employee1"):
        h = as_user(name)
        r = client.get(f"{API}/tasks/by-employee", headers=h)
        assert r.status_code == 403, name
        assert client.get(f"{API}/tasks/by-employee/export", headers=h).status_code == 403


def test_counts_per_employee(client, as_user, admin_headers):
    eng = uid(client, as_user("engineer1"))
    emp1 = uid(client, as_user("employee1"))
    data = by_emp(client, as_user("director"))
    t0 = ist_today()
    week_end = t0 + timedelta(days=6 - t0.weekday())
    # demo: engineer1 has done (-6d), in progress (+5d), to do (-1d → overdue), to do (+30d)
    r = row_for(data, eng)
    assert r["name"] == "Arjun Das" and r["employee_code"] == "TCE0006" and r["department"] == "Projects"
    assert (r["open"], r["overdue"], r["blocked"], r["total"]) == (3, 1, 0, 4)
    assert r["done_this_month"] == 1  # completed today
    assert r["due_this_week"] == (1 if t0 + timedelta(days=5) <= week_end else 0)
    assert row_for(data, emp1)["open"] == 1
    # every active employee is listed, even with no tasks; the most overdue come first
    sales1 = uid(client, as_user("sales1"))
    assert row_for(data, sales1)["total"] == 0
    assert data["rows"][0]["user_id"] == eng
    assert data["totals"]["overdue"] == 1 and data["totals"]["open"] == 4
    # top-N for the dashboard card
    assert len(by_emp(client, admin_headers, limit=5)["rows"]) == 5


def test_filters_and_unassigned_row(client, as_user):
    m = as_user("manager")
    eng = uid(client, as_user("engineer1"))
    prj = demo_project(client, m)
    r = client.post(f"{API}/projects/{prj['id']}/tasks", headers=m,
                    json={"title": "Order test kit", "due_date": (ist_today() - timedelta(days=3)).isoformat()})
    assert r.status_code == 201, r.text
    data = by_emp(client, m)
    none = next(x for x in data["rows"] if x["user_id"] is None)
    assert none["name"] == "Not assigned to anyone" and none["overdue"] == 1
    # overdue only → only people with overdue tasks
    od = by_emp(client, m, overdue="true")
    assert {x["user_id"] for x in od["rows"]} == {eng, None}
    assert all(x["matching"] == 1 for x in od["rows"])
    # one employee
    one = by_emp(client, m, assigned_to=eng)
    assert [x["user_id"] for x in one["rows"]] == [eng]
    assert [x["user_id"] for x in by_emp(client, m, unassigned="true")["rows"]] == [None]
    # status
    ip = by_emp(client, m, status="in_progress")
    assert [(x["user_id"], x["matching"]) for x in ip["rows"]] == [(eng, 1)]
    # date range on the due date
    t0 = ist_today()
    rng = by_emp(client, m, due_from=(t0 + timedelta(days=10)).isoformat(), due_to=(t0 + timedelta(days=40)).isoformat())
    got = {x["user_id"]: x["total"] for x in rng["rows"]}
    assert got[eng] == 1 and got[uid(client, as_user("employee1"))] == 1 and None not in got
    # the project filter
    assert by_emp(client, m, project_id=prj["id"])["totals"]["total"] == 6
    # the expanded row lists that person's tasks (with project and click-through ids)
    lst = client.get(f"{API}/tasks", headers=m, params={"assigned_to": eng, "page_size": 100}).json()["data"]
    assert len(lst) == 4 and all(t["project_id"] == prj["id"] and t["project_number"] for t in lst)
    lst = client.get(f"{API}/tasks", headers=m, params={"unassigned": "true"}).json()["data"]
    assert [t["title"] for t in lst] == ["Order test kit"]
    lst = client.get(f"{API}/tasks", headers=m, params={"assigned_to": eng, "overdue": "true"}).json()["data"]
    assert len(lst) == 1


def test_employee_name_comes_from_employee_record(client, as_user):
    from app.core.db import SessionLocal
    from app.hr.models import Employee
    from app.users.models import User

    with SessionLocal() as s:
        u = s.scalar(select(User).where(User.username == "engineer1"))
        e = s.scalar(select(Employee).where(Employee.user_id == u.id))
        e.full_name = "Arjun Das K."
        s.commit()
        eng = str(u.id)
    assert row_for(by_emp(client, as_user("director")), eng)["name"] == "Arjun Das K."


def test_ordinary_users_still_see_only_their_tasks(client, as_user):
    m = as_user("manager")
    eng = uid(client, as_user("engineer1"))
    cust = client.get(f"{API}/customers", headers=m, params={"q": "ABC Hospital"}).json()["data"][0]
    other = client.post(f"{API}/projects", headers=m, json={"customer_id": cust["id"], "name": "Office rewiring"}).json()["data"]
    r = client.post(f"{API}/projects/{other['id']}/tasks", headers=m, json={"title": "Manager-only task"})
    assert r.status_code == 201
    # the manager sees it; the PM (not on that project) does not — not even when filtering by assignee
    assert any(t["title"] == "Manager-only task" for t in
               client.get(f"{API}/tasks", headers=m, params={"unassigned": "true"}).json()["data"])
    pm = as_user("pm1")
    assert not any(t["title"] == "Manager-only task" for t in
                   client.get(f"{API}/tasks", headers=pm, params={"unassigned": "true"}).json()["data"])
    # the engineer can only ask for their own tasks
    e = as_user("engineer1")
    assert client.get(f"{API}/tasks", headers=e, params={"assigned_to": eng}).status_code == 200
    mine = client.get(f"{API}/tasks", headers=as_user("employee1"), params={"mine": "true"}).json()["data"]
    assert len(mine) == 1


def test_export_to_excel(client, as_user):
    h = as_user("director")
    r = client.get(f"{API}/tasks/by-employee/export", headers=h)
    assert r.status_code == 200 and r.headers["content-type"].startswith(
        "application/vnd.openxmlformats-officedocument.spreadsheetml")
    ws = load_workbook(io.BytesIO(r.content)).active
    rows = list(ws.iter_rows(values_only=True))
    assert rows[0][:5] == ("Employee", "Employee code", "Project no.", "Project", "Task")
    names = [x[0] for x in rows[1:]]
    assert names.count("Arjun Das") == 4 and len(rows) == 6
    overdue = [x for x in rows[1:] if x[10] == "Yes"]
    assert len(overdue) == 1 and overdue[0][8] == "To do"
    r = client.get(f"{API}/tasks/by-employee/export", headers=h, params={"overdue": "true"})
    assert len(list(load_workbook(io.BytesIO(r.content)).active.iter_rows())) == 2
