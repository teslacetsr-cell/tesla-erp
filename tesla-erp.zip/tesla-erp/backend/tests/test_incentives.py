"""Incentive & performance module through the API: the four reference bills A–D raised as real invoices and paid by
real receipts, approve & lock / unlock / paid out, payment follow-up, project settings and permissions."""
from datetime import date
from decimal import Decimal as D

from sqlalchemy import select

from tests.test_finance import err, get, post

API = "/api/v1"
YM = "2025-06"                          # a quiet past month: the demo data has no billing here
BILL_DAY, PAID_DAY = date(2025, 6, 3), date(2025, 6, 18)
EXPECTED = {"am": D("1100"), "bde": D("11500"), "je": D("3750"), "pe": D("4000"), "oa": D("630"), "dm": D("875")}
STAFF = {"am": "manager", "bde": "sales1", "je": "engineer1", "pe": "pm1", "acc": "accounts1", "oa": "employee1",
         "dm": "purchase1"}


def put(client, h, path, body, status=200):
    r = client.put(f"{API}{path}", headers=h, json=body)
    assert r.status_code == status, r.text
    return r.json()["data"]


def _setup_staff_and_projects():
    """One demo employee in each incentive role (and nobody else); four projects A–D for one customer."""
    from app.core.db import SessionLocal
    from app.customers.models import Customer
    from app.hr.service import employee_for_user
    from app.incentives.models import IncentiveRole, IncentiveRoleMember
    from app.projects.models import Project
    from app.users.models import User

    with SessionLocal() as s:
        admin = s.scalar(select(User).where(User.username == "admin"))
        by = {"created_by": admin.id, "updated_by": admin.id}
        s.query(IncentiveRoleMember).delete()
        roles = {r.code: r for r in s.scalars(select(IncentiveRole))}
        emp = {}
        for code, username in STAFF.items():
            e = employee_for_user(s, s.scalar(select(User.id).where(User.username == username)))
            emp[code] = str(e.id)
            s.add(IncentiveRoleMember(role_id=roles[code].id, employee_id=e.id, **by))
        cust = Customer(customer_code="CUSINC1", customer_name="Incentive Test Client", state_code="32", **by)
        gov = Customer(customer_code="CUSINC2", customer_name="PWD Electrical Division", state_code="32",
                       customer_type="government", **by)
        s.add_all([cust, gov])
        s.flush()
        prj = {}
        for key, name, value, c in (("A", "Solar rooftop 50 kW", "500000", cust), ("B", "Lightning protection", "200000", cust),
                                    ("C", "Consulting study", "100000", cust), ("D", "Govt electrical works", "1000000", gov)):
            p = Project(project_number=f"PRJ-INC-{key}", name=name, customer_id=c.id, contract_value=D(value),
                        status="active", **by)
            s.add(p)
            s.flush()
            prj[key] = str(p.id)
        s.commit()
        return emp, prj, {"cust": str(cust.id), "gov": str(gov.id)}


def _bill(client, h, project_id, amount, final=False, pay=True):
    inv = post(client, h, "/invoices", {"project_id": project_id, "invoice_date": BILL_DAY.isoformat(),
                                        "bill_type": "final" if final else "regular", "items": [
        {"description": "Works as per order", "hsn_sac": "995461", "quantity": "1", "unit": "JOB", "rate": amount,
         "tax_rate": "18"}]})
    inv = post(client, h, f"/invoices/{inv['id']}/issue")
    if pay:
        post(client, h, "/receipts", {"customer_id": inv["customer_id"], "receipt_date": PAID_DAY.isoformat(),
                                      "amount": inv["grand_total"], "mode": "neft",
                                      "allocations": [{"document_id": inv["id"], "amount": inv["grand_total"]}]})
    return inv


def _reference(client, as_user):
    emp, prj, _ = _setup_staff_and_projects()
    mgr, acc = as_user("director"), as_user("accounts1")
    put(client, mgr, f"/projects/{prj['A']}/incentive", {"category_code": "solar", "ei_kseb": True, "subsidy_done": True,
                                                        "subsidy_date": PAID_DAY.isoformat()})
    put(client, mgr, f"/projects/{prj['B']}/incentive", {"category_code": "lps"})
    put(client, mgr, f"/projects/{prj['C']}/incentive", {"category_code": "consulting"})
    s = put(client, mgr, f"/projects/{prj['D']}/incentive", {"category_code": "electrical", "is_govt": True,
                                                            "from_tender": True})
    assert s["saved"] and s["is_govt"] and s["from_tender"]
    _bill(client, acc, prj["A"], "500000", final=True)
    _bill(client, acc, prj["B"], "200000")
    _bill(client, acc, prj["C"], "100000")
    _bill(client, acc, prj["D"], "1000000")
    return emp, prj, mgr, acc


def _by_role(reg, emp):
    tot = {g["employee_id"]: D(g["total"]) for g in reg["employees"]}
    return {code: tot.get(eid, D(0)) for code, eid in emp.items()}


def test_reference_bills_lock_unlock_and_paid_out(client, as_user):
    emp, prj, mgr, acc = _reference(client, as_user)

    reg = get(client, mgr, "/incentives/register", ym=YM)
    got = _by_role(reg, emp)
    assert {k: got[k] for k in EXPECTED} == EXPECTED and got["acc"] == 0
    assert D(reg["billed"]) == D("1800000") and D(reg["welfare"]) == D("9000")

    # the accountant's share needs "all account statements proper"
    reg = put(client, mgr, f"/incentives/months/{YM}/accounts", {"accounts_proper": True})
    got = _by_role(reg, emp)
    assert got["acc"] == D("1800") and {k: got[k] for k in EXPECTED} == EXPECTED

    dash = get(client, mgr, "/incentives/dashboard", ym=YM)
    assert D(dash["billed"]) == D("1800000") and D(dash["collected"]) == D("1800000") and dash["billed_count"] == 4
    assert D(dash["incentives"]) == sum(EXPECTED.values()) + D("1800")

    # paid out only after locking; locking freezes the figures
    assert err(client, mgr, f"/incentives/months/{YM}/paid", {"employee_id": emp["bde"]})[1] == "NOT_LOCKED"
    reg = post(client, mgr, f"/incentives/months/{YM}/lock")
    assert reg["status"] == "locked"
    put(client, mgr, f"/projects/{prj['B']}/incentive", {"category_code": "consulting"})   # later change …
    reg = get(client, mgr, "/incentives/register", ym=YM)
    assert _by_role(reg, emp)["bde"] == D("11500")                                       # … not in the snapshot
    assert err(client, mgr, f"/incentives/months/{YM}/accounts", {"accounts_proper": False}, "put")[1] == "MONTH_LOCKED"

    reg = post(client, mgr, f"/incentives/months/{YM}/paid", {"employee_id": emp["bde"], "paid_on": "2025-07-05"})
    row = next(g for g in reg["employees"] if g["employee_id"] == emp["bde"])
    assert row["paid"] == {"paid_on": "2025-07-05", "amount": "11500.00"}

    # only an administrator unlocks, and not while anything is marked paid out
    assert err(client, mgr, f"/incentives/months/{YM}/unlock")[0] == 403
    admin = _admin(client)
    assert err(client, admin, f"/incentives/months/{YM}/unlock")[1] == "PAID_OUT"
    r = client.delete(f"{API}/incentives/months/{YM}/paid/{emp['bde']}", headers=mgr)
    assert r.status_code == 200, r.text
    reg = post(client, admin, f"/incentives/months/{YM}/unlock")
    assert reg["status"] == "draft" and _by_role(reg, emp)["bde"] != D("11500")         # live again

    # exports and the printable statement
    r = client.get(f"{API}/incentives/register/export", headers=mgr, params={"ym": YM, "fmt": "csv"})
    assert r.status_code == 200 and "Employee" in r.content.decode("utf-8-sig").splitlines()[0]
    r = client.get(f"{API}/incentives/register/export", headers=mgr, params={"ym": YM})
    assert r.status_code == 200 and r.content[:2] == b"PK"
    r = client.get(f"{API}/incentives/statement/{emp['je']}.pdf", headers=mgr, params={"ym": YM})
    assert r.status_code == 200 and r.content[:4] == b"%PDF"

    rep = get(client, mgr, "/incentives/reports", fy=2025)
    assert rep["months"][2] == YM and D(rep["billing"][2]["total"]) == D("1800000") and D(rep["welfare"][2]) == D("9000")


def _admin(client):
    from app.core.db import SessionLocal
    from app.users.models import User
    from tests.conftest import ADMIN_PASSWORD, login

    with SessionLocal() as s:
        s.query(User).filter_by(username="admin").one().must_change_password = False
        s.commit()
    return login(client, "admin", ADMIN_PASSWORD)


def test_employee_sees_only_own_statement_and_cannot_manage(client, as_user):
    emp, prj, mgr, acc = _reference(client, as_user)
    eng = as_user("engineer1")
    me = get(client, eng, "/incentives/me", ym=YM)
    assert me["employee"]["id"] == emp["je"] and D(me["total"]) == EXPECTED["je"]
    assert {ln["employee_id"] for ln in me["lines"]} == {emp["je"]}
    assert client.get(f"{API}/incentives/statement/{emp['je']}.pdf", headers=eng, params={"ym": YM}).status_code == 200
    assert client.get(f"{API}/incentives/statement/{emp['bde']}.pdf", headers=eng, params={"ym": YM}).status_code == 403
    for path in ("/incentives/register", "/incentives/dashboard", "/incentives/setup", "/incentives/followup"):
        assert client.get(f"{API}{path}", headers=eng).status_code == 403, path
    assert err(client, eng, f"/incentives/months/{YM}/lock")[0] == 403
    # accounts can see and export, but not approve, lock or change rates
    assert client.get(f"{API}/incentives/register", headers=acc, params={"ym": YM}).status_code == 200
    assert err(client, acc, f"/incentives/months/{YM}/lock")[0] == 403
    assert err(client, acc, "/incentives/restore-standard")[0] == 403
    assert client.put(f"{API}/projects/{prj['A']}/incentive", headers=acc, json={}).status_code == 403


def test_followup_manual_confirmation_subsidy_and_team(client, as_user):
    emp, prj, _ = _setup_staff_and_projects()
    mgr, acc = as_user("director"), as_user("accounts1")
    put(client, mgr, f"/projects/{prj['B']}/incentive", {"category_code": "lps"})
    put(client, mgr, f"/projects/{prj['A']}/incentive", {"category_code": "solar", "ei_kseb": True})
    inv = _bill(client, acc, prj["B"], "200000", pay=False)

    fu = get(client, acc, "/incentives/followup")
    row = next(b for b in fu["bills"] if b["invoice_id"] == inv["id"])
    assert row["state"] == "open" and row["age_days"] > 60 and row["amount"] == "200000.00"
    assert any(x["project_id"] == prj["A"] for x in fu["subsidy"])
    assert get(client, mgr, "/incentives/register", ym=YM)["total"] == "0.00"

    # part paid → still not counted; confirmed in full → counts in the month of the confirmed date
    post(client, acc, f"/incentives/followup/{inv['id']}/part", {"amount": "100000", "on": "2025-06-10"})
    assert get(client, mgr, "/incentives/register", ym=YM)["total"] == "0.00"
    post(client, acc, f"/incentives/followup/{inv['id']}/paid", {"paid_date": PAID_DAY.isoformat()})
    reg = get(client, mgr, "/incentives/register", ym=YM)
    assert _by_role(reg, emp)["bde"] == D("4000") and _by_role(reg, emp)["pe"] == D("500")
    fu = get(client, acc, "/incentives/followup")
    assert not any(b["invoice_id"] == inv["id"] for b in fu["bills"])
    assert fu["manually_confirmed"][0]["invoice_id"] == inv["id"]

    # "Nobody" for business development on B
    bde_role = next(r for r in get(client, mgr, f"/projects/{prj['B']}/incentive")["roles"] if "Business" in r["name"])
    put(client, mgr, f"/projects/{prj['B']}/incentive", {"category_code": "lps", "team": {bde_role["id"]: "none"}})
    assert _by_role(get(client, mgr, "/incentives/register", ym=YM), emp)["bde"] == 0

    # subsidy "Yes, done" from the follow-up screen
    post(client, acc, f"/incentives/projects/{prj['A']}/subsidy", {"on": "2025-06-20"})
    assert not any(x["project_id"] == prj["A"] for x in get(client, acc, "/incentives/followup")["subsidy"])

    # reopening the manual confirmation takes the bill out again
    post(client, acc, f"/incentives/followup/{inv['id']}/reopen")
    assert _by_role(get(client, mgr, "/incentives/register", ym=YM), emp)["pe"] == 0


def test_setup_rules_welfare_restore_and_performance(client, as_user):
    emp, prj, mgr, acc = _reference(client, as_user)
    st = get(client, mgr, "/incentives/setup")
    assert st["can_edit"] and len(st["categories"]) >= 6 and len(st["roles"]) == 7
    assert any(x["value"] == "1000" and x["basis"] == "fixed" for r in st["roles"] for x in r["rules"])   # no "1E+3"
    bde = next(r for r in st["roles"] if r["code"] == "bde")
    rule = next(x for x in bde["rules"] if x["categories"] == ["lps"])
    put(client, mgr, f"/incentives/rules/{rule['id']}", rule | {"value": "3"})          # 2% → 3% on B
    assert _by_role(get(client, mgr, "/incentives/register", ym=YM), emp)["bde"] == D("13500")
    st = post(client, mgr, "/incentives/categories", {"name": "EV charging"})
    assert any(c["code"] == "ev_charging" for c in st["categories"])
    put(client, mgr, "/incentives/welfare", {"welfare_pct": "1"})
    assert D(get(client, mgr, "/incentives/register", ym=YM)["welfare"]) == D("18000")
    post(client, mgr, "/incentives/restore-standard")
    reg = get(client, mgr, "/incentives/register", ym=YM)
    assert _by_role(reg, emp)["bde"] == D("11500") and D(reg["welfare"]) == D("9000")

    perf = put(client, mgr, f"/incentives/performance/{YM}/{emp['je']}",
               {"quality": 5, "timeliness": 4, "follow_up": 5, "teamwork": 4, "learning": 5, "remarks": "Good month"})
    je = next(e for e in perf["employees"] if e["employee_id"] == emp["je"])
    assert je["average"] == "4.6" and je["band"] == "Outstanding" and D(je["incentive"]) == EXPECTED["je"]
    assert client.put(f"{API}/incentives/performance/{YM}/{emp['je']}", headers=acc, json={"quality": 1}).status_code == 403
    assert client.put(f"{API}/incentives/performance/{YM}/{emp['je']}", headers=mgr, json={"quality": 6}).status_code == 422


def test_new_joiner_earns_only_after_qualifying_period(client, as_user):
    emp, prj, mgr, acc = _reference(client, as_user)
    from app.core.db import SessionLocal
    from app.hr.models import Employee

    with SessionLocal() as s:                       # the junior engineer joined on 1 May 2025 → eligible 1 Aug 2025
        s.get(Employee, emp["je"]).date_of_joining = date(2025, 5, 1)
        s.commit()
    got = _by_role(get(client, mgr, "/incentives/register", ym=YM), emp)
    assert got["je"] == 0 and got["bde"] == EXPECTED["bde"]
    st = get(client, mgr, "/incentives/setup")
    assert st["eligible_after_months"] == 3
    je = next(m for r in st["roles"] for m in r["members"] if m["employee_id"] == emp["je"])
    assert je["eligible_from"] == "2025-08-01"
    assert get(client, as_user("engineer1"), "/incentives/me", ym=YM)["employee"]["eligible_from"] == "2025-08-01"

    # the period is a setting: with 1 month the engineer is eligible from 1 Jun and earns the June bills
    put(client, mgr, "/incentives/eligibility", {"months": 1})
    assert _by_role(get(client, mgr, "/incentives/register", ym=YM), emp)["je"] == EXPECTED["je"]
    assert client.put(f"{API}/incentives/eligibility", headers=acc, json={"months": 0}).status_code == 403
    post(client, mgr, "/incentives/restore-standard")
    assert get(client, mgr, "/incentives/setup")["eligible_after_months"] == 3
