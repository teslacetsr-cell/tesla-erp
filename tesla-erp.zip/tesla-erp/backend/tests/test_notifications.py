"""Phase 10: the notification engine — event catalogue, per-person preferences, email by the background worker with
retries (fake SMTP server), the WhatsApp/SMS adapter interface, the admin test email, and the daily alerts
(idempotent per day, switchable in Settings, bundled into the daily digest)."""
import email
import re
from datetime import timedelta
from pathlib import Path

import pytest
from sqlalchemy import text

from tests.test_finance import err, get, post

API = "/api/v1"


class FakeSMTP:
    """Stands in for smtplib.SMTP: records every message; `fail` makes the next sends raise."""
    sent: list = []
    fail = 0
    logins: list = []

    def __init__(self, host, port, timeout=None):
        self.host, self.port = host, port

    def ehlo(self):
        return 250, b"ok"

    def starttls(self, context=None):
        return 220, b"ready"

    def login(self, user, password):
        FakeSMTP.logins.append(user)

    def send_message(self, msg):
        if FakeSMTP.fail:
            FakeSMTP.fail -= 1
            raise ConnectionRefusedError("mail server down")
        FakeSMTP.sent.append(email.message_from_bytes(msg.as_bytes()))

    def quit(self):
        pass


@pytest.fixture
def mail(monkeypatch):
    from app.core.config import get_settings
    from app.platform.notifications import channels

    s = get_settings()
    for k, v in {"smtp_host": "smtp.test", "smtp_port": 587, "smtp_user": "erp@teslace.test",
                 "smtp_password": "secret-pw", "smtp_from": "TCE ERP <erp@teslace.test>", "smtp_tls": "starttls",
                 "app_base_url": "https://erp.teslace.test"}.items():
        monkeypatch.setattr(s, k, v)
    FakeSMTP.sent, FakeSMTP.fail, FakeSMTP.logins = [], 0, []
    monkeypatch.setattr(channels.smtplib, "SMTP", FakeSMTP)
    return FakeSMTP.sent


def run_jobs() -> int:
    from app.core.db import SessionLocal
    from app.platform.jobs.service import run_pending

    return run_pending(SessionLocal, limit=200)


def uid(owner_engine, username) -> str:
    with owner_engine.connect() as c:
        return c.execute(text("select id::text from users where username = :u"), {"u": username}).scalar()


def body_of(msg) -> tuple[str, str]:
    plain = html = ""
    for part in msg.walk():
        if part.get_content_type() == "text/plain":
            plain = part.get_payload(decode=True).decode()
        elif part.get_content_type() == "text/html":
            html = part.get_payload(decode=True).decode()
    return plain, html


def demo_project(client, h) -> dict:
    return [p for p in get(client, h, "/projects", page_size=50) if "ABC" in p["name"]][0]


# ------------------------------------------------------------------ catalogue
def test_every_notify_call_uses_a_catalogued_event():
    from app.platform.notifications import alerts, events

    root = Path(__file__).resolve().parents[1] / "app"
    found = set()
    for f in root.rglob("*.py"):
        if "notifications" in f.parts:
            continue                        # the engine itself (docstrings show the call form)
        src = f.read_text(encoding="utf-8")
        for call in re.finditer(r"notify\((.*?)\)\n", src, re.S):
            m = re.search(r'event=f?"([a-z_.{}]+)"', call.group(1))
            if m:
                found.add(m.group(1))
    assert len(found) >= 18
    expand = {"task.{status}": ["task.blocked", "task.done"],
              "material_request.{action}": ["material_request.reject", "material_request.close"]}
    keys = [k for e in found for k in expand.get(e, [e])]
    missing = [k for k in keys if "{" not in k and k not in events.EVENTS]
    assert missing == [], missing
    assert all("{" not in e or e in expand for e in found)
    assert {a.event for a in alerts.ALERTS} <= set(events.EVENTS)


# ------------------------------------------------------------------ preferences
def test_preferences_default_and_are_honoured(client, as_user, owner_engine, mail):
    pm = as_user("pm1")
    eng = as_user("engineer1")
    prefs = get(client, eng, "/notifications/preferences")
    by = {e["key"]: e for e in prefs["events"]}
    assert prefs["channels"] == {"email": True, "whatsapp": False, "sms": False}
    assert by["task.assigned"]["in_app"] is True and by["task.assigned"]["email"] is True
    assert by["project.status"]["email"] is False and prefs["digest"] is False
    assert {e["group"] for e in prefs["events"]} <= set(prefs["groups"])
    eng_id = uid(owner_engine, "engineer1")
    prj = demo_project(client, pm)

    def new_task(title):
        return post(client, pm, f"/projects/{prj['id']}/tasks", {"title": title, "assigned_to": eng_id})

    def bell(title):
        return [n for n in get(client, eng, "/notifications", limit=50) if title in n["title"]]

    # defaults: in the bell AND emailed (by the worker, not during the request)
    new_task("Fix earth pit 4")
    assert len(bell("Fix earth pit 4")) == 1 and mail == []
    assert run_jobs() >= 1
    msg = [m for m in mail if "Fix earth pit 4" in m["Subject"]][0]
    assert "engineer" in msg["To"].lower() or "@" in msg["To"]
    plain, html = body_of(msg)
    assert "https://erp.teslace.test/projects/view/?id=" in plain and "Open in the ERP" in html
    assert "/account/notifications" in plain and "secret-pw" not in plain + html
    # switched off in the bell and by email → nothing at all
    r = client.put(f"{API}/notifications/preferences", headers=eng,
                   json={"items": [{"event": "task.assigned", "in_app": False, "email": False}]})
    assert r.status_code == 200
    mail.clear()
    new_task("Fix earth pit 5")
    run_jobs()
    assert bell("Fix earth pit 5") == [] and mail == []
    # email only
    r = client.put(f"{API}/notifications/preferences", headers=eng,
                   json={"items": [{"event": "task.assigned", "in_app": False, "email": True}]})
    assert r.status_code == 200
    saved = {e["key"]: e for e in r.json()["data"]["events"]}["task.assigned"]
    assert saved["in_app"] is False and saved["email"] is True
    new_task("Fix earth pit 6")
    run_jobs()
    assert bell("Fix earth pit 6") == [] and any("Fix earth pit 6" in m["Subject"] for m in mail)
    # someone else's preferences are untouched
    assert {e["key"]: e for e in get(client, pm, "/notifications/preferences")["events"]}["task.assigned"]["in_app"]
    # unknown event refused
    r = client.put(f"{API}/notifications/preferences", headers=eng, json={"items": [{"event": "nope.x"}]})
    assert r.status_code == 400 and r.json()["error"]["code"] == "UNKNOWN_EVENT"


def test_no_email_when_smtp_not_configured(client, as_user, owner_engine):
    pm = as_user("pm1")
    prj = demo_project(client, pm)
    post(client, pm, f"/projects/{prj['id']}/tasks", {"title": "No mail task", "assigned_to": uid(owner_engine, "engineer1")})
    with owner_engine.connect() as c:
        assert c.execute(text("select count(*) from jobs where kind = 'notification.deliver'")).scalar() == 0
    assert get(client, as_user("engineer1"), "/notifications/preferences")["channels"]["email"] is False


def test_email_retries_then_fails_and_is_reported(client, as_user, owner_engine, admin_headers, mail):
    pm = as_user("pm1")
    prj = demo_project(client, pm)
    post(client, pm, f"/projects/{prj['id']}/tasks", {"title": "Retry task", "assigned_to": uid(owner_engine, "engineer1")})
    FakeSMTP.fail = 1
    run_jobs()
    with owner_engine.begin() as c:
        st, attempts, err_txt = c.execute(text("select status, attempts, last_error from jobs "
                                               "where kind = 'notification.deliver'")).one()
        assert st == "pending" and attempts == 1 and "mail server down" in err_txt
        assert "secret-pw" not in err_txt
        c.execute(text("update jobs set run_at = now() where kind = 'notification.deliver'"))
    run_jobs()                                   # second attempt succeeds
    assert [m["Subject"] for m in mail] == ["New task: Retry task"]
    assert set(FakeSMTP.logins) == {"erp@teslace.test"}
    # permanent failure after max attempts shows in the email status for administrators
    post(client, pm, f"/projects/{prj['id']}/tasks", {"title": "Doomed task", "assigned_to": uid(owner_engine, "engineer1")})
    FakeSMTP.fail = 99
    for _ in range(6):
        run_jobs()
        with owner_engine.begin() as c:
            c.execute(text("update jobs set run_at = now() where status = 'pending'"))
    st = get(client, admin_headers, "/notifications/channels")
    assert st["email"]["configured"] is True and st["last_7_days"]["failed"] == 1
    assert st["last_7_days"]["sent"] == 1 and "mail server down" in st["last_error"]
    assert "secret" not in str(st)


def test_test_email_button(client, as_user, admin_headers, mail, monkeypatch):
    r = client.post(f"{API}/notifications/test-email", headers=admin_headers, json={"to": "it@teslace.in"})
    assert r.status_code == 200, r.text
    assert mail[-1]["To"] == "it@teslace.in" and mail[-1]["Subject"] == "Test email from the ERP"
    assert "TCE ERP" in mail[-1]["From"]
    assert err(client, as_user("director"), "/notifications/test-email", {})[0] == 403   # settings.update only
    FakeSMTP.fail = 1
    assert err(client, admin_headers, "/notifications/test-email", {}) == (400, "EMAIL_FAILED")
    from app.core.config import get_settings
    monkeypatch.setattr(get_settings(), "smtp_host", None)
    assert err(client, admin_headers, "/notifications/test-email", {}) == (400, "EMAIL_NOT_SET_UP")


def test_whatsapp_sms_adapter_interface(client, as_user, owner_engine, monkeypatch, caplog):
    from app.core.config import get_settings
    from app.platform.notifications import channels

    assert channels.get_channel("whatsapp") is None and channels.get_channel("sms") is None
    monkeypatch.setattr(get_settings(), "whatsapp_provider", "log")
    eng = as_user("engineer1")
    assert get(client, eng, "/notifications/preferences")["channels"]["whatsapp"] is True
    client.put(f"{API}/notifications/preferences", headers=eng,
               json={"items": [{"event": "task.assigned", "in_app": True, "whatsapp": True}]})
    with owner_engine.begin() as c:
        c.execute(text("update users set phone = '9847012345' where username = 'engineer1'"))
    pm = as_user("pm1")
    post(client, pm, f"/projects/{demo_project(client, pm)['id']}/tasks",
         {"title": "WhatsApp task", "assigned_to": uid(owner_engine, "engineer1")})
    caplog.set_level("INFO", logger="notifications")
    assert run_jobs() == 1
    assert any("whatsapp (log only" in r.message and "***345" in r.message for r in caplog.records)
    assert not any("WhatsApp task" in r.message for r in caplog.records)    # no message text in logs


# ------------------------------------------------------------------ daily alerts
def _run(day, only=None):
    from app.auth.deps import default_company_id
    from app.core.db import SessionLocal
    from app.platform.notifications import alerts

    with SessionLocal() as db:
        res = alerts.run_daily(db, default_company_id(db), day, only=only)
        db.commit()
    return {r["alert"]: r for r in res}


def _alerts_for(client, h) -> dict:
    return {n["event"]: n for n in get(client, h, "/notifications", limit=100) if n["event"].startswith("alert.")}


def test_daily_alerts_reach_the_right_people_once_a_day(client, as_user, owner_engine, admin_headers):
    from app.crm.service import today

    day = today() + timedelta(days=60)          # the demo tasks, PO delivery and project target are all past by then
    with owner_engine.begin() as c:
        c.execute(text("update invoices set due_date = current_date - 20 where status = 'issued'"))
        c.execute(text("update supplier_invoices set due_date = current_date + 1 where status = 'posted'"))
    res = _run(day)
    for k in ("invoice_overdue", "bill_due", "project_late", "task_overdue", "po_late", "low_stock"):
        assert res[k]["ran"] and res[k]["items"] > 0 and res[k]["recipients"] > 0, (k, res[k])
    acc = _alerts_for(client, as_user("accounts1"))
    assert "alert.invoice_overdue" in acc and "alert.bill_due" in acc and "₹" in acc["alert.invoice_overdue"]["title"]
    assert acc["alert.invoice_overdue"]["link"] == "/finance/receivables"
    assert "overdue" in acc["alert.invoice_overdue"]["title"]
    # the sales person of the order hears about their customer's overdue invoice
    assert "alert.invoice_overdue" in _alerts_for(client, as_user("sales1"))
    pm = _alerts_for(client, as_user("pm1"))
    assert {"alert.project_late", "alert.task_overdue"} <= set(pm)
    assert "alert.low_stock" in _alerts_for(client, as_user("store1"))
    assert "alert.po_late" in _alerts_for(client, as_user("purchase1"))
    # people with nothing to act on hear nothing
    assert _alerts_for(client, as_user("hr1")) == {}
    assert set(_alerts_for(client, as_user("employee1"))) <= {"alert.task_overdue"}   # only their own task
    assert "alert.invoice_overdue" not in _alerts_for(client, as_user("store1"))
    # idempotent: the same day again sends nothing more
    with owner_engine.connect() as c:
        before = c.execute(text("select count(*) from notifications where event like 'alert.%'")).scalar()
    again = _run(day)
    assert not any(r["ran"] for r in again.values()) and again["invoice_overdue"]["already_ran"]
    with owner_engine.connect() as c:
        assert c.execute(text("select count(*) from notifications where event like 'alert.%'")).scalar() == before
        assert c.execute(text("select count(*) from alert_runs where run_date = :d"), {"d": day}).scalar() >= 6
    # the next day runs again
    assert _run(day + timedelta(days=1))["task_overdue"]["ran"]
    # history for administrators
    hist = get(client, admin_headers, "/notifications/alerts")["history"]
    assert any(h["alert"] == "invoice_overdue" and h["items"] > 0 for h in hist)


def test_alert_switched_off_and_thresholds(client, as_user, admin_headers, owner_engine):
    from app.crm.service import today

    day = today() + timedelta(days=60)
    r = client.put(f"{API}/settings/alerts.task_overdue", headers=admin_headers, json={"value": False})
    assert r.status_code == 200
    r = client.put(f"{API}/settings/alerts.run_hour", headers=admin_headers, json={"value": 24})
    assert r.status_code == 400
    res = _run(day, only=["task_overdue", "project_late"])
    assert res["task_overdue"]["enabled"] is False and res["task_overdue"]["ran"] is False
    assert res["project_late"]["ran"]
    assert "alert.task_overdue" not in _alerts_for(client, as_user("pm1"))
    # a threshold: invoices overdue by more than 30 days only
    with owner_engine.begin() as c:
        c.execute(text("update invoices set due_date = current_date - 10 where status = 'issued'"))
    client.put(f"{API}/settings/alerts.invoice_overdue_days", headers=admin_headers, json={"value": 30})
    assert _run(today(), only=["invoice_overdue"])["invoice_overdue"]["items"] == 0
    assert _run(today() + timedelta(days=25), only=["invoice_overdue"])["invoice_overdue"]["items"] > 0


def test_run_now_button_and_permissions(client, as_user, admin_headers):
    r = client.post(f"{API}/notifications/alerts/run", headers=admin_headers, json={})
    assert r.status_code == 200
    first = {x["alert"]: x for x in r.json()["data"]}
    assert set(first) >= {"invoice_overdue", "low_stock", "rfq_due"}
    again = {x["alert"]: x for x in post(client, admin_headers, "/notifications/alerts/run", {})}
    assert not any(x["ran"] for x in again.values())
    assert err(client, as_user("director"), "/notifications/alerts/run", {})[0] == 403
    assert client.get(f"{API}/notifications/alerts", headers=as_user("sales1")).status_code == 403
    assert err(client, admin_headers, "/notifications/alerts/run", {"only": ["bogus"]})[1] == "UNKNOWN_ALERT"


def test_daily_digest_bundles_alerts_into_one_email(client, as_user, owner_engine, mail):
    from app.crm.service import today

    acc = as_user("accounts1")
    r = client.put(f"{API}/notifications/preferences", headers=acc,
                   json={"digest": True, "items": [{"event": "alert.invoice_overdue", "in_app": True, "email": True},
                                                   {"event": "alert.bill_due", "in_app": True, "email": True}]})
    assert r.json()["data"]["digest"] is True
    store = as_user("store1")      # no digest, low-stock alert by email straight away
    client.put(f"{API}/notifications/preferences", headers=store,
               json={"items": [{"event": "alert.low_stock", "in_app": True, "email": True}]})
    with owner_engine.begin() as c:
        c.execute(text("update invoices set due_date = current_date - 20 where status = 'issued'"))
        c.execute(text("update supplier_invoices set due_date = current_date where status = 'posted'"))
    res = _run(today() + timedelta(days=1))
    assert res["digest"]["ran"] and res["digest"]["recipients"] == 1
    run_jobs()
    acc_mail = [m for m in mail if "accounts" in m["To"].lower() or "Daily summary" in m["Subject"]]
    assert len(acc_mail) == 1 and acc_mail[0]["Subject"].startswith("Daily summary")
    plain, _ = body_of(acc_mail[0])
    assert "customer invoice" in plain and "supplier bill" in plain and "https://erp.teslace.test/finance/" in plain
    assert any("items low or out of stock" in m["Subject"] or "item low or out of stock" in m["Subject"]
               for m in mail)
    # the digest is sent once a day
    assert _run(today() + timedelta(days=1))["digest"]["ran"] is False


def test_worker_runs_alerts_after_the_set_hour(client, admin_headers, owner_engine, monkeypatch):
    from app.core.db import SessionLocal
    from app.platform.notifications import alerts

    client.put(f"{API}/settings/alerts.run_hour", headers=admin_headers, json={"value": 23})
    alerts._checked.clear()
    from app.crm.service import now
    res = alerts.maybe_run(SessionLocal)
    if now().hour < 23:
        assert res is None
    client.put(f"{API}/settings/alerts.run_hour", headers=admin_headers, json={"value": 0})
    alerts._checked.clear()
    res = alerts.maybe_run(SessionLocal)
    assert res is not None and any(r["ran"] for r in res)
    alerts._checked.clear()
    assert alerts.maybe_run(SessionLocal) is None          # everything done today
    with owner_engine.connect() as c:
        assert c.execute(text("select count(distinct alert) from alert_runs")).scalar() >= 8


def test_leave_waiting_too_long_reaches_the_line_manager(client, as_user, owner_engine):
    from datetime import date

    from app.crm.service import today
    from tests.test_hr import leave_type, next_workday

    eng = as_user("engineer1")                      # reports to pm1
    d1 = next_workday(date.today(), 5)
    lr = post(client, eng, "/leave-requests", {"leave_type_id": leave_type(client, eng, "CL")["id"],
                                               "from_date": str(d1), "to_date": str(d1), "reason": "Family function"})
    assert _run(today(), only=["approval_waiting"])["approval_waiting"]["items"] == 0      # only just asked
    with owner_engine.begin() as c:
        c.execute(text("update approval_requests set requested_at = now() - interval '3 days' where entity_id = :i"),
                  {"i": lr["id"]})
    res = _run(today() + timedelta(days=1), only=["approval_waiting"])
    assert res["approval_waiting"]["items"] == 1
    note = _alerts_for(client, as_user("pm1"))["alert.approval_waiting"]
    assert note["title"] == "1 approval waiting for you" and note["link"] == "/approvals"
    assert "alert.approval_waiting" not in _alerts_for(client, as_user("manager"))
    assert "alert.approval_waiting" not in _alerts_for(client, eng)
