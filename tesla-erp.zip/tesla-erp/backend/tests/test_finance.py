"""Phase 7: invoices, credit notes, receipts, receivables, supplier bills and payments, expenses, the journal
(Spec §22–§25, §30, §45: Invoice; Payment; Invoice → Payment → Receivable)."""
from decimal import Decimal as D

import pytest
from sqlalchemy import create_engine, text

from tests.test_projects import accepted_quote, make_so
from tests.test_purchase import approve_all, item, po_line, supplier, wh

API = "/api/v1"


def get(client, h, path, **params):
    r = client.get(f"{API}{path}", headers=h, params=params)
    assert r.status_code == 200, r.text
    return r.json()["data"]


def post(client, h, path, body=None, status=(200, 201)):
    r = client.post(f"{API}{path}", headers=h, json=body or {})
    assert r.status_code in status, r.text
    return r.json()["data"]


def err(client, h, path, body=None, method="post"):
    r = getattr(client, method)(f"{API}{path}", headers=h, **({"json": body or {}} if method != "get" else {}))
    assert r.status_code >= 400, r.text
    return r.status_code, r.json()["error"]["code"]


INV_LINE_KEYS = ("section", "item_id", "description", "hsn_sac", "unit", "rate", "discount_pct", "tax_rate")


def so_lines(client, h, so_id, qty: dict | None = None) -> list[dict]:
    """Invoice lines for an order: every line, or {line_no: qty}."""
    rows = get(client, h, f"/sales-orders/{so_id}/billable")["lines"]
    out = []
    for r in rows:
        q = (qty or {}).get(r["line_no"], r["balance_qty"] if qty is None else None)
        if q is None:
            continue
        out.append({k: r[k] for k in INV_LINE_KEYS} | {"quantity": str(q), "so_item_id": r["so_item_id"]})
    return out


def new_order(client, as_user) -> dict:
    s = as_user("sales1")
    return make_so(client, s, accepted_quote(client, s))


def journal_balanced(owner_engine) -> None:
    with owner_engine.connect() as c:
        bad = c.execute(text("""select e.entry_number from journal_entries e join journal_lines l on l.entry_id = e.id
                                group by e.id having sum(l.debit) <> sum(l.credit) or sum(l.debit) <> e.total""")).all()
        assert bad == []
        dr, cr = c.execute(text("select sum(debit), sum(credit) from journal_lines")).one()
        assert dr == cr


# ------------------------------------------------------------------ invoices
def test_invoice_from_order_gst_round_off_and_issue(client, as_user, owner_engine):
    so = new_order(client, as_user)
    acc = as_user("accounts1")
    lines = so_lines(client, acc, so["id"], {1: "1", 2: "3"})
    inv = post(client, acc, "/invoices", {"sales_order_id": so["id"], "bill_type": "running", "items": lines})
    assert inv["status"] == "draft" and inv["invoice_number"] is None and inv["customer_id"] == so["customer_id"]
    assert inv["inter_state"] is False and inv["igst"] == "0.00"
    taxable = sum(D(i["taxable"]) for i in inv["items"])
    assert D(inv["taxable"]) == taxable and D(inv["cgst"]) == D(inv["sgst"])
    assert D(inv["grand_total"]) == D(inv["taxable"]) + D(inv["cgst"]) + D(inv["sgst"]) + D(inv["round_off"])
    assert D(inv["grand_total"]) % 1 == 0 and abs(D(inv["round_off"])) < D("0.5")
    assert inv["can"]["issue"] is True and inv["ra_bill_no"] == 1
    # rates stay as ordered
    bad = [dict(lines[0], rate=str(D(lines[0]["rate"]) + 1))]
    assert err(client, acc, "/invoices", {"sales_order_id": so["id"], "items": bad}) == (400, "ORDER_TERMS_CHANGED")
    # Sales can read invoices but cannot issue
    assert err(client, as_user("sales1"), f"/invoices/{inv['id']}/issue")[0] == 403
    inv = post(client, acc, f"/invoices/{inv['id']}/issue", {"row_version": inv["row_version"]})
    assert inv["status"] == "issued" and len(inv["invoice_number"]) <= 16 and inv["invoice_number"].startswith("TCE/")
    assert inv["customer_snapshot"]["gstin"] is None or len(inv["customer_snapshot"]["gstin"]) == 15
    assert inv["due_date"] and inv["balance"] == inv["grand_total"]
    assert not inv["can"]["edit"]
    assert err(client, acc, f"/invoices/{inv['id']}", {**{"items": lines, "sales_order_id": so["id"]},
                                                       "row_version": inv["row_version"]}, "put")[1] == "NOT_DRAFT"
    assert client.delete(f"{API}/invoices/{inv['id']}", headers=acc).status_code == 400
    r = client.get(f"{API}/invoices/{inv['id']}/pdf", headers=acc)
    assert r.status_code == 200 and r.content[:4] == b"%PDF"
    journal_balanced(owner_engine)


def test_cannot_bill_more_than_ordered(client, as_user):
    so = new_order(client, as_user)
    acc = as_user("accounts1")
    first = post(client, acc, "/invoices", {"sales_order_id": so["id"], "items": so_lines(client, acc, so["id"], {2: "5"})})
    post(client, acc, f"/invoices/{first['id']}/issue")
    left = {r["line_no"]: r for r in get(client, acc, f"/sales-orders/{so['id']}/billable")["lines"]}
    assert D(left[2]["billed_qty"]) == 5 and D(left[2]["balance_qty"]) == 2
    code = err(client, acc, "/invoices", {"sales_order_id": so["id"], "items": so_lines(client, acc, so["id"], {2: "3"})})
    assert code == (400, "OVER_BILLED")
    # two drafts may each fit, but only the first to be issued gets the quantity
    a = post(client, acc, "/invoices", {"sales_order_id": so["id"], "items": so_lines(client, acc, so["id"], {2: "2"})})
    b = post(client, acc, "/invoices", {"sales_order_id": so["id"], "items": so_lines(client, acc, so["id"], {2: "2"})})
    post(client, acc, f"/invoices/{a['id']}/issue")
    assert err(client, acc, f"/invoices/{b['id']}/issue")[1] == "OVER_BILLED"
    # an invoiced order cannot be cancelled
    s = as_user("sales1")
    assert err(client, s, f"/sales-orders/{so['id']}/status", {"status": "cancelled", "reason": "x"})[1] == "INVOICED"


def test_invoice_receipt_receivable_partial_then_full(client, as_user, owner_engine):
    """Spec §45: Invoice → Payment → Receivable."""
    so = new_order(client, as_user)
    acc = as_user("accounts1")
    inv = post(client, acc, "/invoices", {"sales_order_id": so["id"], "items": so_lines(client, acc, so["id"], {1: "1"})})
    inv = post(client, acc, f"/invoices/{inv['id']}/issue")
    total, cust = D(inv["grand_total"]), inv["customer_id"]
    before = get(client, acc, "/finance/receivables", customer_id=cust)["totals"]

    # part payment with TDS deducted by the customer
    tds = D("100.00")
    part = (total / 2).quantize(D("1"))
    r1 = post(client, acc, "/receipts", {"customer_id": cust, "mode": "neft", "reference_no": "UTR1",
                                         "amount": str(part - tds), "tds_amount": str(tds),
                                         "allocations": [{"document_id": inv["id"], "amount": str(part - tds),
                                                          "tds": str(tds)}]})
    assert r1["receipt_number"].startswith("TCE/RCT/") and r1["unallocated"] == "0.00"
    inv = get(client, acc, f"/invoices/{inv['id']}")
    assert inv["payment_status"] == "partially_paid" and D(inv["balance"]) == total - part and inv["tds"] == "100.00"
    after = get(client, acc, "/finance/receivables", customer_id=cust)["totals"]
    assert D(after["outstanding"]) == D(before["outstanding"]) - part

    # over-settling is refused; the rest arrives with a little extra → advance
    code = err(client, acc, "/receipts", {"customer_id": cust, "amount": str(total), "allocations": [
        {"document_id": inv["id"], "amount": str(total)}]})
    assert code == (400, "OVER_SETTLED")
    rest = total - part
    r2 = post(client, acc, "/receipts", {"customer_id": cust, "amount": str(rest + 500), "mode": "cheque",
                                         "allocations": [{"document_id": inv["id"], "amount": str(rest)}]})
    assert r2["unallocated"] == "500.00"
    inv = get(client, acc, f"/invoices/{inv['id']}")
    assert inv["payment_status"] == "paid" and inv["balance"] == "0.00" and len(inv["receipts"]) == 2
    rec = get(client, acc, "/finance/receivables", customer_id=cust)
    assert D(rec["totals"]["advance"]) >= 500

    # bounced cheque: cancelling the receipt puts the money back on the invoice and reverses the journal
    r2 = post(client, acc, f"/receipts/{r2['id']}/cancel", {"reason": "Cheque returned unpaid"})
    assert r2["status"] == "cancelled"
    inv = get(client, acc, f"/invoices/{inv['id']}")
    assert inv["payment_status"] == "partially_paid" and D(inv["balance"]) == rest
    stmt = get(client, acc, "/finance/statement", party_type="customer", party_id=cust)
    assert D(stmt["closing"]) == D(get(client, acc, "/finance/receivables", customer_id=cust)["rows"][0]["net"])
    journal_balanced(owner_engine)


def test_advance_allocated_later_and_unallocated(client, as_user):
    so = new_order(client, as_user)
    acc = as_user("accounts1")
    adv = post(client, acc, "/receipts", {"customer_id": so["customer_id"], "amount": "10000", "mode": "rtgs"})
    assert adv["unallocated"] == "10000.00" and adv["can"]["allocate"]
    inv = post(client, acc, "/invoices", {"sales_order_id": so["id"], "items": so_lines(client, acc, so["id"], {1: "1"})})
    inv = post(client, acc, f"/invoices/{inv['id']}/issue")
    adv = post(client, acc, f"/receipts/{adv['id']}/allocate", {"allocations": [{"document_id": inv["id"], "amount": "4000"}]})
    assert adv["unallocated"] == "6000.00"
    assert get(client, acc, f"/invoices/{inv['id']}")["received"] == "4000.00"
    a = [x for x in adv["allocations"] if x["is_active"]][0]
    adv = post(client, acc, f"/receipts/{adv['id']}/allocations/{a['id']}/remove")
    assert adv["unallocated"] == "10000.00" and get(client, acc, f"/invoices/{inv['id']}")["received"] == "0.00"
    # someone else's invoice cannot take this customer's money
    other = post(client, as_user("sales1"), "/customers", {"customer_name": "Other Builders", "state_code": "32"})
    assert err(client, acc, "/receipts", {"customer_id": other["id"], "amount": "10", "allocations": [
        {"document_id": inv["id"], "amount": "10"}]})[1] == "INVALID_INVOICE"


def test_credit_notes_partial_and_full_cancel(client, as_user, owner_engine):
    so = new_order(client, as_user)
    acc = as_user("accounts1")
    inv = post(client, acc, "/invoices", {"sales_order_id": so["id"], "items": so_lines(client, acc, so["id"], {2: "4"})})
    inv = post(client, acc, f"/invoices/{inv['id']}/issue")
    cn = post(client, acc, f"/invoices/{inv['id']}/credit-notes", {"reason": "Rate difference agreed", "taxable": "1000"})
    inv = cn["invoice"]
    assert cn["cn_number"].startswith("TCE/CN/") and len(cn["cn_number"]) <= 16
    c = inv["credit_notes"][0]
    assert c["taxable"] == "1000.00" and D(c["total"]) == D("1180")  # 18 % GST reversed in proportion
    assert D(inv["balance"]) == D(inv["grand_total"]) - D("1180") and inv["status"] == "issued"
    # cannot credit more than is left
    assert err(client, acc, f"/invoices/{inv['id']}/credit-notes", {"reason": "Too much", "taxable": inv["taxable"]})[1] == "OVER_CREDIT"
    # full cancellation once nothing has been received; the quantity becomes billable again
    inv = post(client, acc, f"/invoices/{inv['id']}/credit-notes", {"reason": "Billed in error", "cancel_invoice": True})["invoice"]
    assert inv["status"] == "cancelled" and inv["balance"] == "0.00"
    assert D(inv["credited"]) == D(inv["grand_total"])
    left = {r["line_no"]: r for r in get(client, acc, f"/sales-orders/{so['id']}/billable")["lines"]}
    assert left[2]["billed_qty"] == "0.000"
    r = client.get(f"{API}/credit-notes/{cn['id']}/pdf", headers=acc)
    assert r.status_code == 200 and r.content[:4] == b"%PDF"
    gst = get(client, acc, "/finance/gst-summary")
    assert D(gst["credit_notes"]["taxable"]) >= D(inv["taxable"])
    journal_balanced(owner_engine)


def test_invoice_with_receipts_cannot_be_cancelled(client, as_user):
    so = new_order(client, as_user)
    acc = as_user("accounts1")
    inv = post(client, acc, "/invoices", {"sales_order_id": so["id"], "items": so_lines(client, acc, so["id"], {1: "1"})})
    inv = post(client, acc, f"/invoices/{inv['id']}/issue")
    post(client, acc, "/receipts", {"customer_id": inv["customer_id"], "amount": "100",
                                    "allocations": [{"document_id": inv["id"], "amount": "100"}]})
    assert err(client, acc, f"/invoices/{inv['id']}/credit-notes", {"reason": "Billed in error", "cancel_invoice": True})[1] == "HAS_RECEIPTS"


def test_standalone_service_invoice_inter_state(client, as_user):
    acc = as_user("accounts1")
    c = post(client, as_user("sales1"), "/customers", {"customer_name": "Bengaluru Tech Park", "state_code": "29"})
    inv = post(client, acc, "/invoices", {"customer_id": c["id"], "bill_type": "service", "items": [
        {"description": "Earth resistance testing", "hsn_sac": "998346", "quantity": "1", "unit": "JOB",
         "rate": "12500", "tax_rate": "18"}]})
    assert inv["inter_state"] is True and inv["igst"] == "2250.00" and inv["grand_total"] == "14750.00"


# ------------------------------------------------------------------ the journal
def test_journal_is_append_only_and_must_balance(client, as_user, owner_engine):
    from app.core.config import get_settings

    acc = as_user("accounts1")
    tb = get(client, acc, "/finance/trial-balance")
    assert tb["debit"] == tb["credit"] and D(tb["debit"]) > 0
    app_engine = create_engine(get_settings().database_url)
    with app_engine.connect() as c, pytest.raises(Exception, match="permission denied"):
        c.execute(text("update journal_lines set debit = debit + 1"))
    with app_engine.connect() as c, pytest.raises(Exception, match="permission denied"):
        c.execute(text("delete from journal_entries"))
    # an unbalanced entry is refused at commit, even by a direct insert
    with app_engine.connect() as c, pytest.raises(Exception, match="does not balance"):
        acct = c.execute(text("select id from ledger_accounts where system_key = 'bank'")).scalar()
        eid = c.execute(text("""insert into journal_entries (id, entry_number, entry_date, source_type, source_id,
                               narration, total) values (gen_random_uuid(), 'TEST-1', current_date, 'test',
                               gen_random_uuid(), 'x', 10) returning id""")).scalar()
        c.execute(text("insert into journal_lines (id, entry_id, line_no, account_id, debit, credit) "
                       "values (gen_random_uuid(), :e, 1, :a, 10, 0)"), {"e": eid, "a": acct})
        c.commit()
    app_engine.dispose()
    journal_balanced(owner_engine)


# ------------------------------------------------------------------ supplier bills & payments
def test_supplier_bill_three_way_match_and_payment(client, as_user, owner_engine):
    h = as_user("purchase1")
    spd, main, dehn = item(client, h, "DEHN-SPD-T12"), wh(client, h, "MAIN"), supplier(client, h)
    po = post(client, h, "/purchase-orders", {"supplier_id": dehn["id"], "warehouse_id": main["id"],
                                              "items": [po_line(spd, "4", "14000")]})
    po = post(client, h, f"/purchase-orders/{po['id']}/submit")
    approve_all(client, as_user, po["po_number"])
    post(client, h, f"/purchase-orders/{po['id']}/send")
    po = get(client, h, f"/purchase-orders/{po['id']}")
    st = as_user("store1")
    post(client, st, "/grns", {"purchase_order_id": po["id"], "lines": [
        {"po_line_id": po["items"][0]["id"], "accepted_qty": "2", "serial_nos": ["S-1", "S-2"]}]})
    acc = as_user("accounts1")
    billable = get(client, acc, f"/purchase-orders/{po['id']}/billable")["lines"][0]
    assert billable["received_qty"] == "2.000" and billable["to_bill_qty"] == "2.000"
    base = {k: billable[k] for k in ("item_id", "description", "hsn_sac", "unit", "rate", "discount_pct", "tax_rate")}

    # billing 3 when only 2 arrived → differences listed, needs approval
    over = post(client, acc, "/supplier-invoices", {"supplier_id": dehn["id"], "supplier_invoice_no": "DI-900",
                                                    "supplier_invoice_date": po["po_date"], "purchase_order_id": po["id"],
                                                    "items": [base | {"quantity": "3", "po_item_id": billable["po_item_id"]}]})
    assert over["mismatch"] is True and over["mismatches"][0]["kind"] == "quantity"
    over = post(client, acc, f"/supplier-invoices/{over['id']}/submit")
    assert over["status"] == "pending_approval" and over["bill_number"].startswith("TCE/PB/")
    # same supplier invoice number cannot be entered twice
    assert err(client, acc, "/supplier-invoices", {"supplier_id": dehn["id"], "supplier_invoice_no": "di-900",
                                                   "supplier_invoice_date": po["po_date"], "items": [base | {"quantity": "1"}]})[1] == "DUPLICATE_BILL"
    mgr = as_user("manager")
    req = [r for r in get(client, mgr, "/approvals/inbox") if over["bill_number"] in r["entity_label"]][0]
    post(client, mgr, f"/approvals/{req['id']}/decide", {"decision": "approved", "comment": "Third unit in transit"})
    over = get(client, acc, f"/supplier-invoices/{over['id']}")
    assert over["status"] == "posted" and over["payment_status"] == "unpaid"
    total = D(over["grand_total"])
    assert over["inter_state"] is True and D(over["igst"]) > 0  # DEHN is in Karnataka

    # pay part with TDS, then the rest
    pay = post(client, acc, "/supplier-payments", {"supplier_id": dehn["id"], "amount": "10000", "tds_amount": "100",
                                                   "allocations": [{"document_id": over["id"], "amount": "10000", "tds": "100"}]})
    assert pay["payment_number"].startswith("TCE/PAY/")
    assert get(client, acc, f"/supplier-invoices/{over['id']}")["balance"] == str(total - D("10100"))
    assert err(client, acc, f"/supplier-invoices/{over['id']}/cancel", {"reason": "x"})[1] == "HAS_PAYMENTS"
    payables = get(client, acc, "/finance/payables", supplier_id=dehn["id"])
    assert D(payables["totals"]["outstanding"]) >= total - D("10100")
    post(client, acc, "/supplier-payments", {"supplier_id": dehn["id"], "amount": str(total - D("10100")),
                                             "allocations": [{"document_id": over["id"], "amount": str(total - D("10100"))}]})
    assert get(client, acc, f"/supplier-invoices/{over['id']}")["payment_status"] == "paid"
    journal_balanced(owner_engine)


def test_matching_bill_posts_without_approval(client, as_user):
    acc = as_user("accounts1")
    dehn = supplier(client, acc)
    bill = post(client, acc, "/supplier-invoices", {"supplier_id": dehn["id"], "supplier_invoice_no": "SVC-1",
                                                    "supplier_invoice_date": "2026-09-30", "items": [
        {"description": "Crane hire", "quantity": "1", "unit": "JOB", "rate": "8000", "tax_rate": "18"}]})
    assert bill["mismatch"] is False and bill["account"]["name"] == "Purchases"
    bill = post(client, acc, f"/supplier-invoices/{bill['id']}/submit")
    assert bill["status"] == "posted"


# ------------------------------------------------------------------ expenses
def _cat(client, h, name):
    return [c for c in get(client, h, "/expenses/options")["categories"] if c["name"].startswith(name)][0]


def test_expense_claim_employee_manager_accounts_paid(client, as_user, owner_engine):
    from tests.test_projects import demo_project

    e = as_user("employee1")
    cat = _cat(client, e, "Courier")
    claim = post(client, e, "/expenses", {"category_id": cat["id"], "expense_date": "2026-09-28", "amount": "450",
                                          "description": "Courier of test certificates to ABC Hospital"})
    assert claim["status"] == "draft" and claim["employee"] == "Vishnu Prasad"
    # a receipt is needed for this category
    assert err(client, e, f"/expenses/{claim['id']}/submit")[1] == "RECEIPT_REQUIRED"
    r = client.post(f"{API}/documents", headers=e, data={"entity_type": "expense", "entity_id": claim["id"],
                                                          "category": "receipt"},
                    files={"file": ("bill.pdf", b"%PDF-1.4\n%%EOF\n", "application/pdf")})
    assert r.status_code == 201, r.text
    claim = post(client, e, f"/expenses/{claim['id']}/submit")
    assert claim["status"] == "submitted" and claim["expense_number"].startswith("TCE/EXP/")
    # other employees cannot see it
    assert client.get(f"{API}/expenses/{claim['id']}", headers=as_user("store1")).status_code == 403
    assert all(x["id"] != claim["id"] for x in get(client, as_user("store1"), "/expenses"))
    # Manager, then Accounts
    for who in ("manager", "accounts1"):
        h = as_user(who)
        req = [x for x in get(client, h, "/approvals/inbox") if claim["expense_number"] in x["entity_label"]]
        assert req, who
        post(client, h, f"/approvals/{req[0]['id']}/decide", {"decision": "approved"})
    acc = as_user("accounts1")
    claim = get(client, acc, f"/expenses/{claim['id']}")
    assert claim["status"] == "approved" and claim["can"]["pay"] is True
    assert err(client, e, f"/expenses/{claim['id']}/pay", {"payment_mode": "upi"})[0] == 403
    claim = post(client, acc, f"/expenses/{claim['id']}/pay", {"payment_mode": "upi", "payment_reference": "UPI-1"})
    assert claim["status"] == "paid" and claim["paid_by"]
    emp = get(client, acc, "/expenses/options")["employees"]
    emp_id = [x for x in emp if x["name"] == "Vishnu Prasad"][0]["id"]
    st = get(client, acc, "/finance/statement", party_type="employee", party_id=emp_id)
    assert st["closing"] == "0.00" and len(st["lines"]) == 2

    # a project expense becomes project cost
    prj = demo_project(client, as_user("pm1"))
    before = D(prj["financials"]["actual_cost"])
    eng = as_user("engineer1")
    c2 = post(client, eng, "/expenses", {"category_id": _cat(client, eng, "Local conveyance")["id"], "project_id": prj["id"],
                                         "expense_date": "2026-09-29", "amount": "300", "description": "Auto to site"})
    number = post(client, eng, f"/expenses/{c2['id']}/submit")["expense_number"]
    for who in ("manager", "accounts1"):
        h = as_user(who)
        req = [x for x in get(client, h, "/approvals/inbox") if number in x["entity_label"]]
        post(client, h, f"/approvals/{req[0]['id']}/decide", {"decision": "approved"})
    prj = demo_project(client, as_user("pm1"))
    assert D(prj["financials"]["actual_cost"]) == before + 300 and D(prj["financials"]["travel_cost"]) >= 300
    journal_balanced(owner_engine)


def test_expense_rejection_returns_to_draft_and_own_claims_cannot_be_self_approved(client, as_user):
    m = as_user("manager")
    claim = post(client, m, "/expenses", {"category_id": _cat(client, m, "Local conveyance")["id"],
                                          "expense_date": "2026-09-28", "amount": "200", "description": "Taxi to client"})
    claim = post(client, m, f"/expenses/{claim['id']}/submit")
    assert claim["can"]["decide"] is False  # nobody approves their own claim
    d = as_user("director")
    req = [x for x in get(client, d, "/approvals/inbox") if claim["expense_number"] in x["entity_label"]][0]
    post(client, d, f"/approvals/{req['id']}/decide", {"decision": "rejected", "comment": "Use the office car"})
    claim = get(client, m, f"/expenses/{claim['id']}")
    assert claim["status"] == "draft" and claim["last_rejection"] == "Use the office car"
    claim = post(client, m, f"/expenses/{claim['id']}/cancel", {"reason": "Withdrawn"})
    assert claim["status"] == "cancelled"


def test_dashboard_and_permissions(client, as_user):
    acc = as_user("accounts1")
    d = get(client, acc, "/finance/dashboard")
    assert D(d["receivable"]) > 0 and "payable" in d and len(d["trend"]) == 6
    s = get(client, as_user("sales1"), "/finance/dashboard")
    assert "payable" not in s and "bank_movement" not in s
    assert client.get(f"{API}/finance/dashboard", headers=as_user("store1")).status_code == 403
    assert client.get(f"{API}/supplier-invoices", headers=as_user("sales1")).status_code == 403
    assert client.get(f"{API}/finance/gst-summary", headers=as_user("manager")).status_code == 403
    r = client.get(f"{API}/finance/daybook/export", headers=acc)
    assert r.status_code == 200 and r.content[:2] == b"PK"
    r = client.get(f"{API}/finance/receivables/export", headers=acc)
    assert r.status_code == 200
