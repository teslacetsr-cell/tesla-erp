"""Phase 3: BOQ, quotations, approvals (Spec §13, §14, §30, §45 "Quotation calculation / approval")."""
import io
import re
from decimal import Decimal as D

from openpyxl import load_workbook

API = "/api/v1"


def me(client, h) -> str:
    return client.get(f"{API}/auth/me", headers=h).json()["data"]["id"]


def abc(client, h) -> dict:
    return client.get(f"{API}/customers", headers=h, params={"q": "ABC Hospital"}).json()["data"][0]


def item(client, h, code) -> dict:
    return client.get(f"{API}/items", headers=h, params={"q": code}).json()["data"][0]


def line(**kw) -> dict:
    return {"description": "DEHN SPD Type 1+2", "quantity": "2", "unit": "NOS", "rate": "14200", "discount_pct": "0",
            "tax_rate": "18", "hsn_sac": "85363000"} | kw


def new_quote(client, h, lines, **kw) -> dict:
    c = kw.pop("customer_id", None) or abc(client, h)["id"]
    r = client.post(f"{API}/quotations", headers=h, json={"customer_id": c, "subject": "LPS for main block",
                                                          "items": lines} | kw)
    assert r.status_code == 201, r.text
    return r.json()["data"]


def act(client, h, q, action, **body) -> dict:
    r = client.post(f"{API}/quotations/{q['id']}/{action}", headers=h, json=body)
    assert r.status_code in (200, 201), r.text
    return r.json()["data"]


# ------------------------------------------------------------------ BOQ
def test_boq_totals_final_lock_copy(client, as_user):
    h = as_user("pm1")
    c = abc(client, h)
    r = client.post(f"{API}/boqs", headers=h, json={"title": "LPS main block", "customer_id": c["id"], "items": [
        line(section="Surge protection"),
        line(section="External LPS", description="Copper tape 25×3", quantity="120", unit="M", rate="620",
             discount_pct="5", hsn_sac="74072990")]})
    assert r.status_code == 201, r.text
    b = r.json()["data"]
    assert re.fullmatch(r"TCE/BOQ/\d{4}-\d{2}/\d{4}", b["boq_number"])
    # 28,400 + (74,400 − 3,720) = 99,080 before GST; 18 % = 17,834.40; total 1,16,914.40 (BOQ totals are not rounded)
    assert (b["taxable"], b["tax_total"], b["total"]) == ("99080.00", "17834.40", "116914.40")
    assert b["inter_state"] is False and [i["section"] for i in b["items"]] == ["Surge protection", "External LPS"]
    r = client.post(f"{API}/boqs/{b['id']}/status", headers=h, json={"status": "final"})
    assert r.json()["data"]["status"] == "final"
    r = client.put(f"{API}/boqs/{b['id']}", headers=h, json={"title": "x y z", "items": [], "row_version": r.json()["data"]["row_version"]})
    assert r.json()["error"]["code"] == "BOQ_FINAL"
    cp = client.post(f"{API}/boqs/{b['id']}/copy", headers=h).json()["data"]
    assert cp["status"] == "draft" and cp["total"] == b["total"] and cp["boq_number"] != b["boq_number"]
    pdf = client.get(f"{API}/boqs/{b['id']}/pdf", headers=h)
    assert pdf.status_code == 200 and pdf.content[:5] == b"%PDF-"


def test_boq_rejects_gst_rate_not_in_master(client, as_user):
    h = as_user("pm1")
    r = client.post(f"{API}/boqs", headers=h, json={"title": "Odd rate", "items": [line(tax_rate="17")]})
    assert r.status_code == 400 and r.json()["error"]["code"] == "INVALID_GST_RATE"


def test_boq_excel_import_validates_then_commits(client, as_user):
    h = as_user("pm1")
    b = client.post(f"{API}/boqs", headers=h, json={"title": "Import test"}).json()["data"]
    wb = load_workbook(io.BytesIO(client.get(f"{API}/boqs/import-template", headers=h).content))
    ws = wb.worksheets[0]
    headers = [c.value.replace(" *", "") for c in ws[1]]
    col = {h_: i + 1 for i, h_ in enumerate(headers)}
    ws.delete_rows(2)
    rows = [{"Section": "External LPS", "Item code": "LP-AT-16", "Qty": 12},             # fills from item master
            {"Description": "Test joint box", "Qty": 4, "Unit": "NOS", "Rate": 450, "GST %": 18},
            {"Description": "Bad rate row", "Qty": 1, "Rate": 10, "GST %": 7},              # not in GST master
            {"Item code": "NOPE-1", "Qty": 1}]                                           # unknown item
    for r_i, row in enumerate(rows, start=2):
        for k, v in row.items():
            ws.cell(row=r_i, column=col[k], value=v)
    buf = io.BytesIO()
    wb.save(buf)
    files = {"file": ("boq.xlsx", buf.getvalue(), "application/octet-stream")}
    rep = client.post(f"{API}/boqs/{b['id']}/import", headers=h, files=files, params={"dry_run": False}).json()["data"]
    assert rep["committed"] is False and {e["row"] for e in rep["errors"]} == {4, 5}
    # fix the file: drop the bad rows
    ws.delete_rows(4, 2)
    buf = io.BytesIO()
    wb.save(buf)
    files = {"file": ("boq.xlsx", buf.getvalue(), "application/octet-stream")}
    rep = client.post(f"{API}/boqs/{b['id']}/import", headers=h, files=files, params={"dry_run": False}).json()["data"]
    assert rep["committed"] is True and rep["valid"] == 2
    got = client.get(f"{API}/boqs/{b['id']}", headers=h).json()["data"]
    at = got["items"][0]
    assert (at["description"], at["unit"], at["rate"], at["tax_rate"]) == ("Air Terminal, copper, 16 mm × 1 m", "NOS",
                                                                           "2400.0000", "18")
    x = client.get(f"{API}/boqs/{b['id']}/export", headers=h)
    assert x.status_code == 200 and x.content[:2] == b"PK"


# ------------------------------------------------------------------ quotation workflow (below threshold)
def test_quotation_lifecycle_revisions_are_immutable(client, as_user):
    h = as_user("sales1")
    # a new enquiry from the demo ABC Hospital lead's customer
    enq = client.post(f"{API}/enquiries", headers=h, json={"customer_id": abc(client, h)["id"],
                                                           "subject": "Surge protection for OT block"}).json()["data"]
    q = new_quote(client, h, [line()], enquiry_id=enq["id"], customer_id=None)
    assert q["status"] == "draft" and q["quotation_number"] is None and q["display_number"] == "DRAFT"
    cur = q["current"]
    assert (cur["taxable"], cur["cgst"], cur["sgst"], cur["grand_total"]) == ("28400.00", "2556.00", "2556.00", "33512.00")
    assert cur["payment_terms"] and len(cur["terms"]) >= 3  # defaults from the terms library
    q = act(client, h, q, "submit", row_version=q["row_version"])
    assert q["status"] == "approved"  # ₹28,400 is below the ₹5 lakh rule
    assert re.fullmatch(r"TCE/QTN/\d{4}-\d{2}/\d{4}", q["quotation_number"])
    q = act(client, h, q, "send")
    assert q["status"] == "sent" and q["current"]["locked"] and q["current"]["pdf_document_id"]
    assert client.get(f"{API}/enquiries/{enq['id']}", headers=h).json()["data"]["status"] == "quoted"
    # a sent revision can never be edited
    body = {"customer_id": q["customer_id"], "subject": "changed", "items": [line(rate="1")], "row_version": q["row_version"]}
    assert client.put(f"{API}/quotations/{q['id']}", headers=h, json=body).json()["error"]["code"] == "NOT_DRAFT"
    sent_pdf = client.get(f"{API}/quotations/{q['id']}/revisions/0/pdf", headers=h).content
    # revise → R1 draft; R0 unchanged
    r = client.post(f"{API}/quotations/{q['id']}/revise", headers=h, json={"change_note": "Customer asked 5 % off"})
    q = r.json()["data"]
    assert q["current_revision_no"] == 1 and q["status"] == "draft" and q["display_number"].endswith("-R1")
    body = {"customer_id": q["customer_id"], "enquiry_id": enq["id"], "subject": q["subject"], "row_version": q["row_version"],
            "items": [line(discount_pct="5")], "terms": q["current"]["terms"]}
    q = client.put(f"{API}/quotations/{q['id']}", headers=h, json=body).json()["data"]
    assert q["current"]["taxable"] == "26980.00"
    r0 = client.get(f"{API}/quotations/{q['id']}/revisions/0", headers=h).json()["data"]
    assert r0["taxable"] == "28400.00" and r0["locked"] is True
    assert client.get(f"{API}/quotations/{q['id']}/revisions/0/pdf", headers=h).content == sent_pdf  # the filed copy
    q = act(client, h, q, "submit")
    q = act(client, h, q, "send")
    q = act(client, h, q, "accept")
    assert q["status"] == "accepted" and q["accepted_revision_no"] == 1
    assert client.get(f"{API}/enquiries/{enq['id']}", headers=h).json()["data"]["status"] == "won"


def test_inter_state_quotation_uses_igst(client, as_user, admin_headers):
    h = as_user("manager")
    c = client.post(f"{API}/customers", headers=admin_headers, json={
        "customer_name": "Bengaluru Tech Park", "state_code": "29", "city": "Bengaluru"}).json()["data"]
    q = new_quote(client, h, [line()], customer_id=c["id"])
    cur = q["current"]
    assert cur["inter_state"] is True and cur["place_of_supply"] == "29"
    assert (cur["cgst"], cur["sgst"], cur["igst"]) == ("0.00", "0.00", "5112.00")
    pdf = client.get(f"{API}/quotations/{q['id']}/revisions/0/pdf", headers=h)
    assert pdf.status_code == 200 and pdf.content[:5] == b"%PDF-"


def test_special_discount_round_off(client, as_user):
    h = as_user("sales1")
    q = new_quote(client, h, [line(quantity="3", rate="1850", discount_pct="7.5")], special_discount="133.75")
    cur = q["current"]
    # 5,550 − 416.25 = 5,133.75 − special 133.75 = 5,000 → +18 % = 5,900
    assert (cur["taxable"], cur["grand_total"], cur["round_off"]) == ("5000.00", "5900.00", "0.00")


# ------------------------------------------------------------------ approvals (Spec §30 exit test)
def test_above_5_lakh_needs_manager_then_director(client, as_user):
    hs, hm, hd = as_user("sales1"), as_user("manager"), as_user("director")
    q = new_quote(client, hs, [line(quantity="40", rate="14200")])  # ₹5,68,000 before GST
    q = act(client, hs, q, "submit")
    assert q["status"] == "pending_approval" and q["approval"]["steps"] == ["MANAGER", "DIRECTOR"]
    # the salesperson cannot approve; the director is allowed to act on the manager step, but here the manager does
    assert client.get(f"{API}/approvals/inbox", headers=hs).json()["data"] == []
    inbox = client.get(f"{API}/approvals/inbox", headers=hm).json()["data"]
    req = next(r for r in inbox if r["entity_id"] == q["id"])
    notes = client.get(f"{API}/notifications", headers=hm).json()
    assert notes["meta"]["unread"] >= 1 and "Approval needed" in notes["data"][0]["title"]
    r = client.post(f"{API}/approvals/{req['id']}/decide", headers=hm, json={"decision": "approved", "comment": "OK"})
    assert r.json()["data"]["current_step"] == 1
    assert client.get(f"{API}/quotations/{q['id']}", headers=hs).json()["data"]["status"] == "pending_approval"
    # the manager cannot also take the director step
    r = client.post(f"{API}/approvals/{req['id']}/decide", headers=hm, json={"decision": "approved"})
    assert r.status_code == 403 and r.json()["error"]["code"] == "NOT_YOUR_STEP"
    # director rejects: a comment is required; the quotation goes back to draft with the comment
    r = client.post(f"{API}/approvals/{req['id']}/decide", headers=hd, json={"decision": "rejected"})
    assert r.json()["error"]["code"] == "COMMENT_REQUIRED"
    r = client.post(f"{API}/approvals/{req['id']}/decide", headers=hd, json={"decision": "rejected",
                                                                             "comment": "Margin too low; revise rate"})
    assert r.json()["data"]["status"] == "rejected"
    q = client.get(f"{API}/quotations/{q['id']}", headers=hs).json()["data"]
    assert q["status"] == "draft" and "Margin too low" in q["current"]["last_rejection"]
    notes = client.get(f"{API}/notifications", headers=hs).json()["data"]
    assert any("rejected" in n["title"] for n in notes)
    # resubmit → both steps → approved
    q = act(client, hs, q, "submit")
    for who in (hm, hd):
        req = next(r for r in client.get(f"{API}/approvals/inbox", headers=who).json()["data"] if r["entity_id"] == q["id"])
        assert client.post(f"{API}/approvals/{req['id']}/decide", headers=who, json={"decision": "approved"}).status_code == 200
    q = client.get(f"{API}/quotations/{q['id']}", headers=hs).json()["data"]
    assert q["status"] == "approved" and len(q["approvals"]) == 2
    assert any("approved" in n["title"] for n in client.get(f"{API}/notifications", headers=hs).json()["data"])


def test_nobody_approves_their_own_quotation(client, as_user):
    hm = as_user("manager")
    q = new_quote(client, hm, [line(quantity="40", rate="14200")])
    q = act(client, hm, q, "submit")
    req = q["approval"]
    assert req["can_decide"] is False
    r = client.post(f"{API}/approvals/{req['id']}/decide", headers=hm, json={"decision": "approved"})
    assert r.status_code == 403 and r.json()["error"]["code"] == "OWN_REQUEST"
    # withdraw returns it to draft for editing
    q = act(client, hm, q, "withdraw")
    assert q["status"] == "draft" and q["approval"] is None


def test_approval_rules_are_configurable(client, as_user, admin_headers):
    pols = [x for x in client.get(f"{API}/approval-policies", headers=admin_headers).json()["data"]
            if x["entity_type"] == "quotation"]
    assert pols[0]["min_amount"] == "500000.00" and pols[0]["steps"] == ["MANAGER", "DIRECTOR"]
    r = client.post(f"{API}/approval-policies", headers=admin_headers, json={
        "entity_type": "quotation", "name": "Every quotation", "min_amount": "0", "steps": ["NOPE"]})
    assert r.json()["error"]["code"] == "INVALID_STEPS"
    r = client.post(f"{API}/approval-policies", headers=admin_headers, json={
        "entity_type": "quotation", "name": "Every quotation — manager", "min_amount": "0", "steps": ["manager"]})
    assert r.status_code == 201 and r.json()["data"]["steps"] == ["MANAGER"]
    hs = as_user("sales1")
    q = act(client, hs, new_quote(client, hs, [line()]), "submit")  # small value now needs the manager
    assert q["status"] == "pending_approval" and q["approval"]["steps"] == ["MANAGER"]
    assert client.get(f"{API}/approval-policies", headers=hs).status_code == 403


# ------------------------------------------------------------------ scope, expiry, delete
def test_sales_see_only_own_quotations(client, as_user):
    q = new_quote(client, as_user("sales1"), [line()])
    h2 = as_user("sales2")
    assert client.get(f"{API}/quotations/{q['id']}", headers=h2).status_code == 403
    assert all(x["id"] != q["id"] for x in client.get(f"{API}/quotations", headers=h2).json()["data"])
    assert client.get(f"{API}/quotations/{q['id']}", headers=as_user("accounts1")).status_code == 200
    assert client.post(f"{API}/quotations", headers=as_user("accounts1"), json={}).status_code == 403


def test_expiry_and_delete_rules(client, as_user, owner_engine):
    from sqlalchemy import text

    from app.core.db import SessionLocal
    from app.quotations.service import expire_due

    h = as_user("sales1")
    draft = new_quote(client, h, [line()])
    assert client.delete(f"{API}/quotations/{draft['id']}", headers=as_user("manager")).status_code == 200
    q = act(client, h, act(client, h, new_quote(client, h, [line()]), "submit"), "send")
    with owner_engine.begin() as c:
        c.execute(text("UPDATE quotation_revisions SET quotation_date = current_date - 40, "
                       "valid_until = current_date - 1 WHERE quotation_id = :q"), {"q": q["id"]})
    with SessionLocal() as s:
        assert expire_due(s) == 1
        s.commit()
    q = client.get(f"{API}/quotations/{q['id']}", headers=h).json()["data"]
    assert q["status"] == "expired" and q["can"]["revise"]
    assert client.delete(f"{API}/quotations/{q['id']}", headers=as_user("manager")).json()["error"]["code"] == "NUMBERED"


def test_quotation_from_boq_copies_lines(client, as_user):
    h = as_user("sales1")
    b = client.post(f"{API}/boqs", headers=h, json={"title": "From BOQ", "customer_id": abc(client, h)["id"],
                                                    "items": [line(), line(description="Earth pit", rate="3600")]}).json()["data"]
    q = new_quote(client, h, [], boq_id=b["id"])
    assert [i["description"] for i in q["current"]["items"]] == ["DEHN SPD Type 1+2", "Earth pit"]
    assert D(q["current"]["taxable"]) == D(b["taxable"])


def test_transparent_logo_prints_on_white():
    """The TCE logo is a transparent PNG whose transparent pixels are stored as black; PDFs must show white."""
    from PIL import Image as PILImage

    from app.platform.pdfkit import ASSETS, flatten

    with PILImage.open(ASSETS / "tce-logo.png") as im:
        assert im.mode == "RGBA" and im.getpixel((0, 0))[:3] == (0, 0, 0)  # transparent black
        flat = flatten(im)
    assert flat.mode == "RGB" and flat.getpixel((0, 0)) == (255, 255, 255)
    assert flat.getpixel((256, 256)) != (255, 255, 255)  # the logo itself is untouched
