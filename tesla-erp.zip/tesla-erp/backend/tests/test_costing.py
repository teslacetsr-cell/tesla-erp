"""Phase 6: material issue and return, the project cost ledger, profitability (Spec §20, §21, §24, §44)."""
from decimal import Decimal as D

from sqlalchemy import text

from tests.test_finance import err, get, post, so_lines
from tests.test_projects import accepted_quote, demo_project, make_so
from tests.test_purchase import item, wh

API = "/api/v1"


def costs(client, h, prj_id) -> dict:
    return {r["head"]: D(r["actual"]) for r in get(client, h, f"/projects/{prj_id}/profitability")["heads"]}


def approve(client, as_user, number):
    for who in ("pm1", "director"):
        h = as_user(who)
        for r in get(client, h, "/approvals/inbox"):
            if number in r["entity_label"]:
                post(client, h, f"/approvals/{r['id']}/decide", {"decision": "approved"})
                return


def opening(client, as_user, item_id, qty, cost, serials=()):
    st = as_user("store1")
    main = wh(client, st, "MAIN")
    a = post(client, st, "/stock-adjustments", {"warehouse_id": main["id"], "reason_type": "opening",
                                                 "reason": "More opening stock for test", "lines": [
                                                     {"item_id": item_id, "quantity": str(qty), "unit_cost": str(cost),
                                                      "serial_nos": list(serials)}]})
    post(client, st, f"/stock-adjustments/{a['id']}/submit")
    for who in ("manager", "director"):
        h = as_user(who)
        for r in get(client, h, "/approvals/inbox"):
            if r["entity_id"] == a["id"]:
                post(client, h, f"/approvals/{r['id']}/decide", {"decision": "approved"})
    return main


def test_issue_five_spds_adds_exact_weighted_cost(client, as_user, owner_engine):
    """Spec §20 / plan exit test: issue 5 × DEHN SPD → material cost up by exactly the weighted average cost."""
    st = as_user("store1")
    spd = item(client, st, "DEHN-SPD-T12")
    main = opening(client, as_user, spd["id"], 4, "15100", [f"T-{n}" for n in range(4)])
    # main store now holds 3 @ 14,200 (demo opening) + 4 @ 15,100 → average (42,600 + 60,400) / 7
    prj = demo_project(client, as_user("pm1"))
    before = costs(client, as_user("pm1"), prj["id"])["material"]
    serials = ["DV2026090", "DV2026091", "DV2026092", "T-0", "T-1"]
    m = post(client, st, "/material-issues", {"project_id": prj["id"], "warehouse_id": main["id"], "submit": True,
                                              "issued_to": "Site team", "lines": [
                                                  {"item_id": spd["id"], "quantity": "5", "serial_nos": serials}]})
    assert m["status"] == "pending_approval" and m["issue_number"].startswith("TCE/MI/")
    left = D(next(x for x in get(client, st, f"/projects/{prj['id']}/issuable")["lines"]
                  if x["item_id"] == spd["id"])["left_qty"])
    assert m["has_excess"] is True  # the BOQ needs only 2 SPDs
    assert D(m["lines"][0]["excess_qty"]) == 5 - left
    approve(client, as_user, m["issue_number"])
    m = get(client, st, f"/material-issues/{m['id']}")
    assert m["status"] == "posted"
    expected = (D("103000") * 5 / 7).quantize(D("0.01"))
    assert abs(D(m["value"]) - expected) <= D("0.05")
    after = costs(client, as_user("pm1"), prj["id"])["material"]
    assert after - before == D(m["value"])
    with owner_engine.connect() as c:
        led = c.execute(text("select sum(-value) from stock_transactions where source_id = :i"), {"i": m["id"]}).scalar()
        assert D(led) == D(m["value"])
        assert c.execute(text("select status from stock_serials where serial_no = 'T-0'")).scalar() == "out"


def test_failed_issue_changes_nothing(client, as_user, owner_engine):
    """Spec §44: if any step fails, nothing is posted — stock, cost, BOQ issued quantity and audit unchanged."""
    st = as_user("store1")
    main = wh(client, st, "MAIN")
    tape, at16 = item(client, st, "LP-CT-25X3"), item(client, st, "LP-AT-16")
    prj = demo_project(client, as_user("pm1"))

    def snapshot():
        with owner_engine.connect() as c:
            return (c.execute(text("select count(*), coalesce(sum(value),0) from stock_transactions")).one(),
                    c.execute(text("select count(*), coalesce(sum(amount),0) from project_cost_entries")).one(),
                    c.execute(text("select coalesce(sum(issued_qty),0) from project_boq_lines")).scalar(),
                    c.execute(text("select count(*) from audit_logs where entity_type = 'material_issue' and action = 'post'")).scalar())

    m = post(client, st, "/material-issues", {"project_id": prj["id"], "warehouse_id": main["id"], "lines": [
        {"item_id": at16["id"], "quantity": "2"}, {"item_id": tape["id"], "quantity": "100000"}]})
    before = snapshot()
    code = err(client, st, f"/material-issues/{m['id']}/submit")
    assert code == (409, "INSUFFICIENT_STOCK")
    assert snapshot() == before
    assert get(client, st, f"/material-issues/{m['id']}")["status"] == "draft"


def test_return_at_project_cost_and_limits(client, as_user):
    st = as_user("store1")
    prj = demo_project(client, as_user("pm1"))
    ret = get(client, st, f"/projects/{prj['id']}/returnable")
    line = next(r for r in ret["lines"] if not r["serial"])
    before = costs(client, as_user("pm1"), prj["id"])["material"]
    r = post(client, st, "/material-returns", {"project_id": prj["id"], "lines": [
        {"item_id": line["item_id"], "quantity": "1"}]})
    assert r["kind"] == "return" and r["status"] == "posted" and r["issue_number"].startswith("TCE/MRN/")
    assert D(r["lines"][0]["unit_cost"]) == D(line["avg_cost"])
    assert costs(client, as_user("pm1"), prj["id"])["material"] == before - D(r["value"])
    too_many = str(D(line["net_qty"]) + 5)
    assert err(client, st, "/material-returns", {"project_id": prj["id"], "lines": [
        {"item_id": line["item_id"], "quantity": too_many}]})[1] == "OVER_RETURN"


def test_rejected_issue_goes_back_to_draft(client, as_user):
    st = as_user("store1")
    at16 = item(client, st, "LP-AT-16")
    prj = demo_project(client, as_user("pm1"))
    m = post(client, st, "/material-issues", {"project_id": prj["id"], "submit": True,
                                              "lines": [{"item_id": at16["id"], "quantity": "1"}]})
    if m["status"] == "posted":  # the site store may not hold air terminals; issue from the main store instead
        return
    pm = as_user("pm1")
    req = [r for r in get(client, pm, "/approvals/inbox") if m["issue_number"] in r["entity_label"]][0]
    post(client, pm, f"/approvals/{req['id']}/decide", {"decision": "rejected", "comment": "Use the site stock"})
    m = get(client, st, f"/material-issues/{m['id']}")
    assert m["status"] == "draft" and m["last_rejection"] == "Use the site stock"


def test_manual_costs_profitability_and_budget(client, as_user):
    pm = as_user("pm1")
    prj = demo_project(client, pm)
    pr = get(client, pm, f"/projects/{prj['id']}/profitability")
    before = {r["head"]: D(r["actual"]) for r in pr["heads"]}
    e = post(client, pm, f"/projects/{prj['id']}/costs", {"cost_head": "subcontract", "cost_date": "2026-09-30",
                                                         "amount": "42000", "party": "Kerala Scaffolding Co",
                                                         "description": "Scaffolding hire for roof work"})
    assert err(client, pm, f"/projects/{prj['id']}/costs", {"cost_head": "material", "cost_date": "2026-09-30",
                                                           "amount": "1", "description": "x y z"})[0] == 422
    pr = get(client, pm, f"/projects/{prj['id']}/profitability")
    heads = {r["head"]: r for r in pr["heads"]}
    assert D(heads["subcontract"]["actual"]) == before["subcontract"] + 42000
    total = sum(D(r["actual"]) for r in pr["heads"])
    assert D(pr["actual"]["cost"]) == total
    assert D(pr["actual"]["profit"]) == D(pr["actual"]["revenue"]) - total
    # the project page shows the same figures
    f = demo_project(client, pm)["financials"]
    assert D(f["actual_cost"]) == total and D(f["material_cost"]) == D(heads["material"]["actual"])
    # budgets give estimated vs actual
    pr = client.put(f"{API}/projects/{prj['id']}/budget", headers=pm, json={"labour": "60000", "subcontract": "50000"}).json()["data"]
    heads = {r["head"]: r for r in pr["heads"]}
    assert heads["subcontract"]["estimated"] == "50000.00" and D(heads["subcontract"]["variance"]) == 50000 - D(heads["subcontract"]["actual"])
    assert pr["material_from_boq"] is True and D(heads["material"]["estimated"]) > 0
    # reverse the manual entry
    post(client, pm, f"/project-costs/{e['id']}/reverse", {"reason": "Entered against the wrong project"})
    assert costs(client, pm, prj["id"])["subcontract"] == before["subcontract"]
    assert err(client, pm, f"/project-costs/{e['id']}/reverse", {"reason": "again"})[1] == "ALREADY_REVERSED"
    # the ledger lists the entry, marked reversed, with its reversal
    led = client.get(f"{API}/projects/{prj['id']}/costs", headers=pm, params={"head": "subcontract"}).json()
    mine = [x for x in led["data"] if x["id"] == e["id"]]
    assert mine and mine[0]["reversed"] is True and mine[0]["can_reverse"] is False and mine[0]["created_by"]
    assert any(x["reverses_id"] == e["id"] for x in led["data"])
    # who can see costs
    assert client.get(f"{API}/projects/{prj['id']}/profitability", headers=as_user("sales1")).status_code == 403
    rows = get(client, as_user("director"), "/project-profitability")
    assert any(r["id"] == prj["id"] for r in rows)
    r = client.get(f"{API}/project-profitability/export", headers=as_user("director"))
    assert r.status_code == 200 and r.content[:2] == b"PK"


def test_collected_counts_order_invoices_and_project_advances(client, as_user):
    """Bug report: money received did not show as Collected on the project."""
    s = as_user("sales1")
    so = make_so(client, s, accepted_quote(client, s))
    acc = as_user("accounts1")
    # billed and paid on the ORDER, before the project exists
    inv = post(client, acc, "/invoices", {"sales_order_id": so["id"], "items": so_lines(client, acc, so["id"], {1: "1"})})
    inv = post(client, acc, f"/invoices/{inv['id']}/issue")
    post(client, acc, "/receipts", {"customer_id": so["customer_id"], "amount": "5000",
                                    "allocations": [{"document_id": inv["id"], "amount": "5000"}]})
    post(client, acc, "/receipts", {"customer_id": so["customer_id"], "amount": "20000", "sales_order_id": so["id"]})
    pm = as_user("pm1")
    pm_id = get(client, pm, "/auth/me")["id"]
    prj = post(client, pm, "/projects", {"sales_order_id": so["id"], "name": "SPD retrofit", "project_manager_id": pm_id})
    f = get(client, pm, f"/projects/{prj['id']}")["financials"]
    assert D(f["billed"]) == D(inv["taxable"]) and D(f["advance"]) == 20000
    assert D(f["collected"]) == 25000 and D(f["collected_against_invoices"]) == 5000
    assert get(client, acc, f"/invoices/{inv['id']}")["project_id"] == prj["id"]  # adopted by the project
    # an advance recorded straight against the project counts as well
    post(client, acc, "/receipts", {"customer_id": so["customer_id"], "amount": "1000", "project_id": prj["id"]})
    assert D(get(client, pm, f"/projects/{prj['id']}")["financials"]["collected"]) == 26000


def test_dashboard_open_value_includes_open_projects(client, as_user):
    d = as_user("director")
    before = get(client, d, "/sales-orders/summary")
    pm = as_user("pm1")
    pm_id = get(client, pm, "/auth/me")["id"]
    cust = get(client, pm, "/customers", q="ABC Hospital")[0]
    post(client, pm, "/projects", {"customer_id": cust["id"], "name": "Earth pit maintenance", "contract_value": "75000",
                                   "project_manager_id": pm_id})
    after = get(client, d, "/sales-orders/summary")
    assert D(after["open_value"]) == D(before["open_value"]) + 75000
    assert D(after["open_project_value"]) == D(before["open_project_value"]) + 75000
    assert after["open_order_value"] == before["open_order_value"]
