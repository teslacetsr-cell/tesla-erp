"""Phase 8: HR — attendance with check-in location, leave with line-manager approval and balances, employee profile
privacy, confidential salary, and labour cost from attendance (Spec §26; plan exit: an employee can apply leave and
mark attendance on the phone; HR sees balances; salary visible only to HR / Director)."""
from datetime import date, timedelta
from decimal import Decimal as D

from sqlalchemy import text

from tests.test_finance import err, get, post

API = "/api/v1"


def next_workday(start: date, skip: int = 0) -> date:
    d = start
    n = -1
    while True:
        d += timedelta(days=1)
        if d.weekday() != 6 and (d.month, d.day) not in ((1, 26), (5, 1), (8, 15), (10, 2), (12, 25)):
            n += 1
            if n == skip:
                return d


def leave_type(client, h, code):
    return [t for t in get(client, h, "/hr/me")["leave_types"] if t["code"] == code][0]


def test_check_in_and_out_with_location(client, as_user, admin_headers):
    h = as_user("store1")
    me = get(client, h, "/hr/me")
    assert me["employee"]["full_name"] == "Suresh Babu" and me["today"] is None
    row = post(client, h, "/hr/me/check-in", {"lat": "10.5276", "lng": "76.2144", "accuracy_m": 12})
    assert row["status"] == "present" and row["located"] is True and row["check_in_at"]
    assert err(client, h, "/hr/me/check-in", {})[1] == "ALREADY_CHECKED_IN"
    row = post(client, h, "/hr/me/check-out", {"lat": "10.5276", "lng": "76.2144"})
    assert row["check_out_at"] and row["work_hours"] is not None
    # a check-out within minutes of check-in is less than half of the 8-hour day → half day
    assert row["status"] == "half_day"
    month = date.today().strftime("%Y-%m")
    mine = get(client, h, "/hr/me/attendance", month=month)["rows"][0]
    assert any(c["status"] == "half_day" and c["located"] for c in mine["days"])
    # only HR marks attendance for others
    assert err(client, h, "/attendance/mark", {"employee_id": me["employee"]["id"], "att_date": str(date.today()),
                                                "status": "present"})[0] == 403
    hr = as_user("hr1")
    fixed = post(client, hr, "/attendance/mark", {"employee_id": me["employee"]["id"], "att_date": str(date.today()),
                                                  "status": "present", "remarks": "Stock count ran late; full day"})
    assert fixed["status"] == "present" and fixed["source"] == "hr"
    assert any(x["project_number"] for x in get(client, hr, "/attendance/projects"))
    assert client.get(f"{API}/attendance/projects", headers=h).status_code == 403
    reg = get(client, hr, "/attendance/register", month=month)
    assert len(reg["rows"]) >= 11 and get(client, hr, "/attendance/today")["employees"] >= 11
    r = client.get(f"{API}/attendance/register/export", headers=hr, params={"month": month})
    assert r.status_code == 200 and r.content[:2] == b"PK"


def test_leave_goes_to_the_line_manager(client, as_user):
    eng = as_user("engineer1")          # reports to pm1 (demo)
    cl = leave_type(client, eng, "CL")
    d1 = next_workday(date.today(), 3)
    d2 = next_workday(d1)
    before = {b["code"]: b for b in get(client, eng, "/hr/me")["balances"]}["CL"]
    lr = post(client, eng, "/leave-requests", {"leave_type_id": cl["id"], "from_date": str(d1), "to_date": str(d2),
                                               "reason": "Sister's wedding"})
    assert lr["status"] == "pending" and lr["days"] == "2" and lr["approval"]["steps"] == ["LINE_MANAGER"]
    # the Manager role is not this person's line manager; the project manager (line manager) is
    mgr = as_user("manager")
    assert all(x["entity_id"] != lr["id"] for x in get(client, mgr, "/approvals/inbox"))
    pm = as_user("pm1")
    req = [x for x in get(client, pm, "/approvals/inbox") if x["entity_id"] == lr["id"]]
    assert req, "the line manager should see the request"
    assert get(client, pm, f"/leave-requests/{lr['id']}")["can"]["decide"] is True
    post(client, pm, f"/approvals/{req[0]['id']}/decide", {"decision": "approved"})
    lr = get(client, eng, f"/leave-requests/{lr['id']}")
    assert lr["status"] == "approved"
    assert get(client, pm, f"/leave-requests/{lr['id']}")["status"] == "approved"   # the line manager still sees it
    assert client.get(f"{API}/leave-requests/{lr['id']}", headers=as_user("sales1")).status_code == 403
    after = {b["code"]: b for b in lr["balances"]}["CL"]
    assert D(after["taken"]) == D(before["taken"]) + 2 and D(after["available"]) == D(before["available"]) - 2
    # attendance shows the days as leave
    month = d1.strftime("%Y-%m")
    days = {c["date"]: c["status"] for c in get(client, eng, "/hr/me/attendance", month=month)["rows"][0]["days"]}
    assert days[str(d1)] == "on_leave"
    # overlapping and over-quota requests are refused
    assert err(client, eng, "/leave-requests", {"leave_type_id": cl["id"], "from_date": str(d2), "to_date": str(d2),
                                                "reason": "again"})[1] == "LEAVE_OVERLAP"
    far = next_workday(date.today(), 40)
    code = err(client, eng, "/leave-requests", {"leave_type_id": cl["id"], "from_date": str(far),
                                                "to_date": str(far + timedelta(days=30)), "reason": "Long trip"})[1]
    assert code in ("INSUFFICIENT_LEAVE", "SPANS_YEARS")
    # the employee cancels the approved future leave; attendance is cleared
    post(client, eng, f"/leave-requests/{lr['id']}/cancel", {"reason": "Wedding postponed"})
    days = {c["date"]: c["status"] for c in get(client, eng, "/hr/me/attendance", month=month)["rows"][0]["days"]}
    assert days[str(d1)] is None


def test_line_manager_falls_back_to_manager_role_and_half_days(client, as_user):
    d = as_user("director")             # the director reports to nobody
    sl = leave_type(client, d, "SL")
    day = next_workday(date.today(), 2)
    lr = post(client, d, "/leave-requests", {"leave_type_id": sl["id"], "from_date": str(day), "to_date": str(day),
                                             "half_day": "second", "reason": "Doctor's appointment"})
    assert lr["days"] == "0.5" and lr["approval"]["steps"] == ["MANAGER"]
    assert any(x["entity_id"] == lr["id"] for x in get(client, as_user("manager"), "/approvals/inbox"))
    # a range made only of a Sunday has no working days
    sunday = date.today() + timedelta(days=(6 - date.today().weekday()) % 7 or 7)
    assert err(client, d, "/leave-requests", {"leave_type_id": sl["id"], "from_date": str(sunday),
                                              "to_date": str(sunday), "reason": "x x x"})[1] == "NO_WORKING_DAYS"


def test_profile_privacy_and_confidential_salary(client, as_user, owner_engine):
    hr = as_user("hr1")
    eng_id = get(client, as_user("engineer1"), "/hr/me")["employee"]["id"]
    # HR and the employee see personal and bank details; a colleague does not
    assert get(client, hr, f"/employees/{eng_id}/profile")["private"]["bank_account_number"] == "30211234567"
    assert get(client, as_user("engineer1"), f"/employees/{eng_id}/profile")["private"]["blood_group"] == "B+"
    assert get(client, as_user("sales1"), f"/employees/{eng_id}/profile")["private"] is None
    # salary: HR only
    recs = get(client, hr, f"/employees/{eng_id}/salary")
    assert recs and recs[0]["components"]["labour_day_rate"] == "1450.00"
    assert client.get(f"{API}/employees/{eng_id}/salary", headers=as_user("manager")).status_code == 403
    assert client.get(f"{API}/employees/{eng_id}/salary", headers=as_user("accounts1")).status_code == 403
    rec = post(client, hr, f"/employees/{eng_id}/salary", {"effective_from": "2026-10-01", "basic": "20000",
                                                           "hra": "8000", "employee_pf": "2400", "employer_pf": "2400",
                                                           "remarks": "Annual increment"})
    assert (rec["gross"], rec["net"], rec["ctc_monthly"]) == ("28000.00", "25600.00", "30400.00")
    # stored encrypted, and never written into the audit log
    with owner_engine.connect() as c:
        raw = c.execute(text("select components from salary_records where id = :i"), {"i": rec["id"]}).scalar()
        assert "20000" not in raw
        logs = " ".join(str(x) for x in c.execute(text("select summary, changes from audit_logs "
                                                       "where entity_id = :i"), {"i": eng_id}).all())
        assert "20000" not in logs
        pan_raw = c.execute(text("select bank_account_number from employees where id = :i"), {"i": eng_id}).scalar()
        assert pan_raw and "30211234567" not in pan_raw
    # HR updates private details; the employee can update their own contact details only
    prof = get(client, hr, f"/employees/{eng_id}/profile")
    r = client.put(f"{API}/employees/{eng_id}/private", headers=hr, json={
        **{k: v for k, v in prof["private"].items() if k not in ("pan", "bank_account_number")},
        "bank_account_number": "30219999999", "pan": "ABCPD1234E", "row_version": prof["row_version"]})
    assert r.status_code == 200, r.text
    assert client.put(f"{API}/employees/{eng_id}/private", headers=as_user("engineer1"),
                      json={"row_version": 1}).status_code == 403
    me = client.put(f"{API}/hr/me/profile", headers=as_user("engineer1"), json={"emergency_contact_phone": "9847000001"})
    assert me.status_code == 200 and me.json()["data"]["emergency_contact_phone"] == "9847000001"


def test_labour_cost_from_attendance_is_posted_once(client, as_user):
    from tests.test_projects import demo_project

    hr = as_user("hr1")
    prj = demo_project(client, as_user("pm1"))
    months = {date.today().strftime("%Y-%m"), (date.today().replace(day=1) - timedelta(days=1)).strftime("%Y-%m")}
    before = D(prj["financials"]["labour_cost"])
    total = D(0)
    for m in months:
        pv = get(client, hr, "/hr/labour-cost", month=m)
        row = next((r for r in pv["rows"] if r["project_id"] == prj["id"]), None)
        if row:
            total += D(row["amount"])
            post(client, hr, "/hr/labour-cost/post", {"month": m})
            post(client, hr, "/hr/labour-cost/post", {"month": m})   # posting again replaces, never doubles
    assert total > 0
    prj = demo_project(client, as_user("pm1"))
    assert D(prj["financials"]["labour_cost"]) == before + total
    assert client.get(f"{API}/hr/labour-cost", headers=as_user("accounts1"),
                      params={"month": "2026-10"}).status_code == 403


def test_employee_dashboard_and_holidays(client, as_user):
    h = as_user("employee1")
    me = get(client, h, "/hr/me")
    assert me["can"]["check_in"] and me["can"]["apply_leave"] and me["holidays"] is not None
    assert {b["code"] for b in me["balances"]} >= {"CL", "SL", "EL", "LOP"}
    assert client.get(f"{API}/attendance/register", headers=h, params={"month": "2026-10"}).json()["data"]["rows"][0][
        "name"] == "Vishnu Prasad"   # own row only
    s = get(client, as_user("hr1"), "/hr/summary")
    assert s["pending_leave"] >= 1 and "birthdays" in s
    assert client.get(f"{API}/hr/summary", headers=h).status_code == 403
