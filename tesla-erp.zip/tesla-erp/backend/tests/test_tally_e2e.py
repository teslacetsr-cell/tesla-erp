"""Phase 11 end to end: the real Windows connector (tally-connector/connector.py) and the mock TallyPrime
(tally-connector/mock_tally.py) against this ERP served over HTTP — issue an invoice and a receipt, let the connector
push them, check Tally got valid vouchers; then Tally down, a Tally line error, retry, and a reconciliation."""
import socket
import sys
import threading
import time
from decimal import Decimal as D
from pathlib import Path

import pytest

from tests.test_tally import API, get, jobs, post, service_invoice, setup_sync

ROOT = Path(__file__).resolve().parents[2] / "tally-connector"
sys.path.insert(0, str(ROOT))
connector = pytest.importorskip("connector")
mock_tally = pytest.importorskip("mock_tally")


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture
def erp_url():
    import uvicorn

    from app.main import app

    port = _free_port()

    class Server(uvicorn.Server):
        def install_signal_handlers(self):  # running in a thread
            pass

    srv = Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning", lifespan="off"))
    t = threading.Thread(target=srv.run, daemon=True)
    t.start()
    for _ in range(100):
        if srv.started:
            break
        time.sleep(0.05)
    assert srv.started
    yield f"http://127.0.0.1:{port}"
    srv.should_exit = True
    t.join(5)


@pytest.fixture
def tally():
    srv = mock_tally.make_server()
    t = threading.Thread(target=srv.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
    t.start()
    yield srv
    srv.shutdown()
    srv.server_close()


def make_connector(tmp_path, erp_url, key, tally_url):
    cfg = connector.Config(erp_url=erp_url, connector_key=key, tally_url=tally_url, timeout_seconds=5,
                           log_dir=tmp_path / "logs", outbox_file=tmp_path / "outbox.jsonl")
    connector.setup_logging(cfg.log_dir, key, console=False)
    return connector.Connector(cfg)


def drain(c, cycles=6):
    outcomes = []
    for _ in range(cycles):
        o = c.run_cycle()
        outcomes.append(o)
        if o.status != "ok" or o.jobs_leased == 0:
            break
    return outcomes


def test_connector_pushes_invoice_and_receipt_to_tally(client, as_user, erp_url, tally, tmp_path):
    acc = as_user("accounts1")
    setup_sync(client, acc)
    key = post(client, acc, "/tally/keys", {"name": "Accounts PC"})["key"]
    post(client, acc, "/tally/ledgers/push")   # the ERP's ledgers (Sales, GST, Bank …) into a fresh Tally company
    inv = service_invoice(client, as_user)
    rc = post(client, acc, "/receipts", {"customer_id": inv["customer_id"], "mode": "neft", "reference_no": "UTR77",
                                         "amount": "10000", "tds_amount": "200", "allocations": [
                                             {"document_id": inv["id"], "amount": "10000", "tds": "200"}]}, status=201)
    tally_url = f"http://127.0.0.1:{tally.server_port}"
    c = make_connector(tmp_path, erp_url, key, tally_url)
    out = drain(c)
    assert out[0].status == "ok" and out[0].jobs_leased == 4, [o.__dict__ for o in out]
    st = get(client, acc, "/tally/status")
    assert st["counts"]["done"] == 4 and st["counts"]["failed"] == 0 and st["counts"]["pending"] == 0
    assert st["connector"]["online"] and st["connector"]["tally_ok"] is True
    assert st["connector"]["tally_company"] == "Tesla Consulting Engineers" and st["connector"]["agent_version"]

    data = tally.state.snapshot()
    vouchers = {(v["type"], v["number"]): v for v in data["vouchers"]}
    sales = vouchers[("Sales", inv["invoice_number"])]
    receipt = vouchers[("Receipt", rc["receipt_number"])]
    assert sales["remote_id"] == f"erp-invoice-{inv['id']}" and sales["party"] == "Bengaluru Tech Park"
    assert sum(D(e["amount"]) for e in sales["entries"]) == 0
    assert {e["ledger"]: D(e["amount"]) for e in receipt["entries"]} == {
        "Bank Account": D("-10000.00"), "TDS Receivable": D("-200.00"), "Bengaluru Tech Park": D("10200.00")}
    party = data["ledgers"]["Bengaluru Tech Park"]
    assert party["parent"] == "Sundry Debtors" and party["state"] == "Karnataka"
    # Tally's party balance = invoice − receipt (debit, negative in Tally)
    assert D(party["closing"]) == -(D(inv["grand_total"]) - D("10200"))
    assert D(data["ledgers"]["TDS Receivable"]["closing"]) == D("-200.00")
    assert get(client, acc, "/tally/doc-status", entity_type="invoice", entity_id=inv["id"])["state"] == "in_tally"
    assert get(client, acc, "/tally/doc-status", entity_type="receipt", entity_id=rc["id"])["state"] == "in_tally"

    # the connector retrying the same voucher never duplicates it in Tally
    from app.core.db import SessionLocal
    from app.tally.models import TallyJob

    with SessionLocal() as s:
        j = s.query(TallyJob).filter(TallyJob.doc_number == inv["invoice_number"]).one()
        j.status = "pending"
        s.commit()
    drain(c)
    data = tally.state.snapshot()
    assert sum(1 for v in data["vouchers"] if v["number"] == inv["invoice_number"]) == 1
    assert get(client, acc, "/tally/status")["counts"]["done"] == 4

    # Tally down: the job stays in the queue with a plain error, nothing is lost
    inv2 = service_invoice(client, as_user, rate="5000", name="Calicut Mall")
    dead = make_connector(tmp_path, erp_url, key, f"http://127.0.0.1:{_free_port()}")
    o = dead.run_cycle()
    assert o.status == "error"
    st = get(client, acc, "/tally/status")
    assert st["connector"]["tally_ok"] is False and st["counts"]["pending"] == 2
    assert any("could not be reached" in (j["last_error"] or "") for j in jobs(client, acc, status="pending"))
    drain(c)
    assert get(client, acc, "/tally/doc-status", entity_type="invoice", entity_id=inv2["id"])["state"] == "in_tally"

    # Tally refuses a voucher (ledger missing): failed with Tally's own words; fix the mapping, Retry, done
    sales_row = [r for r in get(client, acc, "/tally/mapping")["accounts"] if r["erp_name"].startswith("Sales")][0]
    client.put(f"{API}/tally/mapping", headers=acc, json={"items": [
        {"kind": "account", "erp_key": sales_row["erp_key"], "tally_name": "Sales Works Contract"}]})
    inv3 = service_invoice(client, as_user, rate="7000", name="Thrissur Mills")
    drain(c)
    failed = jobs(client, acc, status="failed")
    assert len(failed) == 1 and failed[0]["last_error"] == "Tally: Ledger 'Sales Works Contract' does not exist!"
    assert get(client, acc, "/tally/doc-status", entity_type="invoice", entity_id=inv3["id"])["state"] == "failed"
    client.put(f"{API}/tally/mapping", headers=acc, json={"items": [
        {"kind": "account", "erp_key": sales_row["erp_key"], "tally_name": ""}]})
    assert post(client, acc, "/tally/jobs/retry-failed")["retried"] == 1
    drain(c)
    assert jobs(client, acc, status="failed") == []
    assert get(client, acc, "/tally/doc-status", entity_type="invoice", entity_id=inv3["id"])["state"] == "in_tally"

    # cancel the receipt in the ERP -> the Tally voucher is cancelled
    post(client, acc, f"/receipts/{rc['id']}/cancel", {"reason": "Cheque returned unpaid"})
    drain(c)
    data = tally.state.snapshot()
    assert [v for v in data["vouchers"] if v["number"] == rc["receipt_number"]][0]["cancelled"] is True
    assert D(data["ledgers"]["Bengaluru Tech Park"]["closing"]) == -D(inv["grand_total"])

    # reconciliation: the ERP and Tally agree for the parties pushed
    post(client, acc, "/tally/reconciliations")
    drain(c)
    rec = get(client, acc, "/tally/reconciliations/latest")
    assert rec["status"] == "done"
    rows = {r["erp_name"]: r for r in rec["rows"]}
    for name in ("Bengaluru Tech Park", "Calicut Mall", "Thrissur Mills"):
        assert rows[name]["status"] == "match", rows[name]
