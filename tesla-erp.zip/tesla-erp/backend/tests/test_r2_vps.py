"""VPS deployment: Cloudflare R2 storage settings and off-site backups."""
import io
from datetime import datetime
from zoneinfo import ZoneInfo

import pytest
from moto import mock_aws

from app.core.config import Settings, get_settings
from app.platform.documents import storage as storage_mod

IST = ZoneInfo("Asia/Kolkata")
PDF = b"%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n"
KEY = "k7yq8B0pFf3rJjZ2Vb6mV1XnVb2mQv8hT1rWqY3nKxQ="


def test_vps_production_settings_for_r2():
    base = dict(environment="production", deployment="cloud", storage_backend="s3", cookie_secure=True,
                storage_endpoint="https://abc123.r2.cloudflarestorage.com", storage_region="auto",
                storage_bucket="tce-erp-documents", secret_key="x" * 48, field_encryption_key=KEY)
    with pytest.raises(ValueError, match="STORAGE_SSE=false"):
        Settings(**base)  # R2 would reject every upload
    s = Settings(**base, storage_sse=False)
    assert s.storage_region == "auto"
    with pytest.raises(ValueError, match="COOKIE_SECURE"):
        Settings(**base | {"cookie_secure": False}, storage_sse=False)


@pytest.fixture
def s3(monkeypatch, tmp_path):
    with mock_aws():
        s = get_settings()
        for k, v in {"storage_backend": "s3", "storage_bucket": "docs", "storage_access_key": "a",
                     "storage_secret_key": "b", "storage_sse": False, "backup_bucket": "backups",
                     "status_file": str(tmp_path / "status.json"), "backup_keep_daily": 3,
                     "backup_keep_weekly": 2, "backup_keep_monthly": 2}.items():
            monkeypatch.setattr(s, k, v)
        st = storage_mod.S3Storage()
        for b in ("docs", "backups"):
            st.client.create_bucket(Bucket=b, CreateBucketConfiguration={"LocationConstraint": "ap-south-1"})
        storage_mod.set_storage(st)
        yield st
        storage_mod.set_storage(None)


def test_upload_without_sse_header(client, admin_headers, s3, monkeypatch):
    sent = {}
    real_put = s3.client.put_object

    def spy(**kw):
        sent.update(kw)
        return real_put(**kw)

    monkeypatch.setattr(s3.client, "put_object", spy)
    cid = client.get("/api/v1/customers", headers=admin_headers, params={"q": "ABC"}).json()["data"][0]["id"]
    r = client.post("/api/v1/documents", headers=admin_headers,
                    data={"entity_type": "customer", "entity_id": cid, "category": "drawing"},
                    files={"file": ("layout.pdf", io.BytesIO(PDF), "application/pdf")})
    assert r.status_code == 201, r.text
    assert "ServerSideEncryption" not in sent
    status = client.get("/api/v1/system/status", headers=admin_headers).json()["data"]
    assert status["storage"]["ok"] is True and status["storage"]["location"] == "docs"


def test_offsite_backup_rotation_checksum_and_status(s3, tmp_path):
    from app.ops import offsite

    for day in range(1, 8):  # 1 Mar 2026 is a Sunday and the 1st
        f = tmp_path / f"tce_erp_202603{day:02d}_0130.dump"
        f.write_bytes(b"PGDMP" + bytes([day]) * 100)
        offsite.upload(f, now=datetime(2026, 3, day, 1, 30, tzinfo=IST))
    keys = [r["key"] for r in offsite.listing()]
    assert [k for k in keys if k.startswith("daily/")] == [f"daily/tce_erp_202603{d:02d}_0130.dump" for d in (5, 6, 7)]
    assert "weekly/tce_erp_20260301_0130.dump" in keys and "monthly/tce_erp_20260301_0130.dump" in keys
    status = offsite.json.loads((tmp_path / "status.json").read_text())["backup"]
    assert status["ok"] is True and status["file"] == "backups/daily/tce_erp_20260307_0130.dump"

    out = offsite.download("monthly/tce_erp_20260301_0130.dump", tmp_path / "restore.dump")
    assert out.read_bytes() == b"PGDMP" + bytes([1]) * 100

    # A tampered object is refused on download
    s3.client.put_object(Bucket="backups", Key="daily/tce_erp_20260307_0130.dump", Body=b"corrupt",
                         Metadata={"sha256": "0" * 64})
    with pytest.raises(RuntimeError, match="checksum"):
        offsite.download("daily/tce_erp_20260307_0130.dump", tmp_path / "bad.dump")

    offsite.fail("pg_dump: connection refused")
    status = offsite.json.loads((tmp_path / "status.json").read_text())["backup"]
    assert status["ok"] is False and status["last_success"].startswith("2026-03-07")


def test_offsite_cli_reports_errors(s3, tmp_path, capsys):
    from app.ops import offsite

    assert offsite.main(["x", "upload", str(tmp_path / "missing.dump")]) == 1
    status = offsite.json.loads((tmp_path / "status.json").read_text())["backup"]
    assert status["ok"] is False and "upload failed" in status["error"]
    assert offsite.main(["x"]) == 2
