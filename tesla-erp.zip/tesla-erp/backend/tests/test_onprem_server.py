"""On-premise server package: config secrets, NAS paths, backup rotation and scheduling, setup wizard API."""
import json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import pytest
from fastapi.testclient import TestClient

IST = ZoneInfo("Asia/Kolkata")


@pytest.fixture
def tce_home(tmp_path, monkeypatch):
    monkeypatch.setenv("TCE_HOME", str(tmp_path / "home"))
    return tmp_path


def test_config_round_trip_protects_secrets(tce_home):
    from onprem.config import OnPremConfig, load, save

    cfg = OnPremConfig(nas_path=r"\\NAS\TCE-ERP", nas_password="nas-secret", pg_app_password="db-secret",
                       secret_key="k" * 48, configured=True)
    save(cfg)
    raw = (tce_home / "home" / "config.json").read_text()
    assert "nas-secret" not in raw and "db-secret" not in raw
    back = load()
    assert back.nas_password == "nas-secret" and back.configured is True
    assert back.documents_path == r"\\NAS\TCE-ERP\documents"
    assert back.backups_path == r"\\NAS\TCE-ERP\backups"
    env = back.app_environment()
    assert env["STORAGE_BACKEND"] == "filesystem" and env["DEPLOYMENT"] == "onprem"
    assert "127.0.0.1:5433/tesla_erp" in env["DATABASE_URL"] and "erp_app" in env["DATABASE_URL"]


def test_share_root():
    from onprem.nas import share_root

    assert share_root(r"\\NAS\TCE-ERP\documents") == r"\\NAS\TCE-ERP"
    assert share_root(r"\\192.168.1.20\erp") == r"\\192.168.1.20\erp"
    assert share_root(r"D:\ERP") is None


class FakePg:
    def __init__(self, fail=False):
        self.fail = fail

    def dump(self, target: Path):
        if self.fail:
            raise RuntimeError("pg_dump: connection refused")
        target.write_bytes(b"PGDMP fake archive")


def test_backup_rotation_and_status(tce_home):
    from onprem import backup
    from onprem.config import OnPremConfig

    cfg = OnPremConfig(nas_path=str(tce_home / "nas"), keep_daily=3, keep_weekly=2, keep_monthly=2)
    # 1 Mar 2026 is a Sunday: gets daily + weekly + monthly copies
    for day in range(1, 8):
        backup.run_backup(cfg, FakePg(), now=datetime(2026, 3, day, 1, 0, tzinfo=IST))
    root = tce_home / "nas" / "backups"
    assert len(list((root / "daily").glob("*.dump"))) == 3
    assert [p.name for p in (root / "weekly").glob("*.dump")] == ["tce_erp_20260301_0100.dump"]
    assert [p.name for p in (root / "monthly").glob("*.dump")] == ["tce_erp_20260301_0100.dump"]
    assert all(Path(str(p) + ".sha256").exists() for p in (root / "daily").glob("*.dump"))
    st = backup.read_status()["backup"]
    assert st["ok"] is True and st["file"].endswith("tce_erp_20260307_0100.dump")
    with pytest.raises(RuntimeError):
        backup.run_backup(cfg, FakePg(fail=True), now=datetime(2026, 3, 8, 1, 0, tzinfo=IST))
    st = backup.read_status()["backup"]
    assert st["ok"] is False and "connection refused" in st["error"]
    assert st["last_success"].startswith("2026-03-07")  # the last good backup is still known


def test_backup_due(tce_home):
    from onprem import backup
    from onprem.config import OnPremConfig

    cfg = OnPremConfig(backup_time="01:00")
    assert backup.due(cfg, datetime(2026, 3, 7, 12, 0, tzinfo=IST)) is True  # never backed up
    backup.update_status("backup", {"last_success": datetime(2026, 3, 7, 1, 0, tzinfo=IST).isoformat()})
    assert backup.due(cfg, datetime(2026, 3, 7, 18, 0, tzinfo=IST)) is False
    assert backup.due(cfg, datetime(2026, 3, 8, 0, 59, tzinfo=IST)) is False
    assert backup.due(cfg, datetime(2026, 3, 8, 1, 0, tzinfo=IST)) is True
    assert backup.due(cfg, datetime(2026, 3, 9, 12, 0, tzinfo=IST)) is True  # missed a night -> catch up


def test_setup_wizard_validates_before_touching_anything(tce_home):
    from onprem.config import OnPremConfig
    from onprem.setup_app import create_setup_app

    app = create_setup_app(OnPremConfig(), on_finished=lambda: None)
    with TestClient(app) as c:
        assert "TCE ERP — Server setup" in c.get("/setup").text
        ok = c.post("/setup/api/check-nas", json={"nas_path": str(tce_home / "nas")}).json()
        assert ok["ok"] is True
        blocked = tce_home / "file"
        blocked.write_text("x")
        bad = c.post("/setup/api/check-nas", json={"nas_path": str(blocked)}).json()
        assert bad["ok"] is False
        weak = c.post("/setup/api/complete", json={
            "company_name": "TCE", "nas_path": str(tce_home / "nas"), "admin_email": "a@b.in",
            "admin_password": "aaaaaaaaaaaa"})
        assert weak.status_code == 422 and "repetitive" in weak.json()["error"]
        assert c.get("/setup/api/progress").json()["running"] is False
    assert not (tce_home / "home" / "config.json").exists()


def test_status_file_is_valid_json(tce_home):
    from onprem import backup, paths

    backup.update_status("tunnel", {"state": "running"})
    backup.update_status("tunnel", {"detail": None})
    assert json.loads(paths.status_file().read_text())["tunnel"] == {"state": "running", "detail": None}
