"""Quotation / GST calculation (Spec §45: "Quotation calculation", "GST calculation"). Pure unit tests."""
from decimal import Decimal as D

import pytest

from app.core.gst import CalcError, LineIn, amount_in_words, calculate, is_inter_state


def test_intra_state_splits_cgst_sgst():
    outs, t = calculate([LineIn(D("2"), D("14200"), D("0"), D("18"))], inter_state=False)
    assert outs[0].amount == D("28400.00")
    assert (t.cgst, t.sgst, t.igst) == (D("2556.00"), D("2556.00"), D("0"))
    assert t.grand_total == D("33512") and t.round_off == D("0")


def test_inter_state_uses_igst():
    _, t = calculate([LineIn(D("2"), D("14200"), D("0"), D("18"))], inter_state=True)
    assert (t.cgst, t.sgst, t.igst) == (D("0"), D("0"), D("5112.00"))
    assert t.grand_total == D("33512")


def test_line_discount_then_tax_and_round_off():
    # 3 × 1,850 = 5,550; 7.5 % off = 416.25 → 5,133.75; 18 % → 924.075 → CGST/SGST 462.04 each (half rate 9 %)
    outs, t = calculate([LineIn(D("3"), D("1850"), D("7.5"), D("18"))], inter_state=False)
    o = outs[0]
    assert (o.amount, o.discount_amount, o.taxable) == (D("5550.00"), D("416.25"), D("5133.75"))
    assert (o.cgst, o.sgst) == (D("462.04"), D("462.04"))
    assert t.total_before_round == D("6057.83")
    assert t.grand_total == D("6058") and t.round_off == D("0.17")


def test_five_percent_gst_half_rates():
    _, t = calculate([LineIn(D("1"), D("1000"), D("0"), D("5"))], inter_state=False)
    assert (t.cgst, t.sgst) == (D("25.00"), D("25.00"))


def test_special_discount_allocated_pro_rata_and_adds_up():
    lines = [LineIn(D("1"), D("100000"), D("0"), D("18")), LineIn(D("1"), D("50000"), D("0"), D("12")),
             LineIn(D("3"), D("333.33"), D("0"), D("18"))]
    outs, t = calculate(lines, inter_state=False, special_discount=D("10000"))
    assert sum(o.special_discount for o in outs) == D("10000.00")
    assert t.taxable == t.gross - D("10000")
    # tax is on the value AFTER the special discount, at each line's own rate
    assert t.tax_summary[0]["rate"] == D("12") and t.tax_summary[1]["rate"] == D("18")
    assert t.cgst == sum(o.cgst for o in outs)


def test_mixed_rates_summary_and_zero_rated():
    lines = [LineIn(D("10"), D("620"), D("0"), D("18")), LineIn(D("1"), D("5000"), D("0"), D("0"))]
    _, t = calculate(lines, inter_state=True)
    assert [r["rate"] for r in t.tax_summary] == [D("0"), D("18")]
    assert t.igst == D("1116.00") and t.grand_total == D("12316")


def test_rounding_half_up_to_rupee():
    _, t = calculate([LineIn(D("1"), D("100.50"), D("0"), D("0"))], inter_state=False)
    assert t.grand_total == D("101") and t.round_off == D("0.50")
    _, t = calculate([LineIn(D("1"), D("100.49"), D("0"), D("0"))], inter_state=False)
    assert t.grand_total == D("100") and t.round_off == D("-0.49")


@pytest.mark.parametrize("line,special,msg", [
    (LineIn(D("-1"), D("10")), D("0"), "negative"),
    (LineIn(D("1"), D("10"), D("101")), D("0"), "between 0 and 100"),
    (LineIn(D("1"), D("10")), D("11"), "cannot be more"),
])
def test_invalid_input(line, special, msg):
    with pytest.raises(CalcError, match=msg):
        calculate([line], inter_state=False, special_discount=special)


def test_place_of_supply():
    assert is_inter_state("32", "29") is True
    assert is_inter_state("32", "32") is False
    assert is_inter_state("32", None) is False


@pytest.mark.parametrize("value,words", [
    (D("550000"), "Rupees Five Lakh Fifty Thousand Only"),
    (D("33512"), "Rupees Thirty Three Thousand Five Hundred Twelve Only"),
    (D("12500000.50"), "Rupees One Crore Twenty Five Lakh and Fifty Paise Only"),
    (D("101"), "Rupees One Hundred One Only"),
    (D("0"), "Rupees Zero Only"),
    (D("999999999"), "Rupees Ninety Nine Crore Ninety Nine Lakh Ninety Nine Thousand Nine Hundred Ninety Nine Only"),
])
def test_amount_in_words(value, words):
    assert amount_in_words(value) == words
