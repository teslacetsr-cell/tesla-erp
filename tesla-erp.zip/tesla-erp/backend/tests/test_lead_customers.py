"""New customer details entered on a lead are saved as a customer at once (CUS code, prospect, source "lead")."""
import re

from sqlalchemy import func, select

from app.core.india import gstin_check_char

API = "/api/v1"
GSTIN_MALABAR = "32AABCM1234F1Z" + gstin_check_char("32AABCM1234F1Z")
GSTIN_PERIYAR = "32AAACP7777K1Z" + gstin_check_char("32AAACP7777K1Z")


def lead_body(**kw) -> dict:
    return {"title": "Rooftop solar for warehouse", "company_name": "Periyar Cold Storage", "contact_name": "Mr. Biju",
            "contact_phone": "98950 44556", "contact_email": "biju@periyar-demo.in", "city": "Aluva",
            "address_line1": "NH 544, Companypady", "state_code": "32", "pincode": "683106",
            "source": "phone"} | kw


def customer(client, h, cid) -> dict:
    r = client.get(f"{API}/customers/{cid}", headers=h)
    assert r.status_code == 200, r.text
    return r.json()["data"]


def count_customers(client, h) -> int:
    return client.get(f"{API}/customers", headers=h, params={"page_size": 1}).json()["meta"]["total"]


def test_lead_with_new_customer_creates_prospect_customer(client, as_user):
    h = as_user("sales1")
    before = count_customers(client, h)
    r = client.post(f"{API}/leads", headers=h, json=lead_body())
    assert r.status_code == 201, r.text
    lead = r.json()["data"]
    assert lead["customer_action"] == "created"
    assert re.fullmatch(r"CUS\d{5}", lead["customer"]["code"])
    assert lead["customer"]["is_prospect"] is True
    assert lead["company_name"] == "Periyar Cold Storage"  # the lead keeps what was entered
    c = customer(client, h, lead["customer_id"])
    assert c["customer_name"] == "Periyar Cold Storage" and c["customer_type"] == "company"
    assert c["is_prospect"] is True and c["source"] == "lead" and c["status"] == "active"
    assert c["phone"] == "98950 44556" and c["email"] == "biju@periyar-demo.in"
    assert (c["address_line1"], c["city"], c["state"], c["state_code"], c["pincode"]) == (
        "NH 544, Companypady", "Aluva", "Kerala", "32", "683106")
    assert [(x["name"], x["is_primary"]) for x in c["contacts"]] == [("Mr. Biju", True)]
    assert c["can_edit"] is True  # the salesperson owns it (assigned to them)
    assert count_customers(client, h) == before + 1
    # findable everywhere customers are listed (pickers ask for active customers)
    hits = client.get(f"{API}/customers", headers=as_user("manager"),
                      params={"q": "Periyar", "status": "active"}).json()["data"]
    assert [x["customer_code"] for x in hits] == [c["customer_code"]] and hits[0]["is_prospect"] is True
    prospects = client.get(f"{API}/customers", headers=h, params={"prospect": "true", "page_size": 200}).json()["data"]
    assert c["id"] in {x["id"] for x in prospects}
    regular = client.get(f"{API}/customers", headers=h, params={"prospect": "false", "page_size": 200}).json()["data"]
    assert c["id"] not in {x["id"] for x in regular}


def test_same_gstin_links_existing_customer(client, as_user):
    h = as_user("sales1")
    hm = as_user("manager")
    r = client.post(f"{API}/customers", headers=hm, json={"customer_name": "Malabar Cements Ltd",
                                                          "gstin": GSTIN_MALABAR, "phone": "0491 2555000"})
    assert r.status_code == 201, r.text
    existing = r.json()["data"]
    before = count_customers(client, h)
    r = client.post(f"{API}/leads", headers=h, json=lead_body(company_name="Malabar Cements (Walayar plant)",
                                                              contact_phone="94470 99887", gstin=GSTIN_MALABAR))
    assert r.status_code == 201, r.text
    lead = r.json()["data"]
    assert lead["customer_action"] == "linked" and lead["customer_id"] == existing["id"]
    assert count_customers(client, h) == before


def test_lookalike_warns_then_link_or_create_anyway(client, as_user):
    h = as_user("sales2")
    first = client.post(f"{API}/leads", headers=h, json=lead_body()).json()["data"]
    before = count_customers(client, h)
    body = lead_body(title="Earthing for second warehouse", contact_name="Ms. Anu")
    r = client.post(f"{API}/leads", headers=h, json=body)
    assert r.status_code == 409 and r.json()["error"]["code"] == "POSSIBLE_DUPLICATE_CUSTOMER"
    cand = r.json()["error"]["details"]["candidates"]
    assert cand[0]["id"] == first["customer_id"] and cand[0]["customer_code"] == first["customer"]["code"]
    assert count_customers(client, h) == before  # nothing saved
    # option 1: link to the existing one
    r = client.post(f"{API}/leads", headers=h, json=body | {"customer_id": cand[0]["id"]})
    assert r.status_code == 201 and r.json()["data"]["customer_id"] == first["customer_id"]
    # option 2: create anyway
    r = client.post(f"{API}/leads", headers=h, params={"allow_duplicate": "true"}, json=body)
    assert r.status_code == 201, r.text
    assert r.json()["data"]["customer_id"] != first["customer_id"] and r.json()["data"]["customer_action"] == "created"
    assert count_customers(client, h) == before + 1


def test_edit_lead_updates_its_prospect_customer_without_duplicating(client, as_user):
    h = as_user("sales1")
    lead = client.post(f"{API}/leads", headers=h, json=lead_body()).json()["data"]
    cid = lead["customer_id"]
    before = count_customers(client, h)
    upd = lead_body(title="Rooftop solar — 100 kW", company_name="Periyar Cold Storage Pvt Ltd",
                    contact_phone="98950 44557", city="Aluva") | {"row_version": lead["row_version"]}
    r = client.put(f"{API}/leads/{lead['id']}", headers=h, json=upd)
    assert r.status_code == 200, r.text
    out = r.json()["data"]
    assert out["customer_id"] == cid and out["customer_action"] == "updated"
    c = customer(client, h, cid)
    assert c["customer_name"] == "Periyar Cold Storage Pvt Ltd" and c["phone"] == "98950 44557"
    assert c["is_prospect"] is True and len(c["contacts"]) == 1
    assert count_customers(client, h) == before
    # completing the GSTIN on the lead upgrades the prospect to a regular customer
    upd = upd | {"gstin": GSTIN_PERIYAR, "row_version": out["row_version"]}
    out = client.put(f"{API}/leads/{lead['id']}", headers=h, json=upd).json()["data"]
    c = customer(client, h, cid)
    assert out["customer_id"] == cid and c["gstin"] == GSTIN_PERIYAR and c["pan"] == "AAACP7777K"
    assert c["is_prospect"] is False
    assert count_customers(client, h) == before


def test_prospect_upgraded_on_customer_page(client, as_user):
    h = as_user("sales1")
    lead = client.post(f"{API}/leads", headers=h, json=lead_body()).json()["data"]
    c = customer(client, h, lead["customer_id"])
    keep = {k: c[k] for k in ("customer_name", "customer_type", "phone", "email", "city", "state_code", "pincode",
                              "address_line1", "status", "assigned_sales_person_id")}
    # an edit without GSTIN keeps it a prospect
    r = client.put(f"{API}/customers/{c['id']}", headers=h, json=keep | {"row_version": c["row_version"]})
    assert r.status_code == 200 and r.json()["data"]["is_prospect"] is True
    r = client.put(f"{API}/customers/{c['id']}", headers=h,
                   json=keep | {"gstin": GSTIN_PERIYAR, "row_version": r.json()["data"]["row_version"]})
    assert r.status_code == 200, r.text
    assert r.json()["data"]["is_prospect"] is False
    # or the user can mark it regular without a GSTIN (unregistered customer)
    lead2 = client.post(f"{API}/leads", headers=h, params={"allow_duplicate": "true"},
                        json=lead_body(company_name=None, contact_name="Thomas Kurian", contact_phone="94000 12121")).json()["data"]
    c2 = customer(client, h, lead2["customer_id"])
    assert c2["customer_type"] == "individual" and c2["is_prospect"] is True
    r = client.put(f"{API}/customers/{c2['id']}", headers=h, json={
        "customer_name": c2["customer_name"], "customer_type": "individual", "phone": c2["phone"],
        "is_prospect": False, "assigned_sales_person_id": c2["assigned_sales_person_id"],
        "row_version": c2["row_version"]})
    assert r.status_code == 200 and r.json()["data"]["is_prospect"] is False


def test_convert_keeps_the_leads_customer(client, as_user):
    h = as_user("sales1")
    lead = client.post(f"{API}/leads", headers=h, json=lead_body()).json()["data"]
    before = count_customers(client, h)
    r = client.post(f"{API}/leads/{lead['id']}/convert", headers=h, json={})
    assert r.status_code == 201, r.text
    assert r.json()["data"]["customer_id"] == lead["customer_id"]
    assert count_customers(client, h) == before
    # the lead now has an enquiry: its customer cannot be switched to another one
    got = client.get(f"{API}/leads/{lead['id']}", headers=h).json()["data"]
    abc = client.get(f"{API}/customers", headers=h, params={"q": "ABC Hospital"}).json()["data"][0]
    r = client.put(f"{API}/leads/{lead['id']}", headers=h, json=lead_body() | {
        "customer_id": abc["id"], "row_version": got["row_version"]})
    assert r.status_code == 400 and r.json()["error"]["code"] == "CUSTOMER_LOCKED"
    # editing the prospect details keeps the same customer
    r = client.put(f"{API}/leads/{lead['id']}", headers=h, json=lead_body(city="Kalamassery") | {
        "row_version": got["row_version"]})
    assert r.status_code == 200 and r.json()["data"]["customer_id"] == lead["customer_id"]
    assert customer(client, h, lead["customer_id"])["city"] == "Kalamassery"


def test_user_without_customer_create_must_pick_existing(client, as_user, admin_headers):
    # give PM a lead.create grant only (no customer.create): a new-customer lead is refused in plain words
    from app.core.db import SessionLocal
    from app.users.models import Permission, Role, RolePermission

    with SessionLocal() as s:
        role = s.scalar(select(Role).where(Role.code == "PROJECT_MANAGER"))
        perm = s.scalar(select(Permission).where(Permission.code == "lead.create"))
        s.add(RolePermission(role_id=role.id, permission_id=perm.id, scope="all"))
        s.commit()
    h = as_user("pm1")
    r = client.post(f"{API}/leads", headers=h, json=lead_body())
    assert r.status_code == 403 and r.json()["error"]["code"] == "CUSTOMER_REQUIRED"


def test_backfill_open_prospect_leads_is_idempotent(client, as_user, owner_engine):
    from app.core.db import SessionLocal
    from app.crm.models import Lead
    from app.crm.service import backfill_prospect_customers
    from app.customers.models import Customer
    from app.seed import seed_core

    with SessionLocal() as s:
        # demo prospects were linked when the demo data was loaded
        open_unlinked = s.scalar(select(func.count()).select_from(Lead).where(
            Lead.customer_id.is_(None), Lead.company_name.is_not(None), Lead.status.not_in(("won", "lost"))))
        assert open_unlinked == 0
        sobha = s.scalar(select(Lead).where(Lead.company_name == "Sobha City Mall"))
        sobha_cust = s.get(Customer, sobha.customer_id)
        assert sobha_cust.is_prospect and sobha_cust.source == "lead" and sobha_cust.customer_code.startswith("CUS")
        assert s.scalar(select(Lead).where(Lead.company_name == "Kairali Textiles")).customer_id is None  # lost lead
        # simulate leads saved before this change: unlink two leads and remove one of the customers
        lone = Lead(lead_number="TCE/LEAD/OLD/0001", title="Old prospect", company_name="Kochi Metro Depot",
                    contact_name="Mr. Ravi", contact_phone="0484 2000111", city="Muttom", source="phone",
                    status="contacted", sales_person_id=sobha.sales_person_id)
        dup_of_sobha = Lead(lead_number="TCE/LEAD/OLD/0002", title="Old prospect 2", company_name="sobha city mall",
                            contact_phone="0487-2440000", source="phone", status="new")
        s.add_all([lone, dup_of_sobha])
        s.commit()
        total = s.scalar(select(func.count()).select_from(Customer))
        company = seed_core(s)  # the deploy-time backfill
        s.commit()
        assert s.scalar(select(func.count()).select_from(Customer)) == total + 1  # only Kochi Metro Depot is new
        s.refresh(lone)
        s.refresh(dup_of_sobha)
        assert dup_of_sobha.customer_id == sobha_cust.id  # exact name + phone → linked, not duplicated
        new = s.get(Customer, lone.customer_id)
        assert new.customer_name == "Kochi Metro Depot" and new.is_prospect and new.contacts[0].name == "Mr. Ravi"
        # running again changes nothing
        assert backfill_prospect_customers(s, company.id, None) == {"linked": 0, "created": 0}
        seed_core(s)
        s.commit()
        assert s.scalar(select(func.count()).select_from(Customer)) == total + 1
    # the backfilled customer shows on the lead with its code
    lead = client.get(f"{API}/leads", headers=as_user("manager"), params={"q": "Kochi Metro"}).json()["data"][0]
    assert lead["customer"]["code"] == new.customer_code and lead["customer"]["is_prospect"] is True


def test_legacy_unlinked_lead_still_converts(client, as_user):
    """A lead saved before this change without a customer (e.g. no company name) still converts as before."""
    from app.core.db import SessionLocal
    from app.crm.models import Lead
    from app.users.models import User

    with SessionLocal() as s:
        s1 = s.scalar(select(User).where(User.username == "sales1"))
        lead = Lead(lead_number="TCE/LEAD/OLD/0003", title="Home earthing", contact_name="Mrs. Leela Menon",
                    contact_phone="94461 30303", source="phone", status="new", sales_person_id=s1.id,
                    created_by=s1.id, updated_by=s1.id)
        s.add(lead)
        s.commit()
        lead_id = str(lead.id)
    h = as_user("sales1")
    r = client.post(f"{API}/leads/{lead_id}/convert", headers=h, json={})
    assert r.status_code == 201, r.text
    c = customer(client, h, r.json()["data"]["customer_id"])
    assert c["customer_name"] == "Mrs. Leela Menon" and c["source"] == "lead" and c["is_prospect"] is True
