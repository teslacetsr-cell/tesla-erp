"""Phase 10: the Director / Manager dashboard — one aggregated call whose figures reconcile with the reports and the
ledgers, permission-limited, and under 2 seconds on production-sized data (plan exit criterion)."""
import time
from datetime import date
from decimal import Decimal as D

from sqlalchemy import text

from tests.test_finance import get
from tests.test_reports import _books, run

API = "/api/v1"


def fy(t: date) -> tuple[str, str]:
    start = date(t.year if t.month >= 4 else t.year - 1, 4, 1)
    return start.isoformat(), date(start.year + 1, 3, 31).isoformat()


def test_director_dashboard_reconciles_with_reports_and_ledgers(client, as_user, owner_engine):
    from app.crm.service import today

    _books(client, as_user)
    d = as_user("director")
    dash = get(client, d, "/dashboard/director")
    start, end = fy(today())
    assert dash["fy"]["start"] == start and len(dash["months"]) == 12 and dash["months"][0]["short"] == "Apr"
    # billing and collections by month = the Billing vs collections report for the financial year
    bvc = run(client, d, "billing_vs_collections", date_from=start, date_to=end)
    assert D(dash["totals"]["billed"]) == D(bvc["totals"]["billed"]) > 0
    assert D(dash["totals"]["billed_gross"]) == D(bvc["totals"]["billed_gross"])
    assert D(dash["totals"]["collected"]) == D(bvc["totals"]["collected"]) > 0
    by_month = {r["month"]: r for r in bvc["rows"]}
    for m in dash["months"]:
        if m["month"] in by_month:
            assert D(m["billed"]) == D(by_month[m["month"]]["billed"])
            assert D(m["collected"]) == D(by_month[m["month"]]["collected"])
        else:
            assert D(m["billed"]) == 0 and D(m["collected"]) == 0
    # receivables = the Receivables ageing report = the debtors ledger
    rec = run(client, d, "receivables_ageing")
    for k in ("not_due", "d0_30", "d31_60", "d61_90", "d90", "outstanding", "advance", "net"):
        assert D(dash["receivables"][k]) == D(rec["totals"][k]), k
    tb = get(client, as_user("accounts1"), "/finance/trial-balance")
    debtors = sum(D(r["debit"]) - D(r["credit"]) for r in tb["rows"] if r["group"] == "Sundry Debtors")
    assert D(dash["receivables"]["net"]) == debtors
    assert D(dash["payables"]["net"]) == D(run(client, d, "payables_ageing")["totals"]["net"])
    # cash position = the bank and cash ledgers
    with owner_engine.connect() as c:
        bank = c.execute(text("""select coalesce(sum(l.debit - l.credit), 0) from journal_lines l
                                 join ledger_accounts a on a.id = l.account_id where a.system_key = 'bank'""")).scalar()
        orders = c.execute(text("select count(*), coalesce(sum(taxable), 0) from sales_orders "
                                "where status <> 'cancelled' and so_date between :a and :b"), {"a": start, "b": end}).one()
        pending = c.execute(text("select count(*) from approval_requests where status = 'pending'")).scalar()
    assert D(dash["cash"]["bank"]) == bank and D(dash["cash"]["total"]) == D(dash["cash"]["bank"]) + D(dash["cash"]["cash"])
    # funnel: orders this financial year
    stages = {s["stage"]: s for s in dash["funnel"]}
    assert [s["stage"] for s in dash["funnel"]] == ["leads", "enquiries", "quotations", "orders"]
    assert stages["orders"]["count"] == orders[0] and D(stages["orders"]["value"]) == orders[1]
    assert D(dash["totals"]["order_intake"]) == orders[1]
    assert stages["leads"]["count"] > 0 and stages["quotations"]["count"] > 0
    # top projects: margin as on Projects → Profitability
    assert dash["top_projects"] and len(dash["top_projects"]) <= 10
    values = [D(x["contract_value"]) for x in dash["top_projects"]]
    assert values == sorted(values, reverse=True)
    top = dash["top_projects"][0]
    prof = get(client, d, f"/projects/{top['id']}/profitability")
    assert top["billed"] == prof["actual"]["revenue"] and top["margin_pct"] == prof["actual"]["margin_pct"]
    assert dash["approvals"]["total"] == pending and dash["approvals"]["mine"] >= 0


def test_dashboard_permissions(client, as_user, admin_headers):
    assert client.get(f"{API}/dashboard/director", headers=as_user("manager")).status_code == 200
    assert client.get(f"{API}/dashboard/director", headers=admin_headers).status_code == 200
    for u in ("sales1", "accounts1", "store1", "employee1", "pm1"):
        assert client.get(f"{API}/dashboard/director", headers=as_user(u)).status_code == 403, u


def _copy(c, table: str, source_sql: str, n: int, overrides: dict) -> None:
    """Insert n copies of one row, replacing the columns in `overrides` (SQL expressions using g = 1..n)."""
    cols = [r[0] for r in c.execute(text("select column_name from information_schema.columns where table_name = :t "
                                         "and table_schema = 'public' order by ordinal_position"), {"t": table})]
    sel = ", ".join(overrides.get(col, f"src.{col}") for col in cols)
    c.execute(text(f"insert into {table} ({', '.join(cols)}) select {sel} from ({source_sql}) src, "  # noqa: S608
                   f"generate_series(1, {n}) g"))


def test_director_dashboard_under_two_seconds_on_production_sized_data(client, as_user, owner_engine):
    from app.crm.service import today

    _books(client, as_user)
    start, _ = fy(today())
    days = max((today() - date.fromisoformat(start)).days, 1)
    with owner_engine.begin() as c:
        # 5,000 issued invoices spread over the year, half unpaid; 5,000 receipts; 1,000 orders; 300 open projects
        _copy(c, "invoices", "select * from invoices where status = 'issued' limit 1", 5000, {
            "id": "gen_random_uuid()", "invoice_number": "'LOAD/INV/' || g", "irn": "null",
            "invoice_date": f"date '{start}' + (g % {days})", "due_date": f"date '{start}' + (g % {days}) + 30",
            "received": "case when g % 2 = 0 then src.grand_total else 0 end", "credited": "0", "tds": "0",
            "payment_status": "case when g % 2 = 0 then 'paid' else 'unpaid' end"})
        _copy(c, "receipts", "select * from receipts where status = 'posted' limit 1", 5000, {
            "id": "gen_random_uuid()", "receipt_number": "'LOAD/RC/' || g", "allocated": "src.amount + src.tds_amount",
            "receipt_date": f"date '{start}' + (g % {days})"})
        _copy(c, "sales_orders", "select * from sales_orders limit 1", 1000, {
            "id": "gen_random_uuid()", "so_number": "'LOAD/SO/' || g", "quotation_id": "null",
            "so_date": f"date '{start}' + (g % {days})"})
        _copy(c, "projects", "select * from projects limit 1", 300, {
            "id": "gen_random_uuid()", "project_number": "'LOAD/PRJ/' || g", "sales_order_id": "null",
            "contract_value": "src.contract_value + g", "status": "'active'"})
        _copy(c, "leads", "select * from leads limit 1", 3000, {
            "id": "gen_random_uuid()", "lead_number": "'LOAD/LD/' || g"})
        for t in ("invoices", "receipts", "sales_orders", "projects", "leads"):
            c.execute(text(f"analyze {t}"))
        n_inv = c.execute(text("select count(*) from invoices")).scalar()
    assert n_inv >= 5000
    d = as_user("director")
    get(client, d, "/dashboard/director")                 # warm up (first request loads code paths)
    started = time.perf_counter()
    dash = get(client, d, "/dashboard/director")
    elapsed = time.perf_counter() - started
    print(f"director dashboard: {elapsed:.3f}s with {n_inv} invoices")
    assert elapsed < 2.0, f"director dashboard took {elapsed:.2f}s"
    assert {s["stage"]: s for s in dash["funnel"]}["orders"]["count"] >= 1000
    assert D(dash["receivables"]["outstanding"]) > 0 and len(dash["top_projects"]) == 10
    # still reconciles at this size
    rec = run(client, d, "receivables_ageing")
    assert D(dash["receivables"]["net"]) == D(rec["totals"]["net"])
