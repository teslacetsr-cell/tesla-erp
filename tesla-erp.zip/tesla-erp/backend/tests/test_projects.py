"""Phase 4: sales orders from accepted quotations, projects, BOQ tracking, installation, tasks (Spec §15–§18)."""
from datetime import timedelta

from app.crm.service import today as ist_today
from tests.test_quotations import API, abc, act, line, new_quote

FIELDS = ("line_no", "section", "item_id", "description", "technical_specification", "hsn_sac", "quantity", "unit",
          "rate", "discount_pct", "tax_rate", "amount", "discount_amount", "taxable", "cgst", "sgst", "igst", "total",
          "remarks")
TOTALS = ("gross", "line_discount", "special_discount", "taxable", "cgst", "sgst", "igst", "round_off", "grand_total")


def accepted_quote(client, h, lines=None, **kw) -> dict:
    lines = lines or [
        line(section="Surge protection", remarks="Main LT panel"),
        line(section="Earthing", description="Chemical earth electrode 3 m", quantity="7", unit="NOS", rate="8350.50",
             discount_pct="7.5", tax_rate="18", technical_specification="Copper bonded, 17.2 mm"),
        line(section="Installation", description="Installation and testing", quantity="1", unit="JOB", rate="45999",
             tax_rate="18", hsn_sac="998719"),
    ]
    q = new_quote(client, h, lines, special_discount="1234.56", **kw)
    for a in ("submit", "send", "accept"):
        q = act(client, h, q, a)
    return q


def make_so(client, h, q, **body) -> dict:
    r = client.post(f"{API}/quotations/{q['id']}/sales-order", headers=h,
                    json={"customer_po_number": "PO-778", "customer_po_date": "2026-09-20"} | body)
    assert r.status_code == 201, r.text
    return r.json()["data"]


def demo_project(client, h) -> dict:
    rows = client.get(f"{API}/projects", headers=h, params={"q": "ABC Hospital Lightning"}).json()["data"]
    return client.get(f"{API}/projects/{rows[0]['id']}", headers=h).json()["data"]


# ------------------------------------------------------------------ Quotation → SO → Project (exact carry-over)
def test_quotation_to_sales_order_to_project_carries_every_value(client, as_user):
    h = as_user("sales1")
    q = accepted_quote(client, h)
    rev = client.get(f"{API}/quotations/{q['id']}", headers=h).json()["data"]["current"]
    assert q["can"]["create_sales_order"] is True
    so = make_so(client, h, q)
    assert so["status"] == "confirmed" and so["so_number"].startswith("TCE/SO/")
    assert so["quotation_number"] == q["quotation_number"]
    assert [{k: i[k] for k in FIELDS} for i in so["items"]] == [{k: i[k] for k in FIELDS} for i in rev["items"]]
    for k in TOTALS:
        assert so[k] == rev[k], k
    assert so["payment_terms"] == rev["payment_terms"] and so["terms"] == rev["terms"]
    assert so["customer_snapshot"]["name"]
    # one order per quotation; the quotation now links to it
    r = client.post(f"{API}/quotations/{q['id']}/sales-order", headers=h, json={})
    assert r.status_code == 409 and r.json()["error"]["code"] == "SO_EXISTS"
    qd = client.get(f"{API}/quotations/{q['id']}", headers=h).json()["data"]
    assert qd["sales_order"]["so_number"] == so["so_number"] and qd["can"]["create_sales_order"] is False

    # project from the order (project manager)
    pm = as_user("pm1")
    pm_id = client.get(f"{API}/auth/me", headers=pm).json()["data"]["id"]
    r = client.post(f"{API}/projects", headers=pm, json={"sales_order_id": so["id"], "name": "SPD retrofit",
                                                         "project_manager_id": pm_id})
    assert r.status_code == 201, r.text
    prj = r.json()["data"]
    assert prj["contract_value"] == so["taxable"] and prj["customer_id"] == so["customer_id"]
    assert prj["project_number"].startswith("TCE/PRJ/") and prj["so_number"] == so["so_number"]
    boq = client.get(f"{API}/projects/{prj['id']}/boq", headers=pm).json()["data"]
    assert len(boq) == len(so["items"])
    for b, i in zip(boq, so["items"], strict=True):
        assert (b["line_no"], b["description"], b["unit"], b["contract_amount"]) == \
               (i["line_no"], i["description"], i["unit"], i["taxable"])
        assert b["approved_qty"] == i["quantity"].rstrip("0").rstrip(".") and b["installed_qty"] == "0"
        assert b["remaining_qty"] == b["approved_qty"] and b["from_order"] is True
    total = sum(__import__("decimal").Decimal(b["contract_amount"]) for b in boq)
    assert str(total) == so["taxable"]
    so2 = client.get(f"{API}/sales-orders/{so['id']}", headers=pm).json()["data"]
    assert so2["status"] == "in_progress" and so2["projects"][0]["project_number"] == prj["project_number"]
    r = client.post(f"{API}/projects", headers=pm, json={"sales_order_id": so["id"], "name": "Again"})
    assert r.json()["error"]["code"] == "PROJECT_EXISTS"
    # an order with a running project cannot be cancelled
    r = client.post(f"{API}/sales-orders/{so['id']}/status", headers=as_user("manager"),
                    json={"status": "cancelled", "reason": "customer withdrew"})
    assert r.json()["error"]["code"] == "PROJECT_ACTIVE"


def test_only_accepted_quotations_become_orders(client, as_user):
    h = as_user("sales1")
    q = new_quote(client, h, [line()])
    q = act(client, h, q, "submit")
    q = act(client, h, q, "send")
    r = client.post(f"{API}/quotations/{q['id']}/sales-order", headers=h, json={})
    assert r.status_code == 400 and r.json()["error"]["code"] == "NOT_ACCEPTED"
    # accounts may read orders but not create them
    q = act(client, h, q, "accept")
    assert client.post(f"{API}/quotations/{q['id']}/sales-order", headers=as_user("accounts1"), json={}).status_code == 403


# ------------------------------------------------------------------ commercial lock
def test_sales_order_rates_locked_except_for_commercial_permission(client, as_user):
    h = as_user("sales1")
    so = make_so(client, h, accepted_quote(client, h))
    items = [{k: i[k] for k in ("section", "item_id", "description", "technical_specification", "hsn_sac", "quantity",
                                "unit", "rate", "discount_pct", "tax_rate", "remarks")} for i in so["items"]]
    items[0]["rate"] = "1"
    body = {"items": items, "special_discount": "0", "terms": so["terms"], "reason": "Customer negotiated",
            "row_version": so["row_version"]}
    for user in ("sales1", "manager", "pm1", "accounts1"):  # the salesperson who owns it cannot change prices either
        r = client.put(f"{API}/sales-orders/{so['id']}/commercial", headers=as_user(user), json=body)
        assert r.status_code == 403, user
    # non-commercial details stay editable by the owner
    r = client.put(f"{API}/sales-orders/{so['id']}", headers=h, json={"customer_po_number": "PO-778/A",
                                                                     "row_version": so["row_version"]})
    assert r.status_code == 200 and r.json()["data"]["customer_po_number"] == "PO-778/A"
    so = r.json()["data"]
    d = as_user("director")
    r = client.put(f"{API}/sales-orders/{so['id']}/commercial", headers=d, json=body | {"reason": "", "row_version": so["row_version"]})
    assert r.status_code == 422  # a reason is mandatory
    items[0]["rate"] = "14000"
    r = client.put(f"{API}/sales-orders/{so['id']}/commercial", headers=d,
                   json=body | {"items": items, "row_version": so["row_version"]})
    assert r.status_code == 200, r.text
    new = r.json()["data"]
    assert new["items"][0]["rate"] == "14000.0000" and new["items"][0]["taxable"] == "28000.00"
    assert new["special_discount"] == "0.00" and new["commercial_changed_at"]
    log = client.get(f"{API}/audit-logs", headers=d,
                     params={"entity_type": "sales_order", "entity_id": so["id"]}).json()["data"]
    assert any(x["action"] == "commercial_change" and "Customer negotiated" in (x["summary"] or "") for x in log)


def test_commercial_change_flows_into_project_boq(client, as_user):
    h, d, pm = as_user("sales1"), as_user("director"), as_user("pm1")
    so = make_so(client, h, accepted_quote(client, h))
    prj = client.post(f"{API}/projects", headers=pm, json={"sales_order_id": so["id"], "name": "Sync test"}).json()["data"]
    boq = client.get(f"{API}/projects/{prj['id']}/boq", headers=pm).json()["data"]
    r = client.post(f"{API}/projects/{prj['id']}/installations", headers=pm, json={
        "boq_line_id": boq[1]["id"], "quantity": "5", "entry_date": ist_today().isoformat()})
    assert r.status_code == 201, r.text
    items = [{k: i[k] for k in ("section", "item_id", "description", "technical_specification", "hsn_sac", "quantity",
                                "unit", "rate", "discount_pct", "tax_rate", "remarks")} for i in so["items"]]
    items[1]["quantity"] = "9"
    items = items[:2]  # installation line dropped from the order
    r = client.put(f"{API}/sales-orders/{so['id']}/commercial", headers=d, json={
        "items": items, "terms": so["terms"], "reason": "Scope revised by customer", "row_version": so["row_version"]})
    assert r.status_code == 200, r.text
    new = r.json()["data"]
    p2 = client.get(f"{API}/projects/{prj['id']}", headers=pm).json()["data"]
    boq = client.get(f"{API}/projects/{prj['id']}/boq", headers=pm).json()["data"]
    assert p2["contract_value"] == new["taxable"] and len(boq) == 2
    assert boq[1]["approved_qty"] == "9" and boq[1]["installed_qty"] == "5" and boq[1]["remaining_qty"] == "4"


# ------------------------------------------------------------------ BOQ tracking & installation
def test_installation_never_exceeds_approved_quantity(client, as_user):
    e = as_user("engineer1")
    prj = demo_project(client, e)
    assert prj["can"]["site_create"] is True and prj["can"]["update"] is False
    boq = client.get(f"{API}/projects/{prj['id']}/boq", headers=e).json()["data"]
    at = boq[0]  # 16 air terminals, 10 recorded by the demo site reports
    assert (at["approved_qty"], at["installed_qty"], at["remaining_qty"]) == ("16", "10", "6")
    today = ist_today().isoformat()
    r = client.post(f"{API}/projects/{prj['id']}/installations", headers=e,
                    json={"boq_line_id": at["id"], "quantity": "7", "entry_date": today})
    assert r.status_code == 400 and r.json()["error"]["code"] == "OVER_INSTALLED"
    r = client.post(f"{API}/projects/{prj['id']}/installations", headers=e,
                    json={"boq_line_id": at["id"], "quantity": "2",
                          "entry_date": (ist_today() + timedelta(days=1)).isoformat()})
    assert r.json()["error"]["code"] == "FUTURE_DATE"
    # a site report records work, installation and progress together
    r = client.post(f"{API}/projects/{prj['id']}/site-reports", headers=e, json={
        "report_date": today, "work_done": "Remaining air terminals on the north parapet", "manpower": 4,
        "progress_pct": 45, "installations": [{"boq_line_id": at["id"], "quantity": "6", "location": "North"}]})
    assert r.status_code == 201, r.text
    rep = r.json()["data"]
    assert rep["installations"][0]["quantity"] == "6"
    at2 = client.get(f"{API}/projects/{prj['id']}/boq", headers=e).json()["data"][0]
    assert (at2["installed_qty"], at2["remaining_qty"], at2["installed_pct"]) == ("16", "0", "100.0")
    assert client.get(f"{API}/projects/{prj['id']}", headers=e).json()["data"]["progress_pct"] == 45
    # the whole report is rejected if any line would be over-installed (nothing half-saved)
    r = client.post(f"{API}/projects/{prj['id']}/site-reports", headers=e, json={
        "report_date": today, "work_done": "Over", "installations": [{"boq_line_id": at["id"], "quantity": "1"}]})
    assert r.json()["error"]["code"] == "OVER_INSTALLED"
    assert len(client.get(f"{API}/site-reports", headers=e, params={"project_id": prj["id"]}).json()["data"]) == 3
    # deleting a report gives its quantities back (engineer has no delete; the PM does)
    assert client.delete(f"{API}/site-reports/{rep['id']}", headers=e).status_code == 403
    assert client.delete(f"{API}/site-reports/{rep['id']}", headers=as_user("pm1")).status_code == 200
    assert client.get(f"{API}/projects/{prj['id']}/boq", headers=e).json()["data"][0]["installed_qty"] == "10"


def test_dashboard_figures(client, as_user):
    prj = demo_project(client, as_user("manager"))
    f = prj["financials"]
    assert f["contract_value"] == prj["contract_value"]
    from decimal import Decimal as D
    assert D(f["estimated_cost"]) > 0 and D(f["estimated_profit"]) == D(f["contract_value"]) - D(f["estimated_cost"])
    assert D(f["installed_value"]) > 0 and f["billed"] is None  # billing arrives in Phase 6
    c = prj["counts"]
    assert c["tasks_total"] == 5 and c["tasks_done"] == 1 and c["tasks_overdue"] == 1 and c["issues_open"] == 1
    s = client.get(f"{API}/projects/summary", headers=as_user("pm1")).json()["data"]
    assert s["active"] >= 1 and s["overdue_tasks"] >= 1
    assert client.get(f"{API}/projects/{prj['id']}/pdf", headers=as_user("pm1")).content[:4] == b"%PDF"
    x = client.get(f"{API}/projects/{prj['id']}/boq/export", headers=as_user("pm1"))
    assert x.status_code == 200 and x.content[:2] == b"PK"
    so = client.get(f"{API}/sales-orders", headers=as_user("accounts1")).json()["data"][0]
    assert client.get(f"{API}/sales-orders/{so['id']}/pdf", headers=as_user("accounts1")).content[:4] == b"%PDF"


# ------------------------------------------------------------------ scope & tasks
def test_project_visibility_and_team_rules(client, as_user):
    assert client.get(f"{API}/projects", headers=as_user("sales1")).status_code == 403
    assert client.get(f"{API}/projects", headers=as_user("hr1")).status_code == 403
    prj = demo_project(client, as_user("manager"))
    assert demo_project(client, as_user("store1"))["id"] == prj["id"]
    e = as_user("engineer1")
    body = {"name": prj["name"], "priority": "high", "row_version": prj["row_version"]}
    assert client.put(f"{API}/projects/{prj['id']}", headers=e, json=body).status_code == 403
    assert client.post(f"{API}/projects", headers=e, json={"customer_id": abc(client, e)["id"],
                                                           "name": "Mine"}).status_code == 403
    # a standalone project by the manager; the engineer is not on its team so cannot see it
    m = as_user("manager")
    r = client.post(f"{API}/projects", headers=m, json={"customer_id": abc(client, m)["id"], "name": "AMC visit works",
                                                        "contract_value": "50000"})
    assert r.status_code == 201, r.text
    other = r.json()["data"]
    assert other["contract_value"] == "50000.00" and other["sales_order_id"] is None
    assert client.get(f"{API}/projects/{other['id']}", headers=e).status_code == 403
    assert client.post(f"{API}/projects/{other['id']}/site-reports", headers=e,
                       json={"report_date": ist_today().isoformat(), "work_done": "x x x"}).status_code == 403
    # assigning a task puts the engineer on the team
    eid = client.get(f"{API}/auth/me", headers=e).json()["data"]["id"]
    r = client.post(f"{API}/projects/{other['id']}/tasks", headers=m, json={"title": "Check earth pits", "assigned_to": eid})
    assert r.status_code == 201
    assert client.get(f"{API}/projects/{other['id']}", headers=e).status_code == 200
    mine = client.get(f"{API}/tasks", headers=e, params={"mine": True}).json()["data"]
    assert any(t["title"] == "Check earth pits" for t in mine)
    # a planning project without work can be deleted; later it must be cancelled
    r = client.delete(f"{API}/projects/{other['id']}", headers=m)
    assert r.status_code == 200


def test_assignee_moves_own_task_and_blocked_needs_reason(client, as_user):
    emp = as_user("employee1")  # Technician: no project permissions, but has a demo task
    mine = client.get(f"{API}/tasks", headers=emp, params={"mine": True}).json()["data"]
    assert len(mine) == 1 and mine[0]["can"]["status"] is True and mine[0]["can"]["edit"] is False
    t = mine[0]
    r = client.post(f"{API}/tasks/{t['id']}/status", headers=emp, json={"status": "blocked"})
    assert r.json()["error"]["code"] == "REASON_REQUIRED"
    r = client.post(f"{API}/tasks/{t['id']}/status", headers=emp, json={"status": "blocked", "blocked_reason": "Scaffold not ready"})
    assert r.status_code == 200 and r.json()["data"]["status"] == "blocked"
    r = client.post(f"{API}/tasks/{t['id']}/status", headers=emp, json={"status": "done"})
    assert r.json()["data"]["status"] == "done" and r.json()["data"]["completed_at"]
    # someone else's task: no
    other = [x for x in client.get(f"{API}/tasks", headers=as_user("pm1")).json()["data"] if x["assigned_to"] != t["assigned_to"]][0]
    assert client.post(f"{API}/tasks/{other['id']}/status", headers=emp, json={"status": "done"}).status_code == 403
    assert client.get(f"{API}/tasks", headers=emp).status_code == 403  # only "my tasks"
    # the PM was told about the block
    n = client.get(f"{API}/notifications", headers=as_user("pm1")).json()["data"]
    assert any("blocked" in x["title"].lower() for x in n)


def test_project_status_rules(client, as_user):
    pm = as_user("pm1")
    prj = demo_project(client, pm)
    r = client.post(f"{API}/projects/{prj['id']}/status", headers=pm, json={"status": "on_hold"})
    assert r.json()["error"]["code"] == "REASON_REQUIRED"
    r = client.post(f"{API}/projects/{prj['id']}/status", headers=pm, json={"status": "completed"})
    assert r.status_code == 200 and r.json()["data"]["actual_end_date"]
    r = client.post(f"{API}/projects/{prj['id']}/installations", headers=pm, json={
        "boq_line_id": client.get(f"{API}/projects/{prj['id']}/boq", headers=pm).json()["data"][0]["id"],
        "quantity": "1", "entry_date": ist_today().isoformat()})
    assert r.json()["error"]["code"] == "PROJECT_CLOSED"
    r = client.post(f"{API}/projects/{prj['id']}/status", headers=pm, json={"status": "active", "reason": "Snag list"})
    assert r.status_code == 200 and r.json()["data"]["actual_end_date"] is None
    assert client.delete(f"{API}/projects/{prj['id']}", headers=as_user("director")).json()["error"]["code"] == "PROJECT_STARTED"
