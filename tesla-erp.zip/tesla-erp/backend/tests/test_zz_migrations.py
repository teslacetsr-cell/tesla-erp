"""Migrations: full downgrade to empty and upgrade again (runs last — it rebuilds the schema)."""
from alembic import command
from sqlalchemy import inspect

from tests.conftest import _alembic_cfg


def test_downgrade_and_upgrade_cleanly(owner_engine):
    cfg = _alembic_cfg()
    command.downgrade(cfg, "base")
    assert set(inspect(owner_engine).get_table_names()) <= {"alembic_version"}
    command.upgrade(cfg, "head")
    tables = set(inspect(owner_engine).get_table_names())
    assert {"users", "customers", "audit_logs", "document_sequences", "items"} <= tables
