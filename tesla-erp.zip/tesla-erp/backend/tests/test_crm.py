"""Phase 2 CRM (Spec §11, §12, §45: "Enquiries can be created", "Site visits can be recorded")."""
import io
import re

from PIL import Image

API = "/api/v1"


def me(client, h) -> str:
    return client.get(f"{API}/auth/me", headers=h).json()["data"]["id"]


def abc_customer(client, h) -> dict:
    return client.get(f"{API}/customers", headers=h, params={"q": "ABC Hospital"}).json()["data"][0]


def new_lead(client, h, **kw) -> dict:
    body = {"title": "Surge protection for data centre", "company_name": "Nila Data Centre", "contact_name": "Ms. Priya",
            "contact_phone": "94955 12345", "city": "Kochi", "source": "website", "estimated_value": "250000"} | kw
    r = client.post(f"{API}/leads", headers=h, json=body)
    assert r.status_code == 201, r.text
    return r.json()["data"]


# ------------------------------------------------------------------ leads
def test_lead_numbering_and_validation(client, as_user):
    h = as_user("sales1")
    lead = new_lead(client, h)
    assert re.fullmatch(r"TCE/LEAD/\d{4}-\d{2}/\d{4}", lead["lead_number"])
    assert lead["status"] == "new" and lead["sales_person_id"] == me(client, h)  # a salesperson owns their leads
    assert lead["estimated_value"] == "250000.00"  # money is a string, never a float
    r = client.post(f"{API}/leads", headers=h, json={"title": "No way to reach them", "company_name": "Someone"})
    assert r.status_code == 422 and "phone number or email" in r.text
    r = client.post(f"{API}/leads", headers=h, json={"title": "Nobody", "contact_phone": "9876543210"})
    assert r.status_code == 422


def test_sales_see_only_their_own_leads(client, as_user):
    h1, h2, hm = as_user("sales1"), as_user("sales2"), as_user("manager")
    mine = new_lead(client, h1, title="Only for sales1")
    numbers = lambda h: {x["lead_number"] for x in client.get(f"{API}/leads", headers=h, params={"page_size": 200}).json()["data"]}  # noqa: E731
    assert mine["lead_number"] in numbers(h1)
    assert mine["lead_number"] not in numbers(h2)
    assert mine["lead_number"] in numbers(hm)
    r = client.get(f"{API}/leads/{mine['id']}", headers=h2)
    assert r.status_code == 403 and r.json()["error"]["code"] == "OUT_OF_SCOPE"
    # nor its documents, activities or search hits
    assert client.get(f"{API}/documents", headers=h2, params={"entity_type": "lead", "entity_id": mine["id"]}).status_code == 403
    assert client.get(f"{API}/crm/activities", headers=h2, params={"lead_id": mine["id"]}).status_code == 403
    hits = client.get(f"{API}/search", headers=h2, params={"q": "Only for sales1"}).json()["data"]
    assert not any(g["type"] == "lead" for g in hits)
    assert any(g["type"] == "lead" for g in client.get(f"{API}/search", headers=h1, params={"q": "Only for sales1"}).json()["data"])


def test_lost_needs_a_reason(client, as_user):
    h = as_user("sales1")
    lead = new_lead(client, h)
    r = client.post(f"{API}/leads/{lead['id']}/status", headers=h, json={"status": "lost"})
    assert r.status_code == 400 and r.json()["error"]["code"] == "LOST_REASON_REQUIRED"
    r = client.post(f"{API}/leads/{lead['id']}/status", headers=h, json={"status": "lost", "lost_reason": "Budget cut"})
    assert r.status_code == 200 and r.json()["data"]["lost_reason"] == "Budget cut"
    r = client.post(f"{API}/leads/{lead['id']}/convert", headers=h, json={})
    assert r.json()["error"]["code"] == "LEAD_CLOSED"


# ------------------------------------------------------------------ conversion never duplicates customers
def test_convert_detects_existing_customer(client, as_user):
    h = as_user("sales1")
    before = client.get(f"{API}/customers", headers=h).json()["meta"]["total"]
    lead = new_lead(client, h, title="More SPDs", company_name="ABC Hospital", contact_phone="0487 2330000")
    r = client.post(f"{API}/leads/{lead['id']}/convert", headers=h, json={})
    assert r.status_code == 409 and r.json()["error"]["code"] == "POSSIBLE_DUPLICATE_CUSTOMER"
    candidate = r.json()["error"]["details"]["candidates"][0]
    assert candidate["customer_name"] == "ABC Hospital"
    # the user picks the existing customer
    r = client.post(f"{API}/leads/{lead['id']}/convert", headers=h, json={"customer_id": candidate["id"]})
    assert r.status_code == 201, r.text
    enq = r.json()["data"]
    assert enq["customer_id"] == candidate["id"] and enq["lead_number"] == lead["lead_number"]
    assert re.fullmatch(r"TCE/ENQ/\d{4}-\d{2}/\d{4}", enq["enquiry_number"])
    assert client.get(f"{API}/customers", headers=h).json()["meta"]["total"] == before
    lead = client.get(f"{API}/leads/{lead['id']}", headers=h).json()["data"]
    assert lead["status"] == "qualified" and lead["customer_id"] == candidate["id"]
    # a second enquiry from the same lead reuses the same customer — still no new customer
    r = client.post(f"{API}/leads/{lead['id']}/convert", headers=h, json={"subject": "Phase 2 block"})
    assert r.status_code == 201 and r.json()["data"]["customer_id"] == candidate["id"]
    assert client.get(f"{API}/customers", headers=h).json()["meta"]["total"] == before


def test_convert_creates_new_customer_with_contact(client, as_user):
    h = as_user("sales2")
    lead = new_lead(client, h)
    r = client.post(f"{API}/leads/{lead['id']}/convert", headers=h, json={"priority": "high"})
    assert r.status_code == 201, r.text
    enq = r.json()["data"]
    cust = client.get(f"{API}/customers/{enq['customer_id']}", headers=h).json()["data"]
    assert cust["customer_name"] == "Nila Data Centre" and cust["phone"] == "94955 12345"
    assert cust["assigned_sales_person_id"] == me(client, h)
    assert [c["name"] for c in cust["contacts"]] == ["Ms. Priya"]
    assert enq["priority"] == "high" and enq["estimated_value"] == "250000.00"


def test_site_engineer_cannot_create_customers_through_conversion(client, as_user, admin_headers):
    # a role with lead.update + enquiry.create but not customer.create must pick an existing customer
    pm = as_user("pm1")
    lead = new_lead(client, as_user("manager"))
    r = client.post(f"{API}/leads/{lead['id']}/convert", headers=pm, json={})
    assert r.status_code == 403  # PM may read leads but not update them


# ------------------------------------------------------------------ enquiry → site visit → report
def _png(color=(200, 30, 30)) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", (1600, 1200), color).save(buf, "PNG")
    return buf.getvalue()


def test_site_visit_full_flow(client, as_user):
    hs, he = as_user("sales1"), as_user("engineer1")
    engineer_id = me(client, he)
    abc = abc_customer(client, hs)
    lead = new_lead(client, hs, title="Earthing upgrade", customer_id=abc["id"], company_name=None, contact_name=None,
                    contact_phone=None)
    enq = client.post(f"{API}/leads/{lead['id']}/convert", headers=hs, json={}).json()["data"]
    assert enq["status"] == "open"

    # the engineer cannot see the enquiry until a visit is assigned to them
    assert client.get(f"{API}/enquiries/{enq['id']}", headers=he).status_code == 403
    r = client.post(f"{API}/site-visits", headers=hs, json={
        "enquiry_id": enq["id"], "visit_date": "2026-10-05", "visit_time": "10:30", "engineer_id": engineer_id,
        "purpose": "Earth resistance survey"})
    assert r.status_code == 201, r.text
    v = r.json()["data"]
    assert re.fullmatch(r"TCE/SV/\d{4}-\d{2}/\d{4}", v["visit_number"])
    assert v["customer_id"] == abc["id"] and v["site_location"]  # location defaulted from the customer / site
    assert client.get(f"{API}/enquiries/{enq['id']}", headers=hs).json()["data"]["status"] == "site_visit"
    assert client.get(f"{API}/leads/{lead['id']}", headers=hs).json()["data"]["status"] == "site_visit"
    assert client.get(f"{API}/enquiries/{enq['id']}", headers=he).status_code == 200  # now visible to the engineer
    assert any(x["id"] == v["id"] for x in client.get(f"{API}/site-visits", headers=he).json()["data"])

    # nothing recorded yet → cannot complete
    r = client.post(f"{API}/site-visits/{v['id']}/complete", headers=he, json={})
    assert r.status_code == 400 and r.json()["error"]["code"] == "VISIT_EMPTY"

    full = client.get(f"{API}/site-visits/{v['id']}", headers=he).json()["data"]
    body = {k: full[k] for k in ("enquiry_id", "visit_date", "visit_time", "engineer_id", "purpose", "site_location",
                                 "row_version")} | {
        "observations": "Two earth pits, both dry.\nDG earthing missing.", "requirements": "New pits, SPD at LT panel",
        "recommendations": "Copper-bonded electrodes; target < 1 Ω", "measurements": [
            {"label": "Earth pit 1", "value": "8.4", "unit": "Ω"}, {"label": "Roof height", "value": "22", "unit": "m"}],
        "customer_rep_name": "Mr. Joseph Mathew", "customer_rep_phone": "98470 00000", "follow_up_date": "2026-10-08",
        "latitude": 10.52761234567, "longitude": 76.21443219876, "location_accuracy_m": 12}
    r = client.put(f"{API}/site-visits/{v['id']}", headers=he, json=body)
    assert r.status_code == 200, r.text
    v = r.json()["data"]
    assert v["latitude"] == "10.527612" and v["location_captured_at"] and v["measurements"][0]["unit"] == "Ω"

    for i, color in enumerate(((200, 30, 30), (30, 120, 200))):
        r = client.post(f"{API}/documents", headers=he, data={"entity_type": "site_visit", "entity_id": v["id"],
                                                              "category": "site_photo"},
                        files={"file": (f"photo{i}.png", _png(color), "image/png")})
        assert r.status_code == 201, r.text

    r = client.post(f"{API}/site-visits/{v['id']}/complete", headers=he, json={"row_version": v["row_version"]})
    assert r.status_code == 200 and r.json()["data"]["status"] == "completed"
    assert client.get(f"{API}/enquiries/{enq['id']}", headers=hs).json()["data"]["status"] == "evaluation"
    # the follow-up date became a follow-up task for the salesperson
    fu = client.get(f"{API}/crm/follow-ups", headers=hs, params={"page_size": 100}).json()["data"]
    task = next(a for a in fu if v["visit_number"] in a["subject"])
    assert task["due_at"].startswith("2026-10-08") and task["parent"]["number"] == enq["enquiry_number"]

    # Site Visit Report PDF, stored on the visit; regenerating makes version 2
    r = client.post(f"{API}/site-visits/{v['id']}/report", headers=he)
    assert r.status_code == 201, r.text
    rep = r.json()["data"]
    pdf = client.get(f"{API}/documents/{rep['id']}/content", headers=hs)
    assert pdf.status_code == 200 and pdf.content[:5] == b"%PDF-" and pdf.headers["content-type"] == "application/pdf"
    assert 5_000 < len(pdf.content) < 3_000_000  # photos were downscaled
    assert client.post(f"{API}/site-visits/{v['id']}/report", headers=he).json()["data"]["version"] == 2

    # completed visits cannot be deleted; the enquiry with visits cannot be deleted either
    assert client.delete(f"{API}/site-visits/{v['id']}", headers=as_user("manager")).status_code == 409
    assert client.delete(f"{API}/enquiries/{enq['id']}", headers=as_user("manager")).status_code == 409


def test_other_engineer_and_salesperson_are_out_of_scope(client, as_user):
    hs = as_user("sales1")
    abc = abc_customer(client, hs)
    v = client.post(f"{API}/site-visits", headers=hs, json={
        "customer_id": abc["id"], "visit_date": "2026-10-06", "site_location": "Warehouse, Thrissur"}).json()["data"]
    assert client.get(f"{API}/site-visits/{v['id']}", headers=as_user("sales2")).status_code == 403
    assert client.get(f"{API}/site-visits/{v['id']}", headers=as_user("engineer1")).status_code == 403
    assert client.get(f"{API}/site-visits/{v['id']}", headers=as_user("pm1")).status_code == 200  # PM sees all
    assert client.post(f"{API}/site-visits/{v['id']}/report", headers=as_user("sales2")).status_code == 403
    assert client.get(f"{API}/leads", headers=as_user("accounts1")).status_code == 403


def test_visit_requires_location_and_matching_customer(client, as_user, admin_headers):
    h = as_user("manager")
    abc = abc_customer(client, h)
    other = client.post(f"{API}/customers", headers=admin_headers, json={"customer_name": "Other Co"}).json()["data"]
    r = client.post(f"{API}/site-visits", headers=h, json={"customer_id": other["id"], "visit_date": "2026-10-06"})
    assert r.status_code == 400 and r.json()["error"]["code"] == "LOCATION_REQUIRED"
    enq = client.post(f"{API}/enquiries", headers=h, json={"customer_id": abc["id"], "subject": "Solar survey"}).json()["data"]
    r = client.post(f"{API}/site-visits", headers=h, json={"enquiry_id": enq["id"], "customer_id": other["id"],
                                                          "visit_date": "2026-10-06", "site_location": "x"})
    assert r.json()["error"]["code"] == "CUSTOMER_MISMATCH"
    r = client.post(f"{API}/site-visits", headers=h, json={"customer_id": abc["id"], "visit_date": "2026-10-06",
                                                          "site_location": "Roof", "latitude": 10.5})
    assert r.status_code == 422


def test_gps_setting_off_drops_location(client, as_user, admin_headers):
    assert client.put(f"{API}/settings/crm.site_visit_gps", headers=admin_headers, json={"value": False}).status_code == 200
    h = as_user("manager")
    abc = abc_customer(client, h)
    v = client.post(f"{API}/site-visits", headers=h, json={"customer_id": abc["id"], "visit_date": "2026-10-06",
                                                          "site_location": "Roof", "latitude": 10.5,
                                                          "longitude": 76.2}).json()["data"]
    assert client.get(f"{API}/site-visits/{v['id']}", headers=h).json()["data"]["latitude"] is None


def test_enquiry_won_wins_the_lead(client, as_user):
    h = as_user("sales1")
    lead = new_lead(client, h)
    enq = client.post(f"{API}/leads/{lead['id']}/convert", headers=h, json={}).json()["data"]
    r = client.post(f"{API}/enquiries/{enq['id']}/status", headers=h, json={"status": "won"})
    assert r.status_code == 200
    assert client.get(f"{API}/leads/{lead['id']}", headers=h).json()["data"]["status"] == "won"


# ------------------------------------------------------------------ activities & follow-ups
def test_follow_ups_buckets_and_done(client, as_user):
    h = as_user("sales2")
    lead = new_lead(client, h)
    base = {"lead_id": lead["id"], "kind": "follow_up"}
    r = client.post(f"{API}/crm/activities", headers=h, json=base | {"subject": "Call back"})
    assert r.status_code == 422  # a follow-up needs a due time
    overdue = client.post(f"{API}/crm/activities", headers=h, json=base | {
        "subject": "Overdue call", "due_at": "2020-01-01T10:00:00+05:30"}).json()["data"]
    client.post(f"{API}/crm/activities", headers=h, json=base | {"subject": "Later", "due_at": "2099-01-01T10:00:00+05:30"})
    client.post(f"{API}/crm/activities", headers=h, json={"lead_id": lead["id"], "kind": "call", "subject": "Spoke to Priya"})
    subjects = lambda b: [a["subject"] for a in client.get(f"{API}/crm/follow-ups", headers=h, params={"bucket": b}).json()["data"]]  # noqa: E731
    assert "Overdue call" in subjects("overdue") and "Later" in subjects("upcoming") and "Later" not in subjects("overdue")
    assert client.get(f"{API}/crm/summary", headers=h).json()["data"]["my_follow_ups_overdue"] >= 1
    r = client.post(f"{API}/crm/activities/{overdue['id']}/done", headers=h, json={"outcome": "Survey fixed"})
    assert r.status_code == 200 and r.json()["data"]["done_at"]
    assert "Overdue call" not in subjects("overdue") and "Overdue call" in subjects("done")
    timeline = client.get(f"{API}/crm/activities", headers=h, params={"lead_id": lead["id"]}).json()["data"]
    assert {a["kind"] for a in timeline} == {"follow_up", "call"}
    # another salesperson cannot add to or close someone else's lead activities
    assert client.post(f"{API}/crm/activities", headers=as_user("sales1"), json={
        "lead_id": lead["id"], "kind": "note", "subject": "x y"}).status_code == 403


def test_summary_and_demo_pipeline(client, as_user):
    s = client.get(f"{API}/crm/summary", headers=as_user("manager")).json()["data"]
    by = {x["status"]: x["count"] for x in s["leads_by_status"]}
    assert by["site_visit"] >= 1 and by["contacted"] >= 1 and by["lost"] >= 1
    assert s["open_enquiries"] >= 1
    # engineers get no lead figures (no lead.read), only their visits
    se = client.get(f"{API}/crm/summary", headers=as_user("engineer1")).json()["data"]
    assert "leads_by_status" not in se and "visits_next_7_days" in se


def test_people_pickers(client, as_user):
    h = as_user("sales1")
    names = lambda k: {p["name"] for p in client.get(f"{API}/crm/people", headers=h, params={"kind": k}).json()["data"]}  # noqa: E731
    assert "Arjun Das (Site Engineer)" in names("engineer") and "Anil Kumar (Sales)" in names("sales")
    assert client.get(f"{API}/crm/people", headers=as_user("accounts1"), params={"kind": "sales"}).status_code == 403


def test_exports(client, as_user):
    h = as_user("manager")
    for path in ("leads", "enquiries"):
        r = client.get(f"{API}/{path}/export", headers=h)
        assert r.status_code == 200 and r.content[:2] == b"PK"


# ------------------------------------------------------------------ upgrade from Phase 1
def test_upgrade_grants_new_module_to_existing_roles(owner_engine):
    """A live Phase 1 database gets the CRM permissions on its standard roles when `seed core` runs — without
    overwriting any grant an administrator changed."""
    from sqlalchemy import text

    from app.core.db import SessionLocal
    from app.users.bootstrap import sync_permissions

    with owner_engine.begin() as c:  # make the database look like Phase 1: no CRM permission codes yet
        c.execute(text("DELETE FROM role_permissions WHERE permission_id IN "
                       "(SELECT id FROM permissions WHERE module IN ('lead','enquiry','site_visit'))"))
        c.execute(text("DELETE FROM permissions WHERE module IN ('lead','enquiry','site_visit')"))
        # an admin had customised the SALES role: removed customer.export
        c.execute(text("DELETE FROM role_permissions WHERE role_id=(SELECT id FROM roles WHERE code='SALES') AND "
                       "permission_id=(SELECT id FROM permissions WHERE code='customer.export')"))
    with SessionLocal() as s:
        sync_permissions(s)
        s.commit()
    with owner_engine.connect() as c:
        grants = dict(c.execute(text(
            "SELECT p.code, rp.scope FROM role_permissions rp JOIN permissions p ON p.id=rp.permission_id "
            "JOIN roles r ON r.id=rp.role_id WHERE r.code='SALES'")).all())
    assert grants["lead.read"] == "own" and grants["site_visit.create"] == "all"
    assert "customer.export" not in grants  # the administrator's change stands


def test_ui_allows_geolocation_for_site_visits(client):
    """The GPS button on the site-visit form needs geolocation; the security headers must not block it."""
    h = client.get("/api/v1/healthz").headers.get("permissions-policy") or client.get("/healthz").headers["permissions-policy"]
    assert "geolocation=(self)" in h and "camera=()" in h
