"""Team chat: the company channel everyone is in, groups and direct messages with member-only access, attachments
through the documents store, edit window, soft delete, moderation (audited), unread counts and @mentions."""
import io

from sqlalchemy import text

from tests.test_finance import err, get, post

API = "/api/v1"


def _png(color=(30, 120, 200), size=(900, 600)) -> bytes:
    from PIL import Image

    buf = io.BytesIO()
    Image.new("RGB", size, color).save(buf, "PNG")
    return buf.getvalue()


def uid(client, h, username):
    return next(u["id"] for u in get(client, h, "/chat/people") if u["username"] == username)


def company(client, h):
    return next(c for c in get(client, h, "/chat/channels") if c["kind"] == "company")


def send(client, h, channel_id, body="", **extra):
    return post(client, h, f"/chat/channels/{channel_id}/messages", {"body": body, **extra})


def upload(client, h, channel_id, name="site.png", data=None, ctype="image/png"):
    r = client.post(f"{API}/chat/channels/{channel_id}/attachments", headers=h,
                    files={"file": (name, data if data is not None else _png(), ctype)})
    return r


def test_company_channel_includes_everyone_and_seeded_messages(client, as_user):
    for user in ("employee1", "accounts1"):
        c = company(client, as_user(user))
        assert c["name"] == "Tesla Team" and c["member_count"] >= 11
    h = as_user("employee1")
    c = company(client, h)
    msgs = get(client, h, f"/chat/channels/{c['id']}/messages")
    assert len(msgs) >= 3 and msgs[1]["reply_to"]["sender_name"] == "Director"
    # a brand-new login is a member automatically
    adm = as_user("hr1")
    ch = company(client, adm)
    m = send(client, adm, ch["id"], "Welcome to the team!\nLink: https://teslace.in")
    assert m["body"].endswith("https://teslace.in") and m["can_edit"] and m["can_delete"]
    assert company(client, h)["unread"] >= 1


def test_direct_messages_are_private(client, as_user):
    s1, pm, s2 = as_user("sales1"), as_user("pm1"), as_user("sales2")
    dm = post(client, s1, "/chat/direct", {"user_id": uid(client, s1, "pm1")})
    assert post(client, pm, "/chat/direct", {"user_id": uid(client, pm, "sales1")})["id"] == dm["id"]  # same room
    assert dm["kind"] == "direct" and dm["name"] == "Rahul Nair (Project Manager)"
    msg = send(client, s1, dm["id"], "Please send the earthing test report")
    assert any(m["id"] == msg["id"] for m in get(client, pm, f"/chat/channels/{dm['id']}/messages"))
    # outsiders see nothing: not in their list, cannot read, post or search
    assert dm["id"] not in [c["id"] for c in get(client, s2, "/chat/channels")]
    assert err(client, s2, f"/chat/channels/{dm['id']}/messages", method="get") == (403, "NOT_A_MEMBER")
    assert err(client, s2, f"/chat/channels/{dm['id']}/messages", {"body": "hi"})[0] == 403
    assert client.get(f"{API}/chat/channels/{dm['id']}/search", headers=s2, params={"q": "earthing"}).status_code == 403
    assert err(client, s1, "/chat/direct", {"user_id": uid(client, s1, "sales1")})[1] == "SELF_MESSAGE"


def test_groups_membership_and_audit(client, as_user, admin_headers, owner_engine):
    pm, eng, store, s2 = as_user("pm1"), as_user("engineer1"), as_user("store1"), as_user("sales2")
    g = post(client, pm, "/chat/channels", {"name": "ABC Hospital site", "member_ids": [uid(client, pm, "engineer1")]})
    assert g["kind"] == "group" and len(g["members"]) == 2 and g["can_rename"]
    assert err(client, s2, f"/chat/channels/{g['id']}", method="get")[0] == 403
    send(client, eng, g["id"], "Reached site")
    # any member can add people; only the creator or a moderator renames or removes others
    post(client, eng, f"/chat/channels/{g['id']}/members", {"user_ids": [uid(client, eng, "store1")]})
    assert any(c["id"] == g["id"] for c in get(client, store, "/chat/channels"))
    r = client.put(f"{API}/chat/channels/{g['id']}", headers=eng, json={"name": "Renamed"})
    assert r.status_code == 403
    r = client.put(f"{API}/chat/channels/{g['id']}", headers=pm, json={"name": "ABC Hospital — LPS"})
    assert r.status_code == 200 and r.json()["data"]["name"] == "ABC Hospital — LPS"
    assert client.delete(f"{API}/chat/channels/{g['id']}/members/{uid(client, pm, 'store1')}", headers=eng).status_code == 403
    assert client.delete(f"{API}/chat/channels/{g['id']}/members/{uid(client, pm, 'store1')}", headers=pm).status_code == 200
    assert err(client, store, f"/chat/channels/{g['id']}/messages", method="get")[0] == 403
    post(client, eng, f"/chat/channels/{g['id']}/leave")
    assert g["id"] not in [c["id"] for c in get(client, eng, "/chat/channels")]
    # the company channel cannot be left
    assert err(client, eng, f"/chat/channels/{company(client, eng)['id']}/leave")[1] == "CANNOT_LEAVE"
    # director (moderator) closes the group even though not a member? — must be a member: add and close
    post(client, pm, f"/chat/channels/{g['id']}/members", {"user_ids": [uid(client, pm, "director")]})
    d = as_user("director")
    assert client.delete(f"{API}/chat/channels/{g['id']}", headers=d).status_code == 200
    assert g["id"] not in [c["id"] for c in get(client, pm, "/chat/channels")]
    with owner_engine.connect() as c:
        summaries = [r[0] for r in c.execute(text(
            "select summary from audit_logs where entity_type='chat_channel' and entity_id=:i order by id"), {"i": g["id"]})]
    assert any(s.startswith("Created chat group") for s in summaries)
    assert any("Added Suresh Babu" in s for s in summaries) and any(s.startswith("Removed Suresh") for s in summaries)
    assert any("left chat" in s for s in summaries) and any(s.startswith("Closed chat group") for s in summaries)
    # messages are not audited one by one
    with owner_engine.connect() as c:
        assert c.execute(text("select count(*) from audit_logs where entity_type in ('chat_message', 'chat_channel') "
                              "and summary ilike '%Reached site%'")).scalar() == 0


def test_attachments_member_only_download(client, as_user):
    s1, pm, s2 = as_user("sales1"), as_user("pm1"), as_user("sales2")
    dm = post(client, s1, "/chat/direct", {"user_id": uid(client, s1, "pm1")})
    r = upload(client, s1, dm["id"])
    assert r.status_code == 201, r.text
    photo = r.json()["data"]
    assert photo["is_image"] and photo["has_thumb"] and photo["width"] == 900
    pdf = upload(client, s1, dm["id"], "report.pdf", b"%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF", "application/pdf")
    assert pdf.status_code == 201
    pdf = pdf.json()["data"]
    # not sent yet: only the uploader can fetch it
    assert client.get(f"{API}/chat/attachments/{photo['id']}", headers=pm).status_code == 404
    m = send(client, s1, dm["id"], "Site photo and report", attachment_ids=[photo["id"], pdf["id"]])
    assert [a["file_name"] for a in m["attachments"]] == ["site.png", "report.pdf"]
    r = client.get(f"{API}/chat/attachments/{photo['id']}", headers=pm, params={"thumb": True})
    assert r.status_code == 200 and r.headers["content-type"] == "image/jpeg" and r.content[:2] == b"\xff\xd8"
    r = client.get(f"{API}/chat/attachments/{pdf['id']}", headers=pm)
    assert r.status_code == 200 and r.content.startswith(b"%PDF") and "attachment" in r.headers["content-disposition"]
    for doc in (photo["id"], pdf["id"]):
        assert client.get(f"{API}/chat/attachments/{doc}", headers=s2).status_code == 403
        # and the generic documents endpoints do not open chat files either
        assert client.get(f"{API}/documents/{doc}/content", headers=s2).status_code in (403, 404)
    # an attachment cannot be re-used in another message or another channel
    assert err(client, s1, f"/chat/channels/{dm['id']}/messages", {"attachment_ids": [photo["id"]]})[1] == "ATTACHMENT_NOT_FOUND"
    # same type and size checks as every document
    assert upload(client, s1, dm["id"], "virus.exe", b"MZ\x90\x00" + b"\x00" * 100,
                  "application/octet-stream").json()["error"]["code"] == "FILE_TYPE_NOT_ALLOWED"
    assert upload(client, s1, dm["id"], "empty.png", b"").json()["error"]["code"] == "EMPTY_FILE"
    # pm cannot attach someone else's pending upload either
    pending = upload(client, s1, dm["id"]).json()["data"]
    assert err(client, pm, f"/chat/channels/{dm['id']}/messages", {"attachment_ids": [pending["id"]]})[1] == "ATTACHMENT_NOT_FOUND"


def test_edit_window_soft_delete_and_moderation(client, as_user, owner_engine):
    s1, pm, d = as_user("sales1"), as_user("pm1"), as_user("director")
    ch = company(client, s1)["id"]
    m = send(client, s1, ch, "Meeting at 4 pm")
    r = client.put(f"{API}/chat/channels/{ch}/messages/{m['id']}", headers=s1, json={"body": "Meeting at 5 pm"})
    assert r.status_code == 200 and r.json()["data"]["edited_at"] and r.json()["data"]["body"] == "Meeting at 5 pm"
    assert client.put(f"{API}/chat/channels/{ch}/messages/{m['id']}", headers=pm, json={"body": "x"}).status_code == 403
    with owner_engine.begin() as c:
        c.execute(text("update chat_messages set created_at = now() - interval '16 minutes' where id = :i"), {"i": m["id"]})
    r = client.put(f"{API}/chat/channels/{ch}/messages/{m['id']}", headers=s1, json={"body": "Meeting at 6 pm"})
    assert r.json()["error"]["code"] == "EDIT_WINDOW_OVER"
    # others cannot delete; the sender can (soft), any time
    assert client.delete(f"{API}/chat/channels/{ch}/messages/{m['id']}", headers=pm).status_code == 403
    r = client.delete(f"{API}/chat/channels/{ch}/messages/{m['id']}", headers=s1)
    out = r.json()["data"]
    assert r.status_code == 200 and out["deleted"] and out["body"] == "" and not out["can_delete"]
    msgs = get(client, pm, f"/chat/channels/{ch}/messages")
    assert next(x for x in msgs if x["id"] == m["id"])["deleted"]
    # a reply to a deleted message shows "Message deleted"
    rep = send(client, pm, ch, "ok", reply_to_id=m["id"])
    assert rep["reply_to"]["deleted"] and rep["reply_to"]["body"] == "Message deleted"
    # moderator removes someone else's message — audited with the text
    bad = send(client, pm, ch, "Wrong group, sorry")
    assert get(client, d, f"/chat/channels/{ch}/messages")[-1]["can_delete"] is True
    assert client.delete(f"{API}/chat/channels/{ch}/messages/{bad['id']}", headers=d).status_code == 200
    with owner_engine.connect() as c:
        row = c.execute(text("select summary from audit_logs where entity_type='chat_message' and entity_id=:i"),
                        {"i": str(bad["id"])}).scalar()
    assert row and "Rahul Nair" in row and "Wrong group" in row
    # own deletions are not audited
    with owner_engine.connect() as c:
        assert c.execute(text("select count(*) from audit_logs where entity_type='chat_message' and entity_id=:i"),
                         {"i": str(m["id"])}).scalar() == 0


def test_unread_counts_mark_read_and_polling(client, as_user):
    s1, pm = as_user("sales1"), as_user("pm1")
    dm = post(client, s1, "/chat/direct", {"user_id": uid(client, s1, "pm1")})
    post(client, pm, f"/chat/channels/{dm['id']}/read", {})  # the seeded message from sales1
    base = get(client, pm, "/chat/unread")["unread"]
    page = client.get(f"{API}/chat/channels/{dm['id']}/messages", headers=pm).json()
    since, last = page["meta"]["server_time"], page["meta"]["last_message_id"]
    a = send(client, s1, dm["id"], "one")
    send(client, s1, dm["id"], "two")
    assert get(client, pm, "/chat/unread")["unread"] == base + 2
    assert next(c for c in get(client, pm, "/chat/channels") if c["id"] == dm["id"])["unread"] == 2
    assert get(client, s1, "/chat/channels") and next(
        c for c in get(client, s1, "/chat/channels") if c["id"] == dm["id"])["unread"] == 0  # own messages are read
    # the bell poll carries the chat count too
    assert client.get(f"{API}/notifications", headers=pm).json()["meta"]["chat_unread"] == base + 2
    # poll: new messages after the last seen id, plus recent edits
    new = get(client, pm, f"/chat/channels/{dm['id']}/messages", after_id=last, since=since)
    assert [m["body"] for m in new][-2:] == ["one", "two"]
    client.put(f"{API}/chat/channels/{dm['id']}/messages/{a['id']}", headers=s1, json={"body": "one (edited)"})
    changed = get(client, pm, f"/chat/channels/{dm['id']}/messages", after_id=new[-1]["id"], since=since)
    assert "one (edited)" in [m["body"] for m in changed]  # (a 30-second overlap may repeat recent ones)
    post(client, pm, f"/chat/channels/{dm['id']}/read", {"last_id": a["id"]})
    assert next(c for c in get(client, pm, "/chat/channels") if c["id"] == dm["id"])["unread"] == 1
    post(client, pm, f"/chat/channels/{dm['id']}/read", {})
    assert get(client, pm, "/chat/unread")["unread"] == base


def test_paging_search_and_limits(client, as_user):
    h = as_user("engineer1")
    g = post(client, h, "/chat/channels", {"name": "Notes", "member_ids": []})
    ids = [send(client, h, g["id"], f"note {i}")["id"] for i in range(45)]
    r = client.get(f"{API}/chat/channels/{g['id']}/messages", headers=h).json()
    assert len(r["data"]) == 40 and r["meta"]["has_older"] and r["data"][-1]["body"] == "note 44"
    older = client.get(f"{API}/chat/channels/{g['id']}/messages", headers=h,
                       params={"before_id": r["data"][0]["id"]}).json()
    assert [m["body"] for m in older["data"]] == [f"note {i}" for i in range(5)] and not older["meta"]["has_older"]
    around = get(client, h, f"/chat/channels/{g['id']}/messages", around_id=ids[10])
    assert ids[10] in [m["id"] for m in around]
    found = get(client, h, f"/chat/channels/{g['id']}/search", q="note 1")
    assert {m["body"] for m in found} == {"note 1", *{f"note 1{i}" for i in range(10)}}
    assert err(client, h, f"/chat/channels/{g['id']}/messages", {"body": "x" * 4001})[1] == "MESSAGE_TOO_LONG"
    assert err(client, h, f"/chat/channels/{g['id']}/messages", {"body": "   "})[1] == "EMPTY_MESSAGE"


def test_mention_sends_notification(client, as_user):
    s1, pm, eng = as_user("sales1"), as_user("pm1"), as_user("engineer1")
    ch = company(client, s1)["id"]
    pm_id, eng_id = uid(client, s1, "pm1"), uid(client, s1, "engineer1")
    m = send(client, s1, ch, "@Rahul Nair (Project Manager) please check the BOQ", mention_ids=[pm_id, eng_id])
    assert m["mentions"] == [pm_id]  # engineer1 was not actually mentioned in the text
    notes = client.get(f"{API}/notifications", headers=pm).json()["data"]
    n = next(x for x in notes if "mentioned you" in x["title"])
    assert n["title"] == "Anil Kumar (Sales) mentioned you in Tesla Team" and n["link"].startswith(f"/chat?c={ch}")
    assert not any("Anil Kumar (Sales) mentioned you" in x["title"]
                   for x in client.get(f"{API}/notifications", headers=eng).json()["data"])
    # mentioning someone outside a direct conversation does nothing
    dm = post(client, s1, "/chat/direct", {"user_id": pm_id})
    m = send(client, s1, dm["id"], "@Arjun Das (Site Engineer) hello", mention_ids=[eng_id])
    assert m["mentions"] == []


def test_permissions_and_deactivated_user(client, as_user, admin_headers, owner_engine):
    for user in ("sales1", "store1", "hr1", "accounts1", "engineer1", "purchase1", "manager"):
        assert "chat.use" in client.get(f"{API}/auth/me", headers=as_user(user)).json()["data"]["permissions"]
    h = as_user("employee1")
    me = client.get(f"{API}/auth/me", headers=h).json()["data"]
    assert "chat.use" in me["permissions"] and "chat.moderate" not in me["permissions"]
    d = client.get(f"{API}/auth/me", headers=as_user("director")).json()["data"]
    assert "chat.moderate" in d["permissions"]
    # deactivated user: the session ends, so nothing can be posted
    with owner_engine.begin() as c:
        c.execute(text("update users set is_active = false where username = 'employee1'"))
    assert client.get(f"{API}/chat/channels", headers=h).status_code == 401
    # nobody can start a direct message with them
    s1 = as_user("sales1")
    with owner_engine.connect() as c:
        emp = str(c.execute(text("select id from users where username='employee1'")).scalar())
    assert err(client, s1, "/chat/direct", {"user_id": emp})[1] == "USER_NOT_AVAILABLE"


def test_project_channel(client, as_user):
    pm = as_user("pm1")
    prj = get(client, pm, "/projects")[0]
    ch = post(client, pm, f"/chat/projects/{prj['id']}")
    assert ch["kind"] == "project" and ch["name"].startswith(prj["project_number"])
    assert post(client, pm, f"/chat/projects/{prj['id']}")["id"] == ch["id"]
    send(client, pm, ch["id"], "Project room open")
    # someone who cannot see the project cannot open its room
    assert err(client, as_user("sales2"), f"/chat/projects/{prj['id']}")[0] == 403
