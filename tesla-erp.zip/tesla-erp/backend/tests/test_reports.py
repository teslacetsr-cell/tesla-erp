"""Phase 10: the report catalog, every report running and exporting, reconciliation with the books, permissions
and filters."""
import io
import time
from decimal import Decimal as D

from openpyxl import load_workbook
from sqlalchemy import text

from tests.test_finance import get, new_order, post, so_lines

API = "/api/v1"


def catalog(client, h) -> dict:
    groups = get(client, h, "/reports")
    return {r["key"]: r for g in groups for r in g["reports"]}


def run(client, h, key, **params) -> dict:
    return get(client, h, f"/reports/{key}", **params)


def _issued_invoice(client, as_user, qty: dict) -> dict:
    so = new_order(client, as_user)
    acc = as_user("accounts1")
    inv = post(client, acc, "/invoices", {"sales_order_id": so["id"], "items": so_lines(client, acc, so["id"], qty)})
    return post(client, acc, f"/invoices/{inv['id']}/issue")


def _books(client, as_user) -> dict:
    """A few more documents on top of the demo data: two invoices (one partly credited), a receipt."""
    acc = as_user("accounts1")
    a = _issued_invoice(client, as_user, {1: "1", 2: "2"})
    b = _issued_invoice(client, as_user, {2: "3"})
    post(client, acc, f"/invoices/{b['id']}/credit-notes", {"reason": "Rate difference agreed", "taxable": "1000"})
    post(client, acc, "/receipts", {"customer_id": a["customer_id"], "mode": "neft", "reference_no": "UTR-REP-1",
                                    "amount": "5000", "allocations": [{"document_id": a["id"], "amount": "5000"}]})
    return {"a": a, "b": b}


# ------------------------------------------------------------------ every report runs and exports
def test_every_report_runs_and_exports_for_director(client, as_user, owner_engine):
    _books(client, as_user)
    d = as_user("director")
    cat = catalog(client, d)
    from app.reports.registry import REPORTS

    assert set(cat) == set(REPORTS) and len(cat) >= 35
    for key, r in cat.items():
        assert r["title"] and r["description"] and r["columns"], key
        started = time.perf_counter()
        res = run(client, d, key)
        assert time.perf_counter() - started < 2, f"{key} is slow"
        assert res["row_count"] == len(res["rows"]) and res["truncated"] is False
        keys = [c["key"] for c in res["columns"]]
        for row in res["rows"]:
            assert set(keys) <= set(row), key
            for c in res["columns"]:
                v = row[c["key"]]
                if v is not None and c["type"] in ("money", "qty", "pct"):
                    assert isinstance(v, str) and D(v) == D(v), (key, c["key"], v)   # strings, never floats
        x = client.get(f"{API}/reports/{key}/export", headers=d, params={"format": "xlsx"})
        assert x.status_code == 200, (key, x.text)
        ws = load_workbook(io.BytesIO(x.content)).active
        assert ws["A1"].value == r["title"] and ws.cell(row=4, column=1).value == res["columns"][0]["label"]
        assert ws.max_row >= 4 + len(res["rows"])
        pdf = client.get(f"{API}/reports/{key}/export", headers=d, params={"format": "pdf"})
        assert pdf.status_code == 200 and pdf.content[:4] == b"%PDF", key
    with owner_engine.connect() as c:
        n = c.execute(text("select count(*) from audit_logs where action = 'export' and entity_type = 'report'")).scalar()
    assert n == 2 * len(cat)


def test_demo_data_shows_in_the_main_registers(client, as_user):
    d = as_user("director")
    for key in ("lead_register", "enquiry_register", "quotation_register", "sales_order_register", "project_status",
                "boq_vs_installed", "purchase_order_register", "grn_register", "stock_summary", "sales_register",
                "receipt_register", "supplier_bill_register", "headcount"):
        assert run(client, d, key)["row_count"] > 0, key


# ------------------------------------------------------------------ reconciliation
def test_sales_register_reconciles_with_gst_summary(client, as_user, owner_engine):
    _books(client, as_user)
    acc = as_user("accounts1")
    period = {"date_from": "2020-04-01", "date_to": "2035-03-31"}
    reg = run(client, acc, "sales_register", **period)
    gst = get(client, acc, "/finance/gst-summary", **period)
    for k in ("taxable", "cgst", "sgst", "igst"):
        assert D(reg["totals"][k]) == D(gst["output_total"][k]), k
    with owner_engine.connect() as c:
        total = c.execute(text("select sum(grand_total), count(*) from invoices where status in ('issued','cancelled')")).one()
    assert D(reg["totals"]["total"]) == total[0] and reg["row_count"] == total[1]
    # credit notes: the register total is what the GST summary subtracts
    cn = run(client, acc, "credit_note_register", **period)
    for k in ("taxable", "cgst", "sgst", "igst"):
        assert D(cn["totals"][k]) == D(gst["credit_notes"][k])
    # sales by customer / month = invoices less credit notes
    net = D(gst["net_output"]["taxable"])
    assert D(run(client, acc, "sales_by_customer", **period)["totals"]["net_taxable"]) == net
    assert D(run(client, acc, "sales_by_month", **period)["totals"]["net_taxable"]) == net


def test_receipt_and_stock_registers_reconcile(client, as_user, owner_engine):
    _books(client, as_user)
    acc = as_user("accounts1")
    reg = run(client, acc, "receipt_register", date_from="2020-04-01", date_to="2035-03-31")
    with owner_engine.connect() as c:
        amt, tds = c.execute(text("select sum(amount), sum(tds_amount) from receipts where status = 'posted'")).one()
        stock = c.execute(text("select sum(value) from stock_balances")).scalar()
    assert D(reg["totals"]["amount"]) == amt and D(reg["totals"]["tds"]) == tds
    assert all(r["status"] == "posted" for r in reg["rows"])
    ss = run(client, acc, "stock_summary")
    assert D(ss["totals"]["value"]) == stock and stock > 0
    # stock movement for all time closes at the stock value
    mv = run(client, acc, "stock_movement", date_from="2020-01-01", date_to="2035-12-31")
    assert D(mv["totals"]["closing_value"]) == stock


def test_receivables_reconcile_with_debtors_ledger(client, as_user):
    _books(client, as_user)
    acc = as_user("accounts1")
    rec = run(client, acc, "receivables_ageing")
    tb = get(client, acc, "/finance/trial-balance")
    debtors = sum(D(r["debit"]) - D(r["credit"]) for r in tb["rows"] if r["group"] == "Sundry Debtors")
    assert D(rec["totals"]["net"]) == debtors and debtors > 0
    assert D(rec["totals"]["outstanding"]) == D(get(client, acc, "/finance/receivables")["totals"]["outstanding"])
    pay = run(client, acc, "payables_ageing")
    creditors = sum(D(r["credit"]) - D(r["debit"]) for r in tb["rows"] if r["group"] == "Sundry Creditors")
    assert D(pay["totals"]["net"]) == creditors


def test_sales_order_billed_and_balance(client, as_user):
    b = _books(client, as_user)["b"]
    acc = as_user("accounts1")
    so_id = b["sales_order_id"]
    row = next(r for r in run(client, acc, "sales_order_register")["rows"] if r["_link"].endswith(so_id))
    assert D(row["billed"]) == D(b["taxable"]) - 1000
    assert D(row["balance"]) == D(row["value"]) - D(row["billed"])


# ------------------------------------------------------------------ permissions & scope
def test_report_permissions(client, as_user):
    sales = as_user("sales1")
    cat = catalog(client, sales)
    assert "lead_register" in cat and "quotation_register" in cat
    for key in ("sales_register", "credit_note_register", "supplier_bill_register", "billing_vs_collections",
                "payables_ageing", "expense_claim_register", "leave_register", "stock_summary"):
        assert key not in cat
        assert client.get(f"{API}/reports/{key}", headers=sales).status_code == 403, key
        assert client.get(f"{API}/reports/{key}/export", headers=sales, params={"format": "pdf"}).status_code == 403
    acc = as_user("accounts1")
    acc_cat = catalog(client, acc)
    for key in ("sales_register", "credit_note_register", "receipt_register", "receivables_ageing", "payables_ageing",
                "supplier_bill_register", "supplier_payment_register", "expense_claim_register",
                "billing_vs_collections", "stock_summary"):
        assert key in acc_cat, key
    assert "lead_register" not in acc_cat and "leave_register" not in acc_cat
    # an employee's own claims, leave and attendance are on their own pages; no reports for them
    assert get(client, as_user("employee1"), "/reports") == []
    assert client.get(f"{API}/reports/expense_claim_register", headers=as_user("employee1")).status_code == 403
    hr = catalog(client, as_user("hr1"))
    assert {"leave_register", "attendance_summary", "headcount"} <= set(hr) and "sales_register" not in hr
    assert client.get(f"{API}/reports/nope", headers=acc).status_code == 404
    # option lists only for filters of reports the user can run
    assert client.get(f"{API}/reports/options/suppliers", headers=sales).status_code == 403
    assert len(get(client, sales, "/reports/options/customers")) > 0


def test_lead_register_respects_own_scope(client, as_user, owner_engine):
    with owner_engine.connect() as c:
        ids = dict(c.execute(text("select username, id::text from users where username in ('sales1','sales2')")).all())
        total = c.execute(text("select count(*) from leads")).scalar()
        own = c.execute(text("select count(*) from leads where sales_person_id = :u or created_by = :u"),
                        {"u": ids["sales1"]}).scalar()
    assert 0 < own < total
    rows = run(client, as_user("sales1"), "lead_register", date_from="", date_to="")["rows"]
    assert len(rows) == own
    assert run(client, as_user("director"), "lead_register", date_from="", date_to="")["row_count"] == total
    conv = run(client, as_user("sales1"), "lead_conversion", date_from="", date_to="")
    assert conv["totals"]["leads"] == own


# ------------------------------------------------------------------ filters
def test_filters_date_range_and_customer(client, as_user):
    books = _books(client, as_user)
    acc = as_user("accounts1")
    cust = books["a"]["customer_id"]
    all_rows = run(client, acc, "sales_register", date_from="2020-04-01", date_to="2035-03-31")
    one = run(client, acc, "sales_register", date_from="2020-04-01", date_to="2035-03-31", customer_id=cust)
    assert 0 < one["row_count"] <= all_rows["row_count"]
    assert len({r["customer"] for r in one["rows"]}) == 1
    assert one["filters_applied"]["customer_id"] == cust and "Customer:" in one["filters_label"]
    # a period with nothing in it
    empty = run(client, acc, "sales_register", date_from="2001-04-01", date_to="2001-04-30")
    assert empty["rows"] == [] and empty["totals"]["taxable"] == "0.00"
    # defaults: the sales register opens on the current month; the lead register on the financial year
    d = catalog(client, acc)["sales_register"]
    period = next(x for x in d["filters"] if x["name"] == "period")
    assert period["default"]["date_from"].endswith("-01")
    # bad values are refused, not ignored
    r = client.get(f"{API}/reports/sales_register", headers=acc, params={"date_from": "31-12-2026"})
    assert r.status_code == 400 and r.json()["error"]["code"] == "INVALID_FILTER"
    r = client.get(f"{API}/reports/receipt_register", headers=acc, params={"status": "bogus"})
    assert r.status_code == 400
    r = client.get(f"{API}/reports/sales_register", headers=acc, params={"date_from": "2026-05-01", "date_to": "2026-04-01"})
    assert r.status_code == 400


def test_task_register_group_by_assignee(client, as_user):
    pm = as_user("pm1")
    detail = run(client, pm, "task_register", date_from="", date_to="")
    summary = run(client, pm, "task_register", group_by="assignee", date_from="", date_to="")
    assert [c["key"] for c in summary["columns"]][:2] == ["assignee", "total"]

    assert summary["totals"]["total"] == detail["row_count"]


def test_every_report_runs_and_exports_for_each_role(client, as_user):
    """Each demo role: every report in its own catalog runs, and exports to Excel and PDF; nothing else is offered."""
    from app.reports.registry import REPORTS

    seen = set()
    for user in ("manager", "sales1", "sales2", "pm1", "engineer1", "purchase1", "store1", "accounts1", "hr1"):
        h = as_user(user)
        cat = catalog(client, h)
        seen |= set(cat)
        for key in cat:
            res = run(client, h, key)
            assert res["row_count"] == len(res["rows"]), (user, key)
            for fmt, magic in (("xlsx", b"PK"), ("pdf", b"%PDF")):
                r = client.get(f"{API}/reports/{key}/export", headers=h, params={"format": fmt})
                assert r.status_code == 200 and r.content[:len(magic)] == magic, (user, key, fmt, r.text[:200])
        for key in set(REPORTS) - set(cat):
            assert client.get(f"{API}/reports/{key}", headers=h).status_code == 403, (user, key)
    assert seen == set(REPORTS)          # every report is reachable by some standard role besides the director


def test_gst_and_sales_reconcile_with_the_journal(client, as_user, owner_engine):
    """Sales register / GST summary = the Output GST and Sales ledgers; input GST = the Input GST ledgers;
    payables report = unpaid supplier bills = the creditors ledger; stock summary = the stock ledger."""
    _books(client, as_user)
    acc = as_user("accounts1")
    period = {"date_from": "2020-04-01", "date_to": "2035-03-31"}
    gst = get(client, acc, "/finance/gst-summary", **period)
    with owner_engine.connect() as c:
        led = dict(c.execute(text("""select a.system_key, coalesce(sum(l.credit - l.debit), 0) from ledger_accounts a
                                     left join journal_lines l on l.account_id = a.id
                                     where a.system_key is not null group by a.system_key""")).all())
        stock_ledger = c.execute(text("select coalesce(sum(value), 0) from stock_transactions")).scalar()
        bills_open = c.execute(text("select coalesce(sum(grand_total - paid), 0) from supplier_invoices "
                                    "where status = 'posted' and payment_status <> 'paid'")).scalar()
    for k in ("cgst", "sgst", "igst"):
        assert D(gst["net_output"][k]) == led[f"output_{k}"], k
        assert D(gst["input_total"][k]) == -led[f"input_{k}"], k
    reg = run(client, acc, "sales_register", **period)
    cn = run(client, acc, "credit_note_register", **period)
    assert D(reg["totals"]["taxable"]) - D(cn["totals"]["taxable"]) == led["sales"]
    assert D(run(client, acc, "stock_summary")["totals"]["value"]) == stock_ledger
    pay = run(client, acc, "payables_ageing")
    assert D(pay["totals"]["outstanding"]) == bills_open
    bills = run(client, acc, "supplier_bill_register", **period)
    assert D(bills["totals"]["balance"]) == bills_open
