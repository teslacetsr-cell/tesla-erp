"""On-premise mode: NAS/folder storage, serving the UI, cookies over LAN vs tunnel, system status."""
import io

import pytest
from fastapi.testclient import TestClient

from app.core.config import Settings, get_settings
from app.platform.documents import storage as storage_mod
from app.platform.documents.storage import FilesystemStorage
from tests.conftest import DEMO_PASSWORD

PDF = b"%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n"


# ------------------------------------------------------------------ NAS / folder storage
def test_filesystem_storage_is_atomic_and_never_overwrites(tmp_path):
    fs = FilesystemStorage(str(tmp_path / "nas"))
    fs.put("customer/1/a/v1-x.pdf", PDF, "application/pdf")
    assert fs.get("customer/1/a/v1-x.pdf") == PDF
    assert not list((tmp_path / "nas").rglob("*.part"))  # no temp files left behind
    with pytest.raises(FileExistsError):
        fs.put("customer/1/a/v1-x.pdf", b"other", "application/pdf")
    for bad in ("../escape.pdf", "/etc/passwd", "a/../../b"):
        with pytest.raises(ValueError):
            fs.put(bad, b"x", "text/plain")
    assert fs.health() == (True, "writable")


def test_filesystem_storage_reports_unreachable_share(tmp_path):
    blocker = tmp_path / "not-a-dir"
    blocker.write_text("file, not folder")
    ok, detail = FilesystemStorage(str(blocker)).health()
    assert ok is False and detail


def test_documents_flow_through_nas_storage(client, admin_headers, tmp_path):
    storage_mod.set_storage(FilesystemStorage(str(tmp_path / "nas")))
    try:
        cid = client.get("/api/v1/customers", headers=admin_headers, params={"q": "ABC"}).json()["data"][0]["id"]
        up = client.post("/api/v1/documents", headers=admin_headers,
                         data={"entity_type": "customer", "entity_id": cid, "category": "drawing"},
                         files={"file": ("layout.pdf", io.BytesIO(PDF), "application/pdf")})
        assert up.status_code == 201, up.text
        files = [p for p in (tmp_path / "nas").rglob("*.pdf")]
        assert len(files) == 1 and files[0].read_bytes() == PDF
        dl = client.get(f"/api/v1/documents/{up.json()['data']['id']}/download", headers=admin_headers).json()["data"]
        assert dl["url"].endswith("/content")  # permission-checked download through the API
    finally:
        storage_mod.set_storage(None)


# ------------------------------------------------------------------ configuration guard
def test_onprem_production_config_rules():
    good = dict(environment="production", deployment="onprem", storage_backend="filesystem",
                storage_path=r"\\NAS\TCE-ERP\documents", secret_key="x" * 48,
                field_encryption_key="k7yq8B0pFf3rJjZ2Vb6mV1XnVb2mQv8hT1rWqY3nKxQ=")
    s = Settings(**good)
    assert s.cookie_secure is False  # allowed on-premise: plain HTTP inside the office
    with pytest.raises(ValueError, match="scratch storage"):
        Settings(**good | {"storage_backend": "local"})
    with pytest.raises(ValueError, match="STORAGE_PATH"):
        Settings(**good | {"storage_path": None})
    with pytest.raises(ValueError, match="must be set"):
        Settings(**good | {"secret_key": "dev-only-insecure-secret-change-me-0123456789"})
    with pytest.raises(ValueError, match="S3"):
        Settings(**good | {"deployment": "cloud", "cookie_secure": True})


# ------------------------------------------------------------------ cookies: LAN (http) vs tunnel (https)
def test_onprem_cookie_secure_follows_request_scheme(monkeypatch):
    s = get_settings()
    monkeypatch.setattr(s, "deployment", "onprem")
    monkeypatch.setattr(s, "cookie_secure", False)
    from app.main import app

    body = {"login": "manager", "password": DEMO_PASSWORD}
    with TestClient(app, base_url="http://tce-erp:8080") as lan:
        r = lan.post("/api/v1/auth/login", json=body)
        assert r.status_code == 200
        assert "secure" not in r.headers.get("set-cookie", "").lower()
    with TestClient(app, base_url="https://erp.example.in") as remote:
        r = remote.post("/api/v1/auth/login", json=body)
        cookies = r.headers.get_list("set-cookie")
        assert cookies and all("secure" in c.lower() for c in cookies)


def test_client_ip_from_tunnel_only_when_proxy_is_local(monkeypatch, owner_engine):
    from sqlalchemy import text

    s = get_settings()
    monkeypatch.setattr(s, "deployment", "onprem")
    from app.main import app

    with TestClient(app, client=("127.0.0.1", 50000)) as via_tunnel:
        via_tunnel.post("/api/v1/auth/login", json={"login": "hr1", "password": DEMO_PASSWORD},
                        headers={"CF-Connecting-IP": "203.0.113.9"})
    with TestClient(app, client=("192.168.1.50", 50000)) as lan:
        lan.post("/api/v1/auth/login", json={"login": "hr1", "password": DEMO_PASSWORD},
                 headers={"CF-Connecting-IP": "198.51.100.1"})  # spoofed by a LAN machine: ignored
    with owner_engine.connect() as c:
        ips = [str(r[0]) for r in c.execute(text("select ip from audit_logs where action='login' order by id"))]
    assert ips[-2:] == ["203.0.113.9", "192.168.1.50"]


# ------------------------------------------------------------------ serving the web UI from the API process
def test_ui_served_with_its_own_csp(monkeypatch, tmp_path):
    ui = tmp_path / "ui"
    (ui / "customers" / "view").mkdir(parents=True)
    (ui / "_next" / "static").mkdir(parents=True)
    (ui / "index.html").write_text("<html>home</html>")
    (ui / "404.html").write_text("<html>missing</html>")
    (ui / "customers" / "view" / "index.html").write_text("<html>customer</html>")
    (ui / "_next" / "static" / "app.js").write_text("console.log(1)")
    monkeypatch.setattr(get_settings(), "frontend_dir", str(ui))
    from app.main import create_app

    with TestClient(create_app()) as c:
        r = c.get("/customers/view/?id=123")
        assert r.status_code == 200 and "customer" in r.text
        assert "script-src 'self'" in r.headers["content-security-policy"]
        assert r.headers["cache-control"] == "no-cache"
        js = c.get("/_next/static/app.js")
        assert "immutable" in js.headers["cache-control"]
        assert c.head("/customers/view/").status_code == 200
        assert c.get("/does-not-exist").status_code == 404
        assert c.get("/../../etc/passwd").status_code == 404
        api = c.get("/api/v1/auth/me")
        assert api.status_code == 401 and api.headers["content-security-policy"].startswith("default-src 'none'")
        assert c.get("/api/v1/nope").json()["error"]["code"] == "NOT_FOUND"


# ------------------------------------------------------------------ status page data
def test_system_status_reports_storage_and_backup(client, admin_headers, monkeypatch, tmp_path):
    status = tmp_path / "status.json"
    status.write_text('{"backup": {"last_success": "2026-09-25T01:00:05+05:30", "file": "tce_erp_x.dump"}}')
    monkeypatch.setattr(get_settings(), "status_file", str(status))
    storage_mod.set_storage(FilesystemStorage(str(tmp_path / "nas")))
    try:
        d = client.get("/api/v1/system/status", headers=admin_headers).json()["data"]
        assert d["storage"]["ok"] is True
        assert d["backup"]["file"] == "tce_erp_x.dump"
        assert d["database"]["size"]
    finally:
        storage_mod.set_storage(None)
