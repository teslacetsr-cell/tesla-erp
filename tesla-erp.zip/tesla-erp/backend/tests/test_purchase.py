"""Phase 5: procurement and inventory (Spec §19–§21) — PO calculation, approvals, MR → PR → PO → GRN → stock,
weighted average cost, serial numbers, negative stock, the append-only ledger and its rebuild."""
import threading
from decimal import Decimal as D

import pytest
from sqlalchemy import create_engine, select, text

API = "/api/v1"


def get(client, h, path, **params):
    r = client.get(f"{API}{path}", headers=h, params=params)
    assert r.status_code == 200, r.text
    return r.json()["data"]


def post(client, h, path, body=None, status=(200, 201)):
    r = client.post(f"{API}{path}", headers=h, json=body or {})
    assert r.status_code in status, r.text
    return r.json()["data"]


def item(client, h, code) -> dict:
    return [i for i in get(client, h, "/items", q=code) if i["item_code"] == code][0]


def wh(client, h, code) -> dict:
    return [w for w in get(client, h, "/warehouses", page_size=100) if w["code"] == code][0]


def supplier(client, h, name="DEHN") -> dict:
    return get(client, h, "/suppliers", q=name)[0]


def po_line(it, qty, rate, disc="0", **kw):
    return {"item_id": it["id"], "description": it["item_name"], "quantity": qty, "unit": it["unit"], "rate": rate,
            "discount_pct": disc, "tax_rate": "18", "hsn_sac": "85363000"} | kw


def stock_of(client, h, item_id, warehouse_id=None) -> D:
    rows = get(client, h, f"/stock/items/{item_id}")["warehouses"]
    if warehouse_id is None:
        return sum((D(r["quantity"]) for r in rows), D(0))
    return next((D(r["quantity"]) for r in rows if r["warehouse"]["id"] == warehouse_id), D(0))


def approve_all(client, as_user, entity_label_part: str):
    """Decide every pending step for a document whose label contains the text (manager, then director)."""
    for user in ("manager", "director"):
        h = as_user(user)
        for req in get(client, h, "/approvals/inbox"):
            if entity_label_part in req["entity_label"]:
                post(client, h, f"/approvals/{req['id']}/decide", {"decision": "approved"})


# ------------------------------------------------------------------ PO calculation & approval
def test_po_calculation_intra_and_inter_state(client, as_user):
    h = as_user("purchase1")
    spd, main = item(client, h, "DEHN-SPD-T12"), wh(client, h, "MAIN")
    local = post(client, h, "/suppliers", {"supplier_name": "Kerala Electricals", "state_code": "32"})
    lines = [po_line(spd, "10", "1000", "10"), po_line(spd, "1", "5000", "0", description="Mounting kit")]
    po = post(client, h, "/purchase-orders", {"supplier_id": local["id"], "warehouse_id": main["id"], "items": lines})
    assert (po["gross"], po["line_discount"], po["taxable"]) == ("15000.00", "1000.00", "14000.00")
    assert (po["cgst"], po["sgst"], po["igst"], po["grand_total"]) == ("1260.00", "1260.00", "0.00", "16520.00")
    assert po["po_number"] is None and po["display_number"] == "DRAFT" and po["inter_state"] is False
    po2 = post(client, h, "/purchase-orders", {"supplier_id": supplier(client, h)["id"], "warehouse_id": main["id"],
                                                "special_discount": "400", "items": lines})
    assert po2["inter_state"] is True and (po2["igst"], po2["cgst"]) == ("2448.00", "0.00")  # (14000 − 400) × 18 %
    assert po2["taxable"] == "13600.00" and po2["grand_total"] == "16048.00"
    # the payment terms default from the supplier
    assert po2["payment_terms"] == "30 days from invoice"


def test_po_approval_limits(client, as_user):
    h = as_user("purchase1")
    spd, main, dehn = item(client, h, "DEHN-SPD-T12"), wh(client, h, "MAIN"), supplier(client, h)
    small = post(client, h, "/purchase-orders", {"supplier_id": dehn["id"], "warehouse_id": main["id"],
                                                 "items": [po_line(spd, "2", "14200")]})
    small = post(client, h, f"/purchase-orders/{small['id']}/submit")
    assert small["status"] == "pending_approval" and small["po_number"].startswith("TCE/PO/")
    assert small["approval"]["steps"] == ["MANAGER"]
    assert client.post(f"{API}/approvals/{small['approval']['id']}/decide", headers=h,
                       json={"decision": "approved"}).status_code == 403  # purchase cannot approve
    big = post(client, h, "/purchase-orders", {"supplier_id": dehn["id"], "warehouse_id": main["id"],
                                               "items": [po_line(spd, "20", "14200")]})
    big = post(client, h, f"/purchase-orders/{big['id']}/submit")
    assert big["approval"]["steps"] == ["MANAGER", "DIRECTOR"]  # ₹2,84,000 > ₹2 lakh
    m = as_user("manager")
    post(client, m, f"/approvals/{big['approval']['id']}/decide", {"decision": "approved"})
    assert get(client, h, f"/purchase-orders/{big['id']}")["status"] == "pending_approval"
    post(client, as_user("director"), f"/approvals/{big['approval']['id']}/decide", {"decision": "approved"})
    big = get(client, h, f"/purchase-orders/{big['id']}")
    assert big["status"] == "approved" and big["can"]["send"]
    # nothing moves stock until goods are received
    assert stock_of(client, h, spd["id"], main["id"]) == 3
    # rejection returns the PO to draft with the comment
    post(client, m, f"/approvals/{small['approval']['id']}/decide", {"decision": "rejected", "comment": "Get 3 quotes"})
    small = get(client, h, f"/purchase-orders/{small['id']}")
    assert small["status"] == "draft" and small["last_rejection"] == "Get 3 quotes"


# ------------------------------------------------------------------ MR → PR → PO → GRN → stock
def test_material_request_to_stock_end_to_end(client, as_user):
    eng, buyer, store = as_user("engineer1"), as_user("purchase1"), as_user("store1")
    prj = get(client, as_user("pm1"), "/projects", q="ABC Hospital Lightning")[0]
    boq = get(client, as_user("pm1"), f"/projects/{prj['id']}/boq")
    at = item(client, eng, "LP-AT-16")
    mr = post(client, eng, "/material-requests", {"project_id": prj["id"], "lines": [
        {"item_id": at["id"], "description": at["item_name"], "unit": "NOS", "quantity": "12",
         "project_boq_line_id": boq[0]["id"]}]})
    assert mr["warehouse"]["type"] == "site"  # defaults to the project's site store
    mr = post(client, eng, f"/material-requests/{mr['id']}/submit")
    assert mr["mr_number"].startswith("TCE/MR/") and mr["status"] == "submitted"
    assert D(mr["lines"][0]["stock_total"]) > 0  # the store can see stock exists
    ml = mr["lines"][0]
    # purchase: PR from the MR line (cannot ask for more than requested)
    body = {"project_id": prj["id"], "warehouse_id": mr["warehouse"]["id"], "lines": [
        {"item_id": at["id"], "description": at["item_name"], "unit": "NOS", "quantity": "13", "estimated_rate": "1850",
         "mr_line_id": ml["id"]}]}
    r = client.post(f"{API}/purchase-requests", headers=buyer, json=body)
    assert r.json()["error"]["code"] == "OVER_REQUEST"
    body["lines"][0]["quantity"] = "12"
    pr = post(client, buyer, "/purchase-requests", body)
    assert pr["estimated_value"] == "22200.00"
    assert get(client, eng, f"/material-requests/{mr['id']}")["status"] == "closed"  # fully taken up
    pr = post(client, buyer, f"/purchase-requests/{pr['id']}/submit")
    assert pr["status"] == "pending_approval"
    approve_all(client, as_user, pr["pr_number"])
    pr = get(client, buyer, f"/purchase-requests/{pr['id']}")
    assert pr["status"] == "approved"
    # PO from the PR line, delivered to the site store; 5 % discount
    po = post(client, buyer, "/purchase-orders", {
        "supplier_id": supplier(client, buyer)["id"], "project_id": prj["id"], "warehouse_id": mr["warehouse"]["id"],
        "items": [po_line(at, "12", "1900", "5", pr_line_id=pr["lines"][0]["id"])]})
    assert get(client, buyer, f"/purchase-requests/{pr['id']}")["status"] == "ordered"
    assert po["items"][0]["project_boq_line_id"] == boq[0]["id"]  # carried through from the MR
    po = post(client, buyer, f"/purchase-orders/{po['id']}/submit")
    approve_all(client, as_user, po["po_number"])
    po = post(client, buyer, f"/purchase-orders/{po['id']}/send")
    assert po["status"] == "sent"
    net = D(po["items"][0]["net_rate"])
    assert net == D("1805.0000")  # 1900 less 5 %, before GST (GST is input credit, not stock cost)
    site = mr["warehouse"]["id"]
    before = stock_of(client, store, at["id"], site)
    before_value = D(next(w["value"] for w in get(client, store, f"/stock/items/{at['id']}")["warehouses"]
                          if w["warehouse"]["id"] == site))
    pl = po["items"][0]["id"]
    # over-receipt blocked; a rejected quantity needs a reason
    r = client.post(f"{API}/grns", headers=store, json={"purchase_order_id": po["id"], "lines": [
        {"po_line_id": pl, "accepted_qty": "13"}]})
    assert r.json()["error"]["code"] == "OVER_RECEIPT"
    r = client.post(f"{API}/grns", headers=store, json={"purchase_order_id": po["id"], "lines": [
        {"po_line_id": pl, "accepted_qty": "7", "rejected_qty": "1"}]})
    assert r.status_code == 422
    g1 = post(client, store, "/grns", {"purchase_order_id": po["id"], "supplier_invoice_no": "INV-1", "lines": [
        {"po_line_id": pl, "accepted_qty": "7", "rejected_qty": "1", "rejection_reason": "Bent rod"}]})
    assert g1["grn_number"].startswith("TCE/GRN/") and g1["value"] == "12635.00"  # 7 × 1805
    po = get(client, buyer, f"/purchase-orders/{po['id']}")
    assert po["status"] == "partially_received" and po["items"][0]["pending_qty"] == "5"
    assert po["items"][0]["rejected_qty"] == "1"
    assert stock_of(client, store, at["id"], site) == before + 7
    g2 = post(client, store, "/grns", {"purchase_order_id": po["id"], "lines": [{"po_line_id": pl, "accepted_qty": "5"}]})
    po = get(client, buyer, f"/purchase-orders/{po['id']}")
    assert po["status"] == "received" and not po["can"]["receive"]
    after = get(client, store, f"/stock/items/{at['id']}")["warehouses"]
    site_row = next(w for w in after if w["warehouse"]["id"] == site)
    assert D(site_row["quantity"]) == before + 12
    assert D(site_row["value"]) == before_value + D("12635.00") + D(g2["value"])
    # ledger rows point back to the GRNs; project BOQ shows the procured quantity
    led = get(client, store, "/stock/ledger", item_id=at["id"], warehouse_id=site, txn_type="grn")
    assert {x["source_number"] for x in led} == {g1["grn_number"], g2["grn_number"]}
    boq_after = get(client, as_user("pm1"), f"/projects/{prj['id']}/boq")
    assert D(boq_after[0]["procured_qty"]) == D(boq[0]["procured_qty"]) + 12
    assert client.get(f"{API}/grns/{g1['id']}/pdf", headers=store).content[:4] == b"%PDF"
    assert client.get(f"{API}/purchase-orders/{po['id']}/pdf", headers=buyer).content[:4] == b"%PDF"
    assert get(client, store, "/stock/verify")["ok"] is True


def test_service_lines_are_received_but_not_stocked(client, as_user):
    h = as_user("purchase1")
    svc = item(client, h, "SVC-LPS-INST")
    po = post(client, h, "/purchase-orders", {"supplier_id": supplier(client, h)["id"], "warehouse_id": wh(client, h, "MAIN")["id"],
                                              "items": [po_line(svc, "1", "12000", unit="JOB", hsn_sac="995461")]})
    po = post(client, h, f"/purchase-orders/{po['id']}/submit")
    approve_all(client, as_user, po["po_number"])
    g = post(client, as_user("store1"), "/grns", {"purchase_order_id": po["id"], "lines": [
        {"po_line_id": po["items"][0]["id"], "accepted_qty": "1"}]})
    assert g["lines"][0]["stocked"] is False
    assert get(client, h, f"/purchase-orders/{po['id']}")["status"] == "received"


# ------------------------------------------------------------------ serial numbers
def test_serial_numbers_unique_and_counted(client, as_user):
    buyer, store = as_user("purchase1"), as_user("store1")
    spd, main = item(client, buyer, "DEHN-SPD-T12"), wh(client, buyer, "MAIN")
    po = post(client, buyer, "/purchase-orders", {"supplier_id": supplier(client, buyer)["id"], "warehouse_id": main["id"],
                                                  "items": [po_line(spd, "2", "14200")]})
    po = post(client, buyer, f"/purchase-orders/{po['id']}/submit")
    approve_all(client, as_user, po["po_number"])
    pl = po["items"][0]["id"]
    r = client.post(f"{API}/grns", headers=store, json={"purchase_order_id": po["id"], "lines": [
        {"po_line_id": pl, "accepted_qty": "2", "serial_nos": ["NEW-1"]}]})
    assert r.json()["error"]["code"] == "SERIALS_REQUIRED"
    r = client.post(f"{API}/grns", headers=store, json={"purchase_order_id": po["id"], "lines": [
        {"po_line_id": pl, "accepted_qty": "2", "serial_nos": ["NEW-1", "DV2026090"]}]})  # DV2026090 is in stock
    assert r.status_code == 409 and r.json()["error"]["code"] == "DUPLICATE_SERIAL"
    # nothing was saved by the failed attempt
    assert get(client, buyer, f"/purchase-orders/{po['id']}")["items"][0]["received_qty"] == "0"
    post(client, store, "/grns", {"purchase_order_id": po["id"], "lines": [
        {"po_line_id": pl, "accepted_qty": "2", "serial_nos": ["NEW-1", "NEW-2"]}]})
    serials = get(client, store, "/stock/serials", item_id=spd["id"], warehouse_id=main["id"])
    assert {"NEW-1", "NEW-2", "DV2026090"} <= set(serials)
    # a serial moves with a transfer, and must be in stock at the source
    site = wh(client, store, "SITE-202627-0001")
    r = client.post(f"{API}/stock-transfers", headers=store, json={
        "from_warehouse_id": main["id"], "to_warehouse_id": site["id"], "post": True,
        "lines": [{"item_id": spd["id"], "quantity": "1", "serial_nos": ["DV2026311"]}]})  # that one is at site
    assert r.json()["error"]["code"] == "SERIAL_NOT_IN_STOCK"
    post(client, store, "/stock-transfers", {"from_warehouse_id": main["id"], "to_warehouse_id": site["id"], "post": True,
                                             "lines": [{"item_id": spd["id"], "quantity": "1", "serial_nos": ["NEW-2"]}]})
    assert "NEW-2" in get(client, store, "/stock/serials", item_id=spd["id"], warehouse_id=site["id"])


# ------------------------------------------------------------------ valuation, negative stock, transfers
def test_weighted_average_and_transfer_moves_value(client, as_user):
    store = as_user("store1")
    gi, main = item(client, store, "EA-GI-50X6"), wh(client, store, "MAIN")
    site = wh(client, store, "SITE-202627-0001")
    # opening had 300 m at ₹158; add 100 m at ₹170 → average (47400 + 17000) / 400 = ₹161
    adj = post(client, store, "/stock-adjustments", {"warehouse_id": main["id"], "reason_type": "found",
                                                     "reason": "Found in the yard during count",
                                                     "lines": [{"item_id": gi["id"], "quantity": "100", "unit_cost": "170"}]})
    adj = post(client, store, f"/stock-adjustments/{adj['id']}/submit")
    assert adj["status"] == "pending_approval"
    approve_all(client, as_user, adj["adjustment_number"])
    row = next(w for w in get(client, store, f"/stock/items/{gi['id']}")["warehouses"] if w["warehouse"]["id"] == main["id"])
    assert (row["quantity"], row["value"], row["average_cost"]) == ("400", "64400.00", "161.0000")
    t = post(client, store, "/stock-transfers", {"from_warehouse_id": main["id"], "to_warehouse_id": site["id"], "post": True,
                                                 "lines": [{"item_id": gi["id"], "quantity": "80"}]})
    assert t["status"] == "posted" and t["transfer_number"].startswith("TCE/TRF/") and t["lines"][0]["unit_cost"] == "161.0000"
    rows = {w["warehouse"]["id"]: w for w in get(client, store, f"/stock/items/{gi['id']}")["warehouses"]}
    assert (rows[main["id"]]["quantity"], rows[main["id"]]["value"]) == ("320", "51520.00")
    assert (rows[site["id"]]["quantity"], rows[site["id"]]["value"]) == ("80", "12880.00")
    # emptying a balance leaves exactly zero value (no rounding residue)
    post(client, store, "/stock-transfers", {"from_warehouse_id": site["id"], "to_warehouse_id": main["id"], "post": True,
                                             "lines": [{"item_id": gi["id"], "quantity": "80"}]})
    rows = {w["warehouse"]["id"]: w for w in get(client, store, f"/stock/items/{gi['id']}")["warehouses"]}
    assert site["id"] not in rows and rows[main["id"]]["value"] == "64400.00"
    assert get(client, store, "/stock/verify")["ok"] is True


def test_negative_stock_blocked(client, as_user):
    store = as_user("store1")
    elec, main, site = item(client, store, "EA-ELEC-3M"), wh(client, store, "MAIN"), wh(client, store, "SITE-202627-0001")
    r = client.post(f"{API}/stock-transfers", headers=store, json={
        "from_warehouse_id": main["id"], "to_warehouse_id": site["id"], "post": True,
        "lines": [{"item_id": elec["id"], "quantity": "5"}]})  # only 4 in the main store
    assert r.status_code == 409 and r.json()["error"]["code"] == "INSUFFICIENT_STOCK"
    assert stock_of(client, store, elec["id"], main["id"]) == 4
    # removing stock by adjustment is checked at posting time too
    adj = post(client, store, "/stock-adjustments", {"warehouse_id": main["id"], "reason_type": "damage", "reason": "Crushed",
                                                     "lines": [{"item_id": elec["id"], "quantity": "-9"}]})
    adj = post(client, store, f"/stock-adjustments/{adj['id']}/submit")
    req = adj["approval"]["id"]
    r = client.post(f"{API}/approvals/{req}/decide", headers=as_user("manager"), json={"decision": "approved"})
    assert r.status_code == 409 and r.json()["error"]["code"] == "INSUFFICIENT_STOCK"
    assert get(client, store, f"/stock-adjustments/{adj['id']}")["status"] == "pending_approval"


def test_adjustments_need_approval_and_opening_import(client, as_user):
    store = as_user("store1")
    main = wh(client, store, "MAIN")
    adj = post(client, store, "/stock-adjustments", {"warehouse_id": main["id"], "reason_type": "opening",
                                                     "reason": "Opening stock of the service van"})
    import io

    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.append(["Item code", "Quantity", "Unit cost", "Batch", "Expiry date", "Serial numbers", "Remarks"])
    ws.append(["LP-AT-16", 10, 1800, None, None, None, None])
    ws.append(["SOL-MOD-545", 2, 13000, None, None, "WA-1, WA-2", None])
    ws.append(["NOPE-1", 1, 1, None, None, None, None])
    buf = io.BytesIO()
    wb.save(buf)
    r = client.post(f"{API}/stock-adjustments/{adj['id']}/import", headers=store,
                    files={"file": ("s.xlsx", buf.getvalue(), "application/octet-stream")})
    assert r.json()["error"]["code"] == "IMPORT_ERRORS" and r.json()["error"]["details"][0]["row"] == 4
    ws.delete_rows(4)
    buf = io.BytesIO()
    wb.save(buf)
    r = client.post(f"{API}/stock-adjustments/{adj['id']}/import", headers=store,
                    files={"file": ("s.xlsx", buf.getvalue(), "application/octet-stream")})
    assert r.status_code == 200, r.text
    adj = r.json()["data"]
    assert len(adj["lines"]) == 2 and adj["value"] == "44000.00"
    adj = post(client, store, f"/stock-adjustments/{adj['id']}/submit")
    assert adj["status"] == "pending_approval" and not adj["can"]["decide"]  # the store cannot approve
    post(client, as_user("manager"), f"/approvals/{adj['approval']['id']}/decide", {"decision": "approved"})
    adj = get(client, store, f"/stock-adjustments/{adj['id']}")
    assert adj["status"] == "posted"
    led = get(client, store, "/stock/ledger", q=adj["adjustment_number"])
    assert {x["txn_type"] for x in led} == {"opening"} and len(led) == 2


# ------------------------------------------------------------------ concurrency & the ledger
def _principal(username: str):
    from app.auth.deps import Principal, load_permissions
    from app.core.db import SessionLocal
    from app.users.models import User

    with SessionLocal() as s:
        u = s.scalar(select(User).where(User.username == username))
        perms, roles = load_permissions(s, u.id)
        company = s.execute(text("select id from companies limit 1")).scalar()
        s.expunge(u)
    return Principal(user=u, company_id=company, permissions=perms, role_codes=roles)


def test_two_people_take_the_last_unit_only_one_succeeds(client, as_user):
    """Spec §45: two simultaneous issues of the last unit — exactly one succeeds, stock never goes negative."""
    from app.core.config import get_settings
    from app.inventory import service as inv
    from app.inventory.schemas import TransferIn, TransferLineIn

    store = as_user("store1")
    ev, main, site = item(client, store, "EV-AC-7K"), wh(client, store, "MAIN"), wh(client, store, "SITE-202627-0001")
    # take one of the two chargers out first, so exactly one unit is left
    post(client, store, "/stock-transfers", {"from_warehouse_id": main["id"], "to_warehouse_id": site["id"], "post": True,
                                             "lines": [{"item_id": ev["id"], "quantity": "1", "serial_nos": ["EVW-7K-1101"]}]})
    ev_id = ev["id"]
    p = _principal("store1")
    eng = create_engine(get_settings().database_url, pool_size=10, max_overflow=0)
    barrier = threading.Barrier(2)
    ok, failed = [], []

    def worker(serial: str):
        from sqlalchemy.orm import Session
        try:
            with Session(bind=eng) as s:
                barrier.wait()
                inv.create_transfer(s, p, TransferIn(from_warehouse_id=main["id"], to_warehouse_id=site["id"], post=True,
                                                     lines=[TransferLineIn(item_id=ev_id, quantity=D("1"),
                                                                           serial_nos=[serial])]))
                s.commit()
            ok.append(serial)
        except Exception as exc:  # noqa: BLE001
            failed.append(getattr(exc, "code", type(exc).__name__))

    # both ask for the same last unit (EVW-7K-1102)
    threads = [threading.Thread(target=worker, args=("EVW-7K-1102",)) for _ in range(2)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    eng.dispose()
    assert len(ok) == 1 and len(failed) == 1 and failed[0] in ("INSUFFICIENT_STOCK", "SERIAL_NOT_IN_STOCK")
    assert stock_of(client, store, ev_id, main["id"]) == 0
    assert stock_of(client, store, ev_id, site["id"]) == 2


def test_last_unit_race_without_serials(client, as_user):
    from app.core.config import get_settings
    from app.inventory import service as inv
    from app.inventory.schemas import TransferIn, TransferLineIn

    store = as_user("store1")
    elec, main, site = item(client, store, "EA-ELEC-3M"), wh(client, store, "MAIN"), wh(client, store, "SITE-202627-0001")
    post(client, store, "/stock-transfers", {"from_warehouse_id": main["id"], "to_warehouse_id": site["id"], "post": True,
                                             "lines": [{"item_id": elec["id"], "quantity": "3"}]})  # 1 left
    p = _principal("store1")
    eng = create_engine(get_settings().database_url, pool_size=10, max_overflow=0)
    n = 6
    barrier = threading.Barrier(n)
    ok, failed = [], []

    def worker():
        from sqlalchemy.orm import Session
        try:
            with Session(bind=eng) as s:
                barrier.wait()
                inv.create_transfer(s, p, TransferIn(from_warehouse_id=main["id"], to_warehouse_id=site["id"], post=True,
                                                     lines=[TransferLineIn(item_id=elec["id"], quantity=D("1"))]))
                s.commit()
            ok.append(1)
        except Exception as exc:  # noqa: BLE001
            failed.append(getattr(exc, "code", type(exc).__name__))

    threads = [threading.Thread(target=worker) for _ in range(n)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    eng.dispose()
    assert len(ok) == 1 and failed == ["INSUFFICIENT_STOCK"] * (n - 1)
    assert stock_of(client, store, elec["id"], main["id"]) == 0
    assert get(client, store, "/stock/verify")["ok"] is True


def test_ledger_is_append_only_and_rebuilds_to_the_balances(client, as_user, owner_engine):
    from app.core.db import SessionLocal
    from app.inventory.ledger import verify

    with SessionLocal() as s:  # the application's own database role
        with pytest.raises(Exception, match="permission denied"):
            s.execute(text("update stock_transactions set quantity = quantity + 1"))
        s.rollback()
        with pytest.raises(Exception, match="permission denied"):
            s.execute(text("delete from stock_transactions"))
        s.rollback()
        assert verify(s) == []
        # every balance equals the sum of its ledger rows, quantity and value
        rows = s.execute(text("""
            select b.quantity, b.value, coalesce(sum(t.quantity), 0), coalesce(sum(t.value), 0)
            from stock_balances b left join stock_transactions t
              on t.item_id = b.item_id and t.warehouse_id = b.warehouse_id
            group by b.id""")).all()
        assert rows and all(q == lq and v == lv for q, v, lq, lv in rows)
    # tampering with a cached balance is detected
    with owner_engine.begin() as c:
        c.execute(text("update stock_balances set quantity = quantity + 1 where id = (select id from stock_balances limit 1)"))
    assert get(client, as_user("store1"), "/stock/verify")["ok"] is False


# ------------------------------------------------------------------ scope, site store, low stock
def test_material_request_scope_and_site_store(client, as_user):
    eng, pm = as_user("engineer1"), as_user("pm1")
    mine = get(client, eng, "/material-requests")
    assert mine and all(m["requested_by"].startswith("Arjun") for m in mine)
    other = post(client, pm, "/material-requests", {"lines": [{"description": "Cable ties", "unit": "PKT", "quantity": "5"}]})
    assert client.get(f"{API}/material-requests/{other['id']}", headers=eng).status_code == 403
    assert client.post(f"{API}/material-requests/{mine[0]['id']}/reject", headers=eng,
                       json={"reason": "no"}).status_code == 403  # only purchase/store/managers process requests
    prj = get(client, pm, "/projects", q="ABC Hospital Lightning")[0]
    r = client.post(f"{API}/projects/{prj['id']}/site-store", headers=pm)
    assert r.json()["error"]["code"] == "SITE_STORE_EXISTS"
    mats = get(client, pm, f"/projects/{prj['id']}/materials")
    assert mats["site_store"]["code"] == "SITE-202627-0001" and mats["site_stock"]
    assert mats["purchase_orders"] and mats["material_requests"]


def test_low_stock_list(client, as_user):
    store = as_user("store1")
    s = get(client, store, "/stock/summary")
    assert s["out_of_stock"] >= 1 and s["below_reorder"] >= 1  # solar modules none; electrodes 4 < minimum 5
    low = {r["item"]["code"]: r["status"] for r in get(client, store, "/stock/items", status="low", page_size=100)}
    assert low["SOL-MOD-545"] == "out" and "LP-CT-25X3" not in low
    x = client.get(f"{API}/stock/items/export", headers=store)
    assert x.status_code == 200 and x.content[:2] == b"PK"
