"""Platform services: audit log, numbering, documents, settings, jobs."""
import io
import threading
import uuid
from datetime import date

import pytest
from sqlalchemy import create_engine, select, text
from sqlalchemy.exc import DBAPIError, ProgrammingError

from app.company.models import Company
from app.core.config import get_settings
from app.core.db import SessionLocal
from app.core.errors import AppError
from app.core.india import financial_year, gstin_check_char, validate_gstin
from app.core.money import format_inr, round_to_rupee
from app.platform.jobs.models import Job
from app.platform.jobs.service import enqueue, run_pending
from app.platform.numbering import service as numbering


def _company_id():
    with SessionLocal() as s:
        return s.scalar(select(Company.id).where(Company.code == "TCE"))


# ------------------------------------------------------------------ audit
def test_changes_are_audited_with_old_and_new_values(client, admin_headers):
    items = client.get("/api/v1/items", headers=admin_headers, params={"q": "DEHN SPD"}).json()["data"]
    item = items[0]
    body = {k: item[k] for k in ("item_name", "item_type", "category_id", "unit_id", "hsn_sac", "tax_rate_id",
                                 "brand_id", "model", "minimum_stock", "reorder_level", "row_version")}
    body["selling_price"] = "16500"
    r = client.put(f"/api/v1/items/{item['id']}", headers=admin_headers, json=body)
    assert r.status_code == 200, r.text
    logs = client.get("/api/v1/audit-logs", headers=admin_headers,
                      params={"entity_type": "item", "entity_id": item["id"]}).json()["data"]
    assert logs[0]["action"] == "update"
    assert logs[0]["changes"]["selling_price"] == {"old": "16000.0000", "new": "16500.0000"}
    assert logs[0]["user_name"] == "System Administrator"


def test_audit_log_is_append_only_for_app_role():
    with SessionLocal() as s:
        with pytest.raises(ProgrammingError):
            s.execute(text("UPDATE audit_logs SET summary = 'tampered'"))
        s.rollback()
        with pytest.raises(ProgrammingError):
            s.execute(text("DELETE FROM audit_logs"))
        s.rollback()


def test_audit_log_is_append_only_even_for_owner(owner_engine):
    with owner_engine.connect() as c:
        with pytest.raises(DBAPIError, match="append-only"):
            c.execute(text("UPDATE audit_logs SET summary = 'tampered'"))
        c.rollback()
        with pytest.raises(DBAPIError, match="append-only"):
            c.execute(text("TRUNCATE audit_logs"))
        c.rollback()


def test_failed_change_leaves_no_audit_record(client, admin_headers):
    before = client.get("/api/v1/audit-logs", headers=admin_headers).json()["meta"]["total"]
    r = client.post("/api/v1/items", headers=admin_headers, json={
        "item_name": "Bad", "category_id": str(uuid.uuid4()), "unit_id": str(uuid.uuid4())})
    assert r.status_code == 400
    after = client.get("/api/v1/audit-logs", headers=admin_headers).json()["meta"]["total"]
    assert after == before


# ------------------------------------------------------------------ numbering
def test_financial_year():
    assert financial_year(date(2026, 9, 25)) == (2026, 2027)
    assert financial_year(date(2027, 3, 31)) == (2026, 2027)
    assert financial_year(date(2027, 4, 1)) == (2027, 2028)


def test_number_formats_use_financial_year():
    d = date(2026, 9, 25)
    assert numbering.render("TCE/QTN/{FY}/{SEQ:4}", 1, d) == "TCE/QTN/2026-27/0001"
    assert numbering.render("TCE/{FYS}/{SEQ:4}", 12, d) == "TCE/2627/0012"
    assert numbering.period_key("fy", date(2027, 3, 31)) == "2026-27"
    assert numbering.period_key("fy", date(2027, 4, 1)) == "2027-28"


def test_invoice_pattern_limited_to_16_characters():
    with pytest.raises(AppError) as e:
        numbering.validate_pattern("TCE/INV/{FY}/{SEQ:4}", "fy", 16)
    assert e.value.code == "PATTERN_TOO_LONG"
    numbering.validate_pattern("TCE/{FYS}/{SEQ:4}", "fy", 16)
    with pytest.raises(AppError):
        numbering.validate_pattern("TCE/{FY}/0001", "fy", None)  # no SEQ
    with pytest.raises(AppError):
        numbering.validate_pattern("TCE/{YYYY}/{SEQ:4}", "fy", None) if False else numbering.validate_pattern(
            "TCE/{FY}/{SEQ:4}", "calendar", None)


def test_numbers_restart_each_financial_year():
    cid = _company_id()
    with SessionLocal() as s:
        a = numbering.next_number(s, cid, "QTN", date(2027, 3, 31))
        b = numbering.next_number(s, cid, "QTN", date(2027, 3, 31))
        c = numbering.next_number(s, cid, "QTN", date(2027, 4, 1))
        s.commit()
    assert (a, b, c) == ("TCE/QTN/2026-27/0001", "TCE/QTN/2026-27/0002", "TCE/QTN/2027-28/0001")


def test_rolled_back_number_is_reused_no_gaps():
    cid = _company_id()
    with SessionLocal() as s:
        first = numbering.next_number(s, cid, "PO", date(2026, 9, 25))
        s.rollback()
    with SessionLocal() as s:
        again = numbering.next_number(s, cid, "PO", date(2026, 9, 25))
        s.commit()
    assert first == again == "TCE/PO/2026-27/0001"


def test_fifty_concurrent_users_never_share_a_number():
    """Spec §29: two users must never receive the same number."""
    cid = _company_id()
    eng = create_engine(get_settings().database_url, pool_size=50, max_overflow=0)
    results: list[str] = []
    errors: list[Exception] = []
    barrier = threading.Barrier(50)
    lock = threading.Lock()

    def worker():
        try:
            with eng.connect() as conn:
                from sqlalchemy.orm import Session

                with Session(bind=conn) as s:
                    barrier.wait()
                    n = numbering.next_number(s, cid, "INV", date(2026, 9, 25))
                    s.commit()
                with lock:
                    results.append(n)
        except Exception as exc:  # noqa: BLE001
            errors.append(exc)

    threads = [threading.Thread(target=worker) for _ in range(50)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    eng.dispose()
    assert not errors
    assert len(set(results)) == 50
    assert sorted(results) == [f"TCE/2627/{i:04d}" for i in range(1, 51)]


def test_numbering_format_update_via_api(client, admin_headers):
    fmts = {f["doc_type"]: f for f in client.get("/api/v1/numbering-formats", headers=admin_headers).json()["data"]}
    assert fmts["QTN"]["example"].startswith("TCE/QTN/20")
    r = client.put("/api/v1/numbering-formats/INV", headers=admin_headers,
                   json={"pattern": "TCE/INVOICE/{FY}/{SEQ:5}", "period": "fy", "row_version": fmts["INV"]["row_version"]})
    assert r.status_code == 400 and r.json()["error"]["code"] == "PATTERN_TOO_LONG"


# ------------------------------------------------------------------ money & india helpers
def test_money_helpers():
    assert format_inr("550000") == "5,50,000.00"
    assert format_inr("12345678.5") == "1,23,45,678.50"
    assert round_to_rupee("1180.50") == (1181, pytest.approx(0.5))


def test_gstin_checksum():
    body = "32AABCT1332L1Z"
    full = body + gstin_check_char(body)
    assert validate_gstin(full) == full
    wrong = body + ("A" if full[-1] != "A" else "B")
    with pytest.raises(ValueError, match="check digit"):
        validate_gstin(wrong)


# ------------------------------------------------------------------ documents
PNG = (b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89"
       b"\x00\x00\x00\rIDATx\x9cc\xf8\x0f\x00\x00\x01\x01\x00\x05\x18\xd8N\x00\x00\x00\x00IEND\xaeB`\x82")
PDF = b"%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n"


def _customer_id(client, h):
    return client.get("/api/v1/customers", headers=h, params={"q": "ABC"}).json()["data"][0]["id"]


def test_document_upload_version_download(client, admin_headers):
    cid = _customer_id(client, admin_headers)
    up = client.post("/api/v1/documents", headers=admin_headers,
                     data={"entity_type": "customer", "entity_id": cid, "category": "agreement"},
                     files={"file": ("contract.pdf", io.BytesIO(PDF), "application/pdf")})
    assert up.status_code == 201, up.text
    d1 = up.json()["data"]
    assert d1["version"] == 1 and d1["content_type"] == "application/pdf" and len(d1["sha256"]) == 64
    up2 = client.post("/api/v1/documents", headers=admin_headers,
                      data={"entity_type": "customer", "entity_id": cid, "category": "agreement", "replaces": d1["id"]},
                      files={"file": ("contract-rev1.pdf", io.BytesIO(PDF + b"%rev1\n"), "application/pdf")})
    assert up2.status_code == 201, up2.text
    assert up2.json()["data"]["version"] == 2 and up2.json()["data"]["group_id"] == d1["group_id"]
    latest = client.get("/api/v1/documents", headers=admin_headers,
                        params={"entity_type": "customer", "entity_id": cid}).json()["data"]
    assert [d["version"] for d in latest] == [2]
    history = client.get("/api/v1/documents", headers=admin_headers,
                         params={"entity_type": "customer", "entity_id": cid, "include_history": True}).json()["data"]
    assert sorted(d["version"] for d in history) == [1, 2]
    content = client.get(f"/api/v1/documents/{d1['id']}/content", headers=admin_headers)
    assert content.status_code == 200 and content.content == PDF


def test_document_type_is_sniffed_not_trusted(client, admin_headers):
    cid = _customer_id(client, admin_headers)
    # An executable renamed to .pdf is rejected
    r = client.post("/api/v1/documents", headers=admin_headers,
                    data={"entity_type": "customer", "entity_id": cid, "category": "other"},
                    files={"file": ("invoice.pdf", io.BytesIO(b"MZ\x90\x00" + b"\x00" * 200), "application/pdf")})
    assert r.status_code == 400 and r.json()["error"]["code"] == "FILE_TYPE_NOT_ALLOWED"
    # A PNG claiming to be a PDF is rejected (extension mismatch)
    r = client.post("/api/v1/documents", headers=admin_headers,
                    data={"entity_type": "customer", "entity_id": cid, "category": "site_photo"},
                    files={"file": ("photo.pdf", io.BytesIO(PNG), "application/pdf")})
    assert r.status_code == 400
    r = client.post("/api/v1/documents", headers=admin_headers,
                    data={"entity_type": "customer", "entity_id": cid, "category": "site_photo"},
                    files={"file": ("../../etc/photo.png", io.BytesIO(PNG), "image/png")})
    assert r.status_code == 201 and r.json()["data"]["file_name"] == "photo.png"


def test_document_size_limit(client, admin_headers, monkeypatch):
    monkeypatch.setattr(get_settings(), "max_upload_mb", 1)
    cid = _customer_id(client, admin_headers)
    big = PDF + b"0" * (1024 * 1024 + 10)
    r = client.post("/api/v1/documents", headers=admin_headers,
                    data={"entity_type": "customer", "entity_id": cid, "category": "other"},
                    files={"file": ("big.pdf", io.BytesIO(big), "application/pdf")})
    assert r.status_code == 413


def test_document_access_follows_entity_permission(client, admin_headers, as_user):
    sid = client.get("/api/v1/suppliers", headers=admin_headers).json()["data"][0]["id"]
    r = client.post("/api/v1/documents", headers=as_user("sales1"),
                    data={"entity_type": "supplier", "entity_id": sid, "category": "other"},
                    files={"file": ("x.pdf", io.BytesIO(PDF), "application/pdf")})
    assert r.status_code == 403  # sales has no supplier permissions


def test_documents_survive_on_s3_backend(client, admin_headers, monkeypatch):
    """The same flow against an S3 API (moto) — what staging/production use."""
    from moto import mock_aws

    from app.platform.documents import storage

    with mock_aws():
        s = get_settings()
        monkeypatch.setattr(s, "storage_backend", "s3")
        monkeypatch.setattr(s, "storage_bucket", "tce-test")
        monkeypatch.setattr(s, "storage_access_key", "test")
        monkeypatch.setattr(s, "storage_secret_key", "test")
        s3 = storage.S3Storage()
        s3.client.create_bucket(Bucket="tce-test", CreateBucketConfiguration={"LocationConstraint": "ap-south-1"})
        storage.set_storage(s3)
        try:
            cid = _customer_id(client, admin_headers)
            up = client.post("/api/v1/documents", headers=admin_headers,
                             data={"entity_type": "customer", "entity_id": cid, "category": "drawing"},
                             files={"file": ("layout.pdf", io.BytesIO(PDF), "application/pdf")}).json()["data"]
            dl = client.get(f"/api/v1/documents/{up['id']}/download", headers=admin_headers).json()["data"]
            assert "X-Amz-Signature" in dl["url"] and "tce-test" in dl["url"]
            keys = [o["Key"] for o in s3.client.list_objects_v2(Bucket="tce-test")["Contents"]]
            assert any(k.startswith(f"customer/{cid}/") for k in keys)
        finally:
            storage.set_storage(None)


def test_production_refuses_local_storage():
    from pydantic import ValidationError

    from app.core.config import Settings

    with pytest.raises(ValidationError, match="scratch storage"):
        Settings(environment="production", storage_backend="local")


# ------------------------------------------------------------------ settings & jobs
def test_settings_typed_and_audited(client, admin_headers):
    r = client.put("/api/v1/settings/inventory.allow_negative_stock", headers=admin_headers, json={"value": "yes"})
    assert r.status_code == 400
    r = client.put("/api/v1/settings/approvals.quotation_director_threshold", headers=admin_headers,
                   json={"value": 750000})
    assert r.status_code == 200
    vals = {x["key"]: x["value"] for x in client.get("/api/v1/settings", headers=admin_headers).json()["data"]}
    assert vals["approvals.quotation_director_threshold"] == 750000
    assert vals["inventory.allow_negative_stock"] is False  # Spec §21 default
    logs = client.get("/api/v1/audit-logs", headers=admin_headers, params={"entity_type": "setting"}).json()["data"]
    assert logs[0]["changes"]["value"] == {"old": 500000, "new": 750000}


def test_jobs_run_retry_and_commit_with_business_transaction():
    with SessionLocal() as s:
        enqueue(s, "system.ping", {})
        enqueue(s, "system.ping", {"fail": True})
        s.rollback()  # rolled back with the "business change" -> never runs
    assert run_pending(SessionLocal) == 0
    with SessionLocal() as s:
        enqueue(s, "system.ping", {})
        enqueue(s, "system.ping", {"fail": True})
        s.commit()
    assert run_pending(SessionLocal) == 2
    with SessionLocal() as s:
        states = sorted((j.status, j.attempts) for j in s.scalars(select(Job)))
    assert states == [("done", 1), ("pending", 1)]  # failed one scheduled for retry
