import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select

from app.auth.deps import Principal, require
from app.core.api import ListParams, ok
from app.core.db import DbSession
from app.core.permissions import ACTION_LABELS, ACTIONS, MODULE_LABELS, REGISTRY
from app.users import service
from app.users.schemas import ResetPasswordIn, RoleCreate, RoleUpdate, UserCreate, UserOut, UserUpdate

router = APIRouter(tags=["users & roles"])


def _u(user, db=None) -> dict:
    out = UserOut.model_validate(user).model_dump(mode="json")
    if db is not None:
        from app.hr.service import employee_for_user

        e = employee_for_user(db, user.id)
        out["employee"] = {"id": str(e.id), "employee_code": e.employee_code} if e else None
    return out


@router.get("/users")
def list_users(db: DbSession, _: Annotated[Principal, require("user.read")],
               params: Annotated[ListParams, Depends()], is_active: bool | None = Query(None)):
    rows, meta = service.list_users(db, params, is_active)
    from app.hr.models import Employee

    emps = dict(db.execute(select(Employee.user_id, Employee.employee_code)
                           .where(Employee.user_id.in_([u.id for u in rows]))).all()) if rows else {}
    data = []
    for u in rows:
        out = _u(u)
        out["employee"] = {"employee_code": emps[u.id]} if u.id in emps else None
        data.append(out)
    return {"data": data, "meta": meta.model_dump()}


@router.post("/users", status_code=201)
def create_user(body: UserCreate, db: DbSession, p: Annotated[Principal, require("user.create")]):
    return ok(_u(service.create_user(db, p, body), db))


@router.get("/users/{user_id}")
def get_user(user_id: uuid.UUID, db: DbSession, _: Annotated[Principal, require("user.read")]):
    return ok(_u(service.get_user(db, user_id), db))


@router.put("/users/{user_id}")
def update_user(user_id: uuid.UUID, body: UserUpdate, db: DbSession, p: Annotated[Principal, require("user.update")]):
    return ok(_u(service.update_user(db, p, user_id, body), db))


@router.post("/users/{user_id}/reset-password")
def reset_password(user_id: uuid.UUID, body: ResetPasswordIn, db: DbSession,
                   p: Annotated[Principal, require("user.update")]):
    service.reset_password(db, p, user_id, body.temporary_password)
    return ok({"ok": True})


@router.post("/users/{user_id}/revoke-sessions")
def revoke_sessions(user_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("user.update")]):
    service.revoke_sessions(db, p, user_id)
    return ok({"ok": True})


@router.post("/users/{user_id}/unlock")
def unlock(user_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("user.update")]):
    service.unlock(db, p, user_id)
    return ok({"ok": True})


@router.get("/permissions")
def permissions(_: Annotated[Principal, require("role.read")]):
    modules: dict[str, dict] = {}
    for d in REGISTRY.values():
        m = modules.setdefault(d.module, {"module": d.module, "label": MODULE_LABELS[d.module], "permissions": []})
        m["permissions"].append({"code": d.code, "action": d.action, "label": ACTION_LABELS[d.action],
                                 "supports_scope": d.supports_scope})
    for m in modules.values():
        m["permissions"].sort(key=lambda x: ACTIONS.index(x["action"]))
    return ok(sorted(modules.values(), key=lambda m: m["label"]), actions=list(ACTIONS))


@router.get("/roles")
def list_roles(db: DbSession, _: Annotated[Principal, require("role.read")]):
    return ok([service.role_out(db, r) for r in service.list_roles(db)])


@router.post("/roles", status_code=201)
def create_role(body: RoleCreate, db: DbSession, p: Annotated[Principal, require("role.create")]):
    return ok(service.role_out(db, service.create_role(db, p, body)))


@router.get("/roles/{role_id}")
def get_role(role_id: uuid.UUID, db: DbSession, _: Annotated[Principal, require("role.read")]):
    return ok(service.role_out(db, service.get_role(db, role_id)))


@router.put("/roles/{role_id}")
def update_role(role_id: uuid.UUID, body: RoleUpdate, db: DbSession, p: Annotated[Principal, require("role.update")]):
    return ok(service.role_out(db, service.update_role(db, p, role_id, body)))


@router.delete("/roles/{role_id}")
def delete_role(role_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("role.delete")]):
    service.delete_role(db, p, role_id)
    return ok({"ok": True})
