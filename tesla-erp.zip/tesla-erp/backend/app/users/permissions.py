from app.core.permissions import register

register("user", "Users", ("create", "read", "update", "delete", "export"))
register("role", "Roles & permissions", ("create", "read", "update", "delete"))
