"""Initial roles (Spec §6) and their default permission grants.

These are only the starting point: after seeding, roles are data and are edited in
Administration → Roles. `sync_permissions` never overwrites grants an admin has changed;
it only adds new permission codes and grants every new code to ADMIN.

Grant syntax: "module.action" or "module.*" (all actions of a module), mapped to a scope.
"""
ROLES: dict[str, dict] = {
    "ADMIN": {"name": "Administrator", "grants": {"*": "all"},
              "description": "Full access, including users, roles, settings and the audit log."},
    "DIRECTOR": {
        "name": "Director",
        "description": "Sees everything; approves; manages masters. No user administration.",
        "grants": {
            "company.*": "all", "division.*": "all", "settings.read": "all", "user.read": "all", "role.read": "all",
            "org_master.*": "all", "employee.*": "all", "customer.*": "all", "supplier.*": "all",
            "supplier_bank.read": "all", "item.*": "all", "tax_rate.*": "all", "warehouse.*": "all",
            "audit.*": "all",
        },
    },
    "MANAGER": {
        "name": "Manager",
        "description": "Manages masters and teams; approves within limits.",
        "grants": {
            "company.read": "all", "division.read": "all", "user.read": "all", "org_master.read": "all",
            "employee.read": "all", "customer.create": "all", "customer.read": "all", "customer.update": "all",
            "customer.export": "all", "customer.print": "all", "supplier.create": "all", "supplier.read": "all",
            "supplier.update": "all", "supplier.export": "all", "item.create": "all", "item.read": "all",
            "item.update": "all", "item.export": "all", "tax_rate.read": "all", "warehouse.read": "all",
        },
    },
    "SALES": {
        "name": "Sales",
        "description": "Creates customers; can edit only customers assigned to them.",
        "grants": {
            "company.read": "all", "division.read": "all", "customer.create": "all", "customer.read": "all",
            "customer.update": "own", "customer.export": "all", "customer.print": "all", "item.read": "all",
            "tax_rate.read": "all", "employee.read": "all",
        },
    },
    "PROJECT_MANAGER": {
        "name": "Project Manager",
        "description": "Runs projects; reads customers, items and suppliers.",
        "grants": {
            "company.read": "all", "division.read": "all", "customer.read": "all", "customer.update": "all",
            "supplier.read": "all", "item.read": "all", "tax_rate.read": "all", "warehouse.read": "all",
            "employee.read": "all",
        },
    },
    "SITE_ENGINEER": {
        "name": "Site Engineer",
        "description": "Field work: site visits, tasks, material requests (from Phase 2).",
        "grants": {"company.read": "all", "customer.read": "all", "item.read": "all", "warehouse.read": "all"},
    },
    "PURCHASE": {
        "name": "Purchase",
        "description": "Maintains suppliers and items; raises purchase orders (from Phase 5).",
        "grants": {
            "company.read": "all", "division.read": "all", "supplier.*": "all", "supplier_bank.read": "all",
            "item.create": "all", "item.read": "all", "item.update": "all", "item.export": "all",
            "tax_rate.read": "all", "warehouse.read": "all", "customer.read": "all",
        },
    },
    "STORE": {
        "name": "Store",
        "description": "Stock, receipts and issues (from Phase 5).",
        "grants": {
            "company.read": "all", "item.create": "all", "item.read": "all", "item.update": "all",
            "warehouse.read": "all", "warehouse.update": "all", "supplier.read": "all", "customer.read": "all",
        },
    },
    "ACCOUNTS": {
        "name": "Accounts",
        "description": "Billing, receivables, payables, GST.",
        "grants": {
            "company.read": "all", "division.read": "all", "customer.read": "all", "customer.update": "all",
            "customer.export": "all", "supplier.read": "all", "supplier.update": "all", "supplier.export": "all",
            "supplier_bank.*": "all", "item.read": "all", "tax_rate.*": "all", "settings.read": "all",
            "employee.read": "all",
        },
    },
    "HR": {
        "name": "HR",
        "description": "Employees, departments, designations; attendance and leave (from Phase 8).",
        "grants": {"company.read": "all", "division.read": "all", "org_master.*": "all", "employee.*": "all",
                   "user.read": "all"},
    },
    "EMPLOYEE": {
        "name": "Employee",
        "description": "Every staff member: own expenses, leave and attendance (later phases).",
        "grants": {"company.read": "all"},
    },
}
