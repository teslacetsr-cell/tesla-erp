"""Initial roles (Spec §6) and their default permission grants.

These are only the starting point: after seeding, roles are data and are edited in
Administration → Roles. `sync_permissions` never overwrites grants an admin has changed;
it only adds new permission codes and grants every new code to ADMIN.

Grant syntax: "module.action" or "module.*" (all actions of a module), mapped to a scope.
"""
ROLES: dict[str, dict] = {
    "ADMIN": {"name": "Administrator", "grants": {"*": "all"},
              "description": "Full access, including users, roles, settings and the audit log.",
    },
    "DIRECTOR": {
        "name": "Director",
        "description": "Sees everything; approves; manages masters. No user administration.",
        "grants": {
            "invoice.*": "all", "invoice_post.approve": "all", "receipt.*": "all", "supplier_invoice.*": "all",
            "supplier_payment.*": "all", "expense.*": "all", "expense_payment.create": "all", "receivable.*": "all",
            "payable.*": "all", "finance_report.*": "all", "finance_master.*": "all", "company.*": "all",
            "division.*": "all", "settings.read": "all", "user.read": "all", "role.read": "all",
            "org_master.*": "all", "employee.*": "all", "customer.*": "all", "supplier.*": "all",
            "supplier_bank.read": "all", "item.*": "all", "tax_rate.*": "all", "warehouse.*": "all", "audit.*": "all",
            "lead.*": "all", "enquiry.*": "all", "site_visit.*": "all", "boq.*": "all", "quotation.*": "all",
            "quotation_term.*": "all", "approval_policy.*": "all", "sales_order.*": "all",
            "sales_order_commercial.update": "all", "project.*": "all", "site_work.*": "all",
            "material_request.*": "all", "purchase_request.*": "all", "purchase_order.*": "all", "grn.*": "all",
            "rfq.*": "all",
            "stock.*": "all", "stock_transfer.*": "all", "stock_adjustment.*": "all", "material_issue.*": "all",
            "project_cost.*": "all", "employee_private.*": "all",
            "attendance.*": "all", "leave_request.*": "all", "hr_master.*": "all", "salary.*": "all",
            "labour_cost.create": "all", "dashboard.read": "all", "tally.*": "all",
        },
    },
    "MANAGER": {
        "name": "Manager",
        "description": "Manages masters and teams; approves within limits.",
        "grants": {
            "invoice.read": "all", "invoice.print": "all", "receipt.read": "all", "supplier_invoice.read": "all",
            "supplier_invoice.approve": "all", "supplier_payment.read": "all", "expense.create": "all",
            "expense.read": "all", "expense.update": "own", "expense.delete": "own", "expense.print": "all",
            "expense.approve": "all", "expense.export": "all", "receivable.read": "all", "payable.read": "all",
            "company.read": "all", "division.read": "all", "user.read": "all", "org_master.read": "all",
            "employee.read": "all", "customer.create": "all", "customer.read": "all", "customer.update": "all",
            "customer.export": "all", "customer.print": "all", "supplier.create": "all", "supplier.read": "all",
            "supplier.update": "all", "supplier.export": "all", "item.create": "all", "item.read": "all",
            "item.update": "all", "item.export": "all", "tax_rate.read": "all", "warehouse.read": "all",
            "lead.*": "all", "enquiry.*": "all", "site_visit.*": "all", "boq.*": "all", "quotation.*": "all",
            "quotation_term.*": "all", "approval_policy.read": "all", "sales_order.*": "all", "project.*": "all",
            "site_work.*": "all", "material_request.*": "all", "purchase_request.*": "all", "purchase_order.*": "all",
            "rfq.*": "all", "grn.*": "all", "stock.*": "all", "stock_transfer.*": "all", "stock_adjustment.*": "all",
            "material_issue.*": "all", "project_cost.*": "all", "attendance.create": "all", "attendance.read": "all",
            "leave_request.create": "all", "leave_request.read": "all", "attendance.export": "all",
            "leave_request.approve": "all", "leave_request.export": "all", "hr_master.read": "all",
            "dashboard.read": "all",
        },
    },
    "SALES": {
        "name": "Sales",
        "description": "Creates customers; can edit only customers assigned to them.",
        "grants": {
            "expense.create": "all", "expense.read": "own", "expense.update": "own", "expense.delete": "own",
            "expense.print": "own", "invoice.read": "all", "invoice.print": "all", "receipt.read": "all",
            "receivable.read": "all", "company.read": "all", "division.read": "all", "customer.create": "all",
            "customer.read": "all", "customer.update": "own", "customer.export": "all", "customer.print": "all",
            "item.read": "all", "tax_rate.read": "all", "employee.read": "all", "lead.create": "all",
            "lead.read": "own", "lead.update": "own", "lead.export": "all", "enquiry.create": "all",
            "enquiry.read": "own", "enquiry.update": "own", "enquiry.export": "all", "site_visit.create": "all",
            "site_visit.read": "own", "site_visit.update": "own", "site_visit.print": "own", "boq.create": "all",
            "boq.read": "all", "boq.update": "all", "boq.export": "all", "boq.print": "all",
            "quotation.create": "all", "quotation.read": "own", "quotation.update": "own", "quotation.print": "own",
            "quotation.export": "all", "quotation_term.read": "all", "sales_order.create": "all",
            "sales_order.read": "own", "sales_order.update": "own", "sales_order.print": "all",
            "sales_order.export": "all", "attendance.create": "all", "attendance.read": "own",
            "leave_request.create": "all", "leave_request.read": "own",
        },
    },
    "PROJECT_MANAGER": {
        "name": "Project Manager",
        "description": "Runs projects; reads customers, items and suppliers.",
        "grants": {
            "expense.create": "all", "expense.read": "own", "expense.update": "own", "expense.delete": "own",
            "expense.print": "own", "invoice.read": "all", "receipt.read": "all", "receivable.read": "all",
            "company.read": "all", "division.read": "all", "customer.read": "all", "customer.update": "all",
            "supplier.read": "all", "item.read": "all", "tax_rate.read": "all", "warehouse.read": "all",
            "employee.read": "all", "lead.read": "all", "enquiry.read": "all", "enquiry.update": "all",
            "site_visit.create": "all", "site_visit.read": "all", "site_visit.update": "all",
            "site_visit.print": "all", "boq.create": "all", "boq.read": "all", "boq.update": "all",
            "boq.export": "all", "boq.print": "all", "quotation.read": "all", "quotation.print": "all",
            "quotation_term.read": "all", "sales_order.read": "all", "sales_order.print": "all",
            "project.create": "all", "project.read": "all", "project.update": "own", "project.export": "all",
            "project.print": "all", "site_work.create": "own", "site_work.read": "own", "site_work.update": "own",
            "site_work.delete": "own", "material_request.create": "all", "material_request.read": "all",
            "material_request.update": "own", "material_request.delete": "own", "purchase_request.read": "all",
            "rfq.read": "all", "rfq.export": "all",
            "purchase_order.read": "all", "purchase_order.print": "all", "grn.create": "all", "grn.read": "all",
            "grn.print": "all", "stock.read": "all", "stock_transfer.create": "all", "stock_transfer.read": "all",
            "stock_transfer.update": "all", "material_issue.create": "own", "material_issue.read": "own",
            "material_issue.approve": "all", "material_issue.print": "all", "material_issue.export": "all",
            "project_cost.create": "own", "project_cost.read": "own", "project_cost.export": "all",
            "attendance.create": "all", "attendance.read": "all", "leave_request.create": "all",
            "leave_request.read": "own",
        },
    },
    "SITE_ENGINEER": {
        "name": "Site Engineer",
        "description": "Field work: site visits, project tasks and daily site reports on their projects.",
        "grants": {
            "expense.create": "all", "expense.read": "own", "expense.update": "own", "expense.delete": "own",
            "expense.print": "own", "company.read": "all", "customer.read": "all", "item.read": "all",
            "warehouse.read": "all", "enquiry.read": "own", "site_visit.create": "all", "site_visit.read": "own",
            "site_visit.update": "own", "site_visit.print": "own", "boq.create": "all", "boq.read": "all",
            "boq.update": "all", "boq.print": "all", "project.read": "own", "site_work.create": "own",
            "site_work.read": "own", "site_work.update": "own", "material_request.create": "all",
            "material_request.read": "own", "material_request.update": "own", "material_request.delete": "own",
            "grn.create": "all", "grn.read": "all", "stock.read": "all", "stock_transfer.read": "all",
            "material_issue.create": "own", "material_issue.read": "own", "material_issue.print": "all",
            "attendance.create": "all", "attendance.read": "own", "leave_request.create": "all",
            "leave_request.read": "own",
        },
    },
    "PURCHASE": {
        "name": "Purchase",
        "description": "Suppliers and items; turns material requests into purchase requests and purchase orders.",
        "grants": {
            "expense.create": "all", "expense.read": "own", "expense.update": "own", "expense.delete": "own",
            "expense.print": "own", "supplier_invoice.create": "all", "supplier_invoice.read": "all",
            "supplier_invoice.update": "all", "supplier_invoice.delete": "all", "supplier_invoice.export": "all",
            "supplier_payment.read": "all", "payable.read": "all", "company.read": "all", "division.read": "all",
            "supplier.*": "all", "supplier_bank.read": "all", "item.create": "all", "item.read": "all",
            "item.update": "all", "item.export": "all", "tax_rate.read": "all", "warehouse.read": "all",
            "customer.read": "all", "material_request.read": "all", "material_request.approve": "all",
            "purchase_request.create": "all", "purchase_request.read": "all", "purchase_request.update": "all",
            "purchase_request.delete": "all", "rfq.*": "all", "purchase_order.create": "all", "purchase_order.read": "all",
            "purchase_order.update": "all", "purchase_order.delete": "all", "purchase_order.export": "all",
            "purchase_order.print": "all", "grn.read": "all", "grn.print": "all", "stock.read": "all",
            "stock.export": "all", "project.read": "all", "material_issue.read": "all", "attendance.create": "all",
            "attendance.read": "own", "leave_request.create": "all", "leave_request.read": "own",
        },
    },
    "STORE": {
        "name": "Store",
        "description": "Receives goods (GRN), keeps stock, transfers to site stores, raises stock adjustments.",
        "grants": {
            "expense.create": "all", "expense.read": "own", "expense.update": "own", "expense.delete": "own",
            "expense.print": "own", "company.read": "all", "item.create": "all", "item.read": "all",
            "item.update": "all", "warehouse.read": "all", "warehouse.update": "all", "supplier.read": "all",
            "customer.read": "all", "project.read": "all", "warehouse.create": "all", "material_request.read": "all",
            "material_request.approve": "all", "purchase_request.create": "all", "purchase_request.read": "all",
            "purchase_request.update": "all", "purchase_request.delete": "all", "purchase_order.read": "all",
            "purchase_order.print": "all", "rfq.read": "all", "rfq.export": "all", "grn.*": "all", "stock.*": "all", "stock_transfer.*": "all",
            "stock_adjustment.create": "all", "stock_adjustment.read": "all", "stock_adjustment.update": "all",
            "material_issue.create": "all", "material_issue.read": "all", "material_issue.update": "all",
            "material_issue.delete": "all", "material_issue.print": "all", "material_issue.export": "all",
            "attendance.create": "all", "attendance.read": "own", "leave_request.create": "all",
            "leave_request.read": "own",
        },
    },
    "ACCOUNTS": {
        "name": "Accounts",
        "description": "Billing, receipts, supplier bills and payments, expenses, GST.",
        "grants": {
            "invoice.*": "all", "invoice_post.approve": "all", "receipt.*": "all", "supplier_invoice.*": "all",
            "supplier_payment.*": "all", "expense.*": "all", "expense_payment.create": "all", "receivable.*": "all",
            "payable.*": "all", "finance_report.*": "all", "finance_master.*": "all", "company.read": "all",
            "division.read": "all", "customer.read": "all", "customer.update": "all", "customer.export": "all",
            "supplier.read": "all", "supplier.update": "all", "supplier.export": "all", "supplier_bank.*": "all",
            "item.read": "all", "tax_rate.*": "all", "settings.read": "all", "employee.read": "all",
            "quotation.read": "all", "quotation.print": "all", "quotation.export": "all", "sales_order.read": "all",
            "sales_order.print": "all", "sales_order.export": "all", "project.read": "all", "project.export": "all",
            "project.print": "all", "purchase_request.read": "all", "rfq.read": "all", "rfq.export": "all",
            "purchase_order.read": "all",
            "purchase_order.print": "all", "purchase_order.export": "all", "grn.read": "all", "grn.export": "all",
            "grn.print": "all", "stock.*": "all", "stock_adjustment.read": "all", "stock_transfer.read": "all",
            "material_issue.read": "all", "material_issue.export": "all", "material_issue.print": "all",
            "project_cost.read": "all", "project_cost.export": "all", "attendance.create": "all",
            "attendance.read": "own", "leave_request.create": "all", "leave_request.read": "own", "tally.*": "all",
        },
    },
    "HR": {
        "name": "HR",
        "description": "Employees, personal details, attendance, leave, holidays, salary records and labour costing.",
        "grants": {
            "expense.create": "all", "expense.read": "own", "expense.update": "own", "expense.delete": "own",
            "expense.print": "own", "company.read": "all", "division.read": "all", "org_master.*": "all",
            "employee.*": "all", "user.read": "all", "employee_private.*": "all",
            "attendance.*": "all", "leave_request.*": "all", "hr_master.*": "all", "salary.*": "all",
            "labour_cost.create": "all",
        },
    },
    "EMPLOYEE": {
        "name": "Employee",
        "description": "Every staff member: own attendance, leave and expense claims.",
        "grants": {
            "expense.create": "all", "expense.read": "own", "expense.update": "own", "expense.delete": "own",
            "expense.print": "own", "company.read": "all", "attendance.create": "all", "attendance.read": "own",
            "leave_request.create": "all", "leave_request.read": "own",
        },
    },
}

# Team chat: every standard role can chat; directors (and ADMIN, who holds everything) also moderate.
for _spec in ROLES.values():
    if "*" not in _spec["grants"]:
        _spec["grants"]["chat.use"] = "all"
ROLES["DIRECTOR"]["grants"]["chat.moderate"] = "all"

# Employee incentives & performance: management sets the scheme, approves months and marks payouts; managers and accounts
# see the register; accounts and managers update payment follow-up; managers rate performance. Every employee sees
# their own statement (no permission needed). Unlocking a month is for administrators only (ADMIN holds everything).
ROLES["DIRECTOR"]["grants"].update({"incentive.*": "all", "incentive_followup.update": "all", "performance.*": "all"})
ROLES["MANAGER"]["grants"].update({"incentive.read": "all", "incentive.export": "all", "incentive_followup.update": "all",
                                   "performance.*": "all"})
ROLES["ACCOUNTS"]["grants"].update({"incentive.read": "all", "incentive.export": "all",
                                    "incentive_followup.update": "all"})
