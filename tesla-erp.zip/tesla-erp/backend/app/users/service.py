import uuid

from sqlalchemy import delete, func, or_, select
from sqlalchemy.orm import Session

from app.auth import service as auth_service
from app.auth.deps import Principal
from app.core.api import ListParams, paginate
from app.core.errors import AppError, Conflict, Forbidden, NotFound
from app.core.models import check_row_version
from app.core.permissions import REGISTRY, normalise
from app.platform.audit import service as audit
from app.users.models import Permission, Role, RolePermission, User, UserRole
from app.users.schemas import RoleCreate, RoleUpdate, UserCreate, UserUpdate


# ------------------------------------------------------------------ users
def _roles_by_code(session: Session, codes: list[str]) -> list[Role]:
    codes = sorted({c.strip().upper() for c in codes})
    roles = list(session.scalars(select(Role).where(Role.code.in_(codes), Role.is_active.is_(True))))
    missing = set(codes) - {r.code for r in roles}
    if missing:
        raise AppError("UNKNOWN_ROLE", f"Unknown or inactive role(s): {', '.join(sorted(missing))}.")
    return roles


def _guard_admin_assignment(actor: Principal, roles: list[Role]) -> None:
    if any(r.code == "ADMIN" for r in roles) and "ADMIN" not in actor.role_codes:
        raise Forbidden("Only an administrator can grant the Administrator role.")


def _active_admin_count(session: Session, exclude_user: uuid.UUID | None = None) -> int:
    stmt = (select(func.count(func.distinct(User.id)))
            .join(UserRole, UserRole.user_id == User.id).join(Role, Role.id == UserRole.role_id)
            .where(Role.code == "ADMIN", User.is_active.is_(True)))
    if exclude_user:
        stmt = stmt.where(User.id != exclude_user)
    return session.scalar(stmt) or 0


def _set_roles(session: Session, user: User, roles: list[Role]) -> None:
    session.execute(delete(UserRole).where(UserRole.user_id == user.id))
    for r in roles:
        session.add(UserRole(user_id=user.id, role_id=r.id))
    session.flush()
    session.refresh(user, ["roles"])


def _snap(user: User) -> dict:
    s = audit.snapshot(user)
    s["roles"] = sorted(r.code for r in user.roles)
    for k in ("failed_login_count", "last_login_at", "session_version", "locked_until", "password_changed_at"):
        s.pop(k, None)
    return s


def list_users(session: Session, params: ListParams, is_active: bool | None):
    stmt = select(User)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(User.username.ilike(like), User.email.ilike(like), User.full_name.ilike(like)))
    if is_active is not None:
        stmt = stmt.where(User.is_active.is_(is_active))
    return paginate(session, stmt, params, default_sort=User.full_name,
                    sortable={"full_name": User.full_name, "username": User.username,
                              "last_login_at": User.last_login_at, "created_at": User.created_at})


def get_user(session: Session, user_id: uuid.UUID) -> User:
    user = session.get(User, user_id)
    if user is None:
        raise NotFound("user")
    return user


def create_user(session: Session, actor: Principal, data: UserCreate) -> User:
    roles = _roles_by_code(session, data.role_codes)
    _guard_admin_assignment(actor, roles)
    if session.scalar(select(User.id).where(or_(User.username == data.username, User.email == str(data.email)))):
        raise Conflict("USER_EXISTS", "A user with this username or email already exists.")
    user = User(username=data.username, email=str(data.email), full_name=data.full_name, phone=data.phone,
                password_hash="!", must_change_password=True, created_by=actor.id, updated_by=actor.id)
    auth_service.set_password(user, data.temporary_password, must_change=True)
    session.add(user)
    session.flush()
    _set_roles(session, user, roles)
    audit.record(session, action="create", entity_type="user", entity_id=user.id, entity_label=user.username,
                 after=_snap(user))
    from app.hr.service import ensure_employee

    ensure_employee(session, user, company_id=actor.company_id, actor_id=actor.id, employee_id=data.employee_id,
                    department_id=data.department_id, designation_id=data.designation_id, division_id=data.division_id)
    return user


def update_user(session: Session, actor: Principal, user_id: uuid.UUID, data: UserUpdate) -> User:
    user = get_user(session, user_id)
    before = _snap(user)
    check_row_version(user, data.row_version)
    roles = _roles_by_code(session, data.role_codes)
    old_codes = {r.code for r in user.roles}
    new_codes = {r.code for r in roles}
    if old_codes != new_codes:
        _guard_admin_assignment(actor, roles)
        if "ADMIN" in old_codes and "ADMIN" not in new_codes and "ADMIN" not in actor.role_codes:
            raise Forbidden("Only an administrator can remove the Administrator role.")
    losing_admin = "ADMIN" in old_codes and ("ADMIN" not in new_codes or not data.is_active)
    if losing_admin and _active_admin_count(session, exclude_user=user.id) == 0:
        raise AppError("LAST_ADMIN", "At least one active administrator must remain.")
    if user.id == actor.id and not data.is_active:
        raise AppError("SELF_DEACTIVATE", "You cannot deactivate your own account.")
    if str(data.email).lower() != user.email.lower() and session.scalar(
        select(User.id).where(User.email == str(data.email), User.id != user.id)
    ):
        raise Conflict("USER_EXISTS", "Another user already uses this email.")
    user.email, user.full_name, user.phone = str(data.email), data.full_name, data.phone
    was_active = user.is_active
    user.is_active = data.is_active
    user.updated_by = actor.id
    _set_roles(session, user, roles)
    if was_active and not data.is_active:
        auth_service.revoke_all_sessions(session, user, "deactivated")
    elif old_codes != new_codes:
        auth_service.revoke_all_sessions(session, user, "roles_changed")
    audit.record(session, action="update", entity_type="user", entity_id=user.id, entity_label=user.username,
                 before=before, after=_snap(user))
    from app.hr.service import sync_from_user

    sync_from_user(session, user, actor.id)
    return user


def reset_password(session: Session, actor: Principal, user_id: uuid.UUID, temporary: str) -> None:
    user = get_user(session, user_id)
    if "ADMIN" in {r.code for r in user.roles} and "ADMIN" not in actor.role_codes:
        raise Forbidden("Only an administrator can reset an administrator's password.")
    auth_service.set_password(user, temporary, must_change=True)
    user.failed_login_count, user.locked_until = 0, None
    auth_service.revoke_all_sessions(session, user, "password_reset")
    audit.record(session, action="password_reset", entity_type="user", entity_id=user.id, entity_label=user.username,
                 summary=f"Temporary password set by {actor.user.username}")


def revoke_sessions(session: Session, actor: Principal, user_id: uuid.UUID) -> None:
    user = get_user(session, user_id)
    auth_service.revoke_all_sessions(session, user, "admin_revoked")
    audit.record(session, action="revoke_sessions", entity_type="user", entity_id=user.id, entity_label=user.username)


def unlock(session: Session, actor: Principal, user_id: uuid.UUID) -> None:
    user = get_user(session, user_id)
    user.failed_login_count, user.locked_until = 0, None
    audit.record(session, action="unlock", entity_type="user", entity_id=user.id, entity_label=user.username)




# ------------------------------------------------------------------ roles
def role_out(session: Session, role: Role) -> dict:
    users = session.scalar(select(func.count()).select_from(UserRole).where(UserRole.role_id == role.id)) or 0
    return {
        "id": role.id, "code": role.code, "name": role.name, "description": role.description,
        "is_system": role.is_system, "is_active": role.is_active, "row_version": role.row_version,
        "user_count": users, "grants": {g.permission.code: g.scope for g in role.grants},
    }


def list_roles(session: Session) -> list[Role]:
    return list(session.scalars(select(Role).order_by(Role.is_system.desc(), Role.name)))


def get_role(session: Session, role_id: uuid.UUID) -> Role:
    role = session.get(Role, role_id)
    if role is None:
        raise NotFound("role")
    return role


def _apply_grants(session: Session, role: Role, grants: dict[str, str]) -> None:
    normalised = {normalise(k): v for k, v in grants.items()}
    unknown = set(normalised) - set(REGISTRY)
    if unknown:
        raise AppError("UNKNOWN_PERMISSION", f"Unknown permission(s): {', '.join(sorted(unknown))}.")
    for code, scope in normalised.items():
        if scope != "all" and not REGISTRY[code].supports_scope:
            raise AppError("SCOPE_NOT_SUPPORTED", f"'{code}' does not support a restricted scope.")
    perms = {p.code: p for p in session.scalars(select(Permission).where(Permission.code.in_(list(normalised))))}
    role.grants.clear()
    session.flush()
    for code, scope in normalised.items():
        role.grants.append(RolePermission(permission_id=perms[code].id, scope=scope))
    session.flush()


def create_role(session: Session, actor: Principal, data: RoleCreate) -> Role:
    if session.scalar(select(Role.id).where(Role.code == data.code)):
        raise Conflict("ROLE_EXISTS", "A role with this code already exists.")
    role = Role(code=data.code, name=data.name, description=data.description, is_system=False,
                created_by=actor.id, updated_by=actor.id)
    session.add(role)
    session.flush()
    _apply_grants(session, role, data.grants)
    audit.record(session, action="create", entity_type="role", entity_id=role.id, entity_label=role.code,
                 after={"name": role.name, "grants": {g.permission.code: g.scope for g in role.grants}})
    return role


def update_role(session: Session, actor: Principal, role_id: uuid.UUID, data: RoleUpdate) -> Role:
    role = get_role(session, role_id)
    if role.code == "ADMIN":
        raise AppError("ROLE_LOCKED", "The Administrator role always has every permission and cannot be edited.")
    before = {"name": role.name, "description": role.description, "is_active": role.is_active,
              "grants": {g.permission.code: g.scope for g in role.grants}}
    check_row_version(role, data.row_version)
    role.name, role.description, role.is_active, role.updated_by = data.name, data.description, data.is_active, actor.id
    _apply_grants(session, role, data.grants)
    after = {"name": role.name, "description": role.description, "is_active": role.is_active,
             "grants": {g.permission.code: g.scope for g in role.grants}}
    audit.record(session, action="update", entity_type="role", entity_id=role.id, entity_label=role.code,
                 before=before, after=after)
    return role


def delete_role(session: Session, actor: Principal, role_id: uuid.UUID) -> None:
    role = get_role(session, role_id)
    if role.is_system:
        raise AppError("ROLE_LOCKED", "Built-in roles cannot be deleted; deactivate or edit them instead.")
    if session.scalar(select(func.count()).select_from(UserRole).where(UserRole.role_id == role.id)):
        raise Conflict("IN_USE", "Remove this role from all users before deleting it.")
    audit.record(session, action="delete", entity_type="role", entity_id=role.id, entity_label=role.code)
    session.delete(role)
