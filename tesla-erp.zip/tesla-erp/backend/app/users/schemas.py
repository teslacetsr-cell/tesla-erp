import uuid
from datetime import datetime
from typing import Literal

from pydantic import EmailStr, Field, field_validator

from app.core.api import Schema


class RoleRef(Schema):
    id: uuid.UUID
    code: str
    name: str


class UserOut(Schema):
    id: uuid.UUID
    username: str
    email: str
    full_name: str
    phone: str | None
    is_active: bool
    must_change_password: bool
    last_login_at: datetime | None
    locked_until: datetime | None
    roles: list[RoleRef]
    row_version: int
    created_at: datetime


class UserCreate(Schema):
    username: str = Field(min_length=3, max_length=50, pattern=r"^[A-Za-z0-9._-]+$")
    email: EmailStr
    full_name: str = Field(min_length=2, max_length=150)
    phone: str | None = Field(default=None, max_length=20)
    role_codes: list[str] = Field(min_length=1)
    temporary_password: str = Field(min_length=1, max_length=128)


class UserUpdate(Schema):
    email: EmailStr
    full_name: str = Field(min_length=2, max_length=150)
    phone: str | None = Field(default=None, max_length=20)
    role_codes: list[str] = Field(min_length=1)
    is_active: bool
    row_version: int


class ResetPasswordIn(Schema):
    temporary_password: str = Field(min_length=1, max_length=128)


class RoleOut(Schema):
    id: uuid.UUID
    code: str
    name: str
    description: str | None
    is_system: bool
    is_active: bool
    row_version: int
    user_count: int = 0
    grants: dict[str, str] = {}


class RoleCreate(Schema):
    code: str = Field(min_length=2, max_length=50, pattern=r"^[A-Z][A-Z0-9_]*$")
    name: str = Field(min_length=2, max_length=100)
    description: str | None = Field(default=None, max_length=500)
    grants: dict[str, Literal["own", "team", "division", "all"]] = {}

    @field_validator("code", mode="before")
    @classmethod
    def _upper(cls, v: str) -> str:
        return v.strip().upper() if isinstance(v, str) else v


class RoleUpdate(Schema):
    name: str = Field(min_length=2, max_length=100)
    description: str | None = Field(default=None, max_length=500)
    is_active: bool = True
    grants: dict[str, Literal["own", "team", "division", "all"]]
    row_version: int
