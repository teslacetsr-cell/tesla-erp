"""Keeps the permissions table in step with the code registry and creates the initial roles."""
import fnmatch

from sqlalchemy import select
from sqlalchemy.orm import Session

import app.registry  # noqa: F401 - loads all module permission declarations
from app.core.permissions import REGISTRY
from app.users.default_roles import ROLES
from app.users.models import Permission, Role, RolePermission


def sync_permissions(session: Session) -> dict[str, int]:
    existing = {p.code: p for p in session.scalars(select(Permission))}
    new_codes: set[str] = set()
    added = 0
    for code, d in REGISTRY.items():
        p = existing.get(code)
        if p is None:
            p = Permission(code=code, module=d.module, action=d.action, description=d.description,
                           supports_scope=d.supports_scope)
            session.add(p)
            existing[code] = p
            new_codes.add(code)
            added += 1
        else:
            p.description, p.supports_scope = d.description, d.supports_scope
    session.flush()

    created_roles = 0
    roles = {r.code: r for r in session.scalars(select(Role))}
    for code, spec in ROLES.items():
        role = roles.get(code)
        is_new = role is None
        if is_new:
            role = Role(code=code, name=spec["name"], description=spec["description"], is_system=True)
            session.add(role)
            session.flush()
            roles[code] = role
            created_roles += 1
        granted = {g.permission_id for g in role.grants}
        # New roles get their defaults; ADMIN always receives every permission, including new ones.
        # When an upgrade adds a module (e.g. CRM in Phase 2), the standard roles receive their default grants
        # for the NEW permission codes only — grants an administrator already changed are never touched.
        codes = existing if (is_new or code == "ADMIN") else new_codes
        for perm_code in codes:
            perm = existing[perm_code]
            scope = _match(spec["grants"], perm_code)
            if scope and perm.id not in granted:
                session.add(RolePermission(role_id=role.id, permission_id=perm.id, scope=scope))
    session.flush()
    return {"permissions_added": added, "roles_created": created_roles}


def _match(grants: dict[str, str], code: str) -> str | None:
    for pattern, scope in grants.items():
        if fnmatch.fnmatchcase(code, pattern):
            return scope
    return None
