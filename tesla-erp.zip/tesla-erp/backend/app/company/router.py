from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, File, UploadFile
from fastapi.responses import Response
from pydantic import EmailStr, Field, model_validator
from sqlalchemy import select

from app.auth.deps import Principal, require
from app.company.models import BusinessDivision, Company
from app.core.api import Schema, ok
from app.core.crud import master_routes
from app.core.db import DbSession
from app.core.errors import AppError, NotFound
from app.core.models import check_row_version
from app.core.security import mask
from app.core.validators import GSTIN, IFSC, PAN, Blank, Phone, Pincode, StateCode, Text, UpperStr, check_tax_identity
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.platform.documents.storage import get_storage
from app.platform.numbering import service as numbering
from app.platform.numbering.models import NumberingFormat
from app.platform.settings import service as settings_service

router = APIRouter(tags=["company & settings"])
documents.register_entity("company", "company", Company)


# ------------------------------------------------------------------ company profile
class CompanyIn(Schema):
    company_name: str = Field(min_length=2, max_length=200)
    legal_name: str = Field(min_length=2, max_length=200)
    tagline: Text(200) = None
    gstin: GSTIN = None
    pan: PAN = None
    address_line1: Text(200) = None
    address_line2: Text(200) = None
    city: Text(100) = None
    state: Text(100) = None
    state_code: StateCode = None
    pincode: Pincode = None
    phone: Phone = None
    email: EmailStr | None = None
    website: Text(200) = None
    bank_name: Text(150) = None
    bank_account_name: Text(200) = None
    account_number: Annotated[Annotated[str, Field(pattern=r"^[0-9]{6,18}$")] | None, Blank] = None
    ifsc: IFSC = None
    branch: Text(150) = None
    row_version: int

    @model_validator(mode="after")
    def _identity(self):
        for k, v in check_tax_identity(self.gstin, self.pan, self.state_code).items():
            setattr(self, k, v)
        return self


def company_out(c: Company, principal: Principal) -> dict:
    full = principal.can("company.update")
    return {
        "id": str(c.id), "code": c.code, "company_name": c.company_name, "legal_name": c.legal_name,
        "tagline": c.tagline, "gstin": c.gstin, "pan": c.pan, "address_line1": c.address_line1,
        "address_line2": c.address_line2, "city": c.city, "state": c.state, "state_code": c.state_code,
        "pincode": c.pincode, "phone": c.phone, "email": c.email, "website": c.website,
        "bank_name": c.bank_name, "bank_account_name": c.bank_account_name,
        "account_number": c.account_number if full else mask(c.account_number), "ifsc": c.ifsc, "branch": c.branch,
        "has_logo": c.logo_document_id is not None, "row_version": c.row_version,
    }


def _company(db, p: Principal) -> Company:
    c = db.get(Company, p.company_id)
    if c is None:
        raise NotFound("company")
    return c


@router.get("/company")
def get_company(db: DbSession, p: Annotated[Principal, require("company.read")]):
    return ok(company_out(_company(db, p), p))


@router.put("/company")
def update_company(body: CompanyIn, db: DbSession, p: Annotated[Principal, require("company.update")]):
    c = _company(db, p)
    before = audit.snapshot(c)
    data = body.model_dump()
    check_row_version(c, data.pop("row_version"))
    for k, v in data.items():
        setattr(c, k, v)
    c.updated_by = p.id
    audit.record(db, action="update", entity_type="company", entity_id=c.id, entity_label=c.company_name,
                 before=before, after=audit.snapshot(c))
    return ok(company_out(c, p))


@router.post("/company/logo")
async def upload_logo(db: DbSession, p: Annotated[Principal, require("company.update")], file: UploadFile = File(...)):
    c = _company(db, p)
    data = await file.read()
    if not (file.filename or "").lower().endswith((".png", ".jpg", ".jpeg", ".webp")):
        raise AppError("LOGO_NOT_IMAGE", "The logo must be a PNG, JPG or WEBP image.")
    doc = documents.upload(db, entity_type="company", entity_id=c.id, category="logo", file_name=file.filename or "logo",
                           data=data, user_id=p.id, replaces=c.logo_document_id)
    if not doc.content_type.startswith("image/") or doc.content_type == "image/heic":
        raise AppError("LOGO_NOT_IMAGE", "The logo must be a PNG, JPG or WEBP image.")
    c.logo_document_id = doc.id
    return ok(company_out(c, p))


@router.get("/company/logo")
def get_logo(db: DbSession, p: Annotated[Principal, require("company.read")]):
    c = _company(db, p)
    if c.logo_document_id is None:
        raise NotFound("logo")
    doc = documents.get(db, c.logo_document_id)
    return Response(get_storage().get(doc.storage_key), media_type=doc.content_type,
                    headers={"Cache-Control": "private, max-age=300"})


# ------------------------------------------------------------------ divisions
class DivisionIn(Schema):
    code: UpperStr = Field(min_length=1, max_length=20, pattern=r"^[A-Z0-9_-]+$")
    name: str = Field(min_length=2, max_length=120)
    description: Text(1000) = None
    is_active: bool = True


class DivisionUpdate(DivisionIn):
    row_version: int


def division_out(d: BusinessDivision) -> dict:
    return {"id": str(d.id), "code": d.code, "name": d.name, "description": d.description,
            "is_active": d.is_active, "row_version": d.row_version}


master_routes(router, path="/divisions", entity="division", model=BusinessDivision, perm="division",
              create_schema=DivisionIn, update_schema=DivisionUpdate, out=division_out, search=("code", "name"),
              sortable=("code", "name"), default_sort="name", label=lambda d: d.name, company_scoped=True)


# ------------------------------------------------------------------ settings
class SettingIn(Schema):
    value: bool | int | str


@router.get("/settings")
def get_settings_(db: DbSession, p: Annotated[Principal, require("settings.read")]):
    values = settings_service.all_settings(db, p.company_id)
    return ok([
        {"key": d.key, "label": d.label, "group": d.group, "help": d.help, "type": d.type.__name__,
         "value": values[d.key], "default": d.default}
        for d in settings_service.DEFINITIONS.values()
    ])


@router.put("/settings/{key}")
def put_setting(key: str, body: SettingIn, db: DbSession, p: Annotated[Principal, require("settings.update")]):
    return ok({"key": key, "value": settings_service.set_setting(db, p.company_id, key, body.value, p.id)})


# ------------------------------------------------------------------ numbering formats
class NumberingIn(Schema):
    pattern: str = Field(min_length=3, max_length=60)
    period: str = Field(pattern=r"^(fy|calendar|none)$")
    row_version: int


def numbering_out(f: NumberingFormat) -> dict:
    today = datetime.now().date()
    return {"doc_type": f.doc_type, "label": f.label, "pattern": f.pattern, "period": f.period,
            "max_length": f.max_length, "example": numbering.render(f.pattern, 1, today),
            "row_version": f.row_version}


@router.get("/numbering-formats")
def list_numbering(db: DbSession, p: Annotated[Principal, require("settings.read")]):
    rows = db.scalars(select(NumberingFormat).where(NumberingFormat.company_id == p.company_id)
                      .order_by(NumberingFormat.label))
    return ok([numbering_out(f) for f in rows])


@router.put("/numbering-formats/{doc_type}")
def update_numbering(doc_type: str, body: NumberingIn, db: DbSession,
                     p: Annotated[Principal, require("settings.update")]):
    f = db.scalar(select(NumberingFormat).where(NumberingFormat.company_id == p.company_id,
                                                NumberingFormat.doc_type == doc_type.upper()))
    if f is None:
        raise NotFound("numbering_format")
    numbering.validate_pattern(body.pattern, body.period, f.max_length)
    before = {"pattern": f.pattern, "period": f.period}
    check_row_version(f, body.row_version)
    f.pattern, f.period, f.updated_by = body.pattern, body.period, p.id
    audit.record(db, action="update", entity_type="numbering_format", entity_id=f.id, entity_label=f.label,
                 before=before, after={"pattern": f.pattern, "period": f.period},
                 summary="Numbering changes apply to documents issued from now on.")
    return ok(numbering_out(f))


