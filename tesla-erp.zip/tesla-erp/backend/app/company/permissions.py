from app.core.permissions import register

register("company", "Company profile", ("read", "update"))
register("division", "Business divisions", ("create", "read", "update", "delete"))
register("settings", "Settings & numbering", ("read", "update"))
