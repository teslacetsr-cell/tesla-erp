import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import EmailStr, Field

from app.core.api import Schema
from app.core.validators import Phone, Text

PosQty = Field(gt=0, max_digits=18, decimal_places=3)


class NewSupplierIn(Schema):
    """Quick-add a supplier that is not in the master yet (only a name and how to reach them)."""
    supplier_name: str = Field(min_length=2, max_length=200)
    phone: Phone = None
    email: EmailStr | None = None


class RfqLineIn(Schema):
    id: uuid.UUID | None = None  # an existing line keeps its identity (and the rates quoted on it)
    item_id: uuid.UUID | None = None
    description: str = Field(min_length=1, max_length=2000)
    specification: Text(4000) = None
    unit: str = Field(min_length=1, max_length=20)
    quantity: Decimal = PosQty
    required_by: date | None = None
    pr_line_id: uuid.UUID | None = None
    mr_line_id: uuid.UUID | None = None
    remarks: Text(500) = None


class RfqIn(Schema):
    rfq_date: date | None = None
    purchase_request_id: uuid.UUID | None = None
    material_request_id: uuid.UUID | None = None
    project_id: uuid.UUID | None = None
    warehouse_id: uuid.UUID | None = None
    delivery_location: Text(1000) = None
    due_date: date | None = None
    required_by: date | None = None
    contact_person: Text(300) = None
    terms: Text(4000) = None
    notes: Text(2000) = None
    compare_on: Literal["net", "total"] = "net"
    # On create from a purchase / material request, leave `lines` empty to copy the request's open lines.
    lines: list[RfqLineIn] = Field(default_factory=list, max_length=500)
    supplier_ids: list[uuid.UUID] = Field(default_factory=list, max_length=50)
    new_suppliers: list[NewSupplierIn] = Field(default_factory=list, max_length=20)


class RfqUpdate(RfqIn):
    row_version: int


class AddSupplierIn(Schema):
    supplier_id: uuid.UUID | None = None
    new_supplier: NewSupplierIn | None = None


class ReasonIn(Schema):
    reason: Text(500) = None
    row_version: int | None = None


class QuoteLineIn(Schema):
    rfq_line_id: uuid.UUID
    not_quoted: bool = False
    unit_rate: Decimal | None = Field(default=None, ge=0, max_digits=18, decimal_places=4)
    discount_pct: Decimal = Field(default=Decimal("0"), ge=0, le=100, max_digits=7, decimal_places=4)
    gst_pct: Decimal = Field(default=Decimal("18"), ge=0, le=100, max_digits=7, decimal_places=4)
    make: Text(120) = None
    delivery_days: int | None = Field(default=None, ge=0, le=3650)
    remarks: Text(500) = None


class QuotationIn(Schema):
    quote_ref: Text(100) = None
    quote_date: date | None = None
    valid_until: date | None = None
    payment_terms: Text(500) = None
    delivery_period: Text(300) = None
    freight_included: bool = True
    freight_amount: Decimal = Field(default=Decimal("0"), ge=0, max_digits=18, decimal_places=2)
    warranty: Text(300) = None
    gst_inclusive: bool = False
    notes: Text(2000) = None
    source: Literal["manual", "excel", "ai"] = "manual"
    lines: list[QuoteLineIn] = Field(min_length=1, max_length=500)
    row_version: int | None = None


class SelectionLineIn(Schema):
    rfq_line_id: uuid.UUID
    quotation_id: uuid.UUID | None = None  # null = do not order this line now
    remark: Text(500) = None


class SelectionIn(Schema):
    lines: list[SelectionLineIn] = Field(min_length=1, max_length=500)
    row_version: int | None = None


class CreateOrdersIn(Schema):
    warehouse_id: uuid.UUID | None = None
    expected_delivery: date | None = None
    row_version: int | None = None
