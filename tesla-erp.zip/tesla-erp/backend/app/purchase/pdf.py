"""Purchase order and GRN PDFs on the Tesla letterhead."""
import io
from collections import defaultdict
from decimal import Decimal
from html import escape

from reportlab.lib.units import mm
from reportlab.platypus import KeepTogether, ListFlowable, ListItem, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from sqlalchemy.orm import Session

from app.boq.pdf import lines_table, totals_table
from app.core.gst import amount_in_words
from app.platform import pdfkit as K
from app.products.models import Warehouse
from app.projects.models import Project
from app.purchase.models import Grn, PurchaseOrder
from app.suppliers.models import Supplier, SupplierContact


def _date(d) -> str:
    return d.strftime("%d %b %Y") if d else "—"


def _rate(r: Decimal) -> str:
    return f"{r.normalize():f}"


def _qty(v: Decimal) -> str:
    return f"{v.normalize():f}"


def _supplier_block(sup: Supplier, st) -> list:
    out = [Paragraph("Supplier", st["label"]), Paragraph(f"<b>{escape(sup.supplier_name)}</b>", st["base"])]
    for a in (sup.address_line1, sup.address_line2, ", ".join(x for x in (sup.city, sup.state, sup.pincode) if x)):
        if a:
            out.append(Paragraph(escape(a), st["base"]))
    if sup.gstin:
        out.append(Paragraph(f"GSTIN {escape(sup.gstin)}", st["base"]))
    if sup.phone or sup.email:
        out.append(Paragraph(escape(" · ".join(x for x in (sup.phone, sup.email) if x)), st["small"]))
    return out


def _box(left, right) -> Table:
    box = Table([[left, right]], colWidths=[92 * mm, None])
    box.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("BOX", (0, 0), (-1, -1), 0.5, K.LINE),
                             ("LINEAFTER", (0, 0), (0, 0), 0.5, K.LINE), ("TOPPADDING", (0, 0), (-1, -1), 5),
                             ("BOTTOMPADDING", (0, 0), (-1, -1), 5), ("LEFTPADDING", (0, 0), (-1, -1), 6)]))
    return box


def _head(title: str, right: str, st) -> Table:
    head = Table([[Paragraph(title, st["title"]), Paragraph(right, st["right"])]], colWidths=[None, 75 * mm])
    head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "BOTTOM"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                              ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    return head


def build_po(db: Session, po: PurchaseOrder) -> bytes:
    K.fonts()
    st = K.styles()
    sup = db.get(Supplier, po.supplier_id)
    wh = db.get(Warehouse, po.warehouse_id)
    prj = db.get(Project, po.project_id) if po.project_id else None
    contact = db.get(SupplierContact, po.contact_id) if po.contact_id else None
    number = po.po_number or "DRAFT"
    approved = po.status not in ("draft", "pending_approval")
    story = K.letterhead(db, st)
    story += [_head("PURCHASE ORDER", f"<b>PO No.</b> {escape(number)}<br/><b>Date</b> {_date(po.po_date)}"
                    + (f"<br/><b>Delivery by</b> {_date(po.expected_delivery)}" if po.expected_delivery else ""), st),
              Spacer(1, 3 * mm)]
    left = _supplier_block(sup, st)
    if contact:
        left.append(Paragraph(f"Kind attention: {escape(contact.name)}", st["small"]))
    right = [Paragraph("Deliver to", st["label"]), Paragraph(f"<b>{escape(wh.name)}</b>", st["base"])]
    if po.delivery_address:
        right.append(K.p(po.delivery_address, st["small"]))
    if prj:
        right += [Spacer(1, 1.5 * mm), Paragraph("Project", st["label"]),
                  Paragraph(f"{escape(prj.project_number)} · {escape(prj.name)}", st["small"])]
    if po.supplier_quote_ref:
        right += [Spacer(1, 1.5 * mm), Paragraph("Your quotation", st["label"]), Paragraph(escape(po.supplier_quote_ref), st["small"])]
    right += [Spacer(1, 1.5 * mm), Paragraph(
        f"{'Inter-state (IGST)' if po.inter_state else 'Intra-state (CGST + SGST)'}", st["small"])]
    story += [_box(left, right), Spacer(1, 3 * mm),
              K.p("Please supply the following as per the terms below and quote our PO number on your invoice and "
                  "delivery challan.", st["base"]), Spacer(1, 3 * mm), lines_table(po.items, st), Spacer(1, 3 * mm)]
    by_rate: dict[Decimal, dict] = defaultdict(lambda: {"cgst": Decimal(0), "sgst": Decimal(0), "igst": Decimal(0)})
    for it in po.items:
        for k in ("cgst", "sgst", "igst"):
            by_rate[it.tax_rate][k] += getattr(it, k)
    rows = [("Total", K.money(po.gross), False)]
    if po.line_discount:
        rows.append(("Less: discount", "− " + K.money(po.line_discount), False))
    if po.special_discount:
        rows.append(("Less: special discount", "− " + K.money(po.special_discount), False))
    rows.append(("Taxable value", K.money(po.taxable), True))
    for rate in sorted(by_rate):
        t = by_rate[rate]
        if po.inter_state and t["igst"]:
            rows.append((f"IGST @ {_rate(rate)} %", K.money(t["igst"]), False))
        elif not po.inter_state and t["cgst"]:
            half = _rate(rate / 2)
            rows += [(f"CGST @ {half} %", K.money(t["cgst"]), False), (f"SGST @ {half} %", K.money(t["sgst"]), False)]
    if po.round_off:
        rows.append(("Round off", ("+ " if po.round_off > 0 else "− ") + K.money(abs(po.round_off)), False))
    rows.append(("PO value (₹)", K.money(po.grand_total), True))
    story.append(KeepTogether([totals_table(rows, st, width=95 * mm), Spacer(1, 1.5 * mm),
                               Paragraph(f"<b>In words:</b> {escape(amount_in_words(po.grand_total))}", st["base"])]))
    commercial = [("Payment", po.payment_terms), ("Delivery", po.delivery_terms), ("Warranty", po.warranty)]
    crow = [[Paragraph(f"<b>{k}</b>", st["cell"]), K.p(v, st["cell"])] for k, v in commercial if v]
    if crow:
        ct = Table(crow, colWidths=[28 * mm, None])
        ct.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, -1), 0.3, K.LINE),
                                ("LEFTPADDING", (0, 0), (-1, -1), 2)]))
        story += [Paragraph("Commercial terms", st["h"]), ct]
    if po.terms:
        story += [Paragraph("Terms and conditions", st["h"]),
                  ListFlowable([ListItem(K.p(t, st["base"]), leftIndent=10) for t in po.terms], bulletType="1",
                               bulletFontName="DejaVu", bulletFontSize=8, leftIndent=12)]
    if po.notes:
        story += [Paragraph("Notes", st["h"]), K.p(po.notes, st["base"])]
    company = K.company_snapshot(db)
    name = (company or {}).get("company_name") or "Tesla Consulting Engineers"
    gst = (company or {}).get("gstin")
    story.append(KeepTogether([Spacer(1, 6 * mm)] + ([Paragraph(f"Our GSTIN: {escape(gst)}", st["small"])] if gst else [])
                              + [Paragraph(f"For <b>{escape(name)}</b>", st["base"]), Spacer(1, 14 * mm),
                                 Paragraph("Authorised Signatory", st["base"])]))
    buf = io.BytesIO()
    watermark = None if approved and po.status != "cancelled" else ("CANCELLED" if po.status == "cancelled" else "DRAFT")
    SimpleDocTemplate(buf, pagesize=K.PAGE, leftMargin=K.MARGIN, rightMargin=K.MARGIN, topMargin=10 * mm,
                      bottomMargin=14 * mm, title=f"Purchase order {number}", author=name).build(
        story, canvasmaker=K.numbered_canvas(f"Purchase order {number}", watermark))
    return buf.getvalue()


def build_grn(db: Session, g: Grn) -> bytes:
    K.fonts()
    st = K.styles()
    sup = db.get(Supplier, g.supplier_id)
    wh = db.get(Warehouse, g.warehouse_id)
    po = db.get(PurchaseOrder, g.purchase_order_id)
    story = K.letterhead(db, st)
    story += [_head("GOODS RECEIVED NOTE", f"<b>GRN No.</b> {escape(g.grn_number)}<br/><b>Date</b> {_date(g.grn_date)}"
                    f"<br/><b>PO</b> {escape(po.po_number or '')}", st), Spacer(1, 3 * mm)]
    right = [Paragraph("Received at", st["label"]), Paragraph(f"<b>{escape(wh.name)}</b>", st["base"])]
    for label, v in (("Supplier invoice", " · ".join(x for x in (g.supplier_invoice_no, _date(g.supplier_invoice_date)
                                                                   if g.supplier_invoice_date else None) if x)),
                     ("Delivery challan", g.delivery_challan_no), ("Vehicle", g.vehicle_no)):
        if v:
            right += [Spacer(1, 1.2 * mm), Paragraph(label, st["label"]), Paragraph(escape(v), st["small"])]
    story += [_box(_supplier_block(sup, st), right), Spacer(1, 4 * mm)]
    head = ["#", "Description", "Unit", "Ordered", "Received", "Accepted", "Rejected", "Value (₹)"]
    data = [[Paragraph(f"<b>{h}</b>", st["cellr"] if i >= 3 else st["cell"]) for i, h in enumerate(head)]]
    for ln in g.lines:
        desc = f"<b>{escape(ln.description)}</b>"
        if ln.batch_no:
            desc += f"<br/><font size=6.8 color='#6b7280'>Batch {escape(ln.batch_no)}" + \
                    (f" · expiry {_date(ln.expiry_date)}" if ln.expiry_date else "") + "</font>"
        if ln.serial_nos:
            desc += f"<br/><font size=6.8 color='#6b7280'>Serial nos: {escape(', '.join(ln.serial_nos))}</font>"
        if ln.rejected_qty:
            desc += f"<br/><font size=6.8 color='#b91c1c'>Rejected: {escape(ln.rejection_reason or '')}</font>"
        data.append([Paragraph(str(ln.line_no), st["cell"]), Paragraph(desc, st["cell"]), Paragraph(escape(ln.unit), st["cell"])]
                    + [Paragraph(_qty(v), st["cellr"]) for v in (ln.ordered_qty, ln.received_qty, ln.accepted_qty, ln.rejected_qty)]
                    + [Paragraph(K.money(ln.value), st["cellr"])])
    t = Table(data, colWidths=[7 * mm, 72 * mm, 12 * mm, 17 * mm, 17 * mm, 17 * mm, 17 * mm, 23 * mm], repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), K.TINT), ("LINEBELOW", (0, 0), (-1, 0), 0.8, K.RED),
                           ("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 1), (-1, -1), 0.3, K.LINE),
                           ("LEFTPADDING", (0, 0), (-1, -1), 2.5), ("RIGHTPADDING", (0, 0), (-1, -1), 2.5)]))
    story += [t, Spacer(1, 3 * mm), totals_table([("Accepted value, before GST (₹)", K.money(g.value), True)], st, 95 * mm)]
    if g.notes:
        story += [Paragraph("Notes", st["h"]), K.p(g.notes, st["base"])]
    sig = Table([[Paragraph("Received by", st["label"]), Paragraph("Checked by", st["label"]),
                  Paragraph("Store in-charge", st["label"])]], colWidths=[60 * mm] * 3)
    sig.setStyle(TableStyle([("TOPPADDING", (0, 0), (-1, -1), 16 * mm), ("LINEABOVE", (0, 0), (-1, -1), 0.4, K.INK)]))
    story += [Spacer(1, 8 * mm), sig]
    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=K.PAGE, leftMargin=K.MARGIN, rightMargin=K.MARGIN, topMargin=10 * mm,
                      bottomMargin=14 * mm, title=f"GRN {g.grn_number}").build(
        story, canvasmaker=K.numbered_canvas(f"GRN {g.grn_number}"))
    return buf.getvalue()
