import uuid
from decimal import Decimal
from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from sqlalchemy import func, select

from app.auth.deps import Principal, get_principal, require
from app.boq import lines as L
from app.core import excel
from app.core.api import ListParams, ok
from app.core.db import DbSession
from app.core.errors import Forbidden
from app.inventory.models import StockBalance
from app.inventory.router import wh_ref
from app.platform.approvals import service as approvals
from app.platform.approvals.router import request_out
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.products.models import Item, Warehouse
from app.projects.models import Project, ProjectBoqLine
from app.purchase import pdf, service
from app.purchase.models import Grn, MaterialRequest, MaterialRequestLine, PurchaseOrder, PurchaseRequest, PurchaseRequestLine
from app.purchase.schemas import (
    GrnIn,
    MaterialRequestIn,
    MaterialRequestUpdate,
    PurchaseOrderIn,
    PurchaseOrderUpdate,
    PurchaseRequestIn,
    PurchaseRequestUpdate,
    ReasonIn,
)
from app.suppliers.models import Supplier, SupplierContact
from app.users.models import User

router = APIRouter(tags=["purchase"])
Z = Decimal("0")

documents.register_entity("material_request", "material_request", MaterialRequest,
                          check=lambda p, mr, action: service.mr_check(p, mr, "read" if action == "read" else "update"))
documents.register_entity("purchase_order", "purchase_order", PurchaseOrder)
documents.register_entity("grn", "grn", Grn)


def _q(v) -> str:
    return f"{Decimal(v).normalize():f}"


def _names(db, ids) -> dict:
    ids = {i for i in ids if i}
    return dict(db.execute(select(User.id, User.full_name).where(User.id.in_(ids))).all()) if ids else {}


def _project_ref(db, pid) -> dict | None:
    if not pid:
        return None
    p = db.get(Project, pid)
    return {"id": str(p.id), "number": p.project_number, "name": p.name} if p else None


def _wh(db, wid) -> dict | None:
    return wh_ref(db.get(Warehouse, wid)) if wid else None


def _stock_by_item(db, item_ids, warehouse_id=None) -> dict:
    ids = {i for i in item_ids if i}
    if not ids:
        return {}
    total = dict(db.execute(select(StockBalance.item_id, func.sum(StockBalance.quantity))
                            .where(StockBalance.item_id.in_(ids)).group_by(StockBalance.item_id)).all())
    here = dict(db.execute(select(StockBalance.item_id, StockBalance.quantity).where(
        StockBalance.item_id.in_(ids), StockBalance.warehouse_id == warehouse_id)).all()) if warehouse_id else {}
    return {i: (total.get(i, Z), here.get(i, Z)) for i in ids}


def _item_codes(db, ids) -> dict:
    ids = {i for i in ids if i}
    return dict(db.execute(select(Item.id, Item.item_code).where(Item.id.in_(ids))).all()) if ids else {}


# ================================================================== material requests
def mr_out(db, p: Principal, mr: MaterialRequest, detail: bool = False) -> dict:
    names = _names(db, [mr.created_by])
    out = {"id": str(mr.id), "mr_number": mr.mr_number, "request_date": mr.request_date.isoformat(), "status": mr.status,
           "priority": mr.priority, "required_by": mr.required_by.isoformat() if mr.required_by else None,
           "project": _project_ref(db, mr.project_id), "warehouse": _wh(db, mr.warehouse_id), "purpose": mr.purpose,
           "lines_count": len(mr.lines), "requested_by": names.get(mr.created_by), "created_at": mr.created_at.isoformat(),
           "row_version": mr.row_version}
    if not detail:
        return out
    stock = _stock_by_item(db, [ln.item_id for ln in mr.lines], mr.warehouse_id)
    codes = _item_codes(db, [ln.item_id for ln in mr.lines])
    boq = {b.id: b.line_no for b in db.scalars(select(ProjectBoqLine).where(
        ProjectBoqLine.id.in_({ln.project_boq_line_id for ln in mr.lines} - {None})))}
    prs = db.execute(select(PurchaseRequest.id, PurchaseRequest.pr_number, PurchaseRequest.status).distinct()
                     .join(PurchaseRequestLine, PurchaseRequestLine.request_id == PurchaseRequest.id)
                     .where(PurchaseRequestLine.mr_line_id.in_([ln.id for ln in mr.lines]))).all() if mr.lines else []
    upd = service.mr_allowed(p, mr, "update")
    decide = p.can("material_request.approve") and mr.status in ("submitted", "in_progress")
    return out | {
        "status_reason": mr.status_reason, "submitted_at": mr.submitted_at.isoformat() if mr.submitted_at else None,
        "lines": [{"id": str(ln.id), "line_no": ln.line_no, "item_id": str(ln.item_id) if ln.item_id else None,
                   "item_code": codes.get(ln.item_id), "description": ln.description, "unit": ln.unit,
                   "quantity": _q(ln.quantity), "processed_qty": _q(ln.processed_qty),
                   "remaining_qty": _q(max(Z, ln.quantity - ln.processed_qty)),
                   "project_boq_line_id": str(ln.project_boq_line_id) if ln.project_boq_line_id else None,
                   "boq_line_no": boq.get(ln.project_boq_line_id), "remarks": ln.remarks,
                   "stock_total": _q(stock[ln.item_id][0]) if ln.item_id in stock else None,
                   "stock_here": _q(stock[ln.item_id][1]) if ln.item_id in stock and mr.warehouse_id else None}
                  for ln in mr.lines],
        "purchase_requests": [{"id": str(i), "pr_number": n, "status": s} for i, n, s in prs],
        "can": {"edit": upd and mr.status == "draft", "submit": upd and mr.status == "draft",
                "delete": service.mr_allowed(p, mr, "delete") and mr.mr_number is None,
                "cancel": upd and mr.status in ("draft", "submitted") and not any(ln.processed_qty for ln in mr.lines),
                "create_pr": p.can("purchase_request.create") and mr.status in ("submitted", "in_progress"),
                "reject": decide and not any(ln.processed_qty for ln in mr.lines), "close": decide},
    }


@router.get("/material-requests")
def list_mrs(db: DbSession, p: Annotated[Principal, require("material_request.read")],
             params: Annotated[ListParams, Depends()], status: str | None = None, project_id: uuid.UUID | None = None,
             open_only: bool = False):
    rows, meta = service.list_mrs(db, p, params, status=status, project_id=project_id, open_only=open_only)
    return {"data": [mr_out(db, p, r) for r in rows], "meta": meta.model_dump()}


@router.post("/material-requests", status_code=201)
def create_mr(body: MaterialRequestIn, db: DbSession, p: Annotated[Principal, require("material_request.create")]):
    return ok(mr_out(db, p, service.create_mr(db, p, body), detail=True))


@router.get("/material-requests/{mid}")
def get_mr(mid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("material_request.read")]):
    mr = service.get_mr(db, mid)
    service.mr_check(p, mr, "read")
    return ok(mr_out(db, p, mr, detail=True))


@router.put("/material-requests/{mid}")
def update_mr(mid: uuid.UUID, body: MaterialRequestUpdate, db: DbSession,
              p: Annotated[Principal, require("material_request.update")]):
    return ok(mr_out(db, p, service.update_mr(db, p, mid, body), detail=True))


@router.delete("/material-requests/{mid}")
def delete_mr(mid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("material_request.delete")]):
    service.delete_mr(db, p, mid)
    return ok({"ok": True})


@router.post("/material-requests/{mid}/submit")
def submit_mr(mid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("material_request.update")]):
    return ok(mr_out(db, p, service.submit_mr(db, p, mid), detail=True))


@router.post("/material-requests/{mid}/{action}")
def mr_action(mid: uuid.UUID, action: str, body: ReasonIn, db: DbSession, p: Annotated[Principal, Depends(get_principal)]):
    if action not in ("reject", "close", "cancel"):
        from app.core.errors import NotFound
        raise NotFound("action")
    return ok(mr_out(db, p, service.mr_decision(db, p, mid, action, body.reason), detail=True))


# ================================================================== purchase requests
def pr_out(db, p: Principal, pr: PurchaseRequest, detail: bool = False) -> dict:
    names = _names(db, [pr.created_by])
    out = {"id": str(pr.id), "pr_number": pr.pr_number, "pr_date": pr.pr_date.isoformat(), "status": pr.status,
           "priority": pr.priority, "required_by": pr.required_by.isoformat() if pr.required_by else None,
           "project": _project_ref(db, pr.project_id), "warehouse": _wh(db, pr.warehouse_id),
           "estimated_value": str(pr.estimated_value), "lines_count": len(pr.lines),
           "created_by": names.get(pr.created_by), "created_at": pr.created_at.isoformat(), "row_version": pr.row_version}
    if not detail:
        return out
    mr_lines = {m.id: m for m in db.scalars(select(MaterialRequestLine).where(
        MaterialRequestLine.id.in_({ln.mr_line_id for ln in pr.lines} - {None})))}
    mr_nums = dict(db.execute(select(MaterialRequest.id, MaterialRequest.mr_number).where(
        MaterialRequest.id.in_({m.request_id for m in mr_lines.values()}))).all()) if mr_lines else {}
    sups = dict(db.execute(select(Supplier.id, Supplier.supplier_name).where(
        Supplier.id.in_({ln.suggested_supplier_id for ln in pr.lines} - {None}))).all()) if pr.lines else {}
    stock = _stock_by_item(db, [ln.item_id for ln in pr.lines], pr.warehouse_id)
    codes = _item_codes(db, [ln.item_id for ln in pr.lines])
    from app.purchase.models import PurchaseOrderItem

    pos = db.execute(select(PurchaseOrder.id, PurchaseOrder.po_number, PurchaseOrder.status).distinct()
                     .join(PurchaseOrderItem, PurchaseOrderItem.purchase_order_id == PurchaseOrder.id)
                     .where(PurchaseOrderItem.pr_line_id.in_([ln.id for ln in pr.lines]))).all() if pr.lines else []
    pending = approvals.pending_for(db, "purchase_request", pr.id)
    upd = p.can("purchase_request.update")
    ordered = any(ln.ordered_qty for ln in pr.lines)
    return out | {
        "notes": pr.notes, "status_reason": pr.status_reason, "last_rejection": pr.last_rejection,
        "approved_at": pr.approved_at.isoformat() if pr.approved_at else None,
        "lines": [{"id": str(ln.id), "line_no": ln.line_no, "item_id": str(ln.item_id) if ln.item_id else None,
                   "item_code": codes.get(ln.item_id), "description": ln.description, "unit": ln.unit,
                   "quantity": _q(ln.quantity), "estimated_rate": str(ln.estimated_rate),
                   "estimated_amount": str(ln.estimated_amount), "ordered_qty": _q(ln.ordered_qty),
                   "remaining_qty": _q(max(Z, ln.quantity - ln.ordered_qty)),
                   "mr_line_id": str(ln.mr_line_id) if ln.mr_line_id else None,
                   "mr_number": mr_nums.get(mr_lines[ln.mr_line_id].request_id) if ln.mr_line_id in mr_lines else None,
                   "project_boq_line_id": str(ln.project_boq_line_id) if ln.project_boq_line_id else None,
                   "suggested_supplier_id": str(ln.suggested_supplier_id) if ln.suggested_supplier_id else None,
                   "suggested_supplier": sups.get(ln.suggested_supplier_id), "remarks": ln.remarks,
                   "stock_total": _q(stock[ln.item_id][0]) if ln.item_id in stock else None} for ln in pr.lines],
        "purchase_orders": [{"id": str(i), "po_number": n, "status": s} for i, n, s in pos],
        "approval": request_out(db, p, pending) if pending else None,
        "approvals": [request_out(db, p, r) for r in approvals.history(db, "purchase_request", pr.id)],
        "can": {"edit": upd and pr.status == "draft", "submit": upd and pr.status == "draft",
                "withdraw": upd and pr.status == "pending_approval",
                "cancel": upd and pr.status in ("draft", "pending_approval", "approved") and not ordered,
                "close": upd and pr.status in ("approved", "partially_ordered"),
                "delete": p.can("purchase_request.delete") and pr.pr_number is None,
                "create_po": p.can("purchase_order.create") and pr.status in ("approved", "partially_ordered"),
                "decide": bool(pending and approvals.can_decide(p, pending))},
    }


@router.get("/purchase-requests")
def list_prs(db: DbSession, p: Annotated[Principal, require("purchase_request.read")],
             params: Annotated[ListParams, Depends()], status: str | None = None, project_id: uuid.UUID | None = None,
             open_only: bool = False, orderable: bool = False):
    rows, meta = service.list_prs(db, params, status=status, project_id=project_id, open_only=open_only,
                                  orderable=orderable)
    return {"data": [pr_out(db, p, r) for r in rows], "meta": meta.model_dump()}


@router.post("/purchase-requests", status_code=201)
def create_pr(body: PurchaseRequestIn, db: DbSession, p: Annotated[Principal, require("purchase_request.create")]):
    return ok(pr_out(db, p, service.create_pr(db, p, body), detail=True))


@router.get("/purchase-requests/{rid}")
def get_pr(rid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("purchase_request.read")]):
    return ok(pr_out(db, p, service.get_pr(db, rid), detail=True))


@router.put("/purchase-requests/{rid}")
def update_pr(rid: uuid.UUID, body: PurchaseRequestUpdate, db: DbSession,
              p: Annotated[Principal, require("purchase_request.update")]):
    return ok(pr_out(db, p, service.update_pr(db, p, rid, body), detail=True))


@router.delete("/purchase-requests/{rid}")
def delete_pr(rid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("purchase_request.delete")]):
    service.delete_pr(db, p, rid)
    return ok({"ok": True})


@router.post("/purchase-requests/{rid}/submit")
def submit_pr(rid: uuid.UUID, body: ReasonIn, db: DbSession, p: Annotated[Principal, require("purchase_request.update")]):
    return ok(pr_out(db, p, service.submit_pr(db, p, rid, body.row_version), detail=True))


@router.post("/purchase-requests/{rid}/{action}")
def pr_action(rid: uuid.UUID, action: str, body: ReasonIn, db: DbSession,
              p: Annotated[Principal, require("purchase_request.update")]):
    if action not in ("withdraw", "cancel", "close"):
        from app.core.errors import NotFound
        raise NotFound("action")
    return ok(pr_out(db, p, service.pr_action(db, p, rid, action, body.reason), detail=True))


# ================================================================== purchase orders
def po_out(db, p: Principal, po: PurchaseOrder, detail: bool = False) -> dict:
    sup = db.get(Supplier, po.supplier_id)
    names = _names(db, [po.created_by])
    out = {"id": str(po.id), "po_number": po.po_number, "display_number": po.po_number or "DRAFT",
           "po_date": po.po_date.isoformat(), "status": po.status,
           "supplier": {"id": str(sup.id), "name": sup.supplier_name, "code": sup.supplier_code, "city": sup.city},
           "project": _project_ref(db, po.project_id), "warehouse": _wh(db, po.warehouse_id),
           "expected_delivery": po.expected_delivery.isoformat() if po.expected_delivery else None,
           "taxable": str(po.taxable), "grand_total": str(po.grand_total), "created_by": names.get(po.created_by),
           "created_at": po.created_at.isoformat(), "row_version": po.row_version}
    if not detail:
        return out
    grns = db.execute(select(Grn.id, Grn.grn_number, Grn.grn_date, Grn.value).where(Grn.purchase_order_id == po.id)
                      .order_by(Grn.created_at)).all()
    pr_lines = {x.id: x for x in db.scalars(select(PurchaseRequestLine).where(
        PurchaseRequestLine.id.in_({it.pr_line_id for it in po.items} - {None})))}
    pr_nums = dict(db.execute(select(PurchaseRequest.id, PurchaseRequest.pr_number).where(
        PurchaseRequest.id.in_({x.request_id for x in pr_lines.values()}))).all()) if pr_lines else {}
    items = {i.id: i for i in db.scalars(select(Item).where(Item.id.in_({it.item_id for it in po.items} - {None})))}
    contact = db.get(SupplierContact, po.contact_id) if po.contact_id else None
    pending = approvals.pending_for(db, "purchase_order", po.id)
    upd = p.can("purchase_order.update")
    received = any(it.received_qty or it.rejected_qty for it in po.items)
    s = po.status
    lines = []
    for it in po.items:
        row = L.line_out(it)
        item = items.get(it.item_id)
        row |= {"received_qty": _q(it.received_qty), "rejected_qty": _q(it.rejected_qty),
                "pending_qty": _q(max(Z, it.quantity - it.received_qty)), "net_rate": str(service.net_rate(it)),
                "pr_line_id": str(it.pr_line_id) if it.pr_line_id else None,
                "pr_number": pr_nums.get(pr_lines[it.pr_line_id].request_id) if it.pr_line_id in pr_lines else None,
                "project_boq_line_id": str(it.project_boq_line_id) if it.project_boq_line_id else None,
                "item_code": item.item_code if item else None, "stocked": bool(item and item.item_type == "goods"),
                "serial": bool(item and item.serial_number_required), "batch": bool(item and item.batch_required)}
        lines.append(row)
    return out | {
        "contact_id": str(po.contact_id) if po.contact_id else None, "contact": contact.name if contact else None,
        "delivery_address": po.delivery_address, "supplier_quote_ref": po.supplier_quote_ref,
        "payment_terms": po.payment_terms, "delivery_terms": po.delivery_terms, "warranty": po.warranty,
        "terms": po.terms, "notes": po.notes, "status_reason": po.status_reason, "last_rejection": po.last_rejection,
        "place_of_supply": po.place_of_supply, "inter_state": po.inter_state, "special_discount": str(po.special_discount),
        **{k: str(getattr(po, k)) for k in service.TOTALS},
        "tax_summary": [{"rate": f"{r.normalize():f}", "cgst": str(sum(i.cgst for i in po.items if i.tax_rate == r)),
                         "sgst": str(sum(i.sgst for i in po.items if i.tax_rate == r)),
                         "igst": str(sum(i.igst for i in po.items if i.tax_rate == r))}
                        for r in sorted({i.tax_rate for i in po.items})],
        "items": lines,
        "submitted_at": po.submitted_at.isoformat() if po.submitted_at else None,
        "approved_at": po.approved_at.isoformat() if po.approved_at else None,
        "sent_at": po.sent_at.isoformat() if po.sent_at else None,
        "grns": [{"id": str(i), "grn_number": n, "grn_date": d.isoformat(), "value": str(v)} for i, n, d, v in grns],
        "approval": request_out(db, p, pending) if pending else None,
        "approvals": [request_out(db, p, r) for r in approvals.history(db, "purchase_order", po.id)],
        "can": {"edit": upd and s == "draft", "submit": upd and s == "draft",
                "withdraw": upd and s in ("pending_approval", "approved"), "send": upd and s == "approved",
                "cancel": upd and s not in ("received", "closed", "cancelled") and not received,
                "close": upd and s in ("approved", "sent", "partially_received"),
                "delete": p.can("purchase_order.delete") and po.po_number is None,
                "receive": p.can("grn.create") and s in ("approved", "sent", "partially_received"),
                "print": p.can("purchase_order.print"), "decide": bool(pending and approvals.can_decide(p, pending))},
    }


@router.get("/purchase-orders")
def list_pos(db: DbSession, p: Annotated[Principal, require("purchase_order.read")],
             params: Annotated[ListParams, Depends()], status: str | None = None, supplier_id: uuid.UUID | None = None,
             project_id: uuid.UUID | None = None, open_only: bool = False, receivable: bool = False):
    rows, meta = service.list_pos(db, params, status=status, supplier_id=supplier_id, project_id=project_id,
                                  open_only=open_only, receivable=receivable)
    return {"data": [po_out(db, p, r) for r in rows], "meta": meta.model_dump()}


@router.get("/purchase-orders/summary")
def po_summary(db: DbSession, p: Annotated[Principal, Depends(get_principal)]):
    if not any(p.can(c) for c in ("purchase_order.read", "purchase_request.read", "material_request.read", "grn.read")):
        raise Forbidden()
    count = lambda model, col, statuses: db.scalar(select(func.count()).select_from(model).where(col.in_(statuses)))  # noqa: E731
    out = {}
    if p.can("purchase_order.read"):
        out |= {"po_pending_approval": count(PurchaseOrder, PurchaseOrder.status, ("pending_approval",)),
                "po_to_send": count(PurchaseOrder, PurchaseOrder.status, ("approved",)),
                "po_awaiting_delivery": count(PurchaseOrder, PurchaseOrder.status, ("sent", "partially_received")),
                "open_po_value": str(db.scalar(select(func.coalesce(func.sum(PurchaseOrder.taxable), 0)).where(
                    PurchaseOrder.status.in_(("approved", "sent", "partially_received")))))}
    if p.can("purchase_request.read"):
        out |= {"pr_pending_approval": count(PurchaseRequest, PurchaseRequest.status, ("pending_approval",)),
                "pr_to_order": count(PurchaseRequest, PurchaseRequest.status, ("approved", "partially_ordered"))}
    if p.can("material_request.read") and p.scope("material_request.read") == "all":
        out |= {"mr_open": count(MaterialRequest, MaterialRequest.status, ("submitted", "in_progress"))}
    return ok(out)


PO_EXPORT = [excel.Column("po_number", "PO number", 22), excel.Column("po_date", "Date", 12),
             excel.Column("supplier", "Supplier", 32), excel.Column("project", "Project", 26),
             excel.Column("warehouse", "Deliver to", 24), excel.Column("taxable", "Value before GST (₹)", 18),
             excel.Column("grand_total", "PO value (₹)", 16), excel.Column("status", "Status", 16),
             excel.Column("expected_delivery", "Delivery by", 12)]


@router.get("/purchase-orders/export")
def export_pos(db: DbSession, p: Annotated[Principal, require("purchase_order.export")],
               params: Annotated[ListParams, Depends()], status: str | None = None):
    params.page, params.page_size = 1, 100000
    rows, _ = service.list_pos(db, params, status=status)
    data = []
    for po in rows:
        r = po_out(db, p, po)
        data.append({"po_number": po.po_number or "DRAFT", "po_date": po.po_date, "supplier": r["supplier"]["name"],
                     "project": (r["project"] or {}).get("number"), "warehouse": (r["warehouse"] or {}).get("name"),
                     "taxable": po.taxable, "grand_total": po.grand_total, "status": po.status.replace("_", " "),
                     "expected_delivery": po.expected_delivery})
    audit.record(db, action="export", entity_type="purchase_order", summary=f"Exported {len(data)} purchase orders")
    return Response(excel.export("Purchase orders", PO_EXPORT, data), media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="purchase-orders.xlsx"'})


@router.post("/purchase-orders", status_code=201)
def create_po(body: PurchaseOrderIn, db: DbSession, p: Annotated[Principal, require("purchase_order.create")]):
    return ok(po_out(db, p, service.create_po(db, p, body), detail=True))


@router.get("/purchase-orders/{oid}")
def get_po(oid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("purchase_order.read")]):
    return ok(po_out(db, p, service.get_po(db, oid), detail=True))


@router.put("/purchase-orders/{oid}")
def update_po(oid: uuid.UUID, body: PurchaseOrderUpdate, db: DbSession,
              p: Annotated[Principal, require("purchase_order.update")]):
    return ok(po_out(db, p, service.update_po(db, p, oid, body), detail=True))


@router.delete("/purchase-orders/{oid}")
def delete_po(oid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("purchase_order.delete")]):
    service.delete_po(db, p, oid)
    return ok({"ok": True})


@router.get("/purchase-orders/{oid}/pdf")
def po_pdf(oid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("purchase_order.print")]):
    po = service.get_po(db, oid)
    audit.record(db, action="print", entity_type="purchase_order", entity_id=po.id, entity_label=po.po_number or "Draft PO")
    name = (po.po_number or "DRAFT-PO").replace("/", "-")
    return Response(pdf.build_po(db, po), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{name}.pdf"', "Cache-Control": "no-store"})


@router.post("/purchase-orders/{oid}/submit")
def submit_po(oid: uuid.UUID, body: ReasonIn, db: DbSession, p: Annotated[Principal, require("purchase_order.update")]):
    return ok(po_out(db, p, service.submit_po(db, p, oid, body.row_version), detail=True))


@router.post("/purchase-orders/{oid}/{action}")
def po_action(oid: uuid.UUID, action: str, body: ReasonIn, db: DbSession,
              p: Annotated[Principal, require("purchase_order.update")]):
    if action not in ("send", "withdraw", "cancel", "close"):
        from app.core.errors import NotFound
        raise NotFound("action")
    return ok(po_out(db, p, service.po_action(db, p, oid, action, body.reason, body.row_version), detail=True))


# ================================================================== GRN
def grn_out(db, p: Principal, g: Grn, detail: bool = False) -> dict:
    sup = db.get(Supplier, g.supplier_id)
    po = db.get(PurchaseOrder, g.purchase_order_id)
    names = _names(db, [g.created_by])
    out = {"id": str(g.id), "grn_number": g.grn_number, "grn_date": g.grn_date.isoformat(),
           "supplier": {"id": str(sup.id), "name": sup.supplier_name}, "purchase_order_id": str(po.id),
           "po_number": po.po_number, "warehouse": _wh(db, g.warehouse_id), "project": _project_ref(db, g.project_id),
           "supplier_invoice_no": g.supplier_invoice_no, "value": str(g.value),
           "rejected": any(ln.rejected_qty for ln in g.lines), "received_by": names.get(g.created_by),
           "created_at": g.created_at.isoformat()}
    if not detail:
        return out
    return out | {
        "supplier_invoice_date": g.supplier_invoice_date.isoformat() if g.supplier_invoice_date else None,
        "delivery_challan_no": g.delivery_challan_no, "vehicle_no": g.vehicle_no, "notes": g.notes,
        "lines": [{"id": str(ln.id), "line_no": ln.line_no, "po_line_id": str(ln.po_line_id), "description": ln.description,
                   "unit": ln.unit, "ordered_qty": _q(ln.ordered_qty), "received_qty": _q(ln.received_qty),
                   "accepted_qty": _q(ln.accepted_qty), "rejected_qty": _q(ln.rejected_qty),
                   "rejection_reason": ln.rejection_reason, "batch_no": ln.batch_no,
                   "expiry_date": ln.expiry_date.isoformat() if ln.expiry_date else None, "serial_nos": ln.serial_nos,
                   "unit_cost": str(ln.unit_cost), "value": str(ln.value), "stocked": ln.stocked} for ln in g.lines],
        "can": {"print": p.can("grn.print")},
    }


@router.get("/grns")
def list_grns(db: DbSession, p: Annotated[Principal, require("grn.read")], params: Annotated[ListParams, Depends()],
              purchase_order_id: uuid.UUID | None = None, supplier_id: uuid.UUID | None = None,
              project_id: uuid.UUID | None = None, warehouse_id: uuid.UUID | None = None):
    rows, meta = service.list_grns(db, params, purchase_order_id=purchase_order_id, supplier_id=supplier_id,
                                   project_id=project_id, warehouse_id=warehouse_id)
    return {"data": [grn_out(db, p, g) for g in rows], "meta": meta.model_dump()}


@router.post("/grns", status_code=201)
def create_grn(body: GrnIn, db: DbSession, p: Annotated[Principal, require("grn.create")]):
    return ok(grn_out(db, p, service.create_grn(db, p, body), detail=True))


@router.get("/grns/{gid}")
def get_grn(gid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("grn.read")]):
    return ok(grn_out(db, p, service.get_grn(db, gid), detail=True))


@router.get("/grns/{gid}/pdf")
def grn_pdf(gid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("grn.print")]):
    g = service.get_grn(db, gid)
    audit.record(db, action="print", entity_type="grn", entity_id=g.id, entity_label=g.grn_number)
    return Response(pdf.build_grn(db, g), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{g.grn_number.replace("/", "-")}.pdf"',
                             "Cache-Control": "no-store"})


# ================================================================== project materials
@router.get("/projects/{project_id}/materials")
def project_materials(project_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("project.read")],
                      q: str | None = Query(None)):
    from app.projects import service as projects

    prj = projects.get(db, project_id)
    projects.check(p, prj, "read")
    store = db.scalar(select(Warehouse).where(Warehouse.project_id == prj.id))
    out: dict = {"site_store": wh_ref(store) if store else None,
                 "can_create_store": projects.allowed(p, prj, "update") and store is None
                 and prj.status not in ("completed", "cancelled")}
    if store is not None and p.can("stock.read"):
        rows = db.execute(select(Item, StockBalance.quantity, StockBalance.value)
                          .join(StockBalance, StockBalance.item_id == Item.id)
                          .where(StockBalance.warehouse_id == store.id, StockBalance.quantity != 0)
                          .order_by(Item.item_name)).all()
        out["site_stock"] = [{"item_id": str(i.id), "code": i.item_code, "name": i.item_name, "unit": i.unit.code,
                              "quantity": _q(qv), "value": str(v)} for i, qv, v in rows]
    if p.can("material_request.read"):
        mrs = db.scalars(select(MaterialRequest).where(MaterialRequest.project_id == prj.id)
                         .order_by(MaterialRequest.created_at.desc()).limit(50)).all()
        own = p.scope("material_request.read") == "own"
        out["material_requests"] = [mr_out(db, p, m) for m in mrs if not own or m.created_by == p.id]
    if p.can("purchase_order.read"):
        pos = db.scalars(select(PurchaseOrder).where(PurchaseOrder.project_id == prj.id)
                         .order_by(PurchaseOrder.created_at.desc()).limit(50)).all()
        out["purchase_orders"] = [po_out(db, p, x) for x in pos]
    out["can"] = {"request": p.can("material_request.create") and prj.status not in ("completed", "cancelled")}
    return ok(out)
