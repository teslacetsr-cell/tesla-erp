"""RFQ letters (one per supplier, or all suppliers in one file) and the comparison sheet, on the Tesla letterhead."""
import io
from datetime import datetime
from html import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import landscape
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.platypus import KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from sqlalchemy.orm import Session

from app.platform import pdfkit as K
from app.projects.models import Project
from app.purchase.pdf import _box, _head, _supplier_block
from app.purchase.rfq_models import Rfq, VendorQuotation
from app.suppliers.models import Supplier
from app.users.models import User

GREEN = colors.HexColor("#dcfce7")


def _date(d) -> str:
    return d.strftime("%d %b %Y") if d else "—"


def _qty(v) -> str:
    return f"{v.normalize():f}"


def _company_name(db: Session) -> str:
    c = K.company(db)
    return c.company_name if c else "Tesla Consulting Engineers"


def _letter(db: Session, rfq: Rfq, vq: VendorQuotation, st) -> list:
    sup = db.get(Supplier, vq.supplier_id)
    contact = next((c for c in sup.contacts if getattr(c, "is_primary", False)), sup.contacts[0] if sup.contacts else None)
    prj = db.get(Project, rfq.project_id) if rfq.project_id else None
    number = rfq.rfq_number or "DRAFT"
    story = K.letterhead(db, st)
    story += [_head("REQUEST FOR QUOTATION", f"<b>RFQ No.</b> {escape(number)}<br/><b>Date</b> {_date(rfq.rfq_date)}"
                    + (f"<br/><b>Quote by</b> {_date(rfq.due_date)}" if rfq.due_date else ""), st), Spacer(1, 3 * mm)]
    left = _supplier_block(sup, st)
    if contact is not None:
        left.append(Paragraph(f"Kind attention: {escape(contact.name)}", st["small"]))
    right = [Paragraph("Deliver to", st["label"]), K.p(rfq.delivery_location, st["base"])]
    if rfq.required_by:
        right += [Spacer(1, 1.5 * mm), Paragraph("Required by", st["label"]), Paragraph(_date(rfq.required_by), st["small"])]
    if prj:
        right += [Spacer(1, 1.5 * mm), Paragraph("Project", st["label"]),
                  Paragraph(f"{escape(prj.project_number)} · {escape(prj.name)}", st["small"])]
    if rfq.contact_person:
        right += [Spacer(1, 1.5 * mm), Paragraph("Contact", st["label"]), K.p(rfq.contact_person, st["small"])]
    due = f" by <b>{_date(rfq.due_date)}</b>" if rfq.due_date else ""
    story += [_box(left, right), Spacer(1, 3 * mm),
              Paragraph("Dear Sir / Madam,", st["base"]), Spacer(1, 1.5 * mm),
              Paragraph(f"Please send us your best quotation for the items below{due}, quoting our RFQ number. Fill in the "
                        "rate, discount, GST % and make for each item, and your commercial terms. If you received our "
                        "Excel reply form, filling it in and sending it back helps us process your offer faster.",
                        st["base"]), Spacer(1, 3 * mm)]
    head = ["#", "Description", "Qty", "Unit", "Make / Brand", "Rate (₹)", "Disc %", "GST %", "Amount (₹)"]
    data = [[Paragraph(f"<b>{h}</b>", st["cellr"] if i in (2, 5, 6, 7, 8) else st["cell"]) for i, h in enumerate(head)]]
    for ln in rfq.lines:
        desc = f"<b>{escape(ln.description)}</b>"
        if ln.specification:
            desc += f"<br/><font size=6.8 color='#6b7280'>{escape(ln.specification).replace(chr(10), '<br/>')}</font>"
        if ln.remarks:
            desc += f"<br/><font size=6.8 color='#6b7280'><i>{escape(ln.remarks)}</i></font>"
        data.append([Paragraph(str(ln.line_no), st["cell"]), Paragraph(desc, st["cell"]),
                     Paragraph(_qty(ln.quantity), st["cellr"]), Paragraph(escape(ln.unit), st["cell"]), "", "", "", "", ""])
    t = Table(data, colWidths=[7 * mm, 66 * mm, 14 * mm, 11 * mm, 22 * mm, 18 * mm, 11 * mm, 11 * mm, 22 * mm], repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), K.TINT), ("LINEBELOW", (0, 0), (-1, 0), 0.8, K.RED),
                           ("VALIGN", (0, 0), (-1, -1), "TOP"), ("GRID", (0, 1), (-1, -1), 0.3, K.LINE),
                           ("BOX", (0, 0), (-1, -1), 0.5, K.LINE), ("LEFTPADDING", (0, 0), (-1, -1), 2.5),
                           ("RIGHTPADDING", (0, 0), (-1, -1), 2.5), ("TOPPADDING", (0, 1), (-1, -1), 5),
                           ("BOTTOMPADDING", (0, 1), (-1, -1), 5)]))
    story += [t, Spacer(1, 4 * mm)]
    fill = [("Your quotation no. and date", ""), ("Payment terms", ""), ("Delivery period", ""),
            ("Validity of the offer", ""), ("Freight", "Included / extra ₹"), ("Warranty", ""),
            ("GST", "Extra as shown / included in the rates")]
    ft = Table([[Paragraph(f"<b>{k}</b>", st["cell"]), Paragraph(v, st["small"])] for k, v in fill],
               colWidths=[50 * mm, None])
    ft.setStyle(TableStyle([("LINEBELOW", (1, 0), (1, -1), 0.4, K.MUTED), ("TOPPADDING", (0, 0), (-1, -1), 5),
                            ("VALIGN", (0, 0), (-1, -1), "BOTTOM")]))
    story += [KeepTogether([Paragraph("Your commercial terms", st["h"]), ft])]
    if rfq.terms:
        story += [Paragraph("Our terms", st["h"]), K.p(rfq.terms, st["base"])]
    if rfq.notes:
        story += [Paragraph("Notes", st["h"]), K.p(rfq.notes, st["base"])]
    u = db.get(User, rfq.created_by) if rfq.created_by else None
    story.append(KeepTogether([Spacer(1, 6 * mm), Paragraph(f"For <b>{escape(_company_name(db))}</b>", st["base"]),
                               Spacer(1, 12 * mm), Paragraph(escape(u.full_name) if u else "", st["base"]),
                               Paragraph("Purchase department", st["small"])]))
    return story


def build_rfq(db: Session, rfq: Rfq, quotations: list[VendorQuotation]) -> bytes:
    K.fonts()
    st = K.styles()
    number = rfq.rfq_number or "DRAFT"
    story: list = []
    for n, vq in enumerate(quotations):
        if n:
            story.append(PageBreak())
        story += _letter(db, rfq, vq, st)
    buf = io.BytesIO()
    mark = "CANCELLED" if rfq.status == "cancelled" else ("DRAFT" if rfq.rfq_number is None else None)
    SimpleDocTemplate(buf, pagesize=K.PAGE, leftMargin=K.MARGIN, rightMargin=K.MARGIN, topMargin=10 * mm,
                      bottomMargin=14 * mm, title=f"Request for quotation {number}", author=_company_name(db)).build(
        story, canvasmaker=K.numbered_canvas(f"RFQ {number}", mark))
    return buf.getvalue()


# ------------------------------------------------------------------ comparison (A4 landscape)
PAGE = landscape(K.PAGE)


def _landscape_canvas(footer_left: str):
    generated = datetime.now(K.IST).strftime("%d %b %Y, %I:%M %p IST")

    class LandscapeCanvas(rl_canvas.Canvas):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._pages = []

        def showPage(self):  # noqa: N802 - ReportLab API
            self._pages.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            total = len(self._pages)
            for state in self._pages:
                self.__dict__.update(state)
                self.saveState()
                self.setFont("DejaVu", 6.8)
                self.setFillColor(K.MUTED)
                self.drawString(K.MARGIN, 7 * mm, f"{footer_left} · generated {generated}")
                self.drawRightString(PAGE[0] - K.MARGIN, 7 * mm, f"Page {self._pageNumber} of {total}")
                self.restoreState()
                super().showPage()
            super().save()

    return LandscapeCanvas


def build_comparison(db: Session, rfq: Rfq, cmp: dict) -> bytes:
    K.fonts()
    st = K.styles()
    number = rfq.rfq_number or "Draft RFQ"
    totals = cmp["totals"]
    net = cmp["net"]
    story = K.letterhead(db, st)
    prj = db.get(Project, rfq.project_id) if rfq.project_id else None
    sub = (f"<b>RFQ</b> {escape(number)} · {_date(rfq.rfq_date)}"
           + (f"<br/><b>Project</b> {escape(prj.project_number)} · {escape(prj.name)}" if prj else "")
           + f"<br/>L1 on value {'before' if net else 'including'} GST · L1 shaded green")
    story += [_head("COMPARISON OF QUOTATIONS", sub, st), Spacer(1, 3 * mm)]
    width = PAGE[0] - 2 * K.MARGIN
    fixed = [7 * mm, 62 * mm, 16 * mm, 18 * mm]
    sel_w = 30 * mm
    each = max(24 * mm, (width - sum(fixed) - sel_w) / max(1, len(totals)))
    small = st["cell"].clone("tiny", fontSize=6.8, leading=8.6)
    smallr = st["cellr"].clone("tinyr", fontSize=6.8, leading=8.6)
    head = [Paragraph("<b>#</b>", small), Paragraph("<b>Description</b>", small), Paragraph("<b>Qty</b>", smallr),
            Paragraph("<b>Last price</b>", smallr)]
    for t in totals:
        head.append(Paragraph(f"<b>{escape(t['supplier'].supplier_name)}</b>"
                              + (f"<br/><font color='#6b7280'>L{t['rank']}</font>" if t["rank"] else ""), smallr))
    head.append(Paragraph("<b>Selected</b>", small))
    data = [head]
    style = [("BACKGROUND", (0, 0), (-1, 0), K.TINT), ("LINEBELOW", (0, 0), (-1, 0), 0.8, K.RED),
             ("VALIGN", (0, 0), (-1, -1), "TOP"), ("GRID", (0, 0), (-1, -1), 0.3, K.LINE),
             ("LEFTPADDING", (0, 0), (-1, -1), 2), ("RIGHTPADDING", (0, 0), (-1, -1), 2)]
    names = {t["q"].id: t["supplier"].supplier_name for t in totals}
    for row in cmp["lines"]:
        ln = row["line"]
        desc = f"<b>{escape(ln.description)}</b>" + (f"<br/><font color='#6b7280'>{escape(ln.specification[:200])}</font>"
                                                    if ln.specification else "")
        lp = row["last"]
        r = [Paragraph(str(ln.line_no), small), Paragraph(desc, small),
             Paragraph(f"{_qty(ln.quantity)} {escape(ln.unit)}", smallr),
             Paragraph(f"{K.money(lp['rate'])}<br/><font color='#6b7280'>{escape(lp['po_number'] or '')}</font>" if lp else "—",
                       smallr)]
        for j, t in enumerate(totals):
            x = row["cells"].get(t["q"].id)
            if x is None:
                r.append(Paragraph("<font color='#9ca3af'>not quoted</font>", smallr))
                continue
            disc = f" −{x.discount_pct.normalize():f}%" if x.discount_pct else ""
            amount = x.taxable if net else x.total
            mark = " ✔" if row["selected"] == t["q"].id else ""
            r.append(Paragraph(f"{K.money(x.unit_rate)}{disc}<br/>net {K.money(x.net_rate)} · GST {x.gst_pct.normalize():f}%"
                               f"<br/><b>{K.money(amount)}{mark}</b>"
                               + (f"<br/><font color='#6b7280'>{escape(x.make)}</font>" if x.make else ""), smallr))
            if t["q"].id in row["l1"]:
                style.append(("BACKGROUND", (4 + j, len(data)), (4 + j, len(data)), GREEN))
        sel = names.get(row["selected"]) or ("not ordered" if row["saved"] else "—")
        r.append(Paragraph(escape(sel) + (f"<br/><font color='#b45309'>{escape(ln.selection_remark)}</font>"
                                          if ln.selection_remark else ""), small))
        data.append(r)
    low = min((t["basis"] for t in totals if t["rank"] == 1), default=None)
    rows = [("Value before GST", lambda t: K.money(t["q"].taxable)), ("GST", lambda t: K.money(t["q"].gst)),
            ("Freight", lambda t: "included" if t["q"].freight_included else K.money(t["q"].freight_amount)),
            ("Total incl. GST + freight", lambda t: K.money(t["q"].grand_total)),
            ("Compared total", lambda t: f"<b>{K.money(t['basis'])}</b>"),
            ("Lines quoted", lambda t: f"{t['quoted']} of {len(cmp['lines'])}"),
            ("Quotation ref", lambda t: escape(" · ".join(
                x for x in (t["q"].quote_ref, _date(t["q"].quote_date) if t["q"].quote_date else None) if x) or "—")),
            ("Payment terms", lambda t: escape(t["q"].payment_terms or "—")),
            ("Delivery", lambda t: escape(t["q"].delivery_period or "—")),
            ("Valid until", lambda t: _date(t["q"].valid_until)), ("Warranty", lambda t: escape(t["q"].warranty or "—"))]
    for lbl, fn in rows:
        r = ["", Paragraph(f"<b>{lbl}</b>", small), "", ""]
        for j, t in enumerate(totals):
            r.append(Paragraph(fn(t), smallr))
            if lbl == "Compared total" and t["rank"] == 1 and t["basis"] == low:
                style.append(("BACKGROUND", (4 + j, len(data)), (4 + j, len(data)), GREEN))
        r.append("")
        style += [("SPAN", (1, len(data)), (3, len(data))), ("BACKGROUND", (0, len(data)), (3, len(data)), colors.HexColor("#f9fafb"))]
        data.append(r)
    t = Table(data, colWidths=fixed + [each] * len(totals) + [sel_w], repeatRows=1)
    t.setStyle(TableStyle(style))
    story += [t, Spacer(1, 3 * mm),
              Paragraph(f"<b>Value of the selection:</b> ₹{K.money(cmp['selected_value'])} · <b>sum of L1 per line:</b> "
                        f"₹{K.money(cmp['l1_value'])} · <b>saving vs last purchase prices:</b> ₹{K.money(cmp['savings'])}",
                        st["base"])]
    if cmp["awaited"]:
        story.append(Paragraph("No quotation from: " + escape(", ".join(cmp["suppliers"][q.supplier_id].supplier_name
                                                                        for q in cmp["awaited"])), st["small"]))
    sig = Table([[Paragraph("Prepared by", st["label"]), Paragraph("Checked by", st["label"]),
                  Paragraph("Approved by", st["label"])]], colWidths=[80 * mm] * 3)
    sig.setStyle(TableStyle([("TOPPADDING", (0, 0), (-1, -1), 16 * mm), ("LINEABOVE", (0, 0), (0, 0), 0.4, K.INK),
                             ("LINEABOVE", (1, 0), (1, 0), 0.4, K.INK), ("LINEABOVE", (2, 0), (2, 0), 0.4, K.INK),
                             ("RIGHTPADDING", (0, 0), (-1, -1), 12 * mm)]))
    story += [Spacer(1, 6 * mm), KeepTogether([sig])]
    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=PAGE, leftMargin=K.MARGIN, rightMargin=K.MARGIN, topMargin=9 * mm,
                      bottomMargin=13 * mm, title=f"Comparison {number}", author=_company_name(db)).build(
        story, canvasmaker=_landscape_canvas(f"Comparison of quotations {number}"))
    return buf.getvalue()

