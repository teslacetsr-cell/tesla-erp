"""Vendor quotations API: /rfqs (request for quotation, supplier quotations, comparison, purchase orders)."""
import uuid
from decimal import Decimal
from typing import Annotated

from fastapi import APIRouter, Depends, File, Form, Query, UploadFile
from fastapi.responses import Response
from pydantic import ValidationError
from sqlalchemy import select

from app.auth.deps import Principal, require
from app.boq import lines as L
from app.core.api import ListParams, ok
from app.core.db import DbSession
from app.core.errors import AppError
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.platform.documents.storage import get_storage
from app.products.models import Item
from app.purchase import rfq_ai, rfq_excel, rfq_pdf
from app.purchase import rfq_service as service
from app.purchase.models import MaterialRequest, PurchaseOrder, PurchaseRequest
from app.purchase.rfq_models import Rfq, VendorQuotation
from app.purchase.rfq_schemas import AddSupplierIn, CreateOrdersIn, QuotationIn, ReasonIn, RfqIn, RfqUpdate, SelectionIn
from app.purchase.router import _names, _project_ref, _wh
from app.suppliers.models import Supplier

router = APIRouter(prefix="/rfqs", tags=["vendor quotations"])
Z = Decimal("0")

documents.register_entity("rfq", "rfq", Rfq)
documents.register_entity("vendor_quotation", "rfq", VendorQuotation)


def _q(v) -> str:
    return f"{Decimal(v).normalize():f}"


def _s(v) -> str | None:
    return None if v is None else str(v)


def _d(v) -> str | None:
    return v.isoformat() if v else None


def _fname(rfq: Rfq, suffix: str) -> str:
    return f"{(rfq.rfq_number or 'DRAFT-RFQ').replace('/', '-')}{suffix}"


def _sup_ref(s: Supplier | None) -> dict | None:
    if s is None:
        return None
    return {"id": str(s.id), "name": s.supplier_name, "code": s.supplier_code, "city": s.city, "phone": s.phone,
            "email": s.email, "status": s.status}


def _quote_out(db, vq: VendorQuotation, sup: Supplier | None) -> dict:
    po = db.get(PurchaseOrder, vq.purchase_order_id) if vq.purchase_order_id else None
    return {
        "id": str(vq.id), "supplier": _sup_ref(sup), "invited": vq.invited, "status": vq.status, "source": vq.source,
        "quote_ref": vq.quote_ref, "quote_date": _d(vq.quote_date), "valid_until": _d(vq.valid_until),
        "payment_terms": vq.payment_terms, "delivery_period": vq.delivery_period,
        "freight_included": vq.freight_included, "freight_amount": str(vq.freight_amount), "warranty": vq.warranty,
        "gst_inclusive": vq.gst_inclusive, "notes": vq.notes, "taxable": str(vq.taxable), "gst": str(vq.gst),
        "grand_total": str(vq.grand_total), "received_at": _d(vq.received_at), "row_version": vq.row_version,
        "purchase_order": {"id": str(po.id), "po_number": po.po_number, "status": po.status} if po else None,
        "lines": [{"rfq_line_id": str(x.rfq_line_id), "not_quoted": x.not_quoted, "unit_rate": _s(x.unit_rate),
                   "discount_pct": _q(x.discount_pct), "gst_pct": _q(x.gst_pct), "make": x.make,
                   "delivery_days": x.delivery_days, "remarks": x.remarks, "net_rate": str(x.net_rate),
                   "taxable": str(x.taxable), "gst_amount": str(x.gst_amount), "total": str(x.total)} for x in vq.lines],
    }


def rfq_out(db, p: Principal, rfq: Rfq, detail: bool = False) -> dict:
    names = _names(db, [rfq.created_by])
    pr = db.get(PurchaseRequest, rfq.purchase_request_id) if rfq.purchase_request_id else None
    mr = db.get(MaterialRequest, rfq.material_request_id) if rfq.material_request_id else None
    sups = {s.id: s for s in db.scalars(select(Supplier).where(Supplier.id.in_({q.supplier_id for q in rfq.quotations})))} \
        if rfq.quotations else {}
    out = {
        "id": str(rfq.id), "rfq_number": rfq.rfq_number, "display_number": rfq.rfq_number or "Draft RFQ",
        "rfq_date": rfq.rfq_date.isoformat(), "status": rfq.status, "due_date": _d(rfq.due_date),
        "required_by": _d(rfq.required_by), "project": _project_ref(db, rfq.project_id), "warehouse": _wh(db, rfq.warehouse_id),
        "purchase_request": {"id": str(pr.id), "number": pr.pr_number} if pr else None,
        "material_request": {"id": str(mr.id), "number": mr.mr_number} if mr else None,
        "lines_count": len(rfq.lines), "suppliers": [sups[q.supplier_id].supplier_name for q in rfq.quotations if q.supplier_id in sups],
        "received_count": sum(1 for q in rfq.quotations if q.status == "received"),
        "created_by": names.get(rfq.created_by), "created_at": rfq.created_at.isoformat(), "row_version": rfq.row_version,
    }
    if not detail:
        return out
    codes = dict(db.execute(select(Item.id, Item.item_code).where(
        Item.id.in_({ln.item_id for ln in rfq.lines} - {None}))).all()) if rfq.lines else {}
    upd = p.can("rfq.update")
    s = rfq.status
    pos = [q.purchase_order_id for q in rfq.quotations if q.purchase_order_id]
    return out | {
        "delivery_location": rfq.delivery_location, "contact_person": rfq.contact_person, "terms": rfq.terms,
        "notes": rfq.notes, "compare_on": rfq.compare_on, "status_reason": rfq.status_reason,
        "sent_at": _d(rfq.sent_at), "compared_at": _d(rfq.compared_at), "closed_at": _d(rfq.closed_at),
        "lines": [{"id": str(ln.id), "line_no": ln.line_no, "item_id": _s(ln.item_id), "item_code": codes.get(ln.item_id),
                   "description": ln.description, "specification": ln.specification, "unit": ln.unit,
                   "quantity": _q(ln.quantity), "required_by": _d(ln.required_by), "pr_line_id": _s(ln.pr_line_id),
                   "mr_line_id": _s(ln.mr_line_id), "remarks": ln.remarks,
                   "selected_quotation_id": _s(ln.selected_quotation_id), "selection_remark": ln.selection_remark}
                  for ln in rfq.lines],
        "quotations": [_quote_out(db, q, sups.get(q.supplier_id)) for q in rfq.quotations],
        "purchase_orders": [{"id": str(po.id), "po_number": po.po_number, "status": po.status,
                             "supplier": sups[po.supplier_id].supplier_name if po.supplier_id in sups else None,
                             "taxable": str(po.taxable), "grand_total": str(po.grand_total)}
                            for po in (db.get(PurchaseOrder, i) for i in pos) if po],
        "ai_enabled": rfq_ai.enabled(),
        "gst_rates": [f"{r:f}" for r in sorted(L.gst_rates(db))],
        "can": {"edit": upd and s in service.EDITABLE, "send": upd and s == "draft",
                "cancel": upd and s not in ("closed", "cancelled"), "delete": p.can("rfq.delete") and rfq.rfq_number is None,
                "quote": upd and s in service.QUOTABLE, "add_supplier": upd and s in service.QUOTABLE,
                "compare": upd and s in ("quotes_received", "compared"),
                "create_po": upd and p.can("purchase_order.create") and s == "compared",
                "export": p.can("rfq.export"), "ai": upd and rfq_ai.enabled()},
    }


def _cmp_out(db, rfq: Rfq, cmp: dict) -> dict:
    def cell(x):
        if x is None:
            return None
        return {"unit_rate": _s(x.unit_rate), "discount_pct": _q(x.discount_pct), "net_rate": str(x.net_rate),
                "gst_pct": _q(x.gst_pct), "taxable": str(x.taxable), "gst_amount": str(x.gst_amount),
                "total": str(x.total), "make": x.make, "delivery_days": x.delivery_days, "remarks": x.remarks}

    return {
        "rfq": {"id": str(rfq.id), "display_number": rfq.rfq_number or "Draft RFQ", "status": rfq.status,
                "compare_on": rfq.compare_on, "row_version": rfq.row_version},
        "suppliers": [{
            "quotation_id": str(t["q"].id), "supplier": _sup_ref(t["supplier"]), "rank": t["rank"],
            "complete": t["complete"], "quoted_lines": t["quoted"], "basis_total": str(t["basis"]),
            "taxable": str(t["q"].taxable), "gst": str(t["q"].gst), "freight_included": t["q"].freight_included,
            "freight_amount": str(t["q"].freight_amount), "grand_total": str(t["q"].grand_total),
            "quote_ref": t["q"].quote_ref, "quote_date": _d(t["q"].quote_date), "valid_until": _d(t["q"].valid_until),
            "payment_terms": t["q"].payment_terms, "delivery_period": t["q"].delivery_period,
            "warranty": t["q"].warranty, "gst_inclusive": t["q"].gst_inclusive,
            "selected_lines": t["selected_lines"], "selected_taxable": str(t["selected_taxable"]),
            "selected_gst": str(t["selected_gst"]), "selected_freight": str(t["selected_freight"])} for t in cmp["totals"]],
        "awaited": [{"quotation_id": str(q.id), "supplier": _sup_ref(cmp["suppliers"].get(q.supplier_id)), "status": q.status}
                    for q in cmp["awaited"]],
        "lines": [{
            "id": str(row["line"].id), "line_no": row["line"].line_no, "item_code": row["item_code"],
            "description": row["line"].description, "specification": row["line"].specification,
            "unit": row["line"].unit, "quantity": _q(row["line"].quantity),
            "last_price": {"rate": str(row["last"]["rate"]), "po_number": row["last"]["po_number"],
                           "po_date": _d(row["last"]["po_date"]), "supplier": row["last"]["supplier"]} if row["last"] else None,
            "cells": {str(k): cell(v) for k, v in row["cells"].items()},
            "l1": [str(x) for x in row["l1"]], "l1_value": _s(row["l1_value"]),
            "selected_quotation_id": _s(row["selected"]), "selection_saved": row["saved"],
            "selection_remark": row["line"].selection_remark, "chosen_value": _s(row["chosen_value"]),
            "savings_vs_last": _s(row["savings"])} for row in cmp["lines"]],
        "selected_value": str(cmp["selected_value"]), "l1_value": str(cmp["l1_value"]), "savings_vs_last": str(cmp["savings"]),
    }


# ------------------------------------------------------------------ RFQ
@router.get("")
def list_rfqs(db: DbSession, p: Annotated[Principal, require("rfq.read")], params: Annotated[ListParams, Depends()],
              status: str | None = None, purchase_request_id: uuid.UUID | None = None,
              material_request_id: uuid.UUID | None = None, project_id: uuid.UUID | None = None, open_only: bool = False):
    rows, meta = service.list_rfqs(db, params, status=status, purchase_request_id=purchase_request_id,
                                   material_request_id=material_request_id, project_id=project_id, open_only=open_only)
    return {"data": [rfq_out(db, p, r) for r in rows], "meta": meta.model_dump()}


@router.post("", status_code=201)
def create_rfq(body: RfqIn, db: DbSession, p: Annotated[Principal, require("rfq.create")]):
    return ok(rfq_out(db, p, service.create(db, p, body), detail=True))


@router.get("/{rid}")
def get_rfq(rid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("rfq.read")]):
    return ok(rfq_out(db, p, service.get(db, rid), detail=True))


@router.put("/{rid}")
def update_rfq(rid: uuid.UUID, body: RfqUpdate, db: DbSession, p: Annotated[Principal, require("rfq.update")]):
    return ok(rfq_out(db, p, service.update(db, p, rid, body), detail=True))


@router.delete("/{rid}")
def delete_rfq(rid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("rfq.delete")]):
    service.delete(db, p, rid)
    return ok({"ok": True})


@router.post("/{rid}/send")
def send_rfq(rid: uuid.UUID, body: ReasonIn, db: DbSession, p: Annotated[Principal, require("rfq.update")]):
    return ok(rfq_out(db, p, service.send(db, p, rid, body.row_version), detail=True))


@router.post("/{rid}/cancel")
def cancel_rfq(rid: uuid.UUID, body: ReasonIn, db: DbSession, p: Annotated[Principal, require("rfq.update")]):
    return ok(rfq_out(db, p, service.cancel(db, p, rid, body.reason, body.row_version), detail=True))


@router.post("/{rid}/suppliers", status_code=201)
def add_supplier(rid: uuid.UUID, body: AddSupplierIn, db: DbSession, p: Annotated[Principal, require("rfq.update")]):
    service.add_supplier(db, p, rid, body)
    return ok(rfq_out(db, p, service.get(db, rid), detail=True))


# ------------------------------------------------------------------ outputs
@router.get("/{rid}/pdf")
def rfq_pdf_download(rid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("rfq.export")],
                     quotation_id: uuid.UUID | None = None):
    rfq = service.get(db, rid, lock=True)
    quotes = [service.get_quotation(db, rfq, quotation_id)] if quotation_id else list(rfq.quotations)
    if not quotes:
        raise AppError("NO_SUPPLIERS", "Add at least one supplier first.")
    if rfq.status != "cancelled":
        service.ensure_number(db, p, rfq)
    sup = db.get(Supplier, quotes[0].supplier_id) if quotation_id else None
    audit.record(db, action="print", entity_type="rfq", entity_id=rfq.id, entity_label=service.label(rfq),
                 summary=f"RFQ PDF for {sup.supplier_name if sup else 'all suppliers'}")
    suffix = f"-{sup.supplier_code}.pdf" if sup else "-all-suppliers.pdf"
    return Response(rfq_pdf.build_rfq(db, rfq, quotes), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{_fname(rfq, suffix)}"', "Cache-Control": "no-store"})


@router.get("/{rid}/quotations/{qid}/template")
def rfq_template(rid: uuid.UUID, qid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("rfq.export")]):
    rfq = service.get(db, rid, lock=True)
    vq = service.get_quotation(db, rfq, qid)
    if rfq.status != "cancelled":
        service.ensure_number(db, p, rfq)
    sup = db.get(Supplier, vq.supplier_id)
    audit.record(db, action="export", entity_type="rfq", entity_id=rfq.id, entity_label=service.label(rfq),
                 summary=f"Excel reply form for {sup.supplier_name}")
    return Response(rfq_excel.template(db, rfq, vq), media_type=rfq_excel.XLSX,
                    headers={"Content-Disposition": f'attachment; filename="{_fname(rfq, "-" + sup.supplier_code + ".xlsx")}"',
                             "Cache-Control": "no-store"})


# ------------------------------------------------------------------ quotations
@router.put("/{rid}/quotations/{qid}")
def save_quotation(rid: uuid.UUID, qid: uuid.UUID, body: QuotationIn, db: DbSession,
                   p: Annotated[Principal, require("rfq.update")]):
    service.save_quotation(db, p, rid, qid, body)
    return ok(rfq_out(db, p, service.get(db, rid), detail=True))


@router.delete("/{rid}/quotations/{qid}")
def remove_quotation(rid: uuid.UUID, qid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("rfq.update")]):
    service.remove_quotation(db, p, rid, qid)
    return ok(rfq_out(db, p, service.get(db, rid), detail=True))


@router.post("/{rid}/quotations/{qid}/decline")
def decline_quotation(rid: uuid.UUID, qid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("rfq.update")]):
    service.decline(db, p, rid, qid)
    return ok(rfq_out(db, p, service.get(db, rid), detail=True))


def _quote_body(vq: VendorQuotation, parsed: dict, source: str) -> QuotationIn:
    h = parsed["header"]
    keep = {k: getattr(vq, k) for k in ("quote_ref", "quote_date", "valid_until", "payment_terms", "delivery_period",
                                         "warranty", "notes")}
    data = {k: (h.get(k) if h.get(k) not in (None, "") else v) for k, v in keep.items()}
    data |= {"freight_included": h.get("freight_included", vq.freight_included),
             "freight_amount": h.get("freight_amount", vq.freight_amount),
             "gst_inclusive": h.get("gst_inclusive", vq.gst_inclusive), "source": source,
             "lines": [{k: x[k] for k in ("rfq_line_id", "not_quoted", "unit_rate", "discount_pct", "gst_pct", "make",
                                          "delivery_days", "remarks")} for x in parsed["lines"]]}
    return QuotationIn.model_validate(data)


@router.post("/{rid}/quotations/{qid}/import")
async def import_quotation(rid: uuid.UUID, qid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("rfq.update")],
                           file: UploadFile = File(...), save: bool = Query(True)):
    """Read the supplier's filled Excel reply form. With no problems (and save=true) the quotation is saved and the
    file kept as an attachment; otherwise the problems are listed per row and nothing is saved."""
    rfq = service.get(db, rid)
    if rfq.status not in service.QUOTABLE:
        raise AppError("RFQ_CLOSED", f"This RFQ is {rfq.status}; quotations can no longer be changed.")
    vq = service.get_quotation(db, rfq, qid)
    data = await file.read()
    parsed = rfq_excel.parse(db, rfq, data)
    saved = False
    if save and not parsed["errors"]:
        try:
            body = _quote_body(vq, parsed, "excel")
        except ValidationError as exc:
            parsed["errors"] = [{"message": e["msg"].replace("Value error, ", "")} for e in exc.errors()]
        else:
            service.save_quotation(db, p, rid, qid, body)
            documents.upload(db, entity_type="vendor_quotation", entity_id=vq.id, category="quotation",
                             file_name=file.filename or "quotation.xlsx", data=data, user_id=p.id,
                             title="Excel reply form")
            saved = True
    return ok({"saved": saved, **parsed, "rfq": rfq_out(db, p, service.get(db, rid), detail=True) if saved else None})


@router.post("/{rid}/quotations/{qid}/ai-read")
async def ai_read(rid: uuid.UUID, qid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("rfq.update")],
                  file: UploadFile | None = File(None), document_id: Annotated[uuid.UUID | None, Form()] = None):
    """Read a supplier's quotation file (PDF, photo or Excel) with AI and return a pre-fill for review. Nothing is saved
    except the uploaded file, kept as an attachment of the supplier's quotation."""
    if not rfq_ai.enabled():
        raise AppError("AI_NOT_CONFIGURED", rfq_ai.NOT_SET_UP)
    rfq = service.get(db, rid)
    vq = service.get_quotation(db, rfq, qid)
    if document_id:
        doc = documents.get(db, document_id)
        if doc.entity_type != "vendor_quotation" or doc.entity_id != vq.id:
            raise AppError("INVALID_DOCUMENT", "That file is not attached to this supplier's quotation.")
        data = get_storage().get(doc.storage_key)
    elif file is not None:
        data = await file.read()
        doc = documents.upload(db, entity_type="vendor_quotation", entity_id=vq.id, category="quotation",
                               file_name=file.filename or "quotation", data=data, user_id=p.id, title="Supplier quotation")
    else:
        raise AppError("FILE_REQUIRED", "Choose the supplier's quotation file.")
    sup = db.get(Supplier, vq.supplier_id)
    defaults = {i: g for i, (_, g) in rfq_excel._item_gst(db, rfq).items()}
    result = rfq_ai.read_quotation(rfq, sup.supplier_name, data, doc.content_type, L.gst_rates(db), defaults)
    audit.record(db, action="ai_read", entity_type="rfq", entity_id=rfq.id, entity_label=service.label(rfq),
                 summary=f"AI read the quotation file '{doc.file_name}' of {sup.supplier_name} (not saved until reviewed)")
    return ok(result | {"document": {"id": str(doc.id), "file_name": doc.file_name}})


# ------------------------------------------------------------------ comparison
@router.get("/{rid}/comparison")
def get_comparison(rid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("rfq.read")]):
    rfq = service.get(db, rid)
    return ok(_cmp_out(db, rfq, service.comparison(db, rfq)))


@router.get("/{rid}/comparison/xlsx")
def comparison_xlsx(rid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("rfq.export")]):
    rfq = service.get(db, rid)
    cmp = service.comparison(db, rfq)
    if not cmp["totals"]:
        raise AppError("NO_QUOTES", "No quotation is recorded yet.")
    audit.record(db, action="export", entity_type="rfq", entity_id=rfq.id, entity_label=service.label(rfq),
                 summary="Comparison sheet (Excel)")
    return Response(rfq_excel.comparison(db, rfq, cmp), media_type=rfq_excel.XLSX,
                    headers={"Content-Disposition": f'attachment; filename="{_fname(rfq, "-comparison.xlsx")}"',
                             "Cache-Control": "no-store"})


@router.get("/{rid}/comparison/pdf")
def comparison_pdf(rid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("rfq.export")]):
    rfq = service.get(db, rid)
    cmp = service.comparison(db, rfq)
    if not cmp["totals"]:
        raise AppError("NO_QUOTES", "No quotation is recorded yet.")
    audit.record(db, action="print", entity_type="rfq", entity_id=rfq.id, entity_label=service.label(rfq),
                 summary="Comparison sheet (PDF)")
    return Response(rfq_pdf.build_comparison(db, rfq, cmp), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{_fname(rfq, "-comparison.pdf")}"',
                             "Cache-Control": "no-store"})


@router.put("/{rid}/selection")
def save_selection(rid: uuid.UUID, body: SelectionIn, db: DbSession, p: Annotated[Principal, require("rfq.update")]):
    rfq = service.save_selection(db, p, rid, body)
    return ok(_cmp_out(db, rfq, service.comparison(db, rfq)))


@router.post("/{rid}/ai-summary")
def ai_summary(rid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("rfq.update")]):
    if not rfq_ai.enabled():
        raise AppError("AI_NOT_CONFIGURED", rfq_ai.NOT_SET_UP)
    rfq = service.get(db, rid)
    cmp = service.comparison(db, rfq)
    if not cmp["totals"]:
        raise AppError("NO_QUOTES", "No quotation is recorded yet.")
    text = rfq_ai.summarise(rfq, cmp)
    audit.record(db, action="ai_summary", entity_type="rfq", entity_id=rfq.id, entity_label=service.label(rfq),
                 summary="AI recommendation generated")
    return ok({"text": text})


@router.post("/{rid}/create-orders")
def create_orders(rid: uuid.UUID, body: CreateOrdersIn, db: DbSession, p: Annotated[Principal, require("rfq.update")]):
    pos = service.create_orders(db, p, rid, body)
    from app.purchase.router import po_out

    return ok({"purchase_orders": [po_out(db, p, po) for po in pos],
               "rfq": rfq_out(db, p, service.get(db, rid), detail=True)})

