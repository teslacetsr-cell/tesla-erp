from app.core.permissions import register

# 'own' scope: a site engineer sees and edits the material requests they raised.
register("material_request", "Material requests (approve = process: reject or close)",
         ("create", "read", "update", "delete", "approve"), scoped=("read", "update", "delete"))
register("purchase_request", "Purchase requests", ("create", "read", "update", "delete", "approve"))
register("purchase_order", "Purchase orders", ("create", "read", "update", "delete", "approve", "export", "print"))
register("grn", "Goods received notes (GRN)", ("create", "read", "export", "print"))
