"""AI help for vendor quotations (Anthropic Messages API): read a supplier's PDF / photo / Excel into rates for the
RFQ lines, and write a short recommendation from a comparison. The result is only ever a pre-fill or a suggestion:
a person reviews and saves it. The API key comes from the ANTHROPIC_API_KEY environment variable only and is never
stored, logged or returned."""
import base64
import difflib
import json
import logging
import re
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation

import httpx

from app.core.config import get_settings
from app.core.errors import AppError
from app.crm.service import today
from app.purchase.rfq_models import Rfq

log = logging.getLogger(__name__)
API_URL = "https://api.anthropic.com/v1/messages"
MAX_AI_BYTES = 15 * 1024 * 1024
IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp", "image/gif"}
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
NOT_SET_UP = "AI reading is not set up (ask the administrator to add ANTHROPIC_API_KEY)."


def enabled() -> bool:
    return bool(get_settings().anthropic_api_key)


def _call(content: list[dict], max_tokens: int = 4096) -> str:
    s = get_settings()
    if not s.anthropic_api_key:
        raise AppError("AI_NOT_CONFIGURED", NOT_SET_UP)
    try:
        r = httpx.post(API_URL, headers={"x-api-key": s.anthropic_api_key, "anthropic-version": "2023-06-01",
                                         "content-type": "application/json"},
                       json={"model": s.ai_model, "max_tokens": max_tokens,
                             "messages": [{"role": "user", "content": content}]}, timeout=120)
    except httpx.HTTPError as exc:
        log.warning("AI request failed: %s", type(exc).__name__)
        raise AppError("AI_UNAVAILABLE", "The AI service could not be reached. Try again, or enter the rates by hand.",
                       status_code=502) from None
    if r.status_code != 200:
        try:
            msg = (r.json().get("error") or {}).get("message") or ""
        except ValueError:
            msg = ""
        log.warning("AI request returned HTTP %s", r.status_code)
        raise AppError("AI_FAILED", f"The AI service returned an error (HTTP {r.status_code}). {msg[:200]}".strip(),
                       status_code=502)
    try:
        body = r.json()
        return "".join(b.get("text", "") for b in body.get("content", []) if b.get("type") == "text")
    except (ValueError, AttributeError):
        raise AppError("AI_BAD_REPLY", "The AI service sent a reply that could not be read.", status_code=502) from None


def parse_json(text: str) -> dict:
    """The JSON object in a model reply, tolerating code fences or a sentence around it."""
    t = text.strip()
    fence = re.search(r"```(?:json)?\s*(.*?)```", t, re.S)
    if fence:
        t = fence.group(1).strip()
    start, end = t.find("{"), t.rfind("}")
    if start < 0 or end <= start:
        raise AppError("AI_BAD_REPLY", "The AI could not read a quotation in this file. Enter the rates by hand.",
                       status_code=422)
    try:
        out = json.loads(t[start:end + 1])
    except json.JSONDecodeError:
        try:  # trailing commas are the usual slip
            out = json.loads(re.sub(r",\s*([}\]])", r"\1", t[start:end + 1]))
        except json.JSONDecodeError:
            raise AppError("AI_BAD_REPLY", "The AI reply was not valid data. Try again, or enter the rates by hand.",
                           status_code=422) from None
    if not isinstance(out, dict):
        raise AppError("AI_BAD_REPLY", "The AI reply was not valid data.", status_code=422)
    return out


SCHEMA = """{
  "supplier_quote_no": string or null,
  "quote_date": "YYYY-MM-DD" or null,
  "valid_until": "YYYY-MM-DD" or null,
  "validity_days": integer or null,
  "payment_terms": string or null,
  "delivery": string or null,
  "freight": {"included": true/false/null, "amount": number or null},
  "warranty": string or null,
  "rates_include_gst": true/false/null,
  "lines": [
    {"rfq_line_no": integer or null, "description": string, "unit_rate": number or null, "discount_pct": number or null,
     "gst_pct": number or null, "make": string or null, "delivery_days": integer or null, "remarks": string or null}
  ]
}"""


def _prompt(rfq: Rfq, supplier_name: str) -> str:
    items = "\n".join(f"{ln.line_no}. {ln.description}" + (f" [{ln.specification[:150]}]" if ln.specification else "")
                      + f" — qty {ln.quantity.normalize():f} {ln.unit}" for ln in rfq.lines)
    return (
        f"The attached file is a supplier's quotation from {supplier_name}, in reply to our request for quotation "
        f"{rfq.rfq_number or ''} (an electrical / lightning-protection contractor in Kerala, India; amounts in Indian rupees).\n\n"
        f"Our RFQ lines:\n{items}\n\n"
        "Extract the supplier's offer and return ONLY one JSON object, no other text, exactly in this shape:\n"
        f"{SCHEMA}\n\n"
        "Rules:\n"
        "- One entry in \"lines\" per RFQ line the supplier quoted, with rfq_line_no set to OUR line number above that "
        "it answers (match by description, size and quantity; the supplier's own serial numbers may differ). If you "
        "cannot tell which RFQ line an item answers, set rfq_line_no to null and give the supplier's description.\n"
        "- unit_rate = the price for ONE unit of our unit of measure, before discount, as numbers without commas or "
        "currency symbols. If only a line amount is given, divide it by the quantity. If the quotation is per a "
        "different unit (e.g. per metre vs per coil), convert to our unit and explain in remarks.\n"
        "- rates_include_gst = true only if the rates are stated to include GST; otherwise false. gst_pct = the GST "
        "rate for the line (e.g. 18); use the overall GST rate if only one is stated.\n"
        "- discount_pct = a percentage discount for the line (or the overall discount applied to every line).\n"
        "- If an item is marked regret / not quoted / not available, set unit_rate to null and say so in remarks.\n"
        "- freight.included = true if freight / transport is included or free; false with the amount if charged extra.\n"
        "- delivery_days = the delivery period in days if given per line (convert weeks to days).\n"
        "- Never invent numbers. Use null for anything not in the document. Dates as YYYY-MM-DD (Indian documents "
        "write dates as day/month/year)."
    )


def file_blocks(data: bytes, content_type: str) -> list[dict]:
    if len(data) > MAX_AI_BYTES:
        raise AppError("FILE_TOO_LARGE", "Files read by AI must be at most 15 MB.", status_code=413)
    if content_type == "application/pdf":
        return [{"type": "document", "source": {"type": "base64", "media_type": "application/pdf",
                                                "data": base64.b64encode(data).decode()}}]
    if content_type in IMAGE_TYPES:
        return [{"type": "image", "source": {"type": "base64", "media_type": content_type,
                                             "data": base64.b64encode(data).decode()}}]
    if content_type == XLSX:
        from app.purchase.rfq_excel import to_csv_text

        return [{"type": "text", "text": "The supplier's quotation (Excel workbook, as CSV text):\n" + to_csv_text(data)}]
    if content_type in ("text/csv", "text/plain"):
        return [{"type": "text", "text": "The supplier's quotation:\n" + data.decode("utf-8", "replace")[:60000]}]
    raise AppError("AI_FILE_TYPE", "AI can read PDF, JPG, PNG, WEBP and Excel (.xlsx) quotations.")


def _dec(v) -> Decimal | None:
    if v is None or v == "":
        return None
    try:
        d = Decimal(str(v).replace(",", "").replace("₹", "").replace("%", "").strip())
    except InvalidOperation:
        return None
    return d if d >= 0 else None


def _date(v) -> str | None:
    try:
        return date.fromisoformat(str(v)[:10]).isoformat() if v else None
    except ValueError:
        return None


def _short(v, n: int) -> str | None:
    if v is None:
        return None
    s = str(v).strip()
    return s[:n] or None


def to_prefill(rfq: Rfq, out: dict, allowed_gst: set[Decimal], default_gst: dict) -> dict:
    """Map the model's JSON onto the RFQ lines, in the same shape as the Excel reader's result."""
    freight = out.get("freight") or {}
    amount = _dec(freight.get("amount")) if isinstance(freight, dict) else None
    included = freight.get("included") if isinstance(freight, dict) else None
    header = {"quote_ref": _short(out.get("supplier_quote_no"), 100), "quote_date": _date(out.get("quote_date")),
              "valid_until": _date(out.get("valid_until")), "payment_terms": _short(out.get("payment_terms"), 500),
              "delivery_period": _short(out.get("delivery"), 300), "warranty": _short(out.get("warranty"), 300),
              "gst_inclusive": bool(out.get("rates_include_gst")),
              "freight_included": not (included is False or (amount and amount > 0)),
              "freight_amount": f"{amount.normalize():f}" if amount and included is not True else "0"}
    if not header["valid_until"] and isinstance(out.get("validity_days"), int | float) and out["validity_days"] > 0:
        base = date.fromisoformat(header["quote_date"]) if header["quote_date"] else today()
        header["valid_until"] = (base + timedelta(days=int(out["validity_days"]))).isoformat()
    by_no = {ln.line_no: ln for ln in rfq.lines}
    descs = {ln.id: ln.description.lower() for ln in rfq.lines}
    found: dict = {}
    warnings, unmatched = [], []
    raw_lines = out.get("lines") if isinstance(out.get("lines"), list) else []
    for x in raw_lines:
        if not isinstance(x, dict):
            continue
        ln = None
        try:
            ln = by_no.get(int(x.get("rfq_line_no"))) if x.get("rfq_line_no") is not None else None
        except (TypeError, ValueError):
            ln = None
        if ln is None and x.get("description"):
            d = str(x["description"]).lower()
            best = max(((difflib.SequenceMatcher(None, d, v).ratio(), k) for k, v in descs.items() if k not in found),
                       default=(0, None))
            if best[0] >= 0.55:
                ln = next(r for r in rfq.lines if r.id == best[1])
        if ln is None or ln.id in found:
            unmatched.append({"description": _short(x.get("description"), 300), "unit_rate": str(x.get("unit_rate"))})
            continue
        rate = _dec(x.get("unit_rate"))
        gst = _dec(x.get("gst_pct"))
        if gst is not None and Decimal("0") < gst < 1:
            gst *= 100
        if gst is None or (allowed_gst and gst.normalize() not in allowed_gst):
            if gst is not None:
                warnings.append({"line_no": ln.line_no, "message": f"Line {ln.line_no}: GST {gst.normalize():f} % read "
                                                                   "from the file is not a GST rate; check it."})
            gst = default_gst.get(ln.item_id) or Decimal("18")
        disc = _dec(x.get("discount_pct")) or Decimal("0")
        if disc > 100:
            disc = Decimal("0")
        days = x.get("delivery_days")
        found[ln.id] = {"rfq_line_id": str(ln.id), "line_no": ln.line_no, "not_quoted": rate is None,
                        "unit_rate": f"{rate.normalize():f}" if rate is not None else None,
                        "discount_pct": f"{disc.normalize():f}", "gst_pct": f"{gst.normalize():f}",
                        "make": _short(x.get("make"), 120),
                        "delivery_days": int(days) if isinstance(days, int | float) and days >= 0 else None,
                        "remarks": _short(x.get("remarks"), 500)}
    lines = []
    for ln in rfq.lines:
        if ln.id in found:
            lines.append(found[ln.id])
        else:
            lines.append({"rfq_line_id": str(ln.id), "line_no": ln.line_no, "not_quoted": True, "unit_rate": None,
                          "discount_pct": "0", "gst_pct": f"{(default_gst.get(ln.item_id) or Decimal('18')).normalize():f}",
                          "make": None, "delivery_days": None, "remarks": None})
            warnings.append({"line_no": ln.line_no, "message": f"Line {ln.line_no}: no rate found in the file."})
    for u in unmatched:
        warnings.append({"message": f"Could not match the supplier's item '{u['description']}' to an RFQ line."})
    return {"header": header, "lines": lines, "errors": [], "warnings": warnings, "unmatched": unmatched}


def read_quotation(rfq: Rfq, supplier_name: str, data: bytes, content_type: str, allowed_gst, default_gst) -> dict:
    blocks = file_blocks(data, content_type)
    text = _call(blocks + [{"type": "text", "text": _prompt(rfq, supplier_name)}])
    return to_prefill(rfq, parse_json(text), allowed_gst, default_gst)


def summarise(rfq: Rfq, cmp: dict) -> str:
    net = cmp["net"]
    rows = []
    for row in cmp["lines"]:
        ln = row["line"]
        cells = []
        for t in cmp["totals"]:
            x = row["cells"].get(t["q"].id)
            cells.append(f"{t['supplier'].supplier_name}: " + ("not quoted" if x is None else
                         f"net rate {x.net_rate} ({'before' if net else 'incl.'} GST value {x.taxable if net else x.total})"
                         + (f", make {x.make}" if x.make else "") + (f", {x.delivery_days} days" if x.delivery_days else "")))
        last = f"; last bought at {row['last']['rate']}" if row["last"] else ""
        rows.append(f"Line {ln.line_no} {ln.description} × {ln.quantity.normalize():f} {ln.unit}{last}: " + " | ".join(cells))
    sups = [f"{t['supplier'].supplier_name}: compared total {t['basis']}, quoted {t['quoted']}/{len(cmp['lines'])} lines, "
            f"freight {'included' if t['q'].freight_included else t['q'].freight_amount}, payment '{t['q'].payment_terms or '-'}', "
            f"delivery '{t['q'].delivery_period or '-'}', validity {t['q'].valid_until or '-'}, warranty '{t['q'].warranty or '-'}'"
            + (f", rank L{t['rank']}" if t["rank"] else ", incomplete") for t in cmp["totals"]]
    prompt = ("You help the purchase team of an electrical / lightning-protection contractor in Kerala, India compare "
              f"supplier quotations for RFQ {rfq.rfq_number or ''}. Amounts are in rupees; L1 is judged on value "
              f"{'before GST (GST credit is available)' if net else 'including GST'}.\n\nSuppliers:\n" + "\n".join(sups)
              + "\n\nLines:\n" + "\n".join(rows)
              + "\n\nWrite ONE short paragraph (at most 120 words, plain text, no headings or lists) recommending whom to "
                "award which lines to and why, mentioning price differences, any lines not quoted, delivery, payment "
                "terms, warranty and validity where they matter, and anything the buyer should check before ordering. "
                "The buyer makes the decision; do not claim to have made it.")
    text = _call([{"type": "text", "text": prompt}], max_tokens=600).strip()
    if not text:
        raise AppError("AI_BAD_REPLY", "The AI service sent an empty reply.", status_code=502)
    return text[:2000]
