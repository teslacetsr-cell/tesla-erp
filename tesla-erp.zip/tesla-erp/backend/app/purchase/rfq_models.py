"""Vendor quotations: request for quotation (RFQ) → quotations from several suppliers → comparison → purchase orders.

- An **RFQ** lists what we want priced (copied from a purchase request or a material request, or typed in) and
  the suppliers asked to quote. It goes out as a PDF letter and an Excel template per supplier.
- A **vendor quotation** is one supplier's answer: commercial terms and a rate (or "not quoted") per RFQ line.
  Invited suppliers have a quotation row in status 'awaited' until their rates are entered.
- The **comparison** puts the quotations side by side; the buyer chooses a supplier per line (the lowest, L1,
  by default; a remark is required for any other choice) and creates one draft purchase order per supplier.
"""
import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.models import AuditColumnsMixin, Base
from app.core.money import AMOUNT, PERCENT, QTY, RATE

RFQ_STATUSES = ("draft", "sent", "quotes_received", "compared", "closed", "cancelled")
QUOTE_STATUSES = ("awaited", "received", "declined")
QUOTE_SOURCES = ("manual", "excel", "ai")
COMPARE_ON = ("net", "total")  # value before GST (GST credit available) / value including GST
Z = Decimal("0")


def _in(col: str, values: tuple[str, ...]) -> str:
    return f"{col} in ({', '.join(repr(v) for v in values)})"


class Rfq(AuditColumnsMixin, Base):
    __tablename__ = "rfqs"
    __table_args__ = (CheckConstraint(_in("status", RFQ_STATUSES), name="status_valid"),
                      CheckConstraint(_in("compare_on", COMPARE_ON), name="compare_on_valid"),
                      Index("ix_rfqs_status", "status"), Index("ix_rfqs_pr", "purchase_request_id"),
                      Index("ix_rfqs_mr", "material_request_id"))

    rfq_number: Mapped[str | None] = mapped_column(String(30), unique=True)  # given when first sent or printed
    rfq_date: Mapped[date] = mapped_column(Date, nullable=False)
    purchase_request_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("purchase_requests.id", ondelete="SET NULL"))
    material_request_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("material_requests.id", ondelete="SET NULL"))
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"))
    warehouse_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("warehouses.id", ondelete="RESTRICT"))
    delivery_location: Mapped[str | None] = mapped_column(Text)
    due_date: Mapped[date | None] = mapped_column(Date)  # quotes due by
    required_by: Mapped[date | None] = mapped_column(Date)
    contact_person: Mapped[str | None] = mapped_column(String(300))
    terms: Mapped[str | None] = mapped_column(Text)
    notes: Mapped[str | None] = mapped_column(Text)
    compare_on: Mapped[str] = mapped_column(String(10), nullable=False, default="net", server_default="net")
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="draft", server_default="draft")
    status_reason: Mapped[str | None] = mapped_column(String(500))
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    compared_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    lines: Mapped[list["RfqLine"]] = relationship(order_by="RfqLine.line_no", cascade="all, delete-orphan",
                                                  lazy="selectin")
    quotations: Mapped[list["VendorQuotation"]] = relationship(order_by="VendorQuotation.created_at",
                                                               cascade="all, delete-orphan", lazy="selectin")


class RfqLine(AuditColumnsMixin, Base):
    __tablename__ = "rfq_lines"
    __table_args__ = (CheckConstraint("quantity > 0", name="qty_positive"),)

    rfq_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("rfqs.id", ondelete="CASCADE"), nullable=False, index=True)
    line_no: Mapped[int] = mapped_column(Integer, nullable=False)
    item_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("items.id", ondelete="RESTRICT"))
    description: Mapped[str] = mapped_column(Text, nullable=False)
    specification: Mapped[str | None] = mapped_column(Text)
    unit: Mapped[str] = mapped_column(String(20), nullable=False)
    quantity: Mapped[Decimal] = mapped_column(QTY, nullable=False)
    required_by: Mapped[date | None] = mapped_column(Date)
    pr_line_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("purchase_request_lines.id", ondelete="SET NULL"))
    mr_line_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("material_request_lines.id", ondelete="SET NULL"))
    remarks: Mapped[str | None] = mapped_column(String(500))
    # the buyer's choice on the comparison (null = not chosen yet / not to be ordered)
    selected_quotation_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("vendor_quotations.id", ondelete="SET NULL"))
    selection_remark: Mapped[str | None] = mapped_column(String(500))


class VendorQuotation(AuditColumnsMixin, Base):
    __tablename__ = "vendor_quotations"
    __table_args__ = (UniqueConstraint("rfq_id", "supplier_id"),
                      CheckConstraint(_in("status", QUOTE_STATUSES), name="status_valid"),
                      CheckConstraint(f"source is null or {_in('source', QUOTE_SOURCES)}", name="source_valid"),
                      CheckConstraint("freight_amount >= 0", name="freight_nonneg"),
                      Index("ix_vendor_quotations_supplier", "supplier_id"))

    rfq_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("rfqs.id", ondelete="CASCADE"), nullable=False, index=True)
    supplier_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("suppliers.id", ondelete="RESTRICT"), nullable=False)
    invited: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="awaited", server_default="awaited")
    source: Mapped[str | None] = mapped_column(String(10))
    quote_ref: Mapped[str | None] = mapped_column(String(100))
    quote_date: Mapped[date | None] = mapped_column(Date)
    valid_until: Mapped[date | None] = mapped_column(Date)
    payment_terms: Mapped[str | None] = mapped_column(String(500))
    delivery_period: Mapped[str | None] = mapped_column(String(300))
    freight_included: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")
    freight_amount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    warranty: Mapped[str | None] = mapped_column(String(300))
    gst_inclusive: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    notes: Mapped[str | None] = mapped_column(Text)
    taxable: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    gst: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    grand_total: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")  # incl. freight
    received_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    purchase_order_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("purchase_orders.id", ondelete="SET NULL"))

    lines: Mapped[list["VendorQuotationLine"]] = relationship(cascade="all, delete-orphan", lazy="selectin")


class VendorQuotationLine(AuditColumnsMixin, Base):
    __tablename__ = "vendor_quotation_lines"
    __table_args__ = (UniqueConstraint("quotation_id", "rfq_line_id"),
                      CheckConstraint("unit_rate is null or unit_rate >= 0", name="rate_nonneg"),
                      CheckConstraint("discount_pct >= 0 and discount_pct <= 100", name="discount_range"),
                      CheckConstraint("gst_pct >= 0 and gst_pct <= 100", name="gst_range"))

    quotation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("vendor_quotations.id", ondelete="CASCADE"),
                                                    nullable=False, index=True)
    rfq_line_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("rfq_lines.id", ondelete="CASCADE"), nullable=False,
                                                   index=True)
    not_quoted: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    unit_rate: Mapped[Decimal | None] = mapped_column(RATE)
    discount_pct: Mapped[Decimal] = mapped_column(PERCENT, nullable=False, default=Z, server_default="0")
    gst_pct: Mapped[Decimal] = mapped_column(PERCENT, nullable=False, default=Decimal("18"), server_default="18")
    make: Mapped[str | None] = mapped_column(String(120))
    delivery_days: Mapped[int | None] = mapped_column(Integer)
    remarks: Mapped[str | None] = mapped_column(String(500))
    # computed on save: net rate = value before GST after discount ÷ qty
    net_rate: Mapped[Decimal] = mapped_column(RATE, nullable=False, default=Z, server_default="0")
    taxable: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    gst_amount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    total: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
