"""Excel for vendor quotations: the reply template sent to each supplier, reading it back, and the comparison sheet."""
import io
import re
import uuid
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.boq import lines as L
from app.core.errors import AppError
from app.crm.service import today
from app.platform import pdfkit as K
from app.products.models import Item
from app.purchase.rfq_models import Rfq, VendorQuotation
from app.suppliers.models import Supplier

XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
RED = PatternFill("solid", fgColor="D90000")
INPUT = PatternFill("solid", fgColor="FFF7CC")
GREEN = PatternFill("solid", fgColor="C6EFCE")
GREY = PatternFill("solid", fgColor="F3F4F6")
WHITE_B = Font(bold=True, color="FFFFFF")
BOLD = Font(bold=True)
THIN = Side(style="thin", color="D1D5DB")
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(wrap_text=True, vertical="top")

SHEET = "Quotation"
META = "_rfq"
HEADER_FIELDS = [  # (key, label shown in column A)
    ("quote_ref", "Your quotation no."),
    ("quote_date", "Quotation date"),
    ("validity", "Validity (valid until date, or days)"),
    ("payment_terms", "Payment terms"),
    ("delivery_period", "Delivery period"),
    ("freight", "Freight (Included, or amount extra in ₹)"),
    ("warranty", "Warranty"),
    ("gst_inclusive", "Rates include GST? (Yes / No)"),
]
COLS = [  # (key, header, width)
    ("line_no", "Line no", 8), ("item_code", "Item code", 14), ("description", "Description", 42),
    ("specification", "Specification", 32), ("unit", "Unit", 8), ("quantity", "Qty", 10),
    ("unit_rate", "Unit rate (₹)", 13), ("discount_pct", "Discount %", 10), ("gst_pct", "GST %", 8),
    ("make", "Make / Brand", 18), ("delivery_days", "Delivery (days)", 11), ("remarks", "Remarks", 28),
    ("amount", "Amount before GST (₹)", 16), ("rfq_line_id", "RFQ line id", 38),
]
COL = {k: i for i, (k, _, _) in enumerate(COLS, start=1)}
INPUT_KEYS = ("unit_rate", "discount_pct", "gst_pct", "make", "delivery_days", "remarks")


def _date(d) -> str:
    return d.strftime("%d %b %Y") if d else ""


def _item_gst(db: Session, rfq: Rfq) -> dict:
    ids = {ln.item_id for ln in rfq.lines if ln.item_id}
    items = {i.id: i for i in db.scalars(select(Item).where(Item.id.in_(ids)))} if ids else {}
    return {i: (it.item_code, it.tax_rate.rate if it.tax_rate else None) for i, it in items.items()}


# ------------------------------------------------------------------ template
def template(db: Session, rfq: Rfq, vq: VendorQuotation) -> bytes:
    sup = db.get(Supplier, vq.supplier_id)
    company = K.company(db)
    info = _item_gst(db, rfq)
    wb = Workbook()
    ws = wb.active
    ws.title = SHEET
    for i, (_, _, w) in enumerate(COLS, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws["A1"] = company.company_name if company else "Tesla Consulting Engineers"
    ws["A1"].font = Font(bold=True, size=14, color="D90000")
    ws["A2"] = "REQUEST FOR QUOTATION — reply form"
    ws["A2"].font = Font(bold=True, size=12)
    facts = [("RFQ No.", rfq.rfq_number or "DRAFT"), ("RFQ date", _date(rfq.rfq_date)),
             ("Quotes due by", _date(rfq.due_date)), ("Supplier", sup.supplier_name),
             ("Deliver to", (rfq.delivery_location or "").replace("\n", ", ")),
             ("Required by", _date(rfq.required_by)), ("Contact", rfq.contact_person or "")]
    r = 3
    for k, v in facts:
        ws.cell(r, 1, k).font = BOLD
        ws.cell(r, 3, v)
        r += 1
    ws.cell(r, 1, "Please fill the yellow cells and e-mail this file back. Leave the rate blank for any item you "
                  "do not quote. Do not change the line numbers or delete rows.").font = Font(italic=True, color="6B7280")
    r += 2
    for key, lbl in HEADER_FIELDS:
        ws.cell(r, 1, lbl).font = BOLD
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)
        c = ws.cell(r, 3)
        c.fill, c.border = INPUT, BOX
        ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=4)
        if key == "gst_inclusive":
            c.value = "No"
            dv = DataValidation(type="list", formula1='"Yes,No"', allow_blank=True)
            dv.add(c.coordinate)
            ws.add_data_validation(dv)
        r += 1
    r += 1
    head = r
    for i, (_, h, _) in enumerate(COLS, start=1):
        c = ws.cell(head, i, h)
        c.fill, c.font, c.alignment, c.border = RED, WHITE_B, Alignment(wrap_text=True, vertical="center"), BOX
    ws.row_dimensions[head].height = 30
    rates = sorted(L.gst_rates(db))
    gst_dv = DataValidation(type="list", formula1='"' + ",".join(f"{x:f}" for x in rates) + '"', allow_blank=True) \
        if rates else None
    num_dv = DataValidation(type="decimal", operator="greaterThanOrEqual", formula1="0", allow_blank=True)
    for n, ln in enumerate(rfq.lines):
        row = head + 1 + n
        code, gst = info.get(ln.item_id, (None, None))
        vals = {"line_no": ln.line_no, "item_code": code, "description": ln.description,
                "specification": ln.specification, "unit": ln.unit, "quantity": float(ln.quantity),
                "gst_pct": float(gst) if gst is not None else 18, "discount_pct": 0, "rfq_line_id": str(ln.id)}
        for key, col in COL.items():
            c = ws.cell(row, col, vals.get(key))
            c.border, c.alignment = BOX, WRAP
            if key in INPUT_KEYS:
                c.fill = INPUT
        q, rt, d = (get_column_letter(COL[k]) for k in ("quantity", "unit_rate", "discount_pct"))
        ws.cell(row, COL["amount"], f'=IF({rt}{row}="","",ROUND({q}{row}*{rt}{row}*(1-N({d}{row})/100),2))').border = BOX
        if gst_dv:
            gst_dv.add(ws.cell(row, COL["gst_pct"]).coordinate)
        for k in ("unit_rate", "discount_pct", "delivery_days"):
            num_dv.add(ws.cell(row, COL[k]).coordinate)
    if gst_dv:
        ws.add_data_validation(gst_dv)
    ws.add_data_validation(num_dv)
    last = head + len(rfq.lines)
    tr = last + 1
    ws.cell(tr, COL["remarks"], "Total before GST").font = BOLD
    amt = get_column_letter(COL["amount"])
    ws.cell(tr, COL["amount"], f"=SUM({amt}{head + 1}:{amt}{last})").font = BOLD
    ws.column_dimensions[get_column_letter(COL["rfq_line_id"])].hidden = True
    ws.freeze_panes = ws.cell(head + 1, 4)
    if rfq.terms:
        ws.cell(tr + 2, 1, "Terms").font = BOLD
        ws.cell(tr + 2, 3, rfq.terms).alignment = WRAP
    meta = wb.create_sheet(META)
    for i, (k, v) in enumerate((("rfq_id", str(rfq.id)), ("quotation_id", str(vq.id)), ("supplier_id", str(sup.id)),
                                ("rfq_number", rfq.rfq_number or "")), start=1):
        meta.cell(i, 1, k)
        meta.cell(i, 2, v)
    meta.sheet_state = "hidden"
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ------------------------------------------------------------------ reading a filled template
_NUM = re.compile(r"-?\d[\d,]*(?:\.\d+)?")
NOT_QUOTED_WORDS = ("nq", "n/q", "not quoted", "na", "n/a", "-", "--", "regret", "not available", "nil")


def _num(v) -> Decimal | None:
    if v is None or (isinstance(v, str) and not v.strip()):
        return None
    if isinstance(v, bool):
        raise ValueError
    if isinstance(v, int | float | Decimal):
        return Decimal(str(v))
    s = str(v).replace("₹", "").replace("Rs.", "").replace("Rs", "").replace("%", "").strip()
    m = _NUM.fullmatch(s.replace(" ", ""))
    if not m:
        raise ValueError
    return Decimal(m.group(0).replace(",", ""))


def _parse_date(v) -> date | None:
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    s = str(v).strip()
    for fmt in ("%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d", "%d.%m.%Y", "%d %b %Y", "%d-%b-%Y", "%d %B %Y", "%d/%m/%y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    raise ValueError


def _text(v) -> str | None:
    if v is None:
        return None
    if isinstance(v, datetime):
        v = v.date()
    if isinstance(v, date):
        return v.strftime("%d %b %Y")
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    s = str(v).strip()
    return s or None


def _norm(s) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()


def parse(db: Session, rfq: Rfq, data: bytes) -> dict:
    """Read a supplier's filled reply form. Returns pre-fill data for the quotation (header + one row per RFQ line)
    and the problems found, per Excel row. Nothing is saved here."""
    try:
        wb = load_workbook(io.BytesIO(data), data_only=True)
    except Exception as exc:  # noqa: BLE001
        raise AppError("INVALID_EXCEL", "The file could not be read as an Excel (.xlsx) workbook.") from exc
    if META in wb.sheetnames:
        meta = {str(r[0].value): r[1].value for r in wb[META].iter_rows(min_row=1, max_row=10, max_col=2) if r[0].value}
        if meta.get("rfq_id") and str(meta["rfq_id"]) != str(rfq.id):
            raise AppError("WRONG_RFQ", f"This file is the reply form of another RFQ ({meta.get('rfq_number') or 'unknown'}).")
    ws = wb[SHEET] if SHEET in wb.sheetnames else wb.worksheets[0]
    rows = list(ws.iter_rows(values_only=True))
    head = next((i for i, r in enumerate(rows) if r and _norm(r[0]) in ("line no", "line no.", "sl no", "s no", "#")), None)
    if head is None:
        raise AppError("TEMPLATE_MISMATCH", "No 'Line no' column was found. Use the Excel reply form of this RFQ.")
    hdr = rows[head]
    cols: dict[str, int] = {}
    for idx, h in enumerate(hdr):
        hn = _norm(h).replace(" *", "")
        for key, label, _ in COLS:
            if key not in cols and hn and (hn == _norm(label) or hn.startswith(_norm(label).split(" (")[0])):
                cols[key] = idx
                break
    if "unit_rate" not in cols:
        raise AppError("TEMPLATE_MISMATCH", "No 'Unit rate' column was found. Use the Excel reply form of this RFQ.")

    errors: list[dict] = []
    warnings: list[dict] = []
    header: dict = {}
    labels = {_norm(lbl): key for key, lbl in HEADER_FIELDS}
    for n, r in enumerate(rows[:head], start=1):
        if not r or r[0] is None:
            continue
        key = labels.get(_norm(r[0]))
        if key is None:
            continue
        v = next((x for x in r[1:] if x not in (None, "")), None)
        try:
            if key == "quote_date":
                header["quote_date"] = _parse_date(v)
            elif key == "validity":
                if isinstance(v, datetime | date):
                    header["valid_until"] = _parse_date(v)
                elif v not in (None, ""):
                    try:
                        header["valid_until"] = _parse_date(v)
                    except ValueError:
                        m = re.search(r"\d+", str(v))
                        if not m:
                            raise
                        header["validity_days"] = int(m.group(0))
            elif key == "freight":
                t = _text(v)
                if t is None or "incl" in t.lower() or t.lower() in ("free", "nil", "0", "no", "for site", "f.o.r. site"):
                    header["freight_included"], header["freight_amount"] = True, "0"
                else:
                    m = _NUM.search(t.replace(" ", ""))
                    header["freight_included"] = False
                    header["freight_amount"] = str(Decimal(m.group(0).replace(",", ""))) if m else "0"
                    if not m:
                        warnings.append({"row": n, "message": f"Freight '{t}': no amount given; enter it before saving."})
            elif key == "gst_inclusive":
                t = (_text(v) or "").lower()
                header["gst_inclusive"] = t in ("yes", "y", "true", "inclusive", "incl", "included")
            else:
                header[key] = _text(v)
        except ValueError:
            errors.append({"row": n, "message": f"{r[0]}: '{v}' is not a valid value."})
    if "validity_days" in header:
        header["valid_until"] = (header.get("quote_date") or today()) + timedelta(days=header.pop("validity_days"))

    by_id = {str(ln.id): ln for ln in rfq.lines}
    by_no = {ln.line_no: ln for ln in rfq.lines}
    by_desc = {_norm(ln.description): ln for ln in rfq.lines}
    gst_default = {i: g for i, (_, g) in _item_gst(db, rfq).items()}
    allowed = L.gst_rates(db)
    found: dict[uuid.UUID, dict] = {}

    def cell(r, key):
        i = cols.get(key)
        return r[i] if i is not None and i < len(r) else None

    for n, r in enumerate(rows[head + 1:], start=head + 2):
        if not r or all(x in (None, "") for x in r):
            continue
        if cell(r, "line_no") in (None, "") and cell(r, "description") in (None, "") and cell(r, "rfq_line_id") in (None, ""):
            continue  # totals / notes under the table
        ln = by_id.get(str(cell(r, "rfq_line_id") or "").strip())
        if ln is None:
            try:
                ln = by_no.get(int(_num(cell(r, "line_no")))) if cell(r, "line_no") not in (None, "") else None
            except (ValueError, InvalidOperation, TypeError):
                ln = None
        if ln is None:
            ln = by_desc.get(_norm(cell(r, "description")))
        if ln is None:
            errors.append({"row": n, "message": f"Row {n}: does not match any line of this RFQ."})
            continue
        if ln.id in found:
            errors.append({"row": n, "line_no": ln.line_no, "message": f"Row {n}: line {ln.line_no} appears twice."})
            continue
        problems = []
        raw = cell(r, "unit_rate")
        rate = None
        nq = False
        if isinstance(raw, str) and _norm(raw) in NOT_QUOTED_WORDS:
            nq = True
        else:
            try:
                rate = _num(raw)
                if rate is not None and rate < 0:
                    problems.append("the unit rate cannot be negative")
                nq = rate is None
            except (ValueError, InvalidOperation):
                problems.append(f"unit rate '{raw}' is not a number")
        disc = Decimal("0")
        try:
            disc = _num(cell(r, "discount_pct")) or Decimal("0")
            if not Decimal("0") <= disc <= Decimal("100"):
                problems.append("discount must be between 0 and 100 %")
        except (ValueError, InvalidOperation):
            problems.append(f"discount '{cell(r, 'discount_pct')}' is not a number")
        gst = gst_default.get(ln.item_id) or Decimal("18")
        try:
            g = _num(cell(r, "gst_pct"))
            if g is not None:
                if Decimal("0") < g < 1:  # 0.18 typed for 18 %
                    g = g * 100
                gst = g
            if not nq and allowed and gst.normalize() not in allowed:
                problems.append(f"GST {gst.normalize():f} % is not a GST rate ({', '.join(f'{x:f}' for x in sorted(allowed))})")
        except (ValueError, InvalidOperation):
            problems.append(f"GST '{cell(r, 'gst_pct')}' is not a number")
        days = None
        dv = cell(r, "delivery_days")
        if dv not in (None, ""):
            try:
                days = int(_num(dv))
                if days < 0:
                    problems.append("delivery days cannot be negative")
            except (ValueError, InvalidOperation, TypeError):
                m = re.search(r"\d+", str(dv))
                if m:
                    days = int(m.group(0)) * (7 if "week" in str(dv).lower() else 1)
                else:
                    problems.append(f"delivery '{dv}' is not a number of days")
        if problems:
            errors.append({"row": n, "line_no": ln.line_no, "message": f"Row {n} (line {ln.line_no}): " + "; ".join(problems) + "."})
        found[ln.id] = {"rfq_line_id": str(ln.id), "line_no": ln.line_no, "not_quoted": nq or rate is None,
                        "unit_rate": None if nq or rate is None else f"{rate.normalize():f}",
                        "discount_pct": f"{disc.normalize():f}", "gst_pct": f"{gst.normalize():f}",
                        "make": (_text(cell(r, "make")) or None) and _text(cell(r, "make"))[:120],
                        "delivery_days": days, "remarks": (_text(cell(r, "remarks")) or None) and _text(cell(r, "remarks"))[:500]}
    lines = []
    for ln in rfq.lines:
        if ln.id in found:
            lines.append(found[ln.id])
        else:
            lines.append({"rfq_line_id": str(ln.id), "line_no": ln.line_no, "not_quoted": True, "unit_rate": None,
                          "discount_pct": "0", "gst_pct": f"{(gst_default.get(ln.item_id) or Decimal('18')).normalize():f}",
                          "make": None, "delivery_days": None, "remarks": None})
            warnings.append({"line_no": ln.line_no, "message": f"Line {ln.line_no} is not in the file; treated as not quoted."})
    if not any(not x["not_quoted"] for x in lines) and not errors:
        errors.append({"message": "No rates were found in the file."})
    for k in ("quote_date", "valid_until"):
        if isinstance(header.get(k), date):
            header[k] = header[k].isoformat()
    return {"header": header, "lines": lines, "errors": errors, "warnings": warnings}


def to_csv_text(data: bytes, max_chars: int = 60000) -> str:
    """Any Excel workbook as plain CSV-like text (for the AI reader)."""
    try:
        wb = load_workbook(io.BytesIO(data), data_only=True, read_only=True)
    except Exception as exc:  # noqa: BLE001
        raise AppError("INVALID_EXCEL", "The file could not be read as an Excel (.xlsx) workbook.") from exc
    out = []
    for ws in wb.worksheets:
        if getattr(ws, "sheet_state", "visible") != "visible":
            continue
        out.append(f"### Sheet: {ws.title}")
        for r in ws.iter_rows(values_only=True):
            if r and any(v not in (None, "") for v in r):
                out.append(",".join('"' + str(_text(v) or "").replace('"', "'") + '"' for v in r))
    text = "\n".join(out)
    return text[:max_chars]


# ------------------------------------------------------------------ comparison sheet
def comparison(db: Session, rfq: Rfq, cmp: dict) -> bytes:
    from openpyxl.worksheet.page import PageMargins

    wb = Workbook()
    ws = wb.active
    ws.title = "Comparison"
    company = K.company(db)
    totals = cmp["totals"]
    net = cmp["net"]
    fixed = [("#", 5), ("Description", 40), ("Qty", 9), ("Unit", 7), ("Last price (₹)", 13)]
    per = [("Rate", 11), ("Disc %", 7), ("Net rate", 11), ("GST %", 6), ("Amount" + (" (before GST)" if net else " (incl. GST)"), 14), ("Make", 12)]
    ncol = len(fixed) + len(per) * len(totals) + 3
    ws["A1"] = company.company_name if company else "Tesla Consulting Engineers"
    ws["A1"].font = Font(bold=True, size=14, color="D90000")
    ws["A2"] = f"COMPARISON OF QUOTATIONS — {rfq.rfq_number or 'Draft RFQ'}"
    ws["A2"].font = Font(bold=True, size=12)
    ws["A3"] = (f"RFQ date {_date(rfq.rfq_date)} · {len(totals)} quotation(s) · L1 on value "
                + ("before GST" if net else "including GST") + " · L1 cells are green")
    ws["A3"].font = Font(color="6B7280")
    top = 5
    for i, (h, w) in enumerate(fixed, start=1):
        ws.cell(top + 1, i, h)
        ws.merge_cells(start_row=top, start_column=i, end_row=top + 1, end_column=i)
        ws.cell(top, i, h)
        ws.column_dimensions[get_column_letter(i)].width = w
    col = len(fixed) + 1
    starts = {}
    for t in totals:
        starts[t["q"].id] = col
        name = t["supplier"].supplier_name + (f"  (L{t['rank']})" if t["rank"] else "")
        ws.cell(top, col, name)
        ws.merge_cells(start_row=top, start_column=col, end_row=top, end_column=col + len(per) - 1)
        for j, (h, w) in enumerate(per):
            ws.cell(top + 1, col + j, h)
            ws.column_dimensions[get_column_letter(col + j)].width = w
        col += len(per)
    sel_col = col
    for j, (h, w) in enumerate((("Selected supplier", 22), ("Remark", 30), ("Saving vs last (₹)", 14))):
        ws.cell(top, sel_col + j, h)
        ws.merge_cells(start_row=top, start_column=sel_col + j, end_row=top + 1, end_column=sel_col + j)
        ws.column_dimensions[get_column_letter(sel_col + j)].width = w
    for r in (top, top + 1):
        for c in range(1, ncol + 1):
            cell = ws.cell(r, c)
            cell.fill, cell.font, cell.border = RED, WHITE_B, BOX
            cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
    r = top + 2
    names = {t["q"].id: t["supplier"].supplier_name for t in totals}
    for row in cmp["lines"]:
        ln = row["line"]
        vals = [ln.line_no, ln.description + (f"\n{ln.specification}" if ln.specification else ""), float(ln.quantity), ln.unit,
                float(row["last"]["rate"]) if row["last"] else None]
        for i, v in enumerate(vals, start=1):
            ws.cell(r, i, v)
        for t in totals:
            x = row["cells"].get(t["q"].id)
            c0 = starts[t["q"].id]
            if x is None:
                ws.cell(r, c0, "Not quoted").font = Font(italic=True, color="9CA3AF")
            else:
                for j, v in enumerate((x.unit_rate, x.discount_pct, x.net_rate, x.gst_pct, x.taxable if net else x.total)):
                    ws.cell(r, c0 + j, float(v))
                ws.cell(r, c0 + 5, x.make)
                if t["q"].id in row["l1"]:
                    for j in range(len(per)):
                        ws.cell(r, c0 + j).fill = GREEN
            if row["selected"] == t["q"].id:
                ws.cell(r, c0 + 4).font = BOLD
        ws.cell(r, sel_col, names.get(row["selected"], "— not ordered —" if row["saved"] else ""))
        ws.cell(r, sel_col + 1, row["line"].selection_remark)
        ws.cell(r, sel_col + 2, float(row["savings"]) if row["savings"] is not None else None)
        for c in range(1, ncol + 1):
            ws.cell(r, c).border = BOX
            ws.cell(r, c).alignment = WRAP
        r += 1
    # totals and commercial terms
    low = min((t["basis"] for t in totals if t["rank"] == 1), default=None)
    summary = [("Value before GST (₹)", lambda t: float(t["q"].taxable)), ("GST (₹)", lambda t: float(t["q"].gst)),
               ("Freight (₹)", lambda t: float(t["q"].freight_amount) if not t["q"].freight_included else "Included"),
               ("Total incl. GST and freight (₹)", lambda t: float(t["q"].grand_total)),
               ("Compared total (₹)", lambda t: float(t["basis"])),
               ("Lines quoted", lambda t: f"{t['quoted']} of {len(cmp['lines'])}"),
               ("Rank", lambda t: f"L{t['rank']}" if t["rank"] else "incomplete"),
               ("Quotation ref / date", lambda t: " / ".join(x for x in (t["q"].quote_ref, _date(t["q"].quote_date)) if x)),
               ("Payment terms", lambda t: t["q"].payment_terms), ("Delivery", lambda t: t["q"].delivery_period),
               ("Valid until", lambda t: _date(t["q"].valid_until)), ("Warranty", lambda t: t["q"].warranty),
               ("Rates include GST", lambda t: "Yes" if t["q"].gst_inclusive else "No")]
    r += 1
    for lbl, fn in summary:
        ws.cell(r, 2, lbl).font = BOLD
        ws.cell(r, 2).fill = GREY
        for t in totals:
            c0 = starts[t["q"].id]
            ws.cell(r, c0, fn(t))
            ws.merge_cells(start_row=r, start_column=c0, end_row=r, end_column=c0 + len(per) - 1)
            ws.cell(r, c0).alignment = Alignment(horizontal="center", wrap_text=True)
            if lbl.startswith("Compared total") and t["rank"] == 1 and t["basis"] == low:
                ws.cell(r, c0).fill = GREEN
                ws.cell(r, c0).font = BOLD
        r += 1
    r += 1
    ws.cell(r, 2, "Value of the selection (₹)").font = BOLD
    ws.cell(r, 3, float(cmp["selected_value"]))
    ws.cell(r + 1, 2, "Sum of L1 per line (₹)").font = BOLD
    ws.cell(r + 1, 3, float(cmp["l1_value"]))
    ws.cell(r + 2, 2, "Saving vs last purchase prices (₹)").font = BOLD
    ws.cell(r + 2, 3, float(cmp["savings"]))
    r += 5
    for j, lbl in enumerate(("Prepared by", "Checked by", "Approved by")):
        ws.cell(r, 2 + j * 4 if j else 2, lbl).font = BOLD
    ws.freeze_panes = ws.cell(top + 2, 3)
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins = PageMargins(left=0.3, right=0.3, top=0.4, bottom=0.4)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
