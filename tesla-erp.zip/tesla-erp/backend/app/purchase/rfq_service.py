"""Vendor quotations (RFQ → quotations → comparison → purchase orders). See rfq_models for the flow."""
import uuid
from decimal import Decimal

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.boq import lines as L
from app.core.api import ListParams, paginate
from app.core.errors import AppError, Forbidden, NotFound
from app.core.models import check_row_version
from app.core.money import round_amount, round_qty, round_rate
from app.crm.service import now, today
from app.platform.audit import service as audit
from app.platform.numbering import service as numbering
from app.products.models import Item, Warehouse
from app.projects.models import Project
from app.purchase import service as purchase
from app.purchase.models import (
    MaterialRequest,
    MaterialRequestLine,
    PurchaseOrder,
    PurchaseOrderItem,
    PurchaseRequest,
    PurchaseRequestLine,
)
from app.purchase.rfq_models import Rfq, RfqLine, VendorQuotation, VendorQuotationLine
from app.purchase.schemas import PoLineIn, PurchaseOrderIn
from app.suppliers.models import Supplier
from app.users.models import User

Z = Decimal("0")
HUNDRED = Decimal("100")
EDITABLE = ("draft", "sent")
QUOTABLE = ("draft", "sent", "quotes_received", "compared")


def _q(v: Decimal) -> str:
    return f"{v.normalize():f}"


def label(rfq: Rfq) -> str:
    return rfq.rfq_number or "Draft RFQ"


# ------------------------------------------------------------------ helpers
def get(db: Session, rid: uuid.UUID, lock: bool = False) -> Rfq:
    rfq = db.get(Rfq, rid, with_for_update=lock or None)
    if rfq is None:
        raise NotFound("rfq")
    return rfq


def get_quotation(db: Session, rfq: Rfq, qid: uuid.UUID) -> VendorQuotation:
    vq = db.get(VendorQuotation, qid)
    if vq is None or vq.rfq_id != rfq.id:
        raise NotFound("vendor_quotation")
    return vq


def ensure_number(db: Session, p: Principal, rfq: Rfq) -> None:
    """The RFQ number is given the first time the RFQ leaves the office (sent, printed or a quote is recorded), so
    drafts that are thrown away never use up a number."""
    if rfq.rfq_number is None:
        rfq.rfq_number = numbering.next_number(db, p.company_id, "RFQ", on=rfq.rfq_date)
        db.flush()


def _contact(db: Session, p: Principal) -> str:
    u = db.get(User, p.id)
    return ", ".join(x for x in (u.full_name, u.phone, u.email) if x) if u else ""


def _location(db: Session, wh: Warehouse | None, prj: Project | None) -> str | None:
    parts = []
    if wh is not None:
        parts.append(wh.name + (f", {wh.address}" if wh.address else ""))
    if prj is not None and (wh is None or wh.project_id != prj.id):
        parts.append(f"Project {prj.project_number} · {prj.name}")
    return "\n".join(parts) or None


def quick_supplier(db: Session, p: Principal, data) -> Supplier:
    """Find a supplier by name, or create one through the supplier master's own create (code, audit, checks)."""
    name = data.supplier_name.strip()
    found = db.scalar(select(Supplier).where(func.lower(Supplier.supplier_name) == name.lower()))
    if found is not None:
        return found
    if not p.can("supplier.create"):
        raise Forbidden("You cannot add suppliers to the supplier master.")
    from app.suppliers.router import _create
    from app.suppliers.schemas import SupplierIn

    return _create(db, p, SupplierIn(supplier_name=name, phone=data.phone, email=data.email,
                                     notes="Added from a request for quotation."), allow_duplicate=False)


def _supplier(db: Session, sid: uuid.UUID) -> Supplier:
    s = db.get(Supplier, sid)
    if s is None:
        raise NotFound("supplier")
    if s.status == "blocked":
        raise AppError("SUPPLIER_BLOCKED", f"{s.supplier_name} is blocked.")
    return s


def _add_quotation(db: Session, p: Principal, rfq: Rfq, sup: Supplier, invited: bool = True) -> VendorQuotation:
    vq = next((q for q in rfq.quotations if q.supplier_id == sup.id), None)
    if vq is not None:
        return vq
    vq = VendorQuotation(rfq_id=rfq.id, supplier_id=sup.id, invited=invited, status="awaited",
                         payment_terms=None, created_by=p.id, updated_by=p.id)
    rfq.quotations.append(vq)
    db.flush()
    return vq


# ------------------------------------------------------------------ source documents
def _source_lines(db: Session, data) -> tuple[list[dict], dict]:
    """Open lines (and header defaults) of the purchase request or material request the RFQ is made from."""
    if data.purchase_request_id:
        pr = db.get(PurchaseRequest, data.purchase_request_id)
        if pr is None:
            raise NotFound("purchase_request")
        if pr.status not in ("pending_approval", "approved", "partially_ordered"):
            raise AppError("PR_NOT_OPEN", f"Quotations can be invited on a submitted, open purchase request "
                                          f"({pr.pr_number or 'this draft'} is {pr.status.replace('_', ' ')}).")
        rows = []
        for ln in pr.lines:
            left = ln.quantity - ln.ordered_qty
            if left > 0:
                rows.append({"item_id": ln.item_id, "description": ln.description, "unit": ln.unit, "quantity": left,
                             "pr_line_id": ln.id, "mr_line_id": ln.mr_line_id, "required_by": pr.required_by,
                             "remarks": ln.remarks})
        sups = [ln.suggested_supplier_id for ln in pr.lines if ln.suggested_supplier_id]
        head = {"project_id": pr.project_id, "warehouse_id": pr.warehouse_id, "required_by": pr.required_by,
                "suppliers": sups, "label": pr.pr_number}
    elif data.material_request_id:
        mr = db.get(MaterialRequest, data.material_request_id)
        if mr is None:
            raise NotFound("material_request")
        if mr.status not in ("submitted", "in_progress"):
            raise AppError("MR_NOT_OPEN", f"Quotations can be invited on a submitted, open material request "
                                          f"({mr.mr_number or 'this draft'} is {mr.status.replace('_', ' ')}).")
        rows = [{"item_id": ln.item_id, "description": ln.description, "unit": ln.unit,
                 "quantity": ln.quantity - ln.processed_qty, "mr_line_id": ln.id, "pr_line_id": None,
                 "required_by": mr.required_by, "remarks": ln.remarks}
                for ln in mr.lines if ln.quantity - ln.processed_qty > 0]
        head = {"project_id": mr.project_id, "warehouse_id": mr.warehouse_id, "required_by": mr.required_by,
                "suppliers": [], "label": mr.mr_number}
    else:
        return [], {}
    if not rows:
        raise AppError("NOTHING_OPEN", f"Everything on {head['label']} is already ordered or requested.")
    items = {i.id: i for i in db.scalars(select(Item).where(Item.id.in_({r["item_id"] for r in rows} - {None})))}
    for r in rows:
        it = items.get(r["item_id"])
        r["specification"] = it.technical_specification if it else None
    return rows, head


def _check_lines(db: Session, rfq: Rfq, lines) -> None:
    item_ids = {ln.item_id for ln in lines if ln.item_id}
    if item_ids - set(db.scalars(select(Item.id).where(Item.id.in_(item_ids)))):
        raise AppError("INVALID_ITEM", "An item no longer exists.")
    pr_ids = {ln.pr_line_id for ln in lines if ln.pr_line_id}
    if pr_ids:
        found = {x.id: x for x in db.scalars(select(PurchaseRequestLine).where(PurchaseRequestLine.id.in_(pr_ids)))}
        for i, ln in enumerate(lines, start=1):
            pl = found.get(ln.pr_line_id) if ln.pr_line_id else None
            if ln.pr_line_id and (pl is None or pl.request_id != rfq.purchase_request_id):
                raise AppError("INVALID_PR_LINE", f"Line {i}: not a line of the purchase request this RFQ is for.")
    mr_ids = {ln.mr_line_id for ln in lines if ln.mr_line_id}
    if mr_ids and len(set(db.scalars(select(MaterialRequestLine.id).where(MaterialRequestLine.id.in_(mr_ids))))) != len(mr_ids):
        raise AppError("INVALID_MR_LINE", "A material request line no longer exists.")


def _set_lines(db: Session, p: Principal, rfq: Rfq, lines) -> None:
    _check_lines(db, rfq, lines)
    existing = {ln.id: ln for ln in rfq.lines}
    keep = set()
    for i, ln in enumerate(lines, start=1):
        row = existing.get(ln.id) if ln.id else None
        if ln.id and row is None:
            raise AppError("INVALID_LINE", f"Line {i} is not on this RFQ.")
        if row is None:
            row = RfqLine(rfq_id=rfq.id, created_by=p.id)
            rfq.lines.append(row)
        keep.add(row.id)
        row.line_no, row.item_id, row.description = i, ln.item_id, ln.description.strip()
        row.specification, row.unit, row.quantity = ln.specification, ln.unit.strip().upper(), round_qty(ln.quantity)
        row.required_by, row.pr_line_id, row.mr_line_id = ln.required_by, ln.pr_line_id, ln.mr_line_id
        row.remarks, row.updated_by = ln.remarks, p.id
    for lid, row in existing.items():
        if lid not in keep:
            rfq.lines.remove(row)
    db.flush()
    if not rfq.lines:
        raise AppError("NO_LINES", "Add at least one line.")


def _fill(db: Session, p: Principal, rfq: Rfq, data, head: dict) -> None:
    prj_id = data.project_id or head.get("project_id")
    prj = db.get(Project, prj_id) if prj_id else None
    if prj_id and prj is None:
        raise NotFound("project")
    wh_id = data.warehouse_id or head.get("warehouse_id")
    wh = db.get(Warehouse, wh_id) if wh_id else None
    if wh_id and (wh is None or not wh.is_active):
        raise AppError("INVALID_WAREHOUSE", "Choose an active warehouse.")
    rfq.project_id, rfq.warehouse_id = prj.id if prj else None, wh.id if wh else None
    rfq.rfq_date = data.rfq_date or rfq.rfq_date or today()
    rfq.delivery_location = data.delivery_location or _location(db, wh, prj)
    rfq.due_date, rfq.required_by = data.due_date, data.required_by or head.get("required_by")
    rfq.contact_person = data.contact_person or _contact(db, p)
    rfq.terms, rfq.notes, rfq.compare_on, rfq.updated_by = data.terms, data.notes, data.compare_on, p.id
    if rfq.due_date and rfq.due_date < rfq.rfq_date:
        raise AppError("INVALID_DUE_DATE", "Quotes cannot be due before the RFQ date.", details={"field": "due_date"})


def _sync_suppliers(db: Session, p: Principal, rfq: Rfq, ids, new) -> None:
    wanted = []
    for sid in ids:
        wanted.append(_supplier(db, sid))
    for ns in new:
        wanted.append(quick_supplier(db, p, ns))
    wanted_ids = {s.id for s in wanted}
    for vq in list(rfq.quotations):
        if vq.supplier_id not in wanted_ids:
            if vq.status != "awaited":
                raise AppError("QUOTE_RECORDED", "A supplier whose quotation is recorded cannot be removed.")
            rfq.quotations.remove(vq)
    for s in wanted:
        _add_quotation(db, p, rfq, s)
    db.flush()


def create(db: Session, p: Principal, data) -> Rfq:
    if data.purchase_request_id and data.material_request_id:
        raise AppError("ONE_SOURCE", "An RFQ is made from a purchase request or a material request, not both.")
    src, head = _source_lines(db, data)
    rfq = Rfq(status="draft", created_by=p.id, rfq_date=data.rfq_date or today(),
              purchase_request_id=data.purchase_request_id, material_request_id=data.material_request_id)
    db.add(rfq)
    _fill(db, p, rfq, data, head)
    db.flush()
    lines = data.lines
    if not lines:
        from app.purchase.rfq_schemas import RfqLineIn

        lines = [RfqLineIn(**{k: r.get(k) for k in ("item_id", "description", "specification", "unit", "quantity",
                                                     "required_by", "pr_line_id", "mr_line_id", "remarks")})
                 for r in src]
    _set_lines(db, p, rfq, lines)
    ids = list(dict.fromkeys(list(data.supplier_ids) + list(head.get("suppliers", []))))
    _sync_suppliers(db, p, rfq, ids, data.new_suppliers)
    audit.record(db, action="create", entity_type="rfq", entity_id=rfq.id, entity_label=label(rfq),
                 summary=f"{len(rfq.lines)} lines, {len(rfq.quotations)} supplier(s)"
                         + (f" — from {head['label']}" if head.get("label") else ""))
    return rfq


def update(db: Session, p: Principal, rid: uuid.UUID, data) -> Rfq:
    rfq = get(db, rid, lock=True)
    if rfq.status not in EDITABLE:
        raise AppError("NOT_EDITABLE", "Lines and suppliers can be changed only before quotations are recorded.")
    check_row_version(rfq, data.row_version)
    _fill(db, p, rfq, data, {})
    _set_lines(db, p, rfq, data.lines)
    _sync_suppliers(db, p, rfq, data.supplier_ids, data.new_suppliers)
    audit.record(db, action="update", entity_type="rfq", entity_id=rfq.id, entity_label=label(rfq),
                 summary=f"{len(rfq.lines)} lines, {len(rfq.quotations)} supplier(s)")
    return rfq


def add_supplier(db: Session, p: Principal, rid: uuid.UUID, data) -> VendorQuotation:
    rfq = get(db, rid, lock=True)
    if rfq.status not in QUOTABLE:
        raise AppError("RFQ_CLOSED", f"This RFQ is {rfq.status}.")
    if data.supplier_id:
        sup = _supplier(db, data.supplier_id)
    elif data.new_supplier:
        sup = quick_supplier(db, p, data.new_supplier)
    else:
        raise AppError("SUPPLIER_REQUIRED", "Choose a supplier or type a new supplier's name.")
    if any(q.supplier_id == sup.id for q in rfq.quotations):
        raise AppError("DUPLICATE_SUPPLIER", f"{sup.supplier_name} is already on this RFQ.")
    vq = _add_quotation(db, p, rfq, sup, invited=rfq.status in EDITABLE)
    rfq.row_version += 1
    audit.record(db, action="update", entity_type="rfq", entity_id=rfq.id, entity_label=label(rfq),
                 summary=f"Supplier added: {sup.supplier_name}")
    return vq


def remove_quotation(db: Session, p: Principal, rid: uuid.UUID, qid: uuid.UUID) -> None:
    rfq = get(db, rid, lock=True)
    vq = get_quotation(db, rfq, qid)
    if rfq.status in ("closed", "cancelled"):
        raise AppError("RFQ_CLOSED", f"This RFQ is {rfq.status}.")
    if any(ln.selected_quotation_id == vq.id for ln in rfq.lines):
        raise AppError("QUOTE_SELECTED", "Lines are awarded to this supplier on the comparison. Change that first.")
    name = db.get(Supplier, vq.supplier_id).supplier_name
    rfq.quotations.remove(vq)
    rfq.row_version += 1
    if rfq.status == "quotes_received" and not any(q.status == "received" for q in rfq.quotations):
        rfq.status = "sent" if rfq.sent_at else "draft"
    db.flush()
    audit.record(db, action="update", entity_type="rfq", entity_id=rfq.id, entity_label=label(rfq),
                 summary=f"Supplier removed: {name}")


def decline(db: Session, p: Principal, rid: uuid.UUID, qid: uuid.UUID) -> VendorQuotation:
    """The supplier said they will not quote (or did not answer in time)."""
    rfq = get(db, rid, lock=True)
    if rfq.status not in QUOTABLE:
        raise AppError("RFQ_CLOSED", f"This RFQ is {rfq.status}.")
    vq = get_quotation(db, rfq, qid)
    if vq.status != "awaited":
        raise AppError("NOT_AWAITED", "Only a supplier whose quotation is awaited can be marked as not quoting.")
    vq.status, vq.updated_by = "declined", p.id
    vq.row_version += 1
    rfq.row_version += 1
    db.flush()
    audit.record(db, action="update", entity_type="rfq", entity_id=rfq.id, entity_label=label(rfq),
                 summary=f"{db.get(Supplier, vq.supplier_id).supplier_name} did not quote")
    return vq


def send(db: Session, p: Principal, rid: uuid.UUID, row_version: int | None) -> Rfq:
    rfq = get(db, rid, lock=True)
    if rfq.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft RFQ can be marked as sent.")
    if not rfq.quotations:
        raise AppError("NO_SUPPLIERS", "Add at least one supplier before sending.")
    check_row_version(rfq, row_version)
    ensure_number(db, p, rfq)
    rfq.status, rfq.sent_at, rfq.updated_by = "sent", now(), p.id
    db.flush()
    names = ", ".join(db.get(Supplier, q.supplier_id).supplier_name for q in rfq.quotations)
    audit.record(db, action="send", entity_type="rfq", entity_id=rfq.id, entity_label=rfq.rfq_number,
                 summary=f"Sent to {names}")
    return rfq


def cancel(db: Session, p: Principal, rid: uuid.UUID, reason: str | None, row_version: int | None) -> Rfq:
    rfq = get(db, rid, lock=True)
    if rfq.status in ("closed", "cancelled"):
        raise AppError("RFQ_CLOSED", f"This RFQ is already {rfq.status}.")
    if not reason:
        raise AppError("REASON_REQUIRED", "Give the reason.", details={"field": "reason"})
    check_row_version(rfq, row_version)
    rfq.status, rfq.status_reason, rfq.updated_by = "cancelled", reason, p.id
    db.flush()
    audit.record(db, action="cancel", entity_type="rfq", entity_id=rfq.id, entity_label=label(rfq), summary=reason)
    return rfq


def delete(db: Session, p: Principal, rid: uuid.UUID) -> None:
    rfq = get(db, rid, lock=True)
    if rfq.rfq_number is not None:
        raise AppError("NUMBERED", "An RFQ that has been sent or printed is kept for the record. Cancel it instead.")
    db.delete(rfq)
    db.flush()
    audit.record(db, action="delete", entity_type="rfq", entity_id=rid, entity_label="Draft RFQ")


def list_rfqs(db: Session, params: ListParams, *, status=None, purchase_request_id=None, material_request_id=None,
              project_id=None, open_only=False):
    stmt = select(Rfq)
    if status:
        stmt = stmt.where(Rfq.status == status)
    if open_only:
        stmt = stmt.where(Rfq.status.in_(QUOTABLE))
    for col, v in ((Rfq.purchase_request_id, purchase_request_id), (Rfq.material_request_id, material_request_id),
                   (Rfq.project_id, project_id)):
        if v:
            stmt = stmt.where(col == v)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(
            Rfq.rfq_number.ilike(like), Rfq.notes.ilike(like),
            Rfq.id.in_(select(RfqLine.rfq_id).where(RfqLine.description.ilike(like))),
            Rfq.id.in_(select(VendorQuotation.rfq_id).join(Supplier, Supplier.id == VendorQuotation.supplier_id)
                       .where(Supplier.supplier_name.ilike(like))),
            Rfq.purchase_request_id.in_(select(PurchaseRequest.id).where(PurchaseRequest.pr_number.ilike(like))),
            Rfq.material_request_id.in_(select(MaterialRequest.id).where(MaterialRequest.mr_number.ilike(like)))))
    return paginate(db, stmt, params, default_sort=Rfq.created_at.desc(), sortable={
        "rfq_date": Rfq.rfq_date, "due_date": Rfq.due_date, "status": Rfq.status, "created_at": Rfq.created_at})


# ------------------------------------------------------------------ quotations
def calc_line(qty: Decimal, rate: Decimal | None, disc: Decimal, gst: Decimal, inclusive: bool) -> dict:
    """amount = qty × rate; less discount %; GST added on top (or, for GST-inclusive rates, taken out of it)."""
    if rate is None:
        return {"net_rate": Z, "taxable": Z, "gst_amount": Z, "total": Z}
    amount = round_amount(qty * rate)
    net = amount - round_amount(amount * disc / HUNDRED)
    if inclusive:
        taxable = round_amount(net * HUNDRED / (HUNDRED + gst))
        tax = net - taxable
    else:
        taxable = net
        tax = round_amount(taxable * gst / HUNDRED)
    return {"net_rate": round_rate(taxable / qty) if qty else Z, "taxable": taxable, "gst_amount": tax,
            "total": taxable + tax}


def save_quotation(db: Session, p: Principal, rid: uuid.UUID, qid: uuid.UUID, data) -> VendorQuotation:
    rfq = get(db, rid, lock=True)
    if rfq.status not in QUOTABLE:
        raise AppError("RFQ_CLOSED", f"This RFQ is {rfq.status}; quotations can no longer be changed.")
    vq = get_quotation(db, rfq, qid)
    if data.row_version is not None:
        check_row_version(vq, data.row_version)
    else:
        vq.row_version += 1
    rfq_lines = {ln.id: ln for ln in rfq.lines}
    allowed = L.gst_rates(db)
    seen = set()
    for i, ln in enumerate(data.lines, start=1):
        rl = rfq_lines.get(ln.rfq_line_id)
        if rl is None:
            raise AppError("INVALID_LINE", f"Row {i}: not a line of this RFQ.", details={"row": i})
        if rl.id in seen:
            raise AppError("DUPLICATE_LINE", f"RFQ line {rl.line_no} appears twice.", details={"row": i})
        seen.add(rl.id)
        if not ln.not_quoted and ln.unit_rate is not None and allowed and ln.gst_pct.normalize() not in allowed:
            raise AppError("INVALID_GST_RATE", f"RFQ line {rl.line_no}: GST {ln.gst_pct.normalize():f} % is not in the "
                                               "GST rate master.", details={"line": rl.line_no,
                                                                            "allowed": sorted(str(r) for r in allowed)})
    if not any(not ln.not_quoted and ln.unit_rate is not None for ln in data.lines):
        raise AppError("NO_RATES", "Enter a rate on at least one line (or mark the supplier as not quoting).")
    for k in ("quote_ref", "quote_date", "valid_until", "payment_terms", "delivery_period", "freight_included",
              "warranty", "gst_inclusive", "notes", "source"):
        setattr(vq, k, getattr(data, k))
    vq.freight_amount = Z if data.freight_included else round_amount(data.freight_amount)
    existing = {x.rfq_line_id: x for x in vq.lines}
    given = {ln.rfq_line_id: ln for ln in data.lines}
    taxable = tax = Z
    for rl in rfq.lines:
        ln = given.get(rl.id)
        row = existing.get(rl.id)
        if row is None:
            row = VendorQuotationLine(quotation_id=vq.id, rfq_line_id=rl.id, created_by=p.id)
            vq.lines.append(row)
        nq = ln is None or ln.not_quoted or ln.unit_rate is None
        rate = None if nq else round_rate(ln.unit_rate)
        disc = Z if nq else ln.discount_pct
        gst = ln.gst_pct if ln is not None else Decimal("18")
        c = calc_line(rl.quantity, rate, disc, gst, vq.gst_inclusive)
        row.not_quoted, row.unit_rate, row.discount_pct, row.gst_pct = nq, rate, disc, gst
        row.make = ln.make if ln else None
        row.delivery_days = ln.delivery_days if ln else None
        row.remarks = ln.remarks if ln else None
        row.net_rate, row.taxable, row.gst_amount, row.total = c["net_rate"], c["taxable"], c["gst_amount"], c["total"]
        row.updated_by = p.id
        taxable += c["taxable"]
        tax += c["gst_amount"]
    vq.taxable, vq.gst = taxable, tax
    vq.grand_total = taxable + tax + vq.freight_amount
    first = vq.status != "received"
    vq.status, vq.received_at, vq.updated_by = "received", vq.received_at or now(), p.id
    # a line this supplier no longer quotes cannot stay awarded to them
    now_quoted = {x.rfq_line_id for x in vq.lines if not x.not_quoted}
    for rl in rfq.lines:
        if rl.selected_quotation_id == vq.id and rl.id not in now_quoted:
            rl.selected_quotation_id = None
    if rfq.status in ("draft", "sent", "compared"):
        rfq.status = "quotes_received"
    ensure_number(db, p, rfq)
    rfq.row_version += 1
    db.flush()
    sup = db.get(Supplier, vq.supplier_id)
    audit.record(db, action="quotation", entity_type="rfq", entity_id=rfq.id, entity_label=rfq.rfq_number,
                 summary=f"{'Recorded' if first else 'Updated'} quotation of {sup.supplier_name}"
                         f" ({data.source}): ₹{vq.grand_total}")
    return vq


# ------------------------------------------------------------------ comparison
def last_prices(db: Session, item_ids, exclude_po_ids=()) -> dict:
    """The most recent ordered rate (net of discount, before GST) for each item, from earlier purchase orders."""
    ids = {i for i in item_ids if i}
    if not ids:
        return {}
    stmt = (select(PurchaseOrderItem.item_id, PurchaseOrderItem.taxable, PurchaseOrderItem.quantity,
                   PurchaseOrder.id, PurchaseOrder.po_number, PurchaseOrder.po_date, Supplier.supplier_name)
            .join(PurchaseOrder, PurchaseOrder.id == PurchaseOrderItem.purchase_order_id)
            .join(Supplier, Supplier.id == PurchaseOrder.supplier_id)
            .where(PurchaseOrderItem.item_id.in_(ids), PurchaseOrder.status.not_in(("draft", "cancelled")),
                   PurchaseOrderItem.quantity > 0)
            .order_by(PurchaseOrder.po_date.desc(), PurchaseOrder.created_at.desc()))
    out: dict = {}
    for item_id, taxable, qty, po_id, number, d, name in db.execute(stmt):
        if item_id in out or po_id in exclude_po_ids:
            continue
        out[item_id] = {"rate": round_rate(taxable / qty), "po_number": number, "po_date": d, "supplier": name}
    return out


def comparison(db: Session, rfq: Rfq) -> dict:
    """Lines × suppliers. L1 = lowest per line (on value before GST, or including GST, as the RFQ says) and lowest
    total among suppliers that quoted every line."""
    received = [q for q in rfq.quotations if q.status == "received"]
    sups = {s.id: s for s in db.scalars(select(Supplier).where(Supplier.id.in_({q.supplier_id for q in rfq.quotations})))} \
        if rfq.quotations else {}
    net = rfq.compare_on == "net"
    po_ids = {q.purchase_order_id for q in rfq.quotations if q.purchase_order_id}
    last = last_prices(db, [ln.item_id for ln in rfq.lines], po_ids)
    codes = dict(db.execute(select(Item.id, Item.item_code).where(
        Item.id.in_({ln.item_id for ln in rfq.lines} - {None}))).all()) if rfq.lines else {}
    by_q = {q.id: {x.rfq_line_id: x for x in q.lines} for q in received}

    lines = []
    for ln in rfq.lines:
        cells = {}
        for q in received:
            x = by_q[q.id].get(ln.id)
            if x is None or x.not_quoted:
                cells[q.id] = None
                continue
            cells[q.id] = x
        values = {qid: (x.taxable if net else x.total) for qid, x in cells.items() if x is not None}
        low = min(values.values()) if values else None
        l1 = [qid for qid, v in values.items() if v == low]
        selected = ln.selected_quotation_id if cells.get(ln.selected_quotation_id) is not None else None
        saved = ln.selected_quotation_id is not None or ln.selection_remark is not None or rfq.status in ("compared", "closed")
        default = selected if saved else (l1[0] if l1 else None)
        lp = last.get(ln.item_id)
        chosen = cells.get(default) if default else None
        savings = round_amount((lp["rate"] - chosen.net_rate) * ln.quantity) if lp and chosen else None
        lines.append({
            "line": ln, "cells": cells, "l1": l1, "l1_value": low, "selected": default, "saved": saved,
            "last": lp, "item_code": codes.get(ln.item_id), "savings": savings,
            "chosen_value": (chosen.taxable if net else chosen.total) if chosen else None})

    totals = []
    for q in received:
        quoted = sum(1 for row in lines if row["cells"].get(q.id) is not None)
        basis = q.taxable + q.freight_amount if net else q.grand_total
        sel_lines = [row for row in lines if row["selected"] == q.id]
        sel_taxable = sum((row["cells"][q.id].taxable for row in sel_lines), Z)
        sel_gst = sum((row["cells"][q.id].gst_amount for row in sel_lines), Z)
        totals.append({"q": q, "supplier": sups.get(q.supplier_id), "quoted": quoted, "complete": quoted == len(lines),
                       "basis": basis, "selected_lines": len(sel_lines), "selected_taxable": sel_taxable,
                       "selected_gst": sel_gst, "selected_freight": q.freight_amount if sel_lines else Z})
    pool = [t for t in totals if t["complete"]] or totals
    ranked = sorted(pool, key=lambda t: t["basis"])
    for n, t in enumerate(ranked, start=1):
        t["rank"] = n
    for t in totals:
        t.setdefault("rank", None)
    sel_value = sum(((t["selected_taxable"] + t["selected_freight"]) if net
                     else (t["selected_taxable"] + t["selected_gst"] + t["selected_freight"]) for t in totals), Z)
    return {"lines": lines, "totals": totals, "awaited": [q for q in rfq.quotations if q.status != "received"],
            "suppliers": sups, "selected_value": sel_value,
            "l1_value": sum((row["l1_value"] for row in lines if row["l1_value"] is not None), Z),
            "savings": sum((row["savings"] for row in lines if row["savings"] is not None), Z),
            "net": net}


def save_selection(db: Session, p: Principal, rid: uuid.UUID, data) -> Rfq:
    rfq = get(db, rid, lock=True)
    if rfq.status not in ("quotes_received", "compared"):
        raise AppError("NO_QUOTES" if rfq.status in EDITABLE else "RFQ_CLOSED",
                       "Record at least one quotation first." if rfq.status in EDITABLE else f"This RFQ is {rfq.status}.")
    if data.row_version is not None:
        check_row_version(rfq, data.row_version)
    else:
        rfq.row_version += 1
    cmp = comparison(db, rfq)
    rows = {row["line"].id: row for row in cmp["lines"]}
    given = {x.rfq_line_id: x for x in data.lines}
    if set(given) - set(rows):
        raise AppError("INVALID_LINE", "A line is not on this RFQ.")
    for lid, row in rows.items():
        ln = row["line"]
        x = given.get(lid)
        if x is None:
            continue
        if x.quotation_id is not None:
            if row["cells"].get(x.quotation_id) is None:
                raise AppError("NOT_QUOTED", f"Line {ln.line_no}: that supplier has not quoted this line.",
                               details={"line": ln.line_no})
            if x.quotation_id not in row["l1"] and not x.remark:
                raise AppError("REMARK_REQUIRED", f"Line {ln.line_no}: say why the lowest (L1) quotation is not chosen.",
                               details={"line": ln.line_no, "field": "remark"})
        ln.selected_quotation_id, ln.selection_remark, ln.updated_by = x.quotation_id, x.remark, p.id
    if not any(ln.selected_quotation_id for ln in rfq.lines):
        raise AppError("NOTHING_SELECTED", "Choose a supplier for at least one line.")
    rfq.status, rfq.compared_at, rfq.updated_by = "compared", now(), p.id
    db.flush()
    chosen = {}
    for ln in rfq.lines:
        if ln.selected_quotation_id:
            chosen.setdefault(ln.selected_quotation_id, 0)
            chosen[ln.selected_quotation_id] += 1
    names = {q.id: db.get(Supplier, q.supplier_id).supplier_name for q in rfq.quotations}
    not_l1 = sum(1 for lid, row in rows.items() if rows[lid]["line"].selected_quotation_id
                 and rows[lid]["line"].selected_quotation_id not in row["l1"])
    audit.record(db, action="compare", entity_type="rfq", entity_id=rfq.id, entity_label=label(rfq),
                 summary="; ".join(f"{names[q]}: {n} line(s)" for q, n in chosen.items())
                         + (f" — {not_l1} line(s) not L1" if not_l1 else ""))
    return rfq


def _default_warehouse(db: Session) -> Warehouse | None:
    return db.scalar(select(Warehouse).where(Warehouse.is_active.is_(True), Warehouse.warehouse_type == "main")
                     .order_by(Warehouse.code))


def create_orders(db: Session, p: Principal, rid: uuid.UUID, data) -> list[PurchaseOrder]:
    if not p.can("purchase_order.create"):
        raise Forbidden("You cannot create purchase orders.")
    rfq = get(db, rid, lock=True)
    if rfq.status != "compared":
        raise AppError("NOT_COMPARED", "Save the supplier choice on the comparison first."
                       if rfq.status == "quotes_received" else f"This RFQ is {rfq.status.replace('_', ' ')}.")
    if data.row_version is not None:
        check_row_version(rfq, data.row_version)
    wh = db.get(Warehouse, data.warehouse_id) if data.warehouse_id else \
        (db.get(Warehouse, rfq.warehouse_id) if rfq.warehouse_id else _default_warehouse(db))
    if wh is None:
        raise AppError("WAREHOUSE_REQUIRED", "Choose where the goods are to be delivered.", details={"field": "warehouse_id"})
    quotes = {q.id: q for q in rfq.quotations if q.status == "received"}
    groups: dict[uuid.UUID, list[RfqLine]] = {}
    for ln in rfq.lines:
        if ln.selected_quotation_id in quotes:
            groups.setdefault(ln.selected_quotation_id, []).append(ln)
    if not groups:
        raise AppError("NOTHING_SELECTED", "Choose a supplier for at least one line.")
    items = {i.id: i for i in db.scalars(select(Item).where(Item.id.in_({ln.item_id for ln in rfq.lines} - {None})))}
    pos = []
    for qid, chosen in groups.items():
        q = quotes[qid]
        qlines = {x.rfq_line_id: x for x in q.lines}
        po_lines = []
        for ln in chosen:
            x = qlines[ln.id]
            rate = x.unit_rate if not q.gst_inclusive else round_rate(x.unit_rate * HUNDRED / (HUNDRED + x.gst_pct))
            it = items.get(ln.item_id)
            remarks = " · ".join(v for v in (f"Make: {x.make}" if x.make else None, x.remarks) if v) or None
            po_lines.append(PoLineIn(
                item_id=ln.item_id, description=ln.description, technical_specification=ln.specification,
                hsn_sac=it.hsn_sac if it else None, quantity=ln.quantity, unit=ln.unit, rate=rate,
                discount_pct=x.discount_pct, tax_rate=x.gst_pct, remarks=remarks[:500] if remarks else None,
                pr_line_id=ln.pr_line_id))
        if q.freight_amount > 0:
            po_lines.append(PoLineIn(description="Freight / transportation charges", hsn_sac="9965", quantity=Decimal(1),
                                     unit="LOT", rate=q.freight_amount, tax_rate=max(x.tax_rate for x in po_lines)))
        ref = " dated ".join(v for v in (q.quote_ref, q.quote_date.strftime("%d %b %Y") if q.quote_date else None) if v)
        freight = "Freight included" if q.freight_included else f"Freight extra: ₹{q.freight_amount}"
        po = purchase.create_po(db, p, PurchaseOrderIn(
            supplier_id=q.supplier_id, project_id=rfq.project_id, warehouse_id=wh.id,
            delivery_address=rfq.delivery_location if rfq.warehouse_id is None or rfq.warehouse_id == wh.id else None,
            expected_delivery=data.expected_delivery or rfq.required_by, supplier_quote_ref=(ref or None) and ref[:100],
            payment_terms=q.payment_terms, warranty=q.warranty,
            delivery_terms=" · ".join(v for v in (q.delivery_period, freight) if v),
            notes=f"Against {rfq.rfq_number} (comparison of {len(quotes)} quotation(s))."[:2000],
            items=po_lines))
        q.purchase_order_id = po.id
        pos.append(po)
    rfq.status, rfq.closed_at, rfq.updated_by = "closed", now(), p.id
    db.flush()
    audit.record(db, action="close", entity_type="rfq", entity_id=rfq.id, entity_label=label(rfq),
                 summary=f"{len(pos)} draft purchase order(s) created")
    return pos
