"""Procurement (Spec §19): material request → purchase request → approval → purchase order → GRN.

- A **material request** is the site's or store's "we need this" (often for a project BOQ line).
- A **purchase request** is the purchase department's request to buy — built from material requests or directly —
  and needs approval.
- A **purchase order** goes to one supplier, with GST like any priced document, and needs approval above the limit.
- A **GRN** (goods received note) records what actually arrived: accepted quantities enter stock at the PO's net
  rate; rejected quantities are recorded with the reason and stay pending on the PO. Only a GRN moves purchased stock.
"""
import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.boq.models import LineColumns
from app.core.models import AuditColumnsMixin, Base
from app.core.money import AMOUNT, QTY, RATE

MR_STATUSES = ("draft", "submitted", "in_progress", "closed", "rejected", "cancelled")
PR_STATUSES = ("draft", "pending_approval", "approved", "partially_ordered", "ordered", "closed", "cancelled")
PO_STATUSES = ("draft", "pending_approval", "approved", "sent", "partially_received", "received", "closed", "cancelled")
PRIORITIES = ("low", "normal", "high", "urgent")
Z = Decimal("0")


def _in(col: str, values: tuple[str, ...]) -> str:
    return f"{col} in ({', '.join(repr(v) for v in values)})"


class MaterialRequest(AuditColumnsMixin, Base):
    __tablename__ = "material_requests"
    __table_args__ = (CheckConstraint(_in("status", MR_STATUSES), name="status_valid"),
                      CheckConstraint(_in("priority", PRIORITIES), name="priority_valid"),
                      Index("ix_material_requests_status", "status"), Index("ix_material_requests_project", "project_id"))

    mr_number: Mapped[str | None] = mapped_column(String(30), unique=True)
    request_date: Mapped[date] = mapped_column(Date, nullable=False)
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"))
    warehouse_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("warehouses.id", ondelete="RESTRICT"))
    required_by: Mapped[date | None] = mapped_column(Date)
    priority: Mapped[str] = mapped_column(String(10), nullable=False, default="normal", server_default="normal")
    purpose: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="draft", server_default="draft")
    status_reason: Mapped[str | None] = mapped_column(String(500))
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    lines: Mapped[list["MaterialRequestLine"]] = relationship(order_by="MaterialRequestLine.line_no",
                                                              cascade="all, delete-orphan", lazy="selectin")


class MaterialRequestLine(AuditColumnsMixin, Base):
    __tablename__ = "material_request_lines"
    __table_args__ = (CheckConstraint("quantity > 0", name="qty_positive"),
                      CheckConstraint("processed_qty >= 0", name="processed_nonneg"))

    request_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("material_requests.id", ondelete="CASCADE"), nullable=False,
                                                  index=True)
    line_no: Mapped[int] = mapped_column(Integer, nullable=False)
    item_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("items.id", ondelete="RESTRICT"))
    description: Mapped[str] = mapped_column(Text, nullable=False)
    unit: Mapped[str] = mapped_column(String(20), nullable=False)
    quantity: Mapped[Decimal] = mapped_column(QTY, nullable=False)
    project_boq_line_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("project_boq_lines.id", ondelete="SET NULL"))
    processed_qty: Mapped[Decimal] = mapped_column(QTY, nullable=False, default=Z, server_default="0")  # on PRs
    remarks: Mapped[str | None] = mapped_column(String(500))


class PurchaseRequest(AuditColumnsMixin, Base):
    __tablename__ = "purchase_requests"
    __table_args__ = (CheckConstraint(_in("status", PR_STATUSES), name="status_valid"),
                      CheckConstraint(_in("priority", PRIORITIES), name="priority_valid"),
                      Index("ix_purchase_requests_status", "status"))

    pr_number: Mapped[str | None] = mapped_column(String(30), unique=True)
    pr_date: Mapped[date] = mapped_column(Date, nullable=False)
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"))
    warehouse_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("warehouses.id", ondelete="RESTRICT"))
    required_by: Mapped[date | None] = mapped_column(Date)
    priority: Mapped[str] = mapped_column(String(10), nullable=False, default="normal", server_default="normal")
    notes: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="draft", server_default="draft")
    status_reason: Mapped[str | None] = mapped_column(String(500))
    estimated_value: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    last_rejection: Mapped[str | None] = mapped_column(String(500))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    lines: Mapped[list["PurchaseRequestLine"]] = relationship(order_by="PurchaseRequestLine.line_no",
                                                              cascade="all, delete-orphan", lazy="selectin")


class PurchaseRequestLine(AuditColumnsMixin, Base):
    __tablename__ = "purchase_request_lines"
    __table_args__ = (CheckConstraint("quantity > 0", name="qty_positive"),
                      CheckConstraint("ordered_qty >= 0", name="ordered_nonneg"),
                      Index("ix_purchase_request_lines_mr_line", "mr_line_id"))

    request_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("purchase_requests.id", ondelete="CASCADE"), nullable=False,
                                                  index=True)
    line_no: Mapped[int] = mapped_column(Integer, nullable=False)
    item_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("items.id", ondelete="RESTRICT"))
    description: Mapped[str] = mapped_column(Text, nullable=False)
    unit: Mapped[str] = mapped_column(String(20), nullable=False)
    quantity: Mapped[Decimal] = mapped_column(QTY, nullable=False)
    estimated_rate: Mapped[Decimal] = mapped_column(RATE, nullable=False, default=Z, server_default="0")
    estimated_amount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    mr_line_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("material_request_lines.id", ondelete="SET NULL"))
    project_boq_line_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("project_boq_lines.id", ondelete="SET NULL"))
    suggested_supplier_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("suppliers.id", ondelete="SET NULL"))
    ordered_qty: Mapped[Decimal] = mapped_column(QTY, nullable=False, default=Z, server_default="0")  # on POs
    remarks: Mapped[str | None] = mapped_column(String(500))


class PurchaseOrder(AuditColumnsMixin, Base):
    __tablename__ = "purchase_orders"
    __table_args__ = (CheckConstraint(_in("status", PO_STATUSES), name="status_valid"),
                      Index("ix_purchase_orders_status", "status"), Index("ix_purchase_orders_supplier", "supplier_id"),
                      Index("ix_purchase_orders_project", "project_id"))

    po_number: Mapped[str | None] = mapped_column(String(30), unique=True)
    po_date: Mapped[date] = mapped_column(Date, nullable=False)
    supplier_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("suppliers.id", ondelete="RESTRICT"), nullable=False)
    contact_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("supplier_contacts.id", ondelete="SET NULL"))
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"))
    warehouse_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("warehouses.id", ondelete="RESTRICT"), nullable=False)
    delivery_address: Mapped[str | None] = mapped_column(Text)
    expected_delivery: Mapped[date | None] = mapped_column(Date)
    supplier_quote_ref: Mapped[str | None] = mapped_column(String(100))
    payment_terms: Mapped[str | None] = mapped_column(Text)
    delivery_terms: Mapped[str | None] = mapped_column(Text)
    warranty: Mapped[str | None] = mapped_column(Text)
    terms: Mapped[list] = mapped_column(JSONB, nullable=False, default=list, server_default="[]")
    notes: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="draft", server_default="draft")
    status_reason: Mapped[str | None] = mapped_column(String(500))
    last_rejection: Mapped[str | None] = mapped_column(String(500))
    place_of_supply: Mapped[str | None] = mapped_column(String(2))
    inter_state: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    special_discount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    gross: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    line_discount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    taxable: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    cgst: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    sgst: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    igst: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    round_off: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    grand_total: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    items: Mapped[list["PurchaseOrderItem"]] = relationship(order_by="PurchaseOrderItem.line_no",
                                                            cascade="all, delete-orphan", lazy="selectin")


class PurchaseOrderItem(AuditColumnsMixin, LineColumns, Base):
    __tablename__ = "purchase_order_items"
    __table_args__ = (CheckConstraint("received_qty >= 0 and rejected_qty >= 0", name="received_nonneg"),
                      CheckConstraint("received_qty <= quantity", name="not_over_received"),
                      Index("ix_purchase_order_items_pr_line", "pr_line_id"))

    purchase_order_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("purchase_orders.id", ondelete="CASCADE"),
                                                         nullable=False, index=True)
    special_discount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    pr_line_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("purchase_request_lines.id", ondelete="SET NULL"))
    project_boq_line_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("project_boq_lines.id", ondelete="SET NULL"))
    received_qty: Mapped[Decimal] = mapped_column(QTY, nullable=False, default=Z, server_default="0")   # accepted
    rejected_qty: Mapped[Decimal] = mapped_column(QTY, nullable=False, default=Z, server_default="0")


class Grn(AuditColumnsMixin, Base):
    __tablename__ = "grns"
    __table_args__ = (Index("ix_grns_po", "purchase_order_id"), Index("ix_grns_supplier", "supplier_id"))

    grn_number: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    grn_date: Mapped[date] = mapped_column(Date, nullable=False)
    purchase_order_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("purchase_orders.id", ondelete="RESTRICT"),
                                                         nullable=False)
    supplier_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("suppliers.id", ondelete="RESTRICT"), nullable=False)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("warehouses.id", ondelete="RESTRICT"), nullable=False)
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"))
    supplier_invoice_no: Mapped[str | None] = mapped_column(String(60))
    supplier_invoice_date: Mapped[date | None] = mapped_column(Date)
    delivery_challan_no: Mapped[str | None] = mapped_column(String(60))
    vehicle_no: Mapped[str | None] = mapped_column(String(30))
    notes: Mapped[str | None] = mapped_column(Text)
    value: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")  # accepted, before GST

    lines: Mapped[list["GrnLine"]] = relationship(order_by="GrnLine.line_no", cascade="all, delete-orphan",
                                                  lazy="selectin")


class GrnLine(AuditColumnsMixin, Base):
    __tablename__ = "grn_lines"
    __table_args__ = (CheckConstraint("accepted_qty >= 0 and rejected_qty >= 0", name="qty_nonneg"),
                      CheckConstraint("received_qty = accepted_qty + rejected_qty", name="received_split"),
                      CheckConstraint("received_qty > 0", name="received_positive"))

    grn_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("grns.id", ondelete="CASCADE"), nullable=False, index=True)
    line_no: Mapped[int] = mapped_column(Integer, nullable=False)
    po_line_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("purchase_order_items.id", ondelete="RESTRICT"),
                                                  nullable=False, index=True)
    item_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("items.id", ondelete="RESTRICT"))
    description: Mapped[str] = mapped_column(Text, nullable=False)
    unit: Mapped[str] = mapped_column(String(20), nullable=False)
    ordered_qty: Mapped[Decimal] = mapped_column(QTY, nullable=False)
    received_qty: Mapped[Decimal] = mapped_column(QTY, nullable=False)
    accepted_qty: Mapped[Decimal] = mapped_column(QTY, nullable=False)
    rejected_qty: Mapped[Decimal] = mapped_column(QTY, nullable=False, default=Z, server_default="0")
    rejection_reason: Mapped[str | None] = mapped_column(String(300))
    batch_no: Mapped[str | None] = mapped_column(String(60))
    expiry_date: Mapped[date | None] = mapped_column(Date)
    serial_nos: Mapped[list] = mapped_column(JSONB, nullable=False, default=list, server_default="[]")
    unit_cost: Mapped[Decimal] = mapped_column(RATE, nullable=False)
    value: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False)
    stocked: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
