import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import Field, model_validator

from app.boq.lines import LineIn
from app.core.api import Schema
from app.core.validators import Text

Priority = Literal["low", "normal", "high", "urgent"]
PosQty = Field(gt=0, max_digits=18, decimal_places=3)


class MrLineIn(Schema):
    item_id: uuid.UUID | None = None
    description: str = Field(min_length=1, max_length=2000)
    unit: str = Field(min_length=1, max_length=20)
    quantity: Decimal = PosQty
    project_boq_line_id: uuid.UUID | None = None
    remarks: Text(500) = None


class MaterialRequestIn(Schema):
    request_date: date | None = None
    project_id: uuid.UUID | None = None
    warehouse_id: uuid.UUID | None = None
    required_by: date | None = None
    priority: Priority = "normal"
    purpose: Text(2000) = None
    lines: list[MrLineIn] = Field(min_length=1, max_length=300)


class MaterialRequestUpdate(MaterialRequestIn):
    row_version: int


class ReasonIn(Schema):
    reason: Text(500) = None
    row_version: int | None = None


class PrLineIn(Schema):
    item_id: uuid.UUID | None = None
    description: str = Field(min_length=1, max_length=2000)
    unit: str = Field(min_length=1, max_length=20)
    quantity: Decimal = PosQty
    estimated_rate: Decimal = Field(default=Decimal("0"), ge=0, max_digits=18, decimal_places=4)
    mr_line_id: uuid.UUID | None = None
    project_boq_line_id: uuid.UUID | None = None
    suggested_supplier_id: uuid.UUID | None = None
    remarks: Text(500) = None


class PurchaseRequestIn(Schema):
    pr_date: date | None = None
    project_id: uuid.UUID | None = None
    warehouse_id: uuid.UUID | None = None
    required_by: date | None = None
    priority: Priority = "normal"
    notes: Text(2000) = None
    lines: list[PrLineIn] = Field(min_length=1, max_length=500)


class PurchaseRequestUpdate(PurchaseRequestIn):
    row_version: int


class PoLineIn(LineIn):
    pr_line_id: uuid.UUID | None = None
    project_boq_line_id: uuid.UUID | None = None


class PurchaseOrderIn(Schema):
    po_date: date | None = None
    supplier_id: uuid.UUID
    contact_id: uuid.UUID | None = None
    project_id: uuid.UUID | None = None
    warehouse_id: uuid.UUID
    delivery_address: Text(1000) = None
    expected_delivery: date | None = None
    supplier_quote_ref: Text(100) = None
    payment_terms: Text(2000) = None
    delivery_terms: Text(2000) = None
    warranty: Text(2000) = None
    terms: list[str] = Field(default_factory=list, max_length=40)
    notes: Text(2000) = None
    special_discount: Decimal = Field(default=Decimal("0"), ge=0, max_digits=18, decimal_places=2)
    items: list[PoLineIn] = Field(min_length=1, max_length=1000)


class PurchaseOrderUpdate(PurchaseOrderIn):
    row_version: int


class GrnLineIn(Schema):
    po_line_id: uuid.UUID
    accepted_qty: Decimal = Field(default=Decimal("0"), ge=0, max_digits=18, decimal_places=3)
    rejected_qty: Decimal = Field(default=Decimal("0"), ge=0, max_digits=18, decimal_places=3)
    rejection_reason: Text(300) = None
    batch_no: Text(60) = None
    expiry_date: date | None = None
    serial_nos: list[str] = Field(default_factory=list, max_length=1000)

    @model_validator(mode="after")
    def _some(self):
        if self.rejected_qty > 0 and not self.rejection_reason:
            raise ValueError("Give the reason for the rejected quantity.")
        return self


class GrnIn(Schema):
    purchase_order_id: uuid.UUID
    grn_date: date | None = None
    warehouse_id: uuid.UUID | None = None
    supplier_invoice_no: Text(60) = None
    supplier_invoice_date: date | None = None
    delivery_challan_no: Text(60) = None
    vehicle_no: Text(30) = None
    notes: Text(2000) = None
    lines: list[GrnLineIn] = Field(min_length=1, max_length=1000)
