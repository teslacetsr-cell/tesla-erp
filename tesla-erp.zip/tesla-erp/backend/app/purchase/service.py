"""Procurement rules (Spec §19): material requests, purchase requests, purchase orders and GRNs."""
import uuid
from decimal import Decimal

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.boq import lines as L
from app.core.api import ListParams, paginate
from app.core.errors import AppError, Forbidden, NotFound
from app.core.gst import is_inter_state
from app.core.models import check_row_version
from app.core.money import round_amount, round_qty, round_rate
from app.crm.service import now, today
from app.inventory import ledger
from app.platform.approvals import service as approvals
from app.platform.audit import service as audit
from app.platform.notifications.service import notify, users_with_roles
from app.platform.numbering import service as numbering
from app.products.models import Item, Warehouse
from app.projects.models import Project, ProjectBoqLine
from app.purchase.models import (
    Grn,
    GrnLine,
    MaterialRequest,
    MaterialRequestLine,
    PurchaseOrder,
    PurchaseOrderItem,
    PurchaseRequest,
    PurchaseRequestLine,
)
from app.suppliers.models import Supplier, SupplierContact

Z = Decimal("0")
LINE_KEYS = ("line_no", "section", "item_id", "description", "technical_specification", "hsn_sac", "quantity", "unit",
             "rate", "discount_pct", "tax_rate", "amount", "discount_amount", "special_discount", "taxable", "cgst",
             "sgst", "igst", "total", "remarks")
TOTALS = ("gross", "line_discount", "taxable", "cgst", "sgst", "igst", "round_off", "grand_total")


def _q(v: Decimal) -> str:
    return f"{v.normalize():f}"


def _project(db: Session, project_id) -> Project | None:
    if not project_id:
        return None
    prj = db.get(Project, project_id)
    if prj is None:
        raise NotFound("project")
    if prj.status in ("completed", "cancelled"):
        raise AppError("PROJECT_CLOSED", f"Project {prj.project_number} is {prj.status}.")
    return prj


def _warehouse(db: Session, wid) -> Warehouse | None:
    if not wid:
        return None
    wh = db.get(Warehouse, wid)
    if wh is None or not wh.is_active:
        raise AppError("INVALID_WAREHOUSE", "Choose an active warehouse.")
    return wh


def _boq_line(db: Session, prj: Project | None, line_id, n: int) -> None:
    if not line_id:
        return
    ln = db.get(ProjectBoqLine, line_id)
    if ln is None or prj is None or ln.project_id != prj.id:
        raise AppError("INVALID_BOQ_LINE", f"Line {n}: the BOQ line is not on the chosen project.")


def _items(db: Session, ids) -> dict:
    ids = {i for i in ids if i}
    found = {i.id: i for i in db.scalars(select(Item).where(Item.id.in_(ids)))} if ids else {}
    if ids - set(found):
        raise AppError("INVALID_ITEM", "An item no longer exists.")
    return found


def _people(db: Session, roles) -> list[uuid.UUID]:
    return users_with_roles(db, roles)


# ================================================================== material requests
def mr_check(p: Principal, mr: MaterialRequest, action: str) -> None:
    scope = p.scope(f"material_request.{action}")
    if scope is None:
        raise Forbidden()
    if scope == "own" and mr.created_by != p.id:
        raise Forbidden("You can only work on your own material requests.", code="OUT_OF_SCOPE")


def mr_allowed(p: Principal, mr: MaterialRequest, action: str) -> bool:
    try:
        mr_check(p, mr, action)
        return True
    except Forbidden:
        return False


def get_mr(db: Session, mid: uuid.UUID, lock: bool = False) -> MaterialRequest:
    mr = db.get(MaterialRequest, mid, with_for_update=lock or None)
    if mr is None:
        raise NotFound("material_request")
    return mr


def _fill_mr(db: Session, p: Principal, mr: MaterialRequest, data) -> None:
    prj = _project(db, data.project_id)
    wh = _warehouse(db, data.warehouse_id)
    if wh is None and prj is not None:
        wh = db.scalar(select(Warehouse).where(Warehouse.project_id == prj.id, Warehouse.is_active.is_(True)))
    _items(db, [ln.item_id for ln in data.lines])
    for i, ln in enumerate(data.lines, start=1):
        _boq_line(db, prj, ln.project_boq_line_id, i)
    mr.request_date = data.request_date or mr.request_date or today()
    mr.project_id, mr.warehouse_id = prj.id if prj else None, wh.id if wh else None
    mr.required_by, mr.priority, mr.purpose, mr.updated_by = data.required_by, data.priority, data.purpose, p.id
    mr.lines.clear()
    db.flush()
    for i, ln in enumerate(data.lines, start=1):
        mr.lines.append(MaterialRequestLine(line_no=i, item_id=ln.item_id, description=ln.description.strip(),
                                            unit=ln.unit.strip().upper(), quantity=round_qty(ln.quantity),
                                            project_boq_line_id=ln.project_boq_line_id, remarks=ln.remarks,
                                            created_by=p.id, updated_by=p.id))


def create_mr(db: Session, p: Principal, data) -> MaterialRequest:
    mr = MaterialRequest(status="draft", created_by=p.id, request_date=data.request_date or today())
    db.add(mr)
    _fill_mr(db, p, mr, data)
    db.flush()
    audit.record(db, action="create", entity_type="material_request", entity_id=mr.id, entity_label="Draft request",
                 summary=f"{len(mr.lines)} lines")
    return mr


def update_mr(db: Session, p: Principal, mid: uuid.UUID, data) -> MaterialRequest:
    mr = get_mr(db, mid, lock=True)
    mr_check(p, mr, "update")
    if mr.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft material request can be changed.")
    check_row_version(mr, data.row_version)
    _fill_mr(db, p, mr, data)
    db.flush()
    return mr


def submit_mr(db: Session, p: Principal, mid: uuid.UUID) -> MaterialRequest:
    mr = get_mr(db, mid, lock=True)
    mr_check(p, mr, "update")
    if mr.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft can be submitted.")
    mr.mr_number = mr.mr_number or numbering.next_number(db, p.company_id, "MR", on=mr.request_date)
    mr.status, mr.submitted_at, mr.updated_by = "submitted", now(), p.id
    mr.row_version += 1
    db.flush()
    audit.record(db, action="submit", entity_type="material_request", entity_id=mr.id, entity_label=mr.mr_number,
                 summary=f"{len(mr.lines)} lines")
    prj = db.get(Project, mr.project_id) if mr.project_id else None
    notify(db, _people(db, ["STORE", "PURCHASE"]), event="material_request.submitted", exclude=p.id,
           title=f"Material request {mr.mr_number}", link=f"/purchase/material-requests/view?id={mr.id}",
           body=(f"{prj.project_number} {prj.name} · " if prj else "") + f"{len(mr.lines)} item(s)"
                + (f" · needed by {mr.required_by:%d %b}" if mr.required_by else ""))
    return mr


def _mr_status(mr: MaterialRequest) -> None:
    if mr.status not in ("submitted", "in_progress"):
        return
    done = all(ln.processed_qty >= ln.quantity for ln in mr.lines)
    started = any(ln.processed_qty > 0 for ln in mr.lines)
    mr.status = "closed" if done else "in_progress" if started else "submitted"


def mr_decision(db: Session, p: Principal, mid: uuid.UUID, action: str, reason: str | None) -> MaterialRequest:
    """reject / close (handled otherwise, e.g. from stock) / cancel (by the requester)."""
    mr = get_mr(db, mid, lock=True)
    if action == "cancel":
        mr_check(p, mr, "update")
        if mr.status not in ("draft", "submitted") or any(ln.processed_qty for ln in mr.lines):
            raise AppError("IN_PROGRESS", "Purchase has already started on this request.")
        mr.status = "cancelled"
    else:
        if not p.can("material_request.approve"):
            raise Forbidden()
        if mr.status not in ("submitted", "in_progress"):
            raise AppError("NOT_OPEN", f"This request is {mr.status.replace('_', ' ')}.")
        if not reason:
            raise AppError("REASON_REQUIRED", "Give the reason.", details={"field": "reason"})
        if action == "reject" and any(ln.processed_qty for ln in mr.lines):
            raise AppError("IN_PROGRESS", "Part of this request is already on a purchase request. Close it instead.")
        mr.status = "rejected" if action == "reject" else "closed"
    mr.status_reason, mr.updated_by = reason, p.id
    mr.row_version += 1
    db.flush()
    label = mr.mr_number or "Draft request"
    audit.record(db, action=action, entity_type="material_request", entity_id=mr.id, entity_label=label,
                 summary=reason)
    if action != "cancel":
        notify(db, [mr.created_by], event=f"material_request.{action}", exclude=p.id,
               title=f"Material request {label} {mr.status}", body=reason,
               link=f"/purchase/material-requests/view?id={mr.id}")
    return mr


def delete_mr(db: Session, p: Principal, mid: uuid.UUID) -> None:
    mr = get_mr(db, mid, lock=True)
    mr_check(p, mr, "delete")
    if mr.mr_number is not None:
        raise AppError("NUMBERED", "A submitted request is kept for the record. Cancel it instead.")
    db.delete(mr)
    db.flush()
    audit.record(db, action="delete", entity_type="material_request", entity_id=mid, entity_label="Draft request")


def list_mrs(db: Session, p: Principal, params: ListParams, *, status=None, project_id=None, open_only=False):
    stmt = select(MaterialRequest)
    scope = p.scope("material_request.read")
    if scope is None:
        raise Forbidden()
    if scope == "own":
        stmt = stmt.where(MaterialRequest.created_by == p.id)
    if status:
        stmt = stmt.where(MaterialRequest.status == status)
    if open_only:
        stmt = stmt.where(MaterialRequest.status.in_(("draft", "submitted", "in_progress")))
    if project_id:
        stmt = stmt.where(MaterialRequest.project_id == project_id)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(MaterialRequest.mr_number.ilike(like), MaterialRequest.purpose.ilike(like),
                              MaterialRequest.project_id.in_(select(Project.id).where(
                                  or_(Project.project_number.ilike(like), Project.name.ilike(like))))))
    return paginate(db, stmt, params, default_sort=MaterialRequest.created_at.desc(), sortable={
        "request_date": MaterialRequest.request_date, "required_by": MaterialRequest.required_by,
        "status": MaterialRequest.status, "created_at": MaterialRequest.created_at})


# ================================================================== purchase requests
def get_pr(db: Session, rid: uuid.UUID, lock: bool = False) -> PurchaseRequest:
    pr = db.get(PurchaseRequest, rid, with_for_update=lock or None)
    if pr is None:
        raise NotFound("purchase_request")
    return pr


def _release_mr(db: Session, pr: PurchaseRequest) -> None:
    for ln in pr.lines:
        if ln.mr_line_id:
            m = db.get(MaterialRequestLine, ln.mr_line_id, with_for_update=True)
            if m is not None:
                m.processed_qty = max(Z, m.processed_qty - ln.quantity)
                _mr_status(db.get(MaterialRequest, m.request_id))


def _fill_pr(db: Session, p: Principal, pr: PurchaseRequest, data) -> None:
    prj = _project(db, data.project_id)
    wh = _warehouse(db, data.warehouse_id)
    _items(db, [ln.item_id for ln in data.lines])
    _release_mr(db, pr)
    pr.lines.clear()
    db.flush()
    total = Z
    for i, ln in enumerate(data.lines, start=1):
        _boq_line(db, prj, ln.project_boq_line_id, i)
        boq_line = ln.project_boq_line_id
        if ln.mr_line_id:
            m = db.get(MaterialRequestLine, ln.mr_line_id, with_for_update=True)
            mr = db.get(MaterialRequest, m.request_id) if m else None
            if m is None or mr.status not in ("submitted", "in_progress"):
                raise AppError("INVALID_MR_LINE", f"Line {i}: the material request is not open.")
            left = m.quantity - m.processed_qty
            if round_qty(ln.quantity) > left:
                raise AppError("OVER_REQUEST", f"Line {i}: only {_q(left)} {m.unit} of {mr.mr_number} line "
                                               f"{m.line_no} remain to be requested.")
            m.processed_qty += round_qty(ln.quantity)
            _mr_status(mr)
            boq_line = boq_line or m.project_boq_line_id
        amount = round_amount(round_qty(ln.quantity) * ln.estimated_rate)
        total += amount
        pr.lines.append(PurchaseRequestLine(
            line_no=i, item_id=ln.item_id, description=ln.description.strip(), unit=ln.unit.strip().upper(),
            quantity=round_qty(ln.quantity), estimated_rate=round_rate(ln.estimated_rate), estimated_amount=amount,
            mr_line_id=ln.mr_line_id, project_boq_line_id=boq_line, suggested_supplier_id=ln.suggested_supplier_id,
            remarks=ln.remarks, created_by=p.id, updated_by=p.id))
    pr.pr_date = data.pr_date or pr.pr_date or today()
    pr.project_id, pr.warehouse_id = prj.id if prj else None, wh.id if wh else None
    pr.required_by, pr.priority, pr.notes, pr.updated_by = data.required_by, data.priority, data.notes, p.id
    pr.estimated_value = round_amount(total)


def create_pr(db: Session, p: Principal, data) -> PurchaseRequest:
    pr = PurchaseRequest(status="draft", created_by=p.id, pr_date=data.pr_date or today())
    db.add(pr)
    _fill_pr(db, p, pr, data)
    db.flush()
    audit.record(db, action="create", entity_type="purchase_request", entity_id=pr.id, entity_label="Draft PR",
                 summary=f"{len(pr.lines)} lines, estimated ₹{pr.estimated_value}")
    return pr


def update_pr(db: Session, p: Principal, rid: uuid.UUID, data) -> PurchaseRequest:
    pr = get_pr(db, rid, lock=True)
    if pr.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft purchase request can be changed.")
    check_row_version(pr, data.row_version)
    _fill_pr(db, p, pr, data)
    db.flush()
    return pr


def submit_pr(db: Session, p: Principal, rid: uuid.UUID, row_version: int | None) -> PurchaseRequest:
    pr = get_pr(db, rid, lock=True)
    if pr.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft can be submitted.")
    if row_version is not None:
        check_row_version(pr, row_version)
    else:
        pr.row_version += 1
    pr.pr_number = pr.pr_number or numbering.next_number(db, p.company_id, "PR", on=pr.pr_date)
    pr.last_rejection, pr.updated_by = None, p.id
    division = db.scalar(select(Project.division_id).where(Project.id == pr.project_id)) if pr.project_id else None
    req = approvals.start(db, p, entity_type="purchase_request", entity_id=pr.id, label=pr.pr_number,
                          amount=pr.estimated_value, division_id=division)
    if req is None:
        _pr_approved(db, pr)
    else:
        pr.status = "pending_approval"
    db.flush()
    audit.record(db, action="submit", entity_type="purchase_request", entity_id=pr.id, entity_label=pr.pr_number,
                 summary=f"Estimated ₹{pr.estimated_value}" + ("" if req else " — no approval rule applies, approved"))
    return pr


def _pr_approved(db: Session, pr: PurchaseRequest) -> None:
    pr.status, pr.approved_at = "approved", now()
    notify(db, _people(db, ["PURCHASE"]), event="purchase_request.approved",
           title=f"Purchase request {pr.pr_number} approved — ready to order",
           body=f"{len(pr.lines)} item(s), estimated ₹{pr.estimated_value}",
           link=f"/purchase/requests/view?id={pr.id}")


def _pr_on_approved(db: Session, p: Principal, req) -> None:
    pr = get_pr(db, req.entity_id, lock=True)
    _pr_approved(db, pr)
    pr.row_version += 1


def _pr_on_rejected(db: Session, p: Principal, req, comment: str) -> None:
    pr = get_pr(db, req.entity_id, lock=True)
    pr.status, pr.last_rejection = "draft", comment[:500]
    pr.row_version += 1


approvals.register("purchase_request", approvals.Handler(
    label="Purchase request", href=lambda i: f"/purchase/requests/view?id={i}", on_approved=_pr_on_approved,
    on_rejected=_pr_on_rejected,
    owners=lambda db, i: [x for x in [db.scalar(select(PurchaseRequest.created_by).where(PurchaseRequest.id == i))] if x]))


def _pr_status(pr: PurchaseRequest) -> None:
    if pr.status not in ("approved", "partially_ordered", "ordered"):
        return
    if all(ln.ordered_qty >= ln.quantity for ln in pr.lines):
        pr.status = "ordered"
    elif any(ln.ordered_qty > 0 for ln in pr.lines):
        pr.status = "partially_ordered"
    else:
        pr.status = "approved"


def pr_action(db: Session, p: Principal, rid: uuid.UUID, action: str, reason: str | None) -> PurchaseRequest:
    pr = get_pr(db, rid, lock=True)
    if action == "withdraw":
        if pr.status != "pending_approval":
            raise AppError("NOT_PENDING", "Only a request waiting for approval can be withdrawn.")
        approvals.withdraw(db, p, "purchase_request", pr.id)
        pr.status = "draft"
    elif action == "cancel":
        if pr.status not in ("draft", "pending_approval", "approved") or any(ln.ordered_qty for ln in pr.lines):
            raise AppError("ORDERED", "Items of this request are already on a purchase order. Close it instead.")
        approvals.withdraw(db, p, "purchase_request", pr.id)
        _release_mr(db, pr)
        pr.status = "cancelled"
    elif action == "close":
        if pr.status not in ("approved", "partially_ordered"):
            raise AppError("NOT_OPEN", "Only an approved request can be closed.")
        if not reason:
            raise AppError("REASON_REQUIRED", "Say why the rest will not be ordered.", details={"field": "reason"})
        pr.status = "closed"
    pr.status_reason = reason or pr.status_reason
    pr.updated_by = p.id
    pr.row_version += 1
    db.flush()
    audit.record(db, action=action, entity_type="purchase_request", entity_id=pr.id,
                 entity_label=pr.pr_number or "Draft PR", summary=reason)
    return pr


def delete_pr(db: Session, p: Principal, rid: uuid.UUID) -> None:
    pr = get_pr(db, rid, lock=True)
    if pr.pr_number is not None:
        raise AppError("NUMBERED", "A submitted request is kept for the record. Cancel it instead.")
    _release_mr(db, pr)
    db.delete(pr)
    db.flush()
    audit.record(db, action="delete", entity_type="purchase_request", entity_id=rid, entity_label="Draft PR")


def list_prs(db: Session, params: ListParams, *, status=None, project_id=None, open_only=False, orderable=False):
    stmt = select(PurchaseRequest)
    if status:
        stmt = stmt.where(PurchaseRequest.status == status)
    if open_only:
        stmt = stmt.where(PurchaseRequest.status.in_(("draft", "pending_approval", "approved", "partially_ordered")))
    if orderable:
        stmt = stmt.where(PurchaseRequest.status.in_(("approved", "partially_ordered")))
    if project_id:
        stmt = stmt.where(PurchaseRequest.project_id == project_id)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(PurchaseRequest.pr_number.ilike(like), PurchaseRequest.notes.ilike(like)))
    return paginate(db, stmt, params, default_sort=PurchaseRequest.created_at.desc(), sortable={
        "pr_date": PurchaseRequest.pr_date, "estimated_value": PurchaseRequest.estimated_value,
        "status": PurchaseRequest.status, "created_at": PurchaseRequest.created_at})


# ================================================================== purchase orders
def get_po(db: Session, oid: uuid.UUID, lock: bool = False) -> PurchaseOrder:
    po = db.get(PurchaseOrder, oid, with_for_update=lock or None)
    if po is None:
        raise NotFound("purchase_order")
    return po


def _release_pr(db: Session, po: PurchaseOrder) -> None:
    for it in po.items:
        if it.pr_line_id:
            ln = db.get(PurchaseRequestLine, it.pr_line_id, with_for_update=True)
            if ln is not None:
                ln.ordered_qty = max(Z, ln.ordered_qty - (it.quantity - it.received_qty))
                _pr_status(db.get(PurchaseRequest, ln.request_id))


def _fill_po(db: Session, p: Principal, po: PurchaseOrder, data) -> None:
    sup = db.get(Supplier, data.supplier_id)
    if sup is None:
        raise NotFound("supplier")
    if sup.status != "active":
        raise AppError("SUPPLIER_NOT_ACTIVE", f"{sup.supplier_name} is {sup.status}; orders cannot be placed.")
    if data.contact_id:
        c = db.get(SupplierContact, data.contact_id)
        if c is None or c.supplier_id != sup.id:
            raise AppError("INVALID_CONTACT", "The contact does not belong to this supplier.")
    prj = _project(db, data.project_id)
    wh = _warehouse(db, data.warehouse_id)
    L.validate(db, data.items)
    items = _items(db, [ln.item_id for ln in data.items])
    _release_pr(db, po)
    pos = L.company_state(db, p.company_id)
    inter = is_inter_state(pos, sup.state_code)
    rows, t = L.compute(data.items, inter_state=inter, special_discount=data.special_discount)
    po.items.clear()
    db.flush()
    for i, (ln, r) in enumerate(zip(data.items, rows, strict=True), start=1):
        _boq_line(db, prj, ln.project_boq_line_id, i)
        boq_line = ln.project_boq_line_id
        if ln.pr_line_id:
            pl = db.get(PurchaseRequestLine, ln.pr_line_id, with_for_update=True)
            pr = db.get(PurchaseRequest, pl.request_id) if pl else None
            if pl is None or pr.status not in ("approved", "partially_ordered"):
                raise AppError("PR_NOT_APPROVED", f"Line {i}: the purchase request line is not approved and open.")
            left = pl.quantity - pl.ordered_qty
            if r["quantity"] > left:
                raise AppError("OVER_ORDER", f"Line {i}: only {_q(left)} {pl.unit} of {pr.pr_number} line {pl.line_no} "
                                             "remain to be ordered.")
            pl.ordered_qty += r["quantity"]
            _pr_status(pr)
            boq_line = boq_line or pl.project_boq_line_id
        if ln.item_id and items[ln.item_id].item_type == "goods" and items[ln.item_id].serial_number_required \
                and r["quantity"] != r["quantity"].to_integral_value():
            raise AppError("SERIAL_WHOLE_QTY", f"Line {i}: serial-numbered items are ordered in whole numbers.")
        po.items.append(PurchaseOrderItem(**{k: r[k] for k in LINE_KEYS}, pr_line_id=ln.pr_line_id,
                                          project_boq_line_id=boq_line, created_by=p.id, updated_by=p.id))
    po.po_date = data.po_date or po.po_date or today()
    po.supplier_id, po.contact_id = sup.id, data.contact_id
    po.project_id, po.warehouse_id = prj.id if prj else None, wh.id
    po.delivery_address = data.delivery_address or wh.address
    for k in ("expected_delivery", "supplier_quote_ref", "delivery_terms", "warranty", "notes"):
        setattr(po, k, getattr(data, k))
    po.payment_terms = data.payment_terms or sup.payment_terms
    po.terms = [x.strip() for x in data.terms if x and x.strip()]
    po.place_of_supply, po.inter_state = pos, inter
    po.special_discount = round_amount(data.special_discount)
    for k in TOTALS:
        setattr(po, k, round_amount(getattr(t, k)))
    po.updated_by = p.id


def create_po(db: Session, p: Principal, data) -> PurchaseOrder:
    po = PurchaseOrder(status="draft", created_by=p.id, po_date=data.po_date or today(), supplier_id=data.supplier_id,
                       warehouse_id=data.warehouse_id)
    db.add(po)
    _fill_po(db, p, po, data)
    db.flush()
    audit.record(db, action="create", entity_type="purchase_order", entity_id=po.id, entity_label="Draft PO",
                 summary=f"{len(po.items)} lines, ₹{po.taxable} before GST")
    return po


def update_po(db: Session, p: Principal, oid: uuid.UUID, data) -> PurchaseOrder:
    po = get_po(db, oid, lock=True)
    if po.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft purchase order can be changed. Withdraw it first.")
    check_row_version(po, data.row_version)
    _fill_po(db, p, po, data)
    db.flush()
    return po


def submit_po(db: Session, p: Principal, oid: uuid.UUID, row_version: int | None) -> PurchaseOrder:
    po = get_po(db, oid, lock=True)
    if po.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft can be submitted.")
    if row_version is not None:
        check_row_version(po, row_version)
    else:
        po.row_version += 1
    po.po_number = po.po_number or numbering.next_number(db, p.company_id, "PO", on=po.po_date)
    po.submitted_at, po.last_rejection, po.updated_by = now(), None, p.id
    division = db.scalar(select(Project.division_id).where(Project.id == po.project_id)) if po.project_id else None
    sup = db.get(Supplier, po.supplier_id)
    req = approvals.start(db, p, entity_type="purchase_order", entity_id=po.id,
                          label=f"{po.po_number} · {sup.supplier_name}", amount=po.taxable, division_id=division)
    if req is None:
        po.status, po.approved_at = "approved", now()
    else:
        po.status = "pending_approval"
    db.flush()
    audit.record(db, action="submit", entity_type="purchase_order", entity_id=po.id, entity_label=po.po_number,
                 summary=f"₹{po.taxable} before GST" + ("" if req else " — below the approval limit, approved"))
    return po


def _po_on_approved(db: Session, p: Principal, req) -> None:
    po = get_po(db, req.entity_id, lock=True)
    po.status, po.approved_at = "approved", now()
    po.row_version += 1


def _po_on_rejected(db: Session, p: Principal, req, comment: str) -> None:
    po = get_po(db, req.entity_id, lock=True)
    po.status, po.last_rejection = "draft", comment[:500]
    po.row_version += 1


approvals.register("purchase_order", approvals.Handler(
    label="Purchase order", href=lambda i: f"/purchase/orders/view?id={i}", on_approved=_po_on_approved,
    on_rejected=_po_on_rejected,
    owners=lambda db, i: [x for x in [db.scalar(select(PurchaseOrder.created_by).where(PurchaseOrder.id == i))] if x]))


def po_action(db: Session, p: Principal, oid: uuid.UUID, action: str, reason: str | None,
              row_version: int | None = None) -> PurchaseOrder:
    po = get_po(db, oid, lock=True)
    if row_version is not None and row_version != po.row_version:
        check_row_version(po, row_version)
    received = any(it.received_qty or it.rejected_qty for it in po.items)
    before = po.status
    if action == "send":
        if po.status != "approved":
            raise AppError("NOT_APPROVED", "Only an approved purchase order can be sent.")
        po.status, po.sent_at = "sent", now()
    elif action == "withdraw":
        if po.status not in ("pending_approval", "approved"):
            raise AppError("NOT_PENDING", "Only an unsent purchase order can be withdrawn to draft.")
        approvals.withdraw(db, p, "purchase_order", po.id)
        po.status, po.approved_at = "draft", None
    elif action == "cancel":
        if po.status in ("received", "closed", "cancelled") or received:
            raise AppError("RECEIVED", "Goods were received against this order. Close it instead.")
        if not reason:
            raise AppError("REASON_REQUIRED", "Give the reason.", details={"field": "reason"})
        approvals.withdraw(db, p, "purchase_order", po.id)
        _release_pr(db, po)
        po.status = "cancelled"
    elif action == "close":
        if po.status not in ("sent", "partially_received", "approved"):
            raise AppError("NOT_OPEN", "Only an open purchase order can be short-closed.")
        if not reason:
            raise AppError("REASON_REQUIRED", "Say why the rest will not be received.", details={"field": "reason"})
        # quantities not received go back to the purchase request so they can be ordered elsewhere
        for it in po.items:
            if it.pr_line_id and it.quantity > it.received_qty:
                pl = db.get(PurchaseRequestLine, it.pr_line_id, with_for_update=True)
                if pl is not None:
                    pl.ordered_qty = max(Z, pl.ordered_qty - (it.quantity - it.received_qty))
                    _pr_status(db.get(PurchaseRequest, pl.request_id))
        po.status = "closed"
    else:
        raise AppError("INVALID_ACTION", "Unknown action.")
    po.status_reason = reason or po.status_reason
    po.updated_by = p.id
    po.row_version += 1
    db.flush()
    audit.record(db, action=action, entity_type="purchase_order", entity_id=po.id,
                 entity_label=po.po_number or "Draft PO", summary=f"{before} → {po.status}" + (f": {reason}" if reason else ""))
    return po


def delete_po(db: Session, p: Principal, oid: uuid.UUID) -> None:
    po = get_po(db, oid, lock=True)
    if po.po_number is not None:
        raise AppError("NUMBERED", "A numbered purchase order is kept for the record. Cancel it instead.")
    _release_pr(db, po)
    db.delete(po)
    db.flush()
    audit.record(db, action="delete", entity_type="purchase_order", entity_id=oid, entity_label="Draft PO")


def list_pos(db: Session, params: ListParams, *, status=None, supplier_id=None, project_id=None, open_only=False,
             receivable=False):
    stmt = select(PurchaseOrder)
    if status:
        stmt = stmt.where(PurchaseOrder.status == status)
    if open_only:
        stmt = stmt.where(PurchaseOrder.status.not_in(("received", "closed", "cancelled")))
    if receivable:
        stmt = stmt.where(PurchaseOrder.status.in_(("approved", "sent", "partially_received")))
    if supplier_id:
        stmt = stmt.where(PurchaseOrder.supplier_id == supplier_id)
    if project_id:
        stmt = stmt.where(PurchaseOrder.project_id == project_id)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(PurchaseOrder.po_number.ilike(like), PurchaseOrder.supplier_quote_ref.ilike(like),
                              PurchaseOrder.supplier_id.in_(select(Supplier.id).where(Supplier.supplier_name.ilike(like)))))
    return paginate(db, stmt, params, default_sort=PurchaseOrder.created_at.desc(), sortable={
        "po_date": PurchaseOrder.po_date, "grand_total": PurchaseOrder.grand_total, "status": PurchaseOrder.status,
        "expected_delivery": PurchaseOrder.expected_delivery, "created_at": PurchaseOrder.created_at})


# ================================================================== GRN
def get_grn(db: Session, gid: uuid.UUID) -> Grn:
    g = db.get(Grn, gid)
    if g is None:
        raise NotFound("grn")
    return g


def net_rate(it: PurchaseOrderItem) -> Decimal:
    """Stock cost per unit = the line's value before GST after every discount ÷ quantity (GST is input credit)."""
    return round_rate(it.taxable / it.quantity) if it.quantity else Z


def create_grn(db: Session, p: Principal, data) -> Grn:
    po = get_po(db, data.purchase_order_id, lock=True)
    if po.status not in ("approved", "sent", "partially_received"):
        raise AppError("PO_NOT_OPEN", f"Goods can be received only on an approved, open order (this one is "
                                      f"{po.status.replace('_', ' ')}).")
    wh = _warehouse(db, data.warehouse_id or po.warehouse_id)
    po_lines = {it.id: it for it in po.items}
    items = _items(db, [it.item_id for it in po.items])
    grn_date = data.grn_date or today()
    if grn_date > today():
        raise AppError("FUTURE_DATE", "A GRN cannot be dated in the future.")
    seen = set()
    plan = []
    for n, ln in enumerate(data.lines, start=1):
        it = po_lines.get(ln.po_line_id)
        if it is None:
            raise AppError("INVALID_PO_LINE", f"Line {n}: not a line of {po.po_number}.")
        if it.id in seen:
            raise AppError("DUPLICATE_LINE", f"Line {n}: PO line {it.line_no} appears twice.")
        seen.add(it.id)
        acc, rej = round_qty(ln.accepted_qty), round_qty(ln.rejected_qty)
        if acc + rej == 0:
            continue
        pending = it.quantity - it.received_qty
        if acc > pending:
            raise AppError("OVER_RECEIPT", f"PO line {it.line_no} ({it.description[:60]}): {_q(pending)} {it.unit} "
                                           f"pending; {_q(acc)} cannot be accepted.",
                           details={"po_line": it.line_no, "pending": str(pending)})
        item = items.get(it.item_id)
        stocked = item is not None and item.item_type == "goods"
        serials = ledger.clean_serials(ln.serial_nos)
        if stocked and acc > 0:
            ledger.check_item_rules(item, acc, ln.batch_no, serials, f"PO line {it.line_no}")
        plan.append((it, ln, acc, rej, item, stocked, serials))
    if not plan:
        raise AppError("NOTHING_RECEIVED", "Enter the quantity received on at least one line.")

    g = Grn(grn_number=numbering.next_number(db, p.company_id, "GRN", on=grn_date), grn_date=grn_date,
            purchase_order_id=po.id, supplier_id=po.supplier_id, warehouse_id=wh.id, project_id=po.project_id,
            supplier_invoice_no=data.supplier_invoice_no, supplier_invoice_date=data.supplier_invoice_date,
            delivery_challan_no=data.delivery_challan_no, vehicle_no=data.vehicle_no, notes=data.notes,
            created_by=p.id, updated_by=p.id)
    db.add(g)
    db.flush()
    total = Z
    for n, (it, ln, acc, rej, _item, stocked, serials) in enumerate(plan, start=1):
        cost = net_rate(it)
        value = round_amount(acc * cost)
        gl = GrnLine(line_no=n, po_line_id=it.id, item_id=it.item_id, description=it.description, unit=it.unit,
                     ordered_qty=it.quantity, received_qty=acc + rej, accepted_qty=acc, rejected_qty=rej,
                     rejection_reason=ln.rejection_reason if rej else None, batch_no=ln.batch_no,
                     expiry_date=ln.expiry_date, serial_nos=serials, unit_cost=cost, value=value,
                     stocked=stocked and acc > 0, created_by=p.id, updated_by=p.id)
        g.lines.append(gl)
        total += value
        it.received_qty += acc
        it.rejected_qty += rej
        if it.project_boq_line_id and acc:
            bl = db.get(ProjectBoqLine, it.project_boq_line_id, with_for_update=True)
            if bl is not None:
                bl.procured_qty += acc
    db.flush()
    # stock in, in a fixed order (by item) so concurrent receipts never deadlock
    for gl in sorted(g.lines, key=lambda x: (str(x.item_id), x.line_no)):
        if gl.stocked:
            ledger.post(db, ledger.Movement(items[gl.item_id], wh, gl.accepted_qty, unit_cost=gl.unit_cost,
                                            value=gl.value, batch_no=gl.batch_no, expiry_date=gl.expiry_date,
                                            serial_nos=tuple(gl.serial_nos), source_line_id=gl.id),
                        txn_type="grn", source_type="grn", source_id=g.id, source_number=g.grn_number,
                        txn_date=grn_date, user_id=p.id, project_id=po.project_id,
                        label=f"PO line {gl.line_no} ({items[gl.item_id].item_name})")
    g.value = round_amount(total)
    before = po.status
    po.status = "received" if all(it.received_qty >= it.quantity for it in po.items) else "partially_received"
    po.row_version += 1
    db.flush()
    rejected = sum((x.rejected_qty for x in g.lines), Z)
    audit.record(db, action="create", entity_type="grn", entity_id=g.id, entity_label=g.grn_number,
                 summary=f"{po.po_number}: {len(g.lines)} lines, ₹{g.value} accepted into {wh.name}"
                         + (f"; {_q(rejected)} rejected" if rejected else ""))
    audit.record(db, action="receipt", entity_type="purchase_order", entity_id=po.id, entity_label=po.po_number,
                 summary=f"{g.grn_number}: {before} → {po.status}")
    prj = db.get(Project, po.project_id) if po.project_id else None
    notify(db, {po.created_by, prj.project_manager_id if prj else None}, event="grn.posted", exclude=p.id,
           title=f"Goods received: {po.po_number}", link=f"/purchase/grn/view?id={g.id}",
           body=f"{g.grn_number} · {len(g.lines)} line(s) into {wh.name}" + (f" · {_q(rejected)} rejected" if rejected else ""))
    return g


def list_grns(db: Session, params: ListParams, *, purchase_order_id=None, supplier_id=None, project_id=None,
              warehouse_id=None):
    stmt = select(Grn)
    for col, v in ((Grn.purchase_order_id, purchase_order_id), (Grn.supplier_id, supplier_id),
                   (Grn.project_id, project_id), (Grn.warehouse_id, warehouse_id)):
        if v:
            stmt = stmt.where(col == v)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(Grn.grn_number.ilike(like), Grn.supplier_invoice_no.ilike(like),
                              Grn.delivery_challan_no.ilike(like),
                              Grn.purchase_order_id.in_(select(PurchaseOrder.id).where(PurchaseOrder.po_number.ilike(like)))))
    return paginate(db, stmt, params, default_sort=Grn.created_at.desc(), sortable={
        "grn_date": Grn.grn_date, "value": Grn.value, "created_at": Grn.created_at})
