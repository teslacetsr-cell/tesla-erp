"""Loads every module's permission declarations. Add new modules here."""
import app.boq.permissions  # noqa: F401
import app.company.permissions  # noqa: F401
import app.costing.permissions  # noqa: F401
import app.crm.permissions  # noqa: F401
import app.customers.permissions  # noqa: F401
import app.finance.permissions  # noqa: F401
import app.hr.permissions  # noqa: F401
import app.inventory.permissions  # noqa: F401
import app.platform.permissions  # noqa: F401
import app.products.permissions  # noqa: F401
import app.projects.permissions  # noqa: F401
import app.purchase.permissions  # noqa: F401
import app.quotations.permissions  # noqa: F401
import app.sales.permissions  # noqa: F401
import app.suppliers.permissions  # noqa: F401
import app.users.permissions  # noqa: F401
