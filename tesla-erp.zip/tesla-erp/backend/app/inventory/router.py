import uuid
from datetime import date
from decimal import Decimal
from typing import Annotated

from fastapi import APIRouter, Depends, File, Query, UploadFile
from fastapi.responses import Response
from sqlalchemy import select

from app.auth.deps import Principal, require
from app.core import excel
from app.core.api import ListParams, ok
from app.core.db import DbSession
from app.core.money import round_rate
from app.inventory import ledger, service
from app.inventory.models import StockAdjustment, StockBatch, StockSerial, StockTransaction, StockTransfer
from app.inventory.schemas import AdjustmentIn, AdjustmentUpdate, RowVersionIn, TransferIn, TransferUpdate
from app.platform.approvals import service as approvals
from app.platform.approvals.router import request_out
from app.platform.audit import service as audit
from app.products.models import Item, Warehouse
from app.users.models import User

router = APIRouter(tags=["inventory"])
ZERO = Decimal("0")


def _q(v) -> str:
    return f"{Decimal(v).normalize():f}"


def _names(db, ids) -> dict:
    ids = {i for i in ids if i}
    return dict(db.execute(select(User.id, User.full_name).where(User.id.in_(ids))).all()) if ids else {}


def _whs(db, ids) -> dict:
    ids = {i for i in ids if i}
    return {w.id: w for w in db.scalars(select(Warehouse).where(Warehouse.id.in_(ids)))} if ids else {}


def _items(db, ids) -> dict:
    ids = {i for i in ids if i}
    return {i.id: i for i in db.scalars(select(Item).where(Item.id.in_(ids)))} if ids else {}


def wh_ref(w: Warehouse | None) -> dict | None:
    return {"id": str(w.id), "code": w.code, "name": w.name, "type": w.warehouse_type,
            "project_id": str(w.project_id) if w.project_id else None} if w else None


def item_ref(i: Item | None) -> dict | None:
    return {"id": str(i.id), "code": i.item_code, "name": i.item_name, "unit": i.unit.code,
            "serial": i.serial_number_required, "batch": i.batch_required} if i else None


# ------------------------------------------------------------------ stock enquiries
def stock_row(item: Item, qty, val) -> dict:
    qty, val = Decimal(qty), Decimal(val)
    return {"item": item_ref(item), "category": item.category.name if item.category else None,
            "quantity": _q(qty), "value": str(val), "average_cost": str(round_rate(val / qty)) if qty > 0 else None,
            "minimum_stock": _q(item.minimum_stock), "reorder_level": _q(item.reorder_level),
            "status": service.stock_status(qty, item)}


@router.get("/stock/items")
def stock_items(db: DbSession, _: Annotated[Principal, require("stock.read")], params: Annotated[ListParams, Depends()],
                warehouse_id: uuid.UUID | None = None, category_id: uuid.UUID | None = None,
                status: str | None = Query(None, pattern="^(out|low|in_stock)$")):
    rows, total = service.item_stock(db, params, warehouse_id=warehouse_id, category_id=category_id, status=status)
    return {"data": [stock_row(i, q, v) for i, q, v in rows],
            "meta": {"page": params.page, "page_size": params.page_size, "total": total}}


STOCK_COLUMNS = [excel.Column("code", "Item code", 16), excel.Column("name", "Item", 40), excel.Column("category", "Category", 18),
                 excel.Column("unit", "Unit", 8), excel.Column("quantity", "Quantity", 12), excel.Column("average_cost", "Avg cost (₹)", 14),
                 excel.Column("value", "Value (₹)", 16), excel.Column("reorder_level", "Reorder level", 12),
                 excel.Column("status", "Status", 12)]


@router.get("/stock/items/export")
def export_stock(db: DbSession, _: Annotated[Principal, require("stock.export")], params: Annotated[ListParams, Depends()],
                 warehouse_id: uuid.UUID | None = None, category_id: uuid.UUID | None = None, status: str | None = None):
    params.page, params.page_size = 1, 100000
    rows, _n = service.item_stock(db, params, warehouse_id=warehouse_id, category_id=category_id, status=status)
    data = []
    for i, q, v in rows:
        r = stock_row(i, q, v)
        data.append({"code": i.item_code, "name": i.item_name, "category": r["category"], "unit": i.unit.code,
                     "quantity": Decimal(q), "average_cost": Decimal(r["average_cost"]) if r["average_cost"] else None,
                     "value": Decimal(v), "reorder_level": i.reorder_level, "status": r["status"]})
    audit.record(db, action="export", entity_type="stock", summary=f"Stock list exported ({len(data)} items)")
    return Response(excel.export("Stock", STOCK_COLUMNS, data), media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="stock.xlsx"'})


@router.get("/stock/summary")
def stock_summary(db: DbSession, _: Annotated[Principal, require("stock.read")]):
    return ok(service.low_stock_count(db))


@router.get("/stock/verify")
def stock_verify(db: DbSession, _: Annotated[Principal, require("stock.read")]):
    problems = ledger.verify(db)
    return ok({"ok": not problems, "problems": problems})


@router.get("/stock/available")
def stock_available(db: DbSession, _: Annotated[Principal, require("stock.read")], item_id: uuid.UUID,
                    warehouse_id: uuid.UUID):
    return ok({"quantity": _q(ledger.available(db, item_id, warehouse_id)),
               "average_cost": str(ledger.average_cost(db, item_id, warehouse_id) or "") or None})


@router.get("/stock/items/{item_id}")
def stock_item(item_id: uuid.UUID, db: DbSession, _: Annotated[Principal, require("stock.read")]):
    from app.inventory.models import StockBalance

    item = db.get(Item, item_id)
    if item is None:
        from app.core.errors import NotFound
        raise NotFound("item")
    bals = db.scalars(select(StockBalance).where(StockBalance.item_id == item_id)).all()
    batches = db.scalars(select(StockBatch).where(StockBatch.item_id == item_id, StockBatch.quantity != 0)
                         .order_by(StockBatch.expiry_date.nulls_last(), StockBatch.batch_no)).all()
    serials = db.scalars(select(StockSerial).where(StockSerial.item_id == item_id, StockSerial.status == "in_stock")
                         .order_by(StockSerial.serial_no).limit(500)).all()
    whs = _whs(db, [b.warehouse_id for b in bals] + [b.warehouse_id for b in batches] + [s.warehouse_id for s in serials])
    total_q = sum((b.quantity for b in bals), ZERO)
    total_v = sum((b.value for b in bals), ZERO)
    return ok({
        **stock_row(item, total_q, total_v),
        "warehouses": [{"warehouse": wh_ref(whs.get(b.warehouse_id)), "quantity": _q(b.quantity), "value": str(b.value),
                        "average_cost": str(round_rate(b.value / b.quantity)) if b.quantity > 0 else None}
                       for b in sorted(bals, key=lambda b: whs[b.warehouse_id].name) if b.quantity != 0 or b.value != 0],
        "batches": [{"batch_no": b.batch_no, "warehouse": wh_ref(whs.get(b.warehouse_id)), "quantity": _q(b.quantity),
                     "expiry_date": b.expiry_date.isoformat() if b.expiry_date else None} for b in batches],
        "serials": [{"serial_no": s.serial_no, "warehouse": wh_ref(whs.get(s.warehouse_id)), "batch_no": s.batch_no,
                     "received_via": s.received_via} for s in serials],
    })


def txn_out(t: StockTransaction, items: dict, whs: dict, names: dict) -> dict:
    return {"id": str(t.id), "seq": t.seq, "txn_date": t.txn_date.isoformat(), "posted_at": t.posted_at.isoformat(),
            "txn_type": t.txn_type, "item": item_ref(items.get(t.item_id)), "warehouse": wh_ref(whs.get(t.warehouse_id)),
            "quantity": _q(t.quantity), "unit_cost": str(t.unit_cost), "value": str(t.value),
            "balance_qty": _q(t.balance_qty), "balance_value": str(t.balance_value), "batch_no": t.batch_no,
            "serial_nos": t.serial_nos, "source_type": t.source_type, "source_id": str(t.source_id),
            "source_number": t.source_number, "project_id": str(t.project_id) if t.project_id else None,
            "remarks": t.remarks, "by": names.get(t.created_by)}


@router.get("/stock/ledger")
def stock_ledger(db: DbSession, _: Annotated[Principal, require("stock.read")], params: Annotated[ListParams, Depends()],
                 item_id: uuid.UUID | None = None, warehouse_id: uuid.UUID | None = None,
                 project_id: uuid.UUID | None = None, txn_type: str | None = None, date_from: date | None = None,
                 date_to: date | None = None):
    rows, meta = service.ledger_rows(db, params, item_id=item_id, warehouse_id=warehouse_id, project_id=project_id,
                                     txn_type=txn_type, date_from=date_from, date_to=date_to)
    items, whs, names = _items(db, [r.item_id for r in rows]), _whs(db, [r.warehouse_id for r in rows]), \
        _names(db, [r.created_by for r in rows])
    return {"data": [txn_out(r, items, whs, names) for r in rows], "meta": meta.model_dump()}


@router.get("/stock/serials")
def stock_serials(db: DbSession, _: Annotated[Principal, require("stock.read")], item_id: uuid.UUID,
                  warehouse_id: uuid.UUID | None = None, q: str | None = Query(None, max_length=80)):
    stmt = select(StockSerial).where(StockSerial.item_id == item_id, StockSerial.status == "in_stock")
    if warehouse_id:
        stmt = stmt.where(StockSerial.warehouse_id == warehouse_id)
    if q:
        stmt = stmt.where(StockSerial.serial_no.ilike(f"%{q}%"))
    return ok([s.serial_no for s in db.scalars(stmt.order_by(StockSerial.serial_no).limit(1000))])


# ------------------------------------------------------------------ transfers
def transfer_out(db, p: Principal, t: StockTransfer, detail: bool = False) -> dict:
    whs = _whs(db, [t.from_warehouse_id, t.to_warehouse_id])
    names = _names(db, [t.created_by])
    out = {"id": str(t.id), "transfer_number": t.transfer_number, "transfer_date": t.transfer_date.isoformat(),
           "status": t.status, "from_warehouse": wh_ref(whs.get(t.from_warehouse_id)),
           "to_warehouse": wh_ref(whs.get(t.to_warehouse_id)), "project_id": str(t.project_id) if t.project_id else None,
           "lines_count": len(t.lines), "created_by": names.get(t.created_by), "created_at": t.created_at.isoformat(),
           "row_version": t.row_version}
    if not detail:
        return out
    items = _items(db, [ln.item_id for ln in t.lines])
    upd = p.can("stock_transfer.update") and t.status == "draft"
    project = None
    if t.project_id:
        from app.projects.models import Project
        pr = db.get(Project, t.project_id)
        project = {"id": str(pr.id), "number": pr.project_number, "name": pr.name} if pr else None
    return out | {
        "vehicle_no": t.vehicle_no, "notes": t.notes, "posted_at": t.posted_at.isoformat() if t.posted_at else None,
        "project": project,
        "lines": [{"id": str(ln.id), "line_no": ln.line_no, "item": item_ref(items.get(ln.item_id)), "quantity": _q(ln.quantity),
                   "batch_no": ln.batch_no, "serial_nos": ln.serial_nos, "remarks": ln.remarks,
                   "unit_cost": str(ln.unit_cost) if ln.unit_cost is not None else None} for ln in t.lines],
        "can": {"edit": upd, "post": upd, "cancel": upd},
    }


@router.get("/stock-transfers")
def list_transfers(db: DbSession, p: Annotated[Principal, require("stock_transfer.read")],
                   params: Annotated[ListParams, Depends()], status: str | None = None,
                   warehouse_id: uuid.UUID | None = None, project_id: uuid.UUID | None = None):
    rows, meta = service.list_transfers(db, params, status=status, warehouse_id=warehouse_id, project_id=project_id)
    return {"data": [transfer_out(db, p, t) for t in rows], "meta": meta.model_dump()}


@router.post("/stock-transfers", status_code=201)
def create_transfer(body: TransferIn, db: DbSession, p: Annotated[Principal, require("stock_transfer.create")]):
    if body.post and not p.can("stock_transfer.update"):
        body.post = False
    return ok(transfer_out(db, p, service.create_transfer(db, p, body), detail=True))


@router.get("/stock-transfers/{tid}")
def get_transfer(tid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("stock_transfer.read")]):
    return ok(transfer_out(db, p, service.get_transfer(db, tid), detail=True))


@router.put("/stock-transfers/{tid}")
def update_transfer(tid: uuid.UUID, body: TransferUpdate, db: DbSession,
                    p: Annotated[Principal, require("stock_transfer.update")]):
    return ok(transfer_out(db, p, service.update_transfer(db, p, tid, body), detail=True))


@router.post("/stock-transfers/{tid}/post")
def post_transfer(tid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("stock_transfer.update")]):
    return ok(transfer_out(db, p, service.post_transfer(db, p, tid), detail=True))


@router.post("/stock-transfers/{tid}/cancel")
def cancel_transfer(tid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("stock_transfer.update")]):
    return ok(transfer_out(db, p, service.cancel_transfer(db, p, tid), detail=True))


# ------------------------------------------------------------------ adjustments
def adjustment_out(db, p: Principal, a: StockAdjustment, detail: bool = False) -> dict:
    whs = _whs(db, [a.warehouse_id])
    names = _names(db, [a.created_by])
    out = {"id": str(a.id), "adjustment_number": a.adjustment_number, "adjustment_date": a.adjustment_date.isoformat(),
           "status": a.status, "warehouse": wh_ref(whs.get(a.warehouse_id)), "reason_type": a.reason_type,
           "reason": a.reason, "value": str(a.value), "lines_count": len(a.lines), "created_by": names.get(a.created_by),
           "created_at": a.created_at.isoformat(), "row_version": a.row_version}
    if not detail:
        return out
    items = _items(db, [ln.item_id for ln in a.lines])
    pending = approvals.pending_for(db, "stock_adjustment", a.id)
    upd = p.can("stock_adjustment.update")
    return out | {
        "last_rejection": a.last_rejection, "posted_at": a.posted_at.isoformat() if a.posted_at else None,
        "lines": [{"id": str(ln.id), "line_no": ln.line_no, "item": item_ref(items.get(ln.item_id)), "quantity": _q(ln.quantity),
                   "unit_cost": str(ln.unit_cost) if ln.unit_cost is not None else None, "batch_no": ln.batch_no,
                   "expiry_date": ln.expiry_date.isoformat() if ln.expiry_date else None, "serial_nos": ln.serial_nos,
                   "remarks": ln.remarks} for ln in a.lines],
        "approval": request_out(db, p, pending) if pending else None,
        "approvals": [request_out(db, p, r) for r in approvals.history(db, "stock_adjustment", a.id)],
        "can": {"edit": upd and a.status == "draft", "submit": upd and a.status == "draft",
                "withdraw": upd and a.status == "pending_approval", "cancel": upd and a.status in ("draft", "pending_approval"),
                "decide": bool(pending and approvals.can_decide(p, pending))},
    }


@router.get("/stock-adjustments")
def list_adjustments(db: DbSession, p: Annotated[Principal, require("stock_adjustment.read")],
                     params: Annotated[ListParams, Depends()], status: str | None = None,
                     warehouse_id: uuid.UUID | None = None):
    rows, meta = service.list_adjustments(db, params, status=status, warehouse_id=warehouse_id)
    return {"data": [adjustment_out(db, p, a) for a in rows], "meta": meta.model_dump()}


@router.get("/stock-adjustments/template")
def adjustment_template(_: Annotated[Principal, require("stock_adjustment.create")]):
    return Response(service.adjustment_template(), media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="stock-import-template.xlsx"'})


@router.post("/stock-adjustments", status_code=201)
def create_adjustment(body: AdjustmentIn, db: DbSession, p: Annotated[Principal, require("stock_adjustment.create")]):
    return ok(adjustment_out(db, p, service.create_adjustment(db, p, body), detail=True))


@router.get("/stock-adjustments/{aid}")
def get_adjustment(aid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("stock_adjustment.read")]):
    return ok(adjustment_out(db, p, service.get_adjustment(db, aid), detail=True))


@router.put("/stock-adjustments/{aid}")
def update_adjustment(aid: uuid.UUID, body: AdjustmentUpdate, db: DbSession,
                      p: Annotated[Principal, require("stock_adjustment.update")]):
    return ok(adjustment_out(db, p, service.update_adjustment(db, p, aid, body), detail=True))


@router.post("/stock-adjustments/{aid}/import")
async def import_adjustment(aid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("stock_adjustment.update")],
                            file: UploadFile = File(...), mode: str = Query("append", pattern="^(append|replace)$")):
    a, n = service.import_adjustment_lines(db, p, aid, await file.read(), mode)
    return ok(adjustment_out(db, p, a, detail=True), imported=n)


@router.post("/stock-adjustments/{aid}/submit")
def submit_adjustment(aid: uuid.UUID, body: RowVersionIn, db: DbSession,
                      p: Annotated[Principal, require("stock_adjustment.update")]):
    return ok(adjustment_out(db, p, service.submit_adjustment(db, p, aid, body.row_version), detail=True))


@router.post("/stock-adjustments/{aid}/withdraw")
def withdraw_adjustment(aid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("stock_adjustment.update")]):
    return ok(adjustment_out(db, p, service.withdraw_adjustment(db, p, aid), detail=True))


@router.post("/stock-adjustments/{aid}/cancel")
def cancel_adjustment(aid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("stock_adjustment.update")]):
    return ok(adjustment_out(db, p, service.cancel_adjustment(db, p, aid), detail=True))


# ------------------------------------------------------------------ site store
@router.post("/projects/{project_id}/site-store", status_code=201)
def create_site_store(project_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("project.update")]):
    return ok(wh_ref(service.create_site_store(db, p, project_id)))
