"""Inventory (Spec §19–§21): the stock ledger and what is derived from it.

`stock_transactions` is the ledger — one row per movement with a signed quantity and value. Rows are never updated
or deleted (the application's database role has no UPDATE/DELETE on it). Balances, batch quantities and serial
locations are projections kept in step in the same database transaction, under row locks, and can be rebuilt
from the ledger at any time. Valuation is weighted average cost per item per warehouse.
"""
import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import BigInteger, CheckConstraint, Date, DateTime, ForeignKey, Identity, Index, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.models import AuditColumnsMixin, Base, uuid_pk
from app.core.money import AMOUNT, QTY, RATE

TXN_TYPES = ("opening", "grn", "transfer_in", "transfer_out", "adjustment_in", "adjustment_out", "issue", "return")
TRANSFER_STATUSES = ("draft", "posted", "cancelled")
ADJUSTMENT_STATUSES = ("draft", "pending_approval", "posted", "cancelled")
ADJUSTMENT_REASONS = ("opening", "count_correction", "damage", "loss", "found", "other")


def _in(col: str, values: tuple[str, ...]) -> str:
    return f"{col} in ({', '.join(repr(v) for v in values)})"


class StockTransaction(Base):
    __tablename__ = "stock_transactions"
    __table_args__ = (
        CheckConstraint(_in("txn_type", TXN_TYPES), name="type_valid"),
        CheckConstraint("quantity <> 0", name="qty_nonzero"),
        CheckConstraint("unit_cost >= 0", name="cost_nonneg"),
        Index("ix_stock_transactions_item_wh", "item_id", "warehouse_id", "posted_at"),
        Index("ix_stock_transactions_source", "source_type", "source_id"),
        Index("ix_stock_transactions_project", "project_id"),
    )

    id: Mapped[uuid.UUID] = uuid_pk()
    seq: Mapped[int] = mapped_column(BigInteger, Identity(), unique=True, nullable=False)  # posting order
    txn_date: Mapped[date] = mapped_column(Date, nullable=False)
    posted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    txn_type: Mapped[str] = mapped_column(String(20), nullable=False)
    item_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("items.id", ondelete="RESTRICT"), nullable=False)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("warehouses.id", ondelete="RESTRICT"), nullable=False)
    quantity: Mapped[Decimal] = mapped_column(QTY, nullable=False)            # + in, − out
    unit_cost: Mapped[Decimal] = mapped_column(RATE, nullable=False)
    value: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False)            # signed, ₹
    balance_qty: Mapped[Decimal] = mapped_column(QTY, nullable=False)         # item × warehouse after this row
    balance_value: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False)
    batch_no: Mapped[str | None] = mapped_column(String(60))
    serial_nos: Mapped[list] = mapped_column(JSONB, nullable=False, default=list, server_default="[]")
    source_type: Mapped[str] = mapped_column(String(30), nullable=False)      # grn / transfer / adjustment / …
    source_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    source_number: Mapped[str | None] = mapped_column(String(40))
    source_line_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True))
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"))
    remarks: Mapped[str | None] = mapped_column(String(500))
    created_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))


class StockBalance(Base):
    """Cached quantity and value per item per warehouse (weighted average cost = value ÷ quantity)."""

    __tablename__ = "stock_balances"
    __table_args__ = (UniqueConstraint("item_id", "warehouse_id", name="uq_stock_balances_item_wh"),
                      Index("ix_stock_balances_warehouse", "warehouse_id"))

    id: Mapped[uuid.UUID] = uuid_pk()
    item_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("items.id", ondelete="RESTRICT"), nullable=False)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("warehouses.id", ondelete="RESTRICT"), nullable=False)
    quantity: Mapped[Decimal] = mapped_column(QTY, nullable=False, default=Decimal("0"), server_default="0")
    value: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    last_movement_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class StockBatch(Base):
    __tablename__ = "stock_batches"
    __table_args__ = (UniqueConstraint("item_id", "warehouse_id", "batch_no", name="uq_stock_batches_item_wh_batch"),
                      CheckConstraint("quantity >= 0", name="qty_nonneg"))

    id: Mapped[uuid.UUID] = uuid_pk()
    item_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("items.id", ondelete="RESTRICT"), nullable=False)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("warehouses.id", ondelete="RESTRICT"), nullable=False)
    batch_no: Mapped[str] = mapped_column(String(60), nullable=False)
    expiry_date: Mapped[date | None] = mapped_column(Date)
    quantity: Mapped[Decimal] = mapped_column(QTY, nullable=False, default=Decimal("0"), server_default="0")


class StockSerial(Base):
    """Every serial number ever received. Unique per item across the whole system (Spec §19)."""

    __tablename__ = "stock_serials"
    __table_args__ = (UniqueConstraint("item_id", "serial_no", name="uq_stock_serials_item_serial"),
                      CheckConstraint("status in ('in_stock','out')", name="status_valid"),
                      Index("ix_stock_serials_wh", "warehouse_id", "item_id"))

    id: Mapped[uuid.UUID] = uuid_pk()
    item_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("items.id", ondelete="RESTRICT"), nullable=False)
    serial_no: Mapped[str] = mapped_column(String(80), nullable=False)
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="in_stock")
    warehouse_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("warehouses.id", ondelete="RESTRICT"))
    batch_no: Mapped[str | None] = mapped_column(String(60))
    received_via: Mapped[str | None] = mapped_column(String(40))              # GRN / adjustment number
    received_on: Mapped[date | None] = mapped_column(Date)
    last_txn_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True))


class StockTransfer(AuditColumnsMixin, Base):
    __tablename__ = "stock_transfers"
    __table_args__ = (CheckConstraint(_in("status", TRANSFER_STATUSES), name="status_valid"),
                      CheckConstraint("from_warehouse_id <> to_warehouse_id", name="different_warehouses"))

    transfer_number: Mapped[str | None] = mapped_column(String(30), unique=True)
    transfer_date: Mapped[date] = mapped_column(Date, nullable=False)
    from_warehouse_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("warehouses.id", ondelete="RESTRICT"), nullable=False)
    to_warehouse_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("warehouses.id", ondelete="RESTRICT"), nullable=False)
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"))
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="draft", server_default="draft")
    vehicle_no: Mapped[str | None] = mapped_column(String(30))
    notes: Mapped[str | None] = mapped_column(Text)
    posted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    lines: Mapped[list["StockTransferLine"]] = relationship(order_by="StockTransferLine.line_no",
                                                            cascade="all, delete-orphan", lazy="selectin")


class StockTransferLine(AuditColumnsMixin, Base):
    __tablename__ = "stock_transfer_lines"
    __table_args__ = (CheckConstraint("quantity > 0", name="qty_positive"),)

    transfer_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("stock_transfers.id", ondelete="CASCADE"), nullable=False,
                                                   index=True)
    line_no: Mapped[int] = mapped_column(Integer, nullable=False)
    item_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("items.id", ondelete="RESTRICT"), nullable=False)
    quantity: Mapped[Decimal] = mapped_column(QTY, nullable=False)
    batch_no: Mapped[str | None] = mapped_column(String(60))
    serial_nos: Mapped[list] = mapped_column(JSONB, nullable=False, default=list, server_default="[]")
    unit_cost: Mapped[Decimal | None] = mapped_column(RATE)                  # filled when posted
    remarks: Mapped[str | None] = mapped_column(String(300))


class StockAdjustment(AuditColumnsMixin, Base):
    """Opening stock and corrections. Always needs approval before it moves stock."""

    __tablename__ = "stock_adjustments"
    __table_args__ = (CheckConstraint(_in("status", ADJUSTMENT_STATUSES), name="status_valid"),
                      CheckConstraint(_in("reason_type", ADJUSTMENT_REASONS), name="reason_valid"))

    adjustment_number: Mapped[str | None] = mapped_column(String(30), unique=True)
    adjustment_date: Mapped[date] = mapped_column(Date, nullable=False)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("warehouses.id", ondelete="RESTRICT"), nullable=False)
    reason_type: Mapped[str] = mapped_column(String(20), nullable=False)
    reason: Mapped[str] = mapped_column(String(500), nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="draft", server_default="draft")
    value: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    last_rejection: Mapped[str | None] = mapped_column(String(500))
    posted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    lines: Mapped[list["StockAdjustmentLine"]] = relationship(order_by="StockAdjustmentLine.line_no",
                                                              cascade="all, delete-orphan", lazy="selectin")


class StockAdjustmentLine(AuditColumnsMixin, Base):
    __tablename__ = "stock_adjustment_lines"
    __table_args__ = (CheckConstraint("quantity <> 0", name="qty_nonzero"),
                      CheckConstraint("unit_cost is null or unit_cost >= 0", name="cost_nonneg"))

    adjustment_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("stock_adjustments.id", ondelete="CASCADE"),
                                                     nullable=False, index=True)
    line_no: Mapped[int] = mapped_column(Integer, nullable=False)
    item_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("items.id", ondelete="RESTRICT"), nullable=False)
    quantity: Mapped[Decimal] = mapped_column(QTY, nullable=False)             # + add, − remove
    unit_cost: Mapped[Decimal | None] = mapped_column(RATE)                   # for additions
    batch_no: Mapped[str | None] = mapped_column(String(60))
    expiry_date: Mapped[date | None] = mapped_column(Date)
    serial_nos: Mapped[list] = mapped_column(JSONB, nullable=False, default=list, server_default="[]")
    remarks: Mapped[str | None] = mapped_column(String(300))
