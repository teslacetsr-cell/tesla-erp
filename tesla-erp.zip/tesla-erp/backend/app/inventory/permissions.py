from app.core.permissions import register

register("stock", "Stock balances, stock ledger & serial numbers", ("read", "export"))
register("stock_transfer", "Stock transfers between warehouses and site stores", ("create", "read", "update"))
# Adjustments move stock without a purchase or an issue, so they always need approval (Spec §19).
register("stock_adjustment", "Stock adjustments & opening stock", ("create", "read", "update", "approve"))
