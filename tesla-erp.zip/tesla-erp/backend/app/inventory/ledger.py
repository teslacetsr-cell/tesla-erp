"""The only code that moves stock. Every movement — GRN, transfer, adjustment, and material issue/return from
Phase 6 — calls `post()`, which in one database transaction:

1. locks the item × warehouse balance row (so two people cannot take the last unit at the same time),
2. checks the rules (no negative stock unless allowed, batch and serial numbers),
3. writes the immutable ledger row with the running balance, and
4. updates the cached balance, batch quantity and serial location.

Valuation is weighted average per item per warehouse: receipts add at their cost; issues and transfers go out at
the current average (value ÷ quantity). The movement that empties a balance takes exactly the value left, so
rounding never leaves a residue and the ledger always sums to the cached balance.
"""
import uuid
from dataclasses import dataclass
from datetime import date
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from app.core.errors import AppError
from app.core.money import round_amount, round_qty, round_rate
from app.crm.service import now
from app.inventory.models import StockBalance, StockBatch, StockSerial, StockTransaction
from app.platform.settings import service as settings
from app.products.models import Item, Warehouse

ZERO = Decimal("0")
INBOUND_NEW_SERIAL = ("grn", "opening")  # a serial received from outside must never have existed before


def _fmt(q: Decimal) -> str:
    return f"{q.normalize():f}"


def negative_allowed(db: Session, wh: Warehouse) -> bool:
    if wh.allow_negative_stock is not None:
        return wh.allow_negative_stock
    return bool(settings.get_setting(db, wh.company_id, "inventory.allow_negative_stock"))


def _lock_balance(db: Session, item_id: uuid.UUID, warehouse_id: uuid.UUID) -> StockBalance:
    db.execute(pg_insert(StockBalance).values(id=uuid.uuid4(), item_id=item_id, warehouse_id=warehouse_id)
               .on_conflict_do_nothing(constraint="uq_stock_balances_item_wh"))
    return db.scalar(select(StockBalance).where(StockBalance.item_id == item_id,
                                                StockBalance.warehouse_id == warehouse_id)
                     .with_for_update().execution_options(populate_existing=True))


def _lock_batch(db: Session, item_id, warehouse_id, batch_no: str) -> StockBatch:
    db.execute(pg_insert(StockBatch).values(id=uuid.uuid4(), item_id=item_id, warehouse_id=warehouse_id,
                                            batch_no=batch_no)
               .on_conflict_do_nothing(constraint="uq_stock_batches_item_wh_batch"))
    return db.scalar(select(StockBatch).where(StockBatch.item_id == item_id, StockBatch.warehouse_id == warehouse_id,
                                              StockBatch.batch_no == batch_no)
                     .with_for_update().execution_options(populate_existing=True))


def clean_serials(raw) -> list[str]:
    out: list[str] = []
    for s in raw or []:
        s = str(s).strip()
        if s and s not in out:
            out.append(s)
    return out


def check_item_rules(item: Item, qty: Decimal, batch_no: str | None, serial_nos: list[str], label: str) -> None:
    """Checks that do not need the database — also used to validate a whole document before posting any line."""
    if item.item_type == "service":
        raise AppError("NOT_STOCKED", f"{label}: {item.item_name} is a service and is not kept in stock.")
    if item.batch_required and not batch_no:
        raise AppError("BATCH_REQUIRED", f"{label}: {item.item_name} needs a batch number.")
    if item.serial_number_required:
        n = abs(qty)
        if n != n.to_integral_value():
            raise AppError("SERIAL_WHOLE_QTY", f"{label}: {item.item_name} is serial-numbered; use a whole quantity.")
        if len(serial_nos) != int(n):
            raise AppError("SERIALS_REQUIRED",
                           f"{label}: {item.item_name} needs {int(n)} serial number(s); {len(serial_nos)} given.")
    elif serial_nos:
        raise AppError("NOT_SERIALISED", f"{label}: {item.item_name} is not tracked by serial number.")


@dataclass
class Movement:
    item: Item
    warehouse: Warehouse
    quantity: Decimal                 # signed
    unit_cost: Decimal | None = None  # required for receipts
    value: Decimal | None = None      # receipts only: exact value (a transfer brings in exactly what left the source)
    batch_no: str | None = None
    expiry_date: date | None = None
    serial_nos: tuple[str, ...] = ()
    source_line_id: uuid.UUID | None = None
    remarks: str | None = None


def post(db: Session, m: Movement, *, txn_type: str, source_type: str, source_id: uuid.UUID,
         source_number: str | None, txn_date: date, user_id: uuid.UUID | None, project_id: uuid.UUID | None = None,
         label: str | None = None) -> StockTransaction:
    item, wh = m.item, m.warehouse
    qty = round_qty(m.quantity)
    label = label or item.item_name
    if qty == 0:
        raise AppError("ZERO_QTY", f"{label}: quantity cannot be zero.")
    serials = clean_serials(m.serial_nos)
    batch = (m.batch_no or "").strip() or None
    check_item_rules(item, qty, batch, serials, label)
    if not wh.is_active:
        raise AppError("WAREHOUSE_INACTIVE", f"{wh.name} is inactive.")

    bal = _lock_balance(db, item.id, wh.id)
    if qty > 0:
        if m.unit_cost is None:
            raise AppError("COST_REQUIRED", f"{label}: the unit cost is needed to value the receipt.")
        cost = round_rate(m.unit_cost)
        value = round_amount(m.value) if m.value is not None else round_amount(qty * cost)
    else:
        out = -qty
        if bal.quantity - out < 0 and not negative_allowed(db, wh):
            raise AppError("INSUFFICIENT_STOCK",
                           f"{label}: only {_fmt(max(bal.quantity, ZERO))} {item.unit.code} in {wh.name}; "
                           f"{_fmt(out)} cannot be taken out.",
                           details={"item_id": str(item.id), "warehouse_id": str(wh.id),
                                    "available": str(max(bal.quantity, ZERO))}, status_code=409)
        avg = (bal.value / bal.quantity) if bal.quantity > 0 else (item.purchase_price or ZERO)
        cost = round_rate(avg)
        value = -round_amount(out * avg)
    if bal.quantity + qty == 0:
        value = -bal.value  # an emptied balance holds exactly zero value: the ledger and the cache stay equal

    if batch:
        b = _lock_batch(db, item.id, wh.id, batch)
        if qty < 0 and b.quantity < -qty:
            raise AppError("INSUFFICIENT_BATCH", f"{label}: batch {batch} has only {_fmt(b.quantity)} in {wh.name}.",
                           status_code=409)
        b.quantity += qty
        if qty > 0 and m.expiry_date:
            b.expiry_date = m.expiry_date

    txn = StockTransaction(txn_date=txn_date, txn_type=txn_type, item_id=item.id, warehouse_id=wh.id, quantity=qty,
                           unit_cost=cost, value=value, balance_qty=bal.quantity + qty,
                           balance_value=bal.value + value, batch_no=batch, serial_nos=serials,
                           source_type=source_type, source_id=source_id, source_number=source_number,
                           source_line_id=m.source_line_id, project_id=project_id, remarks=m.remarks,
                           created_by=user_id)
    db.add(txn)
    db.flush()

    for s in serials:
        row = db.scalar(select(StockSerial).where(StockSerial.item_id == item.id, StockSerial.serial_no == s)
                        .with_for_update())
        if qty > 0:
            if row is not None and (row.status == "in_stock" or txn_type in INBOUND_NEW_SERIAL):
                where = f" (in stock at {db.get(Warehouse, row.warehouse_id).name})" if row.status == "in_stock" else \
                    f" (received earlier via {row.received_via})"
                raise AppError("DUPLICATE_SERIAL", f"{label}: serial number {s} already exists{where}.",
                               details={"serial_no": s}, status_code=409)
            if row is None:
                db.add(StockSerial(item_id=item.id, serial_no=s, status="in_stock", warehouse_id=wh.id, batch_no=batch,
                                   received_via=source_number, received_on=txn_date, last_txn_id=txn.id))
            else:
                row.status, row.warehouse_id, row.last_txn_id = "in_stock", wh.id, txn.id
        else:
            if row is None or row.status != "in_stock" or row.warehouse_id != wh.id:
                raise AppError("SERIAL_NOT_IN_STOCK", f"{label}: serial number {s} is not in stock at {wh.name}.",
                               details={"serial_no": s}, status_code=409)
            row.status, row.warehouse_id, row.last_txn_id = "out", None, txn.id

    bal.quantity += qty
    bal.value += value
    bal.last_movement_at = now()
    db.flush()
    return txn


def average_cost(db: Session, item_id: uuid.UUID, warehouse_id: uuid.UUID) -> Decimal | None:
    bal = db.scalar(select(StockBalance).where(StockBalance.item_id == item_id,
                                               StockBalance.warehouse_id == warehouse_id))
    if bal is None or bal.quantity <= 0:
        return None
    return round_rate(bal.value / bal.quantity)


def available(db: Session, item_id: uuid.UUID, warehouse_id: uuid.UUID) -> Decimal:
    return db.scalar(select(StockBalance.quantity).where(StockBalance.item_id == item_id,
                                                         StockBalance.warehouse_id == warehouse_id)) or ZERO


def verify(db: Session) -> list[dict]:
    """Rebuild every balance from the ledger and compare with the cached figures. Empty list = all match."""
    ledger = {(i, w): (q, v) for i, w, q, v in db.execute(
        select(StockTransaction.item_id, StockTransaction.warehouse_id, func.sum(StockTransaction.quantity),
               func.sum(StockTransaction.value)).group_by(StockTransaction.item_id, StockTransaction.warehouse_id))}
    cached = {(b.item_id, b.warehouse_id): (b.quantity, b.value) for b in db.scalars(select(StockBalance))}
    problems = []
    for key in set(ledger) | set(cached):
        lq, lv = ledger.get(key, (ZERO, ZERO))
        cq, cv = cached.get(key, (ZERO, ZERO))
        if lq != cq or lv != cv:
            problems.append({"item_id": str(key[0]), "warehouse_id": str(key[1]), "ledger_qty": str(lq),
                             "cached_qty": str(cq), "ledger_value": str(lv), "cached_value": str(cv)})
    return problems
