import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import Field

from app.core.api import Schema
from app.core.validators import Text
from app.inventory.models import ADJUSTMENT_REASONS

Qty = Field(max_digits=18, decimal_places=3)


class TransferLineIn(Schema):
    item_id: uuid.UUID
    quantity: Decimal = Field(gt=0, max_digits=18, decimal_places=3)
    batch_no: Text(60) = None
    serial_nos: list[str] = Field(default_factory=list, max_length=1000)
    remarks: Text(300) = None


class TransferIn(Schema):
    transfer_date: date | None = None
    from_warehouse_id: uuid.UUID
    to_warehouse_id: uuid.UUID
    project_id: uuid.UUID | None = None
    vehicle_no: Text(30) = None
    notes: Text(2000) = None
    lines: list[TransferLineIn] = Field(min_length=1, max_length=500)
    post: bool = False  # save and move the stock now


class TransferUpdate(TransferIn):
    row_version: int


class AdjustmentLineIn(Schema):
    item_id: uuid.UUID
    quantity: Decimal = Field(max_digits=18, decimal_places=3, description="+ to add, − to remove")
    unit_cost: Decimal | None = Field(default=None, ge=0, max_digits=18, decimal_places=4)
    batch_no: Text(60) = None
    expiry_date: date | None = None
    serial_nos: list[str] = Field(default_factory=list, max_length=1000)
    remarks: Text(300) = None


class AdjustmentIn(Schema):
    adjustment_date: date | None = None
    warehouse_id: uuid.UUID
    reason_type: Literal[ADJUSTMENT_REASONS]  # type: ignore[valid-type]
    reason: str = Field(min_length=5, max_length=500)
    lines: list[AdjustmentLineIn] = Field(default_factory=list, max_length=2000)


class AdjustmentUpdate(AdjustmentIn):
    row_version: int


class RowVersionIn(Schema):
    row_version: int | None = None
