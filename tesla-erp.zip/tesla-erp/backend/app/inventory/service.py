"""Stock transfers, stock adjustments (incl. opening stock), site stores, and stock enquiries."""
import uuid
from datetime import date
from decimal import Decimal

from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.core import excel
from app.core.api import ListParams, paginate
from app.core.errors import AppError, Conflict, NotFound
from app.core.models import check_row_version
from app.core.money import round_amount, round_qty
from app.crm.service import now, today
from app.inventory import ledger
from app.inventory.models import StockAdjustment, StockAdjustmentLine, StockBalance, StockTransaction, StockTransfer, StockTransferLine
from app.platform.approvals import service as approvals
from app.platform.audit import service as audit
from app.platform.numbering import service as numbering
from app.products.models import Item, Warehouse

ZERO = Decimal("0")


def _q(v: Decimal) -> str:
    return f"{v.normalize():f}"


def warehouse(db: Session, wid: uuid.UUID, what: str = "warehouse") -> Warehouse:
    wh = db.get(Warehouse, wid)
    if wh is None:
        raise NotFound(what)
    if not wh.is_active:
        raise AppError("WAREHOUSE_INACTIVE", f"{wh.name} is inactive.")
    return wh


def _items(db: Session, ids) -> dict:
    ids = set(ids)
    found = {i.id: i for i in db.scalars(select(Item).where(Item.id.in_(ids)))} if ids else {}
    missing = ids - set(found)
    if missing:
        raise NotFound("item")
    return found


# ------------------------------------------------------------------ transfers
def get_transfer(db: Session, tid: uuid.UUID, lock: bool = False) -> StockTransfer:
    t = db.get(StockTransfer, tid, with_for_update=lock or None)
    if t is None:
        raise NotFound("stock_transfer")
    return t


def _fill_transfer(db: Session, p: Principal, t: StockTransfer, data) -> None:
    if data.from_warehouse_id == data.to_warehouse_id:
        raise AppError("SAME_WAREHOUSE", "Choose two different warehouses.")
    src, dst = warehouse(db, data.from_warehouse_id, "from_warehouse"), warehouse(db, data.to_warehouse_id, "to_warehouse")
    items = _items(db, [ln.item_id for ln in data.lines])
    for i, ln in enumerate(data.lines, start=1):
        ledger.check_item_rules(items[ln.item_id], round_qty(ln.quantity), ln.batch_no,
                                ledger.clean_serials(ln.serial_nos), f"Line {i}")
    t.transfer_date = data.transfer_date or today()
    t.from_warehouse_id, t.to_warehouse_id = src.id, dst.id
    t.project_id = data.project_id or dst.project_id or src.project_id
    t.vehicle_no, t.notes, t.updated_by = data.vehicle_no, data.notes, p.id
    t.lines.clear()
    db.flush()
    for i, ln in enumerate(data.lines, start=1):
        t.lines.append(StockTransferLine(line_no=i, item_id=ln.item_id, quantity=round_qty(ln.quantity),
                                         batch_no=ln.batch_no, serial_nos=ledger.clean_serials(ln.serial_nos),
                                         remarks=ln.remarks, created_by=p.id, updated_by=p.id))


def create_transfer(db: Session, p: Principal, data) -> StockTransfer:
    t = StockTransfer(status="draft", created_by=p.id, transfer_date=data.transfer_date or today(),
                      from_warehouse_id=data.from_warehouse_id, to_warehouse_id=data.to_warehouse_id)
    db.add(t)
    _fill_transfer(db, p, t, data)
    db.flush()
    audit.record(db, action="create", entity_type="stock_transfer", entity_id=t.id, entity_label="Draft transfer",
                 summary=f"{len(t.lines)} lines")
    if data.post:
        post_transfer(db, p, t.id)
    return t


def update_transfer(db: Session, p: Principal, tid: uuid.UUID, data) -> StockTransfer:
    t = get_transfer(db, tid, lock=True)
    if t.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft transfer can be changed.")
    check_row_version(t, data.row_version)
    _fill_transfer(db, p, t, data)
    db.flush()
    if data.post:
        post_transfer(db, p, t.id)
    return t


def post_transfer(db: Session, p: Principal, tid: uuid.UUID) -> StockTransfer:
    """Out of the source and into the destination in one transaction; the value moves exactly."""
    t = get_transfer(db, tid, lock=True)
    if t.status != "draft":
        raise AppError("NOT_DRAFT", f"This transfer is already {t.status}.")
    src, dst = warehouse(db, t.from_warehouse_id), warehouse(db, t.to_warehouse_id)
    items = _items(db, [ln.item_id for ln in t.lines])
    t.transfer_number = numbering.next_number(db, p.company_id, "TRF", on=t.transfer_date)
    for ln in sorted(t.lines, key=lambda x: (str(x.item_id), x.line_no)):  # fixed lock order: no deadlocks
        item = items[ln.item_id]
        label = f"Line {ln.line_no} ({item.item_name})"
        common = {"source_type": "transfer", "source_id": t.id, "source_number": t.transfer_number,
                  "txn_date": t.transfer_date, "user_id": p.id, "project_id": t.project_id, "label": label}
        out = ledger.post(db, ledger.Movement(item, src, -ln.quantity, batch_no=ln.batch_no,
                                              serial_nos=tuple(ln.serial_nos), source_line_id=ln.id,
                                              remarks=f"To {dst.name}"), txn_type="transfer_out", **common)
        ledger.post(db, ledger.Movement(item, dst, ln.quantity, unit_cost=out.unit_cost, value=-out.value,
                                        batch_no=ln.batch_no, serial_nos=tuple(ln.serial_nos), source_line_id=ln.id,
                                        remarks=f"From {src.name}"), txn_type="transfer_in", **common)
        ln.unit_cost = out.unit_cost
    t.status, t.posted_at, t.updated_by = "posted", now(), p.id
    t.row_version += 1
    db.flush()
    audit.record(db, action="post", entity_type="stock_transfer", entity_id=t.id, entity_label=t.transfer_number,
                 summary=f"{src.name} → {dst.name}: {len(t.lines)} lines")
    return t


def cancel_transfer(db: Session, p: Principal, tid: uuid.UUID) -> StockTransfer:
    t = get_transfer(db, tid, lock=True)
    if t.status != "draft":
        raise AppError("NOT_DRAFT", "A posted transfer cannot be cancelled; transfer the stock back instead.")
    t.status, t.updated_by = "cancelled", p.id
    t.row_version += 1
    db.flush()
    audit.record(db, action="cancel", entity_type="stock_transfer", entity_id=t.id, entity_label="Draft transfer")
    return t


def list_transfers(db: Session, params: ListParams, *, status=None, warehouse_id=None, project_id=None):
    stmt = select(StockTransfer)
    if status:
        stmt = stmt.where(StockTransfer.status == status)
    if warehouse_id:
        stmt = stmt.where(or_(StockTransfer.from_warehouse_id == warehouse_id, StockTransfer.to_warehouse_id == warehouse_id))
    if project_id:
        stmt = stmt.where(StockTransfer.project_id == project_id)
    if params.q:
        stmt = stmt.where(or_(StockTransfer.transfer_number.ilike(f"%{params.q}%"), StockTransfer.notes.ilike(f"%{params.q}%")))
    return paginate(db, stmt, params, default_sort=StockTransfer.created_at.desc(), sortable={
        "transfer_date": StockTransfer.transfer_date, "transfer_number": StockTransfer.transfer_number,
        "created_at": StockTransfer.created_at})


# ------------------------------------------------------------------ adjustments
def get_adjustment(db: Session, aid: uuid.UUID, lock: bool = False) -> StockAdjustment:
    a = db.get(StockAdjustment, aid, with_for_update=lock or None)
    if a is None:
        raise NotFound("stock_adjustment")
    return a


def _line_cost(db: Session, a: StockAdjustment, ln, item: Item) -> Decimal:
    if ln.quantity > 0:
        return ln.unit_cost if ln.unit_cost is not None else (item.purchase_price or ZERO)
    return ledger.average_cost(db, item.id, a.warehouse_id) or item.purchase_price or ZERO


def _fill_adjustment(db: Session, p: Principal, a: StockAdjustment, data) -> None:
    wh = warehouse(db, data.warehouse_id)
    items = _items(db, [ln.item_id for ln in data.lines])
    for i, ln in enumerate(data.lines, start=1):
        q = round_qty(ln.quantity)
        if q == 0:
            raise AppError("ZERO_QTY", f"Line {i}: quantity cannot be zero.")
        ledger.check_item_rules(items[ln.item_id], q, ln.batch_no, ledger.clean_serials(ln.serial_nos), f"Line {i}")
        if data.reason_type == "opening" and q < 0:
            raise AppError("OPENING_POSITIVE", f"Line {i}: opening stock is added, so quantities must be positive.")
    a.adjustment_date = data.adjustment_date or today()
    a.warehouse_id, a.reason_type, a.reason, a.updated_by = wh.id, data.reason_type, data.reason, p.id
    a.lines.clear()
    db.flush()
    total = ZERO
    for i, ln in enumerate(data.lines, start=1):
        row = StockAdjustmentLine(line_no=i, item_id=ln.item_id, quantity=round_qty(ln.quantity), unit_cost=ln.unit_cost,
                                  batch_no=ln.batch_no, expiry_date=ln.expiry_date,
                                  serial_nos=ledger.clean_serials(ln.serial_nos), remarks=ln.remarks,
                                  created_by=p.id, updated_by=p.id)
        a.lines.append(row)
        total += abs(row.quantity) * _line_cost(db, a, row, items[ln.item_id])
    a.value = round_amount(total)


def create_adjustment(db: Session, p: Principal, data) -> StockAdjustment:
    a = StockAdjustment(status="draft", created_by=p.id, reason=data.reason, reason_type=data.reason_type,
                        adjustment_date=data.adjustment_date or today(), warehouse_id=data.warehouse_id)
    db.add(a)
    _fill_adjustment(db, p, a, data)
    db.flush()
    audit.record(db, action="create", entity_type="stock_adjustment", entity_id=a.id, entity_label="Draft adjustment",
                 summary=f"{a.reason_type}: {len(a.lines)} lines, ₹{a.value}")
    return a


def update_adjustment(db: Session, p: Principal, aid: uuid.UUID, data) -> StockAdjustment:
    a = get_adjustment(db, aid, lock=True)
    if a.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft adjustment can be changed.")
    check_row_version(a, data.row_version)
    _fill_adjustment(db, p, a, data)
    db.flush()
    return a


def submit_adjustment(db: Session, p: Principal, aid: uuid.UUID, row_version: int | None) -> StockAdjustment:
    a = get_adjustment(db, aid, lock=True)
    if a.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft adjustment can be submitted.")
    if row_version is not None:
        check_row_version(a, row_version)
    else:
        a.row_version += 1
    if not a.lines:
        raise AppError("NO_LINES", "Add at least one line.")
    if a.adjustment_number is None:
        a.adjustment_number = numbering.next_number(db, p.company_id, "ADJ", on=a.adjustment_date)
    a.last_rejection = None
    req = approvals.start(db, p, entity_type="stock_adjustment", entity_id=a.id, label=a.adjustment_number,
                          amount=a.value)
    if req is None:
        if not p.can("stock_adjustment.approve"):
            raise AppError("APPROVER_NEEDED", "Stock adjustments need approval, and no approval rule applies. "
                                              "Ask an administrator to add one in Administration → Approval rules.")
        _post_adjustment(db, p, a)
    else:
        a.status = "pending_approval"
        audit.record(db, action="submit", entity_type="stock_adjustment", entity_id=a.id,
                     entity_label=a.adjustment_number, summary=f"₹{a.value}: {a.reason}")
    db.flush()
    return a


def _post_adjustment(db: Session, p: Principal, a: StockAdjustment) -> None:
    wh = warehouse(db, a.warehouse_id)
    items = _items(db, [ln.item_id for ln in a.lines])
    kind = "opening" if a.reason_type == "opening" else None
    for ln in sorted(a.lines, key=lambda x: (str(x.item_id), x.line_no)):
        item = items[ln.item_id]
        ledger.post(db, ledger.Movement(item, wh, ln.quantity, unit_cost=_line_cost(db, a, ln, item) if ln.quantity > 0 else None,
                                        batch_no=ln.batch_no, expiry_date=ln.expiry_date, serial_nos=tuple(ln.serial_nos),
                                        source_line_id=ln.id, remarks=ln.remarks or a.reason[:500]),
                    txn_type=kind or ("adjustment_in" if ln.quantity > 0 else "adjustment_out"),
                    source_type="adjustment", source_id=a.id, source_number=a.adjustment_number,
                    txn_date=a.adjustment_date, user_id=p.id, label=f"Line {ln.line_no} ({item.item_name})")
    a.status, a.posted_at, a.updated_by = "posted", now(), p.id
    audit.record(db, action="post", entity_type="stock_adjustment", entity_id=a.id, entity_label=a.adjustment_number,
                 summary=f"Stock moved in {wh.name}: {len(a.lines)} lines, ₹{a.value}")


def _on_approved(db: Session, p: Principal, req) -> None:
    a = get_adjustment(db, req.entity_id, lock=True)
    _post_adjustment(db, p, a)
    a.row_version += 1


def _on_rejected(db: Session, p: Principal, req, comment: str) -> None:
    a = get_adjustment(db, req.entity_id, lock=True)
    a.status, a.last_rejection = "draft", comment[:500]
    a.row_version += 1


approvals.register("stock_adjustment", approvals.Handler(
    label="Stock adjustment", href=lambda i: f"/inventory/adjustments/view?id={i}", on_approved=_on_approved,
    on_rejected=_on_rejected, owners=lambda db, i: [x for x in [db.scalar(
        select(StockAdjustment.created_by).where(StockAdjustment.id == i))] if x]))


def withdraw_adjustment(db: Session, p: Principal, aid: uuid.UUID) -> StockAdjustment:
    a = get_adjustment(db, aid, lock=True)
    if a.status != "pending_approval":
        raise AppError("NOT_PENDING", "Only an adjustment waiting for approval can be withdrawn.")
    approvals.withdraw(db, p, "stock_adjustment", a.id)
    a.status, a.updated_by = "draft", p.id
    a.row_version += 1
    db.flush()
    audit.record(db, action="withdraw", entity_type="stock_adjustment", entity_id=a.id, entity_label=a.adjustment_number)
    return a


def cancel_adjustment(db: Session, p: Principal, aid: uuid.UUID) -> StockAdjustment:
    a = get_adjustment(db, aid, lock=True)
    if a.status not in ("draft", "pending_approval"):
        raise AppError("POSTED", "A posted adjustment cannot be cancelled; make a new adjustment to correct it.")
    approvals.withdraw(db, p, "stock_adjustment", a.id)
    a.status, a.updated_by = "cancelled", p.id
    a.row_version += 1
    db.flush()
    audit.record(db, action="cancel", entity_type="stock_adjustment", entity_id=a.id,
                 entity_label=a.adjustment_number or "Draft adjustment")
    return a


def list_adjustments(db: Session, params: ListParams, *, status=None, warehouse_id=None):
    stmt = select(StockAdjustment)
    if status:
        stmt = stmt.where(StockAdjustment.status == status)
    if warehouse_id:
        stmt = stmt.where(StockAdjustment.warehouse_id == warehouse_id)
    if params.q:
        stmt = stmt.where(or_(StockAdjustment.adjustment_number.ilike(f"%{params.q}%"),
                              StockAdjustment.reason.ilike(f"%{params.q}%")))
    return paginate(db, stmt, params, default_sort=StockAdjustment.created_at.desc(), sortable={
        "adjustment_date": StockAdjustment.adjustment_date, "value": StockAdjustment.value,
        "created_at": StockAdjustment.created_at})


ADJ_COLUMNS = [
    excel.Column("item_code", "Item code", 16, required=True),
    excel.Column("quantity", "Quantity", 12, required=True, note="Positive to add; negative to remove (not for opening stock)"),
    excel.Column("unit_cost", "Unit cost", 12, note="₹ per unit before GST. Blank = the item's purchase price"),
    excel.Column("batch_no", "Batch", 14, note="Required for batch-tracked items"),
    excel.Column("expiry_date", "Expiry date", 12),
    excel.Column("serial_nos", "Serial numbers", 40, note="Comma-separated; one per unit for serial-numbered items"),
    excel.Column("remarks", "Remarks", 30),
]


def adjustment_template() -> bytes:
    return excel.template("Stock", ADJ_COLUMNS, {"item_code": "LP-AT-16", "quantity": 40, "unit_cost": 1850})


def import_adjustment_lines(db: Session, p: Principal, aid: uuid.UUID, data: bytes, mode: str):
    """Opening stock / stock count from Excel into a draft. Every row is checked first; nothing is saved unless all
    rows are valid."""
    from app.inventory.schemas import AdjustmentLineIn, AdjustmentUpdate

    a = get_adjustment(db, aid, lock=True)
    if a.status != "draft":
        raise AppError("NOT_DRAFT", "Lines can only be imported into a draft.")
    rows = excel.read(data, ADJ_COLUMNS)
    codes = {str(r["item_code"]).strip().lower() for _, r in rows if r.get("item_code")}
    by_code = {i.item_code.lower(): i for i in db.scalars(select(Item).where(func.lower(Item.item_code).in_(codes)))}
    errors, lines = [], []
    for n, r in rows:
        item = by_code.get(str(r.get("item_code") or "").strip().lower())
        if item is None:
            errors.append({"row": n, "message": f"Unknown item code '{r.get('item_code')}'."})
            continue
        try:
            qty = Decimal(str(r["quantity"]))
            cost = Decimal(str(r["unit_cost"])) if r.get("unit_cost") not in (None, "") else None
            serials = [s for s in str(r.get("serial_nos") or "").replace(";", ",").split(",") if s.strip()]
            ln = AdjustmentLineIn(item_id=item.id, quantity=qty, unit_cost=cost, batch_no=r.get("batch_no"),
                                  expiry_date=r.get("expiry_date"), serial_nos=serials, remarks=r.get("remarks"))
            ledger.check_item_rules(item, round_qty(qty), ln.batch_no, ledger.clean_serials(serials), f"Row {n}")
            if a.reason_type == "opening" and qty <= 0:
                raise AppError("OPENING_POSITIVE", f"Row {n}: opening quantities must be positive.")
            lines.append(ln)
        except AppError as e:
            errors.append({"row": n, "message": e.message})
        except Exception:  # noqa: BLE001 - bad number etc.
            errors.append({"row": n, "message": "Quantity and unit cost must be numbers."})
    if errors:
        raise AppError("IMPORT_ERRORS", f"{len(errors)} row(s) have problems. Nothing was imported.", details=errors)
    existing = [AdjustmentLineIn(item_id=ln.item_id, quantity=ln.quantity, unit_cost=ln.unit_cost, batch_no=ln.batch_no,
                                 expiry_date=ln.expiry_date, serial_nos=ln.serial_nos, remarks=ln.remarks)
                for ln in a.lines] if mode == "append" else []
    body = AdjustmentUpdate(adjustment_date=a.adjustment_date, warehouse_id=a.warehouse_id, reason_type=a.reason_type,
                            reason=a.reason, lines=existing + lines, row_version=a.row_version)
    return update_adjustment(db, p, a.id, body), len(lines)


# ------------------------------------------------------------------ site stores
def create_site_store(db: Session, p: Principal, project_id: uuid.UUID) -> Warehouse:
    from app.projects import service as projects

    prj = projects.get(db, project_id, lock=True)
    projects.check(p, prj, "update")
    if db.scalar(select(Warehouse.id).where(Warehouse.project_id == prj.id)):
        raise Conflict("SITE_STORE_EXISTS", "This project already has a site store.")
    parts = prj.project_number.split("/")
    code = ("SITE-" + "-".join(x.replace("-", "") for x in parts[-2:]))[:20] if len(parts) >= 2 else f"SITE-{prj.id.hex[:6]}"
    wh = Warehouse(company_id=p.company_id, code=code, name=f"Site store — {prj.name}"[:120], warehouse_type="site",
                   address=prj.site_address, in_charge_id=prj.project_manager_id, project_id=prj.id,
                   created_by=p.id, updated_by=p.id)
    db.add(wh)
    db.flush()
    audit.record(db, action="create", entity_type="warehouse", entity_id=wh.id, entity_label=f"{wh.code} {wh.name}",
                 summary=f"Site store for {prj.project_number}")
    return wh


# ------------------------------------------------------------------ stock enquiries
def stock_status(total: Decimal, item: Item) -> str:
    if total <= 0:
        return "out"
    if item.minimum_stock and total < item.minimum_stock:
        return "low"
    if item.reorder_level and total < item.reorder_level:
        return "reorder"
    return "ok"


def item_stock(db: Session, params: ListParams, *, warehouse_id=None, category_id=None, status=None):
    """One row per stock item: quantity and value (all warehouses, or one), with the low-stock status."""
    cond = [StockBalance.item_id == Item.id]
    if warehouse_id:
        cond.append(StockBalance.warehouse_id == warehouse_id)
    qty = func.coalesce(func.sum(StockBalance.quantity), 0)
    val = func.coalesce(func.sum(StockBalance.value), 0)
    stmt = (select(Item, qty.label("qty"), val.label("val")).outerjoin(StockBalance, and_(*cond))
            .where(Item.item_type == "goods", Item.is_active.is_(True)).group_by(Item.id))
    if category_id:
        stmt = stmt.where(Item.category_id == category_id)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(Item.item_code.ilike(like), Item.item_name.ilike(like), Item.model.ilike(like)))
    if status == "out":
        stmt = stmt.having(qty <= 0)
    elif status == "low":  # below minimum or reorder level (and out of stock)
        stmt = stmt.having(or_(qty <= 0, qty < Item.minimum_stock, qty < Item.reorder_level))
    elif status == "in_stock":
        stmt = stmt.having(qty > 0)
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    order = {"item_code": Item.item_code, "item_name": Item.item_name, "quantity": qty, "value": val}
    key = (params.sort or "item_name").lstrip("-")
    if key not in order:
        raise AppError("INVALID_SORT", f"Cannot sort by '{key}'.")
    col = order[key]
    stmt = stmt.order_by(col.desc() if (params.sort or "").startswith("-") else col.asc(), Item.item_code)
    rows = db.execute(stmt.offset((params.page - 1) * params.page_size).limit(params.page_size)).all()
    return rows, total


def low_stock_count(db: Session) -> dict:
    qty = func.coalesce(func.sum(StockBalance.quantity), 0)
    sub = (select(Item.id, qty.label("q"), Item.minimum_stock, Item.reorder_level)
           .outerjoin(StockBalance, StockBalance.item_id == Item.id)
           .where(Item.item_type == "goods", Item.is_active.is_(True),
                  or_(Item.reorder_level > 0, Item.minimum_stock > 0)).group_by(Item.id).subquery())
    out = db.scalar(select(func.count()).where(sub.c.q <= 0).select_from(sub)) or 0
    low = db.scalar(select(func.count()).where(sub.c.q > 0, or_(sub.c.q < sub.c.minimum_stock,
                                                                  sub.c.q < sub.c.reorder_level)).select_from(sub)) or 0
    value = db.scalar(select(func.coalesce(func.sum(StockBalance.value), 0))) or ZERO
    in_stock = db.scalar(select(func.count(func.distinct(StockBalance.item_id))).where(StockBalance.quantity > 0)) or 0
    return {"out_of_stock": out, "below_reorder": low, "stock_value": str(round_amount(value)), "items_in_stock": in_stock}


def ledger_rows(db: Session, params: ListParams, *, item_id=None, warehouse_id=None, project_id=None,
                date_from: date | None = None, date_to: date | None = None, txn_type=None):
    stmt = select(StockTransaction)
    for col, v in ((StockTransaction.item_id, item_id), (StockTransaction.warehouse_id, warehouse_id),
                   (StockTransaction.project_id, project_id), (StockTransaction.txn_type, txn_type)):
        if v:
            stmt = stmt.where(col == v)
    if date_from:
        stmt = stmt.where(StockTransaction.txn_date >= date_from)
    if date_to:
        stmt = stmt.where(StockTransaction.txn_date <= date_to)
    if params.q:
        stmt = stmt.where(StockTransaction.source_number.ilike(f"%{params.q}%"))
    return paginate(db, stmt, params, default_sort=StockTransaction.seq.desc(),
                    sortable={"posted_at": StockTransaction.seq, "txn_date": StockTransaction.txn_date})

