import io
import uuid
from decimal import Decimal
from html import escape
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from sqlalchemy import func, select

from app.auth.deps import CurrentUser, Principal, require
from app.core import excel
from app.core.api import ListParams, ok
from app.core.db import DbSession
from app.core.errors import Forbidden
from app.core.money import round_qty
from app.costing import service
from app.costing.models import COST_HEADS, MaterialIssue
from app.costing.schemas import BudgetIn, CostEntryIn, IssueIn, IssueUpdate, ReasonIn
from app.crm.service import today
from app.inventory import ledger
from app.platform.approvals import service as approvals
from app.platform.approvals.router import request_out
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.products.models import Item, Warehouse
from app.projects import service as projects
from app.projects.models import Project, ProjectBoqLine
from app.users.models import User

router = APIRouter(tags=["project costing"])
documents.register_entity("material_issue", "material_issue", MaterialIssue)


def _q(v) -> str:
    return f"{round_qty(Decimal(v)).normalize():f}"


def _d(v) -> str | None:
    return v.isoformat() if v else None


def issue_out(db, p: Principal, m: MaterialIssue, detail: bool = False) -> dict:
    prj = db.get(Project, m.project_id)
    wh = db.get(Warehouse, m.warehouse_id)
    out = {"id": str(m.id), "issue_number": m.issue_number, "kind": m.kind, "issue_date": _d(m.issue_date),
           "status": m.status, "project": {"id": str(prj.id), "number": prj.project_number, "name": prj.name},
           "warehouse": {"id": str(wh.id), "name": wh.name}, "issued_to": m.issued_to, "has_excess": m.has_excess,
           "estimated_value": str(m.estimated_value), "value": str(m.value), "lines_count": len(m.lines),
           "row_version": m.row_version}
    if not detail:
        return out
    items = {i.id: i for i in db.scalars(select(Item).where(Item.id.in_({ln.item_id for ln in m.lines})))} \
        if m.lines else {}
    boq = {b.id: b for b in db.scalars(select(ProjectBoqLine).where(
        ProjectBoqLine.id.in_({ln.project_boq_line_id for ln in m.lines} - {None})))} if m.lines else {}
    pending = approvals.pending_for(db, "material_issue", m.id)
    can_create = projects_allowed(p, prj, "create")
    out |= {
        "notes": m.notes, "status_reason": m.status_reason, "last_rejection": m.last_rejection,
        "material_request_id": str(m.material_request_id) if m.material_request_id else None,
        "submitted_at": _d(m.submitted_at), "posted_at": _d(m.posted_at),
        "created_by": db.scalar(select(User.full_name).where(User.id == m.created_by)) if m.created_by else None,
        "lines": [{"id": str(ln.id), "line_no": ln.line_no, "item_id": str(ln.item_id),
                   "item_code": items[ln.item_id].item_code, "item_name": items[ln.item_id].item_name,
                   "unit": items[ln.item_id].unit.code, "serial": items[ln.item_id].serial_number_required,
                   "batch": items[ln.item_id].batch_required, "quantity": _q(ln.quantity),
                   "available": _q(ledger.available(db, ln.item_id, m.warehouse_id)) if m.status != "posted" else None,
                   "project_boq_line_id": str(ln.project_boq_line_id) if ln.project_boq_line_id else None,
                   "boq_line": (lambda b: {"line_no": b.line_no, "description": b.description,
                                           "approved_qty": _q(b.approved_qty), "issued_qty": _q(b.issued_qty)})(
                       boq[ln.project_boq_line_id]) if ln.project_boq_line_id in boq else None,
                   "batch_no": ln.batch_no, "serial_nos": ln.serial_nos, "excess_qty": _q(ln.excess_qty),
                   "unit_cost": str(ln.unit_cost) if ln.unit_cost is not None else None,
                   "value": str(ln.value) if ln.value is not None else None, "remarks": ln.remarks}
                  for ln in m.lines],
        "approval": request_out(db, p, pending) if pending else None,
        "approvals": [request_out(db, p, r) for r in approvals.history(db, "material_issue", m.id)],
        "can": {"edit": can_create and m.status == "draft" and m.kind == "issue",
                "submit": can_create and m.status == "draft" and m.kind == "issue",
                "withdraw": can_create and m.status == "pending_approval",
                "cancel": can_create and m.status in ("draft", "pending_approval") and bool(m.issue_number),
                "delete": p.can("material_issue.delete") and m.status == "draft" and not m.issue_number,
                "decide": bool(pending and approvals.can_decide(p, pending)),
                "print": p.can("material_issue.print"),
                "return": can_create and m.kind == "issue" and m.status == "posted"},
    }
    return out


def projects_allowed(p: Principal, prj: Project, action: str) -> bool:
    try:
        service.issue_check(p, prj, action)
        return True
    except Forbidden:
        return False


def _issue_for(db, p: Principal, iid: uuid.UUID) -> MaterialIssue:
    m = service.get_issue(db, iid)
    service.issue_check(p, db.get(Project, m.project_id), "read")
    return m


@router.get("/material-issues")
def list_issues(db: DbSession, p: Annotated[Principal, require("material_issue.read")],
                params: Annotated[ListParams, Depends()], status: str | None = Query(None),
                project_id: uuid.UUID | None = None, kind: str | None = None, warehouse_id: uuid.UUID | None = None):
    rows, meta = service.list_issues(db, p, params, status=status, project_id=project_id, kind=kind,
                                     warehouse_id=warehouse_id)
    return {"data": [issue_out(db, p, r) for r in rows], "meta": meta.model_dump()}


ISSUE_COLUMNS = [
    excel.Column("issue_number", "Number", 22), excel.Column("kind", "Type", 8), excel.Column("issue_date", "Date", 12),
    excel.Column("project", "Project", 26), excel.Column("warehouse", "Store", 22), excel.Column("item", "Item", 34),
    excel.Column("quantity", "Qty", 10), excel.Column("unit", "Unit", 7), excel.Column("unit_cost", "Cost (₹)", 12),
    excel.Column("value", "Value (₹)", 14), excel.Column("status", "Status", 12),
]


@router.get("/material-issues/export")
def export_issues(db: DbSession, p: Annotated[Principal, require("material_issue.export")],
                  params: Annotated[ListParams, Depends()], status: str | None = Query(None),
                  project_id: uuid.UUID | None = None, kind: str | None = None):
    params.page, params.page_size = 1, 5000
    rows, _ = service.list_issues(db, p, params, status=status, project_id=project_id, kind=kind)
    data = []
    for m in rows:
        o = issue_out(db, p, m, detail=True)
        for ln in o["lines"]:
            sign = -1 if m.kind == "return" else 1
            data.append({"issue_number": m.issue_number or "(draft)", "kind": m.kind, "issue_date": m.issue_date,
                         "project": o["project"]["number"], "warehouse": o["warehouse"]["name"],
                         "item": f"{ln['item_code']} {ln['item_name']}", "quantity": sign * Decimal(ln["quantity"]),
                         "unit": ln["unit"], "unit_cost": Decimal(ln["unit_cost"]) if ln["unit_cost"] else None,
                         "value": sign * Decimal(ln["value"]) if ln["value"] else None, "status": m.status})
    audit.record(db, action="export", entity_type="material_issue", summary=f"Exported {len(data)} issue lines")
    return Response(excel.export("Material issues", ISSUE_COLUMNS, data), media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="material-issues.xlsx"'})


@router.get("/material-issues/summary")
def issue_summary(db: DbSession, _: Annotated[Principal, require("material_issue.read")]):
    month = today().replace(day=1)
    value = db.scalar(select(func.coalesce(func.sum(MaterialIssue.value), 0)).where(
        MaterialIssue.status == "posted", MaterialIssue.kind == "issue", MaterialIssue.issue_date >= month)) or 0
    returned = db.scalar(select(func.coalesce(func.sum(MaterialIssue.value), 0)).where(
        MaterialIssue.status == "posted", MaterialIssue.kind == "return", MaterialIssue.issue_date >= month)) or 0
    drafts = db.scalar(select(func.count()).select_from(MaterialIssue).where(MaterialIssue.status == "draft")) or 0
    return ok({"pending_approval": service.pending_issue_count(db), "drafts": drafts,
               "issued_month": str(Decimal(value) - Decimal(returned))})


@router.post("/material-issues", status_code=201)
def create_issue(body: IssueIn, db: DbSession, p: Annotated[Principal, require("material_issue.create")]):
    return ok(issue_out(db, p, service.create_issue(db, p, body), detail=True))


@router.post("/material-returns", status_code=201)
def create_return(body: IssueIn, db: DbSession, p: Annotated[Principal, require("material_issue.create")]):
    return ok(issue_out(db, p, service.create_issue(db, p, body, kind="return"), detail=True))


@router.get("/material-issues/{iid}")
def get_issue(iid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("material_issue.read")]):
    return ok(issue_out(db, p, _issue_for(db, p, iid), detail=True))


@router.put("/material-issues/{iid}")
def update_issue(iid: uuid.UUID, body: IssueUpdate, db: DbSession,
                 p: Annotated[Principal, require("material_issue.create")]):
    return ok(issue_out(db, p, service.update_issue(db, p, iid, body), detail=True))


@router.delete("/material-issues/{iid}", status_code=204)
def delete_issue(iid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("material_issue.delete")]):
    service.delete_issue(db, p, iid)


@router.post("/material-issues/{iid}/{action}")
def issue_action(iid: uuid.UUID, action: Literal["submit", "withdraw", "cancel"], body: ReasonIn, db: DbSession,
                 p: Annotated[Principal, require("material_issue.create")]):
    fn = {"submit": lambda: service.submit_issue(db, p, iid, body.row_version),
          "withdraw": lambda: service.withdraw_issue(db, p, iid),
          "cancel": lambda: service.cancel_issue(db, p, iid, body.reason)}[action]
    return ok(issue_out(db, p, fn(), detail=True))


@router.get("/material-issues/{iid}/pdf")
def issue_pdf(iid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("material_issue.print")]):
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    from app.platform import pdfkit as K

    m = _issue_for(db, p, iid)
    o = issue_out(db, p, m, detail=True)
    K.fonts()
    st = K.styles()
    title = "MATERIAL RETURN NOTE" if m.kind == "return" else "MATERIAL ISSUE SLIP"
    story = K.letterhead(db, st) + [
        Paragraph(title, st["title"]), Spacer(1, 2 * mm),
        Paragraph(f"<b>No.</b> {escape(m.issue_number or 'DRAFT')} · <b>Date</b> {m.issue_date:%d %b %Y} · "
                  f"<b>Project</b> {escape(o['project']['number'])} {escape(o['project']['name'])} · "
                  f"<b>{'To' if m.kind == 'return' else 'From'} store</b> {escape(o['warehouse']['name'])}"
                  + (f" · <b>Issued to</b> {escape(m.issued_to)}" if m.issued_to else ""), st["base"]),
        Spacer(1, 3 * mm)]
    rows = [[Paragraph(f"<b>{h}</b>", st["cellr"] if i >= 3 else st["cell"]) for i, h in
             enumerate(["#", "Item", "Serial / batch", "Qty", "Cost (₹)", "Value (₹)"])]]
    for ln in o["lines"]:
        tag = ", ".join(ln["serial_nos"]) or ln["batch_no"] or ""
        rows.append([Paragraph(str(ln["line_no"]), st["cell"]),
                     Paragraph(f"{escape(ln['item_name'])}<br/><font size=6.8 color='#6b7280'>{escape(ln['item_code'])}</font>", st["cell"]),
                     Paragraph(escape(tag), st["cell"]), Paragraph(f"{ln['quantity']} {ln['unit']}", st["cellr"]),
                     Paragraph(K.money(ln["unit_cost"]) if ln["unit_cost"] else "", st["cellr"]),
                     Paragraph(K.money(ln["value"]) if ln["value"] else "", st["cellr"])])
    rows.append(["", Paragraph("<b>Total</b>", st["cell"]), "", "", "", Paragraph(f"<b>{K.money(m.value)}</b>", st["cellr"])])
    t = Table(rows, colWidths=[8 * mm, 70 * mm, 38 * mm, 22 * mm, 20 * mm, 24 * mm], repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), K.TINT), ("LINEBELOW", (0, 0), (-1, -1), 0.3, K.LINE),
                           ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    sign = Table([[Paragraph("Issued by (store)", st["small"]), Paragraph("Received by (site)", st["small"]),
                   Paragraph("Approved by", st["small"])]], colWidths=[60 * mm] * 3)
    sign.setStyle(TableStyle([("TOPPADDING", (0, 0), (-1, -1), 18 * mm)]))
    story += [t, Spacer(1, 4 * mm)]
    if m.notes:
        story.append(K.p(m.notes, st["base"]))
    story.append(sign)
    buf = io.BytesIO()
    name = m.issue_number or "draft-issue"
    SimpleDocTemplate(buf, pagesize=K.PAGE, leftMargin=K.MARGIN, rightMargin=K.MARGIN, topMargin=10 * mm,
                      bottomMargin=14 * mm, title=name).build(
        story, canvasmaker=K.numbered_canvas(name, "DRAFT" if m.status != "posted" else None))
    return Response(buf.getvalue(), media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="{name.replace("/", "-")}.pdf"'})


@router.get("/projects/{project_id}/issuable")
def issuable(project_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("material_issue.create")],
             warehouse_id: uuid.UUID | None = None):
    """The project's BOQ material: approved, issued, left to issue, and stock in the chosen store."""
    prj = projects.get(db, project_id)
    service.issue_check(p, prj, "create")
    wh = db.get(Warehouse, warehouse_id) if warehouse_id else service._default_warehouse(db, prj)
    lines = [b for b in projects.boq_lines(db, prj.id) if b.item_id]
    items = {i.id: i for i in db.scalars(select(Item).where(Item.id.in_({b.item_id for b in lines})))} if lines else {}
    out = []
    for b in lines:
        it = items[b.item_id]
        if it.item_type == "service":
            continue
        out.append({"boq_line_id": str(b.id), "line_no": b.line_no, "item_id": str(it.id), "item_code": it.item_code,
                    "item_name": it.item_name, "unit": it.unit.code, "serial": it.serial_number_required,
                    "batch": it.batch_required, "approved_qty": _q(b.approved_qty), "issued_qty": _q(b.issued_qty),
                    "left_qty": _q(max(b.approved_qty - b.issued_qty, Decimal(0))),
                    "available": _q(ledger.available(db, it.id, wh.id)) if wh else None})
    return ok({"warehouse": {"id": str(wh.id), "name": wh.name} if wh else None, "lines": out})


@router.get("/projects/{project_id}/returnable")
def returnable(project_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("material_issue.create")]):
    prj = projects.get(db, project_id)
    service.issue_check(p, prj, "create")
    wh = service._default_warehouse(db, prj)
    return ok({"warehouse": {"id": str(wh.id), "name": wh.name} if wh else None,
               "lines": service.returnable(db, prj.id)})


# ------------------------------------------------------------------ cost ledger & profitability
def entry_out(e, names: dict) -> dict:
    return {"id": str(e.id), "cost_date": _d(e.cost_date), "cost_head": e.cost_head, "amount": str(e.amount),
            "quantity": _q(e.quantity) if e.quantity is not None else None, "unit": e.unit,
            "source_type": e.source_type, "source_id": str(e.source_id) if e.source_id else None,
            "source_number": e.source_number, "party": e.party, "description": e.description,
            "reverses_id": str(e.reverses_id) if e.reverses_id else None, "created_by": names.get(e.created_by),
            "created_at": e.created_at.isoformat()}


@router.get("/projects/{project_id}/costs")
def project_costs(project_id: uuid.UUID, db: DbSession, p: CurrentUser, params: Annotated[ListParams, Depends()],
                  head: str | None = None):
    from app.costing.models import ProjectCostEntry

    prj = projects.get(db, project_id)
    service.check(p, prj, "read")
    rows, meta = service.list_costs(db, prj.id, params, head)
    names = dict(db.execute(select(User.id, User.full_name).where(User.id.in_({r.created_by for r in rows}))).all()) \
        if rows else {}
    reversed_ids = set(db.scalars(select(ProjectCostEntry.reverses_id).where(
        ProjectCostEntry.reverses_id.in_([r.id for r in rows])))) if rows else set()
    data = []
    for r in rows:
        o = entry_out(r, names)
        o["reversed"] = r.id in reversed_ids
        o["can_reverse"] = (r.source_type == "manual" and r.reverses_id is None and r.id not in reversed_ids
                            and service.allowed(p, prj, "create"))
        data.append(o)
    return {"data": data, "meta": meta.model_dump()}


@router.post("/projects/{project_id}/costs", status_code=201)
def add_cost(project_id: uuid.UUID, body: CostEntryIn, db: DbSession, p: CurrentUser):
    e = service.add_manual(db, p, project_id, body)
    return ok(entry_out(e, {p.id: p.user.full_name}))


@router.post("/project-costs/{entry_id}/reverse")
def reverse_cost(entry_id: uuid.UUID, body: ReasonIn, db: DbSession, p: CurrentUser):
    if not (body.reason and body.reason.strip()):
        from app.core.errors import AppError

        raise AppError("REASON_REQUIRED", "Say why the entry is reversed.", details={"field": "reason"})
    return ok(entry_out(service.reverse_manual(db, p, entry_id, body.reason), {p.id: p.user.full_name}))


@router.get("/projects/{project_id}/profitability")
def project_profitability(project_id: uuid.UUID, db: DbSession, p: CurrentUser):
    prj = projects.get(db, project_id)
    service.check(p, prj, "read")
    return ok(service.profitability(db, prj) | {"can": {"budget": projects.allowed(p, prj, "update"),
                                                        "add_cost": service.allowed(p, prj, "create")}})


@router.put("/projects/{project_id}/budget")
def set_budget(project_id: uuid.UUID, body: BudgetIn, db: DbSession, p: CurrentUser):
    service.set_budget(db, p, project_id, body)
    prj = projects.get(db, project_id)
    return ok(service.profitability(db, prj))


@router.get("/project-profitability")
def profitability_list(db: DbSession, p: Annotated[Principal, require("project_cost.read")],
                       status: str | None = Query("open")):
    return ok(service.profitability_list(db, p, status=status or None))


PROFIT_COLUMNS = [
    excel.Column("project_number", "Project", 22), excel.Column("name", "Name", 34), excel.Column("status", "Status", 12),
    excel.Column("contract_value", "Contract (₹)", 15), excel.Column("billed", "Billed (₹)", 15),
    *[excel.Column(f"{h}_cost", f"{h.title()} (₹)", 13) for h in COST_HEADS],
    excel.Column("actual_cost", "Actual cost (₹)", 15), excel.Column("estimated_cost", "Estimated cost (₹)", 15),
    excel.Column("actual_profit", "Gross profit (₹)", 15), excel.Column("actual_margin_pct", "Margin %", 10),
    excel.Column("estimated_margin_pct", "Est. margin %", 11),
]


@router.get("/project-profitability/export")
def profitability_export(db: DbSession, p: Annotated[Principal, require("project_cost.export")],
                         status: str | None = Query("open")):
    rows = service.profitability_list(db, p, status=status or None)
    data = [{k: (Decimal(v) if isinstance(v, str) and k not in ("project_number", "name", "status", "id") else v)
             for k, v in r.items()} for r in rows]
    audit.record(db, action="export", entity_type="project_cost", summary=f"Profitability of {len(data)} projects")
    return Response(excel.export("Project profitability", PROFIT_COLUMNS, data), media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="project-profitability.xlsx"'})
