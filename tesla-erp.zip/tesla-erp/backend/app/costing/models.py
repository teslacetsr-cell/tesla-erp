"""Project costing (Spec §20, §24, §44): material issue to projects, material returns, the project cost ledger and
cost budgets.

- A **material issue** takes stock out of a store for a project. It is checked against the stock available and
  against the project BOQ (issuing more than the BOQ needs is flagged as *excess*), goes for approval when a rule
  applies, and when posted moves stock out at weighted average cost and adds exactly that value to the project's
  material cost — all in one transaction.
- A **material return** brings unused material back from the project into a store at the project's own average issue
  cost, and reduces the project's material cost by the same value.
- The **project cost ledger** is append-only: every cost a project carries is one row (material, labour,
  subcontract, travel, other), written by issues/returns, approved expense claims, supplier bills booked to a
  project, labour from attendance (Phase 8) and manual labour / subcontract entries. Corrections are reversing rows.
"""
import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, String, Text, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.models import AuditColumnsMixin, Base
from app.core.money import AMOUNT, QTY, RATE

Z = Decimal("0")
COST_HEADS = ("material", "labour", "subcontract", "travel", "other")
ISSUE_STATUSES = ("draft", "pending_approval", "posted", "cancelled")
ISSUE_KINDS = ("issue", "return")


def _in(col: str, values: tuple[str, ...]) -> str:
    return f"{col} in ({', '.join(repr(v) for v in values)})"


class MaterialIssue(AuditColumnsMixin, Base):
    __tablename__ = "material_issues"
    __table_args__ = (CheckConstraint(_in("status", ISSUE_STATUSES), name="status_valid"),
                      CheckConstraint(_in("kind", ISSUE_KINDS), name="kind_valid"),
                      Index("ix_material_issues_project", "project_id"), Index("ix_material_issues_status", "status"))

    issue_number: Mapped[str | None] = mapped_column(String(30), unique=True)
    kind: Mapped[str] = mapped_column(String(10), nullable=False, default="issue", server_default="issue")
    issue_date: Mapped[date] = mapped_column(Date, nullable=False)
    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"), nullable=False)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("warehouses.id", ondelete="RESTRICT"), nullable=False)
    material_request_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("material_requests.id",
                                                                             ondelete="SET NULL"))
    issued_to: Mapped[str | None] = mapped_column(String(150))
    notes: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="draft", server_default="draft")
    status_reason: Mapped[str | None] = mapped_column(String(500))
    last_rejection: Mapped[str | None] = mapped_column(String(500))
    has_excess: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    estimated_value: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")
    value: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Z, server_default="0")  # posted, at cost
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    posted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    lines: Mapped[list["MaterialIssueLine"]] = relationship(order_by="MaterialIssueLine.line_no",
                                                            cascade="all, delete-orphan", lazy="selectin")


class MaterialIssueLine(AuditColumnsMixin, Base):
    __tablename__ = "material_issue_lines"
    __table_args__ = (CheckConstraint("quantity > 0", name="qty_positive"),)

    issue_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("material_issues.id", ondelete="CASCADE"), nullable=False,
                                                index=True)
    line_no: Mapped[int] = mapped_column(Integer, nullable=False)
    item_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("items.id", ondelete="RESTRICT"), nullable=False)
    quantity: Mapped[Decimal] = mapped_column(QTY, nullable=False)
    project_boq_line_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("project_boq_lines.id",
                                                                             ondelete="SET NULL"))
    batch_no: Mapped[str | None] = mapped_column(String(60))
    serial_nos: Mapped[list] = mapped_column(JSONB, nullable=False, default=list, server_default="[]")
    excess_qty: Mapped[Decimal] = mapped_column(QTY, nullable=False, default=Z, server_default="0")
    unit_cost: Mapped[Decimal | None] = mapped_column(RATE)       # filled when posted
    value: Mapped[Decimal | None] = mapped_column(AMOUNT)
    remarks: Mapped[str | None] = mapped_column(String(300))


class ProjectCostEntry(Base):
    """One cost on one project. Append-only; a correction is a reversing entry (`reverses_id`)."""

    __tablename__ = "project_cost_entries"
    __table_args__ = (CheckConstraint(_in("cost_head", COST_HEADS), name="head_valid"),
                      Index("ix_project_cost_entries_project", "project_id", "cost_date"),
                      Index("ix_project_cost_entries_source", "source_type", "source_id"))

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4, server_default=text("gen_random_uuid()"))
    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"), nullable=False)
    cost_date: Mapped[date] = mapped_column(Date, nullable=False)
    cost_head: Mapped[str] = mapped_column(String(15), nullable=False)
    amount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False)         # negative for returns / reversals
    quantity: Mapped[Decimal | None] = mapped_column(QTY)
    unit: Mapped[str | None] = mapped_column(String(20))
    item_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("items.id", ondelete="RESTRICT"))
    source_type: Mapped[str] = mapped_column(String(30), nullable=False)
    source_id: Mapped[uuid.UUID | None] = mapped_column()
    source_number: Mapped[str | None] = mapped_column(String(40))
    party: Mapped[str | None] = mapped_column(String(200))                  # subcontractor / supplier / "labour"
    description: Mapped[str] = mapped_column(String(500), nullable=False)
    reverses_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("project_cost_entries.id", ondelete="RESTRICT"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=text("now()"))
    created_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))


class ProjectBudget(AuditColumnsMixin, Base):
    """Estimated cost per head, for estimated-vs-actual. Material defaults to the BOQ at item purchase prices."""

    __tablename__ = "project_budgets"
    __table_args__ = (CheckConstraint(_in("cost_head", COST_HEADS), name="head_valid"),
                      Index("uq_project_budgets_head", "project_id", "cost_head", unique=True))

    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    cost_head: Mapped[str] = mapped_column(String(15), nullable=False)
    amount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False)
    notes: Mapped[str | None] = mapped_column(String(300))
