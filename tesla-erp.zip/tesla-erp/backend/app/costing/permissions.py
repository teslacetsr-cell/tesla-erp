from app.core.permissions import register

# 'own' scope: projects the user manages or belongs to.
register("material_issue", "Material issue to projects and returns from them (approve = pass issues for posting)",
         ("create", "read", "update", "delete", "approve", "export", "print"), scoped=("create", "read"))
register("project_cost", "Project cost ledger and profitability (create = manual labour / subcontract / other costs)",
         ("create", "read", "export"), scoped=("create", "read"))
