"""Material issue / return and the project cost ledger (Spec §20, §24, §44)."""
import uuid
from collections import defaultdict
from datetime import date
from decimal import Decimal

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.core.api import ListParams, paginate
from app.core.errors import AppError, Forbidden, NotFound
from app.core.models import check_row_version
from app.core.money import round_amount, round_qty, round_rate
from app.costing.models import COST_HEADS, MaterialIssue, MaterialIssueLine, ProjectBudget, ProjectCostEntry
from app.crm.service import now, today
from app.inventory import ledger
from app.inventory.models import StockTransaction
from app.platform.approvals import service as approvals
from app.platform.audit import service as audit
from app.platform.notifications.service import notify, users_with_roles
from app.platform.numbering import service as numbering
from app.products.models import Item, Warehouse
from app.projects import service as projects
from app.projects.models import Project, ProjectBoqLine

Z = Decimal("0")
CLOSED = ("completed", "cancelled")


def _q(v: Decimal) -> str:
    return f"{round_qty(v).normalize():f}"


# ================================================================== the project cost ledger
def record(db: Session, *, project_id: uuid.UUID, cost_head: str, amount: Decimal, description: str,
           source_type: str, source_id: uuid.UUID | None, source_number: str | None, cost_date: date,
           user_id: uuid.UUID | None, quantity: Decimal | None = None, unit: str | None = None,
           item_id: uuid.UUID | None = None, party: str | None = None,
           reverses_id: uuid.UUID | None = None) -> ProjectCostEntry | None:
    amount = round_amount(amount)
    if amount == 0:
        return None
    if cost_head not in COST_HEADS:
        raise AppError("INVALID_COST_HEAD", f"Unknown cost head {cost_head}.")
    e = ProjectCostEntry(project_id=project_id, cost_date=cost_date, cost_head=cost_head, amount=amount,
                         quantity=quantity, unit=unit, item_id=item_id, source_type=source_type, source_id=source_id,
                         source_number=source_number, party=party and party[:200], description=description[:500],
                         reverses_id=reverses_id, created_by=user_id)
    db.add(e)
    db.flush()
    return e


def reverse_source(db: Session, *, source_type: str, source_id: uuid.UUID, reason: str, user_id: uuid.UUID | None,
                   cost_date: date | None = None) -> int:
    """Reverse every not-yet-reversed cost row a document wrote (cancelled expense, cancelled bill …)."""
    reversed_ids = select(ProjectCostEntry.reverses_id).where(ProjectCostEntry.reverses_id.is_not(None))
    rows = db.scalars(select(ProjectCostEntry).where(
        ProjectCostEntry.source_type == source_type, ProjectCostEntry.source_id == source_id,
        ProjectCostEntry.reverses_id.is_(None), ProjectCostEntry.id.not_in(reversed_ids))).all()
    for r in rows:
        record(db, project_id=r.project_id, cost_head=r.cost_head, amount=-r.amount,
               description=f"Reversed: {reason}"[:500], source_type=r.source_type, source_id=r.source_id,
               source_number=r.source_number, cost_date=cost_date or today(), user_id=user_id,
               quantity=-r.quantity if r.quantity is not None else None, unit=r.unit, item_id=r.item_id,
               party=r.party, reverses_id=r.id)
    return len(rows)


def costs_by_head(db: Session, project_id: uuid.UUID) -> dict[str, Decimal]:
    out = {h: Z for h in COST_HEADS}
    for head, amt in db.execute(select(ProjectCostEntry.cost_head, func.sum(ProjectCostEntry.amount))
                                .where(ProjectCostEntry.project_id == project_id)
                                .group_by(ProjectCostEntry.cost_head)).all():
        out[head] = Decimal(amt)
    return out


# ------------------------------------------------------------------ manual entries (labour, subcontract, other)
def _project_for_cost(db: Session, p: Principal, project_id: uuid.UUID, action: str) -> Project:
    prj = projects.get(db, project_id)
    check(p, prj, action)
    return prj


def check(p: Principal, prj: Project, action: str) -> None:
    """project_cost.<action> with 'own' = projects the user manages or belongs to."""
    scope = p.scope(f"project_cost.{action}")
    if scope is None:
        raise Forbidden()
    if scope == "own" and not projects._is_team(p, prj):
        raise Forbidden("You can only see costs of projects you manage or belong to.", code="OUT_OF_SCOPE")


def allowed(p: Principal, prj: Project, action: str) -> bool:
    try:
        check(p, prj, action)
        return True
    except Forbidden:
        return False


def add_manual(db: Session, p: Principal, project_id: uuid.UUID, data) -> ProjectCostEntry:
    prj = _project_for_cost(db, p, project_id, "create")
    if prj.status == "cancelled":
        raise AppError("PROJECT_CANCELLED", "This project is cancelled.")
    if data.cost_head == "material":
        raise AppError("USE_MATERIAL_ISSUE", "Material cost comes from material issues (Inventory → Material issues).")
    if data.cost_date > today():
        raise AppError("FUTURE_DATE", "The date cannot be in the future.", details={"field": "cost_date"})
    e = record(db, project_id=prj.id, cost_head=data.cost_head, amount=data.amount, description=data.description,
               source_type="manual", source_id=None, source_number=data.reference, cost_date=data.cost_date,
               user_id=p.id, quantity=data.quantity, unit=data.unit, party=data.party)
    audit.record(db, action="cost_entry", entity_type="project", entity_id=prj.id, entity_label=prj.project_number,
                 summary=f"{data.cost_head.title()} ₹{e.amount}: {data.description}")
    return e


def reverse_manual(db: Session, p: Principal, entry_id: uuid.UUID, reason: str) -> ProjectCostEntry:
    e = db.get(ProjectCostEntry, entry_id)
    if e is None:
        raise NotFound("cost_entry")
    prj = _project_for_cost(db, p, e.project_id, "create")
    if e.source_type != "manual" or e.reverses_id is not None:
        raise AppError("NOT_MANUAL", "Only a manual entry can be reversed here; others follow their document.")
    if db.scalar(select(ProjectCostEntry.id).where(ProjectCostEntry.reverses_id == e.id)):
        raise AppError("ALREADY_REVERSED", "This entry is already reversed.")
    r = record(db, project_id=e.project_id, cost_head=e.cost_head, amount=-e.amount,
               description=f"Reversed: {reason}", source_type="manual", source_id=None,
               source_number=e.source_number, cost_date=today(), user_id=p.id,
               quantity=-e.quantity if e.quantity is not None else None, unit=e.unit, party=e.party, reverses_id=e.id)
    audit.record(db, action="cost_reversal", entity_type="project", entity_id=prj.id, entity_label=prj.project_number,
                 summary=f"Reversed {e.cost_head} ₹{e.amount}: {reason}")
    return r


def list_costs(db: Session, project_id: uuid.UUID, params: ListParams, head: str | None = None):
    stmt = select(ProjectCostEntry).where(ProjectCostEntry.project_id == project_id)
    if head:
        stmt = stmt.where(ProjectCostEntry.cost_head == head)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(ProjectCostEntry.description.ilike(like), ProjectCostEntry.source_number.ilike(like),
                              ProjectCostEntry.party.ilike(like)))
    return paginate(db, stmt, params, default_sort=ProjectCostEntry.created_at.desc(), sortable={
        "cost_date": ProjectCostEntry.cost_date, "amount": ProjectCostEntry.amount,
        "created_at": ProjectCostEntry.created_at})


# ------------------------------------------------------------------ budgets & profitability
def boq_material_estimate(db: Session, project_id: uuid.UUID) -> tuple[Decimal, int]:
    lines = projects.boq_lines(db, project_id)
    ids = {ln.item_id for ln in lines} - {None}
    items = {i.id: i for i in db.scalars(select(Item).where(Item.id.in_(ids)))} if ids else {}
    est, uncosted = Z, 0
    for ln in lines:
        it = items.get(ln.item_id)
        if it is None or it.item_type == "service" or it.purchase_price is None:
            if it is None or it.item_type != "service":
                uncosted += 1
            continue
        est += ln.approved_qty * it.purchase_price
    return round_amount(est), uncosted


def set_budget(db: Session, p: Principal, project_id: uuid.UUID, data) -> None:
    prj = projects.get(db, project_id, lock=True)
    projects.check(p, prj, "update")
    before = {b.cost_head: str(b.amount) for b in db.scalars(select(ProjectBudget).where(ProjectBudget.project_id == prj.id))}
    for head in COST_HEADS:
        val = getattr(data, head)
        row = db.scalar(select(ProjectBudget).where(ProjectBudget.project_id == prj.id, ProjectBudget.cost_head == head))
        if val is None:
            if row is not None:
                db.delete(row)
            continue
        if row is None:
            db.add(ProjectBudget(project_id=prj.id, cost_head=head, amount=round_amount(val), created_by=p.id,
                                 updated_by=p.id))
        else:
            row.amount, row.updated_by = round_amount(val), p.id
    db.flush()
    after = {b.cost_head: str(b.amount) for b in db.scalars(select(ProjectBudget).where(ProjectBudget.project_id == prj.id))}
    audit.record(db, action="budget", entity_type="project", entity_id=prj.id, entity_label=prj.project_number,
                 summary="Cost budget updated", before=before, after=after)


def profitability(db: Session, prj: Project) -> dict:
    """Spec §24: revenue − (material + labour + subcontract + travel + other) = gross profit, estimated vs actual."""
    from app.finance.reports import project_finance

    f = project_finance(db, prj)
    actual = costs_by_head(db, prj.id)
    budgets = {b.cost_head: b.amount for b in db.scalars(select(ProjectBudget).where(ProjectBudget.project_id == prj.id))}
    mat_est, uncosted = boq_material_estimate(db, prj.id)
    est = {h: budgets.get(h) for h in COST_HEADS}
    material_from_boq = est["material"] is None
    if material_from_boq:
        est["material"] = mat_est
    rows = []
    for h in COST_HEADS:
        e, a = est[h], actual[h]
        rows.append({"head": h, "estimated": str(e) if e is not None else None, "actual": str(a),
                     "variance": str(round_amount((e or Z) - a)) if e is not None else None,
                     "used_pct": str(round_amount(a * 100 / e)) if e else None})
    est_total = sum((v for v in est.values() if v is not None), Z)
    act_total = sum(actual.values(), Z)
    revenue_est, revenue_act = prj.contract_value, f["billed"]
    s = lambda v: str(round_amount(v))  # noqa: E731
    return {
        "heads": rows, "material_from_boq": material_from_boq, "uncosted_lines": uncosted,
        "estimated": {"revenue": s(revenue_est), "cost": s(est_total), "profit": s(revenue_est - est_total),
                      "margin_pct": s((revenue_est - est_total) * 100 / revenue_est) if revenue_est else None},
        "actual": {"revenue": s(revenue_act), "cost": s(act_total), "profit": s(revenue_act - act_total),
                   "margin_pct": s((revenue_act - act_total) * 100 / revenue_act) if revenue_act else None},
        # cost so far against the contract: how much of the estimated cost is spent, and the profit if the rest of
        # the work costs what was estimated
        "cost_to_date_pct": s(act_total * 100 / est_total) if est_total else None,
    }


def profitability_list(db: Session, p: Principal, *, status: str | None = None) -> list[dict]:
    clause = projects.scope_clause(p, "project_cost.read")
    stmt = select(Project).order_by(Project.project_number.desc())
    if clause is not None:
        stmt = stmt.where(clause)
    if status == "open":
        stmt = stmt.where(Project.status.not_in(CLOSED))
    elif status:
        stmt = stmt.where(Project.status == status)
    out = []
    for prj in db.scalars(stmt.limit(500)):
        pr = profitability(db, prj)
        out.append({"id": str(prj.id), "project_number": prj.project_number, "name": prj.name, "status": prj.status,
                    "contract_value": str(prj.contract_value), "progress_pct": prj.progress_pct,
                    "billed": pr["actual"]["revenue"], "actual_cost": pr["actual"]["cost"],
                    "estimated_cost": pr["estimated"]["cost"], "actual_profit": pr["actual"]["profit"],
                    "actual_margin_pct": pr["actual"]["margin_pct"], "estimated_margin_pct": pr["estimated"]["margin_pct"],
                    "cost_to_date_pct": pr["cost_to_date_pct"],
                    **{f"{h['head']}_cost": h["actual"] for h in pr["heads"]}})
    return out


# ================================================================== material issue & return
def get_issue(db: Session, iid: uuid.UUID, lock: bool = False) -> MaterialIssue:
    m = db.get(MaterialIssue, iid, with_for_update=lock or None)
    if m is None:
        raise NotFound("material_issue")
    return m


def issue_check(p: Principal, prj: Project, action: str) -> None:
    scope = p.scope(f"material_issue.{action}")
    if scope is None:
        raise Forbidden()
    if scope == "own" and not projects._is_team(p, prj):
        raise Forbidden("Only the project team (or the store) can issue material to this project.",
                        code="OUT_OF_SCOPE")


def _label(m: MaterialIssue) -> str:
    return m.issue_number or f"Draft {'return' if m.kind == 'return' else 'issue'}"


def _default_warehouse(db: Session, prj: Project) -> Warehouse | None:
    return db.scalar(select(Warehouse).where(Warehouse.project_id == prj.id, Warehouse.is_active.is_(True))) or \
        db.scalar(select(Warehouse).where(Warehouse.code == "MAIN", Warehouse.is_active.is_(True)))


def issued_net(db: Session, project_id: uuid.UUID, item_ids) -> dict[uuid.UUID, tuple[Decimal, Decimal]]:
    """Per item: (net quantity issued to the project, net value) from the stock ledger."""
    ids = list(item_ids)
    if not ids:
        return {}
    rows = db.execute(select(StockTransaction.item_id, -func.sum(StockTransaction.quantity), -func.sum(StockTransaction.value))
                      .where(StockTransaction.project_id == project_id, StockTransaction.txn_type.in_(("issue", "return")),
                             StockTransaction.item_id.in_(ids))
                      .group_by(StockTransaction.item_id)).all()
    return {i: (Decimal(q), Decimal(v)) for i, q, v in rows}


def _fill(db: Session, p: Principal, m: MaterialIssue, data) -> None:
    prj = projects.get(db, data.project_id)
    issue_check(p, prj, "create")
    if prj.status in CLOSED or prj.status == "on_hold" and m.kind == "issue":
        raise AppError("PROJECT_NOT_OPEN", f"Project {prj.project_number} is {prj.status.replace('_', ' ')}.")
    wh = db.get(Warehouse, data.warehouse_id) if data.warehouse_id else _default_warehouse(db, prj)
    if wh is None or not wh.is_active:
        raise AppError("INVALID_WAREHOUSE", "Choose an active store.", details={"field": "warehouse_id"})
    ids = {ln.item_id for ln in data.lines}
    items = {i.id: i for i in db.scalars(select(Item).where(Item.id.in_(ids)))}
    if ids - set(items):
        raise NotFound("item")
    boq = {ln.id: ln for ln in projects.boq_lines(db, prj.id)}
    for n, ln in enumerate(data.lines, start=1):
        it = items[ln.item_id]
        ledger.check_item_rules(it, round_qty(ln.quantity), ln.batch_no, ledger.clean_serials(ln.serial_nos), f"Line {n}")
        if ln.project_boq_line_id and ln.project_boq_line_id not in boq:
            raise AppError("INVALID_BOQ_LINE", f"Line {n}: that BOQ line is not on {prj.project_number}.")
    m.project_id, m.warehouse_id = prj.id, wh.id
    m.issue_date = data.issue_date or m.issue_date or today()
    if m.issue_date > today():
        raise AppError("FUTURE_DATE", "The date cannot be in the future.", details={"field": "issue_date"})
    m.issued_to, m.notes, m.material_request_id, m.updated_by = data.issued_to, data.notes, data.material_request_id, p.id
    m.lines.clear()
    db.flush()
    for n, ln in enumerate(data.lines, start=1):
        boq_id = ln.project_boq_line_id
        if boq_id is None:  # link to the project's BOQ line for the same item, when there is exactly one
            same = [b for b in boq.values() if b.item_id == ln.item_id]
            boq_id = same[0].id if len(same) == 1 else None
        m.lines.append(MaterialIssueLine(line_no=n, item_id=ln.item_id, quantity=round_qty(ln.quantity),
                                         project_boq_line_id=boq_id, batch_no=ln.batch_no,
                                         serial_nos=ledger.clean_serials(ln.serial_nos), remarks=ln.remarks,
                                         created_by=p.id, updated_by=p.id))
    _assess(db, m)


def _assess(db: Session, m: MaterialIssue) -> None:
    """Excess against the project BOQ (Spec §21 'excess issue') and the estimated value at today's average cost."""
    if m.kind == "return":
        m.has_excess, m.estimated_value = False, Z
        return
    boq = {ln.id: ln for ln in projects.boq_lines(db, m.project_id)}
    asked: dict[uuid.UUID, Decimal] = defaultdict(lambda: Z)
    est = Z
    for ln in m.lines:
        avg = ledger.average_cost(db, ln.item_id, m.warehouse_id)
        if avg is None:
            it = db.get(Item, ln.item_id)
            avg = it.purchase_price or Z
        est += ln.quantity * avg
        ln.excess_qty = Z
        if ln.project_boq_line_id:
            asked[ln.project_boq_line_id] += ln.quantity
    for bid, qty in asked.items():
        b = boq[bid]
        left = max(b.approved_qty - b.issued_qty, Z)
        over = qty - left
        if over > 0:
            # put the excess on the last line(s) of that BOQ line
            for ln in reversed([x for x in m.lines if x.project_boq_line_id == bid]):
                take = min(over, ln.quantity)
                ln.excess_qty, over = take, over - take
                if over <= 0:
                    break
    for ln in m.lines:
        if ln.project_boq_line_id is None:
            ln.excess_qty = ln.quantity  # not in the project's BOQ at all
    m.has_excess = any(ln.excess_qty > 0 for ln in m.lines)
    m.estimated_value = round_amount(est)


def create_issue(db: Session, p: Principal, data, kind: str = "issue") -> MaterialIssue:
    m = MaterialIssue(kind=kind, status="draft", issue_date=data.issue_date or today(), project_id=data.project_id,
                      warehouse_id=data.warehouse_id or uuid.uuid4(), created_by=p.id, updated_by=p.id)
    _fill(db, p, m, data)
    db.add(m)
    db.flush()
    audit.record(db, action="create", entity_type="material_issue", entity_id=m.id, entity_label=_label(m),
                 summary=f"{len(m.lines)} lines" + (" — some beyond the BOQ" if m.has_excess else ""))
    if kind == "return":
        _post_return(db, p, m)
    elif data.submit:
        submit_issue(db, p, m.id, None)
    return m


def update_issue(db: Session, p: Principal, iid: uuid.UUID, data) -> MaterialIssue:
    m = get_issue(db, iid, lock=True)
    if m.status != "draft" or m.kind != "issue":
        raise AppError("NOT_DRAFT", "Only a draft issue can be changed.")
    check_row_version(m, data.row_version)
    _fill(db, p, m, data)
    db.flush()
    audit.record(db, action="update", entity_type="material_issue", entity_id=m.id, entity_label=_label(m),
                 summary=f"{len(m.lines)} lines")
    if data.submit:
        submit_issue(db, p, m.id, None)
    return m


def _check_stock(db: Session, m: MaterialIssue) -> None:
    need: dict[uuid.UUID, Decimal] = defaultdict(lambda: Z)
    for ln in m.lines:
        need[ln.item_id] += ln.quantity
    wh = db.get(Warehouse, m.warehouse_id)
    if ledger.negative_allowed(db, wh):
        return
    for item_id, qty in need.items():
        have = ledger.available(db, item_id, m.warehouse_id)
        if have < qty:
            it = db.get(Item, item_id)
            raise AppError("INSUFFICIENT_STOCK", f"{it.item_name}: only {_q(have)} {it.unit.code} in {wh.name}; "
                                                 f"{_q(qty)} needed.",
                           details={"item_id": str(item_id), "available": str(have)}, status_code=409)


def submit_issue(db: Session, p: Principal, iid: uuid.UUID, row_version: int | None) -> MaterialIssue:
    m = get_issue(db, iid, lock=True)
    prj = projects.get(db, m.project_id)
    issue_check(p, prj, "create")
    if m.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft can be submitted.")
    if row_version is not None:
        check_row_version(m, row_version)
    else:
        m.row_version += 1
    _assess(db, m)
    _check_stock(db, m)  # Spec §20: the system checks available stock
    m.issue_number = m.issue_number or numbering.next_number(db, p.company_id, "MI", on=m.issue_date)
    m.submitted_at, m.last_rejection, m.updated_by = now(), None, p.id
    req = approvals.start(db, p, entity_type="material_issue", entity_id=m.id,
                          label=f"{m.issue_number} · {prj.project_number}" + (" · beyond BOQ" if m.has_excess else ""),
                          amount=m.estimated_value, division_id=prj.division_id)
    if req is None:
        _post_issue(db, p, m)
    else:
        m.status = "pending_approval"
    db.flush()
    audit.record(db, action="submit", entity_type="material_issue", entity_id=m.id, entity_label=m.issue_number,
                 summary=("Posted — no approval rule applies" if req is None else "Sent for approval")
                 + (" (includes quantities beyond the BOQ)" if m.has_excess else ""))
    return m


def _post_issue(db: Session, p: Principal, m: MaterialIssue) -> None:
    """Spec §44: validate stock → stock transaction → balance → project cost → audit, all in this one transaction.
    Any failure raises and the whole request rolls back (nothing half-done)."""
    prj = projects.get(db, m.project_id)
    if prj.status in CLOSED:
        raise AppError("PROJECT_NOT_OPEN", f"Project {prj.project_number} is {prj.status}.")
    wh = db.get(Warehouse, m.warehouse_id)
    items = {i.id: i for i in db.scalars(select(Item).where(Item.id.in_({ln.item_id for ln in m.lines})))}
    total = Z
    for ln in sorted(m.lines, key=lambda x: (str(x.item_id), x.line_no)):  # fixed lock order
        it = items[ln.item_id]
        txn = ledger.post(db, ledger.Movement(it, wh, -ln.quantity, batch_no=ln.batch_no,
                                              serial_nos=tuple(ln.serial_nos), source_line_id=ln.id,
                                              remarks=f"Issued to {prj.project_number}"),
                          txn_type="issue", source_type="material_issue", source_id=m.id,
                          source_number=m.issue_number, txn_date=m.issue_date, user_id=p.id, project_id=prj.id,
                          label=f"Line {ln.line_no} ({it.item_name})")
        ln.unit_cost, ln.value = txn.unit_cost, -txn.value
        total += ln.value
        if ln.project_boq_line_id:
            b = db.get(ProjectBoqLine, ln.project_boq_line_id, with_for_update=True)
            b.issued_qty += ln.quantity
        record(db, project_id=prj.id, cost_head="material", amount=ln.value,
               description=f"{it.item_name} × {_q(ln.quantity)} {it.unit.code} from {wh.name}",
               source_type="material_issue", source_id=m.id, source_number=m.issue_number, cost_date=m.issue_date,
               user_id=p.id, quantity=ln.quantity, unit=it.unit.code, item_id=it.id)
    m.value, m.status, m.posted_at, m.updated_by = round_amount(total), "posted", now(), p.id
    db.flush()
    audit.record(db, action="post", entity_type="material_issue", entity_id=m.id, entity_label=m.issue_number,
                 summary=f"{len(m.lines)} lines from {wh.name} to {prj.project_number}; material cost +₹{m.value}")
    if prj.project_manager_id and prj.project_manager_id != p.id:
        notify(db, [prj.project_manager_id], event="material_issue.posted",
               title=f"Material issued to {prj.project_number}: ₹{m.value}", body=f"{m.issue_number} · {wh.name}",
               link=f"/inventory/issues/view?id={m.id}")


def _on_approved(db: Session, p: Principal, req) -> None:
    m = get_issue(db, req.entity_id, lock=True)
    if m.status != "pending_approval":
        return
    _assess(db, m)
    _post_issue(db, p, m)  # stock is checked again here; if it has run out, the approval fails and stays pending
    m.row_version += 1


def _on_rejected(db: Session, p: Principal, req, comment: str) -> None:
    m = get_issue(db, req.entity_id, lock=True)
    m.status, m.last_rejection = "draft", comment[:500]
    m.row_version += 1


approvals.register("material_issue", approvals.Handler(
    label="Material issue", href=lambda i: f"/inventory/issues/view?id={i}", on_approved=_on_approved,
    on_rejected=_on_rejected,
    owners=lambda db, i: [x for x in [db.scalar(select(MaterialIssue.created_by).where(MaterialIssue.id == i))] if x]))


def withdraw_issue(db: Session, p: Principal, iid: uuid.UUID) -> MaterialIssue:
    m = get_issue(db, iid, lock=True)
    if m.status != "pending_approval":
        raise AppError("INVALID_TRANSITION", "Only an issue waiting for approval can be withdrawn.")
    approvals.withdraw(db, p, "material_issue", m.id)
    m.status, m.updated_by = "draft", p.id
    m.row_version += 1
    db.flush()
    audit.record(db, action="withdraw", entity_type="material_issue", entity_id=m.id, entity_label=_label(m))
    return m


def cancel_issue(db: Session, p: Principal, iid: uuid.UUID, reason: str | None) -> MaterialIssue:
    m = get_issue(db, iid, lock=True)
    if m.status not in ("draft", "pending_approval"):
        raise AppError("INVALID_TRANSITION", "A posted issue cannot be cancelled — return the material instead.")
    approvals.withdraw(db, p, "material_issue", m.id)
    m.status, m.status_reason, m.updated_by = "cancelled", (reason or "")[:500] or None, p.id
    m.row_version += 1
    db.flush()
    audit.record(db, action="cancel", entity_type="material_issue", entity_id=m.id, entity_label=_label(m),
                 summary=reason)
    return m


def delete_issue(db: Session, p: Principal, iid: uuid.UUID) -> None:
    m = get_issue(db, iid, lock=True)
    if m.status != "draft" or m.issue_number:
        raise AppError("NOT_DRAFT", "Only an unnumbered draft can be deleted.")
    lbl = _label(m)
    db.delete(m)
    db.flush()
    audit.record(db, action="delete", entity_type="material_issue", entity_id=iid, entity_label=lbl)


def _post_return(db: Session, p: Principal, m: MaterialIssue) -> None:
    """Unused material back from the project into a store, at the project's own average issue cost."""
    prj = projects.get(db, m.project_id)
    wh = db.get(Warehouse, m.warehouse_id)
    items = {i.id: i for i in db.scalars(select(Item).where(Item.id.in_({ln.item_id for ln in m.lines})))}
    net = issued_net(db, prj.id, items.keys())
    asked: dict[uuid.UUID, Decimal] = defaultdict(lambda: Z)
    for ln in m.lines:
        asked[ln.item_id] += ln.quantity
    for item_id, qty in asked.items():
        have = net.get(item_id, (Z, Z))[0]
        if qty > have:
            raise AppError("OVER_RETURN", f"{items[item_id].item_name}: only {_q(have)} was issued to "
                                          f"{prj.project_number} (net of returns); {_q(qty)} cannot come back.",
                           details={"item_id": str(item_id)})
    m.issue_number = numbering.next_number(db, p.company_id, "MRN", on=m.issue_date)
    total = Z
    for ln in sorted(m.lines, key=lambda x: (str(x.item_id), x.line_no)):
        it = items[ln.item_id]
        q, v = net[ln.item_id]
        unit = round_rate(v / q) if q else (it.purchase_price or Z)
        value = round_amount(v) if ln.quantity == q else round_amount(ln.quantity * unit)
        txn = ledger.post(db, ledger.Movement(it, wh, ln.quantity, unit_cost=unit, value=value, batch_no=ln.batch_no,
                                              serial_nos=tuple(ln.serial_nos), source_line_id=ln.id,
                                              remarks=f"Returned from {prj.project_number}"),
                          txn_type="return", source_type="material_return", source_id=m.id,
                          source_number=m.issue_number, txn_date=m.issue_date, user_id=p.id, project_id=prj.id,
                          label=f"Line {ln.line_no} ({it.item_name})")
        ln.unit_cost, ln.value = txn.unit_cost, txn.value
        net[ln.item_id] = (q - ln.quantity, v - txn.value)
        total += txn.value
        remaining = ln.quantity
        for b in sorted([b for b in projects.boq_lines(db, prj.id) if b.item_id == it.id and b.issued_qty > 0],
                        key=lambda b: -b.line_no):
            if ln.project_boq_line_id and b.id != ln.project_boq_line_id:
                continue
            take = min(remaining, b.issued_qty)
            b.issued_qty -= take
            remaining -= take
            if remaining <= 0:
                break
        record(db, project_id=prj.id, cost_head="material", amount=-txn.value,
               description=f"Returned {it.item_name} × {_q(ln.quantity)} {it.unit.code} to {wh.name}",
               source_type="material_return", source_id=m.id, source_number=m.issue_number, cost_date=m.issue_date,
               user_id=p.id, quantity=-ln.quantity, unit=it.unit.code, item_id=it.id)
    m.value, m.status, m.posted_at, m.submitted_at = round_amount(total), "posted", now(), now()
    db.flush()
    audit.record(db, action="post", entity_type="material_issue", entity_id=m.id, entity_label=m.issue_number,
                 summary=f"Return of {len(m.lines)} lines to {wh.name}; material cost −₹{m.value}")


def list_issues(db: Session, p: Principal, params: ListParams, *, status=None, project_id=None, kind=None,
                warehouse_id=None):
    stmt = select(MaterialIssue)
    clause = projects.scope_clause(p, "material_issue.read")
    if clause is not None:
        stmt = stmt.where(MaterialIssue.project_id.in_(select(Project.id).where(clause)))
    for col, val in ((MaterialIssue.status, status), (MaterialIssue.project_id, project_id),
                     (MaterialIssue.kind, kind), (MaterialIssue.warehouse_id, warehouse_id)):
        if val:
            stmt = stmt.where(col == val)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(MaterialIssue.issue_number.ilike(like), MaterialIssue.issued_to.ilike(like),
                              MaterialIssue.project_id.in_(select(Project.id).where(or_(
                                  Project.project_number.ilike(like), Project.name.ilike(like))))))
    return paginate(db, stmt, params, default_sort=MaterialIssue.created_at.desc(), sortable={
        "issue_date": MaterialIssue.issue_date, "issue_number": MaterialIssue.issue_number,
        "value": MaterialIssue.value, "created_at": MaterialIssue.created_at})


def returnable(db: Session, project_id: uuid.UUID) -> list[dict]:
    """What can come back from a project: net issued per item."""
    rows = db.execute(select(StockTransaction.item_id, -func.sum(StockTransaction.quantity), -func.sum(StockTransaction.value))
                      .where(StockTransaction.project_id == project_id, StockTransaction.txn_type.in_(("issue", "return")))
                      .group_by(StockTransaction.item_id).having(func.sum(StockTransaction.quantity) < 0)).all()
    items = {i.id: i for i in db.scalars(select(Item).where(Item.id.in_([r[0] for r in rows])))} if rows else {}
    return [{"item_id": str(i), "item_code": items[i].item_code, "item_name": items[i].item_name,
             "unit": items[i].unit.code, "serial": items[i].serial_number_required, "batch": items[i].batch_required,
             "net_qty": _q(Decimal(q)), "value": str(round_amount(Decimal(v))),
             "avg_cost": str(round_rate(Decimal(v) / Decimal(q))) if q else None} for i, q, v in rows]


def pending_issue_count(db: Session) -> int:
    return db.scalar(select(func.count()).select_from(MaterialIssue).where(MaterialIssue.status == "pending_approval")) or 0


def tell_store(db: Session, m: MaterialIssue) -> None:
    notify(db, users_with_roles(db, ["STORE"]), event="material_issue.submitted",
           title=f"Material issue {m.issue_number} to approve/post", body="", link=f"/inventory/issues/view?id={m.id}")
