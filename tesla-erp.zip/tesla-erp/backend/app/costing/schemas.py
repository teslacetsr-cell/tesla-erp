import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import Field

from app.core.api import Schema
from app.core.validators import Text


class IssueLineIn(Schema):
    item_id: uuid.UUID
    quantity: Decimal = Field(gt=0, max_digits=18, decimal_places=3)
    project_boq_line_id: uuid.UUID | None = None
    batch_no: Text(60) = None
    serial_nos: list[str] = Field(default_factory=list, max_length=1000)
    remarks: Text(300) = None


class IssueIn(Schema):
    project_id: uuid.UUID
    warehouse_id: uuid.UUID | None = None   # default: the project's site store, else the main store
    issue_date: date | None = None
    material_request_id: uuid.UUID | None = None
    issued_to: Text(150) = None
    notes: Text(2000) = None
    lines: list[IssueLineIn] = Field(min_length=1, max_length=500)
    submit: bool = False


class IssueUpdate(IssueIn):
    row_version: int


class ReasonIn(Schema):
    reason: Text(500) = None
    row_version: int | None = None


class CostEntryIn(Schema):
    cost_head: Literal["labour", "subcontract", "travel", "other"]
    cost_date: date
    amount: Decimal = Field(gt=0, max_digits=18, decimal_places=2)
    description: str = Field(min_length=3, max_length=500)
    quantity: Decimal | None = Field(default=None, gt=0, max_digits=18, decimal_places=3)
    unit: Text(20) = None          # e.g. man-days
    party: Text(200) = None        # labour contractor / subcontractor
    reference: Text(40) = None     # bill or muster-roll number


class BudgetIn(Schema):
    material: Decimal | None = Field(default=None, ge=0, max_digits=18, decimal_places=2)
    labour: Decimal | None = Field(default=None, ge=0, max_digits=18, decimal_places=2)
    subcontract: Decimal | None = Field(default=None, ge=0, max_digits=18, decimal_places=2)
    travel: Decimal | None = Field(default=None, ge=0, max_digits=18, decimal_places=2)
    other: Decimal | None = Field(default=None, ge=0, max_digits=18, decimal_places=2)
