"""Projects (Spec §16–§18): execution of a sales order — team, milestones, tasks, issues, daily site reports and
BOQ tracking (approved → procured → issued → installed → remaining).

A project normally starts from a sales order: its BOQ lines are copied from the order lines (approved quantity and
contract rate). Procured and issued quantities are filled by purchasing and stores (Phases 5–6); installed quantity
is the sum of the installation entries recorded on site and can never exceed the approved quantity.
"""
import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, SmallInteger, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.models import AuditColumnsMixin, Base
from app.core.money import AMOUNT, QTY, RATE

PROJECT_STATUSES = ("planning", "active", "on_hold", "completed", "cancelled")
PRIORITIES = ("low", "normal", "high", "urgent")
TASK_STATUSES = ("todo", "in_progress", "blocked", "done")
ISSUE_SEVERITIES = ("low", "normal", "high", "critical")
ISSUE_STATUSES = ("open", "resolved", "closed")
CLOSED_PROJECT = ("completed", "cancelled")


def _in(col: str, values: tuple[str, ...]) -> str:
    return f"{col} in ({', '.join(repr(v) for v in values)})"


class Project(AuditColumnsMixin, Base):
    __tablename__ = "projects"
    __table_args__ = (
        CheckConstraint(_in("status", PROJECT_STATUSES), name="status_valid"),
        CheckConstraint(_in("priority", PRIORITIES), name="priority_valid"),
        CheckConstraint("progress_pct between 0 and 100", name="progress_range"),
        CheckConstraint("contract_value >= 0", name="contract_nonneg"),
        Index("ix_projects_status", "status"), Index("ix_projects_customer_id", "customer_id"),
        Index("ix_projects_sales_order_id", "sales_order_id"),
        Index("ix_projects_project_manager_id", "project_manager_id"),
    )

    project_number: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    customer_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("customers.id", ondelete="RESTRICT"), nullable=False)
    site_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("customer_sites.id", ondelete="RESTRICT"))
    sales_order_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("sales_orders.id", ondelete="RESTRICT"))
    division_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("business_divisions.id", ondelete="RESTRICT"))
    project_manager_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    description: Mapped[str | None] = mapped_column(Text)
    site_address: Mapped[str | None] = mapped_column(String(500))
    contract_value: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    start_date: Mapped[date | None] = mapped_column(Date)
    target_end_date: Mapped[date | None] = mapped_column(Date)
    actual_end_date: Mapped[date | None] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="planning", server_default="planning")
    status_reason: Mapped[str | None] = mapped_column(String(500))
    priority: Mapped[str] = mapped_column(String(10), nullable=False, default="normal", server_default="normal")
    progress_pct: Mapped[int] = mapped_column(SmallInteger, nullable=False, default=0, server_default="0")

    members: Mapped[list["ProjectMember"]] = relationship(cascade="all, delete-orphan", lazy="selectin")


class ProjectMember(AuditColumnsMixin, Base):
    __tablename__ = "project_members"
    __table_args__ = (UniqueConstraint("project_id", "user_id", name="uq_project_members_user"),
                      Index("ix_project_members_user_id", "user_id"))

    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    role: Mapped[str | None] = mapped_column(String(80))


class ProjectMilestone(AuditColumnsMixin, Base):
    __tablename__ = "project_milestones"

    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), nullable=False,
                                                  index=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    due_date: Mapped[date | None] = mapped_column(Date)
    completed_on: Mapped[date | None] = mapped_column(Date)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    notes: Mapped[str | None] = mapped_column(String(500))


class ProjectTask(AuditColumnsMixin, Base):
    __tablename__ = "project_tasks"
    __table_args__ = (
        CheckConstraint(_in("status", TASK_STATUSES), name="status_valid"),
        CheckConstraint(_in("priority", PRIORITIES), name="priority_valid"),
        Index("ix_project_tasks_project_id", "project_id"), Index("ix_project_tasks_assigned_to", "assigned_to", "status"),
    )

    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    milestone_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("project_milestones.id", ondelete="SET NULL"))
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    assigned_to: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    start_date: Mapped[date | None] = mapped_column(Date)
    due_date: Mapped[date | None] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="todo", server_default="todo")
    priority: Mapped[str] = mapped_column(String(10), nullable=False, default="normal", server_default="normal")
    blocked_reason: Mapped[str | None] = mapped_column(String(500))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class ProjectIssue(AuditColumnsMixin, Base):
    __tablename__ = "project_issues"
    __table_args__ = (
        CheckConstraint(_in("status", ISSUE_STATUSES), name="status_valid"),
        CheckConstraint(_in("severity", ISSUE_SEVERITIES), name="severity_valid"),
        Index("ix_project_issues_project_id", "project_id", "status"),
    )

    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    severity: Mapped[str] = mapped_column(String(10), nullable=False, default="normal", server_default="normal")
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="open", server_default="open")
    assigned_to: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    resolution: Mapped[str | None] = mapped_column(Text)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class SiteReport(AuditColumnsMixin, Base):
    """Daily progress report from site; photos are attached as documents (category site_photo)."""

    __tablename__ = "site_reports"
    __table_args__ = (
        CheckConstraint("progress_pct is null or progress_pct between 0 and 100", name="progress_range"),
        CheckConstraint("manpower is null or manpower >= 0", name="manpower_nonneg"),
        Index("ix_site_reports_project_date", "project_id", "report_date"),
    )

    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    report_date: Mapped[date] = mapped_column(Date, nullable=False)
    work_done: Mapped[str] = mapped_column(Text, nullable=False)
    manpower: Mapped[int | None] = mapped_column(SmallInteger)
    weather: Mapped[str | None] = mapped_column(String(60))
    hindrances: Mapped[str | None] = mapped_column(Text)
    next_plan: Mapped[str | None] = mapped_column(Text)
    progress_pct: Mapped[int | None] = mapped_column(SmallInteger)


class ProjectBoqLine(AuditColumnsMixin, Base):
    __tablename__ = "project_boq_lines"
    __table_args__ = (
        CheckConstraint("approved_qty >= 0", name="approved_nonneg"),
        CheckConstraint("installed_qty >= 0 and installed_qty <= approved_qty", name="installed_within_approved"),
        CheckConstraint("procured_qty >= 0 and issued_qty >= 0", name="material_nonneg"),
        Index("ix_project_boq_lines_project_id", "project_id", "line_no"),
    )

    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    so_line_no: Mapped[int | None] = mapped_column(Integer)  # the order line it came from; null = added on the project
    line_no: Mapped[int] = mapped_column(Integer, nullable=False)
    section: Mapped[str | None] = mapped_column(String(120))
    item_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("items.id", ondelete="RESTRICT"))
    description: Mapped[str] = mapped_column(Text, nullable=False)
    unit: Mapped[str] = mapped_column(String(20), nullable=False)
    approved_qty: Mapped[Decimal] = mapped_column(QTY, nullable=False)
    rate: Mapped[Decimal] = mapped_column(RATE, nullable=False, default=Decimal("0"), server_default="0")
    contract_amount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    procured_qty: Mapped[Decimal] = mapped_column(QTY, nullable=False, default=Decimal("0"), server_default="0")
    issued_qty: Mapped[Decimal] = mapped_column(QTY, nullable=False, default=Decimal("0"), server_default="0")
    installed_qty: Mapped[Decimal] = mapped_column(QTY, nullable=False, default=Decimal("0"), server_default="0")
    remarks: Mapped[str | None] = mapped_column(String(500))


class InstallationEntry(AuditColumnsMixin, Base):
    __tablename__ = "installation_entries"
    __table_args__ = (CheckConstraint("quantity > 0", name="qty_positive"),
                      Index("ix_installation_entries_line", "boq_line_id", "entry_date"),
                      Index("ix_installation_entries_project", "project_id", "entry_date"))

    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    boq_line_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("project_boq_lines.id", ondelete="CASCADE"), nullable=False)
    site_report_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("site_reports.id", ondelete="SET NULL"))
    entry_date: Mapped[date] = mapped_column(Date, nullable=False)
    quantity: Mapped[Decimal] = mapped_column(QTY, nullable=False)
    location: Mapped[str | None] = mapped_column(String(200))
    remarks: Mapped[str | None] = mapped_column(String(500))
