"""Project rules (Spec §16–§18)."""
import uuid
from datetime import date
from decimal import Decimal

from sqlalchemy import and_, exists, func, or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.core.api import ListParams, paginate
from app.core.errors import AppError, Conflict, Forbidden, NotFound
from app.core.models import check_row_version
from app.core.money import round_amount, round_qty
from app.crm.service import now, today
from app.customers.models import Customer, CustomerSite
from app.platform.audit import service as audit
from app.platform.notifications.service import notify
from app.platform.numbering import service as numbering
from app.products.models import Item
from app.projects.models import (
    CLOSED_PROJECT,
    InstallationEntry,
    Project,
    ProjectBoqLine,
    ProjectIssue,
    ProjectMember,
    ProjectMilestone,
    ProjectTask,
    SiteReport,
)
from app.users.models import User

ZERO = Decimal("0")


# ------------------------------------------------------------------ record-level scope
def _member_ids(prj: Project) -> set:
    return {m.user_id for m in prj.members}


def _is_team(p: Principal, prj: Project) -> bool:
    return p.id in (prj.project_manager_id, prj.created_by) or p.id in _member_ids(prj)


def check(p: Principal, prj: Project, action: str) -> None:
    scope = p.scope(f"project.{action}")
    if scope is None:
        raise Forbidden()
    if scope == "own":
        ok = _is_team(p, prj) if action == "read" else p.id in (prj.project_manager_id, prj.created_by)
        if not ok:
            raise Forbidden("You can only work on projects you manage or belong to.", code="OUT_OF_SCOPE")


def allowed(p: Principal, prj: Project, action: str) -> bool:
    try:
        check(p, prj, action)
        return True
    except Forbidden:
        return False


def check_site(p: Principal, prj: Project, action: str) -> None:
    scope = p.scope(f"site_work.{action}")
    if scope is None:
        raise Forbidden()
    if scope == "own" and not _is_team(p, prj):
        raise Forbidden("Only the project team can record site work on this project.", code="OUT_OF_SCOPE")
    if action != "read" and prj.status in CLOSED_PROJECT:
        raise AppError("PROJECT_CLOSED", f"This project is {prj.status}. Reopen it to record work.")


def site_allowed(p: Principal, prj: Project, action: str) -> bool:
    try:
        check_site(p, prj, action)
        return True
    except (Forbidden, AppError):
        return False


def scope_clause(p: Principal, code: str):
    """WHERE clause limiting Project rows to what the principal may see under permission `code`."""
    scope = p.scope(code)
    if scope is None:
        raise Forbidden()
    if scope == "all":
        return None
    return or_(Project.project_manager_id == p.id, Project.created_by == p.id,
               exists().where(and_(ProjectMember.project_id == Project.id, ProjectMember.user_id == p.id)))


def get(db: Session, project_id: uuid.UUID, lock: bool = False) -> Project:
    prj = db.get(Project, project_id, with_for_update=lock or None)
    if prj is None:
        raise NotFound("project")
    return prj


def _label(prj: Project) -> str:
    return f"{prj.project_number} {prj.name}"


def _user(db: Session, uid: uuid.UUID | None, what: str = "user") -> None:
    if uid is None:
        return
    if not db.scalar(select(User.id).where(User.id == uid, User.is_active.is_(True))):
        raise AppError("INVALID_USER", f"The selected {what} is not an active user.")


def _site_address(s: CustomerSite) -> str | None:
    parts = [s.address_line1, s.address_line2, s.city]
    if s.district and s.district != s.city:
        parts.append(s.district)
    parts.append(" ".join(x for x in (s.state, s.pincode) if x))
    return ", ".join(x for x in parts if x) or None


def _open(prj: Project) -> None:
    if prj.status in CLOSED_PROJECT:
        raise AppError("PROJECT_CLOSED", f"This project is {prj.status}.")


# ------------------------------------------------------------------ list
def list_projects(db: Session, p: Principal, params: ListParams, *, status=None, customer_id=None,
                  project_manager_id=None, open_only=False):
    stmt = select(Project)
    clause = scope_clause(p, "project.read")
    if clause is not None:
        stmt = stmt.where(clause)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(Project.project_number.ilike(like), Project.name.ilike(like),
                              Project.customer_id.in_(select(Customer.id).where(Customer.customer_name.ilike(like)))))
    if status:
        stmt = stmt.where(Project.status == status)
    if open_only:
        stmt = stmt.where(Project.status.not_in(CLOSED_PROJECT))
    if customer_id:
        stmt = stmt.where(Project.customer_id == customer_id)
    if project_manager_id:
        stmt = stmt.where(Project.project_manager_id == project_manager_id)
    return paginate(db, stmt, params, default_sort=Project.created_at.desc(), sortable={
        "project_number": Project.project_number, "name": Project.name, "status": Project.status,
        "contract_value": Project.contract_value, "target_end_date": Project.target_end_date,
        "progress_pct": Project.progress_pct, "created_at": Project.created_at})


# ------------------------------------------------------------------ create / update
def _lines_from_order(so, user_id) -> list[ProjectBoqLine]:
    return [ProjectBoqLine(so_line_no=it.line_no, line_no=it.line_no, section=it.section, item_id=it.item_id,
                           description=it.description, unit=it.unit, approved_qty=it.quantity,
                           rate=_net_rate(it.taxable, it.quantity), contract_amount=it.taxable,
                           remarks=it.remarks, created_by=user_id, updated_by=user_id) for it in so.items]


def _net_rate(taxable: Decimal, qty: Decimal) -> Decimal:
    """Contract rate after all discounts (value before GST ÷ quantity)."""
    return (taxable / qty).quantize(Decimal("0.0001")) if qty else ZERO


def create(db: Session, p: Principal, data) -> Project:
    from app.sales import service as sales

    so = None
    if data.sales_order_id:
        so = sales.get(db, data.sales_order_id, lock=True)
        sales.check(p, so, "read")
        if so.status not in ("confirmed", "in_progress"):
            raise AppError("SO_NOT_OPEN", f"The sales order is {so.status.replace('_', ' ')}.")
        live = db.scalar(select(Project.project_number).where(Project.sales_order_id == so.id,
                                                              Project.status != "cancelled"))
        if live:
            raise Conflict("PROJECT_EXISTS", f"Project {live} already runs this sales order.")
        customer_id, site_id = so.customer_id, data.site_id or so.site_id
        division_id = data.division_id or so.division_id
        contract = so.taxable
    else:
        customer_id, site_id, division_id = data.customer_id, data.site_id, data.division_id
        if not db.get(Customer, customer_id):
            raise NotFound("customer")
        contract = round_amount(data.contract_value or ZERO)
    if site_id:
        site = db.get(CustomerSite, site_id)
        if site is None or site.customer_id != customer_id:
            raise AppError("INVALID_SITE", "The site does not belong to this customer.")
    _user(db, data.project_manager_id, "project manager")
    for m in data.members:
        _user(db, m.user_id, "team member")
    site_address = data.site_address
    if not site_address and site_id:
        s = db.get(CustomerSite, site_id)
        site_address = _site_address(s)
    prj = Project(
        project_number=numbering.next_number(db, p.company_id, "PRJ", on=data.start_date or today()),
        name=data.name, customer_id=customer_id, site_id=site_id, sales_order_id=so.id if so else None,
        division_id=division_id, project_manager_id=data.project_manager_id, description=data.description,
        site_address=site_address, contract_value=contract, start_date=data.start_date,
        target_end_date=data.target_end_date or (so.expected_completion if so else None), priority=data.priority,
        status="planning", created_by=p.id, updated_by=p.id)
    db.add(prj)
    db.flush()
    seen = set()
    for m in data.members:
        if m.user_id not in seen:
            seen.add(m.user_id)
            prj.members.append(ProjectMember(user_id=m.user_id, role=m.role, created_by=p.id, updated_by=p.id))
    if so is not None:
        for line in _lines_from_order(so, p.id):
            line.project_id = prj.id
            db.add(line)
        sales.mark_in_progress(db, so, p.id)
    db.flush()
    audit.record(db, action="create", entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                 summary=(f"From sales order {so.so_number}: {len(so.items)} BOQ lines, contract ₹{contract}"
                          if so else f"Standalone project, contract ₹{contract}"))
    notify(db, [prj.project_manager_id, *seen], event="project.assigned", title=f"Project {prj.project_number}",
           body=f"You are on the team for {prj.name}.", link=f"/projects/view/?id={prj.id}", exclude=p.id)
    return prj


def update(db: Session, p: Principal, project_id: uuid.UUID, data) -> Project:
    prj = get(db, project_id, lock=True)
    check(p, prj, "update")
    if prj.status == "cancelled":
        raise AppError("PROJECT_CANCELLED", "This project is cancelled.")
    if data.site_id:
        site = db.get(CustomerSite, data.site_id)
        if site is None or site.customer_id != prj.customer_id:
            raise AppError("INVALID_SITE", "The site does not belong to this customer.")
    _user(db, data.project_manager_id, "project manager")
    before = audit.snapshot(prj)
    check_row_version(prj, data.row_version)
    old_pm = prj.project_manager_id
    for k in ("name", "site_id", "division_id", "project_manager_id", "description", "site_address", "start_date",
              "target_end_date", "priority"):
        setattr(prj, k, getattr(data, k))
    if prj.sales_order_id is None and data.contract_value is not None:
        prj.contract_value = round_amount(data.contract_value)
    prj.updated_by = p.id
    db.flush()
    audit.record(db, action="update", entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                 before=before, after=audit.snapshot(prj))
    if prj.project_manager_id and prj.project_manager_id != old_pm:
        notify(db, [prj.project_manager_id], event="project.assigned", title=f"Project {prj.project_number}",
               body=f"You are now the project manager for {prj.name}.", link=f"/projects/view/?id={prj.id}",
               exclude=p.id)
    return prj


NEXT = {"planning": ("active", "on_hold", "cancelled"), "active": ("on_hold", "completed", "cancelled"),
        "on_hold": ("active", "cancelled"), "completed": ("active",), "cancelled": ()}


def set_status(db: Session, p: Principal, project_id: uuid.UUID, status: str, reason: str | None,
               row_version: int | None = None) -> Project:
    prj = get(db, project_id, lock=True)
    check(p, prj, "update")
    if status not in NEXT[prj.status]:
        raise AppError("INVALID_TRANSITION",
                       f"A {prj.status.replace('_', ' ')} project cannot become {status.replace('_', ' ')}.")
    if status in ("cancelled", "on_hold") and not reason:
        raise AppError("REASON_REQUIRED", "Give the reason.", details={"field": "reason"})
    if prj.status == "completed" and not reason:
        raise AppError("REASON_REQUIRED", "Say why the project is reopened.", details={"field": "reason"})
    if row_version is not None:
        check_row_version(prj, row_version)
    else:
        prj.row_version += 1
    before = prj.status
    prj.status, prj.updated_by = status, p.id
    if reason:
        prj.status_reason = reason
    if status == "active" and prj.start_date is None:
        prj.start_date = today()
    if status == "completed":
        prj.actual_end_date = today()
    elif before == "completed":
        prj.actual_end_date = None
    db.flush()
    audit.record(db, action="status", entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                 summary=f"{before} → {status}" + (f": {reason}" if reason else ""))
    notify(db, [prj.project_manager_id, *_member_ids(prj)], event="project.status",
           title=f"{prj.project_number} is {status.replace('_', ' ')}", body=reason,
           link=f"/projects/view/?id={prj.id}", exclude=p.id)
    return prj


def set_progress(db: Session, p: Principal, prj: Project, pct: int, source: str = "manual") -> None:
    if pct == prj.progress_pct:
        return
    before = prj.progress_pct
    prj.progress_pct = pct
    audit.record(db, action="progress", entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                 summary=f"Progress {before}% → {pct}% ({source})")


def update_progress(db: Session, p: Principal, project_id: uuid.UUID, pct: int) -> Project:
    prj = get(db, project_id, lock=True)
    check_site(p, prj, "update")
    set_progress(db, p, prj, pct)
    prj.updated_by = p.id
    db.flush()
    return prj


def delete(db: Session, p: Principal, project_id: uuid.UUID) -> None:
    prj = get(db, project_id, lock=True)
    check(p, prj, "delete")
    if prj.status != "planning":
        raise AppError("PROJECT_STARTED", "Only a project still in planning can be deleted. Cancel it instead.")
    if db.scalar(select(func.count()).select_from(InstallationEntry).where(InstallationEntry.project_id == prj.id)) or \
            db.scalar(select(func.count()).select_from(SiteReport).where(SiteReport.project_id == prj.id)):
        raise AppError("PROJECT_HAS_WORK", "Site work is recorded on this project. Cancel it instead.")
    label = _label(prj)
    db.delete(prj)
    db.flush()
    audit.record(db, action="delete", entity_type="project", entity_id=project_id, entity_label=label)


# ------------------------------------------------------------------ team & milestones
def add_member(db: Session, p: Principal, project_id: uuid.UUID, user_id: uuid.UUID, role: str | None) -> Project:
    prj = get(db, project_id, lock=True)
    check(p, prj, "update")
    _open(prj)
    _user(db, user_id, "team member")
    existing = next((m for m in prj.members if m.user_id == user_id), None)
    if existing:
        existing.role, existing.updated_by = role, p.id
    else:
        prj.members.append(ProjectMember(user_id=user_id, role=role, created_by=p.id, updated_by=p.id))
        name = db.scalar(select(User.full_name).where(User.id == user_id))
        audit.record(db, action="member_add", entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                     summary=f"Added {name}" + (f" as {role}" if role else ""))
        notify(db, [user_id], event="project.assigned", title=f"Project {prj.project_number}",
               body=f"You were added to the team for {prj.name}.", link=f"/projects/view/?id={prj.id}", exclude=p.id)
    db.flush()
    return prj


def remove_member(db: Session, p: Principal, project_id: uuid.UUID, user_id: uuid.UUID) -> Project:
    prj = get(db, project_id, lock=True)
    check(p, prj, "update")
    m = next((m for m in prj.members if m.user_id == user_id), None)
    if m is None:
        raise NotFound("project_member")
    if db.scalar(select(ProjectTask.id).where(ProjectTask.project_id == prj.id, ProjectTask.assigned_to == user_id,
                                              ProjectTask.status != "done").limit(1)):
        raise AppError("MEMBER_HAS_TASKS", "This person still has open tasks on the project. Reassign them first.")
    prj.members.remove(m)
    name = db.scalar(select(User.full_name).where(User.id == user_id))
    audit.record(db, action="member_remove", entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                 summary=f"Removed {name}")
    db.flush()
    return prj


def _ensure_member(db: Session, p: Principal, prj: Project, user_id: uuid.UUID | None) -> None:
    """Assigning work to someone puts them on the team, so they can see the project."""
    if user_id and user_id != prj.project_manager_id and user_id not in _member_ids(prj):
        prj.members.append(ProjectMember(user_id=user_id, created_by=p.id, updated_by=p.id))


def save_milestone(db: Session, p: Principal, project_id: uuid.UUID, data, milestone_id: uuid.UUID | None = None):
    prj = get(db, project_id)
    check(p, prj, "update")
    _open(prj)
    if milestone_id:
        ms = db.get(ProjectMilestone, milestone_id)
        if ms is None or ms.project_id != prj.id:
            raise NotFound("milestone")
        action = "milestone_update"
    else:
        ms = ProjectMilestone(project_id=prj.id, created_by=p.id)
        db.add(ms)
        action = "milestone_add"
    for k in ("name", "due_date", "completed_on", "sort_order", "notes"):
        setattr(ms, k, getattr(data, k))
    ms.updated_by = p.id
    db.flush()
    audit.record(db, action=action, entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                 summary=f"Milestone '{ms.name}'" + (f" completed {ms.completed_on}" if ms.completed_on else ""))
    return ms


def delete_milestone(db: Session, p: Principal, project_id: uuid.UUID, milestone_id: uuid.UUID) -> None:
    prj = get(db, project_id)
    check(p, prj, "update")
    ms = db.get(ProjectMilestone, milestone_id)
    if ms is None or ms.project_id != prj.id:
        raise NotFound("milestone")
    db.delete(ms)
    db.flush()
    audit.record(db, action="milestone_delete", entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                 summary=f"Deleted milestone '{ms.name}'")


# ------------------------------------------------------------------ tasks
def get_task(db: Session, task_id: uuid.UUID, lock: bool = False) -> ProjectTask:
    t = db.get(ProjectTask, task_id, with_for_update=lock or None)
    if t is None:
        raise NotFound("task")
    return t


def _milestone_ok(db: Session, prj: Project, milestone_id) -> None:
    if milestone_id:
        ms = db.get(ProjectMilestone, milestone_id)
        if ms is None or ms.project_id != prj.id:
            raise AppError("INVALID_MILESTONE", "The milestone is not on this project.")


def create_task(db: Session, p: Principal, project_id: uuid.UUID, data) -> ProjectTask:
    prj = get(db, project_id, lock=True)
    check_site(p, prj, "create")
    _milestone_ok(db, prj, data.milestone_id)
    _user(db, data.assigned_to, "assignee")
    _ensure_member(db, p, prj, data.assigned_to)
    t = ProjectTask(project_id=prj.id, created_by=p.id, updated_by=p.id,
                    **{k: getattr(data, k) for k in ("title", "description", "milestone_id", "assigned_to",
                                                      "start_date", "due_date", "priority")})
    db.add(t)
    db.flush()
    audit.record(db, action="create", entity_type="project_task", entity_id=t.id, entity_label=t.title,
                 summary=f"Task on {prj.project_number}")
    notify(db, [t.assigned_to], event="task.assigned", title=f"New task: {t.title}",
           body=f"{prj.project_number} {prj.name}" + (f" · due {t.due_date:%d %b}" if t.due_date else ""),
           link=f"/projects/view/?id={prj.id}&tab=tasks", exclude=p.id)
    return t


def _can_task(p: Principal, prj: Project, t: ProjectTask) -> None:
    """The team (site_work.update) may edit any task; the assignee may always move their own task along."""
    if t.assigned_to == p.id and p.scope("site_work.update") is None:
        _open(prj)
        return
    check_site(p, prj, "update")


def _apply_status(t: ProjectTask, status: str, blocked_reason: str | None) -> None:
    if status == "blocked" and not blocked_reason:
        raise AppError("REASON_REQUIRED", "Say what is blocking the task.", details={"field": "blocked_reason"})
    t.status = status
    t.blocked_reason = blocked_reason if status == "blocked" else None
    t.completed_at = now() if status == "done" else None


def update_task(db: Session, p: Principal, task_id: uuid.UUID, data) -> ProjectTask:
    t = get_task(db, task_id, lock=True)
    prj = get(db, t.project_id, lock=True)
    check_site(p, prj, "update")
    _milestone_ok(db, prj, data.milestone_id)
    _user(db, data.assigned_to, "assignee")
    _ensure_member(db, p, prj, data.assigned_to)
    before = audit.snapshot(t)
    check_row_version(t, data.row_version)
    old = t.assigned_to
    for k in ("title", "description", "milestone_id", "assigned_to", "start_date", "due_date", "priority"):
        setattr(t, k, getattr(data, k))
    if data.status != t.status or data.blocked_reason != t.blocked_reason:
        _apply_status(t, data.status, data.blocked_reason)
    t.updated_by = p.id
    db.flush()
    audit.record(db, action="update", entity_type="project_task", entity_id=t.id, entity_label=t.title,
                 before=before, after=audit.snapshot(t))
    if t.assigned_to and t.assigned_to != old:
        notify(db, [t.assigned_to], event="task.assigned", title=f"Task assigned: {t.title}",
               body=f"{prj.project_number} {prj.name}", link=f"/projects/view/?id={prj.id}&tab=tasks", exclude=p.id)
    return t


def set_task_status(db: Session, p: Principal, task_id: uuid.UUID, status: str, blocked_reason: str | None):
    t = get_task(db, task_id, lock=True)
    prj = get(db, t.project_id)
    _can_task(p, prj, t)
    before = t.status
    _apply_status(t, status, blocked_reason)
    t.updated_by = p.id
    t.row_version += 1
    db.flush()
    audit.record(db, action="status", entity_type="project_task", entity_id=t.id, entity_label=t.title,
                 summary=f"{before} → {status}" + (f": {blocked_reason}" if status == "blocked" else ""))
    if status in ("blocked", "done"):
        notify(db, [prj.project_manager_id], event=f"task.{status}", title=f"Task {status}: {t.title}",
               body=blocked_reason if status == "blocked" else f"{prj.project_number} {prj.name}",
               link=f"/projects/view/?id={prj.id}&tab=tasks", exclude=p.id)
    return t


def delete_task(db: Session, p: Principal, task_id: uuid.UUID) -> None:
    t = get_task(db, task_id, lock=True)
    prj = get(db, t.project_id)
    check_site(p, prj, "delete")
    db.delete(t)
    db.flush()
    audit.record(db, action="delete", entity_type="project_task", entity_id=task_id, entity_label=t.title,
                 summary=f"Task on {prj.project_number}")


def list_tasks(db: Session, p: Principal, params: ListParams, *, mine=False, project_id=None, status=None,
               open_only=False, overdue=False):
    stmt = select(ProjectTask).join(Project, Project.id == ProjectTask.project_id)
    if mine:
        stmt = stmt.where(ProjectTask.assigned_to == p.id)
    else:
        clause = scope_clause(p, "site_work.read")
        if clause is not None:
            stmt = stmt.where(or_(clause, ProjectTask.assigned_to == p.id))
    if project_id:
        stmt = stmt.where(ProjectTask.project_id == project_id)
    if status:
        stmt = stmt.where(ProjectTask.status == status)
    if open_only or overdue:
        stmt = stmt.where(ProjectTask.status != "done")
    if overdue:
        stmt = stmt.where(ProjectTask.due_date < today())
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(ProjectTask.title.ilike(like), Project.project_number.ilike(like),
                              Project.name.ilike(like)))
    return paginate(db, stmt, params, default_sort=ProjectTask.due_date.asc().nulls_last(), sortable={
        "due_date": ProjectTask.due_date, "status": ProjectTask.status, "priority": ProjectTask.priority,
        "title": ProjectTask.title, "created_at": ProjectTask.created_at})


# ------------------------------------------------------------------ issues
def get_issue(db: Session, issue_id: uuid.UUID, lock: bool = False) -> ProjectIssue:
    i = db.get(ProjectIssue, issue_id, with_for_update=lock or None)
    if i is None:
        raise NotFound("issue")
    return i


def create_issue(db: Session, p: Principal, project_id: uuid.UUID, data) -> ProjectIssue:
    prj = get(db, project_id, lock=True)
    check_site(p, prj, "create")
    _user(db, data.assigned_to, "assignee")
    _ensure_member(db, p, prj, data.assigned_to)
    i = ProjectIssue(project_id=prj.id, title=data.title, description=data.description, severity=data.severity,
                     assigned_to=data.assigned_to, created_by=p.id, updated_by=p.id)
    db.add(i)
    db.flush()
    audit.record(db, action="create", entity_type="project_issue", entity_id=i.id, entity_label=i.title,
                 summary=f"{i.severity} issue on {prj.project_number}")
    notify(db, [prj.project_manager_id, i.assigned_to], event="issue.raised",
           title=f"Issue ({i.severity}): {i.title}", body=f"{prj.project_number} {prj.name}",
           link=f"/projects/view/?id={prj.id}&tab=issues", exclude=p.id)
    return i


def update_issue(db: Session, p: Principal, issue_id: uuid.UUID, data) -> ProjectIssue:
    i = get_issue(db, issue_id, lock=True)
    prj = get(db, i.project_id, lock=True)
    check_site(p, prj, "update")
    _user(db, data.assigned_to, "assignee")
    _ensure_member(db, p, prj, data.assigned_to)
    if data.status != "open" and not data.resolution:
        raise AppError("RESOLUTION_REQUIRED", "Describe how the issue was resolved.", details={"field": "resolution"})
    before = audit.snapshot(i)
    check_row_version(i, data.row_version)
    was = i.status
    for k in ("title", "description", "severity", "assigned_to", "status", "resolution"):
        setattr(i, k, getattr(data, k))
    if i.status != "open" and was == "open":
        i.resolved_at = now()
    elif i.status == "open":
        i.resolved_at = None
    i.updated_by = p.id
    db.flush()
    audit.record(db, action="update", entity_type="project_issue", entity_id=i.id, entity_label=i.title,
                 before=before, after=audit.snapshot(i))
    if i.status != was:
        notify(db, [i.created_by, prj.project_manager_id], event="issue.status", title=f"Issue {i.status}: {i.title}",
               body=i.resolution, link=f"/projects/view/?id={prj.id}&tab=issues", exclude=p.id)
    return i


def delete_issue(db: Session, p: Principal, issue_id: uuid.UUID) -> None:
    i = get_issue(db, issue_id, lock=True)
    prj = get(db, i.project_id)
    check_site(p, prj, "delete")
    db.delete(i)
    db.flush()
    audit.record(db, action="delete", entity_type="project_issue", entity_id=issue_id, entity_label=i.title,
                 summary=f"Issue on {prj.project_number}")


# ------------------------------------------------------------------ BOQ tracking & installation
def boq_lines(db: Session, project_id: uuid.UUID) -> list[ProjectBoqLine]:
    return list(db.scalars(select(ProjectBoqLine).where(ProjectBoqLine.project_id == project_id)
                           .order_by(ProjectBoqLine.line_no)))


def _install(db: Session, p: Principal, prj: Project, data, entry_date: date, report_id=None) -> InstallationEntry:
    line = db.get(ProjectBoqLine, data.boq_line_id, with_for_update=True)
    if line is None or line.project_id != prj.id:
        raise AppError("INVALID_LINE", "That BOQ line is not on this project.")
    qty = round_qty(data.quantity)
    remaining = line.approved_qty - line.installed_qty
    if qty > remaining:
        raise AppError("OVER_INSTALLED",
                       f"Line {line.line_no} ({line.description[:60]}): only {remaining.normalize():f} {line.unit} "
                       f"remain of the approved {line.approved_qty.normalize():f}; {qty.normalize():f} cannot be "
                       "recorded.", details={"line_no": line.line_no, "remaining": str(remaining)})
    if entry_date > today():
        raise AppError("FUTURE_DATE", "Installation cannot be recorded for a future date.")
    line.installed_qty += qty
    line.updated_by = p.id
    e = InstallationEntry(project_id=prj.id, boq_line_id=line.id, site_report_id=report_id, entry_date=entry_date,
                          quantity=qty, location=data.location, remarks=data.remarks, created_by=p.id, updated_by=p.id)
    db.add(e)
    db.flush()
    audit.record(db, action="install", entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                 summary=f"Installed {qty.normalize():f} {line.unit} on line {line.line_no} ({line.description[:60]}) "
                         f"on {entry_date:%d %b %Y}; now {line.installed_qty.normalize():f} of "
                         f"{line.approved_qty.normalize():f}")
    return e


def add_installation(db: Session, p: Principal, project_id: uuid.UUID, data) -> InstallationEntry:
    prj = get(db, project_id, lock=True)
    check_site(p, prj, "create")
    return _install(db, p, prj, data, data.entry_date)


def delete_installation(db: Session, p: Principal, entry_id: uuid.UUID) -> None:
    e = db.get(InstallationEntry, entry_id, with_for_update=True)
    if e is None:
        raise NotFound("installation_entry")
    prj = get(db, e.project_id, lock=True)
    check_site(p, prj, "delete")
    _reverse(db, p, prj, e)


def _reverse(db: Session, p: Principal, prj: Project, e: InstallationEntry) -> None:
    line = db.get(ProjectBoqLine, e.boq_line_id, with_for_update=True)
    line.installed_qty -= e.quantity
    line.updated_by = p.id
    db.delete(e)
    db.flush()
    audit.record(db, action="install_reverse", entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                 summary=f"Removed installation of {e.quantity.normalize():f} {line.unit} on line {line.line_no} "
                         f"({e.entry_date:%d %b %Y})")


def installations(db: Session, project_id: uuid.UUID, boq_line_id=None, limit: int = 200):
    stmt = select(InstallationEntry).where(InstallationEntry.project_id == project_id)
    if boq_line_id:
        stmt = stmt.where(InstallationEntry.boq_line_id == boq_line_id)
    return list(db.scalars(stmt.order_by(InstallationEntry.entry_date.desc(), InstallationEntry.created_at.desc())
                           .limit(limit)))


def add_boq_line(db: Session, p: Principal, project_id: uuid.UUID, data) -> ProjectBoqLine:
    prj = get(db, project_id, lock=True)
    check(p, prj, "update")
    _open(prj)
    if data.item_id and not db.get(Item, data.item_id):
        raise NotFound("item")
    n = (db.scalar(select(func.max(ProjectBoqLine.line_no)).where(ProjectBoqLine.project_id == prj.id)) or 0) + 1
    qty = round_qty(data.approved_qty)
    line = ProjectBoqLine(project_id=prj.id, line_no=n, section=data.section, item_id=data.item_id,
                          description=data.description, unit=data.unit, approved_qty=qty, rate=data.rate,
                          contract_amount=round_amount(qty * data.rate), remarks=data.remarks,
                          created_by=p.id, updated_by=p.id)
    db.add(line)
    db.flush()
    audit.record(db, action="boq_line_add", entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                 summary=f"Added line {n}: {data.description[:80]} ({qty.normalize():f} {data.unit})")
    return line


def update_boq_line(db: Session, p: Principal, line_id: uuid.UUID, data) -> ProjectBoqLine:
    line = db.get(ProjectBoqLine, line_id, with_for_update=True)
    if line is None:
        raise NotFound("boq_line")
    prj = get(db, line.project_id, lock=True)
    check(p, prj, "update")
    _open(prj)
    if line.so_line_no is not None:
        raise AppError("FROM_ORDER", "This line comes from the sales order. Its quantity and rate change only through "
                                     "a change to the order.")
    qty = round_qty(data.approved_qty)
    if qty < line.installed_qty:
        raise AppError("BELOW_INSTALLED", f"{line.installed_qty.normalize():f} {line.unit} are already installed.")
    before = audit.snapshot(line)
    for k in ("section", "item_id", "description", "unit", "rate", "remarks"):
        setattr(line, k, getattr(data, k))
    line.approved_qty, line.contract_amount, line.updated_by = qty, round_amount(qty * data.rate), p.id
    db.flush()
    audit.record(db, action="boq_line_update", entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                 before=before, after=audit.snapshot(line))
    return line


def delete_boq_line(db: Session, p: Principal, line_id: uuid.UUID) -> None:
    line = db.get(ProjectBoqLine, line_id, with_for_update=True)
    if line is None:
        raise NotFound("boq_line")
    prj = get(db, line.project_id, lock=True)
    check(p, prj, "update")
    _open(prj)
    if line.so_line_no is not None:
        raise AppError("FROM_ORDER", "Lines from the sales order cannot be deleted here.")
    if line.installed_qty or line.procured_qty or line.issued_qty:
        raise AppError("LINE_IN_USE", "Material or installation is recorded on this line.")
    db.delete(line)
    db.flush()
    audit.record(db, action="boq_line_delete", entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                 summary=f"Deleted line {line.line_no}: {line.description[:80]}")


def sync_from_order(db: Session, p: Principal, so) -> list[str]:
    """After a commercial change to the order, bring the live projects' order lines in line (matched by order line
    number). Returns warnings for lines that could not follow the order."""
    warnings: list[str] = []
    projects = db.scalars(select(Project).where(Project.sales_order_id == so.id, Project.status != "cancelled")
                          .with_for_update()).all()
    for prj in projects:
        existing = {ln.so_line_no: ln for ln in boq_lines(db, prj.id) if ln.so_line_no is not None}
        extra_no = max([ln.line_no for ln in boq_lines(db, prj.id)] + [0])
        seen = set()
        for it in so.items:
            seen.add(it.line_no)
            ln = existing.get(it.line_no)
            if ln is None:
                extra_no += 1
                db.add(ProjectBoqLine(project_id=prj.id, so_line_no=it.line_no, line_no=extra_no, section=it.section,
                                      item_id=it.item_id, description=it.description, unit=it.unit,
                                      approved_qty=it.quantity, rate=_net_rate(it.taxable, it.quantity),
                                      contract_amount=it.taxable, remarks=it.remarks, created_by=p.id,
                                      updated_by=p.id))
                continue
            qty = it.quantity
            if qty < ln.installed_qty:
                warnings.append(f"{prj.project_number} line {ln.line_no}: {ln.installed_qty.normalize():f} already "
                                f"installed, more than the new {qty.normalize():f}; approved kept at installed.")
                qty = ln.installed_qty
            ln.section, ln.item_id, ln.description, ln.unit = it.section, it.item_id, it.description, it.unit
            ln.approved_qty, ln.rate, ln.contract_amount = qty, _net_rate(it.taxable, it.quantity), it.taxable
            ln.remarks, ln.updated_by = it.remarks, p.id
        for no, ln in existing.items():
            if no in seen:
                continue
            if ln.installed_qty or ln.procured_qty or ln.issued_qty:
                ln.approved_qty, ln.contract_amount = ln.installed_qty, ZERO
                warnings.append(f"{prj.project_number} line {ln.line_no} was removed from the order but work is "
                                "recorded; kept at the installed quantity with no contract value.")
            else:
                db.delete(ln)
        prj.contract_value = so.taxable
        prj.row_version += 1
        db.flush()
        audit.record(db, action="order_sync", entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                     summary=f"BOQ updated from {so.so_number}; contract ₹{so.taxable}"
                             + (f". {' '.join(warnings)}" if warnings else ""))
    return warnings


# ------------------------------------------------------------------ site reports
def get_report(db: Session, report_id: uuid.UUID, lock: bool = False) -> SiteReport:
    r = db.get(SiteReport, report_id, with_for_update=lock or None)
    if r is None:
        raise NotFound("site_report")
    return r


def create_report(db: Session, p: Principal, project_id: uuid.UUID, data) -> SiteReport:
    prj = get(db, project_id, lock=True)
    check_site(p, prj, "create")
    if data.report_date > today():
        raise AppError("FUTURE_DATE", "A site report cannot be dated in the future.")
    r = SiteReport(project_id=prj.id, created_by=p.id, updated_by=p.id,
                   **{k: getattr(data, k) for k in ("report_date", "work_done", "manpower", "weather", "hindrances",
                                                     "next_plan", "progress_pct")})
    db.add(r)
    db.flush()
    for inst in data.installations:
        _install(db, p, prj, inst, data.report_date, report_id=r.id)
    if data.progress_pct is not None:
        set_progress(db, p, prj, data.progress_pct, source=f"site report {data.report_date:%d %b}")
    if prj.status == "planning":
        prj.status = "active"
        prj.start_date = prj.start_date or data.report_date
        audit.record(db, action="status", entity_type="project", entity_id=prj.id, entity_label=_label(prj),
                     summary="planning → active (first site report)")
    db.flush()
    audit.record(db, action="create", entity_type="site_report", entity_id=r.id,
                 entity_label=f"{prj.project_number} {r.report_date:%d %b %Y}",
                 summary=f"{len(data.installations)} installation entries")
    if data.hindrances:
        notify(db, [prj.project_manager_id], event="site_report.hindrance",
               title=f"Hindrance on {prj.project_number}", body=data.hindrances,
               link=f"/projects/view/?id={prj.id}&tab=reports", exclude=p.id)
    return r


def update_report(db: Session, p: Principal, report_id: uuid.UUID, data) -> SiteReport:
    """Text fields only; installation entries are managed on their own (so quantities are never silently changed)."""
    r = get_report(db, report_id, lock=True)
    prj = get(db, r.project_id, lock=True)
    check_site(p, prj, "update")
    before = audit.snapshot(r)
    for k in ("report_date", "work_done", "manpower", "weather", "hindrances", "next_plan", "progress_pct"):
        setattr(r, k, getattr(data, k))
    r.updated_by = p.id
    r.row_version += 1
    if data.progress_pct is not None:
        set_progress(db, p, prj, data.progress_pct, source=f"site report {r.report_date:%d %b}")
    db.flush()
    audit.record(db, action="update", entity_type="site_report", entity_id=r.id,
                 entity_label=f"{prj.project_number} {r.report_date:%d %b %Y}", before=before, after=audit.snapshot(r))
    return r


def delete_report(db: Session, p: Principal, report_id: uuid.UUID) -> None:
    """Deleting a report also removes the installation it recorded (quantities go back)."""
    r = get_report(db, report_id, lock=True)
    prj = get(db, r.project_id, lock=True)
    check_site(p, prj, "delete")
    for e in db.scalars(select(InstallationEntry).where(InstallationEntry.site_report_id == r.id)).all():
        _reverse(db, p, prj, e)
    label = f"{prj.project_number} {r.report_date:%d %b %Y}"
    db.delete(r)
    db.flush()
    audit.record(db, action="delete", entity_type="site_report", entity_id=report_id, entity_label=label)


def list_reports(db: Session, p: Principal, params: ListParams, *, project_id=None, date_from=None, date_to=None):
    stmt = select(SiteReport).join(Project, Project.id == SiteReport.project_id)
    clause = scope_clause(p, "site_work.read")
    if clause is not None:
        stmt = stmt.where(clause)
    if project_id:
        stmt = stmt.where(SiteReport.project_id == project_id)
    if date_from:
        stmt = stmt.where(SiteReport.report_date >= date_from)
    if date_to:
        stmt = stmt.where(SiteReport.report_date <= date_to)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(SiteReport.work_done.ilike(like), Project.project_number.ilike(like),
                              Project.name.ilike(like)))
    stmt = stmt.order_by(None) if params.sort else stmt.order_by(SiteReport.report_date.desc())
    return paginate(db, stmt, params, default_sort=SiteReport.created_at.desc(),
                    sortable={"report_date": SiteReport.report_date, "created_at": SiteReport.created_at})


# ------------------------------------------------------------------ dashboard
def financials(db: Session, prj: Project) -> dict:
    """Contract value vs estimated cost (item purchase prices). Billing, collections, material and labour costs
    come from Phases 6–7 and are shown as not yet available."""
    lines = boq_lines(db, prj.id)
    prices = dict(db.execute(select(Item.id, Item.purchase_price).where(
        Item.id.in_({ln.item_id for ln in lines} - {None}))).all()) if lines else {}
    est_cost, uncosted = ZERO, 0
    installed_value = ZERO
    for ln in lines:
        price = prices.get(ln.item_id)
        if price is None:
            uncosted += 1
        else:
            est_cost += ln.approved_qty * price
        if ln.approved_qty:
            installed_value += ln.contract_amount * ln.installed_qty / ln.approved_qty
    est_cost = round_amount(est_cost)
    boq_value = sum((ln.contract_amount for ln in lines), ZERO)
    profit = prj.contract_value - est_cost
    return {
        "contract_value": str(prj.contract_value), "estimated_cost": str(est_cost), "uncosted_lines": uncosted,
        "estimated_profit": str(round_amount(profit)),
        "estimated_margin_pct": str(round_amount(profit * 100 / prj.contract_value)) if prj.contract_value else None,
        "installed_value": str(round_amount(installed_value)),
        "work_done_pct": str(round_amount(installed_value * 100 / boq_value)) if boq_value else None,
        "billed": None, "collected": None, "material_cost": None, "labour_cost": None,
    }


def counts(db: Session, project_id: uuid.UUID) -> dict:
    t = dict(db.execute(select(ProjectTask.status, func.count()).where(ProjectTask.project_id == project_id)
                        .group_by(ProjectTask.status)).all())
    overdue = db.scalar(select(func.count()).select_from(ProjectTask).where(
        ProjectTask.project_id == project_id, ProjectTask.status != "done", ProjectTask.due_date < today()))
    issues = db.scalar(select(func.count()).select_from(ProjectIssue).where(
        ProjectIssue.project_id == project_id, ProjectIssue.status == "open"))
    last = db.scalar(select(func.max(SiteReport.report_date)).where(SiteReport.project_id == project_id))
    return {"tasks_total": sum(t.values()), "tasks_done": t.get("done", 0), "tasks_blocked": t.get("blocked", 0),
            "tasks_open": sum(v for k, v in t.items() if k != "done"), "tasks_overdue": overdue,
            "issues_open": issues, "last_report": last.isoformat() if last else None}


def pm_summary(db: Session, p: Principal) -> dict:
    """Project manager dashboard tiles, within the user's project scope."""
    clause = scope_clause(p, "project.read")
    base = select(Project).where(Project.status.not_in(CLOSED_PROJECT))
    if clause is not None:
        base = base.where(clause)
    live = db.scalars(base).all()
    ids = [x.id for x in live]
    overdue_tasks = db.scalar(select(func.count()).select_from(ProjectTask).where(
        ProjectTask.project_id.in_(ids), ProjectTask.status != "done", ProjectTask.due_date < today())) if ids else 0
    open_issues = db.scalar(select(func.count()).select_from(ProjectIssue).where(
        ProjectIssue.project_id.in_(ids), ProjectIssue.status == "open")) if ids else 0
    late = [x for x in live if x.target_end_date and x.target_end_date < today()]
    my_open = db.scalar(select(func.count()).select_from(ProjectTask).where(
        ProjectTask.assigned_to == p.id, ProjectTask.status != "done"))
    return {
        "active": sum(1 for x in live if x.status == "active"), "planning": sum(1 for x in live if x.status == "planning"),
        "on_hold": sum(1 for x in live if x.status == "on_hold"), "late": len(late),
        "contract_value": str(sum((x.contract_value for x in live), ZERO)),
        "overdue_tasks": overdue_tasks, "open_issues": open_issues, "my_open_tasks": my_open,
    }
