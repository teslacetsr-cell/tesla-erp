from app.core.permissions import register

# 'own' scope for projects: the project manager, the creator, or a member of the project team.
# (update 'own' = the project manager or the creator.)
register("project", "Projects", ("create", "read", "update", "delete", "export", "print"), scoped=("read", "update"))
# Day-to-day site work on a project: tasks, issues, daily site reports (with photos) and installation entries.
# 'own' = on projects where the user is the project manager or a team member.
register("site_work", "Project site work (tasks, issues, site reports, installation)",
         ("create", "read", "update", "delete"), scoped=("create", "read", "update", "delete"))
