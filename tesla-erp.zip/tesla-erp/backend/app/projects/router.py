import uuid
from datetime import date
from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.orm import object_session

from app.auth.deps import Principal, get_principal, require
from app.company.models import BusinessDivision
from app.core import excel
from app.core.api import ListParams, ok
from app.core.db import DbSession
from app.core.errors import Forbidden
from app.crm.service import today
from app.customers.models import Customer, CustomerSite
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.projects import pdf, service
from app.projects.models import InstallationEntry, Project, ProjectBoqLine, ProjectIssue, ProjectMilestone, ProjectTask, SiteReport
from app.projects.schemas import (
    BoqLineIn,
    InstallationEntryIn,
    IssueIn,
    IssueUpdate,
    MemberIn,
    MilestoneIn,
    ProgressIn,
    ProjectIn,
    ProjectStatusIn,
    ProjectUpdate,
    SiteReportIn,
    TaskIn,
    TaskStatusIn,
    TaskUpdate,
)
from app.sales.models import SalesOrder
from app.users.models import User

router = APIRouter(tags=["projects"])


def _report_check(p, r: SiteReport, action: str) -> None:
    prj = object_session(r).get(Project, r.project_id)
    if action == "read":
        service.check_site(p, prj, "read")
    else:
        service.check_site(p, prj, "update")


documents.register_entity("project", "project", Project,
                          check=lambda p, prj, action: service.check(p, prj, "read" if action == "read" else "update"))
documents.register_entity("site_report", "site_work", SiteReport, check=_report_check)


# ------------------------------------------------------------------ output
def _names(db, ids) -> dict:
    ids = {i for i in ids if i}
    return dict(db.execute(select(User.id, User.full_name).where(User.id.in_(ids))).all()) if ids else {}


def _d(v) -> str | None:
    return v.isoformat() if v else None


def _q(v) -> str:
    return f"{v.normalize():f}"


def project_out(db, p: Principal, prj: Project, detail: bool = False, names: dict | None = None) -> dict:
    names = names if names is not None else _names(db, [prj.project_manager_id, prj.created_by])
    c = db.get(Customer, prj.customer_id)
    so_number = db.scalar(select(SalesOrder.so_number).where(SalesOrder.id == prj.sales_order_id)) \
        if prj.sales_order_id else None
    out = {
        "id": str(prj.id), "project_number": prj.project_number, "name": prj.name, "status": prj.status,
        "priority": prj.priority, "customer_id": str(prj.customer_id),
        "customer": {"id": str(c.id), "name": c.customer_name, "code": c.customer_code, "city": c.city} if c else None,
        "sales_order_id": str(prj.sales_order_id) if prj.sales_order_id else None, "so_number": so_number,
        "project_manager_id": str(prj.project_manager_id) if prj.project_manager_id else None,
        "project_manager": names.get(prj.project_manager_id), "contract_value": str(prj.contract_value),
        "progress_pct": prj.progress_pct, "start_date": _d(prj.start_date), "target_end_date": _d(prj.target_end_date),
        "actual_end_date": _d(prj.actual_end_date),
        "late": bool(prj.target_end_date and prj.status not in ("completed", "cancelled")
                     and prj.target_end_date < today()),
        "row_version": prj.row_version,
    }
    if not detail:
        return out
    member_names = _names(db, [m.user_id for m in prj.members])
    milestones = db.scalars(select(ProjectMilestone).where(ProjectMilestone.project_id == prj.id)
                            .order_by(ProjectMilestone.sort_order, ProjectMilestone.due_date.nulls_last())).all()
    upd = service.allowed(p, prj, "update")
    live = prj.status not in ("completed", "cancelled")
    out |= {
        "site_id": str(prj.site_id) if prj.site_id else None,
        "site": db.scalar(select(CustomerSite.site_name).where(CustomerSite.id == prj.site_id)) if prj.site_id else None,
        "division_id": str(prj.division_id) if prj.division_id else None,
        "division": db.scalar(select(BusinessDivision.name).where(BusinessDivision.id == prj.division_id))
        if prj.division_id else None,
        "description": prj.description, "site_address": prj.site_address, "status_reason": prj.status_reason,
        "created_by": names.get(prj.created_by), "created_at": prj.created_at.isoformat(),
        "members": [{"user_id": str(m.user_id), "name": member_names.get(m.user_id), "role": m.role}
                    for m in sorted(prj.members, key=lambda m: member_names.get(m.user_id) or "")],
        "milestones": [{"id": str(m.id), "name": m.name, "due_date": _d(m.due_date), "completed_on": _d(m.completed_on),
                        "sort_order": m.sort_order, "notes": m.notes,
                        "late": bool(m.due_date and not m.completed_on and m.due_date < today())} for m in milestones],
        "financials": service.financials(db, prj),
        "counts": service.counts(db, prj.id),
        "can": {
            "update": upd and prj.status != "cancelled", "team": upd and live,
            "delete": service.allowed(p, prj, "delete") and prj.status == "planning",
            "status": [s for s in service.NEXT[prj.status]] if upd else [],
            "site_create": service.site_allowed(p, prj, "create"),
            "site_update": service.site_allowed(p, prj, "update"),
            "site_delete": service.site_allowed(p, prj, "delete"),
            "export": p.can("project.export"), "print": p.can("project.print"),
            "contract": upd and prj.sales_order_id is None,
        },
    }
    return out


def line_out(ln: ProjectBoqLine) -> dict:
    remaining = ln.approved_qty - ln.installed_qty
    return {
        "id": str(ln.id), "line_no": ln.line_no, "so_line_no": ln.so_line_no, "from_order": ln.so_line_no is not None,
        "section": ln.section, "item_id": str(ln.item_id) if ln.item_id else None, "description": ln.description,
        "unit": ln.unit, "approved_qty": _q(ln.approved_qty), "procured_qty": _q(ln.procured_qty),
        "issued_qty": _q(ln.issued_qty), "installed_qty": _q(ln.installed_qty), "remaining_qty": _q(remaining),
        "installed_pct": str(round(ln.installed_qty * 100 / ln.approved_qty, 1)) if ln.approved_qty else None,
        "rate": str(ln.rate), "contract_amount": str(ln.contract_amount), "remarks": ln.remarks,
    }


def task_out(db, p: Principal, t: ProjectTask, prj: Project, names: dict, milestones: dict | None = None) -> dict:
    site_upd = service.site_allowed(p, prj, "update")
    live = prj.status not in ("completed", "cancelled")
    return {
        "id": str(t.id), "project_id": str(prj.id), "project_number": prj.project_number, "project_name": prj.name,
        "title": t.title, "description": t.description, "milestone_id": str(t.milestone_id) if t.milestone_id else None,
        "milestone": (milestones or {}).get(t.milestone_id),
        "assigned_to": str(t.assigned_to) if t.assigned_to else None, "assignee": names.get(t.assigned_to),
        "start_date": _d(t.start_date), "due_date": _d(t.due_date), "status": t.status, "priority": t.priority,
        "blocked_reason": t.blocked_reason, "completed_at": _d(t.completed_at),
        "overdue": bool(t.due_date and t.status != "done" and t.due_date < today()),
        "created_by": names.get(t.created_by), "row_version": t.row_version,
        "can": {"edit": site_upd, "status": live and (site_upd or t.assigned_to == p.id),
                "delete": service.site_allowed(p, prj, "delete")},
    }


def issue_out(p: Principal, i: ProjectIssue, prj: Project, names: dict) -> dict:
    return {
        "id": str(i.id), "project_id": str(prj.id), "title": i.title, "description": i.description,
        "severity": i.severity, "status": i.status, "assigned_to": str(i.assigned_to) if i.assigned_to else None,
        "assignee": names.get(i.assigned_to), "resolution": i.resolution, "resolved_at": _d(i.resolved_at),
        "raised_by": names.get(i.created_by), "created_at": i.created_at.isoformat(), "row_version": i.row_version,
        "can": {"edit": service.site_allowed(p, prj, "update"), "delete": service.site_allowed(p, prj, "delete")},
    }


def report_out(db, p: Principal, r: SiteReport, prj: Project, names: dict) -> dict:
    inst = db.execute(select(InstallationEntry, ProjectBoqLine.line_no, ProjectBoqLine.description,
                             ProjectBoqLine.unit).join(ProjectBoqLine, ProjectBoqLine.id == InstallationEntry.boq_line_id)
                      .where(InstallationEntry.site_report_id == r.id).order_by(ProjectBoqLine.line_no)).all()
    return {
        "id": str(r.id), "project_id": str(prj.id), "project_number": prj.project_number, "project_name": prj.name,
        "report_date": r.report_date.isoformat(), "work_done": r.work_done, "manpower": r.manpower,
        "weather": r.weather, "hindrances": r.hindrances, "next_plan": r.next_plan, "progress_pct": r.progress_pct,
        "reported_by": names.get(r.created_by), "created_at": r.created_at.isoformat(), "row_version": r.row_version,
        "installations": [{"id": str(e.id), "line_no": n, "description": d, "unit": u, "quantity": _q(e.quantity),
                           "location": e.location} for e, n, d, u in inst],
        "can": {"edit": service.site_allowed(p, prj, "update"), "delete": service.site_allowed(p, prj, "delete")},
    }


def _visible(db, p: Principal, project_id: uuid.UUID) -> Project:
    prj = service.get(db, project_id)
    service.check(p, prj, "read")
    return prj


# ------------------------------------------------------------------ projects
@router.get("/projects")
def list_projects(db: DbSession, p: Annotated[Principal, require("project.read")],
                  params: Annotated[ListParams, Depends()], status: str | None = Query(None),
                  customer_id: uuid.UUID | None = None, project_manager_id: uuid.UUID | None = None,
                  open_only: bool = False):
    rows, meta = service.list_projects(db, p, params, status=status, customer_id=customer_id,
                                       project_manager_id=project_manager_id, open_only=open_only)
    names = _names(db, [r.project_manager_id for r in rows])
    return {"data": [project_out(db, p, r, names=names) for r in rows], "meta": meta.model_dump()}


@router.get("/projects/summary")
def summary(db: DbSession, p: Annotated[Principal, require("project.read")]):
    return ok(service.pm_summary(db, p))


@router.post("/projects", status_code=201)
def create_project(body: ProjectIn, db: DbSession, p: Annotated[Principal, require("project.create")]):
    return ok(project_out(db, p, service.create(db, p, body), detail=True))


@router.get("/projects/{project_id}")
def get_project(project_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("project.read")]):
    return ok(project_out(db, p, _visible(db, p, project_id), detail=True))


@router.put("/projects/{project_id}")
def update_project(project_id: uuid.UUID, body: ProjectUpdate, db: DbSession,
                   p: Annotated[Principal, require("project.update")]):
    return ok(project_out(db, p, service.update(db, p, project_id, body), detail=True))


@router.delete("/projects/{project_id}")
def delete_project(project_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("project.delete")]):
    service.delete(db, p, project_id)
    return ok({"ok": True})


@router.post("/projects/{project_id}/status")
def project_status(project_id: uuid.UUID, body: ProjectStatusIn, db: DbSession,
                   p: Annotated[Principal, require("project.update")]):
    prj = service.set_status(db, p, project_id, body.status, body.reason, body.row_version)
    return ok(project_out(db, p, prj, detail=True))


@router.put("/projects/{project_id}/progress")
def project_progress(project_id: uuid.UUID, body: ProgressIn, db: DbSession,
                     p: Annotated[Principal, require("site_work.update")]):
    return ok(project_out(db, p, service.update_progress(db, p, project_id, body.progress_pct), detail=True))


@router.post("/projects/{project_id}/members")
def add_member(project_id: uuid.UUID, body: MemberIn, db: DbSession, p: Annotated[Principal, require("project.update")]):
    return ok(project_out(db, p, service.add_member(db, p, project_id, body.user_id, body.role), detail=True))


@router.delete("/projects/{project_id}/members/{user_id}")
def remove_member(project_id: uuid.UUID, user_id: uuid.UUID, db: DbSession,
                  p: Annotated[Principal, require("project.update")]):
    return ok(project_out(db, p, service.remove_member(db, p, project_id, user_id), detail=True))


@router.post("/projects/{project_id}/milestones", status_code=201)
def add_milestone(project_id: uuid.UUID, body: MilestoneIn, db: DbSession,
                  p: Annotated[Principal, require("project.update")]):
    service.save_milestone(db, p, project_id, body)
    return ok(project_out(db, p, service.get(db, project_id), detail=True))


@router.put("/projects/{project_id}/milestones/{milestone_id}")
def update_milestone(project_id: uuid.UUID, milestone_id: uuid.UUID, body: MilestoneIn, db: DbSession,
                     p: Annotated[Principal, require("project.update")]):
    service.save_milestone(db, p, project_id, body, milestone_id)
    return ok(project_out(db, p, service.get(db, project_id), detail=True))


@router.delete("/projects/{project_id}/milestones/{milestone_id}")
def delete_milestone(project_id: uuid.UUID, milestone_id: uuid.UUID, db: DbSession,
                     p: Annotated[Principal, require("project.update")]):
    service.delete_milestone(db, p, project_id, milestone_id)
    return ok(project_out(db, p, service.get(db, project_id), detail=True))


# ------------------------------------------------------------------ BOQ tracking
@router.get("/projects/{project_id}/boq")
def project_boq(project_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("project.read")]):
    prj = _visible(db, p, project_id)
    return ok([line_out(ln) for ln in service.boq_lines(db, prj.id)])


BOQ_COLUMNS = [
    excel.Column("line_no", "#", 6), excel.Column("section", "Section", 22), excel.Column("description", "Description", 48),
    excel.Column("unit", "Unit", 8), excel.Column("approved_qty", "Approved qty", 13),
    excel.Column("procured_qty", "Procured", 11), excel.Column("issued_qty", "Issued", 11),
    excel.Column("installed_qty", "Installed", 11), excel.Column("remaining_qty", "Remaining", 11),
    excel.Column("rate", "Contract rate (₹)", 16), excel.Column("contract_amount", "Contract value (₹)", 18),
    excel.Column("installed_pct", "Installed %", 11), excel.Column("remarks", "Remarks", 30),
]


@router.get("/projects/{project_id}/boq/export")
def export_boq(project_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("project.export")]):
    from decimal import Decimal

    prj = _visible(db, p, project_id)
    rows = []
    for ln in service.boq_lines(db, prj.id):
        r = line_out(ln)
        for k in ("approved_qty", "procured_qty", "issued_qty", "installed_qty", "remaining_qty", "rate",
                  "contract_amount", "installed_pct"):
            r[k] = Decimal(r[k]) if r[k] is not None else None
        rows.append(r)
    audit.record(db, action="export", entity_type="project", entity_id=prj.id, entity_label=prj.project_number,
                 summary="BOQ tracking exported")
    name = prj.project_number.replace("/", "-")
    return Response(excel.export("BOQ tracking", BOQ_COLUMNS, rows), media_type=excel.XLSX,
                    headers={"Content-Disposition": f'attachment; filename="{name}-boq.xlsx"'})


@router.get("/projects/{project_id}/pdf")
def project_pdf(project_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("project.print")]):
    prj = _visible(db, p, project_id)
    audit.record(db, action="print", entity_type="project", entity_id=prj.id, entity_label=prj.project_number,
                 summary="Project status report")
    name = prj.project_number.replace("/", "-")
    return Response(pdf.build(db, prj), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{name}-status.pdf"',
                             "Cache-Control": "no-store"})


@router.post("/projects/{project_id}/boq-lines", status_code=201)
def add_line(project_id: uuid.UUID, body: BoqLineIn, db: DbSession, p: Annotated[Principal, require("project.update")]):
    return ok(line_out(service.add_boq_line(db, p, project_id, body)))


@router.put("/project-boq-lines/{line_id}")
def update_line(line_id: uuid.UUID, body: BoqLineIn, db: DbSession, p: Annotated[Principal, require("project.update")]):
    return ok(line_out(service.update_boq_line(db, p, line_id, body)))


@router.delete("/project-boq-lines/{line_id}")
def delete_line(line_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("project.update")]):
    service.delete_boq_line(db, p, line_id)
    return ok({"ok": True})


@router.get("/projects/{project_id}/installations")
def list_installations(project_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("project.read")],
                       boq_line_id: uuid.UUID | None = None):
    prj = _visible(db, p, project_id)
    rows = service.installations(db, prj.id, boq_line_id)
    lines = {ln.id: ln for ln in service.boq_lines(db, prj.id)}
    names = _names(db, [e.created_by for e in rows])
    can_delete = service.site_allowed(p, prj, "delete")
    return ok([{"id": str(e.id), "boq_line_id": str(e.boq_line_id), "line_no": lines[e.boq_line_id].line_no,
                "description": lines[e.boq_line_id].description, "unit": lines[e.boq_line_id].unit,
                "entry_date": e.entry_date.isoformat(), "quantity": _q(e.quantity), "location": e.location,
                "remarks": e.remarks, "site_report_id": str(e.site_report_id) if e.site_report_id else None,
                "recorded_by": names.get(e.created_by), "can_delete": can_delete} for e in rows])


@router.post("/projects/{project_id}/installations", status_code=201)
def add_installation(project_id: uuid.UUID, body: InstallationEntryIn, db: DbSession,
                     p: Annotated[Principal, require("site_work.create")]):
    e = service.add_installation(db, p, project_id, body)
    return ok(line_out(db.get(ProjectBoqLine, e.boq_line_id)))


@router.delete("/installations/{entry_id}")
def delete_installation(entry_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("site_work.delete")]):
    service.delete_installation(db, p, entry_id)
    return ok({"ok": True})


# ------------------------------------------------------------------ tasks
def _tasks_out(db, p, rows: list[ProjectTask]) -> list[dict]:
    projects = {x.id: x for x in db.scalars(select(Project).where(Project.id.in_({t.project_id for t in rows})))} \
        if rows else {}
    names = _names(db, [t.assigned_to for t in rows] + [t.created_by for t in rows])
    ms = dict(db.execute(select(ProjectMilestone.id, ProjectMilestone.name).where(
        ProjectMilestone.id.in_({t.milestone_id for t in rows} - {None}))).all()) if rows else {}
    return [task_out(db, p, t, projects[t.project_id], names, ms) for t in rows]


@router.get("/tasks")
def list_tasks(db: DbSession, p: Annotated[Principal, Depends(get_principal)],
               params: Annotated[ListParams, Depends()], mine: bool = False, project_id: uuid.UUID | None = None,
               status: str | None = Query(None), open_only: bool = False, overdue: bool = False):
    if not mine and p.scope("site_work.read") is None:
        raise Forbidden()
    rows, meta = service.list_tasks(db, p, params, mine=mine, project_id=project_id, status=status,
                                    open_only=open_only, overdue=overdue)
    return {"data": _tasks_out(db, p, rows), "meta": meta.model_dump()}


@router.get("/projects/{project_id}/tasks")
def project_tasks(project_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("project.read")]):
    prj = _visible(db, p, project_id)
    rows = db.scalars(select(ProjectTask).where(ProjectTask.project_id == prj.id)
                      .order_by(ProjectTask.status == "done", ProjectTask.due_date.nulls_last(),
                                ProjectTask.created_at)).all()
    return ok(_tasks_out(db, p, list(rows)))


@router.post("/projects/{project_id}/tasks", status_code=201)
def create_task(project_id: uuid.UUID, body: TaskIn, db: DbSession, p: Annotated[Principal, require("site_work.create")]):
    return ok(_tasks_out(db, p, [service.create_task(db, p, project_id, body)])[0])


@router.put("/tasks/{task_id}")
def update_task(task_id: uuid.UUID, body: TaskUpdate, db: DbSession, p: Annotated[Principal, require("site_work.update")]):
    return ok(_tasks_out(db, p, [service.update_task(db, p, task_id, body)])[0])


@router.post("/tasks/{task_id}/status")
def task_status(task_id: uuid.UUID, body: TaskStatusIn, db: DbSession, p: Annotated[Principal, Depends(get_principal)]):
    return ok(_tasks_out(db, p, [service.set_task_status(db, p, task_id, body.status, body.blocked_reason)])[0])


@router.delete("/tasks/{task_id}")
def delete_task(task_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("site_work.delete")]):
    service.delete_task(db, p, task_id)
    return ok({"ok": True})


# ------------------------------------------------------------------ issues
@router.get("/projects/{project_id}/issues")
def project_issues(project_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("project.read")]):
    prj = _visible(db, p, project_id)
    rows = db.scalars(select(ProjectIssue).where(ProjectIssue.project_id == prj.id)
                      .order_by(ProjectIssue.status != "open", ProjectIssue.created_at.desc())).all()
    names = _names(db, [i.assigned_to for i in rows] + [i.created_by for i in rows])
    return ok([issue_out(p, i, prj, names) for i in rows])


@router.post("/projects/{project_id}/issues", status_code=201)
def create_issue(project_id: uuid.UUID, body: IssueIn, db: DbSession, p: Annotated[Principal, require("site_work.create")]):
    i = service.create_issue(db, p, project_id, body)
    return ok(issue_out(p, i, service.get(db, project_id), _names(db, [i.assigned_to, i.created_by])))


@router.put("/issues/{issue_id}")
def update_issue(issue_id: uuid.UUID, body: IssueUpdate, db: DbSession,
                 p: Annotated[Principal, require("site_work.update")]):
    i = service.update_issue(db, p, issue_id, body)
    return ok(issue_out(p, i, service.get(db, i.project_id), _names(db, [i.assigned_to, i.created_by])))


@router.delete("/issues/{issue_id}")
def delete_issue(issue_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("site_work.delete")]):
    service.delete_issue(db, p, issue_id)
    return ok({"ok": True})


# ------------------------------------------------------------------ site reports
def _reports_out(db, p, rows: list[SiteReport]) -> list[dict]:
    projects = {x.id: x for x in db.scalars(select(Project).where(Project.id.in_({r.project_id for r in rows})))} \
        if rows else {}
    names = _names(db, [r.created_by for r in rows])
    return [report_out(db, p, r, projects[r.project_id], names) for r in rows]


@router.get("/site-reports")
def list_reports(db: DbSession, p: Annotated[Principal, require("site_work.read")],
                 params: Annotated[ListParams, Depends()], project_id: uuid.UUID | None = None,
                 date_from: date | None = None, date_to: date | None = None):
    rows, meta = service.list_reports(db, p, params, project_id=project_id, date_from=date_from, date_to=date_to)
    return {"data": _reports_out(db, p, rows), "meta": meta.model_dump()}


@router.post("/projects/{project_id}/site-reports", status_code=201)
def create_report(project_id: uuid.UUID, body: SiteReportIn, db: DbSession,
                  p: Annotated[Principal, require("site_work.create")]):
    return ok(_reports_out(db, p, [service.create_report(db, p, project_id, body)])[0])


@router.get("/site-reports/{report_id}")
def get_report(report_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("site_work.read")]):
    r = service.get_report(db, report_id)
    service.check_site(p, service.get(db, r.project_id), "read")
    return ok(_reports_out(db, p, [r])[0])


@router.put("/site-reports/{report_id}")
def update_report(report_id: uuid.UUID, body: SiteReportIn, db: DbSession,
                  p: Annotated[Principal, require("site_work.update")]):
    return ok(_reports_out(db, p, [service.update_report(db, p, report_id, body)])[0])


@router.delete("/site-reports/{report_id}")
def delete_report(report_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("site_work.delete")]):
    service.delete_report(db, p, report_id)
    return ok({"ok": True})
