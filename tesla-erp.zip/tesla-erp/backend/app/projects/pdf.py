"""Project status report: header, value and cost estimate, BOQ tracking, milestones, open tasks and issues."""
import io
from html import escape

from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.crm.service import today
from app.customers.models import Customer
from app.platform import pdfkit as K
from app.projects import service
from app.projects.models import Project, ProjectIssue, ProjectMilestone, ProjectTask
from app.users.models import User


def _d(d) -> str:
    return d.strftime("%d %b %Y") if d else "—"


def _q(v) -> str:
    return f"{v.normalize():f}"


def _grid(data, widths, st, head=True):
    t = Table(data, colWidths=widths, repeatRows=1 if head else 0)
    style = [("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 2.5),
             ("RIGHTPADDING", (0, 0), (-1, -1), 2.5), ("TOPPADDING", (0, 0), (-1, -1), 2.5),
             ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5), ("LINEBELOW", (0, 1), (-1, -1), 0.3, K.LINE)]
    if head:
        style += [("BACKGROUND", (0, 0), (-1, 0), K.TINT), ("LINEBELOW", (0, 0), (-1, 0), 0.8, K.RED)]
    t.setStyle(TableStyle(style))
    return t


def build(db: Session, prj: Project) -> bytes:
    K.fonts()
    st = K.styles()
    c = db.get(Customer, prj.customer_id)
    pm = db.scalar(select(User.full_name).where(User.id == prj.project_manager_id)) if prj.project_manager_id else None
    f = service.financials(db, prj)
    n = service.counts(db, prj.id)
    story = K.letterhead(db, st)
    story += [Paragraph("PROJECT STATUS REPORT", st["title"]),
              Paragraph(f"<b>{escape(prj.project_number)}</b> · {escape(prj.name)} · as on {_d(today())}", st["base"]),
              Spacer(1, 3 * mm)]
    info = [("Customer", c.customer_name if c else "—"), ("Project manager", pm or "—"),
            ("Status", prj.status.replace("_", " ").capitalize() + f" · {prj.progress_pct}% complete"),
            ("Dates", f"Start {_d(prj.start_date)} · target {_d(prj.target_end_date)}"
                      + (f" · finished {_d(prj.actual_end_date)}" if prj.actual_end_date else "")),
            ("Contract value", "₹ " + K.money(prj.contract_value) + " (before GST)"),
            ("Work installed", "₹ " + K.money(f["installed_value"])
             + (f" ({f['work_done_pct']}% of BOQ value)" if f["work_done_pct"] else "")),
            ("Tasks", f"{n['tasks_done']} of {n['tasks_total']} done · {n['tasks_overdue']} overdue · "
                      f"{n['tasks_blocked']} blocked"),
            ("Open issues", str(n["issues_open"]))]
    it = Table([[Paragraph(k, st["label"]), Paragraph(escape(v), st["cell"])] for k, v in info],
               colWidths=[35 * mm, None])
    it.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.5, K.LINE), ("LINEBELOW", (0, 0), (-1, -1), 0.3, K.LINE),
                            ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5)]))
    story += [it, Paragraph("BOQ tracking", st["h"])]
    head = ["#", "Description", "Unit", "Approved", "Procured", "Issued", "Installed", "Remaining", "%"]
    data = [[Paragraph(f"<b>{h}</b>", st["cellr"] if i >= 3 else st["cell"]) for i, h in enumerate(head)]]
    for ln in service.boq_lines(db, prj.id):
        rem = ln.approved_qty - ln.installed_qty
        pct = f"{ln.installed_qty * 100 / ln.approved_qty:.0f}" if ln.approved_qty else "—"
        data.append([Paragraph(str(ln.line_no), st["cell"]), Paragraph(escape(ln.description), st["cell"]),
                     Paragraph(escape(ln.unit), st["cell"])]
                    + [Paragraph(_q(v), st["cellr"]) for v in (ln.approved_qty, ln.procured_qty, ln.issued_qty,
                                                               ln.installed_qty, rem)]
                    + [Paragraph(pct, st["cellr"])])
    story.append(_grid(data, [7 * mm, 62 * mm, 12 * mm, 17 * mm, 18 * mm, 15 * mm, 17 * mm, 20 * mm, 10 * mm], st))
    ms = db.scalars(select(ProjectMilestone).where(ProjectMilestone.project_id == prj.id)
                    .order_by(ProjectMilestone.sort_order, ProjectMilestone.due_date)).all()
    if ms:
        story += [Paragraph("Milestones", st["h"]), _grid(
            [[Paragraph(f"<b>{h}</b>", st["cell"]) for h in ("Milestone", "Due", "Completed")]]
            + [[Paragraph(escape(m.name), st["cell"]), Paragraph(_d(m.due_date), st["cell"]),
                Paragraph(_d(m.completed_on), st["cell"])] for m in ms], [110 * mm, 36 * mm, 36 * mm], st)]
    tasks = db.scalars(select(ProjectTask).where(ProjectTask.project_id == prj.id, ProjectTask.status != "done")
                       .order_by(ProjectTask.due_date.nulls_last())).all()
    names = dict(db.execute(select(User.id, User.full_name)).all())
    if tasks:
        rows = [[Paragraph(f"<b>{h}</b>", st["cell"]) for h in ("Open task", "Assigned to", "Due", "Status")]]
        for t in tasks:
            late = " (late)" if t.due_date and t.due_date < today() else ""
            rows.append([Paragraph(escape(t.title), st["cell"]),
                         Paragraph(escape(names.get(t.assigned_to, "—")), st["cell"]),
                         Paragraph(_d(t.due_date) + late, st["cell"]),
                         Paragraph(t.status.replace("_", " "), st["cell"])])
        g = _grid(rows, [92 * mm, 40 * mm, 25 * mm, 25 * mm], st)
        story += [Paragraph("Open tasks", st["h"]), g]
    issues = db.scalars(select(ProjectIssue).where(ProjectIssue.project_id == prj.id, ProjectIssue.status == "open")).all()
    if issues:
        story += [Paragraph("Open issues", st["h"]), _grid(
            [[Paragraph(f"<b>{h}</b>", st["cell"]) for h in ("Issue", "Severity", "Raised")]]
            + [[Paragraph(escape(i.title), st["cell"]), Paragraph(i.severity, st["cell"]),
                Paragraph(_d(i.created_at), st["cell"])] for i in issues], [120 * mm, 30 * mm, 32 * mm], st)]
    story += [Spacer(1, 4 * mm), Paragraph(
        "Billing, collections, material and labour costs are added to this report as those modules go live.",
        st["small"])]
    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=K.PAGE, leftMargin=K.MARGIN, rightMargin=K.MARGIN, topMargin=10 * mm,
                      bottomMargin=14 * mm, title=f"Project {prj.project_number}").build(
        story, canvasmaker=K.numbered_canvas(f"Project {prj.project_number}"))
    return buf.getvalue()
