import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import Field, model_validator

from app.core.api import Schema
from app.core.validators import Text
from app.projects.models import ISSUE_SEVERITIES, ISSUE_STATUSES, PRIORITIES, PROJECT_STATUSES, TASK_STATUSES

Priority = Literal[PRIORITIES]  # type: ignore[valid-type]
TaskStatus = Literal[TASK_STATUSES]  # type: ignore[valid-type]
ProjectStatus = Literal[PROJECT_STATUSES]  # type: ignore[valid-type]
Severity = Literal[ISSUE_SEVERITIES]  # type: ignore[valid-type]
IssueStatus = Literal[ISSUE_STATUSES]  # type: ignore[valid-type]
Qty = Field(gt=0, max_digits=18, decimal_places=3)


class MemberIn(Schema):
    user_id: uuid.UUID
    role: Text(80) = None


class ProjectBase(Schema):
    name: str = Field(min_length=3, max_length=200)
    site_id: uuid.UUID | None = None
    division_id: uuid.UUID | None = None
    project_manager_id: uuid.UUID | None = None
    description: Text(4000) = None
    site_address: Text(500) = None
    start_date: date | None = None
    target_end_date: date | None = None
    priority: Priority = "normal"

    @model_validator(mode="after")
    def _dates(self):
        if self.start_date and self.target_end_date and self.target_end_date < self.start_date:
            raise ValueError("The target end date is before the start date.")
        return self


class ProjectIn(ProjectBase):
    """sales_order_id → customer, site, division and BOQ come from the order. Without it the project is standalone:
    customer_id is required and the contract value is entered."""
    sales_order_id: uuid.UUID | None = None
    customer_id: uuid.UUID | None = None
    contract_value: Decimal | None = Field(default=None, ge=0, max_digits=18, decimal_places=2)
    members: list[MemberIn] = Field(default_factory=list, max_length=50)

    @model_validator(mode="after")
    def _party(self):
        if not self.sales_order_id and not self.customer_id:
            raise ValueError("Choose the sales order, or the customer for a project without an order.")
        return self


class ProjectUpdate(ProjectBase):
    contract_value: Decimal | None = Field(default=None, ge=0, max_digits=18, decimal_places=2)
    row_version: int


class ProjectStatusIn(Schema):
    status: ProjectStatus
    reason: Text(500) = None
    row_version: int | None = None


class ProgressIn(Schema):
    progress_pct: int = Field(ge=0, le=100)


class MilestoneIn(Schema):
    name: str = Field(min_length=2, max_length=200)
    due_date: date | None = None
    completed_on: date | None = None
    sort_order: int = 0
    notes: Text(500) = None


class TaskIn(Schema):
    title: str = Field(min_length=2, max_length=200)
    description: Text(4000) = None
    milestone_id: uuid.UUID | None = None
    assigned_to: uuid.UUID | None = None
    start_date: date | None = None
    due_date: date | None = None
    priority: Priority = "normal"


class TaskUpdate(TaskIn):
    status: TaskStatus = "todo"
    blocked_reason: Text(500) = None
    row_version: int


class TaskStatusIn(Schema):
    status: TaskStatus
    blocked_reason: Text(500) = None


class IssueIn(Schema):
    title: str = Field(min_length=3, max_length=200)
    description: Text(4000) = None
    severity: Severity = "normal"
    assigned_to: uuid.UUID | None = None


class IssueUpdate(IssueIn):
    status: IssueStatus = "open"
    resolution: Text(4000) = None
    row_version: int


class InstallationIn(Schema):
    boq_line_id: uuid.UUID
    quantity: Decimal = Qty
    location: Text(200) = None
    remarks: Text(500) = None


class SiteReportIn(Schema):
    report_date: date
    work_done: str = Field(min_length=3, max_length=4000)
    manpower: int | None = Field(default=None, ge=0, le=5000)
    weather: Text(60) = None
    hindrances: Text(4000) = None
    next_plan: Text(4000) = None
    progress_pct: int | None = Field(default=None, ge=0, le=100)
    installations: list[InstallationIn] = Field(default_factory=list, max_length=200)


class InstallationEntryIn(InstallationIn):
    entry_date: date


class BoqLineIn(Schema):
    """A line added on the project (variation / extra work not on the order)."""
    section: Text(120) = None
    item_id: uuid.UUID | None = None
    description: str = Field(min_length=2, max_length=4000)
    unit: str = Field(min_length=1, max_length=20)
    approved_qty: Decimal = Field(ge=0, max_digits=18, decimal_places=3)
    rate: Decimal = Field(default=Decimal("0"), ge=0, max_digits=18, decimal_places=4)
    remarks: Text(500) = None
