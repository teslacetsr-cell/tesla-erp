"""BOQ business logic (Spec §13)."""
import uuid
from decimal import Decimal

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.boq import lines as L
from app.boq.models import Boq, BoqItem
from app.boq.schemas import BoqIn, BoqUpdate
from app.company.models import BusinessDivision
from app.core.api import ListParams, paginate
from app.core.errors import AppError, Conflict, NotFound
from app.core.models import check_row_version
from app.crm.models import Enquiry
from app.customers.models import Customer, CustomerSite
from app.platform.audit import service as audit
from app.platform.numbering import service as numbering


def get(db: Session, boq_id: uuid.UUID, lock: bool = False) -> Boq:
    b = db.get(Boq, boq_id, with_for_update=lock or None)
    if b is None:
        raise NotFound("boq")
    return b


def list_boqs(db: Session, params: ListParams, *, customer_id=None, enquiry_id=None, status=None):
    stmt = select(Boq)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(Boq.boq_number.ilike(like), Boq.title.ilike(like),
                              Boq.customer_id.in_(select(Customer.id).where(Customer.customer_name.ilike(like)))))
    for col, val in ((Boq.customer_id, customer_id), (Boq.enquiry_id, enquiry_id), (Boq.status, status)):
        if val:
            stmt = stmt.where(col == val)
    return paginate(db, stmt, params, default_sort=Boq.created_at.desc(), sortable={
        "boq_number": Boq.boq_number, "title": Boq.title, "created_at": Boq.created_at, "total": Boq.total})


def _refs(db: Session, data: BoqIn) -> dict:
    """Resolve customer/site from the enquiry when given; check everything belongs together."""
    values = data.model_dump(exclude={"items"})
    if data.enquiry_id:
        enq = db.get(Enquiry, data.enquiry_id)
        if enq is None:
            raise AppError("INVALID_ENQUIRY", "The enquiry does not exist.")
        if data.customer_id and data.customer_id != enq.customer_id:
            raise AppError("CUSTOMER_MISMATCH", "The enquiry belongs to a different customer.")
        values["customer_id"] = enq.customer_id
        values["site_id"] = data.site_id or enq.site_id
        values["division_id"] = data.division_id or enq.division_id
    if values["customer_id"] and db.get(Customer, values["customer_id"]) is None:
        raise AppError("INVALID_CUSTOMER", "The customer does not exist.")
    if values["site_id"]:
        s = db.get(CustomerSite, values["site_id"])
        if s is None or s.customer_id != values["customer_id"]:
            raise AppError("INVALID_SITE", "The site does not belong to this customer.")
    if values["division_id"] and db.get(BusinessDivision, values["division_id"]) is None:
        raise AppError("INVALID_DIVISION", "The business division does not exist.")
    return values


def _apply_lines(db: Session, p: Principal, b: Boq, lines: list[L.LineIn]) -> None:
    if lines:
        L.validate(db, lines)
    customer = db.get(Customer, b.customer_id) if b.customer_id else None
    site = db.get(CustomerSite, b.site_id) if b.site_id else None
    b.inter_state = L.inter_state_for(db, p.company_id, L.place_of_supply(customer, site))
    rows, t = L.compute(lines, inter_state=b.inter_state, round_total=False) if lines else ([], None)
    b.items.clear()
    db.flush()
    for r in rows:
        r.pop("special_discount")
        b.items.append(BoqItem(**r, created_by=p.id, updated_by=p.id))
    zero = Decimal("0")
    b.gross = t.gross if t else zero
    b.line_discount = t.line_discount if t else zero
    b.taxable = t.taxable if t else zero
    b.tax_total = t.tax_total if t else zero
    b.total = t.grand_total if t else zero


def create(db: Session, p: Principal, data: BoqIn) -> Boq:
    values = _refs(db, data)
    b = Boq(boq_number=numbering.next_number(db, p.company_id, "BOQ"), **values, status="draft",
            created_by=p.id, updated_by=p.id)
    db.add(b)
    db.flush()
    _apply_lines(db, p, b, data.items)
    db.flush()
    audit.record(db, action="create", entity_type="boq", entity_id=b.id, entity_label=f"{b.boq_number} {b.title}",
                 summary=f"{len(b.items)} lines, ₹{b.taxable} before GST")
    return b


def update(db: Session, p: Principal, boq_id: uuid.UUID, data: BoqUpdate) -> Boq:
    b = get(db, boq_id, lock=True)
    if b.status == "final":
        raise AppError("BOQ_FINAL", "This BOQ is final. Reopen it as a draft (or copy it) to change it.")
    check_row_version(b, data.row_version)
    before = {"lines": len(b.items), "taxable": str(b.taxable), "total": str(b.total)}
    for k, v in _refs(db, data).items():
        if k != "row_version":
            setattr(b, k, v)
    _apply_lines(db, p, b, data.items)
    b.updated_by = p.id
    db.flush()
    audit.record(db, action="update", entity_type="boq", entity_id=b.id, entity_label=f"{b.boq_number} {b.title}",
                 summary=f"Lines {before['lines']} → {len(b.items)}; before GST ₹{before['taxable']} → ₹{b.taxable}")
    return b


def set_status(db: Session, p: Principal, boq_id: uuid.UUID, status: str) -> Boq:
    b = get(db, boq_id, lock=True)
    if status not in ("draft", "final"):
        raise AppError("INVALID_STATUS", "Status must be draft or final.")
    if status == "final" and not b.items:
        raise AppError("NO_LINES", "Add lines before marking the BOQ final.")
    before = b.status
    b.status, b.updated_by = status, p.id
    b.row_version += 1
    db.flush()
    audit.record(db, action="status", entity_type="boq", entity_id=b.id, entity_label=b.boq_number,
                 summary=f"Status {before} → {status}")
    return b


def copy(db: Session, p: Principal, boq_id: uuid.UUID) -> Boq:
    src = get(db, boq_id)
    b = Boq(boq_number=numbering.next_number(db, p.company_id, "BOQ"), title=f"{src.title} (copy)"[:200],
            customer_id=src.customer_id, enquiry_id=src.enquiry_id, site_id=src.site_id, division_id=src.division_id,
            notes=src.notes, status="draft", created_by=p.id, updated_by=p.id)
    db.add(b)
    db.flush()
    _apply_lines(db, p, b, [to_line_in(i) for i in src.items])
    db.flush()
    audit.record(db, action="create", entity_type="boq", entity_id=b.id, entity_label=f"{b.boq_number} {b.title}",
                 summary=f"Copied from {src.boq_number}")
    return b


def to_line_in(i) -> L.LineIn:
    return L.LineIn(section=i.section, item_id=i.item_id, description=i.description,
                    technical_specification=i.technical_specification, hsn_sac=i.hsn_sac, quantity=i.quantity,
                    unit=i.unit, rate=i.rate, discount_pct=i.discount_pct, tax_rate=i.tax_rate, remarks=i.remarks)


def import_lines(db: Session, p: Principal, boq_id: uuid.UUID, data: bytes, *, mode: str, dry_run: bool) -> dict:
    b = get(db, boq_id, lock=not dry_run)
    if b.status == "final":
        raise AppError("BOQ_FINAL", "This BOQ is final. Reopen it as a draft to import lines.")
    lines, errors = L.parse_excel(db, data)
    existing = [] if mode == "replace" else [to_line_in(i) for i in b.items]
    preview_rows, t = L.compute(existing + lines, inter_state=b.inter_state, round_total=False) if (existing + lines) \
        else ([], None)
    report = {"rows": len(lines) + len({e["row"] for e in errors}), "valid": len(lines), "errors": errors,
              "mode": mode, "committed": False, "lines_after": len(existing) + len(lines),
              "totals": L.totals_out(t) if t else None}
    if not dry_run and not errors and lines:
        _apply_lines(db, p, b, existing + lines)
        b.updated_by = p.id
        b.row_version += 1
        db.flush()
        audit.record(db, action="import", entity_type="boq", entity_id=b.id, entity_label=b.boq_number,
                     summary=f"Imported {len(lines)} lines from Excel ({mode})")
        report["committed"] = True
    return report


def delete(db: Session, p: Principal, boq_id: uuid.UUID) -> None:
    from app.quotations.models import Quotation

    b = get(db, boq_id, lock=True)
    if db.scalar(select(func.count()).select_from(Quotation).where(Quotation.boq_id == b.id)):
        raise Conflict("IN_USE", "Quotations were made from this BOQ, so it cannot be deleted.")
    label = f"{b.boq_number} {b.title}"
    db.delete(b)
    db.flush()
    audit.record(db, action="delete", entity_type="boq", entity_id=boq_id, entity_label=label)
