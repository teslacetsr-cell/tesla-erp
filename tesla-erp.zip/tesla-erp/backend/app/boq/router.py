import uuid
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, File, Query, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy import select

from app.auth.deps import Principal, require
from app.boq import lines as L
from app.boq import pdf, service
from app.boq.models import Boq
from app.boq.schemas import BoqIn, BoqUpdate
from app.company.models import BusinessDivision
from app.core import excel
from app.core.api import ListParams, ok
from app.core.db import DbSession
from app.crm.models import Enquiry
from app.customers.models import Customer, CustomerSite
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.users.models import User

router = APIRouter(prefix="/boqs", tags=["boq"])
documents.register_entity("boq", "boq", Boq)


def boq_out(db, b: Boq, detail: bool = False) -> dict:
    c = db.get(Customer, b.customer_id) if b.customer_id else None
    out = {
        "id": str(b.id), "boq_number": b.boq_number, "title": b.title, "status": b.status,
        "customer_id": str(b.customer_id) if b.customer_id else None,
        "customer": {"id": str(c.id), "name": c.customer_name, "code": c.customer_code, "city": c.city} if c else None,
        "enquiry_id": str(b.enquiry_id) if b.enquiry_id else None,
        "enquiry_number": db.scalar(select(Enquiry.enquiry_number).where(Enquiry.id == b.enquiry_id)) if b.enquiry_id else None,
        "site_id": str(b.site_id) if b.site_id else None,
        "site": db.scalar(select(CustomerSite.site_name).where(CustomerSite.id == b.site_id)) if b.site_id else None,
        "division_id": str(b.division_id) if b.division_id else None,
        "division": db.scalar(select(BusinessDivision.name).where(BusinessDivision.id == b.division_id)) if b.division_id else None,
        "inter_state": b.inter_state, "gross": str(b.gross), "line_discount": str(b.line_discount),
        "taxable": str(b.taxable), "tax_total": str(b.tax_total), "total": str(b.total),
        "line_count": len(b.items), "created_at": b.created_at.isoformat(), "row_version": b.row_version,
    }
    if detail:
        out |= {"notes": b.notes, "items": [L.line_out(i) for i in b.items], "updated_at": b.updated_at.isoformat(),
                "created_by": db.scalar(select(User.full_name).where(User.id == b.created_by)) if b.created_by else None}
    return out


@router.get("")
def list_boqs(db: DbSession, _: Annotated[Principal, require("boq.read")], params: Annotated[ListParams, Depends()],
              customer_id: uuid.UUID | None = None, enquiry_id: uuid.UUID | None = None,
              status: str | None = Query(None)):
    rows, meta = service.list_boqs(db, params, customer_id=customer_id, enquiry_id=enquiry_id, status=status)
    return {"data": [boq_out(db, b) for b in rows], "meta": meta.model_dump()}


@router.get("/options")
def boq_options(db: DbSession, _: Annotated[Principal, require("boq.read")]):
    """GST rates allowed on lines (from the GST master)."""
    return ok({"gst_rates": sorted((f"{r:f}" for r in L.gst_rates(db)), key=float)})


@router.get("/import-template")
def import_template(_: Annotated[Principal, require("boq.read")]):
    return Response(L.template(), media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="boq-import-template.xlsx"'})


@router.post("", status_code=201)
def create_boq(body: BoqIn, db: DbSession, p: Annotated[Principal, require("boq.create")]):
    return ok(boq_out(db, service.create(db, p, body), detail=True))


@router.get("/{boq_id}")
def get_boq(boq_id: uuid.UUID, db: DbSession, _: Annotated[Principal, require("boq.read")]):
    return ok(boq_out(db, service.get(db, boq_id), detail=True))


@router.put("/{boq_id}")
def update_boq(boq_id: uuid.UUID, body: BoqUpdate, db: DbSession, p: Annotated[Principal, require("boq.update")]):
    return ok(boq_out(db, service.update(db, p, boq_id, body), detail=True))


class StatusIn(BaseModel):
    status: Literal["draft", "final"]


@router.post("/{boq_id}/status")
def boq_status(boq_id: uuid.UUID, body: StatusIn, db: DbSession, p: Annotated[Principal, require("boq.update")]):
    return ok(boq_out(db, service.set_status(db, p, boq_id, body.status), detail=True))


@router.post("/{boq_id}/copy", status_code=201)
def copy_boq(boq_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("boq.create")]):
    return ok(boq_out(db, service.copy(db, p, boq_id), detail=True))


@router.delete("/{boq_id}")
def delete_boq(boq_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("boq.delete")]):
    service.delete(db, p, boq_id)
    return ok({"ok": True})


@router.post("/{boq_id}/import")
async def import_boq(boq_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("boq.update")],
                     file: UploadFile = File(...), dry_run: bool = Query(True),
                     mode: Literal["append", "replace"] = Query("append")):
    return ok(service.import_lines(db, p, boq_id, await file.read(), mode=mode, dry_run=dry_run))


@router.get("/{boq_id}/export")
def export_boq(boq_id: uuid.UUID, db: DbSession, _: Annotated[Principal, require("boq.export")]):
    b = service.get(db, boq_id)
    rows = [L.line_out(i) | {"item_code": None, "amount": i.taxable} for i in b.items]
    codes = {}
    from app.products.models import Item

    ids = {i.item_id for i in b.items if i.item_id}
    if ids:
        codes = dict(db.execute(select(Item.id, Item.item_code).where(Item.id.in_(ids))).all())
    for r, i in zip(rows, b.items, strict=True):
        r["item_code"] = codes.get(i.item_id)
        for k in ("quantity", "rate", "discount_pct", "tax_rate"):
            r[k] = getattr(i, k)
    audit.record(db, action="export", entity_type="boq", entity_id=b.id, entity_label=b.boq_number,
                 summary=f"Exported {len(rows)} lines")
    name = b.boq_number.replace("/", "-")
    return Response(L.export_excel("BOQ", rows), media_type=excel.XLSX,
                    headers={"Content-Disposition": f'attachment; filename="{name}.xlsx"'})


@router.get("/{boq_id}/pdf")
def boq_pdf(boq_id: uuid.UUID, db: DbSession, _: Annotated[Principal, require("boq.print")]):
    b = service.get(db, boq_id)
    name = b.boq_number.replace("/", "-")
    return Response(pdf.build(db, b), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{name}.pdf"', "Cache-Control": "no-store"})
