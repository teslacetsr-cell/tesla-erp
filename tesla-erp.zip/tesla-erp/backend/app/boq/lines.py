"""Line items shared by BOQs and quotations (and later sales orders / invoices): input schema, validation against
the item and GST masters, the calculation, and Excel import/export of lines."""
import re
import uuid
from decimal import Decimal, InvalidOperation
from typing import Any

from pydantic import Field, ValidationError, field_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.company.models import Company
from app.core import excel
from app.core.api import Schema
from app.core.errors import AppError
from app.core.gst import CalcError, Totals, calculate, is_inter_state
from app.core.gst import LineIn as CalcLine
from app.core.money import round_qty, round_rate
from app.core.validators import Text
from app.customers.models import Customer, CustomerSite
from app.products.models import Item, TaxRate

_HSN = re.compile(r"^[0-9]{4,8}$")


class LineIn(Schema):
    section: Text(120) = None
    item_id: uuid.UUID | None = None
    description: str = Field(min_length=1, max_length=2000)
    technical_specification: Text(4000) = None
    hsn_sac: Text(8) = None
    quantity: Decimal = Field(gt=0, max_digits=18, decimal_places=3)
    unit: str = Field(min_length=1, max_length=20)
    rate: Decimal = Field(ge=0, max_digits=18, decimal_places=4)
    discount_pct: Decimal = Field(default=Decimal("0"), ge=0, le=100, max_digits=7, decimal_places=4)
    tax_rate: Decimal = Field(default=Decimal("18"), ge=0, le=100, max_digits=7, decimal_places=4)
    remarks: Text(500) = None

    @field_validator("hsn_sac")
    @classmethod
    def _hsn(cls, v):
        if v and not _HSN.match(v):
            raise ValueError("HSN/SAC must be 4 to 8 digits.")
        return v

    @field_validator("unit")
    @classmethod
    def _unit(cls, v: str) -> str:
        return v.strip().upper()


def gst_rates(db: Session) -> set[Decimal]:
    """GST rates allowed on documents = the active rates in the tax-rate master (never hard-coded)."""
    return {r.normalize() for r in db.scalars(select(TaxRate.rate).where(TaxRate.is_active.is_(True)))}


def validate(db: Session, lines: list[LineIn]) -> None:
    if not lines:
        raise AppError("NO_LINES", "Add at least one line.")
    if len(lines) > 1000:
        raise AppError("TOO_MANY_LINES", "A document can have at most 1,000 lines.")
    allowed = gst_rates(db)
    item_ids = {ln.item_id for ln in lines if ln.item_id}
    found = set(db.scalars(select(Item.id).where(Item.id.in_(item_ids)))) if item_ids else set()
    for i, ln in enumerate(lines, start=1):
        if ln.item_id and ln.item_id not in found:
            raise AppError("INVALID_ITEM", f"Line {i}: the item no longer exists.", details={"line": i})
        if allowed and ln.tax_rate.normalize() not in allowed:
            raise AppError("INVALID_GST_RATE", f"Line {i}: GST {ln.tax_rate.normalize():f} % is not in the GST rate master.",
                           details={"line": i, "allowed": sorted(str(r) for r in allowed)})


def compute(lines: list[LineIn], *, inter_state: bool, special_discount: Decimal = Decimal("0"),
            round_total: bool = True) -> tuple[list[dict], Totals]:
    try:
        outs, totals = calculate([CalcLine(ln.quantity, ln.rate, ln.discount_pct, ln.tax_rate) for ln in lines],
                                 inter_state=inter_state, special_discount=special_discount, round_total=round_total)
    except CalcError as exc:
        raise AppError("CALCULATION_ERROR", str(exc)) from exc
    rows = []
    for n, (ln, o) in enumerate(zip(lines, outs, strict=True), start=1):
        rows.append({
            "line_no": n, "section": ln.section, "item_id": ln.item_id, "description": ln.description,
            "technical_specification": ln.technical_specification, "hsn_sac": ln.hsn_sac,
            "quantity": round_qty(ln.quantity), "unit": ln.unit, "rate": round_rate(ln.rate),
            "discount_pct": ln.discount_pct, "tax_rate": ln.tax_rate, "remarks": ln.remarks,
            "amount": o.amount, "discount_amount": o.discount_amount, "special_discount": o.special_discount,
            "taxable": o.taxable, "cgst": o.cgst, "sgst": o.sgst, "igst": o.igst, "total": o.total,
        })
    return rows, totals


def totals_out(t: Totals) -> dict:
    s = str
    return {"gross": s(t.gross), "line_discount": s(t.line_discount), "special_discount": s(t.special_discount),
            "taxable": s(t.taxable), "cgst": s(t.cgst), "sgst": s(t.sgst), "igst": s(t.igst),
            "tax_total": s(t.tax_total), "round_off": s(t.round_off), "grand_total": s(t.grand_total),
            "inter_state": t.inter_state,
            "tax_summary": [{k: (str(v) if isinstance(v, Decimal) else v) for k, v in r.items()} for r in t.tax_summary]}


def line_out(row) -> dict:
    """Serialise a stored line (BoqItem / QuotationItem)."""
    g = lambda k: getattr(row, k, None)  # noqa: E731
    out = {"id": str(row.id), "line_no": row.line_no, "section": row.section,
           "item_id": str(row.item_id) if row.item_id else None, "description": row.description,
           "technical_specification": row.technical_specification, "hsn_sac": row.hsn_sac,
           "quantity": str(round_qty(row.quantity)), "unit": row.unit, "rate": str(round_rate(row.rate)),
           "discount_pct": f"{row.discount_pct.normalize():f}", "tax_rate": f"{row.tax_rate.normalize():f}",
           "remarks": row.remarks}
    for k in ("amount", "discount_amount", "special_discount", "taxable", "cgst", "sgst", "igst", "total"):
        if g(k) is not None:
            out[k] = str(g(k))
    return out


# ------------------------------------------------------------------ place of supply
def company_state(db: Session, company_id: uuid.UUID) -> str | None:
    c = db.get(Company, company_id)
    return c.state_code if c else None


def place_of_supply(customer: Customer | None, site: CustomerSite | None) -> str | None:
    """Where the work is supplied: the site's state, else the customer's billing state."""
    if site is not None and site.state_code:
        return site.state_code
    return customer.state_code if customer is not None else None


def inter_state_for(db: Session, company_id: uuid.UUID, pos: str | None) -> bool:
    return is_inter_state(company_state(db, company_id), pos)


# ------------------------------------------------------------------ Excel
COLUMNS = [
    excel.Column("section", "Section", 18, note="Optional group heading, e.g. External LPS"),
    excel.Column("item_code", "Item code", 16, note="Optional. Fills description, unit, rate, GST and HSN from the item master"),
    excel.Column("description", "Description", 45, note="Required unless an item code is given"),
    excel.Column("technical_specification", "Technical specification", 40),
    excel.Column("hsn_sac", "HSN/SAC", 10),
    excel.Column("quantity", "Qty", 10, required=True),
    excel.Column("unit", "Unit", 8, note="NOS, M, KG, SET, JOB…"),
    excel.Column("rate", "Rate", 12, note="Rate per unit, before GST"),
    excel.Column("discount_pct", "Discount %", 10),
    excel.Column("tax_rate", "GST %", 8, note="Must be a rate in the GST master (0, 5, 12, 18, 28)"),
    excel.Column("remarks", "Remarks", 24),
    excel.Column("amount", "Amount (before GST)", 16, note="Filled on export; ignored on import"),
]
IMPORT_COLUMNS = [c for c in COLUMNS if c.key != "amount"]


def _dec(v: Any) -> Decimal | None:
    if v is None or v == "":
        return None
    try:
        return Decimal(str(v).replace(",", "").replace("%", "").strip())
    except InvalidOperation as exc:
        raise ValueError(f"'{v}' is not a number") from exc


def parse_excel(db: Session, data: bytes) -> tuple[list[LineIn], list[dict]]:
    """Validates every row; returns (lines, errors). Row numbers in errors are Excel row numbers."""
    rows = excel.read(data, IMPORT_COLUMNS)
    codes = {str(r["item_code"]).strip().upper() for _, r in rows if r.get("item_code")}
    items = {i.item_code.upper(): i for i in db.scalars(select(Item).where(Item.item_code.in_(codes)))} if codes else {}
    allowed = gst_rates(db)
    lines: list[LineIn] = []
    errors: list[dict] = []
    for n, raw in rows:
        try:
            vals: dict[str, Any] = {k: raw.get(k) for k in ("section", "description", "technical_specification",
                                                            "remarks")}
            for k in ("quantity", "rate", "discount_pct", "tax_rate"):
                vals[k] = _dec(raw.get(k))
            vals["hsn_sac"] = str(raw["hsn_sac"]) if raw.get("hsn_sac") is not None else None
            vals["unit"] = str(raw["unit"]) if raw.get("unit") is not None else None
            code = str(raw.get("item_code") or "").strip().upper()
            if code:
                it = items.get(code)
                if it is None:
                    raise ValueError(f"item code {code} is not in the item master")
                vals["item_id"] = it.id
                vals["description"] = vals["description"] or it.item_name
                vals["technical_specification"] = vals["technical_specification"] or it.technical_specification
                vals["hsn_sac"] = vals["hsn_sac"] or it.hsn_sac
                vals["unit"] = vals["unit"] or it.unit.code
                if vals["rate"] is None:
                    vals["rate"] = it.selling_price
                if vals["tax_rate"] is None and it.tax_rate is not None:
                    vals["tax_rate"] = it.tax_rate.rate
            vals["unit"] = vals["unit"] or "NOS"
            if vals["rate"] is None:
                raise ValueError("Rate is required")
            if vals["discount_pct"] is None:
                vals["discount_pct"] = Decimal("0")
            if vals["tax_rate"] is None:
                vals["tax_rate"] = Decimal("18")
            if vals["quantity"] is not None:
                vals["quantity"] = round_qty(vals["quantity"])
            vals["rate"] = round_rate(vals["rate"])
            line = LineIn.model_validate({k: v for k, v in vals.items() if v is not None})
            if allowed and line.tax_rate.normalize() not in allowed:
                raise ValueError(f"GST {line.tax_rate.normalize():f} % is not in the GST master")
            lines.append(line)
        except ValidationError as exc:
            for e in exc.errors():
                field = str(e["loc"][0]) if e["loc"] else ""
                errors.append({"row": n, "field": field, "message": e["msg"].replace("Value error, ", "")})
        except ValueError as exc:
            errors.append({"row": n, "field": "", "message": str(exc)})
    return lines, errors


def export_excel(title: str, rows: list[dict]) -> bytes:
    return excel.export(title, COLUMNS, rows)


def template() -> bytes:
    return excel.template("BOQ", COLUMNS, example={
        "section": "External LPS", "item_code": "LP-AT-16", "quantity": 12, "discount_pct": 0,
        "remarks": "Air terminals on roof parapet"})
