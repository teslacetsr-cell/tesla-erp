"""BOQ PDF, and the priced-lines table shared with the quotation PDF."""
import io
from html import escape

from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.platypus import KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from sqlalchemy.orm import Session

from app.boq.models import Boq
from app.core.money import round_qty
from app.customers.models import Customer, CustomerSite
from app.platform import pdfkit as K

WIDTHS = [6 * mm, 64 * mm, 17 * mm, 14 * mm, 11 * mm, 22 * mm, 12 * mm, 25 * mm, 11 * mm]  # = 182 mm (A4 − margins)


def _qty(v) -> str:
    q = round_qty(v).normalize()
    return f"{q:f}"


def lines_table(rows, st) -> Table:
    """rows: stored line objects (BoqItem / QuotationItem). Grouped by section, in line order."""
    head = ["#", "Description", "HSN/SAC", "Qty", "Unit", "Rate (₹)", "Disc%", "Amount (₹)", "GST%"]
    data = [[Paragraph(f"<b>{h}</b>", st["cellr"] if i >= 3 and i != 4 else st["cell"]) for i, h in enumerate(head)]]
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), K.TINT), ("LINEBELOW", (0, 0), (-1, 0), 0.8, K.RED),
        ("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 2.5), ("RIGHTPADDING", (0, 0), (-1, -1), 2.5),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    section = object()
    n = 0
    for r in rows:
        if r.section != section and r.section:
            data.append([Paragraph(f"<b>{escape(r.section)}</b>", st["cellb"])] + [""] * 8)
            i = len(data) - 1
            style += [("SPAN", (0, i), (-1, i)), ("BACKGROUND", (0, i), (-1, i), colors.HexColor("#f9fafb"))]
        section = r.section
        n += 1
        desc = f"<b>{escape(r.description)}</b>"
        if r.technical_specification:
            desc += f"<br/><font size=6.8 color='#6b7280'>{escape(r.technical_specification).replace(chr(10), '<br/>')}</font>"
        if r.remarks:
            desc += f"<br/><font size=6.8 color='#6b7280'><i>{escape(r.remarks)}</i></font>"
        disc = r.discount_pct.normalize()
        data.append([
            Paragraph(str(n), st["cell"]), Paragraph(desc, st["cell"]), Paragraph(r.hsn_sac or "", st["cell"]),
            Paragraph(_qty(r.quantity), st["cellr"]), Paragraph(escape(r.unit), st["cell"]),
            Paragraph(K.money(r.rate), st["cellr"]), Paragraph(f"{disc:f}" if disc else "", st["cellr"]),
            Paragraph(K.money(r.taxable), st["cellr"]), Paragraph(f"{r.tax_rate.normalize():f}", st["cellr"]),
        ])
        style.append(("LINEBELOW", (0, len(data) - 1), (-1, len(data) - 1), 0.3, K.LINE))
    t = Table(data, colWidths=WIDTHS, repeatRows=1)
    t.setStyle(TableStyle(style))
    return t


def totals_table(rows: list[tuple[str, str, bool]], st, width=80 * mm) -> Table:
    data = [[Paragraph(f"<b>{escape(k)}</b>" if bold else escape(k), st["cellr"]),
             Paragraph(f"<b>{v}</b>" if bold else v, st["cellr"])] for k, v, bold in rows]
    t = Table(data, colWidths=[width - 30 * mm, 30 * mm], hAlign="RIGHT")
    last = len(data) - 1
    t.setStyle(TableStyle([("LINEABOVE", (0, last), (-1, last), 0.8, K.INK), ("TOPPADDING", (0, 0), (-1, -1), 2),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 2), ("BACKGROUND", (0, last), (-1, last), K.TINT)]))
    return t


def build(db: Session, b: Boq) -> bytes:
    K.fonts()
    st = K.styles()
    customer = db.get(Customer, b.customer_id) if b.customer_id else None
    site = db.get(CustomerSite, b.site_id) if b.site_id else None
    story = K.letterhead(db, st)
    head = Table([[Paragraph("BILL OF QUANTITIES", st["title"]),
                   Paragraph(f"<b>{escape(b.boq_number)}</b><br/>{'Final' if b.status == 'final' else 'Draft'}",
                             st["right"])]], colWidths=[None, 60 * mm])
    head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "BOTTOM"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                              ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    story += [head, Spacer(1, 3 * mm), Paragraph(f"<b>{escape(b.title)}</b>", st["base"])]
    meta = " · ".join(x for x in (customer.customer_name if customer else None, site.site_name if site else None) if x)
    if meta:
        story.append(Paragraph(escape(meta), st["small"]))
    story += [Spacer(1, 3 * mm), lines_table(b.items, st), Spacer(1, 3 * mm)]
    rows = [("Total before discount", K.money(b.gross), False)]
    if b.line_discount:
        rows.append(("Discount", "− " + K.money(b.line_discount), False))
    rows += [("Taxable value", K.money(b.taxable), False),
             ("GST (IGST)" if b.inter_state else "GST (CGST + SGST)", K.money(b.tax_total), False),
             ("Total including GST (₹)", K.money(b.total), True)]
    story.append(KeepTogether(totals_table(rows, st)))
    if b.notes:
        story += [Paragraph("Notes", st["h"]), K.p(b.notes, st["base"])]
    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=K.PAGE, leftMargin=K.MARGIN, rightMargin=K.MARGIN, topMargin=10 * mm,
                      bottomMargin=14 * mm, title=f"BOQ {b.boq_number}").build(
        story, canvasmaker=K.numbered_canvas(f"BOQ {b.boq_number}"))
    return buf.getvalue()
