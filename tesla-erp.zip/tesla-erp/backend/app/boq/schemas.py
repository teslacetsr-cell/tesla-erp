import uuid

from pydantic import Field

from app.boq.lines import LineIn
from app.core.api import Schema
from app.core.validators import Text


class BoqIn(Schema):
    title: str = Field(min_length=3, max_length=200)
    customer_id: uuid.UUID | None = None
    enquiry_id: uuid.UUID | None = None
    site_id: uuid.UUID | None = None
    division_id: uuid.UUID | None = None
    notes: Text(4000) = None
    items: list[LineIn] = Field(default_factory=list, max_length=1000)


class BoqUpdate(BoqIn):
    row_version: int
