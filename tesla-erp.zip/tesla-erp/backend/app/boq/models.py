"""Bill of quantities (Spec §13): a standalone, reusable list of priced lines. A quotation copies its lines from a
BOQ; projects, procurement and billing will reuse the same BOQ in later phases."""
import uuid
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.models import AuditColumnsMixin, Base
from app.core.money import AMOUNT, PERCENT, QTY, RATE

BOQ_STATUSES = ("draft", "final")


class LineColumns:
    """Columns every priced line carries (BOQ, quotation, later SO/invoice)."""

    line_no: Mapped[int] = mapped_column(Integer, nullable=False)
    section: Mapped[str | None] = mapped_column(String(120))
    item_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("items.id", ondelete="RESTRICT"))
    description: Mapped[str] = mapped_column(Text, nullable=False)
    technical_specification: Mapped[str | None] = mapped_column(Text)
    hsn_sac: Mapped[str | None] = mapped_column(String(8))
    quantity: Mapped[Decimal] = mapped_column(QTY, nullable=False)
    unit: Mapped[str] = mapped_column(String(20), nullable=False)
    rate: Mapped[Decimal] = mapped_column(RATE, nullable=False)
    discount_pct: Mapped[Decimal] = mapped_column(PERCENT, nullable=False, default=Decimal("0"), server_default="0")
    tax_rate: Mapped[Decimal] = mapped_column(PERCENT, nullable=False)
    amount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False)          # qty × rate
    discount_amount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    taxable: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False)
    cgst: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    sgst: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    igst: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    total: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False)
    remarks: Mapped[str | None] = mapped_column(String(500))


class Boq(AuditColumnsMixin, Base):
    __tablename__ = "boqs"
    __table_args__ = (CheckConstraint("status in ('draft','final')", name="status_valid"),
                      Index("ix_boqs_customer_id", "customer_id"), Index("ix_boqs_enquiry_id", "enquiry_id"))

    boq_number: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    customer_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("customers.id", ondelete="RESTRICT"))
    enquiry_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("enquiries.id", ondelete="RESTRICT"))
    site_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("customer_sites.id", ondelete="RESTRICT"))
    division_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("business_divisions.id", ondelete="RESTRICT"))
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="draft", server_default="draft")
    notes: Mapped[str | None] = mapped_column(Text)
    inter_state: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    gross: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    line_discount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    taxable: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    tax_total: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    total: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")

    items: Mapped[list["BoqItem"]] = relationship(order_by="BoqItem.line_no", cascade="all, delete-orphan",
                                                  lazy="selectin")


class BoqItem(AuditColumnsMixin, LineColumns, Base):
    __tablename__ = "boq_items"

    boq_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("boqs.id", ondelete="CASCADE"), nullable=False, index=True)
