from app.core.permissions import register

register("boq", "BOQ", ("create", "read", "update", "delete", "export", "print"))
