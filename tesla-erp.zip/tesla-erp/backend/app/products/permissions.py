from app.core.permissions import register

register("item", "Items, categories, brands & units", ("create", "read", "update", "delete", "export"))
register("tax_rate", "GST / tax rates", ("create", "read", "update"))
register("warehouse", "Warehouses", ("create", "read", "update", "delete"))
