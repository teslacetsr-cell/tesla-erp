import uuid
from datetime import date
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, Date, ForeignKey, Index, SmallInteger, String, Text, UniqueConstraint, text
from sqlalchemy.dialects.postgresql import CITEXT
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.models import AuditColumnsMixin, Base
from app.core.money import PERCENT, QTY, RATE


class ItemCategory(AuditColumnsMixin, Base):
    __tablename__ = "item_categories"

    code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(CITEXT, unique=True, nullable=False)
    parent_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("item_categories.id", ondelete="RESTRICT"))
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class Brand(AuditColumnsMixin, Base):
    __tablename__ = "brands"

    name: Mapped[str] = mapped_column(CITEXT, unique=True, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class Unit(AuditColumnsMixin, Base):
    """Unit of measure. A unit may be defined as a multiple of a base unit (1 roll = 50 m)."""

    __tablename__ = "units"
    __table_args__ = (
        CheckConstraint("(base_unit_id is null) = (factor is null)", name="base_and_factor_together"),
        CheckConstraint("factor is null or factor > 0", name="factor_positive"),
    )

    code: Mapped[str] = mapped_column(CITEXT, unique=True, nullable=False)  # NOS, M, KG, SET, ROLL
    name: Mapped[str] = mapped_column(String(50), nullable=False)
    decimals: Mapped[int] = mapped_column(SmallInteger, nullable=False, default=0)  # 0 for NOS, 2-3 for M/KG
    base_unit_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("units.id", ondelete="RESTRICT"))
    factor: Mapped[Decimal | None] = mapped_column(QTY)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class TaxRate(AuditColumnsMixin, Base):
    """GST rates as data with effective dates — never hard-coded (Spec §23)."""

    __tablename__ = "tax_rates"
    __table_args__ = (
        CheckConstraint("rate >= 0 and rate <= 100", name="rate_range"),
        CheckConstraint("effective_to is null or effective_to >= effective_from", name="dates_ordered"),
    )

    code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)  # GST18
    name: Mapped[str] = mapped_column(String(80), nullable=False)
    rate: Mapped[Decimal] = mapped_column(PERCENT, nullable=False)  # total GST %; CGST/SGST = rate/2, IGST = rate
    cess_rate: Mapped[Decimal] = mapped_column(PERCENT, nullable=False, default=Decimal("0"), server_default="0")
    effective_from: Mapped[date] = mapped_column(Date, nullable=False)
    effective_to: Mapped[date | None] = mapped_column(Date)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


ITEM_TYPES = ("goods", "service")


class Item(AuditColumnsMixin, Base):
    """Item / product / service master (Spec §10)."""

    __tablename__ = "items"
    __table_args__ = (
        CheckConstraint(f"item_type in {ITEM_TYPES}", name="type_valid"),
        CheckConstraint("purchase_price is null or purchase_price >= 0", name="purchase_price_nonneg"),
        CheckConstraint("selling_price is null or selling_price >= 0", name="selling_price_nonneg"),
        CheckConstraint("minimum_stock >= 0 and reorder_level >= 0", name="stock_levels_nonneg"),
        CheckConstraint("hsn_sac is null or hsn_sac ~ '^[0-9]{4,8}$'", name="hsn_format"),
        Index("ix_items_name_trgm", "item_name", postgresql_using="gin", postgresql_ops={"item_name": "gin_trgm_ops"}),
    )

    item_code: Mapped[str] = mapped_column(CITEXT, unique=True, nullable=False)
    item_name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    item_type: Mapped[str] = mapped_column(String(10), nullable=False, default="goods")
    category_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("item_categories.id", ondelete="RESTRICT"), nullable=False)
    brand_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("brands.id", ondelete="RESTRICT"))
    model: Mapped[str | None] = mapped_column(String(100))
    unit_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("units.id", ondelete="RESTRICT"), nullable=False)
    hsn_sac: Mapped[str | None] = mapped_column(String(8))
    tax_rate_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("tax_rates.id", ondelete="RESTRICT"))
    purchase_price: Mapped[Decimal | None] = mapped_column(RATE)
    selling_price: Mapped[Decimal | None] = mapped_column(RATE)
    minimum_stock: Mapped[Decimal] = mapped_column(QTY, nullable=False, default=Decimal("0"), server_default="0")
    reorder_level: Mapped[Decimal] = mapped_column(QTY, nullable=False, default=Decimal("0"), server_default="0")
    serial_number_required: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    batch_required: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    technical_specification: Mapped[str | None] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")

    category: Mapped[ItemCategory] = relationship(lazy="selectin")
    brand: Mapped[Brand | None] = relationship(lazy="selectin")
    unit: Mapped[Unit] = relationship(lazy="selectin")
    tax_rate: Mapped[TaxRate | None] = relationship(lazy="selectin")


WAREHOUSE_TYPES = ("main", "site", "transit", "service")


class Warehouse(AuditColumnsMixin, Base):
    """Stock location. Project site stores are warehouses of type 'site'."""

    __tablename__ = "warehouses"
    __table_args__ = (
        UniqueConstraint("company_id", "code"),
        CheckConstraint(f"warehouse_type in {WAREHOUSE_TYPES}", name="type_valid"),
        Index("uq_warehouses_project_id", "project_id", unique=True, postgresql_where=text("project_id is not null")),
    )

    company_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("companies.id", ondelete="RESTRICT"), nullable=False)
    code: Mapped[str] = mapped_column(String(20), nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    warehouse_type: Mapped[str] = mapped_column(String(10), nullable=False, default="main")
    address: Mapped[str | None] = mapped_column(Text)
    in_charge_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    allow_negative_stock: Mapped[bool | None] = mapped_column(Boolean)  # null = company setting applies
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"))  # site store
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")
