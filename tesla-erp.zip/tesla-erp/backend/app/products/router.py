"""Item master and its reference tables (Spec §10)."""
import uuid
from datetime import date
from decimal import Decimal
from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, File, Query, UploadFile
from fastapi.responses import Response
from pydantic import Field, ValidationError, model_validator
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal, require
from app.core import excel
from app.core.api import ListParams, Schema, ok, paginate
from app.core.crud import master_routes
from app.core.db import DbSession
from app.core.errors import AppError, Conflict, NotFound
from app.core.models import check_row_version
from app.core.money import Qty, Rate
from app.core.validators import HSN, Text
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.platform.numbering import service as numbering
from app.products.models import ITEM_TYPES, WAREHOUSE_TYPES, Brand, Item, ItemCategory, TaxRate, Unit, Warehouse

router = APIRouter(tags=["items"])
documents.register_entity("item", "item", Item)


def _base(o) -> dict:
    return {"id": str(o.id), "is_active": o.is_active, "row_version": o.row_version}


# ------------------------------------------------------------------ categories / brands / units / tax / warehouses
class CategoryIn(Schema):
    code: str = Field(min_length=1, max_length=20, pattern=r"^[A-Z0-9_-]+$")
    name: str = Field(min_length=2, max_length=100)
    parent_id: uuid.UUID | None = None
    is_active: bool = True


class CategoryUpdate(CategoryIn):
    row_version: int


class BrandIn(Schema):
    name: str = Field(min_length=1, max_length=100)
    is_active: bool = True


class BrandUpdate(BrandIn):
    row_version: int


class UnitIn(Schema):
    code: str = Field(min_length=1, max_length=10, pattern=r"^[A-Za-z0-9.]+$")
    name: str = Field(min_length=1, max_length=50)
    decimals: int = Field(default=0, ge=0, le=3)
    base_unit_id: uuid.UUID | None = None
    factor: Decimal | None = Field(default=None, gt=0, decimal_places=3)
    is_active: bool = True

    @model_validator(mode="after")
    def _pair(self):
        if (self.base_unit_id is None) != (self.factor is None):
            raise ValueError("Give both a base unit and a factor, or neither.")
        return self


class UnitUpdate(UnitIn):
    row_version: int


class TaxRateIn(Schema):
    code: str = Field(min_length=2, max_length=20, pattern=r"^[A-Z0-9_]+$")
    name: str = Field(min_length=2, max_length=80)
    rate: Decimal = Field(ge=0, le=100, decimal_places=4)
    cess_rate: Decimal = Field(default=Decimal("0"), ge=0, le=100, decimal_places=4)
    effective_from: date
    effective_to: date | None = None
    is_active: bool = True

    @model_validator(mode="after")
    def _dates(self):
        if self.effective_to and self.effective_to < self.effective_from:
            raise ValueError("'Effective to' must be on or after 'effective from'.")
        return self


class TaxRateUpdate(TaxRateIn):
    row_version: int


class WarehouseIn(Schema):
    code: str = Field(min_length=1, max_length=20, pattern=r"^[A-Z0-9_-]+$")
    name: str = Field(min_length=2, max_length=120)
    warehouse_type: Literal[WAREHOUSE_TYPES] = "main"  # type: ignore[valid-type]
    address: Text(1000) = None
    in_charge_id: uuid.UUID | None = None
    allow_negative_stock: bool | None = None
    is_active: bool = True


class WarehouseUpdate(WarehouseIn):
    row_version: int


def _unit_check(db: Session, _p, obj: Unit, _body, _is_new: bool) -> None:
    if obj.base_unit_id is not None:
        if obj.base_unit_id == obj.id:
            raise AppError("INVALID_UNIT", "A unit cannot be based on itself.")
        base = db.get(Unit, obj.base_unit_id)
        if base is None or base.base_unit_id is not None:
            raise AppError("INVALID_UNIT", "The base unit must exist and must itself be a base unit.")


master_routes(router, path="/item-categories", entity="item_category", model=ItemCategory, perm="item",
              create_schema=CategoryIn, update_schema=CategoryUpdate,
              out=lambda c: _base(c) | {"code": c.code, "name": c.name,
                                        "parent_id": str(c.parent_id) if c.parent_id else None},
              search=("code", "name"), sortable=("code", "name"), default_sort="name", label=lambda c: c.name)
master_routes(router, path="/brands", entity="brand", model=Brand, perm="item", create_schema=BrandIn,
              update_schema=BrandUpdate, out=lambda b: _base(b) | {"name": b.name}, search=("name",),
              sortable=("name",), default_sort="name", label=lambda b: b.name)
master_routes(router, path="/units", entity="unit", model=Unit, perm="item", create_schema=UnitIn,
              update_schema=UnitUpdate,
              out=lambda u: _base(u) | {"code": u.code, "name": u.name, "decimals": u.decimals,
                                        "base_unit_id": str(u.base_unit_id) if u.base_unit_id else None,
                                        "factor": str(u.factor) if u.factor is not None else None},
              search=("code", "name"), sortable=("code", "name"), default_sort="code", label=lambda u: u.code,
              before_save=_unit_check)
master_routes(router, path="/tax-rates", entity="tax_rate", model=TaxRate, perm="tax_rate",
              create_schema=TaxRateIn, update_schema=TaxRateUpdate,
              out=lambda t: _base(t) | {"code": t.code, "name": t.name, "rate": str(t.rate),
                                        "cess_rate": str(t.cess_rate), "effective_from": t.effective_from.isoformat(),
                                        "effective_to": t.effective_to.isoformat() if t.effective_to else None},
              search=("code", "name"), sortable=("code", "rate"), default_sort="rate", label=lambda t: t.code,
              read_perm="tax_rate.read")
master_routes(router, path="/warehouses", entity="warehouse", model=Warehouse, perm="warehouse",
              create_schema=WarehouseIn, update_schema=WarehouseUpdate,
              out=lambda w: _base(w) | {"code": w.code, "name": w.name, "warehouse_type": w.warehouse_type,
                                        "address": w.address,
                                        "in_charge_id": str(w.in_charge_id) if w.in_charge_id else None,
                                        "allow_negative_stock": w.allow_negative_stock},
              search=("code", "name"), sortable=("code", "name"), default_sort="code", label=lambda w: w.name,
              company_scoped=True)


# ------------------------------------------------------------------ items
class ItemIn(Schema):
    item_code: Text(30) = Field(default=None, description="Leave blank to auto-number")
    item_name: str = Field(min_length=2, max_length=200)
    description: Text(4000) = None
    item_type: Literal[ITEM_TYPES] = "goods"  # type: ignore[valid-type]
    category_id: uuid.UUID
    brand_id: uuid.UUID | None = None
    model: Text(100) = None
    unit_id: uuid.UUID
    hsn_sac: HSN = None
    tax_rate_id: uuid.UUID | None = None
    purchase_price: Decimal | None = Field(default=None, ge=0, max_digits=18, decimal_places=4)
    selling_price: Decimal | None = Field(default=None, ge=0, max_digits=18, decimal_places=4)
    minimum_stock: Decimal = Field(default=Decimal("0"), ge=0, decimal_places=3)
    reorder_level: Decimal = Field(default=Decimal("0"), ge=0, decimal_places=3)
    serial_number_required: bool = False
    batch_required: bool = False
    technical_specification: Text(8000) = None
    is_active: bool = True

    @model_validator(mode="after")
    def _service_rules(self):
        if self.item_type == "service" and (self.serial_number_required or self.batch_required):
            raise ValueError("Services cannot require serial numbers or batches.")
        return self


class ItemUpdate(ItemIn):
    row_version: int


class ItemOut(Schema):
    id: uuid.UUID
    item_code: str
    item_name: str
    description: str | None
    item_type: str
    category_id: uuid.UUID
    brand_id: uuid.UUID | None
    model: str | None
    unit_id: uuid.UUID
    hsn_sac: str | None
    tax_rate_id: uuid.UUID | None
    purchase_price: Rate | None
    selling_price: Rate | None
    minimum_stock: Qty
    reorder_level: Qty
    serial_number_required: bool
    batch_required: bool
    technical_specification: str | None
    is_active: bool
    row_version: int


def item_out(i: Item) -> dict:
    return ItemOut.model_validate(i).model_dump(mode="json") | {
        "category": i.category.name, "brand": i.brand.name if i.brand else None, "unit": i.unit.code,
        "gst_rate": str(i.tax_rate.rate) if i.tax_rate else None,
    }


def _check_refs(db: Session, body: ItemIn) -> None:
    for model, key, label in ((ItemCategory, body.category_id, "Category"), (Unit, body.unit_id, "Unit"),
                              (Brand, body.brand_id, "Brand"), (TaxRate, body.tax_rate_id, "GST rate")):
        if key is not None:
            obj = db.get(model, key)
            if obj is None or not obj.is_active:
                raise AppError("INVALID_REFERENCE", f"{label} does not exist or is inactive.")
    if body.item_type == "goods" and body.tax_rate_id and not body.hsn_sac:
        raise AppError("HSN_REQUIRED", "An HSN code is required for taxable goods.")


def _create_item(db: Session, p: Principal, body: ItemIn) -> Item:
    _check_refs(db, body)
    values = body.model_dump()
    code = (values.pop("item_code") or "").strip().upper() or numbering.next_number(db, p.company_id, "ITEM")
    if db.scalar(select(Item.id).where(Item.item_code == code)):
        raise Conflict("DUPLICATE_CODE", f"Item code {code} is already used.")
    i = Item(item_code=code, **values, created_by=p.id, updated_by=p.id)
    db.add(i)
    db.flush()
    db.refresh(i)
    audit.record(db, action="create", entity_type="item", entity_id=i.id, entity_label=f"{code} {i.item_name}",
                 after=audit.snapshot(i))
    return i


@router.get("/items")
def list_items(db: DbSession, _: Annotated[Principal, require("item.read")], params: Annotated[ListParams, Depends()],
               category_id: uuid.UUID | None = None, brand_id: uuid.UUID | None = None,
               item_type: str | None = None, is_active: bool | None = Query(None)):
    stmt = select(Item)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(Item.item_name.ilike(like), Item.item_code.ilike(like), Item.model.ilike(like),
                              Item.hsn_sac.ilike(like), Item.description.ilike(like)))
    if category_id:
        stmt = stmt.where(Item.category_id == category_id)
    if brand_id:
        stmt = stmt.where(Item.brand_id == brand_id)
    if item_type:
        stmt = stmt.where(Item.item_type == item_type)
    if is_active is not None:
        stmt = stmt.where(Item.is_active.is_(is_active))
    rows, meta = paginate(db, stmt, params, default_sort=Item.item_name, sortable={
        "item_name": Item.item_name, "item_code": Item.item_code, "selling_price": Item.selling_price,
        "purchase_price": Item.purchase_price})
    return {"data": [item_out(i) for i in rows], "meta": meta.model_dump()}


COLUMNS = [
    excel.Column("item_code", "Item code", 14, note="Leave blank to auto-number"),
    excel.Column("item_name", "Item name", 34, required=True),
    excel.Column("item_type", "Type", 10, choices=ITEM_TYPES),
    excel.Column("category", "Category", 20, required=True, note="Category name as in the ERP"),
    excel.Column("brand", "Brand", 16, note="Created automatically if new"),
    excel.Column("model", "Model", 16),
    excel.Column("unit", "Unit", 8, required=True, note="Unit code, e.g. NOS, M, KG"),
    excel.Column("hsn_sac", "HSN/SAC", 10),
    excel.Column("gst_rate", "GST %", 8, note="0, 5, 12, 18 or 28 (must exist as a tax rate)"),
    excel.Column("purchase_price", "Purchase price", 14),
    excel.Column("selling_price", "Selling price", 14),
    excel.Column("minimum_stock", "Minimum stock", 12),
    excel.Column("reorder_level", "Reorder level", 12),
    excel.Column("serial_number_required", "Serial no. required", 10, choices=("yes", "no")),
    excel.Column("description", "Description", 40),
]


@router.get("/items/import-template")
def item_template(_: Annotated[Principal, require("item.create")]):
    data = excel.template("Items", COLUMNS, example={
        "item_name": "DEHN SPD Type 1+2", "item_type": "goods", "category": "Surge Protection", "brand": "DEHN",
        "unit": "NOS", "hsn_sac": "85363000", "gst_rate": 18, "purchase_price": 14000, "selling_price": 16000,
        "serial_number_required": "yes"})
    return Response(data, media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="item-import-template.xlsx"'})


@router.post("/items/import")
async def import_items(db: DbSession, p: Annotated[Principal, require("item.create")], file: UploadFile = File(...),
                       dry_run: bool = Query(True)):
    rows = excel.read(await file.read(), COLUMNS)
    cats = {c.name.lower(): c.id for c in db.scalars(select(ItemCategory).where(ItemCategory.is_active.is_(True)))}
    units = {u.code.lower(): u.id for u in db.scalars(select(Unit).where(Unit.is_active.is_(True)))}
    brands = {b.name.lower(): b.id for b in db.scalars(select(Brand))}
    today = date.today()
    taxes = {str(Decimal(t.rate).normalize()): t.id for t in db.scalars(
        select(TaxRate).where(TaxRate.is_active.is_(True), TaxRate.effective_from <= today,
                              or_(TaxRate.effective_to.is_(None), TaxRate.effective_to >= today)))}
    errors: list[dict[str, Any]] = []
    valid: list[tuple[ItemIn, str | None]] = []
    seen: set[str] = set()
    for n, raw in rows:
        e_before = len(errors)
        cat = cats.get(str(raw.get("category") or "").lower())
        unit = units.get(str(raw.get("unit") or "").lower())
        if not cat:
            errors.append({"row": n, "field": "Category", "message": f"Unknown category '{raw.get('category')}'."})
        if not unit:
            errors.append({"row": n, "field": "Unit", "message": f"Unknown unit '{raw.get('unit')}'."})
        tax_id = None
        if raw.get("gst_rate") is not None:
            tax_id = taxes.get(str(Decimal(str(raw["gst_rate"])).normalize()))
            if not tax_id:
                errors.append({"row": n, "field": "GST %", "message": f"No active GST rate of {raw['gst_rate']}%."})
        if len(errors) > e_before:
            continue
        brand_name = raw.get("brand")
        payload = {k: v for k, v in raw.items() if k not in ("category", "unit", "brand", "gst_rate") and v is not None}
        payload.update(category_id=cat, unit_id=unit, tax_rate_id=tax_id)
        if "hsn_sac" in payload:
            payload["hsn_sac"] = str(payload["hsn_sac"])
        if "item_code" in payload:
            payload["item_code"] = str(payload["item_code"])
        if "serial_number_required" in payload:
            payload["serial_number_required"] = str(payload["serial_number_required"]).lower() in ("yes", "y", "true", "1")
        if isinstance(payload.get("item_type"), str):
            payload["item_type"] = payload["item_type"].lower()
        try:
            item = ItemIn.model_validate(payload)
        except ValidationError as exc:
            errors += [{"row": n, "field": ".".join(map(str, e["loc"])), "message": e["msg"]} for e in exc.errors()]
            continue
        if item.item_code:
            code = item.item_code.upper()
            if code in seen or db.scalar(select(Item.id).where(Item.item_code == code)):
                errors.append({"row": n, "field": "Item code", "message": f"Code {code} already exists."})
                continue
            seen.add(code)
        valid.append((item, brand_name))
    created = 0
    if not dry_run and not errors:
        for item, brand_name in valid:
            if brand_name:
                bid = brands.get(brand_name.lower())
                if bid is None:
                    b = Brand(name=brand_name, created_by=p.id, updated_by=p.id)
                    db.add(b)
                    db.flush()
                    bid = brands[brand_name.lower()] = b.id
                item.brand_id = bid
            _create_item(db, p, item)
            created += 1
        audit.record(db, action="import", entity_type="item", summary=f"Imported {created} items")
    return ok({"rows": len(rows), "valid": len(valid), "errors": errors, "created": created,
               "committed": not dry_run and not errors})


@router.get("/items/export")
def export_items(db: DbSession, _: Annotated[Principal, require("item.export")]):
    rows = db.scalars(select(Item).order_by(Item.item_name)).all()
    data = [{
        **{c.key: getattr(i, c.key, None) for c in COLUMNS},
        "category": i.category.name, "brand": i.brand.name if i.brand else None, "unit": i.unit.code,
        "gst_rate": i.tax_rate.rate if i.tax_rate else None,
        "serial_number_required": "yes" if i.serial_number_required else "no",
    } for i in rows]
    audit.record(db, action="export", entity_type="item", summary=f"Exported {len(data)} items")
    return Response(excel.export("Items", COLUMNS, data), media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="items.xlsx"'})


@router.post("/items", status_code=201)
def create_item(body: ItemIn, db: DbSession, p: Annotated[Principal, require("item.create")]):
    return ok(item_out(_create_item(db, p, body)))


@router.get("/items/{item_id}")
def get_item(item_id: uuid.UUID, db: DbSession, _: Annotated[Principal, require("item.read")]):
    i = db.get(Item, item_id)
    if i is None:
        raise NotFound("item")
    return ok(item_out(i))


@router.put("/items/{item_id}")
def update_item(item_id: uuid.UUID, body: ItemUpdate, db: DbSession, p: Annotated[Principal, require("item.update")]):
    i = db.get(Item, item_id, with_for_update=True)
    if i is None:
        raise NotFound("item")
    _check_refs(db, body)
    before = audit.snapshot(i)
    values = body.model_dump()
    check_row_version(i, values.pop("row_version"))
    code = (values.pop("item_code") or "").strip().upper()
    if code and code != i.item_code:
        if db.scalar(select(Item.id).where(Item.item_code == code)):
            raise Conflict("DUPLICATE_CODE", f"Item code {code} is already used.")
        i.item_code = code
    for k, v in values.items():
        setattr(i, k, v)
    i.updated_by = p.id
    db.flush()
    db.refresh(i)
    audit.record(db, action="update", entity_type="item", entity_id=i.id, entity_label=f"{i.item_code} {i.item_name}",
                 before=before, after=audit.snapshot(i))
    return ok(item_out(i))


@router.delete("/items/{item_id}")
def delete_item(item_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("item.delete")]):
    i = db.get(Item, item_id, with_for_update=True)
    if i is None:
        raise NotFound("item")
    snap, label = audit.snapshot(i), f"{i.item_code} {i.item_name}"
    with db.begin_nested():
        db.delete(i)
        db.flush()
    audit.record(db, action="delete", entity_type="item", entity_id=item_id, entity_label=label, before=snap)
    return ok({"ok": True})
