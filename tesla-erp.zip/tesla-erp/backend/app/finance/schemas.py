import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import Field, model_validator

from app.boq.lines import LineIn
from app.core.api import Schema
from app.core.validators import Text
from app.finance.models import BILL_TYPES, COST_HEADS, PAYMENT_MODES

Mode = Literal[PAYMENT_MODES]  # type: ignore[valid-type]
Money = Decimal


def money(**kw):
    return Field(max_digits=18, decimal_places=2, **kw)


class ReasonIn(Schema):
    reason: Text(500) = None
    row_version: int | None = None


# ------------------------------------------------------------------ sales invoices
class InvoiceLineIn(LineIn):
    so_item_id: uuid.UUID | None = None


class InvoiceIn(Schema):
    customer_id: uuid.UUID | None = None          # taken from the order / project when one is given
    sales_order_id: uuid.UUID | None = None
    project_id: uuid.UUID | None = None
    site_id: uuid.UUID | None = None
    invoice_date: date | None = None
    due_date: date | None = None
    bill_type: Literal[BILL_TYPES] = "regular"  # type: ignore[valid-type]
    subject: Text(200) = None
    customer_po_number: Text(60) = None
    customer_po_date: date | None = None
    reverse_charge: bool = False
    payment_terms: Text(1000) = None
    notes: Text(2000) = None
    special_discount: Decimal = money(default=Decimal("0"), ge=0)
    retention_pct: Decimal = Field(default=Decimal("0"), ge=0, le=50, max_digits=7, decimal_places=4)
    items: list[InvoiceLineIn] = Field(min_length=1, max_length=1000)

    @model_validator(mode="after")
    def _who(self):
        if not (self.customer_id or self.sales_order_id or self.project_id):
            raise ValueError("Choose the customer, sales order or project to bill.")
        return self


class InvoiceUpdate(InvoiceIn):
    row_version: int


class IrnIn(Schema):
    irn: str = Field(min_length=10, max_length=64)
    irn_ack_no: Text(30) = None
    irn_ack_date: date | None = None
    row_version: int


class CreditNoteIn(Schema):
    cn_date: date | None = None
    reason: str = Field(min_length=3, max_length=500)
    cancel_invoice: bool = False                       # full credit: the invoice becomes cancelled
    taxable: Decimal | None = money(default=None, gt=0)  # partial credit: value before GST to credit
    row_version: int | None = None

    @model_validator(mode="after")
    def _amount(self):
        if not self.cancel_invoice and self.taxable is None:
            raise ValueError("Give the value to credit, or choose to cancel the whole invoice.")
        return self


# ------------------------------------------------------------------ receipts / payments
class AllocationIn(Schema):
    document_id: uuid.UUID          # invoice (receipts) or supplier invoice (payments)
    amount: Decimal = money(default=Decimal("0"), ge=0)
    tds: Decimal = money(default=Decimal("0"), ge=0)


class ReceiptIn(Schema):
    customer_id: uuid.UUID
    receipt_date: date | None = None
    project_id: uuid.UUID | None = None
    sales_order_id: uuid.UUID | None = None
    mode: Mode = "neft"
    reference_no: Text(60) = None
    instrument_date: date | None = None
    bank_name: Text(120) = None
    amount: Decimal = money(ge=0)
    tds_amount: Decimal = money(default=Decimal("0"), ge=0)
    notes: Text(2000) = None
    allocations: list[AllocationIn] = Field(default_factory=list, max_length=200)

    @model_validator(mode="after")
    def _positive(self):
        if self.amount + self.tds_amount <= 0:
            raise ValueError("Enter the amount received.")
        return self


class AllocateIn(Schema):
    allocations: list[AllocationIn] = Field(min_length=1, max_length=200)
    row_version: int | None = None


class SupplierInvoiceIn(Schema):
    supplier_id: uuid.UUID
    supplier_invoice_no: str = Field(min_length=1, max_length=40)
    supplier_invoice_date: date
    due_date: date | None = None
    purchase_order_id: uuid.UUID | None = None
    project_id: uuid.UUID | None = None
    account_id: uuid.UUID | None = None      # default: Purchases
    notes: Text(2000) = None
    special_discount: Decimal = money(default=Decimal("0"), ge=0)
    items: list["SupplierInvoiceLineIn"] = Field(min_length=1, max_length=1000)


class SupplierInvoiceLineIn(LineIn):
    po_item_id: uuid.UUID | None = None


SupplierInvoiceIn.model_rebuild()


class SupplierInvoiceUpdate(SupplierInvoiceIn):
    row_version: int


class SupplierPaymentIn(Schema):
    supplier_id: uuid.UUID
    payment_date: date | None = None
    purchase_order_id: uuid.UUID | None = None
    mode: Mode = "neft"
    reference_no: Text(60) = None
    bank_name: Text(120) = None
    amount: Decimal = money(ge=0)
    tds_amount: Decimal = money(default=Decimal("0"), ge=0)
    notes: Text(2000) = None
    allocations: list[AllocationIn] = Field(default_factory=list, max_length=200)

    @model_validator(mode="after")
    def _positive(self):
        if self.amount + self.tds_amount <= 0:
            raise ValueError("Enter the amount paid.")
        return self


# ------------------------------------------------------------------ expenses
class ExpenseIn(Schema):
    employee_id: uuid.UUID | None = None      # default: the signed-in user's employee record
    project_id: uuid.UUID | None = None
    category_id: uuid.UUID
    expense_date: date
    amount: Decimal = money(gt=0)
    description: str = Field(min_length=3, max_length=1000)
    bill_reference: Text(60) = None


class ExpenseUpdate(ExpenseIn):
    row_version: int


class ExpensePayIn(Schema):
    paid_at: date | None = None
    payment_mode: Mode = "neft"
    payment_reference: Text(60) = None
    row_version: int | None = None


class ExpenseCategoryIn(Schema):
    name: str = Field(min_length=2, max_length=80)
    account_id: uuid.UUID
    needs_project: bool = False
    needs_receipt: bool = True
    is_active: bool = True


class ExpenseCategoryUpdate(ExpenseCategoryIn):
    row_version: int


class LedgerAccountIn(Schema):
    code: str = Field(min_length=1, max_length=20)
    name: str = Field(min_length=2, max_length=120)
    account_type: Literal["asset", "liability", "income", "expense", "equity"]
    group_name: Text(80) = None
    cost_head: Literal[COST_HEADS] | None = None  # type: ignore[valid-type]
    is_active: bool = True


class LedgerAccountUpdate(LedgerAccountIn):
    row_version: int
