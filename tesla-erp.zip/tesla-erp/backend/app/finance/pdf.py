"""Tax invoice, credit note and receipt PDFs on Tesla letterhead.

The tax invoice carries what GST rule 46 asks for: supplier and recipient names, addresses and GSTINs, a serial
number of at most 16 characters, the date, place of supply with state name and code, HSN/SAC, quantity, unit,
taxable value, the rate and amount of each tax, whether tax is payable on reverse charge, and a signature.
"""
import io
from collections import defaultdict
from decimal import Decimal
from html import escape

from reportlab.lib.units import mm
from reportlab.platypus import KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from sqlalchemy.orm import Session

from app.boq.pdf import lines_table, totals_table
from app.core.gst import amount_in_words
from app.core.india import GST_STATE_CODES
from app.finance.models import CreditNote, Invoice, Receipt
from app.platform import pdfkit as K


def _date(d) -> str:
    return d.strftime("%d %b %Y") if d else "—"


def _rate(r: Decimal) -> str:
    return f"{r.normalize():f}"


def _state(code: str | None) -> str:
    return f"{GST_STATE_CODES.get(code, '')} ({code})" if code else "—"


def _box(left: list, right: list) -> Table:
    box = Table([[left, right]], colWidths=[92 * mm, None])
    box.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("BOX", (0, 0), (-1, -1), 0.5, K.LINE),
                             ("LINEAFTER", (0, 0), (0, 0), 0.5, K.LINE), ("TOPPADDING", (0, 0), (-1, -1), 5),
                             ("BOTTOMPADDING", (0, 0), (-1, -1), 5), ("LEFTPADDING", (0, 0), (-1, -1), 6)]))
    return box


def _head(title: str, right: str, st) -> list:
    head = Table([[Paragraph(title, st["title"]), Paragraph(right, st["right"])]], colWidths=[None, 80 * mm])
    head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "BOTTOM"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                              ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    return [head, Spacer(1, 3 * mm)]


def _party(cust: dict, st, label="Bill to") -> list:
    out = [Paragraph(label, st["label"]), Paragraph(f"<b>{escape(cust.get('name') or '')}</b>", st["base"])]
    out += [Paragraph(escape(a), st["base"]) for a in cust.get("address") or []]
    out.append(Paragraph(f"State: {escape(_state(cust.get('state_code')))}", st["base"]))
    out.append(Paragraph(f"GSTIN: {escape(cust.get('gstin') or 'Unregistered')}", st["base"]))
    return out


def _signature(db: Session, st, snapshot: dict | None) -> KeepTogether:
    name = (snapshot or {}).get("company_name") or (K.company_snapshot(db) or {}).get("company_name") \
        or "Tesla Consulting Engineers"
    return KeepTogether([Spacer(1, 6 * mm), Paragraph(f"For <b>{escape(name)}</b>", st["rightb"]),
                         Spacer(1, 14 * mm), Paragraph("Authorised Signatory", st["right"])])


def _doc(buf, title: str, author: str):
    return SimpleDocTemplate(buf, pagesize=K.PAGE, leftMargin=K.MARGIN, rightMargin=K.MARGIN, topMargin=10 * mm,
                             bottomMargin=14 * mm, title=title, author=author)


def invoice(db: Session, inv: Invoice) -> bytes:
    K.fonts()
    st = K.styles()
    cust = inv.customer_snapshot or {}
    company = inv.company_snapshot or K.company_snapshot(db)
    story = K.letterhead(db, st, company if inv.company_snapshot else None)
    kind = "TAX INVOICE" if inv.status != "draft" else "TAX INVOICE — DRAFT"
    ra = f" · RA bill {inv.ra_bill_no}" if inv.bill_type == "running" and inv.ra_bill_no else ""
    story += _head(kind, f"<b>Invoice No.</b> {escape(inv.invoice_number or 'not yet issued')}<br/>"
                         f"<b>Date</b> {_date(inv.invoice_date)}<br/><b>Due</b> {_date(inv.due_date)}{ra}", st)
    right = [Paragraph("Place of supply", st["label"]), Paragraph(escape(_state(inv.place_of_supply)), st["base"]),
             Paragraph(f"{'Inter-state (IGST)' if inv.inter_state else 'Intra-state (CGST + SGST)'} · "
                       f"Reverse charge: {'Yes' if inv.reverse_charge else 'No'}", st["small"])]
    if cust.get("site"):
        right += [Spacer(1, 1.5 * mm), Paragraph("Ship to / site", st["label"]),
                  Paragraph(escape(cust["site"]["name"]), st["base"])]
        if cust["site"].get("address"):
            right.append(Paragraph(escape(cust["site"]["address"]), st["small"]))
    if inv.customer_po_number:
        right += [Spacer(1, 1.5 * mm), Paragraph("Your order", st["label"]),
                  Paragraph(escape(inv.customer_po_number)
                            + (f" dated {_date(inv.customer_po_date)}" if inv.customer_po_date else ""), st["base"])]
    if inv.irn:
        right += [Spacer(1, 1.5 * mm), Paragraph(f"IRN {escape(inv.irn)}", st["small"])]
        if inv.irn_ack_no:
            right.append(Paragraph(f"Ack {escape(inv.irn_ack_no)} · {_date(inv.irn_ack_date)}", st["small"]))
    if not cust:
        from app.finance.invoices import _snapshot

        cust = _snapshot(db, inv)
    story += [_box(_party(cust, st), right), Spacer(1, 3 * mm)]
    if inv.subject:
        story += [Paragraph(f"<b>Subject:</b> {escape(inv.subject)}", st["base"]), Spacer(1, 2 * mm)]
    story += [lines_table(inv.items, st), Spacer(1, 3 * mm)]
    # HSN-wise tax summary (rate × HSN), as GST returns expect
    by: dict[tuple, dict] = defaultdict(lambda: {"taxable": Decimal(0), "cgst": Decimal(0), "sgst": Decimal(0),
                                                 "igst": Decimal(0)})
    for it in inv.items:
        b = by[(it.hsn_sac or "—", it.tax_rate)]
        for k in ("taxable", "cgst", "sgst", "igst"):
            b[k] += getattr(it, k)
    hdr = ["HSN/SAC", "Taxable (₹)", "Rate", *(["IGST (₹)"] if inv.inter_state else ["CGST (₹)", "SGST (₹)"]),
           "Tax total (₹)"]
    rows = [[Paragraph(f"<b>{h}</b>", st["cellr"] if i else st["cell"]) for i, h in enumerate(hdr)]]
    for (hsn, rate), v in sorted(by.items(), key=lambda kv: (kv[0][1], kv[0][0])):
        taxes = [v["igst"]] if inv.inter_state else [v["cgst"], v["sgst"]]
        rows.append([Paragraph(escape(hsn), st["cell"]), Paragraph(K.money(v["taxable"]), st["cellr"]),
                     Paragraph(f"{_rate(rate)} %", st["cellr"]), *[Paragraph(K.money(x), st["cellr"]) for x in taxes],
                     Paragraph(K.money(sum(taxes)), st["cellr"])])
    hsn_t = Table(rows, colWidths=None, hAlign="LEFT")
    hsn_t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), K.TINT), ("LINEBELOW", (0, 0), (-1, -1), 0.3, K.LINE),
                               ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
    tot = [("Total", K.money(inv.gross), False)]
    if inv.line_discount:
        tot.append(("Less: discount", "− " + K.money(inv.line_discount), False))
    if inv.special_discount:
        tot.append(("Less: special discount", "− " + K.money(inv.special_discount), False))
    tot.append(("Taxable value", K.money(inv.taxable), True))
    if inv.inter_state:
        tot.append(("IGST", K.money(inv.igst), False))
    else:
        tot += [("CGST", K.money(inv.cgst), False), ("SGST", K.money(inv.sgst), False)]
    if inv.round_off:
        tot.append(("Round off", ("+ " if inv.round_off > 0 else "− ") + K.money(abs(inv.round_off)), False))
    tot.append(("Invoice total (₹)", K.money(inv.grand_total), True))
    side = Table([[hsn_t, totals_table(tot, st, width=78 * mm)]], colWidths=[None, 80 * mm])
    side.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                              ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    story.append(KeepTogether([side, Spacer(1, 1.5 * mm),
                               Paragraph(f"<b>In words:</b> {escape(amount_in_words(inv.grand_total))}", st["base"])]))
    if inv.retention_amount:
        story += [Spacer(1, 1.5 * mm), Paragraph(
            f"Retention {_rate(inv.retention_pct)} % (₹{K.money(inv.retention_amount)}) is payable on release as per "
            "contract.", st["small"])]
    c = K.company(db)
    bank = []
    if c is not None and c.bank_name:
        bank = [Paragraph("Bank details for payment", st["label"]),
                Paragraph(escape(f"{c.bank_account_name or c.company_name} · {c.bank_name}"
                                 + (f", {c.branch}" if c.branch else "")), st["base"]),
                Paragraph(escape(f"A/c {c.account_number or '—'} · IFSC {c.ifsc or '—'}"), st["base"])]
    terms = []
    if inv.payment_terms:
        terms += [Paragraph("Payment terms", st["label"]), K.p(inv.payment_terms, st["base"])]
    if inv.notes:
        terms += [Spacer(1, 1 * mm), Paragraph("Notes", st["label"]), K.p(inv.notes, st["base"])]
    if bank or terms:
        story += [Spacer(1, 3 * mm), _box(bank or [Paragraph("", st["base"])], terms or [Paragraph("", st["base"])])]
    story.append(Paragraph("Certified that the particulars given above are true and correct.", st["small"]))
    story.append(_signature(db, st, inv.company_snapshot))
    buf = io.BytesIO()
    title = f"Tax invoice {inv.invoice_number or '(draft)'}"
    mark = {"draft": "DRAFT", "cancelled": "CANCELLED"}.get(inv.status)
    _doc(buf, title, (company or {}).get("company_name") or "Tesla Consulting Engineers").build(
        story, canvasmaker=K.numbered_canvas(title, mark))
    return buf.getvalue()


def credit_note(db: Session, cn: CreditNote, inv: Invoice) -> bytes:
    K.fonts()
    st = K.styles()
    cust = inv.customer_snapshot or {}
    story = K.letterhead(db, st, inv.company_snapshot)
    story += _head("CREDIT NOTE", f"<b>Credit note No.</b> {escape(cn.cn_number)}<br/><b>Date</b> {_date(cn.cn_date)}"
                                  f"<br/><b>Against invoice</b> {escape(inv.invoice_number or '')} dated "
                                  f"{_date(inv.invoice_date)}", st)
    story += [_box(_party(cust, st, "Issued to"), [Paragraph("Place of supply", st["label"]),
                                                    Paragraph(escape(_state(inv.place_of_supply)), st["base"]),
                                                    Spacer(1, 1.5 * mm), Paragraph("Reason", st["label"]),
                                                    K.p(cn.reason, st["base"])]), Spacer(1, 4 * mm)]
    rows = [("Taxable value credited", K.money(cn.taxable), True)]
    if inv.inter_state:
        rows.append(("IGST", K.money(cn.igst), False))
    else:
        rows += [("CGST", K.money(cn.cgst), False), ("SGST", K.money(cn.sgst), False)]
    if cn.round_off:
        rows.append(("Round off", ("+ " if cn.round_off > 0 else "− ") + K.money(abs(cn.round_off)), False))
    rows.append(("Credit note total (₹)", K.money(cn.total), True))
    story += [totals_table(rows, st, width=95 * mm), Spacer(1, 1.5 * mm),
              Paragraph(f"<b>In words:</b> {escape(amount_in_words(cn.total))}", st["base"])]
    if cn.cancels_invoice:
        story += [Spacer(1, 2 * mm), Paragraph(f"This credit note cancels invoice {escape(inv.invoice_number)} in full.",
                                               st["base"])]
    story.append(_signature(db, st, inv.company_snapshot))
    buf = io.BytesIO()
    _doc(buf, f"Credit note {cn.cn_number}", "Tesla Consulting Engineers").build(
        story, canvasmaker=K.numbered_canvas(f"Credit note {cn.cn_number}"))
    return buf.getvalue()


def receipt(db: Session, r: Receipt, customer, allocations: list[tuple[str, Decimal, Decimal]]) -> bytes:
    K.fonts()
    st = K.styles()
    story = K.letterhead(db, st)
    story += _head("RECEIPT", f"<b>Receipt No.</b> {escape(r.receipt_number)}<br/><b>Date</b> {_date(r.receipt_date)}", st)
    total = r.amount + r.tds_amount
    mode = r.mode.upper() + (f" · {r.reference_no}" if r.reference_no else "") + \
        (f" dated {_date(r.instrument_date)}" if r.instrument_date else "") + (f" · {r.bank_name}" if r.bank_name else "")
    story += [K.p(f"Received with thanks from {customer.company_name or customer.customer_name} the sum of "
                  f"₹{K.money(r.amount)} ({amount_in_words(r.amount)}) by {mode}.", st["base"]), Spacer(1, 3 * mm)]
    rows = [[Paragraph(f"<b>{h}</b>", st["cellr"] if i else st["cell"]) for i, h in
             enumerate(["Against invoice", "Amount (₹)", "TDS (₹)", "Total (₹)"])]]
    for num, amt, tds in allocations:
        rows.append([Paragraph(escape(num), st["cell"]), Paragraph(K.money(amt), st["cellr"]),
                     Paragraph(K.money(tds), st["cellr"]), Paragraph(K.money(amt + tds), st["cellr"])])
    if r.unallocated:
        rows.append([Paragraph("On account (advance)", st["cell"]), Paragraph("", st["cellr"]),
                     Paragraph("", st["cellr"]), Paragraph(K.money(r.unallocated), st["cellr"])])
    rows.append([Paragraph("<b>Total</b>", st["cell"]), Paragraph(f"<b>{K.money(r.amount)}</b>", st["cellr"]),
                 Paragraph(f"<b>{K.money(r.tds_amount)}</b>", st["cellr"]), Paragraph(f"<b>{K.money(total)}</b>", st["cellr"])])
    t = Table(rows, colWidths=[80 * mm, 34 * mm, 34 * mm, 34 * mm])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), K.TINT), ("LINEBELOW", (0, 0), (-1, -1), 0.3, K.LINE),
                           ("LINEABOVE", (0, -1), (-1, -1), 0.8, K.INK)]))
    story += [t]
    if r.status == "cancelled":
        story += [Spacer(1, 3 * mm), Paragraph(f"<b>Cancelled:</b> {escape(r.status_reason or '')}", st["base"])]
    story.append(_signature(db, st, None))
    buf = io.BytesIO()
    _doc(buf, f"Receipt {r.receipt_number}", "Tesla Consulting Engineers").build(
        story, canvasmaker=K.numbered_canvas(f"Receipt {r.receipt_number}",
                                             "CANCELLED" if r.status == "cancelled" else None))
    return buf.getvalue()
