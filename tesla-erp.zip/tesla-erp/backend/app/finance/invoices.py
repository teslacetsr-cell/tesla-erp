"""Sales invoices and credit notes (Spec §22–§23).

Draft → issued (numbered within the 16-character GST limit, journal posted) → reduced or cancelled only by credit
notes. Lines billed against a sales order keep the order's rate, discount and GST, and the quantity billed on all
issued invoices can never exceed the ordered quantity.
"""
import uuid
from collections import defaultdict
from datetime import timedelta
from decimal import Decimal

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.boq import lines as L
from app.core.api import ListParams, paginate
from app.core.errors import AppError, Forbidden, NotFound
from app.core.models import check_row_version
from app.core.money import round_amount, round_qty, round_to_rupee
from app.crm.service import now, today
from app.customers.models import Customer, CustomerSite
from app.finance import gl
from app.finance.models import CreditNote, Invoice, InvoiceItem
from app.platform import pdfkit
from app.platform.audit import service as audit
from app.platform.numbering import service as numbering
from app.projects.models import Project
from app.sales.models import SalesOrder
from app.tally import hooks as tally

Z = Decimal("0")
LINE_KEYS = ("line_no", "section", "item_id", "description", "technical_specification", "hsn_sac", "quantity", "unit",
             "rate", "discount_pct", "tax_rate", "amount", "discount_amount", "special_discount", "taxable", "cgst",
             "sgst", "igst", "total", "remarks")
TOTALS = ("gross", "line_discount", "taxable", "cgst", "sgst", "igst", "round_off", "grand_total")


def get(db: Session, invoice_id: uuid.UUID, lock: bool = False) -> Invoice:
    inv = db.get(Invoice, invoice_id, with_for_update=lock or None)
    if inv is None:
        raise NotFound("invoice")
    return inv


def label(inv: Invoice) -> str:
    return inv.invoice_number or f"Draft invoice of {inv.invoice_date:%d %b %Y}"


def settle(inv: Invoice) -> None:
    """Payment status from what has been received and credited."""
    done = inv.received + inv.credited
    inv.payment_status = "paid" if done >= inv.grand_total else ("partially_paid" if inv.received > 0 else "unpaid")


# ------------------------------------------------------------------ billed quantities against a sales order
def billed_qty(db: Session, so_item_ids, exclude_invoice: uuid.UUID | None = None) -> dict[uuid.UUID, Decimal]:
    ids = [i for i in so_item_ids if i]
    if not ids:
        return {}
    stmt = (select(InvoiceItem.so_item_id, func.sum(InvoiceItem.quantity))
            .join(Invoice, Invoice.id == InvoiceItem.invoice_id)
            .where(InvoiceItem.so_item_id.in_(ids), Invoice.status == "issued").group_by(InvoiceItem.so_item_id))
    if exclude_invoice:
        stmt = stmt.where(Invoice.id != exclude_invoice)
    return {k: Decimal(v) for k, v in db.execute(stmt).all()}


def billable_lines(db: Session, so: SalesOrder) -> list[dict]:
    """The order's lines with what is still left to bill — the starting point of a new invoice."""
    done = billed_qty(db, [it.id for it in so.items])
    out = []
    for it in so.items:
        left = it.quantity - done.get(it.id, Z)
        out.append({**L.line_out(it), "so_item_id": str(it.id), "ordered_qty": str(round_qty(it.quantity)),
                    "billed_qty": str(round_qty(done.get(it.id, Z))), "balance_qty": str(round_qty(max(left, Z)))})
    return out


def _check_against_order(db: Session, so: SalesOrder | None, items, exclude: uuid.UUID | None) -> None:
    linked = [ln for ln in items if ln.so_item_id]
    if not linked:
        return
    if so is None:
        raise AppError("NO_ORDER", "Lines linked to order lines need the sales order on the invoice.")
    so_items = {it.id: it for it in so.items}
    done = billed_qty(db, so_items.keys(), exclude_invoice=exclude)
    asked: dict[uuid.UUID, Decimal] = defaultdict(lambda: Z)
    for n, ln in enumerate(items, start=1):
        if not ln.so_item_id:
            continue
        it = so_items.get(ln.so_item_id)
        if it is None:
            raise AppError("INVALID_ORDER_LINE", f"Line {n}: not a line of sales order {so.so_number}.",
                           details={"line": n})
        if ln.rate != it.rate or ln.discount_pct != it.discount_pct or ln.tax_rate != it.tax_rate:
            raise AppError("ORDER_TERMS_CHANGED",
                           f"Line {n}: rate, discount and GST must stay as ordered (₹{it.rate}, {it.discount_pct:f} %, "
                           f"GST {it.tax_rate.normalize():f} %). Change the order's commercial terms first.",
                           details={"line": n})
        asked[it.id] += ln.quantity
    for sid, qty in asked.items():
        it = so_items[sid]
        left = it.quantity - done.get(sid, Z)
        if qty > left:
            raise AppError("OVER_BILLED",
                           f"'{it.description[:60]}': only {round_qty(left):f} {it.unit} is left to bill on "
                           f"{so.so_number} (ordered {round_qty(it.quantity):f}).",
                           details={"so_item_id": str(sid), "left": str(round_qty(left))})


# ------------------------------------------------------------------ header
def _resolve(db: Session, data, current: Invoice | None) -> dict:
    so = db.get(SalesOrder, data.sales_order_id) if data.sales_order_id else None
    if data.sales_order_id and so is None:
        raise NotFound("sales_order")
    if so is not None and so.status == "cancelled":
        raise AppError("SO_CANCELLED", f"Sales order {so.so_number} is cancelled.")
    prj = db.get(Project, data.project_id) if data.project_id else None
    if data.project_id and prj is None:
        raise NotFound("project")
    if prj is not None and prj.status == "cancelled":
        raise AppError("PROJECT_CANCELLED", f"Project {prj.project_number} is cancelled.")
    if so is None and prj is not None and prj.sales_order_id:
        so = db.get(SalesOrder, prj.sales_order_id)
    if prj is None and so is not None:
        prj = db.scalar(select(Project).where(Project.sales_order_id == so.id, Project.status != "cancelled"))
    customer_id = so.customer_id if so else (prj.customer_id if prj else data.customer_id)
    if data.customer_id and data.customer_id != customer_id:
        raise AppError("CUSTOMER_MISMATCH", "The customer is not the one on the order / project.")
    customer = db.get(Customer, customer_id)
    if customer is None:
        raise NotFound("customer")
    if current is None and customer.status == "blocked":
        raise AppError("CUSTOMER_BLOCKED", f"{customer.customer_name} is blocked.")
    site_id = data.site_id or (so.site_id if so else None) or (prj.site_id if prj else None)
    site = db.get(CustomerSite, site_id) if site_id else None
    if site is not None and site.customer_id != customer.id:
        raise AppError("INVALID_SITE", "The site belongs to another customer.")
    pos = so.place_of_supply if so and so.place_of_supply else L.place_of_supply(customer, site)
    return {"so": so, "prj": prj, "customer": customer, "site": site, "pos": pos}


def _fill(db: Session, p: Principal, inv: Invoice, data) -> None:
    r = _resolve(db, data, inv if inv.id else None)
    so, prj, customer = r["so"], r["prj"], r["customer"]
    L.validate(db, data.items)
    _check_against_order(db, so, data.items, inv.id)
    inter = so.inter_state if so is not None and so.place_of_supply else L.inter_state_for(db, p.company_id, r["pos"])
    rows, t = L.compute(data.items, inter_state=inter, special_discount=data.special_discount)
    inv.items.clear()
    db.flush()
    for row, ln in zip(rows, data.items, strict=True):
        inv.items.append(InvoiceItem(**row, so_item_id=ln.so_item_id, created_by=p.id, updated_by=p.id))
    inv.customer_id, inv.sales_order_id = customer.id, so.id if so else None
    inv.project_id, inv.site_id = prj.id if prj else None, r["site"].id if r["site"] else None
    inv.division_id = (prj.division_id if prj else None) or (so.division_id if so else None)
    inv.invoice_date = data.invoice_date or inv.invoice_date or today()
    inv.due_date = data.due_date
    inv.bill_type, inv.subject = data.bill_type, data.subject or (so.subject if so else (prj.name if prj else None))
    inv.customer_po_number = data.customer_po_number or (so.customer_po_number if so else None)
    inv.customer_po_date = data.customer_po_date or (so.customer_po_date if so else None)
    inv.reverse_charge, inv.notes = data.reverse_charge, data.notes
    inv.payment_terms = data.payment_terms or (so.payment_terms if so else None) or customer.default_payment_terms
    inv.place_of_supply, inv.inter_state = r["pos"], inter
    inv.special_discount = round_amount(data.special_discount)
    for k in TOTALS:
        setattr(inv, k, round_amount(getattr(t, k)))
    inv.retention_pct = data.retention_pct
    inv.retention_amount = round_amount(inv.grand_total * data.retention_pct / 100)
    if inv.bill_type == "running" and inv.ra_bill_no is None and so is not None:
        inv.ra_bill_no = (db.scalar(select(func.count()).select_from(Invoice).where(
            Invoice.sales_order_id == so.id, Invoice.bill_type == "running", Invoice.status == "issued")) or 0) + 1
    inv.updated_by = p.id


def create(db: Session, p: Principal, data) -> Invoice:
    inv = Invoice(status="draft", invoice_date=data.invoice_date or today(), created_by=p.id, updated_by=p.id)
    _fill(db, p, inv, data)
    db.add(inv)
    db.flush()
    audit.record(db, action="create", entity_type="invoice", entity_id=inv.id, entity_label=label(inv),
                 summary=f"Draft: {len(inv.items)} lines, ₹{inv.taxable} before GST, ₹{inv.grand_total} total")
    return inv


def update(db: Session, p: Principal, invoice_id: uuid.UUID, data) -> Invoice:
    inv = get(db, invoice_id, lock=True)
    if inv.status != "draft":
        raise AppError("NOT_DRAFT", "An issued invoice cannot be edited. Raise a credit note instead.")
    check_row_version(inv, data.row_version)
    _fill(db, p, inv, data)
    db.flush()
    audit.record(db, action="update", entity_type="invoice", entity_id=inv.id, entity_label=label(inv),
                 summary=f"{len(inv.items)} lines, ₹{inv.taxable} before GST, ₹{inv.grand_total} total")
    return inv


def delete(db: Session, p: Principal, invoice_id: uuid.UUID) -> None:
    inv = get(db, invoice_id, lock=True)
    if inv.status != "draft" or inv.invoice_number:
        raise AppError("NOT_DRAFT", "Only an unissued draft can be discarded.")
    lbl = label(inv)
    db.delete(inv)
    db.flush()
    audit.record(db, action="delete", entity_type="invoice", entity_id=invoice_id, entity_label=lbl)


def _snapshot(db: Session, inv: Invoice) -> dict:
    c = db.get(Customer, inv.customer_id)
    site = db.get(CustomerSite, inv.site_id) if inv.site_id else None
    place = c.city if not c.district or (c.city or "").lower() == c.district.lower() else f"{c.city}, {c.district}"
    return {
        "name": c.company_name or c.customer_name, "customer_name": c.customer_name, "code": c.customer_code,
        "address": [x for x in (c.address_line1, c.address_line2, place, " ".join(x for x in (c.state, c.pincode) if x))
                    if x],
        "gstin": c.gstin, "pan": c.pan, "state": c.state, "state_code": c.state_code, "phone": c.phone, "email": c.email,
        "site": {"name": site.site_name, "address": ", ".join(x for x in (site.address_line1, site.city, site.state,
                                                                         site.pincode) if x),
                 "state_code": site.state_code} if site else None,
        "place_of_supply": inv.place_of_supply,
    }


def issue(db: Session, p: Principal, invoice_id: uuid.UUID, row_version: int | None) -> Invoice:
    if not p.can("invoice_post.approve"):
        raise Forbidden("Issuing a tax invoice needs the 'Issue sales invoices' permission.", code="CANNOT_ISSUE")
    inv = get(db, invoice_id, lock=True)
    if inv.status != "draft":
        raise AppError("NOT_DRAFT", "This invoice is already issued.")
    if row_version is not None:
        check_row_version(inv, row_version)
    else:
        inv.row_version += 1
    if inv.invoice_date > today():
        raise AppError("FUTURE_DATE", "A tax invoice cannot be dated in the future.")
    so = db.get(SalesOrder, inv.sales_order_id, with_for_update=True) if inv.sales_order_id else None
    if so is not None and so.status == "cancelled":
        raise AppError("SO_CANCELLED", f"Sales order {so.so_number} is cancelled.")
    _check_against_order(db, so, [_LineView(it) for it in inv.items], inv.id)
    customer = db.get(Customer, inv.customer_id)
    if customer.status == "blocked":
        raise AppError("CUSTOMER_BLOCKED", f"{customer.customer_name} is blocked.")
    company = pdfkit.company(db)
    if company is not None and not company.gstin:
        raise AppError("COMPANY_GSTIN_MISSING", "Add the company's GSTIN (Administration → Company) before issuing "
                                                "tax invoices.")
    if not inv.place_of_supply:
        raise AppError("NO_PLACE_OF_SUPPLY", f"{customer.customer_name} has no state, so the place of supply (and CGST/SGST "
                                             "or IGST) can't be decided. Add the state or GSTIN to the customer (or the "
                                             "site), open this draft and save it again, then issue.")
    inv.invoice_number = numbering.next_number(db, p.company_id, "INV", on=inv.invoice_date)
    inv.status, inv.issued_at, inv.updated_by = "issued", now(), p.id
    if inv.due_date is None:
        inv.due_date = inv.invoice_date + timedelta(days=customer.credit_days or 0)
    inv.customer_snapshot, inv.company_snapshot = _snapshot(db, inv), pdfkit.company_snapshot(db)
    settle(inv)
    db.flush()
    party = {"party_type": "customer", "party_id": inv.customer_id, "project_id": inv.project_id}
    gl.post(db, company_id=p.company_id, entry_date=inv.invoice_date, source_type="invoice", source_id=inv.id,
            source_number=inv.invoice_number, user_id=p.id,
            narration=f"Sales invoice {inv.invoice_number} to {customer.customer_name}",
            lines=[gl.Line("debtors", debit=inv.grand_total, **party),
                   gl.Line("sales", credit=inv.taxable, project_id=inv.project_id),
                   gl.Line("output_cgst", credit=inv.cgst), gl.Line("output_sgst", credit=inv.sgst),
                   gl.Line("output_igst", credit=inv.igst), gl.Line("round_off", credit=inv.round_off)])
    audit.record(db, action="issue", entity_type="invoice", entity_id=inv.id, entity_label=inv.invoice_number,
                 summary=f"Issued: ₹{inv.taxable} before GST, ₹{inv.grand_total} total, due {inv.due_date:%d %b %Y}")
    tally.document_posted(db, "invoice", inv.id)
    return inv


class _LineView:
    """An issued line seen as input, to re-check quantities against the order at issue time."""

    def __init__(self, it: InvoiceItem):
        self.so_item_id, self.quantity, self.rate = it.so_item_id, it.quantity, it.rate
        self.discount_pct, self.tax_rate = it.discount_pct, it.tax_rate


def set_irn(db: Session, p: Principal, invoice_id: uuid.UUID, data) -> Invoice:
    inv = get(db, invoice_id, lock=True)
    if inv.status != "issued":
        raise AppError("NOT_ISSUED", "An IRN is recorded on an issued invoice.")
    check_row_version(inv, data.row_version)
    inv.irn, inv.irn_ack_no, inv.irn_ack_date, inv.updated_by = data.irn, data.irn_ack_no, data.irn_ack_date, p.id
    db.flush()
    audit.record(db, action="update", entity_type="invoice", entity_id=inv.id, entity_label=inv.invoice_number,
                 summary=f"e-invoice IRN recorded ({data.irn_ack_no or 'no ack no.'})")
    return inv


# ------------------------------------------------------------------ credit notes
def credited_parts(db: Session, invoice_id: uuid.UUID) -> dict[str, Decimal]:
    row = db.execute(select(func.coalesce(func.sum(CreditNote.taxable), 0), func.coalesce(func.sum(CreditNote.cgst), 0),
                            func.coalesce(func.sum(CreditNote.sgst), 0), func.coalesce(func.sum(CreditNote.igst), 0),
                            func.coalesce(func.sum(CreditNote.round_off), 0), func.coalesce(func.sum(CreditNote.total), 0))
                     .where(CreditNote.invoice_id == invoice_id)).one()
    return dict(zip(("taxable", "cgst", "sgst", "igst", "round_off", "total"), (Decimal(x) for x in row), strict=True))


def credit_note(db: Session, p: Principal, invoice_id: uuid.UUID, data) -> CreditNote:
    if not p.can("invoice_post.approve"):
        raise Forbidden("Credit notes need the 'Issue sales invoices and credit notes' permission.", code="CANNOT_ISSUE")
    inv = get(db, invoice_id, lock=True)
    if inv.status != "issued":
        raise AppError("NOT_ISSUED", "A credit note is raised against an issued invoice.")
    if data.row_version is not None:
        check_row_version(inv, data.row_version)
    else:
        inv.row_version += 1
    done = credited_parts(db, inv.id)
    cn_date = data.cn_date or today()
    if cn_date < inv.invoice_date or cn_date > today():
        raise AppError("INVALID_DATE", "The credit note date must be between the invoice date and today.")
    if data.cancel_invoice:
        if inv.received > 0:
            raise AppError("HAS_RECEIPTS", f"₹{inv.received} has been received against this invoice. Remove those "
                                           "receipt allocations first (the money becomes an advance).")
        parts = {k: getattr(inv, k) - done[k] for k in ("taxable", "cgst", "sgst", "igst", "round_off")}
        total = inv.grand_total - done["total"]
    else:
        left = inv.taxable - done["taxable"]
        taxable = round_amount(data.taxable)
        if taxable > left:
            raise AppError("OVER_CREDIT", f"Only ₹{left} (before GST) is left to credit on this invoice.",
                           details={"field": "taxable"})
        share = taxable / inv.taxable if inv.taxable else Z
        parts = {"taxable": taxable, **{k: round_amount(getattr(inv, k) * share) for k in ("cgst", "sgst", "igst")}}
        total, parts["round_off"] = round_to_rupee(sum(parts.values(), Z))
        if total > inv.balance:
            raise AppError("OVER_CREDIT", f"This credit (₹{total}) is more than the ₹{inv.balance} still due. "
                                          "Remove receipt allocations first, or refund the customer.")
        if total <= 0:
            raise AppError("OVER_CREDIT", "The credit is too small.")
    cn = CreditNote(cn_number=numbering.next_number(db, p.company_id, "CN", on=cn_date), cn_date=cn_date,
                    invoice_id=inv.id, customer_id=inv.customer_id, reason=data.reason,
                    cancels_invoice=data.cancel_invoice, total=total, **parts, created_by=p.id, updated_by=p.id)
    db.add(cn)
    inv.credited += total
    if data.cancel_invoice:
        inv.status, inv.status_reason = "cancelled", f"Cancelled by credit note {cn.cn_number}: {data.reason}"[:500]
    settle(inv)
    inv.updated_by = p.id
    db.flush()
    party = {"party_type": "customer", "party_id": inv.customer_id, "project_id": inv.project_id}
    gl.post(db, company_id=p.company_id, entry_date=cn_date, source_type="credit_note", source_id=cn.id,
            source_number=cn.cn_number, user_id=p.id,
            narration=f"Credit note {cn.cn_number} against {inv.invoice_number}: {data.reason}",
            lines=[gl.Line("sales", debit=cn.taxable, project_id=inv.project_id), gl.Line("output_cgst", debit=cn.cgst),
                   gl.Line("output_sgst", debit=cn.sgst), gl.Line("output_igst", debit=cn.igst),
                   gl.Line("round_off", debit=cn.round_off), gl.Line("debtors", credit=cn.total, **party)])
    audit.record(db, action="credit_note", entity_type="invoice", entity_id=inv.id, entity_label=inv.invoice_number,
                 summary=f"Credit note {cn.cn_number}: ₹{cn.total}" + (" — invoice cancelled" if data.cancel_invoice
                                                                       else "") + f". {data.reason}")
    tally.document_posted(db, "credit_note", cn.id)
    return cn


# ------------------------------------------------------------------ lists
def list_invoices(db: Session, params: ListParams, *, status=None, customer_id=None, project_id=None,
                  sales_order_id=None, payment_status=None, outstanding=False, overdue=False):
    stmt = select(Invoice)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(Invoice.invoice_number.ilike(like), Invoice.subject.ilike(like),
                              Invoice.customer_po_number.ilike(like),
                              Invoice.customer_id.in_(select(Customer.id).where(Customer.customer_name.ilike(like)))))
    for col, val in ((Invoice.status, status), (Invoice.customer_id, customer_id), (Invoice.project_id, project_id),
                     (Invoice.sales_order_id, sales_order_id), (Invoice.payment_status, payment_status)):
        if val:
            stmt = stmt.where(col == val)
    if outstanding or overdue:
        stmt = stmt.where(Invoice.status == "issued", Invoice.payment_status != "paid")
    if overdue:
        stmt = stmt.where(Invoice.due_date < today())
    return paginate(db, stmt, params, default_sort=Invoice.created_at.desc(), sortable={
        "invoice_number": Invoice.invoice_number, "invoice_date": Invoice.invoice_date, "due_date": Invoice.due_date,
        "grand_total": Invoice.grand_total, "status": Invoice.status, "created_at": Invoice.created_at})
