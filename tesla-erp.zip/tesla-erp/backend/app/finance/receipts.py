"""Customer receipts (Spec §22: Project → Invoice → Receipt).

A receipt records the money that reached us and any TDS the customer deducted. It is allocated to one or more of
the customer's issued invoices; whatever is left unallocated is an advance that can be allocated later. Cancelling a
receipt (bounced cheque, wrong entry) releases its allocations and reverses its journal entry; it is never deleted.
"""
import uuid
from decimal import Decimal

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.core.api import ListParams, paginate
from app.core.errors import AppError, NotFound
from app.core.models import check_row_version
from app.core.money import round_amount
from app.crm.service import today
from app.customers.models import Customer
from app.finance import gl
from app.finance.invoices import settle
from app.finance.models import Invoice, Receipt, ReceiptAllocation
from app.platform.audit import service as audit
from app.platform.numbering import service as numbering
from app.projects.models import Project

Z = Decimal("0")


def get(db: Session, receipt_id: uuid.UUID, lock: bool = False) -> Receipt:
    r = db.get(Receipt, receipt_id, with_for_update=lock or None)
    if r is None:
        raise NotFound("receipt")
    return r


def _allocate(db: Session, p: Principal, r: Receipt, allocations) -> list[str]:
    """Apply money (and TDS) to invoices. Locks each invoice; never lets an invoice be over-settled."""
    merged: dict[uuid.UUID, list[Decimal]] = {}
    for a in allocations:
        amt, tds = round_amount(a.amount), round_amount(a.tds)
        if amt + tds <= 0:
            continue
        m = merged.setdefault(a.document_id, [Z, Z])
        m[0] += amt
        m[1] += tds
    total = sum((a + t for a, t in merged.values()), Z)
    tds_total = sum((t for _, t in merged.values()), Z)
    if total > r.unallocated:
        raise AppError("OVER_ALLOCATED", f"Only ₹{r.unallocated} of this receipt is free to allocate.")
    already_tds = sum((x.tds for x in r.allocations if x.is_active), Z)
    if tds_total + already_tds > r.tds_amount:
        raise AppError("TDS_EXCEEDED", f"The TDS allocated is more than the ₹{r.tds_amount} TDS on this receipt.")
    numbers = []
    for inv_id in sorted(merged, key=str):  # stable lock order
        amt, tds = merged[inv_id]
        inv = db.get(Invoice, inv_id, with_for_update=True)
        if inv is None or inv.customer_id != r.customer_id:
            raise AppError("INVALID_INVOICE", "An invoice is not this customer's.")
        if inv.status != "issued":
            raise AppError("INVALID_INVOICE", f"Invoice {inv.invoice_number or '(draft)'} is not open for payment.")
        if amt + tds > inv.balance:
            raise AppError("OVER_SETTLED", f"Invoice {inv.invoice_number} has only ₹{inv.balance} due.",
                           details={"invoice_id": str(inv.id), "balance": str(inv.balance)})
        r.allocations.append(ReceiptAllocation(invoice_id=inv.id, amount=amt, tds=tds, created_by=p.id,
                                               updated_by=p.id))
        inv.received += amt + tds
        inv.tds += tds
        settle(inv)
        inv.row_version += 1
        numbers.append(inv.invoice_number)
    r.allocated += total
    return numbers


def create(db: Session, p: Principal, data) -> Receipt:
    customer = db.get(Customer, data.customer_id)
    if customer is None:
        raise NotFound("customer")
    if data.project_id:
        prj = db.get(Project, data.project_id)
        if prj is None or prj.customer_id != customer.id:
            raise AppError("INVALID_PROJECT", "The project is not this customer's.")
    rdate = data.receipt_date or today()
    if rdate > today():
        raise AppError("FUTURE_DATE", "A receipt cannot be dated in the future.")
    r = Receipt(receipt_number=numbering.next_number(db, p.company_id, "RCT", on=rdate), receipt_date=rdate,
                customer_id=customer.id, project_id=data.project_id, sales_order_id=data.sales_order_id,
                mode=data.mode, reference_no=data.reference_no, instrument_date=data.instrument_date,
                bank_name=data.bank_name, amount=round_amount(data.amount), tds_amount=round_amount(data.tds_amount),
                allocated=Z, notes=data.notes, status="posted", created_by=p.id, updated_by=p.id)
    db.add(r)
    db.flush()
    numbers = _allocate(db, p, r, data.allocations)
    db.flush()
    party = {"party_type": "customer", "party_id": customer.id, "project_id": r.project_id}
    gl.post(db, company_id=p.company_id, entry_date=rdate, source_type="receipt", source_id=r.id,
            source_number=r.receipt_number, user_id=p.id,
            narration=f"Receipt {r.receipt_number} from {customer.customer_name} ({r.mode.upper()}"
                      + (f" {r.reference_no}" if r.reference_no else "") + ")",
            lines=[gl.Line(gl.money_account(r.mode), debit=r.amount), gl.Line("tds_receivable", debit=r.tds_amount),
                   gl.Line("debtors", credit=r.amount + r.tds_amount, **party)])
    audit.record(db, action="create", entity_type="receipt", entity_id=r.id, entity_label=r.receipt_number,
                 summary=f"₹{r.amount} received" + (f" + ₹{r.tds_amount} TDS" if r.tds_amount else "")
                         + (f", against {', '.join(numbers)}" if numbers else "")
                         + (f"; ₹{r.unallocated} on account (advance)" if r.unallocated else ""))
    return r


def allocate(db: Session, p: Principal, receipt_id: uuid.UUID, data) -> Receipt:
    r = get(db, receipt_id, lock=True)
    if r.status != "posted":
        raise AppError("CANCELLED", "This receipt is cancelled.")
    if data.row_version is not None:
        check_row_version(r, data.row_version)
    else:
        r.row_version += 1
    numbers = _allocate(db, p, r, data.allocations)
    r.updated_by = p.id
    db.flush()
    audit.record(db, action="allocate", entity_type="receipt", entity_id=r.id, entity_label=r.receipt_number,
                 summary=f"Allocated to {', '.join(numbers)}; ₹{r.unallocated} left on account")
    return r


def _release(db: Session, r: Receipt, a: ReceiptAllocation) -> str:
    inv = db.get(Invoice, a.invoice_id, with_for_update=True)
    inv.received -= a.amount + a.tds
    inv.tds -= a.tds
    settle(inv)
    inv.row_version += 1
    a.is_active = False
    r.allocated -= a.amount + a.tds
    return inv.invoice_number


def unallocate(db: Session, p: Principal, receipt_id: uuid.UUID, allocation_id: uuid.UUID) -> Receipt:
    """Take money off an invoice; it stays on the receipt as an advance."""
    r = get(db, receipt_id, lock=True)
    a = next((x for x in r.allocations if x.id == allocation_id and x.is_active), None)
    if a is None:
        raise NotFound("allocation")
    number = _release(db, r, a)
    r.updated_by, r.row_version = p.id, r.row_version + 1
    db.flush()
    audit.record(db, action="unallocate", entity_type="receipt", entity_id=r.id, entity_label=r.receipt_number,
                 summary=f"₹{a.amount + a.tds} taken off invoice {number}; now on account")
    return r


def cancel(db: Session, p: Principal, receipt_id: uuid.UUID, reason: str | None, row_version: int | None) -> Receipt:
    r = get(db, receipt_id, lock=True)
    if r.status != "posted":
        raise AppError("CANCELLED", "This receipt is already cancelled.")
    if not (reason and reason.strip()):
        raise AppError("REASON_REQUIRED", "Say why the receipt is cancelled (e.g. cheque bounced).",
                       details={"field": "reason"})
    if row_version is not None:
        check_row_version(r, row_version)
    else:
        r.row_version += 1
    numbers = [_release(db, r, a) for a in r.allocations if a.is_active]
    r.status, r.status_reason, r.updated_by = "cancelled", reason[:500], p.id
    db.flush()
    gl.reverse(db, company_id=p.company_id, source_type="receipt", source_id=r.id, entry_date=today(),
               narration=f"receipt {r.receipt_number} cancelled: {reason}", user_id=p.id)
    audit.record(db, action="cancel", entity_type="receipt", entity_id=r.id, entity_label=r.receipt_number,
                 summary=f"Cancelled: {reason}" + (f". Released from {', '.join(numbers)}" if numbers else ""))
    return r


def list_receipts(db: Session, params: ListParams, *, customer_id=None, project_id=None, status=None,
                  unallocated=False, date_from=None, date_to=None):
    stmt = select(Receipt)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(Receipt.receipt_number.ilike(like), Receipt.reference_no.ilike(like),
                              Receipt.customer_id.in_(select(Customer.id).where(Customer.customer_name.ilike(like)))))
    for col, val in ((Receipt.customer_id, customer_id), (Receipt.project_id, project_id), (Receipt.status, status)):
        if val:
            stmt = stmt.where(col == val)
    if unallocated:
        stmt = stmt.where(Receipt.status == "posted", Receipt.allocated < Receipt.amount + Receipt.tds_amount)
    if date_from:
        stmt = stmt.where(Receipt.receipt_date >= date_from)
    if date_to:
        stmt = stmt.where(Receipt.receipt_date <= date_to)
    return paginate(db, stmt, params, default_sort=Receipt.created_at.desc(), sortable={
        "receipt_number": Receipt.receipt_number, "receipt_date": Receipt.receipt_date, "amount": Receipt.amount,
        "created_at": Receipt.created_at})
