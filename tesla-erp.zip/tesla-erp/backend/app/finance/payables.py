"""Supplier invoices and payments (Spec §22: PO → GRN → Supplier invoice → Payment).

A supplier invoice is matched line by line to its purchase order and to what the GRNs accepted (3-way match). If
it bills more than was received, at a higher net rate than ordered, or at a different GST rate, the differences are
listed on the bill and it goes for approval before it is posted (rule: approval rules → Supplier invoices).
"""
import uuid
from collections import defaultdict
from decimal import Decimal

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.boq import lines as L
from app.core.api import ListParams, paginate
from app.core.errors import AppError, NotFound
from app.core.gst import is_inter_state
from app.core.models import check_row_version
from app.core.money import round_amount, round_qty
from app.crm.service import now, today
from app.finance import gl
from app.finance.models import (
    LedgerAccount,
    SupplierInvoice,
    SupplierInvoiceItem,
    SupplierPayment,
    SupplierPaymentAllocation,
)
from app.platform.approvals import service as approvals
from app.platform.audit import service as audit
from app.platform.notifications.service import notify, users_with_roles
from app.platform.numbering import service as numbering
from app.projects.models import Project
from app.purchase.models import PurchaseOrder
from app.suppliers.models import Supplier

Z = Decimal("0")
TOTALS = ("gross", "line_discount", "taxable", "cgst", "sgst", "igst", "round_off", "grand_total")
BILLABLE_PO = ("approved", "sent", "partially_received", "received", "closed")


def get_bill(db: Session, bill_id: uuid.UUID, lock: bool = False) -> SupplierInvoice:
    b = db.get(SupplierInvoice, bill_id, with_for_update=lock or None)
    if b is None:
        raise NotFound("supplier_invoice")
    return b


def bill_label(b: SupplierInvoice) -> str:
    return b.bill_number or f"Bill {b.supplier_invoice_no}"


def settle_bill(b: SupplierInvoice) -> None:
    b.payment_status = "paid" if b.paid >= b.grand_total else ("partially_paid" if b.paid > 0 else "unpaid")


def billed_po_qty(db: Session, po_item_ids, exclude: uuid.UUID | None = None) -> dict[uuid.UUID, Decimal]:
    ids = [i for i in po_item_ids if i]
    if not ids:
        return {}
    stmt = (select(SupplierInvoiceItem.po_item_id, func.sum(SupplierInvoiceItem.quantity))
            .join(SupplierInvoice, SupplierInvoice.id == SupplierInvoiceItem.supplier_invoice_id)
            .where(SupplierInvoiceItem.po_item_id.in_(ids), SupplierInvoice.status.in_(("pending_approval", "posted")))
            .group_by(SupplierInvoiceItem.po_item_id))
    if exclude:
        stmt = stmt.where(SupplierInvoice.id != exclude)
    return {k: Decimal(v) for k, v in db.execute(stmt).all()}


def po_billable_lines(db: Session, po: PurchaseOrder) -> list[dict]:
    """PO lines with what was received and what is still to be billed — the starting point of a new bill."""
    done = billed_po_qty(db, [it.id for it in po.items])
    out = []
    for it in po.items:
        out.append({**L.line_out(it), "po_item_id": str(it.id), "ordered_qty": str(round_qty(it.quantity)),
                    "received_qty": str(round_qty(it.received_qty)), "billed_qty": str(round_qty(done.get(it.id, Z))),
                    "to_bill_qty": str(round_qty(max(it.received_qty - done.get(it.id, Z), Z)))})
    return out


def _net(rate: Decimal, disc: Decimal) -> Decimal:
    return rate * (100 - disc) / 100


def match(db: Session, po: PurchaseOrder | None, items, exclude: uuid.UUID | None) -> list[dict]:
    """3-way match: returns the differences that need approval (empty = matches)."""
    if po is None:
        return []
    po_items = {it.id: it for it in po.items}
    done = billed_po_qty(db, po_items.keys(), exclude=exclude)
    asked: dict[uuid.UUID, Decimal] = defaultdict(lambda: Z)
    out = []
    for n, ln in enumerate(items, start=1):
        if not ln.po_item_id:
            out.append({"line": n, "kind": "not_on_po", "message": f"Line {n} is not on {po.po_number}."})
            continue
        it = po_items.get(ln.po_item_id)
        if it is None:
            raise AppError("INVALID_PO_LINE", f"Line {n}: not a line of {po.po_number}.", details={"line": n})
        asked[it.id] += ln.quantity
        if _net(ln.rate, ln.discount_pct) > _net(it.rate, it.discount_pct) + Decimal("0.005"):
            out.append({"line": n, "kind": "rate", "message": f"Line {n}: net rate ₹{round_amount(_net(ln.rate, ln.discount_pct))}"
                        f" is above the PO's ₹{round_amount(_net(it.rate, it.discount_pct))}."})
        if ln.tax_rate != it.tax_rate:
            out.append({"line": n, "kind": "gst", "message": f"Line {n}: GST {ln.tax_rate.normalize():f} % differs from "
                        f"the PO's {it.tax_rate.normalize():f} %."})
    for pid, qty in asked.items():
        it = po_items[pid]
        left = it.received_qty - done.get(pid, Z)
        if qty > left:
            out.append({"kind": "quantity", "po_item_id": str(pid),
                        "message": f"'{it.description[:50]}': billed {round_qty(qty):f} {it.unit} but only "
                                   f"{round_qty(max(left, Z)):f} received and not yet billed."})
    return out


def _fill_bill(db: Session, p: Principal, b: SupplierInvoice, data) -> None:
    sup = db.get(Supplier, data.supplier_id)
    if sup is None:
        raise NotFound("supplier")
    po = None
    if data.purchase_order_id:
        po = db.get(PurchaseOrder, data.purchase_order_id)
        if po is None or po.supplier_id != sup.id:
            raise AppError("INVALID_PO", "The purchase order is not this supplier's.")
        if po.status not in BILLABLE_PO:
            raise AppError("PO_NOT_BILLABLE", f"Purchase order {po.po_number or ''} is {po.status.replace('_', ' ')}.")
    project_id = data.project_id or (po.project_id if po else None)
    if project_id and db.get(Project, project_id) is None:
        raise NotFound("project")
    account_id = data.account_id or gl.account(db, "purchases")
    acc = db.get(LedgerAccount, account_id)
    if acc is None or not acc.is_active or acc.account_type not in ("expense", "asset"):
        raise AppError("INVALID_ACCOUNT", "Choose an active expense or purchase ledger.")
    if any(ln.po_item_id for ln in data.items) and po is None:
        raise AppError("NO_PO", "Lines linked to PO lines need the purchase order on the bill.")
    clash = db.scalar(select(SupplierInvoice.id).where(
        SupplierInvoice.supplier_id == sup.id, SupplierInvoice.status != "cancelled",
        func.lower(SupplierInvoice.supplier_invoice_no) == data.supplier_invoice_no.lower(),
        SupplierInvoice.id != b.id if b.id else True))
    if clash:
        raise AppError("DUPLICATE_BILL", f"{sup.supplier_name}'s invoice {data.supplier_invoice_no} is already entered.",
                       details={"field": "supplier_invoice_no"})
    L.validate(db, data.items)
    inter = po.inter_state if po is not None else is_inter_state(L.company_state(db, p.company_id), sup.state_code)
    rows, t = L.compute(data.items, inter_state=inter, special_discount=data.special_discount)
    b.items.clear()
    db.flush()
    for row, ln in zip(rows, data.items, strict=True):
        b.items.append(SupplierInvoiceItem(**row, po_item_id=ln.po_item_id, created_by=p.id, updated_by=p.id))
    b.supplier_id, b.purchase_order_id, b.project_id, b.account_id = sup.id, po.id if po else None, project_id, acc.id
    b.supplier_invoice_no, b.supplier_invoice_date = data.supplier_invoice_no.strip(), data.supplier_invoice_date
    b.due_date = data.due_date
    b.place_of_supply, b.inter_state, b.notes = sup.state_code, inter, data.notes
    b.special_discount = round_amount(data.special_discount)
    for k in TOTALS:
        setattr(b, k, round_amount(getattr(t, k)))
    b.mismatches = match(db, po, data.items, b.id)
    b.updated_by = p.id


def create_bill(db: Session, p: Principal, data) -> SupplierInvoice:
    b = SupplierInvoice(status="draft", supplier_invoice_no=data.supplier_invoice_no,
                        supplier_invoice_date=data.supplier_invoice_date, created_by=p.id, updated_by=p.id)
    _fill_bill(db, p, b, data)
    db.add(b)
    db.flush()
    audit.record(db, action="create", entity_type="supplier_invoice", entity_id=b.id, entity_label=bill_label(b),
                 summary=f"₹{b.grand_total} total" + (f"; {len(b.mismatches)} difference(s) from the PO/GRN"
                                                      if b.mismatches else ""))
    return b


def update_bill(db: Session, p: Principal, bill_id: uuid.UUID, data) -> SupplierInvoice:
    b = get_bill(db, bill_id, lock=True)
    if b.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft bill can be edited.")
    check_row_version(b, data.row_version)
    _fill_bill(db, p, b, data)
    db.flush()
    audit.record(db, action="update", entity_type="supplier_invoice", entity_id=b.id, entity_label=bill_label(b),
                 summary=f"₹{b.grand_total} total")
    return b


def delete_bill(db: Session, p: Principal, bill_id: uuid.UUID) -> None:
    b = get_bill(db, bill_id, lock=True)
    if b.status != "draft" or b.bill_number:
        raise AppError("NOT_DRAFT", "Only an unposted draft can be discarded. Cancel a posted bill instead.")
    lbl = bill_label(b)
    db.delete(b)
    db.flush()
    audit.record(db, action="delete", entity_type="supplier_invoice", entity_id=bill_id, entity_label=lbl)


def _post_bill(db: Session, p: Principal, b: SupplierInvoice) -> None:
    sup = db.get(Supplier, b.supplier_id)
    b.status, b.posted_at = "posted", now()
    if b.due_date is None:
        from datetime import timedelta

        b.due_date = b.supplier_invoice_date + timedelta(days=sup.credit_days or 0)
    settle_bill(b)
    db.flush()
    gl.post(db, company_id=p.company_id, entry_date=b.supplier_invoice_date, source_type="supplier_invoice",
            source_id=b.id, source_number=b.bill_number, user_id=p.id,
            narration=f"Purchase bill {b.bill_number}: {sup.supplier_name} invoice {b.supplier_invoice_no}",
            lines=[gl.Line(b.account_id, debit=b.taxable, project_id=b.project_id),
                   gl.Line("input_cgst", debit=b.cgst), gl.Line("input_sgst", debit=b.sgst),
                   gl.Line("input_igst", debit=b.igst), gl.Line("round_off", debit=b.round_off),
                   gl.Line("creditors", credit=b.grand_total, party_type="supplier", party_id=b.supplier_id,
                           project_id=b.project_id)])
    acc = db.get(LedgerAccount, b.account_id)
    if b.project_id and acc.cost_head:  # subcontract / labour / site bills booked to a project are project cost
        from app.costing import service as costing

        costing.record(db, project_id=b.project_id, cost_head=acc.cost_head, amount=b.taxable,
                       description=f"{acc.name}: {sup.supplier_name} invoice {b.supplier_invoice_no}",
                       source_type="supplier_invoice", source_id=b.id, source_number=b.bill_number,
                       cost_date=b.supplier_invoice_date, user_id=p.id, party=sup.supplier_name)


def submit_bill(db: Session, p: Principal, bill_id: uuid.UUID, row_version: int | None) -> SupplierInvoice:
    b = get_bill(db, bill_id, lock=True)
    if b.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft bill can be posted.")
    if row_version is not None:
        check_row_version(b, row_version)
    else:
        b.row_version += 1
    po = db.get(PurchaseOrder, b.purchase_order_id) if b.purchase_order_id else None
    b.mismatches = match(db, po, b.items, b.id)   # re-check: other bills or GRNs may have changed since
    b.bill_number = b.bill_number or numbering.next_number(db, p.company_id, "PB", on=b.supplier_invoice_date)
    b.last_rejection, b.updated_by = None, p.id
    req = None
    if b.mismatches:
        sup = db.get(Supplier, b.supplier_id)
        division = db.scalar(select(Project.division_id).where(Project.id == b.project_id)) if b.project_id else None
        req = approvals.start(db, p, entity_type="supplier_invoice", entity_id=b.id,
                              label=f"{b.bill_number} · {sup.supplier_name} {b.supplier_invoice_no}",
                              amount=b.taxable, division_id=division)
    if req is None:
        _post_bill(db, p, b)
    else:
        b.status = "pending_approval"
    db.flush()
    audit.record(db, action="submit", entity_type="supplier_invoice", entity_id=b.id, entity_label=b.bill_number,
                 summary=("Posted" if req is None else "Sent for approval — differs from the PO/GRN: "
                          + "; ".join(m["message"] for m in b.mismatches))[:1000])
    return b


def _bill_approved(db: Session, p: Principal, req) -> None:
    b = get_bill(db, req.entity_id, lock=True)
    if b.status != "pending_approval":
        return
    _post_bill(db, p, b)
    b.row_version += 1


def _bill_rejected(db: Session, p: Principal, req, comment: str) -> None:
    b = get_bill(db, req.entity_id, lock=True)
    b.status, b.last_rejection = "draft", comment[:500]
    b.row_version += 1


approvals.register("supplier_invoice", approvals.Handler(
    label="Supplier invoice", href=lambda i: f"/finance/bills/view?id={i}", on_approved=_bill_approved,
    on_rejected=_bill_rejected,
    owners=lambda db, i: [x for x in [db.scalar(select(SupplierInvoice.created_by).where(SupplierInvoice.id == i))] if x]))


def cancel_bill(db: Session, p: Principal, bill_id: uuid.UUID, reason: str | None, row_version: int | None) -> SupplierInvoice:
    b = get_bill(db, bill_id, lock=True)
    if b.status not in ("pending_approval", "posted"):
        raise AppError("INVALID_TRANSITION", "Only a submitted or posted bill can be cancelled (discard a draft).")
    if not (reason and reason.strip()):
        raise AppError("REASON_REQUIRED", "Say why the bill is cancelled.", details={"field": "reason"})
    if b.paid > 0:
        raise AppError("HAS_PAYMENTS", f"₹{b.paid} has been paid against this bill. Take those payments off it first.")
    if row_version is not None:
        check_row_version(b, row_version)
    else:
        b.row_version += 1
    was = b.status
    approvals.withdraw(db, p, "supplier_invoice", b.id)
    b.status, b.status_reason, b.updated_by = "cancelled", reason[:500], p.id
    db.flush()
    if was == "posted":
        gl.reverse(db, company_id=p.company_id, source_type="supplier_invoice", source_id=b.id, entry_date=today(),
                   narration=f"bill {b.bill_number} cancelled: {reason}", user_id=p.id)
        from app.costing import service as costing

        costing.reverse_source(db, source_type="supplier_invoice", source_id=b.id,
                               reason=f"bill cancelled: {reason}", user_id=p.id)
    audit.record(db, action="cancel", entity_type="supplier_invoice", entity_id=b.id, entity_label=bill_label(b),
                 summary=f"Cancelled: {reason}")
    return b


def list_bills(db: Session, params: ListParams, *, status=None, supplier_id=None, purchase_order_id=None,
               project_id=None, outstanding=False, overdue=False):
    stmt = select(SupplierInvoice)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(SupplierInvoice.bill_number.ilike(like), SupplierInvoice.supplier_invoice_no.ilike(like),
                              SupplierInvoice.supplier_id.in_(select(Supplier.id).where(Supplier.supplier_name.ilike(like)))))
    for col, val in ((SupplierInvoice.status, status), (SupplierInvoice.supplier_id, supplier_id),
                     (SupplierInvoice.purchase_order_id, purchase_order_id), (SupplierInvoice.project_id, project_id)):
        if val:
            stmt = stmt.where(col == val)
    if outstanding or overdue:
        stmt = stmt.where(SupplierInvoice.status == "posted", SupplierInvoice.payment_status != "paid")
    if overdue:
        stmt = stmt.where(SupplierInvoice.due_date < today())
    return paginate(db, stmt, params, default_sort=SupplierInvoice.created_at.desc(), sortable={
        "bill_number": SupplierInvoice.bill_number, "supplier_invoice_date": SupplierInvoice.supplier_invoice_date,
        "due_date": SupplierInvoice.due_date, "grand_total": SupplierInvoice.grand_total,
        "created_at": SupplierInvoice.created_at})


# ================================================================== supplier payments
def get_payment(db: Session, pid: uuid.UUID, lock: bool = False) -> SupplierPayment:
    pay = db.get(SupplierPayment, pid, with_for_update=lock or None)
    if pay is None:
        raise NotFound("supplier_payment")
    return pay


def _allocate(db: Session, p: Principal, pay: SupplierPayment, allocations) -> list[str]:
    merged: dict[uuid.UUID, list[Decimal]] = {}
    for a in allocations:
        amt, tds = round_amount(a.amount), round_amount(a.tds)
        if amt + tds <= 0:
            continue
        m = merged.setdefault(a.document_id, [Z, Z])
        m[0] += amt
        m[1] += tds
    total = sum((a + t for a, t in merged.values()), Z)
    if total > pay.unallocated:
        raise AppError("OVER_ALLOCATED", f"Only ₹{pay.unallocated} of this payment is free to allocate.")
    already_tds = sum((x.tds for x in pay.allocations if x.is_active), Z)
    if sum((t for _, t in merged.values()), Z) + already_tds > pay.tds_amount:
        raise AppError("TDS_EXCEEDED", f"The TDS allocated is more than the ₹{pay.tds_amount} deducted.")
    numbers = []
    for bid in sorted(merged, key=str):
        amt, tds = merged[bid]
        b = db.get(SupplierInvoice, bid, with_for_update=True)
        if b is None or b.supplier_id != pay.supplier_id:
            raise AppError("INVALID_BILL", "A bill is not this supplier's.")
        if b.status != "posted":
            raise AppError("INVALID_BILL", f"Bill {bill_label(b)} is not posted.")
        if amt + tds > b.balance:
            raise AppError("OVER_SETTLED", f"Bill {bill_label(b)} has only ₹{b.balance} due.",
                           details={"supplier_invoice_id": str(b.id), "balance": str(b.balance)})
        pay.allocations.append(SupplierPaymentAllocation(supplier_invoice_id=b.id, amount=amt, tds=tds,
                                                         created_by=p.id, updated_by=p.id))
        b.paid += amt + tds
        settle_bill(b)
        b.row_version += 1
        numbers.append(bill_label(b))
    pay.allocated += total
    return numbers


def create_payment(db: Session, p: Principal, data) -> SupplierPayment:
    sup = db.get(Supplier, data.supplier_id)
    if sup is None:
        raise NotFound("supplier")
    pdate = data.payment_date or today()
    if pdate > today():
        raise AppError("FUTURE_DATE", "A payment cannot be dated in the future.")
    pay = SupplierPayment(payment_number=numbering.next_number(db, p.company_id, "PAY", on=pdate), payment_date=pdate,
                          supplier_id=sup.id, purchase_order_id=data.purchase_order_id, mode=data.mode,
                          reference_no=data.reference_no, bank_name=data.bank_name, amount=round_amount(data.amount),
                          tds_amount=round_amount(data.tds_amount), allocated=Z, notes=data.notes, status="posted",
                          created_by=p.id, updated_by=p.id)
    db.add(pay)
    db.flush()
    numbers = _allocate(db, p, pay, data.allocations)
    db.flush()
    gl.post(db, company_id=p.company_id, entry_date=pdate, source_type="supplier_payment", source_id=pay.id,
            source_number=pay.payment_number, user_id=p.id,
            narration=f"Payment {pay.payment_number} to {sup.supplier_name} ({pay.mode.upper()}"
                      + (f" {pay.reference_no}" if pay.reference_no else "") + ")",
            lines=[gl.Line("creditors", debit=pay.amount + pay.tds_amount, party_type="supplier", party_id=sup.id),
                   gl.Line(gl.money_account(pay.mode), credit=pay.amount),
                   gl.Line("tds_payable", credit=pay.tds_amount)])
    audit.record(db, action="create", entity_type="supplier_payment", entity_id=pay.id, entity_label=pay.payment_number,
                 summary=f"₹{pay.amount} paid" + (f" + ₹{pay.tds_amount} TDS deducted" if pay.tds_amount else "")
                         + (f", against {', '.join(numbers)}" if numbers else "")
                         + (f"; ₹{pay.unallocated} advance" if pay.unallocated else ""))
    notify(db, users_with_roles(db, ["DIRECTOR"]), event="supplier_payment.created", exclude=p.id,
           title=f"Payment {pay.payment_number}: ₹{pay.amount} to {sup.supplier_name}",
           body=f"By {p.user.full_name}", link=f"/finance/payments/view?id={pay.id}")
    return pay


def allocate_payment(db: Session, p: Principal, pid: uuid.UUID, data) -> SupplierPayment:
    pay = get_payment(db, pid, lock=True)
    if pay.status != "posted":
        raise AppError("CANCELLED", "This payment is cancelled.")
    if data.row_version is not None:
        check_row_version(pay, data.row_version)
    else:
        pay.row_version += 1
    numbers = _allocate(db, p, pay, data.allocations)
    pay.updated_by = p.id
    db.flush()
    audit.record(db, action="allocate", entity_type="supplier_payment", entity_id=pay.id,
                 entity_label=pay.payment_number, summary=f"Allocated to {', '.join(numbers)}")
    return pay


def _release(db: Session, pay: SupplierPayment, a: SupplierPaymentAllocation) -> str:
    b = db.get(SupplierInvoice, a.supplier_invoice_id, with_for_update=True)
    b.paid -= a.amount + a.tds
    settle_bill(b)
    b.row_version += 1
    a.is_active = False
    pay.allocated -= a.amount + a.tds
    return bill_label(b)


def unallocate_payment(db: Session, p: Principal, pid: uuid.UUID, allocation_id: uuid.UUID) -> SupplierPayment:
    pay = get_payment(db, pid, lock=True)
    a = next((x for x in pay.allocations if x.id == allocation_id and x.is_active), None)
    if a is None:
        raise NotFound("allocation")
    number = _release(db, pay, a)
    pay.updated_by, pay.row_version = p.id, pay.row_version + 1
    db.flush()
    audit.record(db, action="unallocate", entity_type="supplier_payment", entity_id=pay.id,
                 entity_label=pay.payment_number, summary=f"₹{a.amount + a.tds} taken off bill {number}")
    return pay


def cancel_payment(db: Session, p: Principal, pid: uuid.UUID, reason: str | None, row_version: int | None) -> SupplierPayment:
    pay = get_payment(db, pid, lock=True)
    if pay.status != "posted":
        raise AppError("CANCELLED", "This payment is already cancelled.")
    if not (reason and reason.strip()):
        raise AppError("REASON_REQUIRED", "Say why the payment is cancelled.", details={"field": "reason"})
    if row_version is not None:
        check_row_version(pay, row_version)
    else:
        pay.row_version += 1
    numbers = [_release(db, pay, a) for a in pay.allocations if a.is_active]
    pay.status, pay.status_reason, pay.updated_by = "cancelled", reason[:500], p.id
    db.flush()
    gl.reverse(db, company_id=p.company_id, source_type="supplier_payment", source_id=pay.id, entry_date=today(),
               narration=f"payment {pay.payment_number} cancelled: {reason}", user_id=p.id)
    audit.record(db, action="cancel", entity_type="supplier_payment", entity_id=pay.id, entity_label=pay.payment_number,
                 summary=f"Cancelled: {reason}" + (f". Released from {', '.join(numbers)}" if numbers else ""))
    return pay


def list_payments(db: Session, params: ListParams, *, supplier_id=None, status=None, date_from=None, date_to=None):
    stmt = select(SupplierPayment)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(SupplierPayment.payment_number.ilike(like), SupplierPayment.reference_no.ilike(like),
                              SupplierPayment.supplier_id.in_(select(Supplier.id).where(Supplier.supplier_name.ilike(like)))))
    for col, val in ((SupplierPayment.supplier_id, supplier_id), (SupplierPayment.status, status)):
        if val:
            stmt = stmt.where(col == val)
    if date_from:
        stmt = stmt.where(SupplierPayment.payment_date >= date_from)
    if date_to:
        stmt = stmt.where(SupplierPayment.payment_date <= date_to)
    return paginate(db, stmt, params, default_sort=SupplierPayment.created_at.desc(), sortable={
        "payment_number": SupplierPayment.payment_number, "payment_date": SupplierPayment.payment_date,
        "amount": SupplierPayment.amount, "created_at": SupplierPayment.created_at})
