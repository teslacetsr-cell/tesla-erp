"""Finance (Spec §22–§25): sales invoices, credit notes, customer receipts, supplier invoices, supplier payments,
expense claims, and the journal that every posted document writes to.

Rules kept by this module:
- An issued invoice is never edited or deleted. It is reduced or cancelled only by a credit note.
- A receipt or payment is never deleted; it is cancelled with a reason, which reverses its journal entry.
- Every posted document writes a balanced journal entry in the same transaction (a database constraint trigger
  refuses an unbalanced entry at commit). Journal rows are append-only.
- Amounts are NUMERIC; GST comes from the line items and the GST rate master, never from constants.
"""
import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, String, Text, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.boq.models import LineColumns
from app.core.models import AuditColumnsMixin, Base
from app.core.money import AMOUNT, PERCENT

Z = Decimal("0")
ACCOUNT_TYPES = ("asset", "liability", "income", "expense", "equity")
COST_HEADS = ("material", "labour", "subcontract", "travel", "other")
INVOICE_STATUSES = ("draft", "issued", "cancelled")
BILL_TYPES = ("regular", "running", "final", "service")
PAYMENT_STATUSES = ("unpaid", "partially_paid", "paid")
PAYMENT_MODES = ("cash", "cheque", "neft", "rtgs", "imps", "upi", "card", "dd", "other")
SUPPLIER_INVOICE_STATUSES = ("draft", "pending_approval", "posted", "cancelled")
EXPENSE_STATUSES = ("draft", "submitted", "approved", "paid", "rejected", "cancelled")


def _in(col: str, values: tuple[str, ...]) -> str:
    return f"{col} in ({', '.join(repr(v) for v in values)})"


def _money(nullable: bool = False):
    return mapped_column(AMOUNT, nullable=nullable, default=Z, server_default="0")


# ================================================================== chart of accounts & journal
class LedgerAccount(AuditColumnsMixin, Base):
    """A ledger in the chart of accounts. `system_key` marks the ledgers documents post to automatically
    (debtors, sales, output CGST …); `cost_head` marks expense ledgers that count as project cost."""

    __tablename__ = "ledger_accounts"
    __table_args__ = (CheckConstraint(_in("account_type", ACCOUNT_TYPES), name="type_valid"),
                      CheckConstraint(f"cost_head is null or {_in('cost_head', COST_HEADS)}", name="cost_head_valid"))

    code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(120), unique=True, nullable=False)
    account_type: Mapped[str] = mapped_column(String(10), nullable=False)
    group_name: Mapped[str | None] = mapped_column(String(80))   # Tally group, e.g. "Sundry Debtors"
    system_key: Mapped[str | None] = mapped_column(String(40), unique=True)
    cost_head: Mapped[str | None] = mapped_column(String(15))
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class JournalEntry(Base):
    """Append-only. Written only by the posting code; corrections are reversing entries."""

    __tablename__ = "journal_entries"
    __table_args__ = (Index("ix_journal_entries_source", "source_type", "source_id"),
                      Index("ix_journal_entries_date", "entry_date"))

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4, server_default=text("gen_random_uuid()"))
    entry_number: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    entry_date: Mapped[date] = mapped_column(Date, nullable=False)
    source_type: Mapped[str] = mapped_column(String(40), nullable=False)    # invoice, receipt, credit_note …
    source_id: Mapped[uuid.UUID] = mapped_column(nullable=False)
    source_number: Mapped[str | None] = mapped_column(String(40))
    narration: Mapped[str] = mapped_column(String(500), nullable=False)
    total: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False)
    reverses_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("journal_entries.id", ondelete="RESTRICT"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=text("now()"))
    created_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))

    lines: Mapped[list["JournalLine"]] = relationship(order_by="JournalLine.line_no", lazy="selectin")


class JournalLine(Base):
    __tablename__ = "journal_lines"
    __table_args__ = (CheckConstraint("debit >= 0 and credit >= 0 and (debit = 0) <> (credit = 0)",
                                      name="one_side"),
                      CheckConstraint("party_type is null or party_type in ('customer','supplier','employee')",
                                      name="party_type_valid"),
                      Index("ix_journal_lines_account", "account_id"), Index("ix_journal_lines_party", "party_id"),
                      Index("ix_journal_lines_project", "project_id"))

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4, server_default=text("gen_random_uuid()"))
    entry_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("journal_entries.id", ondelete="RESTRICT"), nullable=False,
                                                index=True)
    line_no: Mapped[int] = mapped_column(Integer, nullable=False)
    account_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("ledger_accounts.id", ondelete="RESTRICT"), nullable=False)
    debit: Mapped[Decimal] = _money()
    credit: Mapped[Decimal] = _money()
    party_type: Mapped[str | None] = mapped_column(String(10))
    party_id: Mapped[uuid.UUID | None] = mapped_column()
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"))
    narration: Mapped[str | None] = mapped_column(String(300))


# ================================================================== sales invoices
class Invoice(AuditColumnsMixin, Base):
    __tablename__ = "invoices"
    __table_args__ = (CheckConstraint(_in("status", INVOICE_STATUSES), name="status_valid"),
                      CheckConstraint(_in("bill_type", BILL_TYPES), name="bill_type_valid"),
                      CheckConstraint(_in("payment_status", PAYMENT_STATUSES), name="payment_status_valid"),
                      CheckConstraint("received >= 0 and credited >= 0 and retention_amount >= 0", name="amounts_nonneg"),
                      CheckConstraint("received + credited <= grand_total", name="not_over_settled"),
                      CheckConstraint("status <> 'issued' or invoice_number is not null", name="issued_numbered"),
                      Index("ix_invoices_customer", "customer_id"), Index("ix_invoices_status", "status"),
                      Index("ix_invoices_sales_order", "sales_order_id"), Index("ix_invoices_project", "project_id"))

    invoice_number: Mapped[str | None] = mapped_column(String(16), unique=True)   # GST limit: 16 characters
    invoice_date: Mapped[date] = mapped_column(Date, nullable=False)
    due_date: Mapped[date | None] = mapped_column(Date)
    bill_type: Mapped[str] = mapped_column(String(10), nullable=False, default="regular", server_default="regular")
    ra_bill_no: Mapped[int | None] = mapped_column(Integer)
    customer_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("customers.id", ondelete="RESTRICT"), nullable=False)
    sales_order_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("sales_orders.id", ondelete="RESTRICT"))
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"))
    site_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("customer_sites.id", ondelete="RESTRICT"))
    division_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("business_divisions.id", ondelete="RESTRICT"))
    subject: Mapped[str | None] = mapped_column(String(200))
    customer_po_number: Mapped[str | None] = mapped_column(String(60))
    customer_po_date: Mapped[date | None] = mapped_column(Date)
    place_of_supply: Mapped[str | None] = mapped_column(String(2))
    inter_state: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    reverse_charge: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    payment_terms: Mapped[str | None] = mapped_column(Text)
    notes: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="draft", server_default="draft")
    status_reason: Mapped[str | None] = mapped_column(String(500))
    issued_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    special_discount: Mapped[Decimal] = _money()
    gross: Mapped[Decimal] = _money()
    line_discount: Mapped[Decimal] = _money()
    taxable: Mapped[Decimal] = _money()
    cgst: Mapped[Decimal] = _money()
    sgst: Mapped[Decimal] = _money()
    igst: Mapped[Decimal] = _money()
    round_off: Mapped[Decimal] = _money()
    grand_total: Mapped[Decimal] = _money()
    # Retention: part of the invoice the customer holds back until the defects-liability period ends.
    retention_pct: Mapped[Decimal] = mapped_column(PERCENT, nullable=False, default=Z, server_default="0")
    retention_amount: Mapped[Decimal] = _money()
    received: Mapped[Decimal] = _money()     # receipts allocated, including TDS the customer deducted
    tds: Mapped[Decimal] = _money()          # the TDS part of `received`
    credited: Mapped[Decimal] = _money()     # credit notes
    payment_status: Mapped[str] = mapped_column(String(15), nullable=False, default="unpaid", server_default="unpaid")
    customer_snapshot: Mapped[dict | None] = mapped_column(JSONB)
    company_snapshot: Mapped[dict | None] = mapped_column(JSONB)
    # e-invoicing (Spec risk R3): filled when the IRN is generated on the government portal
    irn: Mapped[str | None] = mapped_column(String(64))
    irn_ack_no: Mapped[str | None] = mapped_column(String(30))
    irn_ack_date: Mapped[date | None] = mapped_column(Date)

    items: Mapped[list["InvoiceItem"]] = relationship(order_by="InvoiceItem.line_no", cascade="all, delete-orphan",
                                                      lazy="selectin")

    @property
    def balance(self) -> Decimal:
        return self.grand_total - self.received - self.credited


class InvoiceItem(AuditColumnsMixin, LineColumns, Base):
    __tablename__ = "invoice_items"
    __table_args__ = (Index("ix_invoice_items_so_item", "so_item_id"),)

    invoice_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("invoices.id", ondelete="CASCADE"), nullable=False,
                                                  index=True)
    special_discount: Mapped[Decimal] = _money()
    so_item_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("sales_order_items.id", ondelete="RESTRICT"))


class CreditNote(AuditColumnsMixin, Base):
    """Reduces or cancels an issued invoice (Spec §22: posted invoices are corrected only by credit note). The tax
    is reversed in the invoice's own proportion."""

    __tablename__ = "credit_notes"
    __table_args__ = (CheckConstraint("taxable >= 0 and total > 0", name="amounts_valid"),
                      Index("ix_credit_notes_invoice", "invoice_id"), Index("ix_credit_notes_customer", "customer_id"))

    cn_number: Mapped[str] = mapped_column(String(16), unique=True, nullable=False)
    cn_date: Mapped[date] = mapped_column(Date, nullable=False)
    invoice_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("invoices.id", ondelete="RESTRICT"), nullable=False)
    customer_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("customers.id", ondelete="RESTRICT"), nullable=False)
    reason: Mapped[str] = mapped_column(String(500), nullable=False)
    cancels_invoice: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    taxable: Mapped[Decimal] = _money()
    cgst: Mapped[Decimal] = _money()
    sgst: Mapped[Decimal] = _money()
    igst: Mapped[Decimal] = _money()
    round_off: Mapped[Decimal] = _money()
    total: Mapped[Decimal] = _money()


# ================================================================== customer receipts
class Receipt(AuditColumnsMixin, Base):
    """Money received from a customer. `amount` is what reached the bank; `tds_amount` is the tax the customer
    deducted and paid to the government on our behalf. Whatever is not allocated to invoices is an advance."""

    __tablename__ = "receipts"
    __table_args__ = (CheckConstraint(_in("mode", PAYMENT_MODES), name="mode_valid"),
                      CheckConstraint("status in ('posted','cancelled')", name="status_valid"),
                      CheckConstraint("amount >= 0 and tds_amount >= 0 and amount + tds_amount > 0", name="amount_positive"),
                      CheckConstraint("allocated >= 0 and allocated <= amount + tds_amount", name="allocation_within"),
                      Index("ix_receipts_customer", "customer_id"), Index("ix_receipts_date", "receipt_date"))

    receipt_number: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    receipt_date: Mapped[date] = mapped_column(Date, nullable=False)
    customer_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("customers.id", ondelete="RESTRICT"), nullable=False)
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"))
    sales_order_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("sales_orders.id", ondelete="RESTRICT"))
    mode: Mapped[str] = mapped_column(String(10), nullable=False)
    reference_no: Mapped[str | None] = mapped_column(String(60))
    instrument_date: Mapped[date | None] = mapped_column(Date)
    bank_name: Mapped[str | None] = mapped_column(String(120))
    amount: Mapped[Decimal] = _money()
    tds_amount: Mapped[Decimal] = _money()
    allocated: Mapped[Decimal] = _money()      # money + TDS applied to invoices
    notes: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="posted", server_default="posted")
    status_reason: Mapped[str | None] = mapped_column(String(500))

    allocations: Mapped[list["ReceiptAllocation"]] = relationship(cascade="all, delete-orphan", lazy="selectin",
                                                                  order_by="ReceiptAllocation.created_at")

    @property
    def unallocated(self) -> Decimal:
        return self.amount + self.tds_amount - self.allocated


class ReceiptAllocation(AuditColumnsMixin, Base):
    __tablename__ = "receipt_allocations"
    __table_args__ = (CheckConstraint("amount >= 0 and tds >= 0 and amount + tds > 0", name="positive"),
                      Index("ix_receipt_allocations_invoice", "invoice_id"))

    receipt_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("receipts.id", ondelete="RESTRICT"), nullable=False,
                                                  index=True)
    invoice_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("invoices.id", ondelete="RESTRICT"), nullable=False)
    amount: Mapped[Decimal] = _money()
    tds: Mapped[Decimal] = _money()
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


# ================================================================== supplier invoices and payments
class SupplierInvoice(AuditColumnsMixin, Base):
    """A supplier's bill, matched to its purchase order and what was actually received (3-way match). A bill that
    asks for more than was received, or at a higher rate than ordered, needs approval before it is posted."""

    __tablename__ = "supplier_invoices"
    __table_args__ = (CheckConstraint(_in("status", SUPPLIER_INVOICE_STATUSES), name="status_valid"),
                      CheckConstraint(_in("payment_status", PAYMENT_STATUSES), name="payment_status_valid"),
                      CheckConstraint("paid >= 0 and paid <= grand_total", name="paid_within"),
                      Index("ix_supplier_invoices_supplier", "supplier_id"), Index("ix_supplier_invoices_po", "purchase_order_id"),
                      Index("ix_supplier_invoices_status", "status"),
                      Index("uq_supplier_invoices_supplier_no", "supplier_id", "supplier_invoice_no", unique=True,
                            postgresql_where=text("status <> 'cancelled'")))

    bill_number: Mapped[str | None] = mapped_column(String(30), unique=True)   # ours, at posting
    supplier_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("suppliers.id", ondelete="RESTRICT"), nullable=False)
    supplier_invoice_no: Mapped[str] = mapped_column(String(40), nullable=False)
    supplier_invoice_date: Mapped[date] = mapped_column(Date, nullable=False)
    due_date: Mapped[date | None] = mapped_column(Date)
    purchase_order_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("purchase_orders.id", ondelete="RESTRICT"))
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"))
    account_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("ledger_accounts.id", ondelete="RESTRICT"), nullable=False)
    place_of_supply: Mapped[str | None] = mapped_column(String(2))
    inter_state: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    notes: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="draft", server_default="draft")
    status_reason: Mapped[str | None] = mapped_column(String(500))
    mismatches: Mapped[list] = mapped_column(JSONB, nullable=False, default=list, server_default="[]")
    last_rejection: Mapped[str | None] = mapped_column(String(500))
    posted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    special_discount: Mapped[Decimal] = _money()
    gross: Mapped[Decimal] = _money()
    line_discount: Mapped[Decimal] = _money()
    taxable: Mapped[Decimal] = _money()
    cgst: Mapped[Decimal] = _money()
    sgst: Mapped[Decimal] = _money()
    igst: Mapped[Decimal] = _money()
    round_off: Mapped[Decimal] = _money()
    grand_total: Mapped[Decimal] = _money()
    paid: Mapped[Decimal] = _money()          # payments allocated, including TDS we deducted
    payment_status: Mapped[str] = mapped_column(String(15), nullable=False, default="unpaid", server_default="unpaid")

    items: Mapped[list["SupplierInvoiceItem"]] = relationship(order_by="SupplierInvoiceItem.line_no",
                                                              cascade="all, delete-orphan", lazy="selectin")

    @property
    def balance(self) -> Decimal:
        return self.grand_total - self.paid


class SupplierInvoiceItem(AuditColumnsMixin, LineColumns, Base):
    __tablename__ = "supplier_invoice_items"
    __table_args__ = (Index("ix_supplier_invoice_items_po_item", "po_item_id"),)

    supplier_invoice_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("supplier_invoices.id", ondelete="CASCADE"),
                                                           nullable=False, index=True)
    special_discount: Mapped[Decimal] = _money()
    po_item_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("purchase_order_items.id", ondelete="RESTRICT"))


class SupplierPayment(AuditColumnsMixin, Base):
    __tablename__ = "supplier_payments"
    __table_args__ = (CheckConstraint(_in("mode", PAYMENT_MODES), name="mode_valid"),
                      CheckConstraint("status in ('posted','cancelled')", name="status_valid"),
                      CheckConstraint("amount >= 0 and tds_amount >= 0 and amount + tds_amount > 0", name="amount_positive"),
                      CheckConstraint("allocated >= 0 and allocated <= amount + tds_amount", name="allocation_within"),
                      Index("ix_supplier_payments_supplier", "supplier_id"), Index("ix_supplier_payments_date", "payment_date"))

    payment_number: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    payment_date: Mapped[date] = mapped_column(Date, nullable=False)
    supplier_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("suppliers.id", ondelete="RESTRICT"), nullable=False)
    purchase_order_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("purchase_orders.id", ondelete="RESTRICT"))
    mode: Mapped[str] = mapped_column(String(10), nullable=False)
    reference_no: Mapped[str | None] = mapped_column(String(60))
    bank_name: Mapped[str | None] = mapped_column(String(120))
    amount: Mapped[Decimal] = _money()          # paid out
    tds_amount: Mapped[Decimal] = _money()      # deducted by us, payable to the government
    allocated: Mapped[Decimal] = _money()
    notes: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="posted", server_default="posted")
    status_reason: Mapped[str | None] = mapped_column(String(500))

    allocations: Mapped[list["SupplierPaymentAllocation"]] = relationship(
        cascade="all, delete-orphan", lazy="selectin", order_by="SupplierPaymentAllocation.created_at")

    @property
    def unallocated(self) -> Decimal:
        return self.amount + self.tds_amount - self.allocated


class SupplierPaymentAllocation(AuditColumnsMixin, Base):
    __tablename__ = "supplier_payment_allocations"
    __table_args__ = (CheckConstraint("amount >= 0 and tds >= 0 and amount + tds > 0", name="positive"),
                      Index("ix_supplier_payment_allocations_bill", "supplier_invoice_id"))

    payment_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("supplier_payments.id", ondelete="RESTRICT"),
                                                  nullable=False, index=True)
    supplier_invoice_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("supplier_invoices.id", ondelete="RESTRICT"),
                                                           nullable=False)
    amount: Mapped[Decimal] = _money()
    tds: Mapped[Decimal] = _money()
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


# ================================================================== expenses
class ExpenseCategory(AuditColumnsMixin, Base):
    __tablename__ = "expense_categories"

    name: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    account_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("ledger_accounts.id", ondelete="RESTRICT"), nullable=False)
    needs_project: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    needs_receipt: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class ExpenseClaim(AuditColumnsMixin, Base):
    """Spec §25: Employee → Submit → Manager approval → Accounts → Paid. Approved claims post to the expense ledger
    (and to the project's cost when a project is given); paying them clears the amount owed to the employee."""

    __tablename__ = "expense_claims"
    __table_args__ = (CheckConstraint(_in("status", EXPENSE_STATUSES), name="status_valid"),
                      CheckConstraint("amount > 0", name="amount_positive"),
                      CheckConstraint(f"payment_mode is null or {_in('payment_mode', PAYMENT_MODES)}", name="mode_valid"),
                      Index("ix_expense_claims_employee", "employee_id"), Index("ix_expense_claims_project", "project_id"),
                      Index("ix_expense_claims_status", "status"))

    expense_number: Mapped[str | None] = mapped_column(String(30), unique=True)
    employee_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("employees.id", ondelete="RESTRICT"), nullable=False)
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"))
    category_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("expense_categories.id", ondelete="RESTRICT"), nullable=False)
    expense_date: Mapped[date] = mapped_column(Date, nullable=False)
    amount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False)
    description: Mapped[str] = mapped_column(String(1000), nullable=False)
    bill_reference: Mapped[str | None] = mapped_column(String(60))
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="draft", server_default="draft")
    status_reason: Mapped[str | None] = mapped_column(String(500))
    last_rejection: Mapped[str | None] = mapped_column(String(500))
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    paid_at: Mapped[date | None] = mapped_column(Date)
    payment_mode: Mapped[str | None] = mapped_column(String(10))
    payment_reference: Mapped[str | None] = mapped_column(String(60))
    paid_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))

