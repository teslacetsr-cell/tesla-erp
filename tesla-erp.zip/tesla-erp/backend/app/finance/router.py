import uuid
from datetime import date
from decimal import Decimal
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from sqlalchemy import func, select
from sqlalchemy.orm import object_session

from app.auth.deps import CurrentUser, Principal, require
from app.boq import lines as L
from app.core import excel
from app.core.api import ListParams, ok
from app.core.crud import master_routes
from app.core.db import DbSession
from app.core.errors import AppError, Forbidden, NotFound
from app.crm.service import today
from app.customers.models import Customer
from app.finance import expenses, gl, invoices, payables, pdf, receipts, reports
from app.finance.models import (
    CreditNote,
    ExpenseCategory,
    ExpenseClaim,
    Invoice,
    JournalEntry,
    JournalLine,
    LedgerAccount,
    Receipt,
    SupplierInvoice,
    SupplierPayment,
)
from app.finance.schemas import (
    AllocateIn,
    CreditNoteIn,
    ExpenseCategoryIn,
    ExpenseCategoryUpdate,
    ExpenseIn,
    ExpensePayIn,
    ExpenseUpdate,
    InvoiceIn,
    InvoiceUpdate,
    IrnIn,
    LedgerAccountIn,
    LedgerAccountUpdate,
    ReasonIn,
    ReceiptIn,
    SupplierInvoiceIn,
    SupplierInvoiceUpdate,
    SupplierPaymentIn,
)
from app.hr.models import Employee
from app.hr.service import employee_for_user
from app.platform.approvals import service as approvals
from app.platform.approvals.router import request_out
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.projects.models import Project
from app.purchase.models import PurchaseOrder
from app.sales.models import SalesOrder
from app.suppliers.models import Supplier
from app.users.models import User

router = APIRouter(tags=["finance"])
Z = Decimal("0")

documents.register_entity("invoice", "invoice", Invoice)
documents.register_entity("receipt", "receipt", Receipt)
documents.register_entity("supplier_invoice", "supplier_invoice", SupplierInvoice)
documents.register_entity("supplier_payment", "supplier_payment", SupplierPayment)
documents.register_entity("expense", "expense", ExpenseClaim, check=lambda p, e, action: expenses.check(
    object_session(e), p, e, "read" if action == "read" else "update"))


def _s(v) -> str:
    return str(v) if v is not None else None


def _d(v) -> str | None:
    return v.isoformat() if v else None


def _names(db, model, col, ids) -> dict:
    ids = {i for i in ids if i}
    return dict(db.execute(select(model.id, col).where(model.id.in_(ids))).all()) if ids else {}


def _project_ref(db, pid) -> dict | None:
    if not pid:
        return None
    p = db.get(Project, pid)
    return {"id": str(p.id), "number": p.project_number, "name": p.name} if p else None


def _pdf(data: bytes, name: str) -> Response:
    return Response(data, media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="{name.replace("/", "-")}.pdf"'})


def _xlsx(data: bytes, name: str) -> Response:
    return Response(data, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{name}.xlsx"'})


# ================================================================== sales invoices
def invoice_out(db, p: Principal, inv: Invoice, customers: dict | None = None, detail: bool = False) -> dict:
    customers = customers if customers is not None else _names(db, Customer, Customer.customer_name, [inv.customer_id])
    out = {
        "id": str(inv.id), "invoice_number": inv.invoice_number, "invoice_date": _d(inv.invoice_date),
        "due_date": _d(inv.due_date), "status": inv.status, "payment_status": inv.payment_status,
        "bill_type": inv.bill_type, "ra_bill_no": inv.ra_bill_no, "customer_id": str(inv.customer_id),
        "customer": customers.get(inv.customer_id), "subject": inv.subject,
        "sales_order_id": _s(inv.sales_order_id), "project_id": _s(inv.project_id),
        "taxable": str(inv.taxable), "grand_total": str(inv.grand_total), "received": str(inv.received),
        "credited": str(inv.credited), "balance": str(inv.balance), "retention_amount": str(inv.retention_amount),
        "overdue": inv.status == "issued" and inv.payment_status != "paid" and bool(inv.due_date)
        and inv.due_date < today(),
        "row_version": inv.row_version,
    }
    if not detail:
        return out
    so = db.get(SalesOrder, inv.sales_order_id) if inv.sales_order_id else None
    cns = db.scalars(select(CreditNote).where(CreditNote.invoice_id == inv.id).order_by(CreditNote.cn_date)).all()
    issue = p.can("invoice_post.approve")
    out |= {
        "site_id": _s(inv.site_id), "customer_po_number": inv.customer_po_number,
        "customer_po_date": _d(inv.customer_po_date), "place_of_supply": inv.place_of_supply,
        "inter_state": inv.inter_state, "reverse_charge": inv.reverse_charge, "payment_terms": inv.payment_terms,
        "notes": inv.notes, "status_reason": inv.status_reason, "retention_pct": f"{inv.retention_pct.normalize():f}",
        "tds": str(inv.tds), "special_discount": str(inv.special_discount),
        **{k: str(getattr(inv, k)) for k in invoices.TOTALS},
        "items": [{**L.line_out(it), "so_item_id": _s(it.so_item_id)} for it in inv.items],
        "sales_order": {"id": str(so.id), "so_number": so.so_number} if so else None,
        "project": _project_ref(db, inv.project_id),
        "customer_snapshot": inv.customer_snapshot, "irn": inv.irn, "irn_ack_no": inv.irn_ack_no,
        "irn_ack_date": _d(inv.irn_ack_date), "issued_at": _d(inv.issued_at),
        "receipts": reports.receipts_for_invoice(db, inv.id),
        "credit_notes": [{"id": str(c.id), "cn_number": c.cn_number, "cn_date": _d(c.cn_date), "reason": c.reason,
                          "taxable": str(c.taxable), "total": str(c.total), "cancels_invoice": c.cancels_invoice}
                         for c in cns],
        "created_by": db.scalar(select(User.full_name).where(User.id == inv.created_by)) if inv.created_by else None,
        "can": {
            "edit": p.can("invoice.update") and inv.status == "draft",
            "delete": p.can("invoice.delete") and inv.status == "draft",
            "issue": issue and inv.status == "draft",
            "credit_note": issue and inv.status == "issued" and inv.credited < inv.grand_total,
            "cancel": issue and inv.status == "issued" and inv.received == 0,
            "receipt": p.can("receipt.create") and inv.status == "issued" and inv.balance > 0,
            "irn": p.can("invoice.update") and inv.status == "issued",
            "print": p.can("invoice.print"),
        },
    }
    return out


def _inv_filters(status: str | None = Query(None), customer_id: uuid.UUID | None = None,
                 project_id: uuid.UUID | None = None, sales_order_id: uuid.UUID | None = None,
                 payment_status: str | None = None, outstanding: bool = False, overdue: bool = False):
    return {"status": status, "customer_id": customer_id, "project_id": project_id, "sales_order_id": sales_order_id,
            "payment_status": payment_status, "outstanding": outstanding, "overdue": overdue}


@router.get("/invoices")
def list_invoices(db: DbSession, p: Annotated[Principal, require("invoice.read")],
                  params: Annotated[ListParams, Depends()], f: Annotated[dict, Depends(_inv_filters)]):
    rows, meta = invoices.list_invoices(db, params, **f)
    cust = _names(db, Customer, Customer.customer_name, [r.customer_id for r in rows])
    return {"data": [invoice_out(db, p, r, cust) for r in rows], "meta": meta.model_dump()}


INVOICE_COLUMNS = [
    excel.Column("invoice_number", "Invoice no.", 18), excel.Column("invoice_date", "Date", 12),
    excel.Column("customer", "Customer", 32), excel.Column("gstin", "GSTIN", 17),
    excel.Column("place_of_supply", "POS", 6), excel.Column("taxable", "Taxable (₹)", 15),
    excel.Column("cgst", "CGST (₹)", 12), excel.Column("sgst", "SGST (₹)", 12), excel.Column("igst", "IGST (₹)", 12),
    excel.Column("grand_total", "Total (₹)", 15), excel.Column("received", "Received (₹)", 15),
    excel.Column("credited", "Credited (₹)", 13), excel.Column("balance", "Balance (₹)", 15),
    excel.Column("due_date", "Due", 12), excel.Column("status", "Status", 11),
]


@router.get("/invoices/export")
def export_invoices(db: DbSession, p: Annotated[Principal, require("invoice.export")],
                    params: Annotated[ListParams, Depends()], f: Annotated[dict, Depends(_inv_filters)]):
    params.page, params.page_size = 1, 10000
    rows, _ = invoices.list_invoices(db, params, **f)
    cust = {c.id: c for c in db.scalars(select(Customer).where(Customer.id.in_({r.customer_id for r in rows})))} \
        if rows else {}
    data = [{"invoice_number": r.invoice_number or "(draft)", "invoice_date": r.invoice_date,
             "customer": cust[r.customer_id].customer_name, "gstin": cust[r.customer_id].gstin,
             "place_of_supply": r.place_of_supply, "taxable": r.taxable, "cgst": r.cgst, "sgst": r.sgst,
             "igst": r.igst, "grand_total": r.grand_total, "received": r.received, "credited": r.credited,
             "balance": r.balance if r.status == "issued" else Z, "due_date": r.due_date, "status": r.status}
            for r in rows]
    audit.record(db, action="export", entity_type="invoice", summary=f"Exported {len(data)} invoices")
    return _xlsx(excel.export("Sales register", INVOICE_COLUMNS, data), f"sales-register-{today()}")


@router.get("/sales-orders/{so_id}/billable")
def so_billable(so_id: uuid.UUID, db: DbSession, _: Annotated[Principal, require("invoice.create")]):
    so = db.get(SalesOrder, so_id)
    if so is None:
        raise NotFound("sales_order")
    prj = db.scalar(select(Project).where(Project.sales_order_id == so.id, Project.status != "cancelled"))
    cust = db.get(Customer, so.customer_id)
    return ok({"sales_order": {"id": str(so.id), "so_number": so.so_number, "subject": so.subject,
                               "status": so.status, "customer_po_number": so.customer_po_number,
                               "customer_po_date": _d(so.customer_po_date), "special_discount": str(so.special_discount),
                               "payment_terms": so.payment_terms, "inter_state": so.inter_state,
                               "place_of_supply": so.place_of_supply, "site_id": _s(so.site_id)},
               "customer": {"id": str(cust.id), "name": cust.customer_name, "code": cust.customer_code,
                            "city": cust.city},
               "project": _project_ref(db, prj.id) if prj else None,
               "lines": invoices.billable_lines(db, so)})


@router.post("/invoices", status_code=201)
def create_invoice(body: InvoiceIn, db: DbSession, p: Annotated[Principal, require("invoice.create")]):
    return ok(invoice_out(db, p, invoices.create(db, p, body), detail=True))


@router.get("/invoices/{invoice_id}")
def get_invoice(invoice_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("invoice.read")]):
    return ok(invoice_out(db, p, invoices.get(db, invoice_id), detail=True))


@router.put("/invoices/{invoice_id}")
def update_invoice(invoice_id: uuid.UUID, body: InvoiceUpdate, db: DbSession,
                   p: Annotated[Principal, require("invoice.update")]):
    return ok(invoice_out(db, p, invoices.update(db, p, invoice_id, body), detail=True))


@router.delete("/invoices/{invoice_id}", status_code=204)
def delete_invoice(invoice_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("invoice.delete")]):
    invoices.delete(db, p, invoice_id)


@router.post("/invoices/{invoice_id}/issue")
def issue_invoice(invoice_id: uuid.UUID, body: ReasonIn, db: DbSession,
                  p: Annotated[Principal, require("invoice_post.approve")]):
    return ok(invoice_out(db, p, invoices.issue(db, p, invoice_id, body.row_version), detail=True))


@router.post("/invoices/{invoice_id}/irn")
def invoice_irn(invoice_id: uuid.UUID, body: IrnIn, db: DbSession, p: Annotated[Principal, require("invoice.update")]):
    return ok(invoice_out(db, p, invoices.set_irn(db, p, invoice_id, body), detail=True))


@router.post("/invoices/{invoice_id}/credit-notes", status_code=201)
def create_credit_note(invoice_id: uuid.UUID, body: CreditNoteIn, db: DbSession,
                       p: Annotated[Principal, require("invoice_post.approve")]):
    cn = invoices.credit_note(db, p, invoice_id, body)
    return ok({"id": str(cn.id), "cn_number": cn.cn_number,
               "invoice": invoice_out(db, p, invoices.get(db, invoice_id), detail=True)})


@router.get("/invoices/{invoice_id}/pdf")
def invoice_pdf(invoice_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("invoice.print")]):
    inv = invoices.get(db, invoice_id)
    audit.record(db, action="print", entity_type="invoice", entity_id=inv.id, entity_label=invoices.label(inv))
    return _pdf(pdf.invoice(db, inv), inv.invoice_number or "draft-invoice")


@router.get("/credit-notes")
def list_credit_notes(db: DbSession, _: Annotated[Principal, require("invoice.read")],
                      params: Annotated[ListParams, Depends()], customer_id: uuid.UUID | None = None):
    from app.core.api import paginate

    stmt = select(CreditNote)
    if customer_id:
        stmt = stmt.where(CreditNote.customer_id == customer_id)
    if params.q:
        stmt = stmt.where(CreditNote.cn_number.ilike(f"%{params.q}%"))
    rows, meta = paginate(db, stmt, params, default_sort=CreditNote.created_at.desc(),
                          sortable={"cn_date": CreditNote.cn_date, "total": CreditNote.total})
    cust = _names(db, Customer, Customer.customer_name, [r.customer_id for r in rows])
    invs = _names(db, Invoice, Invoice.invoice_number, [r.invoice_id for r in rows])
    return {"data": [{"id": str(c.id), "cn_number": c.cn_number, "cn_date": _d(c.cn_date), "reason": c.reason,
                      "customer": cust.get(c.customer_id), "invoice_id": str(c.invoice_id),
                      "invoice_number": invs.get(c.invoice_id), "taxable": str(c.taxable), "total": str(c.total),
                      "cancels_invoice": c.cancels_invoice} for c in rows], "meta": meta.model_dump()}


@router.get("/credit-notes/{cn_id}/pdf")
def credit_note_pdf(cn_id: uuid.UUID, db: DbSession, _: Annotated[Principal, require("invoice.print")]):
    cn = db.get(CreditNote, cn_id)
    if cn is None:
        raise NotFound("credit_note")
    return _pdf(pdf.credit_note(db, cn, db.get(Invoice, cn.invoice_id)), cn.cn_number)


# ================================================================== receipts
def receipt_out(db, p: Principal, r: Receipt, customers: dict | None = None, detail: bool = False) -> dict:
    customers = customers if customers is not None else _names(db, Customer, Customer.customer_name, [r.customer_id])
    out = {"id": str(r.id), "receipt_number": r.receipt_number, "receipt_date": _d(r.receipt_date),
           "customer_id": str(r.customer_id), "customer": customers.get(r.customer_id), "mode": r.mode,
           "reference_no": r.reference_no, "amount": str(r.amount), "tds_amount": str(r.tds_amount),
           "allocated": str(r.allocated), "unallocated": str(r.unallocated), "status": r.status,
           "row_version": r.row_version}
    if not detail:
        return out
    active = [a for a in r.allocations if a.is_active]
    nums = _names(db, Invoice, Invoice.invoice_number, [a.invoice_id for a in r.allocations])
    out |= {"instrument_date": _d(r.instrument_date), "bank_name": r.bank_name, "notes": r.notes,
            "status_reason": r.status_reason, "project": _project_ref(db, r.project_id),
            "allocations": [{"id": str(a.id), "invoice_id": str(a.invoice_id), "invoice_number": nums.get(a.invoice_id),
                             "amount": str(a.amount), "tds": str(a.tds), "is_active": a.is_active,
                             "created_at": a.created_at.isoformat()} for a in r.allocations],
            "can": {"allocate": p.can("receipt.update") and r.status == "posted" and r.unallocated > 0,
                    "unallocate": p.can("receipt.update") and r.status == "posted" and bool(active),
                    "cancel": p.can("receipt.delete") and r.status == "posted", "print": p.can("receipt.print")}}
    return out


@router.get("/receipts")
def list_receipts(db: DbSession, p: Annotated[Principal, require("receipt.read")],
                  params: Annotated[ListParams, Depends()], customer_id: uuid.UUID | None = None,
                  project_id: uuid.UUID | None = None, status: str | None = None, unallocated: bool = False,
                  date_from: date | None = None, date_to: date | None = None):
    rows, meta = receipts.list_receipts(db, params, customer_id=customer_id, project_id=project_id, status=status,
                                        unallocated=unallocated, date_from=date_from, date_to=date_to)
    cust = _names(db, Customer, Customer.customer_name, [r.customer_id for r in rows])
    return {"data": [receipt_out(db, p, r, cust) for r in rows], "meta": meta.model_dump()}


RECEIPT_COLUMNS = [
    excel.Column("receipt_number", "Receipt no.", 22), excel.Column("receipt_date", "Date", 12),
    excel.Column("customer", "Customer", 32), excel.Column("mode", "Mode", 8),
    excel.Column("reference_no", "Reference", 18), excel.Column("amount", "Amount (₹)", 15),
    excel.Column("tds_amount", "TDS (₹)", 12), excel.Column("allocated", "Allocated (₹)", 15),
    excel.Column("unallocated", "On account (₹)", 15), excel.Column("status", "Status", 10),
]


@router.get("/receipts/export")
def export_receipts(db: DbSession, p: Annotated[Principal, require("receipt.export")],
                    params: Annotated[ListParams, Depends()], customer_id: uuid.UUID | None = None,
                    date_from: date | None = None, date_to: date | None = None):
    params.page, params.page_size = 1, 10000
    rows, _ = receipts.list_receipts(db, params, customer_id=customer_id, date_from=date_from, date_to=date_to)
    cust = _names(db, Customer, Customer.customer_name, [r.customer_id for r in rows])
    data = [{"receipt_number": r.receipt_number, "receipt_date": r.receipt_date, "customer": cust.get(r.customer_id),
             "mode": r.mode.upper(), "reference_no": r.reference_no, "amount": r.amount, "tds_amount": r.tds_amount,
             "allocated": r.allocated, "unallocated": r.unallocated, "status": r.status} for r in rows]
    audit.record(db, action="export", entity_type="receipt", summary=f"Exported {len(data)} receipts")
    return _xlsx(excel.export("Collections", RECEIPT_COLUMNS, data), f"collections-{today()}")


@router.post("/receipts", status_code=201)
def create_receipt(body: ReceiptIn, db: DbSession, p: Annotated[Principal, require("receipt.create")]):
    return ok(receipt_out(db, p, receipts.create(db, p, body), detail=True))


@router.get("/receipts/{receipt_id}")
def get_receipt(receipt_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("receipt.read")]):
    return ok(receipt_out(db, p, receipts.get(db, receipt_id), detail=True))


@router.post("/receipts/{receipt_id}/allocate")
def allocate_receipt(receipt_id: uuid.UUID, body: AllocateIn, db: DbSession,
                     p: Annotated[Principal, require("receipt.update")]):
    return ok(receipt_out(db, p, receipts.allocate(db, p, receipt_id, body), detail=True))


@router.post("/receipts/{receipt_id}/allocations/{allocation_id}/remove")
def unallocate_receipt(receipt_id: uuid.UUID, allocation_id: uuid.UUID, db: DbSession,
                       p: Annotated[Principal, require("receipt.update")]):
    return ok(receipt_out(db, p, receipts.unallocate(db, p, receipt_id, allocation_id), detail=True))


@router.post("/receipts/{receipt_id}/cancel")
def cancel_receipt(receipt_id: uuid.UUID, body: ReasonIn, db: DbSession,
                   p: Annotated[Principal, require("receipt.delete")]):
    return ok(receipt_out(db, p, receipts.cancel(db, p, receipt_id, body.reason, body.row_version), detail=True))


@router.get("/receipts/{receipt_id}/pdf")
def receipt_pdf(receipt_id: uuid.UUID, db: DbSession, _: Annotated[Principal, require("receipt.print")]):
    r = receipts.get(db, receipt_id)
    nums = _names(db, Invoice, Invoice.invoice_number, [a.invoice_id for a in r.allocations])
    allocs = [(nums.get(a.invoice_id) or "", a.amount, a.tds) for a in r.allocations if a.is_active]
    return _pdf(pdf.receipt(db, r, db.get(Customer, r.customer_id), allocs), r.receipt_number)


# ================================================================== supplier invoices
def bill_out(db, p: Principal, b: SupplierInvoice, suppliers: dict | None = None, detail: bool = False) -> dict:
    suppliers = suppliers if suppliers is not None else _names(db, Supplier, Supplier.supplier_name, [b.supplier_id])
    out = {"id": str(b.id), "bill_number": b.bill_number, "supplier_invoice_no": b.supplier_invoice_no,
           "supplier_invoice_date": _d(b.supplier_invoice_date), "due_date": _d(b.due_date),
           "supplier_id": str(b.supplier_id), "supplier": suppliers.get(b.supplier_id), "status": b.status,
           "payment_status": b.payment_status, "purchase_order_id": _s(b.purchase_order_id),
           "taxable": str(b.taxable), "grand_total": str(b.grand_total), "paid": str(b.paid), "balance": str(b.balance),
           "mismatch": bool(b.mismatches),
           "overdue": b.status == "posted" and b.payment_status != "paid" and bool(b.due_date) and b.due_date < today(),
           "row_version": b.row_version}
    if not detail:
        return out
    po = db.get(PurchaseOrder, b.purchase_order_id) if b.purchase_order_id else None
    acc = db.get(LedgerAccount, b.account_id)
    pending = approvals.pending_for(db, "supplier_invoice", b.id)
    from app.finance.models import SupplierPaymentAllocation

    pays = db.execute(select(SupplierPayment.id, SupplierPayment.payment_number, SupplierPayment.payment_date,
                             SupplierPaymentAllocation.amount, SupplierPaymentAllocation.tds)
                      .join(SupplierPayment, SupplierPayment.id == SupplierPaymentAllocation.payment_id)
                      .where(SupplierPaymentAllocation.supplier_invoice_id == b.id,
                             SupplierPaymentAllocation.is_active.is_(True))).all()
    out |= {"notes": b.notes, "status_reason": b.status_reason, "last_rejection": b.last_rejection,
            "place_of_supply": b.place_of_supply, "inter_state": b.inter_state, "mismatches": b.mismatches,
            "special_discount": str(b.special_discount), **{k: str(getattr(b, k)) for k in payables.TOTALS},
            "account": {"id": str(acc.id), "name": acc.name} if acc else None,
            "purchase_order": {"id": str(po.id), "po_number": po.po_number} if po else None,
            "project": _project_ref(db, b.project_id),
            "items": [{**L.line_out(it), "po_item_id": _s(it.po_item_id)} for it in b.items],
            "payments": [{"id": str(i), "payment_number": n, "payment_date": _d(d), "amount": str(a), "tds": str(t)}
                         for i, n, d, a, t in pays],
            "approval": request_out(db, p, pending) if pending else None,
            "approvals": [request_out(db, p, r) for r in approvals.history(db, "supplier_invoice", b.id)],
            "can": {"edit": p.can("supplier_invoice.update") and b.status == "draft",
                    "delete": p.can("supplier_invoice.delete") and b.status == "draft" and not b.bill_number,
                    "submit": p.can("supplier_invoice.update") and b.status == "draft",
                    "cancel": p.can("supplier_invoice.delete") and b.status in ("pending_approval", "posted")
                    and b.paid == 0,
                    "pay": p.can("supplier_payment.create") and b.status == "posted" and b.balance > 0,
                    "decide": bool(pending and approvals.can_decide(p, pending))}}
    return out


def _bill_filters(status: str | None = Query(None), supplier_id: uuid.UUID | None = None,
                  purchase_order_id: uuid.UUID | None = None, project_id: uuid.UUID | None = None,
                  outstanding: bool = False, overdue: bool = False):
    return {"status": status, "supplier_id": supplier_id, "purchase_order_id": purchase_order_id,
            "project_id": project_id, "outstanding": outstanding, "overdue": overdue}


@router.get("/supplier-invoices")
def list_bills(db: DbSession, p: Annotated[Principal, require("supplier_invoice.read")],
               params: Annotated[ListParams, Depends()], f: Annotated[dict, Depends(_bill_filters)]):
    rows, meta = payables.list_bills(db, params, **f)
    sup = _names(db, Supplier, Supplier.supplier_name, [r.supplier_id for r in rows])
    return {"data": [bill_out(db, p, r, sup) for r in rows], "meta": meta.model_dump()}


BILL_COLUMNS = [
    excel.Column("bill_number", "Bill no.", 20), excel.Column("supplier", "Supplier", 30),
    excel.Column("gstin", "GSTIN", 17), excel.Column("supplier_invoice_no", "Supplier invoice", 18),
    excel.Column("supplier_invoice_date", "Invoice date", 12), excel.Column("taxable", "Taxable (₹)", 15),
    excel.Column("cgst", "CGST (₹)", 12), excel.Column("sgst", "SGST (₹)", 12), excel.Column("igst", "IGST (₹)", 12),
    excel.Column("grand_total", "Total (₹)", 15), excel.Column("paid", "Paid (₹)", 15),
    excel.Column("balance", "Balance (₹)", 15), excel.Column("due_date", "Due", 12), excel.Column("status", "Status", 14),
]


@router.get("/supplier-invoices/export")
def export_bills(db: DbSession, p: Annotated[Principal, require("supplier_invoice.export")],
                 params: Annotated[ListParams, Depends()], f: Annotated[dict, Depends(_bill_filters)]):
    params.page, params.page_size = 1, 10000
    rows, _ = payables.list_bills(db, params, **f)
    sups = {s.id: s for s in db.scalars(select(Supplier).where(Supplier.id.in_({r.supplier_id for r in rows})))} \
        if rows else {}
    data = [{"bill_number": r.bill_number or "(draft)", "supplier": sups[r.supplier_id].supplier_name,
             "gstin": sups[r.supplier_id].gstin, "supplier_invoice_no": r.supplier_invoice_no,
             "supplier_invoice_date": r.supplier_invoice_date, "taxable": r.taxable, "cgst": r.cgst, "sgst": r.sgst,
             "igst": r.igst, "grand_total": r.grand_total, "paid": r.paid, "balance": r.balance,
             "due_date": r.due_date, "status": r.status} for r in rows]
    audit.record(db, action="export", entity_type="supplier_invoice", summary=f"Exported {len(data)} bills")
    return _xlsx(excel.export("Purchase register", BILL_COLUMNS, data), f"purchase-register-{today()}")


@router.get("/purchase-orders/{po_id}/billable")
def po_billable(po_id: uuid.UUID, db: DbSession, _: Annotated[Principal, require("supplier_invoice.create")]):
    po = db.get(PurchaseOrder, po_id)
    if po is None:
        raise NotFound("purchase_order")
    sup = db.get(Supplier, po.supplier_id)
    return ok({"purchase_order": {"id": str(po.id), "po_number": po.po_number, "status": po.status,
                                  "project_id": _s(po.project_id), "special_discount": str(po.special_discount)},
               "supplier": {"id": str(sup.id), "name": sup.supplier_name, "code": sup.supplier_code},
               "lines": payables.po_billable_lines(db, po)})


@router.post("/supplier-invoices", status_code=201)
def create_bill(body: SupplierInvoiceIn, db: DbSession, p: Annotated[Principal, require("supplier_invoice.create")]):
    return ok(bill_out(db, p, payables.create_bill(db, p, body), detail=True))


@router.get("/supplier-invoices/{bill_id}")
def get_bill(bill_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("supplier_invoice.read")]):
    return ok(bill_out(db, p, payables.get_bill(db, bill_id), detail=True))


@router.put("/supplier-invoices/{bill_id}")
def update_bill(bill_id: uuid.UUID, body: SupplierInvoiceUpdate, db: DbSession,
                p: Annotated[Principal, require("supplier_invoice.update")]):
    return ok(bill_out(db, p, payables.update_bill(db, p, bill_id, body), detail=True))


@router.delete("/supplier-invoices/{bill_id}", status_code=204)
def delete_bill(bill_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("supplier_invoice.delete")]):
    payables.delete_bill(db, p, bill_id)


@router.post("/supplier-invoices/{bill_id}/submit")
def submit_bill(bill_id: uuid.UUID, body: ReasonIn, db: DbSession,
                p: Annotated[Principal, require("supplier_invoice.update")]):
    return ok(bill_out(db, p, payables.submit_bill(db, p, bill_id, body.row_version), detail=True))


@router.post("/supplier-invoices/{bill_id}/cancel")
def cancel_bill(bill_id: uuid.UUID, body: ReasonIn, db: DbSession,
                p: Annotated[Principal, require("supplier_invoice.delete")]):
    return ok(bill_out(db, p, payables.cancel_bill(db, p, bill_id, body.reason, body.row_version), detail=True))


# ================================================================== supplier payments
def payment_out(db, p: Principal, pay: SupplierPayment, suppliers: dict | None = None, detail: bool = False) -> dict:
    suppliers = suppliers if suppliers is not None else _names(db, Supplier, Supplier.supplier_name, [pay.supplier_id])
    out = {"id": str(pay.id), "payment_number": pay.payment_number, "payment_date": _d(pay.payment_date),
           "supplier_id": str(pay.supplier_id), "supplier": suppliers.get(pay.supplier_id), "mode": pay.mode,
           "reference_no": pay.reference_no, "amount": str(pay.amount), "tds_amount": str(pay.tds_amount),
           "allocated": str(pay.allocated), "unallocated": str(pay.unallocated), "status": pay.status,
           "row_version": pay.row_version}
    if not detail:
        return out
    labels = {b.id: payables.bill_label(b) for b in db.scalars(select(SupplierInvoice).where(
        SupplierInvoice.id.in_({a.supplier_invoice_id for a in pay.allocations})))} if pay.allocations else {}
    sup_inv = _names(db, SupplierInvoice, SupplierInvoice.supplier_invoice_no,
                     [a.supplier_invoice_id for a in pay.allocations])
    active = [a for a in pay.allocations if a.is_active]
    out |= {"bank_name": pay.bank_name, "notes": pay.notes, "status_reason": pay.status_reason,
            "allocations": [{"id": str(a.id), "supplier_invoice_id": str(a.supplier_invoice_id),
                             "bill_number": labels.get(a.supplier_invoice_id),
                             "supplier_invoice_no": sup_inv.get(a.supplier_invoice_id), "amount": str(a.amount),
                             "tds": str(a.tds), "is_active": a.is_active} for a in pay.allocations],
            "can": {"allocate": p.can("supplier_payment.update") and pay.status == "posted" and pay.unallocated > 0,
                    "unallocate": p.can("supplier_payment.update") and pay.status == "posted" and bool(active),
                    "cancel": p.can("supplier_payment.delete") and pay.status == "posted"}}
    return out


@router.get("/supplier-payments")
def list_payments(db: DbSession, p: Annotated[Principal, require("supplier_payment.read")],
                  params: Annotated[ListParams, Depends()], supplier_id: uuid.UUID | None = None,
                  status: str | None = None, date_from: date | None = None, date_to: date | None = None):
    rows, meta = payables.list_payments(db, params, supplier_id=supplier_id, status=status, date_from=date_from,
                                        date_to=date_to)
    sup = _names(db, Supplier, Supplier.supplier_name, [r.supplier_id for r in rows])
    return {"data": [payment_out(db, p, r, sup) for r in rows], "meta": meta.model_dump()}


PAYMENT_COLUMNS = [
    excel.Column("payment_number", "Payment no.", 22), excel.Column("payment_date", "Date", 12),
    excel.Column("supplier", "Supplier", 32), excel.Column("mode", "Mode", 8),
    excel.Column("reference_no", "Reference", 18), excel.Column("amount", "Paid (₹)", 15),
    excel.Column("tds_amount", "TDS (₹)", 12), excel.Column("unallocated", "Advance (₹)", 15),
    excel.Column("status", "Status", 10),
]


@router.get("/supplier-payments/export")
def export_payments(db: DbSession, p: Annotated[Principal, require("supplier_payment.export")],
                    params: Annotated[ListParams, Depends()], supplier_id: uuid.UUID | None = None,
                    date_from: date | None = None, date_to: date | None = None):
    params.page, params.page_size = 1, 10000
    rows, _ = payables.list_payments(db, params, supplier_id=supplier_id, date_from=date_from, date_to=date_to)
    sup = _names(db, Supplier, Supplier.supplier_name, [r.supplier_id for r in rows])
    data = [{"payment_number": r.payment_number, "payment_date": r.payment_date, "supplier": sup.get(r.supplier_id),
             "mode": r.mode.upper(), "reference_no": r.reference_no, "amount": r.amount, "tds_amount": r.tds_amount,
             "unallocated": r.unallocated, "status": r.status} for r in rows]
    audit.record(db, action="export", entity_type="supplier_payment", summary=f"Exported {len(data)} payments")
    return _xlsx(excel.export("Supplier payments", PAYMENT_COLUMNS, data), f"supplier-payments-{today()}")


@router.post("/supplier-payments", status_code=201)
def create_payment(body: SupplierPaymentIn, db: DbSession, p: Annotated[Principal, require("supplier_payment.create")]):
    return ok(payment_out(db, p, payables.create_payment(db, p, body), detail=True))


@router.get("/supplier-payments/{pid}")
def get_payment(pid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("supplier_payment.read")]):
    return ok(payment_out(db, p, payables.get_payment(db, pid), detail=True))


@router.post("/supplier-payments/{pid}/allocate")
def allocate_payment(pid: uuid.UUID, body: AllocateIn, db: DbSession,
                     p: Annotated[Principal, require("supplier_payment.update")]):
    return ok(payment_out(db, p, payables.allocate_payment(db, p, pid, body), detail=True))


@router.post("/supplier-payments/{pid}/allocations/{allocation_id}/remove")
def unallocate_payment(pid: uuid.UUID, allocation_id: uuid.UUID, db: DbSession,
                       p: Annotated[Principal, require("supplier_payment.update")]):
    return ok(payment_out(db, p, payables.unallocate_payment(db, p, pid, allocation_id), detail=True))


@router.post("/supplier-payments/{pid}/cancel")
def cancel_payment(pid: uuid.UUID, body: ReasonIn, db: DbSession,
                   p: Annotated[Principal, require("supplier_payment.delete")]):
    return ok(payment_out(db, p, payables.cancel_payment(db, p, pid, body.reason, body.row_version), detail=True))


# ================================================================== expenses
def expense_out(db, p: Principal, e: ExpenseClaim, refs: dict | None = None, detail: bool = False) -> dict:
    refs = refs or _expense_refs(db, [e])
    cat = refs["cats"].get(e.category_id)
    out = {"id": str(e.id), "expense_number": e.expense_number, "expense_date": _d(e.expense_date),
           "employee_id": str(e.employee_id), "employee": refs["emps"].get(e.employee_id),
           "category_id": str(e.category_id), "category": cat, "project_id": _s(e.project_id),
           "project": refs["prjs"].get(e.project_id), "amount": str(e.amount), "description": e.description,
           "status": e.status, "row_version": e.row_version}
    if not detail:
        return out
    pending = approvals.pending_for(db, "expense", e.id)
    upd = expenses.allowed(db, p, e, "update")
    c = db.get(ExpenseCategory, e.category_id)
    out |= {"bill_reference": e.bill_reference, "status_reason": e.status_reason, "last_rejection": e.last_rejection,
            "submitted_at": _d(e.submitted_at), "approved_at": _d(e.approved_at), "paid_at": _d(e.paid_at),
            "payment_mode": e.payment_mode, "payment_reference": e.payment_reference,
            "paid_by": db.scalar(select(User.full_name).where(User.id == e.paid_by)) if e.paid_by else None,
            "needs_receipt": c.needs_receipt, "has_receipt": expenses.has_receipt(db, e.id),
            "approval": request_out(db, p, pending) if pending else None,
            "approvals": [request_out(db, p, r) for r in approvals.history(db, "expense", e.id)],
            "can": {"edit": upd and e.status == "draft", "submit": upd and e.status == "draft",
                    "delete": expenses.allowed(db, p, e, "delete") and e.status == "draft" and not e.expense_number,
                    "withdraw": upd and e.status == "submitted",
                    "pay": p.can("expense_payment.create") and e.status == "approved",
                    "cancel": (upd and e.status in ("draft", "submitted"))
                    or (p.can("expense_payment.create") and e.status == "approved"),
                    "decide": bool(pending and approvals.can_decide(p, pending)),
                    "attach": upd and e.status in ("draft", "submitted")}}
    return out


def _expense_refs(db, rows) -> dict:
    return {"emps": _names(db, Employee, Employee.full_name, [r.employee_id for r in rows]),
            "cats": _names(db, ExpenseCategory, ExpenseCategory.name, [r.category_id for r in rows]),
            "prjs": _names(db, Project, Project.project_number, [r.project_id for r in rows])}


def _exp_filters(status: str | None = Query(None), employee_id: uuid.UUID | None = None,
                 project_id: uuid.UUID | None = None, category_id: uuid.UUID | None = None,
                 date_from: date | None = None, date_to: date | None = None, mine: bool = False):
    return {"status": status, "employee_id": employee_id, "project_id": project_id, "category_id": category_id,
            "date_from": date_from, "date_to": date_to, "mine": mine}


@router.get("/expenses")
def list_expenses(db: DbSession, p: Annotated[Principal, require("expense.read")],
                  params: Annotated[ListParams, Depends()], f: Annotated[dict, Depends(_exp_filters)]):
    rows, meta = expenses.list_expenses(db, p, params, **f)
    refs = _expense_refs(db, rows)
    return {"data": [expense_out(db, p, r, refs) for r in rows], "meta": meta.model_dump()}


EXPENSE_COLUMNS = [
    excel.Column("expense_number", "Claim no.", 22), excel.Column("expense_date", "Date", 12),
    excel.Column("employee", "Employee", 24), excel.Column("category", "Category", 22),
    excel.Column("project", "Project", 20), excel.Column("description", "Description", 40),
    excel.Column("amount", "Amount (₹)", 14), excel.Column("status", "Status", 10),
    excel.Column("paid_at", "Paid on", 12),
]


@router.get("/expenses/export")
def export_expenses(db: DbSession, p: Annotated[Principal, require("expense.export")],
                    params: Annotated[ListParams, Depends()], f: Annotated[dict, Depends(_exp_filters)]):
    params.page, params.page_size = 1, 10000
    rows, _ = expenses.list_expenses(db, p, params, **f)
    refs = _expense_refs(db, rows)
    data = [{"expense_number": r.expense_number or "(draft)", "expense_date": r.expense_date,
             "employee": refs["emps"].get(r.employee_id), "category": refs["cats"].get(r.category_id),
             "project": refs["prjs"].get(r.project_id), "description": r.description, "amount": r.amount,
             "status": r.status, "paid_at": r.paid_at} for r in rows]
    audit.record(db, action="export", entity_type="expense", summary=f"Exported {len(data)} expense claims")
    return _xlsx(excel.export("Expense report", EXPENSE_COLUMNS, data), f"expenses-{today()}")


@router.get("/expenses/options")
def expense_options(db: DbSession, p: Annotated[Principal, require("expense.create")]):
    """What the claim form needs: active categories, the user's own employee record, and (for Accounts / managers
    who may claim for others) the employee list."""
    cats = db.scalars(select(ExpenseCategory).where(ExpenseCategory.is_active.is_(True)).order_by(ExpenseCategory.name))
    me = employee_for_user(db, p.id)
    others = []
    if p.scope("expense.update") == "all":
        others = [{"id": str(i), "name": n, "code": c} for i, n, c in db.execute(
            select(Employee.id, Employee.full_name, Employee.employee_code).where(Employee.is_active.is_(True))
            .order_by(Employee.full_name)).all()]
    return ok({"categories": [{"id": str(c.id), "name": c.name, "needs_project": c.needs_project,
                               "needs_receipt": c.needs_receipt} for c in cats],
               "me": {"id": str(me.id), "name": me.full_name, "code": me.employee_code} if me else None,
               "employees": others})


@router.get("/expenses/summary")
def expense_summary(db: DbSession, p: Annotated[Principal, require("expense.read")]):
    stmt = select(ExpenseClaim.status, func.count(), func.coalesce(func.sum(ExpenseClaim.amount), 0)).group_by(
        ExpenseClaim.status)
    if p.scope("expense.read") == "own":
        me = employee_for_user(db, p.id)
        stmt = stmt.where((ExpenseClaim.employee_id == (me.id if me else None)) | (ExpenseClaim.created_by == p.id))
    return ok({s: {"count": n, "amount": str(a)} for s, n, a in db.execute(stmt).all()})


@router.post("/expenses", status_code=201)
def create_expense(body: ExpenseIn, db: DbSession, p: Annotated[Principal, require("expense.create")]):
    return ok(expense_out(db, p, expenses.create(db, p, body), detail=True))


@router.get("/expenses/{eid}")
def get_expense(eid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("expense.read")]):
    e = expenses.get(db, eid)
    if not (expenses.allowed(db, p, e, "read") or approvals.pending_for(db, "expense", e.id) is not None
            and approvals.can_decide(p, approvals.pending_for(db, "expense", e.id))):
        raise Forbidden("You can only see your own expense claims.", code="OUT_OF_SCOPE")
    return ok(expense_out(db, p, e, detail=True))


@router.put("/expenses/{eid}")
def update_expense(eid: uuid.UUID, body: ExpenseUpdate, db: DbSession, p: Annotated[Principal, require("expense.update")]):
    return ok(expense_out(db, p, expenses.update(db, p, eid, body), detail=True))


@router.delete("/expenses/{eid}", status_code=204)
def delete_expense(eid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("expense.delete")]):
    expenses.delete(db, p, eid)


ExpenseAction = Literal["submit", "withdraw", "cancel"]


@router.post("/expenses/{eid}/pay")
def pay_expense(eid: uuid.UUID, body: ExpensePayIn, db: DbSession,
                p: Annotated[Principal, require("expense_payment.create")]):
    return ok(expense_out(db, p, expenses.pay(db, p, eid, body), detail=True))


@router.post("/expenses/{eid}/{action}")
def expense_action(eid: uuid.UUID, action: ExpenseAction, body: ReasonIn, db: DbSession, p: CurrentUser):
    fn = {"submit": lambda: expenses.submit(db, p, eid, body.row_version),
          "withdraw": lambda: expenses.withdraw(db, p, eid, body.row_version),
          "cancel": lambda: expenses.cancel(db, p, eid, body.reason, body.row_version)}[action]
    return ok(expense_out(db, p, fn(), detail=True))


# ------------------------------------------------------------------ finance masters
def _account_out(a: LedgerAccount) -> dict:
    return {"id": str(a.id), "code": a.code, "name": a.name, "account_type": a.account_type, "group_name": a.group_name,
            "system_key": a.system_key, "cost_head": a.cost_head, "is_active": a.is_active, "row_version": a.row_version}


def _account_guard(db, p, obj, body, is_new: bool) -> None:
    types = {k: t for k, _, _, t, _, _ in gl.SYSTEM_ACCOUNTS}
    if not is_new and obj.system_key and (body.account_type != types.get(obj.system_key) or not body.is_active):
        raise AppError("SYSTEM_LEDGER", "A system ledger can be renamed but not retyped or deactivated.")


master_routes(router, path="/ledger-accounts", entity="ledger_account", model=LedgerAccount, perm="finance_master",
              create_schema=LedgerAccountIn, update_schema=LedgerAccountUpdate, out=_account_out,
              search=("code", "name", "group_name"), sortable=("code", "name"), default_sort="code",
              label=lambda a: f"{a.code} {a.name}", before_save=_account_guard)


def _category_out(c: ExpenseCategory) -> dict:
    return {"id": str(c.id), "name": c.name, "account_id": str(c.account_id), "needs_project": c.needs_project,
            "needs_receipt": c.needs_receipt, "is_active": c.is_active, "row_version": c.row_version}


def _category_guard(db, p, obj, body, is_new: bool) -> None:
    acc = db.get(LedgerAccount, body.account_id)
    if acc is None or acc.account_type != "expense":
        raise AppError("INVALID_ACCOUNT", "Choose an expense ledger.", details={"field": "account_id"})


master_routes(router, path="/expense-categories", entity="expense_category", model=ExpenseCategory,
              perm="finance_master", create_schema=ExpenseCategoryIn, update_schema=ExpenseCategoryUpdate,
              out=_category_out, search=("name",), sortable=("name",), default_sort="name", label=lambda c: c.name,
              before_save=_category_guard)


# ================================================================== reports
def _need_any(p: Principal, *codes: str) -> None:
    if not any(p.can(c) for c in codes):
        raise Forbidden()


@router.get("/finance/dashboard")
def finance_dashboard(db: DbSession, p: CurrentUser):
    _need_any(p, "receivable.read", "payable.read", "finance_report.read")
    data = reports.dashboard(db)
    if not p.can("payable.read"):
        for k in ("payable", "payable_overdue", "paid_month", "bills_pending_approval"):
            data.pop(k, None)
    if not p.can("finance_report.read"):
        for k in ("bank_movement", "cash_movement", "gst_payable_month"):
            data.pop(k, None)
    data["trend"] = reports.collections_by_month(db)
    return ok(data)


AGEING_COLUMNS = lambda party: [  # noqa: E731
    excel.Column(party, party.title(), 34), excel.Column("not_due", "Not yet due (₹)", 15),
    excel.Column("d0_30", "1–30 days (₹)", 15), excel.Column("d31_60", "31–60 days (₹)", 15),
    excel.Column("d61_90", "61–90 days (₹)", 15), excel.Column("d90", "Over 90 days (₹)", 15),
    *([excel.Column("retention", "Retention held (₹)", 16)] if party == "customer" else []),
    excel.Column("outstanding", "Outstanding (₹)", 16), excel.Column("advance", "Advance (₹)", 14),
    excel.Column("net", "Net (₹)", 16)]


def _dec_rows(rows):
    return [{k: (Decimal(v) if isinstance(v, str) and k not in ("customer", "supplier", "customer_id", "supplier_id")
                 else v) for k, v in r.items()} for r in rows]


@router.get("/finance/receivables")
def receivables(db: DbSession, _: Annotated[Principal, require("receivable.read")], as_of: date | None = None,
                customer_id: uuid.UUID | None = None):
    return ok(reports.receivables(db, as_of, customer_id))


@router.get("/finance/receivables/export")
def receivables_export(db: DbSession, _: Annotated[Principal, require("receivable.export")], as_of: date | None = None):
    r = reports.receivables(db, as_of)
    audit.record(db, action="export", entity_type="receivable", summary=f"Receivables ageing as of {r['as_of']}")
    return _xlsx(excel.export("Receivables", AGEING_COLUMNS("customer"), _dec_rows(r["rows"])),
                 f"receivables-{r['as_of']}")


@router.get("/finance/payables")
def payables_report(db: DbSession, _: Annotated[Principal, require("payable.read")], as_of: date | None = None,
                    supplier_id: uuid.UUID | None = None):
    return ok(reports.payables(db, as_of, supplier_id))


@router.get("/finance/payables/export")
def payables_export(db: DbSession, _: Annotated[Principal, require("payable.export")], as_of: date | None = None):
    r = reports.payables(db, as_of)
    audit.record(db, action="export", entity_type="payable", summary=f"Payables ageing as of {r['as_of']}")
    return _xlsx(excel.export("Payables", AGEING_COLUMNS("supplier"), _dec_rows(r["rows"])), f"payables-{r['as_of']}")


@router.get("/finance/statement")
def party_statement(db: DbSession, p: CurrentUser, party_type: Literal["customer", "supplier", "employee"],
                    party_id: uuid.UUID, date_from: date | None = None, date_to: date | None = None):
    need = {"customer": "receivable.read", "supplier": "payable.read", "employee": "finance_report.read"}[party_type]
    if not p.can(need):
        raise Forbidden()
    model = {"customer": (Customer, Customer.customer_name), "supplier": (Supplier, Supplier.supplier_name),
             "employee": (Employee, Employee.full_name)}[party_type]
    name = db.scalar(select(model[1]).where(model[0].id == party_id))
    if name is None:
        raise NotFound(party_type)
    return ok({"party": {"type": party_type, "id": str(party_id), "name": name},
               **reports.statement(db, party_type, party_id, date_from, date_to)})


def _period(date_from: date | None, date_to: date | None) -> tuple[date, date]:
    t = today()
    return date_from or t.replace(day=1), date_to or t


@router.get("/finance/gst-summary")
def gst_summary(db: DbSession, _: Annotated[Principal, require("finance_report.read")], date_from: date | None = None,
                date_to: date | None = None):
    return ok(reports.gst_summary(db, *_period(date_from, date_to)))


@router.get("/finance/journal")
def journal(db: DbSession, _: Annotated[Principal, require("finance_report.read")],
            params: Annotated[ListParams, Depends()], date_from: date | None = None, date_to: date | None = None,
            source_type: str | None = None, source_id: uuid.UUID | None = None):
    from app.core.api import paginate

    stmt = select(JournalEntry)
    if date_from:
        stmt = stmt.where(JournalEntry.entry_date >= date_from)
    if date_to:
        stmt = stmt.where(JournalEntry.entry_date <= date_to)
    if source_type:
        stmt = stmt.where(JournalEntry.source_type == source_type)
    if source_id:
        stmt = stmt.where(JournalEntry.source_id == source_id)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where((JournalEntry.entry_number.ilike(like)) | (JournalEntry.source_number.ilike(like))
                          | (JournalEntry.narration.ilike(like)))
    rows, meta = paginate(db, stmt, params, default_sort=JournalEntry.created_at.desc(),
                          sortable={"entry_date": JournalEntry.entry_date, "created_at": JournalEntry.created_at})
    accs = _names(db, LedgerAccount, LedgerAccount.name, {ln.account_id for e in rows for ln in e.lines})
    return {"data": [{"id": str(e.id), "entry_number": e.entry_number, "entry_date": _d(e.entry_date),
                      "source_type": e.source_type, "source_id": str(e.source_id), "source_number": e.source_number,
                      "narration": e.narration, "total": str(e.total), "reverses_id": _s(e.reverses_id),
                      "lines": [{"account": accs.get(ln.account_id), "debit": str(ln.debit), "credit": str(ln.credit),
                                 "party_type": ln.party_type} for ln in e.lines]} for e in rows],
            "meta": meta.model_dump()}


DAYBOOK_COLUMNS = [
    excel.Column("date", "Date", 12), excel.Column("voucher", "Voucher no.", 18),
    excel.Column("voucher_type", "Voucher type", 16), excel.Column("reference", "Reference", 20),
    excel.Column("ledger", "Ledger", 30), excel.Column("group", "Tally group", 20),
    excel.Column("party", "Party", 30), excel.Column("debit", "Debit (₹)", 15), excel.Column("credit", "Credit (₹)", 15),
    excel.Column("narration", "Narration", 50),
]
VOUCHER_TYPES = {"invoice": "Sales", "credit_note": "Credit Note", "receipt": "Receipt",
                 "supplier_invoice": "Purchase", "supplier_payment": "Payment", "expense": "Journal",
                 "expense_payment": "Payment"}


@router.get("/finance/daybook/export")
def daybook_export(db: DbSession, _: Annotated[Principal, require("finance_report.export")],
                   date_from: date | None = None, date_to: date | None = None):
    """Day book for Tally: one row per ledger line, using the same ledger names and Tally groups."""
    d1, d2 = _period(date_from, date_to)
    rows = db.execute(select(JournalEntry, JournalLine, LedgerAccount)
                      .join(JournalLine, JournalLine.entry_id == JournalEntry.id)
                      .join(LedgerAccount, LedgerAccount.id == JournalLine.account_id)
                      .where(JournalEntry.entry_date.between(d1, d2))
                      .order_by(JournalEntry.entry_date, JournalEntry.entry_number, JournalLine.line_no)).all()
    parties: dict = {}
    for kind, model, col in (("customer", Customer, Customer.customer_name), ("supplier", Supplier, Supplier.supplier_name),
                             ("employee", Employee, Employee.full_name)):
        parties[kind] = _names(db, model, col, {ln.party_id for _, ln, _ in rows if ln.party_type == kind})
    data = [{"date": e.entry_date, "voucher": e.entry_number,
             "voucher_type": VOUCHER_TYPES.get(e.source_type, "Journal") if not e.reverses_id else "Journal (reversal)",
             "reference": e.source_number, "ledger": a.name, "group": a.group_name,
             "party": parties.get(ln.party_type, {}).get(ln.party_id) if ln.party_type else None,
             "debit": ln.debit or None, "credit": ln.credit or None, "narration": e.narration} for e, ln, a in rows]
    audit.record(db, action="export", entity_type="journal", summary=f"Day book {d1} to {d2}: {len(data)} lines")
    return _xlsx(excel.export("Day book", DAYBOOK_COLUMNS, data), f"daybook-{d1}-to-{d2}")


@router.get("/finance/trial-balance")
def trial_balance(db: DbSession, _: Annotated[Principal, require("finance_report.read")], as_of: date | None = None):
    rows = gl.trial_balance(db, as_of)
    return ok({"as_of": (as_of or today()).isoformat(), "rows": rows,
               "debit": str(sum((Decimal(r["debit"]) for r in rows), Z)),
               "credit": str(sum((Decimal(r["credit"]) for r in rows), Z))})


@router.get("/finance/parties")
def party_search(db: DbSession, p: CurrentUser, kind: Literal["customer", "supplier"], q: str = ""):
    """Small picker for statements / receipts."""
    _need_any(p, "receivable.read", "payable.read", "receipt.create", "supplier_payment.create")
    model, col, code = (Customer, Customer.customer_name, Customer.customer_code) if kind == "customer" else \
        (Supplier, Supplier.supplier_name, Supplier.supplier_code)
    rows = db.execute(select(model.id, col, code).where(col.ilike(f"%{q}%") | code.ilike(f"%{q}%"))
                      .order_by(col).limit(20)).all()
    return ok([{"id": str(i), "name": n, "code": c} for i, n, c in rows])


@router.get("/finance/bill-ledgers")
def bill_ledgers(db: DbSession, _: Annotated[Principal, require("supplier_invoice.create")]):
    """Ledgers a supplier bill can be booked to: Purchases (goods for stock) or an expense ledger."""
    rows = db.scalars(select(LedgerAccount).where(LedgerAccount.is_active.is_(True),
                                                  (LedgerAccount.account_type == "expense")).order_by(LedgerAccount.code))
    return ok([{"id": str(a.id), "code": a.code, "name": a.name, "cost_head": a.cost_head,
                "default": a.system_key == "purchases"} for a in rows])
