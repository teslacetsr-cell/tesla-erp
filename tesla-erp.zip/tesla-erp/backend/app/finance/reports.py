"""Receivables, payables, statements, GST summary, project finance and the accounts dashboard (Spec §22, §24, §33)."""
import uuid
from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.money import round_amount
from app.crm.service import today
from app.customers.models import Customer
from app.finance.models import (
    CreditNote,
    ExpenseClaim,
    Invoice,
    InvoiceItem,
    JournalEntry,
    JournalLine,
    LedgerAccount,
    Receipt,
    ReceiptAllocation,
    SupplierInvoice,
    SupplierInvoiceItem,
    SupplierPayment,
)
from app.hr.models import Employee
from app.suppliers.models import Supplier

Z = Decimal("0")
BUCKETS = (("not_due", "Not yet due"), ("d0_30", "1–30 days"), ("d31_60", "31–60 days"), ("d61_90", "61–90 days"),
           ("d90", "Over 90 days"))


def _bucket(due: date | None, as_of: date) -> str:
    days = (as_of - due).days if due else 0
    if days <= 0:
        return "not_due"
    if days <= 30:
        return "d0_30"
    if days <= 60:
        return "d31_60"
    if days <= 90:
        return "d61_90"
    return "d90"


def _s(v: Decimal) -> str:
    return str(round_amount(v))


# ------------------------------------------------------------------ receivables
def receivables(db: Session, as_of: date | None = None, customer_id: uuid.UUID | None = None) -> dict:
    """Outstanding invoices by customer and age (by due date). Retention the customer holds back is shown on its
    own, not as overdue; unallocated receipts are shown as advances."""
    as_of = as_of or today()
    # columns only (not ORM objects with their lines): fast with thousands of open invoices
    stmt = select(Invoice.customer_id, Invoice.grand_total - Invoice.received - Invoice.credited,
                  Invoice.retention_amount, Invoice.due_date).where(
        Invoice.status == "issued", Invoice.payment_status != "paid", Invoice.invoice_date <= as_of)
    if customer_id:
        stmt = stmt.where(Invoice.customer_id == customer_id)
    rows: dict[uuid.UUID, dict] = {}

    def row(cid) -> dict:
        if cid not in rows:
            rows[cid] = {"customer_id": str(cid), **{k: Z for k, _ in BUCKETS}, "retention": Z, "outstanding": Z,
                         "advance": Z, "invoices": 0}
        return rows[cid]

    for cid, bal, retention, due in db.execute(stmt):
        if bal <= 0:
            continue
        r = row(cid)
        held = min(retention, bal)
        r[_bucket(due, as_of)] += bal - held
        r["retention"] += held
        r["outstanding"] += bal
        r["invoices"] += 1
    adv = select(Receipt.customer_id, func.sum(Receipt.amount + Receipt.tds_amount - Receipt.allocated)).where(
        Receipt.status == "posted", Receipt.allocated < Receipt.amount + Receipt.tds_amount,
        Receipt.receipt_date <= as_of).group_by(Receipt.customer_id)
    if customer_id:
        adv = adv.where(Receipt.customer_id == customer_id)
    for cid, amt in db.execute(adv).all():
        row(cid)["advance"] += Decimal(amt)
    names = dict(db.execute(select(Customer.id, Customer.customer_name).where(Customer.id.in_(rows.keys()))).all()) \
        if rows else {}
    out = sorted(rows.values(), key=lambda r: -r["outstanding"])
    totals = {k: sum((r[k] for r in out), Z) for k in [b for b, _ in BUCKETS] + ["retention", "outstanding", "advance"]}
    for r in out:
        r["customer"] = names.get(uuid.UUID(r["customer_id"]))
        r["net"] = r["outstanding"] - r["advance"]
        for k in list(r):
            if isinstance(r[k], Decimal):
                r[k] = _s(r[k])
    return {"as_of": as_of.isoformat(), "buckets": [{"key": k, "label": lbl} for k, lbl in BUCKETS],
            "rows": out, "totals": {k: _s(v) for k, v in totals.items()}}


def payables(db: Session, as_of: date | None = None, supplier_id: uuid.UUID | None = None) -> dict:
    as_of = as_of or today()
    stmt = select(SupplierInvoice.supplier_id, SupplierInvoice.grand_total - SupplierInvoice.paid,
                  SupplierInvoice.due_date).where(
        SupplierInvoice.status == "posted", SupplierInvoice.payment_status != "paid",
        SupplierInvoice.supplier_invoice_date <= as_of)
    if supplier_id:
        stmt = stmt.where(SupplierInvoice.supplier_id == supplier_id)
    rows: dict[uuid.UUID, dict] = {}

    def row(sid) -> dict:
        if sid not in rows:
            rows[sid] = {"supplier_id": str(sid), **{k: Z for k, _ in BUCKETS}, "outstanding": Z, "advance": Z,
                         "bills": 0}
        return rows[sid]

    for sid, bal, due in db.execute(stmt):
        if bal <= 0:
            continue
        r = row(sid)
        r[_bucket(due, as_of)] += bal
        r["outstanding"] += bal
        r["bills"] += 1
    adv = select(SupplierPayment.supplier_id,
                 func.sum(SupplierPayment.amount + SupplierPayment.tds_amount - SupplierPayment.allocated)).where(
        SupplierPayment.status == "posted",
        SupplierPayment.allocated < SupplierPayment.amount + SupplierPayment.tds_amount,
        SupplierPayment.payment_date <= as_of).group_by(SupplierPayment.supplier_id)
    if supplier_id:
        adv = adv.where(SupplierPayment.supplier_id == supplier_id)
    for sid, amt in db.execute(adv).all():
        row(sid)["advance"] += Decimal(amt)
    names = dict(db.execute(select(Supplier.id, Supplier.supplier_name).where(Supplier.id.in_(rows.keys()))).all()) \
        if rows else {}
    out = sorted(rows.values(), key=lambda r: -r["outstanding"])
    totals = {k: sum((r[k] for r in out), Z) for k in [b for b, _ in BUCKETS] + ["outstanding", "advance"]}
    for r in out:
        r["supplier"] = names.get(uuid.UUID(r["supplier_id"]))
        r["net"] = r["outstanding"] - r["advance"]
        for k in list(r):
            if isinstance(r[k], Decimal):
                r[k] = _s(r[k])
    return {"as_of": as_of.isoformat(), "buckets": [{"key": k, "label": lbl} for k, lbl in BUCKETS],
            "rows": out, "totals": {k: _s(v) for k, v in totals.items()}}


# ------------------------------------------------------------------ statements (from the journal)
def statement(db: Session, party_type: str, party_id: uuid.UUID, date_from: date | None, date_to: date | None) -> dict:
    """A party's ledger: every journal line on their account, with opening and running balance. For a customer a
    positive balance is owed to us; for a supplier or employee a positive balance is owed by us."""
    key = {"customer": "debtors", "supplier": "creditors", "employee": "employee_payable"}[party_type]
    acc = db.scalar(select(LedgerAccount.id).where(LedgerAccount.system_key == key))
    sign = 1 if party_type == "customer" else -1
    base = (select(JournalEntry.entry_date, JournalEntry.entry_number, JournalEntry.source_type,
                   JournalEntry.source_id, JournalEntry.source_number, JournalEntry.narration, JournalLine.debit,
                   JournalLine.credit)
            .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
            .where(JournalLine.account_id == acc, JournalLine.party_id == party_id))
    opening = Z
    if date_from:
        dr, cr = db.execute(select(func.coalesce(func.sum(JournalLine.debit), 0), func.coalesce(func.sum(JournalLine.credit), 0))
                            .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
                            .where(JournalLine.account_id == acc, JournalLine.party_id == party_id,
                                   JournalEntry.entry_date < date_from)).one()
        opening = sign * (Decimal(dr) - Decimal(cr))
        base = base.where(JournalEntry.entry_date >= date_from)
    if date_to:
        base = base.where(JournalEntry.entry_date <= date_to)
    bal = opening
    lines = []
    for d, num, st, sid, sn, narr, dr, cr in db.execute(base.order_by(JournalEntry.entry_date, JournalEntry.created_at)):
        bal += sign * (dr - cr)
        lines.append({"date": d.isoformat(), "entry_number": num, "type": st, "source_id": str(sid),
                      "reference": sn, "narration": narr, "debit": _s(dr), "credit": _s(cr), "balance": _s(bal)})
    return {"opening": _s(opening), "closing": _s(bal), "lines": lines,
            "debits": _s(sum((Decimal(x["debit"]) for x in lines), Z)),
            "credits": _s(sum((Decimal(x["credit"]) for x in lines), Z))}


# ------------------------------------------------------------------ GST
def gst_summary(db: Session, date_from: date, date_to: date) -> dict:
    """Output GST on issued invoices (less credit notes) and input GST on posted supplier bills, by rate."""
    def by_rate(item, doc, date_col, status_col, status_val, fk):
        q = (select(item.tax_rate, func.sum(item.taxable), func.sum(item.cgst), func.sum(item.sgst), func.sum(item.igst),
                    func.count(func.distinct(doc.id)))
             .join(doc, doc.id == fk).where(status_col.in_(status_val), date_col >= date_from, date_col <= date_to)
             .group_by(item.tax_rate).order_by(item.tax_rate))
        return [{"rate": f"{r.normalize():f}", "taxable": _s(t), "cgst": _s(c), "sgst": _s(s), "igst": _s(i),
                 "documents": n} for r, t, c, s, i, n in db.execute(q).all()]

    # Cancelled invoices still count here: their full-value credit note is subtracted below.
    out_rows = by_rate(InvoiceItem, Invoice, Invoice.invoice_date, Invoice.status, ("issued", "cancelled"),
                       InvoiceItem.invoice_id)
    in_rows = by_rate(SupplierInvoiceItem, SupplierInvoice, SupplierInvoice.supplier_invoice_date,
                      SupplierInvoice.status, ("posted",), SupplierInvoiceItem.supplier_invoice_id)
    cn = db.execute(select(func.coalesce(func.sum(CreditNote.taxable), 0), func.coalesce(func.sum(CreditNote.cgst), 0),
                           func.coalesce(func.sum(CreditNote.sgst), 0), func.coalesce(func.sum(CreditNote.igst), 0),
                           func.count()).where(CreditNote.cn_date >= date_from, CreditNote.cn_date <= date_to)).one()

    def tot(rows):
        return {k: sum((Decimal(r[k]) for r in rows), Z) for k in ("taxable", "cgst", "sgst", "igst")}

    o, i = tot(out_rows), tot(in_rows)
    c = dict(zip(("taxable", "cgst", "sgst", "igst"), (Decimal(x) for x in cn[:4]), strict=True))
    net_out = {k: o[k] - c[k] for k in o}
    payable = {k: net_out[k] - i[k] for k in ("cgst", "sgst", "igst")}
    return {"from": date_from.isoformat(), "to": date_to.isoformat(), "output": out_rows, "input": in_rows,
            "credit_notes": {**{k: _s(v) for k, v in c.items()}, "count": cn[4]},
            "output_total": {k: _s(v) for k, v in o.items()}, "net_output": {k: _s(v) for k, v in net_out.items()},
            "input_total": {k: _s(v) for k, v in i.items()},
            "net_payable": {**{k: _s(v) for k, v in payable.items()}, "total": _s(sum(payable.values(), Z))}}


# ------------------------------------------------------------------ project finance (Spec §24)
def project_finance(db: Session, prj) -> dict:
    """Billing, money received and costs of one project.

    An invoice or receipt belongs to the project when it names the project, or names the project's sales order
    (an order can be billed before its project is opened, and money can be received against the order)."""
    from sqlalchemy import or_

    from app.costing.service import costs_by_head

    so_id = prj.sales_order_id
    inv_scope = or_(Invoice.project_id == prj.id, Invoice.sales_order_id == so_id) if so_id else Invoice.project_id == prj.id
    rct_scope = or_(Receipt.project_id == prj.id, Receipt.sales_order_id == so_id) if so_id else Receipt.project_id == prj.id
    inv = db.execute(select(func.coalesce(func.sum(Invoice.taxable), 0), func.coalesce(func.sum(Invoice.grand_total), 0),
                            func.coalesce(func.sum(Invoice.received), 0), func.count())
                     .where(inv_scope, Invoice.status.in_(("issued", "cancelled")))).one()
    cn = db.execute(select(func.coalesce(func.sum(CreditNote.taxable), 0), func.coalesce(func.sum(CreditNote.total), 0))
                    .join(Invoice, Invoice.id == CreditNote.invoice_id).where(inv_scope)).one()
    billed = Decimal(inv[0]) - Decimal(cn[0])
    billed_gross = Decimal(inv[1]) - Decimal(cn[1])
    against_invoices = Decimal(inv[2])          # receipts allocated to the project's invoices (incl. TDS)
    advance = Decimal(db.scalar(select(func.coalesce(func.sum(Receipt.amount + Receipt.tds_amount - Receipt.allocated), 0))
                                .where(rct_scope, Receipt.status == "posted")) or 0)
    pending_expenses = Decimal(db.scalar(select(func.coalesce(func.sum(ExpenseClaim.amount), 0)).where(
        ExpenseClaim.project_id == prj.id, ExpenseClaim.status == "submitted")) or 0)
    return {"billed": billed, "billed_with_gst": billed_gross,
            # everything received for the project: against its invoices, plus advances not yet allocated
            "collected": against_invoices + advance, "collected_against_invoices": against_invoices,
            "outstanding": billed_gross - against_invoices, "advance": advance, "invoices": inv[3],
            "costs": costs_by_head(db, prj.id), "pending_expenses": pending_expenses}


# ------------------------------------------------------------------ dashboard
def dashboard(db: Session) -> dict:
    t = today()
    month_start = t.replace(day=1)
    rec = receivables(db, t)["totals"]
    pay = payables(db, t)["totals"]
    overdue_r = sum(Decimal(rec[k]) for k in ("d0_30", "d31_60", "d61_90", "d90"))
    overdue_p = sum(Decimal(pay[k]) for k in ("d0_30", "d31_60", "d61_90", "d90"))
    invoiced = db.scalar(select(func.coalesce(func.sum(Invoice.grand_total), 0)).where(
        Invoice.status.in_(("issued", "cancelled")), Invoice.invoice_date >= month_start)) or 0
    credited = db.scalar(select(func.coalesce(func.sum(CreditNote.total), 0)).where(CreditNote.cn_date >= month_start)) or 0
    collected = db.scalar(select(func.coalesce(func.sum(Receipt.amount + Receipt.tds_amount), 0)).where(
        Receipt.status == "posted", Receipt.receipt_date >= month_start)) or 0
    paid = db.scalar(select(func.coalesce(func.sum(SupplierPayment.amount + SupplierPayment.tds_amount), 0)).where(
        SupplierPayment.status == "posted", SupplierPayment.payment_date >= month_start)) or 0
    exp_status = dict(db.execute(select(ExpenseClaim.status, func.coalesce(func.sum(ExpenseClaim.amount), 0))
                                 .where(ExpenseClaim.status.in_(("submitted", "approved"))).group_by(ExpenseClaim.status)).all())
    exp_month = db.scalar(select(func.coalesce(func.sum(ExpenseClaim.amount), 0)).where(
        ExpenseClaim.status.in_(("approved", "paid")), ExpenseClaim.expense_date >= month_start)) or 0
    drafts = db.scalar(select(func.count()).select_from(Invoice).where(Invoice.status == "draft")) or 0
    bills_pending = db.scalar(select(func.count()).select_from(SupplierInvoice).where(
        SupplierInvoice.status == "pending_approval")) or 0
    gst = gst_summary(db, month_start, t)
    # cash position: bank + cash ledgers
    cash = db.execute(select(LedgerAccount.system_key, func.sum(JournalLine.debit - JournalLine.credit))
                      .join(LedgerAccount, LedgerAccount.id == JournalLine.account_id)
                      .where(LedgerAccount.system_key.in_(("bank", "cash"))).group_by(LedgerAccount.system_key)).all()
    cash = {k: Decimal(v) for k, v in cash}
    return {
        "receivable": rec["outstanding"], "receivable_overdue": _s(overdue_r), "retention": rec["retention"],
        "customer_advances": rec["advance"], "payable": pay["outstanding"], "payable_overdue": _s(overdue_p),
        "invoiced_month": _s(Decimal(invoiced) - Decimal(credited)), "collected_month": _s(Decimal(collected)),
        "paid_month": _s(Decimal(paid)), "expenses_pending_approval": _s(Decimal(exp_status.get("submitted", 0))),
        "expenses_to_pay": _s(Decimal(exp_status.get("approved", 0))), "expenses_month": _s(Decimal(exp_month)),
        "draft_invoices": drafts, "bills_pending_approval": bills_pending,
        "gst_payable_month": gst["net_payable"]["total"],
        "bank_movement": _s(cash.get("bank", Z)), "cash_movement": _s(cash.get("cash", Z)),
    }


def collections_by_month(db: Session, months: int = 6) -> list[dict]:
    t = today().replace(day=1)
    out = []
    for i in range(months - 1, -1, -1):
        y, m = t.year, t.month - i
        while m <= 0:
            m += 12
            y -= 1
        start = date(y, m, 1)
        end = (date(y + (m == 12), m % 12 + 1, 1)) - timedelta(days=1)
        inv = db.scalar(select(func.coalesce(func.sum(Invoice.taxable), 0)).where(
            Invoice.status.in_(("issued", "cancelled")), Invoice.invoice_date.between(start, end))) or 0
        cn = db.scalar(select(func.coalesce(func.sum(CreditNote.taxable), 0)).where(
            CreditNote.cn_date.between(start, end))) or 0
        col = db.scalar(select(func.coalesce(func.sum(Receipt.amount + Receipt.tds_amount), 0)).where(
            Receipt.status == "posted", Receipt.receipt_date.between(start, end))) or 0
        out.append({"month": start.strftime("%b %Y"), "billed": _s(Decimal(inv) - Decimal(cn)), "collected": _s(Decimal(col))})
    return out


def employee_names(db: Session, ids) -> dict:
    ids = {i for i in ids if i}
    return dict(db.execute(select(Employee.id, Employee.full_name).where(Employee.id.in_(ids))).all()) if ids else {}


def receipts_for_invoice(db: Session, invoice_id: uuid.UUID) -> list[dict]:
    rows = db.execute(select(Receipt.id, Receipt.receipt_number, Receipt.receipt_date, Receipt.mode,
                             ReceiptAllocation.amount, ReceiptAllocation.tds)
                      .join(Receipt, Receipt.id == ReceiptAllocation.receipt_id)
                      .where(ReceiptAllocation.invoice_id == invoice_id, ReceiptAllocation.is_active.is_(True))
                      .order_by(Receipt.receipt_date)).all()
    return [{"id": str(i), "receipt_number": n, "receipt_date": d.isoformat(), "mode": m, "amount": _s(a), "tds": _s(t)}
            for i, n, d, m, a, t in rows]
