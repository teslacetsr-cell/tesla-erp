from app.core.permissions import register

register("invoice", "Sales invoices (drafts; delete = discard a draft)",
         ("create", "read", "update", "delete", "export", "print"))
register("invoice_post", "Issue sales invoices and credit notes (GST documents)", ("approve",))
register("receipt", "Customer receipts (delete = cancel; a receipt is never removed)",
         ("create", "read", "update", "delete", "export", "print"))
register("supplier_invoice", "Supplier invoices / purchase bills (approve = pass bills that do not match the PO or GRN)",
         ("create", "read", "update", "delete", "approve", "export"))
register("supplier_payment", "Supplier payments (delete = cancel; a payment is never removed)",
         ("create", "read", "update", "delete", "export", "print"))
# 'own' scope: an employee sees and edits only their own claims.
register("expense", "Expense claims", ("create", "read", "update", "delete", "approve", "export", "print"),
         scoped=("read", "update", "delete", "print"))
register("expense_payment", "Pay approved expense claims", ("create",))
register("receivable", "Receivables: outstanding, ageing, customer statements", ("read", "export"))
register("payable", "Payables: outstanding, ageing, supplier statements", ("read", "export"))
register("finance_report", "GST summary, journal / day book, trial balance, Tally export", ("read", "export"))
register("finance_master", "Ledger accounts and expense categories", ("create", "read", "update"))
