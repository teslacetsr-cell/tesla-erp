"""The journal: every posted finance document writes one balanced entry here, in the same transaction.

The chart of accounts is deliberately small and Tally-shaped (ledger + Tally group), because the ERP feeds Tally
(architecture Q1): the day book exports with the same ledger names.
"""
import uuid
from dataclasses import dataclass
from datetime import date
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.errors import AppError
from app.core.money import round_amount
from app.finance.models import JournalEntry, JournalLine, LedgerAccount
from app.platform.numbering import service as numbering

Z = Decimal("0")

# (system_key, code, name, type, Tally group, cost head)
SYSTEM_ACCOUNTS = [
    ("debtors", "1100", "Sundry Debtors", "asset", "Sundry Debtors", None),
    ("bank", "1200", "Bank Account", "asset", "Bank Accounts", None),
    ("cash", "1210", "Cash in Hand", "asset", "Cash-in-Hand", None),
    ("tds_receivable", "1300", "TDS Receivable", "asset", "Current Assets", None),
    ("input_cgst", "1410", "Input CGST", "asset", "Duties & Taxes", None),
    ("input_sgst", "1420", "Input SGST", "asset", "Duties & Taxes", None),
    ("input_igst", "1430", "Input IGST", "asset", "Duties & Taxes", None),
    ("creditors", "2100", "Sundry Creditors", "liability", "Sundry Creditors", None),
    ("employee_payable", "2200", "Employee Reimbursements Payable", "liability", "Current Liabilities", None),
    ("tds_payable", "2300", "TDS Payable", "liability", "Duties & Taxes", None),
    ("output_cgst", "2410", "Output CGST", "liability", "Duties & Taxes", None),
    ("output_sgst", "2420", "Output SGST", "liability", "Duties & Taxes", None),
    ("output_igst", "2430", "Output IGST", "liability", "Duties & Taxes", None),
    ("sales", "4100", "Sales — Projects & Services", "income", "Sales Accounts", None),
    ("round_off", "4900", "Round Off", "income", "Indirect Incomes", None),
    ("purchases", "5100", "Purchases", "expense", "Purchase Accounts", None),
]
# Expense ledgers that expense categories and supplier bills post to.
EXPENSE_ACCOUNTS = [
    ("5200", "Subcontract Charges", "Direct Expenses", "subcontract"),
    ("5210", "Labour Charges", "Direct Expenses", "labour"),
    ("5300", "Travelling & Conveyance", "Indirect Expenses", "travel"),
    ("5310", "Site Expenses", "Direct Expenses", "other"),
    ("5320", "Tools & Equipment Hire", "Direct Expenses", "other"),
    ("5400", "Office & Administrative Expenses", "Indirect Expenses", None),
    ("5410", "Communication Expenses", "Indirect Expenses", None),
]


def seed_accounts(db: Session, user_id) -> None:
    """Add any missing standard ledger (never renames or changes one the company has edited)."""
    by = {"created_by": user_id, "updated_by": user_id}
    have_keys = set(db.scalars(select(LedgerAccount.system_key).where(LedgerAccount.system_key.is_not(None))))
    have_codes = set(db.scalars(select(LedgerAccount.code)))
    have_names = {n.lower() for n in db.scalars(select(LedgerAccount.name))}
    for key, code, name, typ, group, head in SYSTEM_ACCOUNTS:
        if key not in have_keys:
            db.add(LedgerAccount(system_key=key, code=code if code not in have_codes else f"S-{key}"[:20], name=name
                                 if name.lower() not in have_names else f"{name} (system)", account_type=typ,
                                 group_name=group, cost_head=head, **by))
    for code, name, group, head in EXPENSE_ACCOUNTS:
        if code not in have_codes and name.lower() not in have_names:
            db.add(LedgerAccount(code=code, name=name, account_type="expense", group_name=group, cost_head=head, **by))
    db.flush()


def account(db: Session, key: str) -> uuid.UUID:
    aid = db.scalar(select(LedgerAccount.id).where(LedgerAccount.system_key == key))
    if aid is None:
        raise AppError("LEDGER_MISSING", f"The '{key}' ledger is missing. Run the setup (seed core) again.")
    return aid


def money_account(mode: str) -> str:
    return "cash" if mode == "cash" else "bank"


@dataclass
class Line:
    account: uuid.UUID | str          # ledger id or system key
    debit: Decimal = Z
    credit: Decimal = Z
    party_type: str | None = None
    party_id: uuid.UUID | None = None
    project_id: uuid.UUID | None = None
    narration: str | None = None


def post(db: Session, *, company_id: uuid.UUID, entry_date: date, source_type: str, source_id: uuid.UUID,
         source_number: str | None, narration: str, lines: list[Line], user_id: uuid.UUID | None,
         reverses_id: uuid.UUID | None = None) -> JournalEntry:
    """Write one balanced entry. Zero lines are dropped; a negative amount moves to the other side."""
    rows: list[Line] = []
    for ln in lines:
        d, c = round_amount(ln.debit), round_amount(ln.credit)
        net = d - c
        if net == 0:
            continue
        acc = ln.account if isinstance(ln.account, uuid.UUID) else account(db, ln.account)
        rows.append(Line(acc, net if net > 0 else Z, -net if net < 0 else Z, ln.party_type, ln.party_id,
                         ln.project_id, ln.narration))
    dr, cr = sum((r.debit for r in rows), Z), sum((r.credit for r in rows), Z)
    if dr != cr:
        raise AppError("UNBALANCED_ENTRY", f"Journal entry does not balance (Dr {dr} ≠ Cr {cr}).")
    if not rows:
        raise AppError("EMPTY_ENTRY", "Nothing to post.")
    entry = JournalEntry(entry_number=numbering.next_number(db, company_id, "JV", on=entry_date), entry_date=entry_date,
                         source_type=source_type, source_id=source_id, source_number=source_number,
                         narration=narration[:500], total=dr, reverses_id=reverses_id, created_by=user_id)
    db.add(entry)
    db.flush()
    for n, r in enumerate(rows, start=1):
        db.add(JournalLine(entry_id=entry.id, line_no=n, account_id=r.account, debit=r.debit, credit=r.credit,
                           party_type=r.party_type, party_id=r.party_id, project_id=r.project_id,
                           narration=(r.narration or None) and r.narration[:300]))
    db.flush()
    return entry


def reverse(db: Session, *, company_id: uuid.UUID, source_type: str, source_id: uuid.UUID, entry_date: date,
            narration: str, user_id: uuid.UUID | None) -> list[JournalEntry]:
    """Reverse every not-yet-reversed entry of a document (cancellation)."""
    reversed_ids = select(JournalEntry.reverses_id).where(JournalEntry.reverses_id.is_not(None))
    originals = db.scalars(select(JournalEntry).where(
        JournalEntry.source_type == source_type, JournalEntry.source_id == source_id,
        JournalEntry.reverses_id.is_(None), JournalEntry.id.not_in(reversed_ids))).all()
    out = []
    for e in originals:
        out.append(post(db, company_id=company_id, entry_date=entry_date, source_type=source_type, source_id=source_id,
                        source_number=e.source_number, narration=f"Reversal of {e.entry_number}: {narration}",
                        lines=[Line(ln.account_id, debit=ln.credit, credit=ln.debit, party_type=ln.party_type,
                                    party_id=ln.party_id, project_id=ln.project_id, narration=ln.narration)
                               for ln in e.lines],
                        user_id=user_id, reverses_id=e.id))
    return out


def trial_balance(db: Session, to_date: date | None = None) -> list[dict]:
    stmt = (select(LedgerAccount.id, LedgerAccount.code, LedgerAccount.name, LedgerAccount.account_type,
                   LedgerAccount.group_name, func.coalesce(func.sum(JournalLine.debit), 0),
                   func.coalesce(func.sum(JournalLine.credit), 0))
            .join(JournalLine, JournalLine.account_id == LedgerAccount.id)
            .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
            .group_by(LedgerAccount.id).order_by(LedgerAccount.code))
    if to_date:
        stmt = stmt.where(JournalEntry.entry_date <= to_date)
    out = []
    for aid, code, name, typ, group, dr, cr in db.execute(stmt).all():
        net = Decimal(dr) - Decimal(cr)
        out.append({"account_id": str(aid), "code": code, "name": name, "type": typ, "group": group,
                    "debit": str(net if net > 0 else Z), "credit": str(-net if net < 0 else Z)})
    return out
