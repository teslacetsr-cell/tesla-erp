"""Expense claims (Spec §25): Employee → Submit → Manager approval → Accounts → Paid.

The approval chain comes from Administration → Approval rules ("Expense claims"), seeded as Manager → Accounts.
An approved claim posts to its category's expense ledger — and to the project's cost when it is for a project — and
the amount is owed to the employee until Accounts pays it.
"""
import uuid
from decimal import Decimal

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.core.api import ListParams, paginate
from app.core.errors import AppError, Forbidden, NotFound
from app.core.models import check_row_version
from app.core.money import round_amount
from app.crm.service import now, today
from app.finance import gl
from app.finance.models import ExpenseCategory, ExpenseClaim
from app.hr.models import Employee
from app.hr.service import employee_for_user
from app.platform.approvals import service as approvals
from app.platform.audit import service as audit
from app.platform.documents.models import Document
from app.platform.notifications.service import notify, users_with_roles
from app.platform.numbering import service as numbering
from app.projects.models import Project


def _own_ids(db: Session, p: Principal) -> tuple[uuid.UUID | None, uuid.UUID]:
    emp = employee_for_user(db, p.id)
    return (emp.id if emp else None), p.id


def check(db: Session, p: Principal, e: ExpenseClaim, action: str) -> None:
    scope = p.scope(f"expense.{action}")
    if scope is None:
        raise Forbidden()
    if scope == "own":
        emp_id, uid = _own_ids(db, p)
        if e.employee_id != emp_id and e.created_by != uid:
            raise Forbidden("You can only work on your own expense claims.", code="OUT_OF_SCOPE")


def allowed(db: Session, p: Principal, e: ExpenseClaim, action: str) -> bool:
    try:
        check(db, p, e, action)
        return True
    except Forbidden:
        return False


def get(db: Session, eid: uuid.UUID, lock: bool = False) -> ExpenseClaim:
    e = db.get(ExpenseClaim, eid, with_for_update=lock or None)
    if e is None:
        raise NotFound("expense")
    return e


def label(e: ExpenseClaim) -> str:
    return e.expense_number or f"Draft expense of {e.expense_date:%d %b %Y}"


def _fill(db: Session, p: Principal, e: ExpenseClaim, data) -> None:
    emp_id = data.employee_id
    own_emp, _ = _own_ids(db, p)
    if emp_id is None:
        if own_emp is None:
            raise AppError("NO_EMPLOYEE_RECORD", "Your login is not linked to an employee record. Ask HR to link it.")
        emp_id = own_emp
    elif emp_id != own_emp and p.scope("expense.update") != "all":
        raise Forbidden("You can only claim expenses for yourself.", code="OUT_OF_SCOPE")
    emp = db.get(Employee, emp_id)
    if emp is None or not emp.is_active:
        raise AppError("INVALID_EMPLOYEE", "Choose an active employee.", details={"field": "employee_id"})
    cat = db.get(ExpenseCategory, data.category_id)
    if cat is None or not cat.is_active:
        raise AppError("INVALID_CATEGORY", "Choose an active expense category.", details={"field": "category_id"})
    if data.project_id:
        prj = db.get(Project, data.project_id)
        if prj is None:
            raise NotFound("project")
        if prj.status in ("cancelled", "completed") and e.project_id != prj.id:
            raise AppError("PROJECT_CLOSED", f"Project {prj.project_number} is {prj.status}.")
    elif cat.needs_project:
        raise AppError("PROJECT_REQUIRED", f"{cat.name} expenses must be for a project.", details={"field": "project_id"})
    if data.expense_date > today():
        raise AppError("FUTURE_DATE", "The expense date cannot be in the future.", details={"field": "expense_date"})
    e.employee_id, e.project_id, e.category_id = emp.id, data.project_id, cat.id
    e.expense_date, e.amount, e.description = data.expense_date, round_amount(data.amount), data.description
    e.bill_reference, e.updated_by = data.bill_reference, p.id


def create(db: Session, p: Principal, data) -> ExpenseClaim:
    e = ExpenseClaim(status="draft", expense_date=data.expense_date, amount=data.amount, created_by=p.id,
                     updated_by=p.id)
    _fill(db, p, e, data)
    db.add(e)
    db.flush()
    audit.record(db, action="create", entity_type="expense", entity_id=e.id, entity_label=label(e),
                 summary=f"₹{e.amount}: {e.description[:120]}")
    return e


def update(db: Session, p: Principal, eid: uuid.UUID, data) -> ExpenseClaim:
    e = get(db, eid, lock=True)
    check(db, p, e, "update")
    if e.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft claim can be edited. Withdraw it first.")
    check_row_version(e, data.row_version)
    before = audit.snapshot(e)
    _fill(db, p, e, data)
    db.flush()
    audit.record(db, action="update", entity_type="expense", entity_id=e.id, entity_label=label(e),
                 before=before, after=audit.snapshot(e))
    return e


def delete(db: Session, p: Principal, eid: uuid.UUID) -> None:
    e = get(db, eid, lock=True)
    check(db, p, e, "delete")
    if e.status != "draft" or e.expense_number:
        raise AppError("NOT_DRAFT", "A submitted claim is kept for the record. Cancel it instead.")
    lbl = label(e)
    db.delete(e)
    db.flush()
    audit.record(db, action="delete", entity_type="expense", entity_id=eid, entity_label=lbl)


def has_receipt(db: Session, eid: uuid.UUID) -> bool:
    return db.scalar(select(Document.id).where(Document.entity_type == "expense", Document.entity_id == eid,
                                               Document.is_latest.is_(True), Document.status == "available")
                     .limit(1)) is not None


def submit(db: Session, p: Principal, eid: uuid.UUID, row_version: int | None) -> ExpenseClaim:
    e = get(db, eid, lock=True)
    check(db, p, e, "update")
    if e.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft claim can be submitted.")
    if row_version is not None:
        check_row_version(e, row_version)
    else:
        e.row_version += 1
    cat = db.get(ExpenseCategory, e.category_id)
    if cat.needs_receipt and not has_receipt(db, e.id):
        raise AppError("RECEIPT_REQUIRED", f"Attach the bill or receipt — {cat.name} claims need one.")
    e.expense_number = e.expense_number or numbering.next_number(db, p.company_id, "EXP", on=e.expense_date)
    e.submitted_at, e.last_rejection, e.updated_by = now(), None, p.id
    emp = db.get(Employee, e.employee_id)
    division = (db.scalar(select(Project.division_id).where(Project.id == e.project_id)) if e.project_id else None) \
        or emp.division_id
    req = approvals.start(db, p, entity_type="expense", entity_id=e.id,
                          label=f"{e.expense_number} · {emp.full_name} · {cat.name}", amount=e.amount,
                          division_id=division)
    if req is None:
        _approved(db, p, e)
    else:
        e.status = "submitted"
    db.flush()
    audit.record(db, action="submit", entity_type="expense", entity_id=e.id, entity_label=e.expense_number,
                 summary=f"₹{e.amount}" + ("" if req else " — no approval rule applies, approved"))
    return e


def _approved(db: Session, p: Principal, e: ExpenseClaim) -> None:
    e.status, e.approved_at = "approved", now()
    cat = db.get(ExpenseCategory, e.category_id)
    emp = db.get(Employee, e.employee_id)
    db.flush()
    gl.post(db, company_id=p.company_id, entry_date=e.expense_date, source_type="expense", source_id=e.id,
            source_number=e.expense_number, user_id=p.id,
            narration=f"Expense {e.expense_number}: {emp.full_name} — {cat.name}: {e.description}"[:500],
            lines=[gl.Line(cat.account_id, debit=e.amount, project_id=e.project_id),
                   gl.Line("employee_payable", credit=e.amount, party_type="employee", party_id=emp.id,
                           project_id=e.project_id)])
    if e.project_id:
        from app.costing import service as costing
        from app.finance.models import LedgerAccount

        head = db.scalar(select(LedgerAccount.cost_head).where(LedgerAccount.id == cat.account_id)) or "other"
        costing.record(db, project_id=e.project_id, cost_head=head, amount=e.amount,
                       description=f"{cat.name}: {e.description} ({emp.full_name})", source_type="expense",
                       source_id=e.id, source_number=e.expense_number, cost_date=e.expense_date, user_id=p.id,
                       party=emp.full_name)
    notify(db, users_with_roles(db, ["ACCOUNTS"]), event="expense.approved", exclude=p.id,
           title=f"Expense {e.expense_number} approved — ₹{e.amount} to pay {emp.full_name}",
           body=e.description[:200], link=f"/finance/expenses/view?id={e.id}")


def _on_approved(db: Session, p: Principal, req) -> None:
    e = get(db, req.entity_id, lock=True)
    if e.status != "submitted":
        return
    _approved(db, p, e)
    e.row_version += 1


def _on_rejected(db: Session, p: Principal, req, comment: str) -> None:
    e = get(db, req.entity_id, lock=True)
    e.status, e.last_rejection = "draft", comment[:500]
    e.row_version += 1


def _owners(db: Session, eid: uuid.UUID) -> list[uuid.UUID]:
    e = db.get(ExpenseClaim, eid)
    if e is None:
        return []
    uid = db.scalar(select(Employee.user_id).where(Employee.id == e.employee_id))
    return [x for x in {uid, e.created_by} if x]


approvals.register("expense", approvals.Handler(
    label="Expense claim", href=lambda i: f"/finance/expenses/view?id={i}", on_approved=_on_approved,
    on_rejected=_on_rejected, owners=_owners))


def withdraw(db: Session, p: Principal, eid: uuid.UUID, row_version: int | None) -> ExpenseClaim:
    e = get(db, eid, lock=True)
    check(db, p, e, "update")
    if e.status != "submitted":
        raise AppError("INVALID_TRANSITION", "Only a claim waiting for approval can be withdrawn.")
    if row_version is not None:
        check_row_version(e, row_version)
    else:
        e.row_version += 1
    approvals.withdraw(db, p, "expense", e.id)
    e.status, e.updated_by = "draft", p.id
    db.flush()
    audit.record(db, action="withdraw", entity_type="expense", entity_id=e.id, entity_label=label(e),
                 summary="Withdrawn for changes")
    return e


def pay(db: Session, p: Principal, eid: uuid.UUID, data) -> ExpenseClaim:
    if not p.can("expense_payment.create"):
        raise Forbidden("Paying expense claims is done by Accounts.", code="CANNOT_PAY")
    e = get(db, eid, lock=True)
    if e.status != "approved":
        raise AppError("NOT_APPROVED", "Only an approved claim can be paid.")
    if data.row_version is not None:
        check_row_version(e, data.row_version)
    else:
        e.row_version += 1
    paid_at = data.paid_at or today()
    if paid_at > today():
        raise AppError("FUTURE_DATE", "The payment date cannot be in the future.")
    emp = db.get(Employee, e.employee_id)
    e.status, e.paid_at, e.payment_mode, e.payment_reference = "paid", paid_at, data.payment_mode, data.payment_reference
    e.paid_by, e.updated_by = p.id, p.id
    db.flush()
    gl.post(db, company_id=p.company_id, entry_date=paid_at, source_type="expense_payment", source_id=e.id,
            source_number=e.expense_number, user_id=p.id,
            narration=f"Paid expense {e.expense_number} to {emp.full_name} ({data.payment_mode.upper()}"
                      + (f" {data.payment_reference}" if data.payment_reference else "") + ")",
            lines=[gl.Line("employee_payable", debit=e.amount, party_type="employee", party_id=emp.id),
                   gl.Line(gl.money_account(data.payment_mode), credit=e.amount)])
    audit.record(db, action="pay", entity_type="expense", entity_id=e.id, entity_label=e.expense_number,
                 summary=f"Paid ₹{e.amount} by {data.payment_mode.upper()}")
    if emp.user_id:
        notify(db, [emp.user_id], event="expense.paid", exclude=p.id, title=f"Expense {e.expense_number} paid",
               body=f"₹{e.amount} · {data.payment_mode.upper()}", link=f"/finance/expenses/view?id={e.id}")
    return e


def cancel(db: Session, p: Principal, eid: uuid.UUID, reason: str | None, row_version: int | None) -> ExpenseClaim:
    e = get(db, eid, lock=True)
    if e.status in ("approved",):
        if not p.can("expense_payment.create"):
            raise Forbidden("An approved claim can only be cancelled by Accounts.")
    else:
        check(db, p, e, "update")
    if e.status not in ("draft", "submitted", "approved"):
        raise AppError("INVALID_TRANSITION", f"A {e.status} claim cannot be cancelled.")
    if not (reason and reason.strip()):
        raise AppError("REASON_REQUIRED", "Say why the claim is cancelled.", details={"field": "reason"})
    if row_version is not None:
        check_row_version(e, row_version)
    else:
        e.row_version += 1
    was = e.status
    approvals.withdraw(db, p, "expense", e.id)
    e.status, e.status_reason, e.updated_by = "cancelled", reason[:500], p.id
    db.flush()
    if was == "approved":
        gl.reverse(db, company_id=p.company_id, source_type="expense", source_id=e.id, entry_date=today(),
                   narration=f"expense {e.expense_number} cancelled: {reason}", user_id=p.id)
        from app.costing import service as costing

        costing.reverse_source(db, source_type="expense", source_id=e.id, reason=f"claim cancelled: {reason}",
                               user_id=p.id)
    audit.record(db, action="cancel", entity_type="expense", entity_id=e.id, entity_label=label(e),
                 summary=f"Cancelled: {reason}")
    return e


def list_expenses(db: Session, p: Principal, params: ListParams, *, status=None, employee_id=None, project_id=None,
                  category_id=None, date_from=None, date_to=None, mine=False):
    stmt = select(ExpenseClaim)
    scope = p.scope("expense.read")
    if scope is None:
        raise Forbidden()
    if scope == "own" or mine:
        emp_id, uid = _own_ids(db, p)
        stmt = stmt.where(or_(ExpenseClaim.employee_id == emp_id, ExpenseClaim.created_by == uid))
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(ExpenseClaim.expense_number.ilike(like), ExpenseClaim.description.ilike(like),
                              ExpenseClaim.employee_id.in_(select(Employee.id).where(Employee.full_name.ilike(like)))))
    for col, val in ((ExpenseClaim.status, status), (ExpenseClaim.employee_id, employee_id),
                     (ExpenseClaim.project_id, project_id), (ExpenseClaim.category_id, category_id)):
        if val:
            stmt = stmt.where(col == val)
    if date_from:
        stmt = stmt.where(ExpenseClaim.expense_date >= date_from)
    if date_to:
        stmt = stmt.where(ExpenseClaim.expense_date <= date_to)
    return paginate(db, stmt, params, default_sort=ExpenseClaim.created_at.desc(), sortable={
        "expense_date": ExpenseClaim.expense_date, "amount": ExpenseClaim.amount, "status": ExpenseClaim.status,
        "created_at": ExpenseClaim.created_at})


def unpaid_total(db: Session) -> Decimal:
    from sqlalchemy import func

    return Decimal(db.scalar(select(func.coalesce(func.sum(ExpenseClaim.amount), 0))
                             .where(ExpenseClaim.status == "approved")) or 0)
