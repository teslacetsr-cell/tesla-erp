"""Indian statutory identifiers: GSTIN, PAN, state codes, financial year."""
import re
from datetime import date, datetime
from zoneinfo import ZoneInfo

GST_STATE_CODES: dict[str, str] = {
    "01": "Jammu and Kashmir", "02": "Himachal Pradesh", "03": "Punjab", "04": "Chandigarh",
    "05": "Uttarakhand", "06": "Haryana", "07": "Delhi", "08": "Rajasthan", "09": "Uttar Pradesh",
    "10": "Bihar", "11": "Sikkim", "12": "Arunachal Pradesh", "13": "Nagaland", "14": "Manipur",
    "15": "Mizoram", "16": "Tripura", "17": "Meghalaya", "18": "Assam", "19": "West Bengal",
    "20": "Jharkhand", "21": "Odisha", "22": "Chhattisgarh", "23": "Madhya Pradesh", "24": "Gujarat",
    "26": "Dadra and Nagar Haveli and Daman and Diu", "27": "Maharashtra", "29": "Karnataka", "30": "Goa",
    "31": "Lakshadweep", "32": "Kerala", "33": "Tamil Nadu", "34": "Puducherry",
    "35": "Andaman and Nicobar Islands", "36": "Telangana", "37": "Andhra Pradesh", "38": "Ladakh",
    "97": "Other Territory",
}
STATE_NAME_TO_CODE = {v.lower(): k for k, v in GST_STATE_CODES.items()}

_GSTIN_RE = re.compile(r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$")
_PAN_RE = re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]$")
_PINCODE_RE = re.compile(r"^[1-9][0-9]{5}$")
_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def gstin_check_char(first14: str) -> str:
    total = 0
    for i, ch in enumerate(first14):
        product = _CHARS.index(ch) * (1 if i % 2 == 0 else 2)
        total += product // 36 + product % 36
    return _CHARS[(36 - total % 36) % 36]


def validate_gstin(value: str) -> str:
    v = value.strip().upper()
    if not _GSTIN_RE.match(v):
        raise ValueError("GSTIN must be 15 characters in the format 22AAAAA0000A1Z5.")
    if v[:2] not in GST_STATE_CODES:
        raise ValueError(f"GSTIN state code {v[:2]} is not a valid GST state code.")
    if gstin_check_char(v[:14]) != v[14]:
        raise ValueError("GSTIN check digit is incorrect — please re-check the number.")
    return v


def validate_pan(value: str) -> str:
    v = value.strip().upper()
    if not _PAN_RE.match(v):
        raise ValueError("PAN must be 10 characters in the format AAAAA0000A.")
    return v


def validate_pincode(value: str) -> str:
    v = value.strip()
    if not _PINCODE_RE.match(v):
        raise ValueError("PIN code must be 6 digits.")
    return v


def validate_state_code(value: str) -> str:
    v = value.strip().zfill(2)
    if v not in GST_STATE_CODES:
        raise ValueError("Unknown GST state code.")
    return v


def financial_year(on: date | datetime | None = None, tz: str = "Asia/Kolkata") -> tuple[int, int]:
    """Indian financial year (April–March). 25 Sep 2026 -> (2026, 2027)."""
    if on is None:
        on = datetime.now(ZoneInfo(tz)).date()
    elif isinstance(on, datetime):
        on = on.astimezone(ZoneInfo(tz)).date() if on.tzinfo else on.date()
    start = on.year if on.month >= 4 else on.year - 1
    return start, start + 1
