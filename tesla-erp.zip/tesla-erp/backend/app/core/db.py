"""Database engine and per-request session (unit of work).

Each HTTP request gets one session. If the request handler finishes without error the
transaction is committed; on any exception it is rolled back — so a business change and
its audit record either both persist or neither does.
"""
from collections.abc import Iterator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.core.config import get_settings

_settings = get_settings()

engine = create_engine(
    _settings.database_url,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20,
    connect_args={"options": "-c timezone=UTC"},
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def get_db() -> Iterator[Session]:
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


# Use this alias in every route and dependency. scope="function" guarantees the commit
# happens *before* the response is sent, so a client never sees success for a change
# that then failed to commit.
from typing import Annotated  # noqa: E402

from fastapi import Depends  # noqa: E402

DbSession = Annotated[Session, Depends(get_db, scope="function")]
