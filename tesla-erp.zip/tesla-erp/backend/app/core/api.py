"""Common list handling: pagination, sorting, search, and the {data, meta} envelope."""
from typing import Annotated, Any, Generic, TypeVar

from fastapi import Query
from pydantic import BaseModel, ConfigDict
from sqlalchemy import Select, func, select
from sqlalchemy.orm import Session

from app.core.errors import AppError

T = TypeVar("T")


class Schema(BaseModel):
    model_config = ConfigDict(from_attributes=True, str_strip_whitespace=True)


class PageMeta(BaseModel):
    page: int
    page_size: int
    total: int


class Envelope(BaseModel, Generic[T]):
    data: T
    meta: dict[str, Any] | None = None


class Page(BaseModel, Generic[T]):
    data: list[T]
    meta: PageMeta


class ListParams:
    def __init__(
        self,
        page: Annotated[int, Query(ge=1)] = 1,
        page_size: Annotated[int, Query(ge=1, le=200)] = 25,
        sort: Annotated[str | None, Query(description="Field name; prefix with - for descending")] = None,
        q: Annotated[str | None, Query(max_length=100)] = None,
    ):
        self.page, self.page_size, self.sort, self.q = page, page_size, sort, (q or "").strip() or None


def paginate(
    session: Session, stmt: Select, params: ListParams, *, sortable: dict[str, Any], default_sort: Any
) -> tuple[list[Any], PageMeta]:
    total = session.scalar(select(func.count()).select_from(stmt.order_by(None).subquery())) or 0
    if params.sort:
        desc = params.sort.startswith("-")
        key = params.sort.lstrip("-")
        if key not in sortable:
            raise AppError("INVALID_SORT", f"Cannot sort by '{key}'.", details={"allowed": sorted(sortable)})
        col = sortable[key]
        stmt = stmt.order_by(col.desc() if desc else col.asc())
    else:
        stmt = stmt.order_by(default_sort)
    rows = session.scalars(stmt.offset((params.page - 1) * params.page_size).limit(params.page_size)).all()
    return list(rows), PageMeta(page=params.page, page_size=params.page_size, total=total)


def ok(data: Any, **meta: Any) -> dict:
    return {"data": data, "meta": meta or None}
