"""Per-request context (user, IP, user agent, request id) used by audit logging."""
import uuid
from contextvars import ContextVar
from dataclasses import dataclass, field


@dataclass
class RequestContext:
    request_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    user_id: uuid.UUID | None = None
    ip: str | None = None
    user_agent: str | None = None


_request_ctx: ContextVar[RequestContext | None] = ContextVar("request_ctx", default=None)


class _Accessor:
    """`request_ctx.get()` always returns a context (a blank one outside requests, e.g. seed scripts)."""

    def get(self) -> RequestContext:
        ctx = _request_ctx.get()
        return ctx if ctx is not None else RequestContext(request_id="-")

    def set(self, ctx: RequestContext):
        return _request_ctx.set(ctx)

    def reset(self, token) -> None:
        _request_ctx.reset(token)


request_ctx = _Accessor()
