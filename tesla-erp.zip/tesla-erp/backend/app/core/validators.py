"""Reusable Pydantic field types with Indian-specific validation."""
import re
from typing import Annotated

from pydantic import AfterValidator, BeforeValidator, Field

from app.core.india import GST_STATE_CODES, validate_gstin, validate_pan, validate_pincode, validate_state_code

_IFSC = re.compile(r"^[A-Z]{4}0[A-Z0-9]{6}$")
_PHONE = re.compile(r"^\+?[0-9][0-9 \-]{6,18}[0-9]$")
_HSN = re.compile(r"^[0-9]{4,8}$")


def _blank_to_none(v):
    if isinstance(v, str) and not v.strip():
        return None
    return v


def _ifsc(v: str) -> str:
    v = v.strip().upper()
    if not _IFSC.match(v):
        raise ValueError("IFSC must be 11 characters: 4 letters, 0, then 6 letters/digits (e.g. SBIN0070123).")
    return v


def _phone(v: str) -> str:
    v = v.strip()
    if not _PHONE.match(v):
        raise ValueError("Enter a valid phone number (digits, spaces, dashes, optional +).")
    return v


def _hsn(v: str) -> str:
    v = v.strip()
    if not _HSN.match(v):
        raise ValueError("HSN/SAC must be 4 to 8 digits.")
    return v


Blank = BeforeValidator(_blank_to_none)
GSTIN = Annotated[str | None, Blank, AfterValidator(lambda v: v and validate_gstin(v))]
PAN = Annotated[str | None, Blank, AfterValidator(lambda v: v and validate_pan(v))]
Pincode = Annotated[str | None, Blank, AfterValidator(lambda v: v and validate_pincode(v))]
StateCode = Annotated[str | None, Blank, AfterValidator(lambda v: v and validate_state_code(v))]
IFSC = Annotated[str | None, Blank, AfterValidator(lambda v: v and _ifsc(v))]
Phone = Annotated[str | None, Blank, AfterValidator(lambda v: v and _phone(v))]
HSN = Annotated[str | None, Blank, AfterValidator(lambda v: v and _hsn(v))]
OptStr = Annotated[str | None, Blank]


def Text(max_len: int):  # noqa: N802 - reads like a type
    """Optional text up to max_len characters; blank -> None. The length rule applies to the string only,
    so an explicit null from the browser is accepted."""
    return Annotated[Annotated[str, Field(max_length=max_len)] | None, Blank]


def check_tax_identity(gstin: str | None, pan: str | None, state_code: str | None) -> dict:
    """Cross-field checks: GSTIN embeds the PAN (chars 3–12) and the state code (chars 1–2).

    Returns fields to auto-fill (state/state_code/pan from GSTIN). Raises ValueError on mismatch.
    """
    fill: dict = {}
    if gstin:
        if pan and gstin[2:12] != pan:
            raise ValueError("PAN does not match the PAN inside the GSTIN (characters 3–12).")
        if state_code and state_code != gstin[:2]:
            raise ValueError(
                f"State code {state_code} does not match the GSTIN, which is registered in "
                f"{GST_STATE_CODES[gstin[:2]]} ({gstin[:2]})."
            )
        fill = {"pan": gstin[2:12], "state_code": gstin[:2], "state": GST_STATE_CODES[gstin[:2]]}
    elif state_code:
        fill = {"state": GST_STATE_CODES[state_code]}
    return fill
