"""The one GST / document-total calculation (Spec §14, §23). Used by BOQs, quotations and — later — sales
orders and invoices, so every document computes money the same way. Pure functions on Decimal; no floats.

Per line
    amount     = qty × rate                       (rounded to paise)
    discount   = amount × discount %              (rounded to paise)
    special    = share of the document's special discount, pro-rata to (amount − discount)
    taxable    = amount − discount − special
    intra-state: CGST = SGST = taxable × (GST% ÷ 2)   inter-state: IGST = taxable × GST%   (each rounded to paise)
Document
    totals are sums of the line figures; the grand total is rounded to the nearest rupee and the difference is
    shown as "round off".
Tax rates are data (the GST % on each line comes from the item's tax-rate master), never hard-coded here.
"""
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal

from app.core.money import round_amount, round_to_rupee

ZERO = Decimal("0")
HUNDRED = Decimal("100")


@dataclass(frozen=True)
class LineIn:
    quantity: Decimal
    rate: Decimal
    discount_pct: Decimal = ZERO
    tax_rate: Decimal = ZERO


@dataclass
class LineOut:
    amount: Decimal
    discount_amount: Decimal
    special_discount: Decimal
    taxable: Decimal
    cgst: Decimal
    sgst: Decimal
    igst: Decimal

    @property
    def tax(self) -> Decimal:
        return self.cgst + self.sgst + self.igst

    @property
    def total(self) -> Decimal:
        return self.taxable + self.tax


@dataclass
class Totals:
    gross: Decimal = ZERO             # Σ qty × rate
    line_discount: Decimal = ZERO
    special_discount: Decimal = ZERO
    taxable: Decimal = ZERO
    cgst: Decimal = ZERO
    sgst: Decimal = ZERO
    igst: Decimal = ZERO
    round_off: Decimal = ZERO
    grand_total: Decimal = ZERO
    inter_state: bool = False
    tax_summary: list[dict] = field(default_factory=list)  # one row per GST rate

    @property
    def tax_total(self) -> Decimal:
        return self.cgst + self.sgst + self.igst

    @property
    def total_before_round(self) -> Decimal:
        return self.taxable + self.tax_total


class CalcError(ValueError):
    pass


def _half(value: Decimal) -> Decimal:
    return (value / 2).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)


def calculate(lines: list[LineIn], *, inter_state: bool, special_discount: Decimal = ZERO,
              round_total: bool = True) -> tuple[list[LineOut], Totals]:
    special_discount = round_amount(special_discount or ZERO)
    outs: list[LineOut] = []
    for ln in lines:
        if ln.quantity < 0 or ln.rate < 0:
            raise CalcError("Quantity and rate cannot be negative.")
        if not ZERO <= ln.discount_pct <= HUNDRED:
            raise CalcError("Discount must be between 0 and 100 %.")
        if ln.tax_rate < 0:
            raise CalcError("GST rate cannot be negative.")
        amount = round_amount(ln.quantity * ln.rate)
        disc = round_amount(amount * ln.discount_pct / HUNDRED)
        outs.append(LineOut(amount, disc, ZERO, amount - disc, ZERO, ZERO, ZERO))

    net_total = sum((o.taxable for o in outs), ZERO)
    if special_discount < 0:
        raise CalcError("The special discount cannot be negative.")
    if special_discount > net_total:
        raise CalcError("The special discount cannot be more than the value after line discounts.")
    if special_discount and net_total:
        # Pro-rata by net value; the rounding remainder goes to the largest line so the parts add up exactly.
        allocated = ZERO
        for o in outs:
            share = round_amount(special_discount * o.taxable / net_total)
            o.special_discount = share
            allocated += share
        biggest = max(outs, key=lambda o: o.taxable)
        biggest.special_discount += special_discount - allocated
        for o in outs:
            o.taxable -= o.special_discount

    summary: dict[Decimal, dict] = {}
    for ln, o in zip(lines, outs, strict=True):
        rate = ln.tax_rate
        if inter_state:
            o.igst = round_amount(o.taxable * rate / HUNDRED)
        else:
            o.cgst = o.sgst = round_amount(o.taxable * _half(rate) / HUNDRED)
        row = summary.setdefault(rate, {"rate": rate, "taxable": ZERO, "cgst": ZERO, "sgst": ZERO, "igst": ZERO})
        row["taxable"] += o.taxable
        row["cgst"] += o.cgst
        row["sgst"] += o.sgst
        row["igst"] += o.igst

    t = Totals(inter_state=inter_state)
    t.gross = sum((o.amount for o in outs), ZERO)
    t.line_discount = sum((o.discount_amount for o in outs), ZERO)
    t.special_discount = special_discount
    t.taxable = sum((o.taxable for o in outs), ZERO)
    t.cgst = sum((o.cgst for o in outs), ZERO)
    t.sgst = sum((o.sgst for o in outs), ZERO)
    t.igst = sum((o.igst for o in outs), ZERO)
    if round_total:
        t.grand_total, t.round_off = round_to_rupee(t.total_before_round)
    else:
        t.grand_total, t.round_off = t.total_before_round, ZERO
    t.tax_summary = [summary[r] for r in sorted(summary)]
    return outs, t


def is_inter_state(company_state_code: str | None, place_of_supply: str | None) -> bool:
    """Inter-state supply (IGST) when the place of supply is a different state from the company's."""
    if not company_state_code or not place_of_supply:
        return False
    return company_state_code != place_of_supply


# ------------------------------------------------------------------ amount in words (Indian system)
_ONES = ("", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve",
         "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen")
_TENS = ("", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety")


def _two(n: int) -> str:
    if n < 20:
        return _ONES[n]
    return (_TENS[n // 10] + (" " + _ONES[n % 10] if n % 10 else "")).strip()


def _three(n: int) -> str:
    h, r = divmod(n, 100)
    parts = []
    if h:
        parts.append(f"{_ONES[h]} Hundred")
    if r:
        parts.append(_two(r))
    return " ".join(parts)


def _indian(n: int) -> str:
    if n == 0:
        return "Zero"
    parts = []
    crore, n = divmod(n, 10_000_000)
    lakh, n = divmod(n, 100_000)
    thousand, n = divmod(n, 1000)
    if crore:
        parts.append(f"{_indian(crore)} Crore")
    if lakh:
        parts.append(f"{_two(lakh)} Lakh")
    if thousand:
        parts.append(f"{_two(thousand)} Thousand")
    if n:
        parts.append(_three(n))
    return " ".join(parts)


def amount_in_words(value: Decimal) -> str:
    """₹5,50,000.50 → 'Rupees Five Lakh Fifty Thousand and Fifty Paise Only'."""
    v = round_amount(value)
    negative = v < 0
    rupees, paise = divmod(int((abs(v) * 100).to_integral_value()), 100)
    words = f"Rupees {_indian(rupees)}"
    if paise:
        words += f" and {_two(paise)} Paise"
    return ("Minus " if negative else "") + words + " Only"
