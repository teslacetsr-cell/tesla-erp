"""Declarative base and standard columns shared by every major table (Spec §5)."""
import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, MetaData, func, text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, declared_attr, mapped_column

# Deterministic constraint names — errors and migrations stay readable.
NAMING = {
    "ix": "ix_%(table_name)s_%(column_0_N_name)s",
    "uq": "uq_%(table_name)s_%(column_0_N_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING)


def uuid_pk() -> Mapped[uuid.UUID]:
    return mapped_column(UUID(as_uuid=True), primary_key=True, server_default=text("gen_random_uuid()"), default=uuid.uuid4)


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )


class AuditColumnsMixin(TimestampMixin):
    """UUID PK + created/updated at/by. `row_version` gives optimistic locking."""

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, server_default=text("gen_random_uuid()"), default=uuid.uuid4
    )

    @declared_attr
    def created_by(cls) -> Mapped[uuid.UUID | None]:
        return mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="RESTRICT"), nullable=True)

    @declared_attr
    def updated_by(cls) -> Mapped[uuid.UUID | None]:
        return mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="RESTRICT"), nullable=True)

    row_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1, server_default="1")



def check_row_version(obj: AuditColumnsMixin, expected: int | None) -> None:
    """Optimistic locking: reject the save if someone else changed the record meanwhile."""
    from app.core.errors import Conflict

    if expected is not None and obj.row_version != expected:
        raise Conflict(
            "STALE_RECORD",
            "This record was changed by someone else after you opened it. Reload and try again.",
            details={"current_row_version": obj.row_version},
        )
    obj.row_version += 1
