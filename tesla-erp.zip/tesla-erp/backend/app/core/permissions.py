"""Permission registry. Each module declares its permission codes in its own permissions.py.

Codes are `module.action`. Actions follow Spec §6: create, read, update, delete, approve, export, print.
`edit` and `view` (used in the spec's example) are accepted as aliases of update/read.
"""
from dataclasses import dataclass

ACTIONS = ("create", "read", "update", "delete", "approve", "export", "print", "use", "moderate")
ACTION_ALIASES = {"edit": "update", "view": "read"}
ACTION_LABELS = {
    "create": "Create", "read": "View", "update": "Edit", "delete": "Delete / deactivate",
    "approve": "Approve", "export": "Export", "print": "Print", "use": "Use", "moderate": "Moderate",
}


@dataclass(frozen=True)
class PermissionDef:
    code: str
    module: str
    action: str
    description: str
    supports_scope: bool


REGISTRY: dict[str, PermissionDef] = {}
MODULE_LABELS: dict[str, str] = {}


def register(module: str, label: str, actions: tuple[str, ...], scoped: tuple[str, ...] = ()) -> None:
    MODULE_LABELS[module] = label
    for action in actions:
        if action not in ACTIONS:
            raise ValueError(f"Unknown action {action}")
        code = f"{module}.{action}"
        REGISTRY[code] = PermissionDef(code, module, action, f"{ACTION_LABELS[action]} — {label}", action in scoped)


def normalise(code: str) -> str:
    module, _, action = code.partition(".")
    return f"{module}.{ACTION_ALIASES.get(action, action)}"
