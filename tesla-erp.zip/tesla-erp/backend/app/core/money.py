"""Money and quantity handling. Never use float for money.

Column conventions (see docs/ERP_ARCHITECTURE.md §5.2):
    Amount      NUMERIC(18,2)
    Rate        NUMERIC(18,4)
    Quantity    NUMERIC(18,3)
    Percentage  NUMERIC(7,4)
"""
from decimal import ROUND_HALF_UP, Decimal
from typing import Annotated

from pydantic import PlainSerializer
from sqlalchemy import Numeric

AMOUNT = Numeric(18, 2)
RATE = Numeric(18, 4)
QTY = Numeric(18, 3)
PERCENT = Numeric(7, 4)

_TWO = Decimal("0.01")
_FOUR = Decimal("0.0001")
_THREE = Decimal("0.001")


def to_decimal(value: object) -> Decimal:
    if isinstance(value, Decimal):
        return value
    if isinstance(value, float):
        # Go through str to avoid binary-float artefacts (0.1 -> 0.1000000000000000055…)
        return Decimal(str(value))
    return Decimal(value)  # type: ignore[arg-type]


def round_amount(value: object) -> Decimal:
    return to_decimal(value).quantize(_TWO, rounding=ROUND_HALF_UP)


def round_rate(value: object) -> Decimal:
    return to_decimal(value).quantize(_FOUR, rounding=ROUND_HALF_UP)


def round_qty(value: object) -> Decimal:
    return to_decimal(value).quantize(_THREE, rounding=ROUND_HALF_UP)


def round_to_rupee(value: object) -> tuple[Decimal, Decimal]:
    """Round a grand total to the nearest rupee. Returns (rounded_total, round_off)."""
    v = round_amount(value)
    rounded = v.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return rounded, rounded - v


def format_inr(value: object) -> str:
    """Indian digit grouping: 550000 -> '5,50,000.00'."""
    v = round_amount(value)
    sign = "-" if v < 0 else ""
    whole, frac = f"{abs(v):.2f}".split(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups + [tail])
    return f"{sign}{whole}.{frac}"


# Pydantic types: serialised as strings in JSON so JavaScript never rounds money.
Money = Annotated[Decimal, PlainSerializer(lambda v: None if v is None else str(round_amount(v)), return_type=str | None)]
Rate = Annotated[Decimal, PlainSerializer(lambda v: None if v is None else str(round_rate(v)), return_type=str | None)]
Qty = Annotated[Decimal, PlainSerializer(lambda v: None if v is None else str(round_qty(v)), return_type=str | None)]
