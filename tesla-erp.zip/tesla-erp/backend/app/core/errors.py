"""Consistent error envelope: {"error": {"code", "message", "details", "request_id"}}."""
import logging
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.context import request_ctx

log = logging.getLogger(__name__)


class AppError(Exception):
    status_code = 400

    def __init__(self, code: str, message: str, *, status_code: int | None = None, details: Any = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details
        if status_code is not None:
            self.status_code = status_code


class NotFound(AppError):
    status_code = 404

    def __init__(self, entity: str, details: Any = None):
        super().__init__(f"{entity.upper()}_NOT_FOUND", f"{entity.replace('_', ' ').capitalize()} not found.", details=details)


class Conflict(AppError):
    status_code = 409


class Forbidden(AppError):
    status_code = 403

    def __init__(self, message: str = "You do not have permission to do this.", code: str = "FORBIDDEN"):
        super().__init__(code, message)


class Unauthorized(AppError):
    status_code = 401

    def __init__(self, message: str = "Authentication required.", code: str = "UNAUTHORIZED"):
        super().__init__(code, message)


def _body(code: str, message: str, details: Any = None) -> dict:
    return {"error": {"code": code, "message": message, "details": details, "request_id": request_ctx.get().request_id}}


def install_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def _app_error(_: Request, exc: AppError):
        return JSONResponse(status_code=exc.status_code, content=_body(exc.code, exc.message, exc.details))

    @app.exception_handler(RequestValidationError)
    async def _validation(_: Request, exc: RequestValidationError):
        details = [
            {"field": ".".join(str(p) for p in e["loc"] if p != "body"), "message": friendly(e), "type": e["type"]}
            for e in exc.errors()
        ]
        parts = [f"{field_label(d['field'])}: {d['message']}" if d["field"] else d["message"] for d in details[:4]]
        more = f" (and {len(details) - 4} more)" if len(details) > 4 else ""
        msg = ("Please check — " + "; ".join(parts) + more) if parts else "Some fields are invalid."
        return JSONResponse(status_code=422, content=_body("VALIDATION_ERROR", msg, details))

    @app.exception_handler(StarletteHTTPException)
    async def _http(_: Request, exc: StarletteHTTPException):
        code = {404: "NOT_FOUND", 405: "METHOD_NOT_ALLOWED", 429: "RATE_LIMITED"}.get(exc.status_code, "HTTP_ERROR")
        return JSONResponse(status_code=exc.status_code, content=_body(code, str(exc.detail)))

    @app.exception_handler(IntegrityError)
    async def _integrity(_: Request, exc: IntegrityError):
        # Constraint names are chosen to be meaningful (e.g. uq_customers_code).
        constraint = getattr(getattr(exc.orig, "diag", None), "constraint_name", None)
        if constraint and constraint.startswith("fk_") and "is not present in table" in str(exc.orig):
            return JSONResponse(status_code=400, content=_body(
                "INVALID_REFERENCE", "A chosen record no longer exists. Reload the page and choose again.",
                {"constraint": constraint}))
        if constraint and constraint.startswith("fk_"):
            log.warning("in use: %s: %s", constraint, exc.orig)
            return JSONResponse(
                status_code=409,
                content=_body("IN_USE", "This record is used by other records, so it cannot be removed. Deactivate it instead.",
                              {"constraint": constraint}),
            )
        sqlstate = getattr(exc.orig, "sqlstate", None)
        if sqlstate == "23505":  # unique_violation
            log.warning("duplicate on %s: %s", constraint, exc.orig)
            return JSONResponse(
                status_code=409,
                content=_body("DUPLICATE", duplicate_message(constraint), {"constraint": constraint}),
            )
        # not-null / check violations are bugs or missing validation — never report them as duplicates
        log.error("integrity error %s on %s: %s", sqlstate, constraint, exc.orig)
        return JSONResponse(status_code=400, content=_body(
            "INVALID_DATA", "The data could not be saved because it breaks a data rule.", {"constraint": constraint}))


# Plain-language messages for the unique rules users can actually run into.
DUPLICATES = {
    "uq_customers_customer_code": "Another customer already has this customer code.",
    "uq_suppliers_supplier_code": "Another supplier already has this supplier code.",
    "uq_items_item_code": "Another item already has this item code.",
    "uq_employees_employee_code": "Another employee already has this employee code.",
    "uq_employees_email": "Another employee already has this email address.",
    "uq_employees_user_id": "This login is already linked to another employee.",
    "uq_users_email": "Another user already has this email address.",
    "uq_users_username": "Another user already has this username.",
    "uq_brands_name": "A brand with this name already exists.",
    "uq_units_code": "A unit with this code already exists.",
    "uq_tax_rates_code": "A GST rate with this code already exists.",
    "uq_item_categories_code": "A category with this code already exists.",
    "uq_item_categories_name": "A category with this name already exists.",
    "uq_departments_code": "A department with this code already exists.",
    "uq_designations_name": "A designation with this name already exists.",
    "uq_business_divisions_company_id_code": "A division with this code already exists.",
    "uq_warehouses_company_id_code": "A warehouse with this code already exists.",
    "uq_warehouses_project_id": "This project already has a site store.",
    "uq_expense_categories_name": "An expense category with this name already exists.",
    "uq_ledger_accounts_code": "A ledger with this code already exists.",
    "uq_ledger_accounts_name": "A ledger with this name already exists.",
    "uq_leave_types_code": "A leave type with this code already exists.",
    "uq_holidays_holiday_date": "There is already a holiday on this date.",
    "uq_roles_code": "A role with this code already exists.",
    "uq_project_members_user": "This person is already on the project team.",
    "uq_stock_serials_item_serial": "This serial number is already recorded for the item.",
    "uq_supplier_invoices_supplier_no": "This supplier's bill number has already been entered.",
    "uq_attendance_emp_date": "Attendance for this person and day already exists.",
    "uq_salary_records_emp_from": "There is already a salary record from that date.",
    "uq_sales_orders_live_quotation": "This quotation already has an open sales order.",
    "uq_approval_requests_one_pending": "This is already waiting for approval.",
}


def duplicate_message(constraint: str | None) -> str:
    if constraint in DUPLICATES:
        return DUPLICATES[constraint]
    if constraint and constraint.endswith("_number"):
        return "That document number is already taken. Please try again."
    return "A record with the same unique value already exists."


LABELS = {"gstin": "GSTIN", "pan": "PAN", "bank_ifsc": "IFSC", "ifsc": "IFSC", "hsn_sac": "HSN/SAC", "role_codes": "Roles",
          "tds_amount": "TDS", "pincode": "PIN code", "igst": "IGST", "cgst": "CGST", "sgst": "SGST",
          "customer_po_number": "Customer PO no.", "so_item_id": "Order line", "items": "Lines", "lines": "Lines"}


def field_label(field: str) -> str:
    """'items.2.rate' → 'Line 3 rate'; 'customer_po_date' → 'Customer po date'."""
    parts = [p for p in field.split(".") if p not in ("query", "path")]
    line = next((int(p) for p in parts if p.isdigit()), None)
    name = next((p for p in reversed(parts) if not p.isdigit()), field) or "Value"
    label = LABELS.get(name) or name.replace("_id", "").replace("_", " ").strip().capitalize() or "Value"
    if line is not None and parts and parts[0] in ("items", "lines"):
        return f"Line {line + 1} {label.lower()}"
    return label


def friendly(e: dict) -> str:
    """Plain-language version of a pydantic error, for people rather than programmers."""
    t, ctx, msg = e.get("type", ""), e.get("ctx") or {}, e.get("msg", "")
    if t == "missing":
        return "This is required."
    if t in ("decimal_parsing", "decimal_type", "float_parsing", "float_type"):
        return "Enter a number (digits only, no commas)."
    if t in ("int_parsing", "int_type", "int_from_float"):
        return "Enter a whole number."
    if t == "decimal_max_places":
        return f"Use at most {ctx.get('decimal_places')} decimal places."
    if t in ("decimal_max_digits", "decimal_whole_digits"):
        return "This number is too large."
    if t == "greater_than":
        return f"Must be more than {ctx.get('gt')}."
    if t == "greater_than_equal":
        return f"Must be {ctx.get('ge')} or more."
    if t == "less_than":
        return f"Must be less than {ctx.get('lt')}."
    if t == "less_than_equal":
        return f"Must be {ctx.get('le')} or less."
    if t == "string_too_short":
        n = ctx.get("min_length")
        return "This is required." if n == 1 else f"Enter at least {n} characters."
    if t == "string_too_long":
        return f"Use at most {ctx.get('max_length')} characters."
    if t == "too_short":
        return f"Choose or add at least {ctx.get('min_length')}."
    if t == "too_long":
        return f"At most {ctx.get('max_length')} allowed."
    if t == "string_pattern_mismatch" and str(e.get("loc", [""])[-1]) == "username":
        return "Use letters, digits, dot, dash or underscore only (no spaces)."
    if t == "string_pattern_mismatch":
        return "Contains characters that are not allowed (use capital letters, digits, - or _)." \
            if "A-Z0-9_-" in str(ctx.get("pattern", "")) else "This is not in the expected format."
    if t in ("literal_error", "enum"):
        return f"Choose one of: {ctx.get('expected', '').replace(chr(39), '')}."
    if t in ("date_parsing", "date_from_datetime_parsing", "date_type", "datetime_parsing", "datetime_type"):
        return "Enter a valid date."
    if t in ("uuid_parsing", "uuid_type"):
        return "Choose from the list."
    if t in ("bool_parsing", "bool_type"):
        return "Choose yes or no."
    if msg.lower().startswith("value is not a valid email"):
        return "Enter a valid email address."
    return msg.replace("Value error, ", "")
