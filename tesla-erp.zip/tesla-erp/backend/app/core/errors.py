"""Consistent error envelope: {"error": {"code", "message", "details", "request_id"}}."""
import logging
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.context import request_ctx

log = logging.getLogger(__name__)


class AppError(Exception):
    status_code = 400

    def __init__(self, code: str, message: str, *, status_code: int | None = None, details: Any = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details
        if status_code is not None:
            self.status_code = status_code


class NotFound(AppError):
    status_code = 404

    def __init__(self, entity: str, details: Any = None):
        super().__init__(f"{entity.upper()}_NOT_FOUND", f"{entity.replace('_', ' ').capitalize()} not found.", details=details)


class Conflict(AppError):
    status_code = 409


class Forbidden(AppError):
    status_code = 403

    def __init__(self, message: str = "You do not have permission to do this.", code: str = "FORBIDDEN"):
        super().__init__(code, message)


class Unauthorized(AppError):
    status_code = 401

    def __init__(self, message: str = "Authentication required.", code: str = "UNAUTHORIZED"):
        super().__init__(code, message)


def _body(code: str, message: str, details: Any = None) -> dict:
    return {"error": {"code": code, "message": message, "details": details, "request_id": request_ctx.get().request_id}}


def install_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def _app_error(_: Request, exc: AppError):
        return JSONResponse(status_code=exc.status_code, content=_body(exc.code, exc.message, exc.details))

    @app.exception_handler(RequestValidationError)
    async def _validation(_: Request, exc: RequestValidationError):
        details = [
            {"field": ".".join(str(p) for p in e["loc"] if p != "body"), "message": e["msg"], "type": e["type"]}
            for e in exc.errors()
        ]
        return JSONResponse(status_code=422, content=_body("VALIDATION_ERROR", "Some fields are invalid.", details))

    @app.exception_handler(StarletteHTTPException)
    async def _http(_: Request, exc: StarletteHTTPException):
        code = {404: "NOT_FOUND", 405: "METHOD_NOT_ALLOWED", 429: "RATE_LIMITED"}.get(exc.status_code, "HTTP_ERROR")
        return JSONResponse(status_code=exc.status_code, content=_body(code, str(exc.detail)))

    @app.exception_handler(IntegrityError)
    async def _integrity(_: Request, exc: IntegrityError):
        # Constraint names are chosen to be meaningful (e.g. uq_customers_code).
        constraint = getattr(getattr(exc.orig, "diag", None), "constraint_name", None)
        if constraint and constraint.startswith("fk_"):
            return JSONResponse(
                status_code=409,
                content=_body("IN_USE", "This record is referenced by other records and cannot be deleted. Deactivate it instead.",
                              {"constraint": constraint}),
            )
        sqlstate = getattr(exc.orig, "sqlstate", None)
        if sqlstate == "23505":  # unique_violation
            return JSONResponse(
                status_code=409,
                content=_body("DUPLICATE", "A record with the same unique value already exists.", {"constraint": constraint}),
            )
        # not-null / check violations are bugs or missing validation — never report them as duplicates
        log.error("integrity error %s on %s: %s", sqlstate, constraint, exc.orig)
        return JSONResponse(status_code=400, content=_body(
            "INVALID_DATA", "The data could not be saved because it breaks a data rule.", {"constraint": constraint}))
