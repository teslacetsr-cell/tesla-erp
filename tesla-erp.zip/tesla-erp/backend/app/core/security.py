"""Password hashing (Argon2id), JWT access tokens, refresh-token hashing, field encryption."""
import hashlib
import secrets
import uuid
from datetime import UTC, datetime, timedelta

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError
from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy import String
from sqlalchemy.types import TypeDecorator

from app.core.config import get_settings

_settings = get_settings()
_hasher = PasswordHasher(time_cost=_settings.argon2_time_cost, memory_cost=_settings.argon2_memory_kib, parallelism=2)
_ALGO = "HS256"

# A short local list catches the worst choices; complements the length rule.
_COMMON_PASSWORDS = {
    "password", "password1", "password123", "123456789", "1234567890", "qwerty123", "iloveyou",
    "admin12345", "welcome123", "letmein123", "tesla12345", "teslace123", "changeme123", "abc1234567",
    "p@ssw0rd123", "admin@123", "admin@12345", "india12345", "qwertyuiop", "1q2w3e4r5t",
}


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return _hasher.verify(password_hash, password)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


# Constant-time dummy verify for unknown users (prevents user enumeration by timing).
_DUMMY_HASH = _hasher.hash(secrets.token_urlsafe(16))


def dummy_verify() -> None:
    verify_password("x", _DUMMY_HASH)


def password_problems(password: str, *, username: str = "", email: str = "") -> list[str]:
    problems = []
    if len(password) < 10:
        problems.append("Password must be at least 10 characters.")
    if len(password) > 128:
        problems.append("Password must be at most 128 characters.")
    lowered = password.lower()
    if lowered in _COMMON_PASSWORDS:
        problems.append("This password is too common.")
    for ident in (username, email.split("@")[0] if email else ""):
        if ident and len(ident) >= 3 and ident.lower() in lowered:
            problems.append("Password must not contain your username or email.")
            break
    if len(set(password)) < 5:
        problems.append("Password is too repetitive.")
    return problems


def create_access_token(user_id: uuid.UUID, session_version: int) -> tuple[str, int]:
    now = datetime.now(UTC)
    ttl = _settings.access_token_minutes * 60
    payload = {
        "sub": str(user_id),
        "sv": session_version,
        "typ": "access",
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(seconds=ttl)).timestamp()),
        "jti": secrets.token_hex(8),
    }
    return jwt.encode(payload, _settings.secret_key, algorithm=_ALGO), ttl


def decode_access_token(token: str) -> dict:
    payload = jwt.decode(token, _settings.secret_key, algorithms=[_ALGO], options={"require": ["exp", "sub", "typ"]})
    if payload.get("typ") != "access":
        raise jwt.InvalidTokenError("wrong token type")
    return payload


def new_opaque_token() -> str:
    return secrets.token_urlsafe(48)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


# ---------------------------------------------------------------- field encryption
_fernet = Fernet(_settings.field_encryption_key.encode())


def encrypt_value(value: str) -> str:
    return _fernet.encrypt(value.encode()).decode()


def decrypt_value(value: str) -> str:
    try:
        return _fernet.decrypt(value.encode()).decode()
    except InvalidToken as exc:  # pragma: no cover - indicates key mismatch
        raise ValueError("Cannot decrypt field: encryption key mismatch") from exc


class EncryptedString(TypeDecorator):
    """Column type that stores text encrypted at rest (bank accounts, PAN of employees, salary)."""

    impl = String
    cache_ok = True

    def process_bind_param(self, value, dialect):
        return None if value is None else encrypt_value(str(value))

    def process_result_value(self, value, dialect):
        return None if value is None else decrypt_value(value)


def mask(value: str | None, visible: int = 4) -> str | None:
    if not value:
        return value
    return "•" * max(len(value) - visible, 0) + value[-visible:]
