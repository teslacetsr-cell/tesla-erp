"""Excel import/export helpers shared by master modules (Spec §13 pattern, used from Phase 1)."""
import io
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Any

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from app.core.errors import AppError

XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
_HEADER_FILL = PatternFill("solid", fgColor="D90000")
_HEADER_FONT = Font(bold=True, color="FFFFFF")
MAX_IMPORT_ROWS = 5000


@dataclass(frozen=True)
class Column:
    key: str
    header: str
    width: int = 18
    required: bool = False
    choices: tuple[str, ...] = ()
    note: str = ""


def _sheet(wb: Workbook, title: str, columns: list[Column]):
    ws = wb.active
    ws.title = title[:31]
    for i, col in enumerate(columns, start=1):
        c = ws.cell(row=1, column=i, value=col.header + (" *" if col.required else ""))
        c.fill, c.font, c.alignment = _HEADER_FILL, _HEADER_FONT, Alignment(vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = col.width
        if col.choices:
            dv = DataValidation(type="list", formula1='"' + ",".join(col.choices) + '"', allow_blank=not col.required)
            dv.add(f"{get_column_letter(i)}2:{get_column_letter(i)}{MAX_IMPORT_ROWS + 1}")
            ws.add_data_validation(dv)
    ws.freeze_panes = "A2"
    ws.row_dimensions[1].height = 30
    return ws


def template(title: str, columns: list[Column], example: dict[str, Any] | None = None) -> bytes:
    wb = Workbook()
    ws = _sheet(wb, title, columns)
    if example:
        for i, col in enumerate(columns, start=1):
            ws.cell(row=2, column=i, value=example.get(col.key))
    notes = wb.create_sheet("Instructions")
    notes.append(["Column", "Required", "Allowed values / notes"])
    for col in columns:
        notes.append([col.header, "Yes" if col.required else "", ", ".join(col.choices) or col.note])
    notes.column_dimensions["A"].width, notes.column_dimensions["C"].width = 28, 80
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def export(title: str, columns: list[Column], rows: list[dict[str, Any]]) -> bytes:
    wb = Workbook()
    ws = _sheet(wb, title, columns)
    for r in rows:
        ws.append([_cell(r.get(c.key)) for c in columns])
    ws.auto_filter.ref = ws.dimensions
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _cell(v: Any) -> Any:
    if isinstance(v, Decimal):
        return float(v) if v == v.to_integral_value() or abs(v) < Decimal("1e15") else str(v)
    return v


def read(data: bytes, columns: list[Column]) -> list[tuple[int, dict[str, Any]]]:
    """Returns [(excel_row_number, {key: value})], skipping blank rows. Header text must match the template."""
    try:
        wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    except Exception as exc:  # noqa: BLE001
        raise AppError("INVALID_EXCEL", "The file could not be read as an Excel (.xlsx) workbook.") from exc
    ws = wb.worksheets[0]
    rows = ws.iter_rows(values_only=True)
    header = next(rows, None) or ()
    by_header = {c.header.lower(): c for c in columns}
    mapping: dict[int, Column] = {}
    for idx, h in enumerate(header):
        key = str(h or "").replace("*", "").strip().lower()
        if key in by_header:
            mapping[idx] = by_header[key]
    missing = [c.header for c in columns if c.required and c not in mapping.values()]
    if missing:
        raise AppError("TEMPLATE_MISMATCH", f"Missing required column(s): {', '.join(missing)}. Use the template.")
    out = []
    for n, row in enumerate(rows, start=2):
        values = {}
        for idx, col in mapping.items():
            v = row[idx] if idx < len(row) else None
            if isinstance(v, str):
                v = v.strip() or None
            elif isinstance(v, datetime):
                v = v.date()
            elif isinstance(v, float) and v.is_integer():
                v = int(v)
            values[col.key] = v
        if all(v is None for v in values.values()):
            continue
        out.append((n, values))
        if len(out) > MAX_IMPORT_ROWS:
            raise AppError("TOO_MANY_ROWS", f"At most {MAX_IMPORT_ROWS} rows can be imported at once.")
    return out


