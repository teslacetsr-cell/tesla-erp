"""Application settings, loaded from environment variables (never hard-coded).

See `.env.example` at the repository root for every variable.
"""
from functools import lru_cache
from typing import Literal

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

Environment = Literal["development", "test", "staging", "production"]
Deployment = Literal["cloud", "onprem"]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    environment: Environment = "development"
    # cloud  = containers behind a load balancer with S3 (docs/runbooks/deployment.md)
    # onprem = the Windows server package: embedded PostgreSQL, documents on a NAS share (docs/ONPREM.md)
    deployment: Deployment = "cloud"
    app_name: str = "Tesla Consulting Engineers ERP"

    # Database. The application connects with a least-privilege role; migrations use the owner role.
    database_url: str = "postgresql+psycopg://erp_app:dev_app@localhost:5432/tesla_erp"
    migration_database_url: str = "postgresql+psycopg://erp_owner:dev_owner@localhost:5432/tesla_erp"
    db_app_role: str = "erp_app"

    # Security
    secret_key: str = Field(default="dev-only-insecure-secret-change-me-0123456789", min_length=32)
    field_encryption_key: str = Field(
        default="ZGV2LW9ubHktZmllbGQta2V5LWNoYW5nZS1tZS0wMTI=",
        description="Fernet key (urlsafe base64, 32 bytes) for bank accounts, PAN, salary.",
    )
    access_token_minutes: int = 15
    refresh_token_days: int = 7
    cookie_secure: bool = False  # True in staging/production (HTTPS only)
    login_max_failures: int = 5
    login_lockout_minutes: int = 15
    login_rate_limit_per_minute: int = 20
    argon2_time_cost: int = 3
    argon2_memory_kib: int = 65536

    # Object storage
    # s3         = S3 / S3-compatible object storage (cloud)
    # filesystem = a durable folder, normally a NAS share such as \\NAS\TCE-ERP\documents (on-premise)
    # local      = scratch folder for development and tests only
    storage_backend: Literal["s3", "filesystem", "local"] = "local"
    storage_path: str | None = None  # for storage_backend=filesystem
    # AWS: leave blank. Cloudflare R2: https://<ACCOUNT_ID>.r2.cloudflarestorage.com (region "auto"). MinIO: http://minio:9000
    storage_endpoint: str | None = None
    storage_region: str = "ap-south-1"
    # Ask the store to encrypt each object with AES256. AWS S3: yes. Cloudflare R2 encrypts everything at rest
    # itself and rejects this header, so it must be false there.
    storage_sse: bool = True
    storage_bucket: str = "tesla-erp-dev"
    storage_access_key: str | None = None
    storage_secret_key: str | None = None
    storage_local_path: str = "./.storage"
    max_upload_mb: int = 25

    # Initial admin (seed only)
    seed_admin_email: str = "admin@teslace-demo.in"
    seed_admin_password: str = "ChangeMe@12345"

    timezone: str = "Asia/Kolkata"
    trust_proxy_headers: bool = False  # true when running behind the load balancer
    # Built web UI (Next.js static export). When set, the API process also serves the UI — used on-premise.
    frontend_dir: str | None = None
    # On-premise: JSON file where the server supervisor records backup and tunnel status (shown in Settings).
    status_file: str | None = None
    app_version: str = "0.4.0"

    # Off-site database backups (VPS deployment): a separate bucket with its own, backup-only API key.
    backup_bucket: str | None = None
    backup_access_key: str | None = None
    backup_secret_key: str | None = None
    backup_keep_daily: int = 30
    backup_keep_weekly: int = 12
    backup_keep_monthly: int = 24

    @model_validator(mode="after")
    def _guard_production(self) -> "Settings":
        if self.environment in ("staging", "production"):
            if self.storage_backend == "local":
                raise ValueError(
                    "Business documents must not live on scratch storage: STORAGE_BACKEND must be 's3' "
                    "or 'filesystem' (a NAS share) in staging/production."
                )
            if self.storage_backend == "filesystem" and not self.storage_path:
                raise ValueError("STORAGE_PATH is required when STORAGE_BACKEND=filesystem.")
            if self.storage_backend == "s3" and self.storage_endpoint and "r2.cloudflarestorage.com" in self.storage_endpoint \
                    and self.storage_sse:
                raise ValueError("Cloudflare R2 rejects the SSE header: set STORAGE_SSE=false (R2 encrypts at rest itself).")
            if self.deployment == "cloud" and self.storage_backend != "s3":
                raise ValueError("Cloud deployments must use S3 storage (the app servers are disposable).")
            if "dev-only" in self.secret_key or "ZGV2LW9ubHkt" in self.field_encryption_key:
                raise ValueError("SECRET_KEY and FIELD_ENCRYPTION_KEY must be set for staging/production.")
            # On-premise the office network is plain HTTP and remote access arrives over HTTPS through the tunnel;
            # there the Secure cookie flag is set per request from the scheme (see auth/router.py).
            if self.deployment == "cloud" and not self.cookie_secure:
                raise ValueError("COOKIE_SECURE must be true in staging/production.")
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
