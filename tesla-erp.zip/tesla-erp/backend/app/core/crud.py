"""Generic CRUD routes for simple master tables (divisions, departments, brands, units, …).

Each call wires list/create/get/update/delete with permission checks, optimistic locking,
audit records and the standard envelope — so every small master behaves identically.
"""
import uuid
from collections.abc import Callable
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal, require
from app.core.api import ListParams, ok, paginate
from app.core.db import DbSession
from app.core.errors import NotFound
from app.core.models import check_row_version
from app.platform.audit import service as audit


def master_routes(
    router: APIRouter,
    *,
    path: str,
    entity: str,
    model: type,
    perm: str,
    create_schema: type[BaseModel],
    update_schema: type[BaseModel],
    out: Callable[[Any], dict],
    search: tuple[str, ...],
    sortable: tuple[str, ...],
    default_sort: str,
    label: Callable[[Any], str],
    company_scoped: bool = False,
    before_save: Callable[[Session, Principal, Any, BaseModel, bool], None] | None = None,
    read_perm: str | None = None,
) -> None:
    read_code = read_perm or f"{perm}.read"

    def _get(db: Session, item_id: uuid.UUID, p: Principal | None = None):
        obj = db.get(model, item_id)
        if obj is None or (company_scoped and p is not None and obj.company_id != p.company_id):
            raise NotFound(entity)
        return obj

    @router.get(path, name=f"list_{entity}")
    def list_(db: DbSession, p: Annotated[Principal, require(read_code)],
              params: Annotated[ListParams, Depends()], is_active: bool | None = Query(None)):
        stmt = select(model)
        if company_scoped:
            stmt = stmt.where(model.company_id == p.company_id)
        if params.q:
            like = f"%{params.q}%"
            stmt = stmt.where(or_(*[getattr(model, f).ilike(like) for f in search]))
        if is_active is not None and hasattr(model, "is_active"):
            stmt = stmt.where(model.is_active.is_(is_active))
        rows, meta = paginate(db, stmt, params, sortable={s: getattr(model, s) for s in sortable},
                              default_sort=getattr(model, default_sort))
        return {"data": [out(r) for r in rows], "meta": meta.model_dump()}

    @router.post(path, status_code=201, name=f"create_{entity}")
    def create(body: create_schema, db: DbSession, p: Annotated[Principal, require(f"{perm}.create")]):  # type: ignore[valid-type]
        values = body.model_dump()
        obj = model(**values, created_by=p.id, updated_by=p.id)
        if company_scoped:
            obj.company_id = p.company_id
        if before_save:
            before_save(db, p, obj, body, True)
        db.add(obj)
        db.flush()
        audit.record(db, action="create", entity_type=entity, entity_id=obj.id, entity_label=label(obj),
                     after=audit.snapshot(obj))
        return ok(out(obj))

    @router.get(path + "/{item_id}", name=f"get_{entity}")
    def get(item_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require(read_code)]):
        return ok(out(_get(db, item_id, p)))

    @router.put(path + "/{item_id}", name=f"update_{entity}")
    def update(item_id: uuid.UUID, body: update_schema, db: DbSession,  # type: ignore[valid-type]
               p: Annotated[Principal, require(f"{perm}.update")]):
        obj = _get(db, item_id, p)
        before = audit.snapshot(obj)
        values = body.model_dump()
        check_row_version(obj, values.pop("row_version", None))
        for k, v in values.items():
            setattr(obj, k, v)
        obj.updated_by = p.id
        if before_save:
            before_save(db, p, obj, body, False)
        db.flush()
        audit.record(db, action="update", entity_type=entity, entity_id=obj.id, entity_label=label(obj),
                     before=before, after=audit.snapshot(obj))
        return ok(out(obj))

    @router.delete(path + "/{item_id}", name=f"delete_{entity}")
    def delete(item_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require(f"{perm}.delete")]):
        """Hard delete only if nothing references the record; otherwise 409 IN_USE (deactivate instead)."""
        obj = _get(db, item_id, p)
        snap = audit.snapshot(obj)
        with db.begin_nested():
            db.delete(obj)
            db.flush()
        audit.record(db, action="delete", entity_type=entity, entity_id=item_id, entity_label=label(obj), before=snap)
        return ok({"ok": True})
