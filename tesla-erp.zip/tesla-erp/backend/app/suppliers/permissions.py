from app.core.permissions import register

register("supplier", "Suppliers", ("create", "read", "update", "delete", "export", "print"))
register("supplier_bank", "Supplier bank details (full account numbers)", ("read", "update"))
