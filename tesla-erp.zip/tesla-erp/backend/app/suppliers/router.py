"""Supplier master (Spec §9). Mirrors the customer module; bank details are encrypted and masked."""
import uuid
from typing import Annotated, Any

from fastapi import APIRouter, Depends, File, Query, UploadFile
from fastapi.responses import Response
from pydantic import ValidationError
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal, require
from app.core import excel
from app.core.api import ListParams, ok, paginate
from app.core.db import DbSession
from app.core.errors import Conflict, NotFound
from app.core.models import check_row_version
from app.core.security import mask
from app.customers.schemas import ContactIn, ContactOut, ContactUpdate
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.platform.numbering import service as numbering
from app.suppliers.models import SUPPLIER_STATUSES, Supplier, SupplierAddress, SupplierBankAccount, SupplierContact
from app.suppliers.schemas import (
    BankAccountIn,
    BankAccountUpdate,
    SupplierAddressIn,
    SupplierAddressUpdate,
    SupplierIn,
    SupplierListOut,
    SupplierUpdate,
)

router = APIRouter(prefix="/suppliers", tags=["suppliers"])
documents.register_entity("supplier", "supplier", Supplier)

COLUMNS = [
    excel.Column("supplier_code", "Supplier code", 14, note="Leave blank to auto-number"),
    excel.Column("supplier_name", "Supplier name", 32, required=True),
    excel.Column("gstin", "GSTIN", 18),
    excel.Column("pan", "PAN", 12),
    excel.Column("phone", "Phone", 16),
    excel.Column("email", "Email", 26),
    excel.Column("website", "Website", 22),
    excel.Column("address_line1", "Address line 1", 30),
    excel.Column("address_line2", "Address line 2", 30),
    excel.Column("city", "City", 16),
    excel.Column("state", "State", 16),
    excel.Column("state_code", "State code", 10),
    excel.Column("pincode", "PIN code", 10),
    excel.Column("payment_terms", "Payment terms", 30),
    excel.Column("credit_days", "Credit days", 10),
    excel.Column("supplies", "Supplies", 30, note="What this supplier provides"),
    excel.Column("status", "Status", 10, choices=SUPPLIER_STATUSES),
]


def _addr(a: SupplierAddress) -> dict:
    return {k: getattr(a, k) for k in ("address_type", "label", "gstin", "address_line1", "address_line2", "city",
                                        "district", "state", "state_code", "pincode", "country", "is_active",
                                        "row_version")} | {"id": str(a.id)}


def _bank(b: SupplierBankAccount, full: bool) -> dict:
    return {"id": str(b.id), "account_name": b.account_name, "bank_name": b.bank_name,
            "account_number": b.account_number if full else mask(b.account_number), "ifsc": b.ifsc,
            "branch": b.branch, "is_primary": b.is_primary, "is_active": b.is_active, "row_version": b.row_version}


def _detail(p: Principal, s: Supplier) -> dict:
    base = SupplierListOut.model_validate(s).model_dump(mode="json")
    full = p.can("supplier_bank.read")
    return base | {
        "pan": s.pan, "website": s.website, "address_line1": s.address_line1, "address_line2": s.address_line2,
        "district": s.district, "state_code": s.state_code, "pincode": s.pincode, "country": s.country,
        "payment_terms": s.payment_terms, "credit_days": s.credit_days, "notes": s.notes,
        "row_version": s.row_version, "updated_at": s.updated_at.isoformat(),
        "contacts": [ContactOut.model_validate(c).model_dump(mode="json") for c in s.contacts],
        "addresses": [_addr(a) for a in s.addresses],
        "bank_accounts": [_bank(b, full) for b in s.bank_accounts],
        "can_view_bank_details": full,
    }


def _get(db: Session, supplier_id: uuid.UUID, lock: bool = False) -> Supplier:
    s = db.get(Supplier, supplier_id, with_for_update=lock or None)
    if s is None:
        raise NotFound("supplier")
    return s


def _label(s: Supplier) -> str:
    return f"{s.supplier_code} {s.supplier_name}"


def _create(db: Session, p: Principal, data: SupplierIn, allow_duplicate: bool) -> Supplier:
    if data.gstin and not allow_duplicate:
        existing = db.scalar(select(Supplier).where(Supplier.gstin == data.gstin))
        if existing:
            raise Conflict("DUPLICATE_GSTIN", f"{_label(existing)} already has this GSTIN.",
                           details={"supplier_id": str(existing.id)})
    values = data.model_dump()
    code = (values.pop("supplier_code") or "").strip().upper() or numbering.next_free_code(db, p.company_id, "SUPPLIER", Supplier.supplier_code)
    if db.scalar(select(Supplier.id).where(Supplier.supplier_code == code)):
        raise Conflict("DUPLICATE_CODE", f"Supplier code {code} is already used.")
    s = Supplier(supplier_code=code, **values, created_by=p.id, updated_by=p.id)
    db.add(s)
    db.flush()
    audit.record(db, action="create", entity_type="supplier", entity_id=s.id, entity_label=_label(s),
                 after=audit.snapshot(s))
    return s


@router.get("")
def list_suppliers(db: DbSession, _: Annotated[Principal, require("supplier.read")],
                   params: Annotated[ListParams, Depends()], status: str | None = None):
    stmt = select(Supplier)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(Supplier.supplier_name.ilike(like), Supplier.supplier_code.ilike(like),
                              Supplier.gstin.ilike(like), Supplier.phone.ilike(like), Supplier.supplies.ilike(like),
                              Supplier.city.ilike(like), Supplier.email.ilike(like)))
    if status:
        stmt = stmt.where(Supplier.status == status)
    rows, meta = paginate(db, stmt, params, default_sort=Supplier.supplier_name, sortable={
        "supplier_name": Supplier.supplier_name, "supplier_code": Supplier.supplier_code, "city": Supplier.city,
        "rating": Supplier.rating, "created_at": Supplier.created_at})
    return {"data": [SupplierListOut.model_validate(r).model_dump(mode="json") for r in rows],
            "meta": meta.model_dump()}


@router.get("/import-template")
def import_template(_: Annotated[Principal, require("supplier.create")]):
    data = excel.template("Suppliers", COLUMNS, example={
        "supplier_name": "DEHN India Pvt Ltd", "supplies": "Surge protection, lightning protection",
        "state_code": "29", "status": "active"})
    return Response(data, media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="supplier-import-template.xlsx"'})


@router.post("/import")
async def import_suppliers(db: DbSession, p: Annotated[Principal, require("supplier.create")],
                           file: UploadFile = File(...), dry_run: bool = Query(True)):
    rows = excel.read(await file.read(), COLUMNS)
    errors: list[dict[str, Any]] = []
    valid: list[SupplierIn] = []
    seen: set[str] = set()
    for n, raw in rows:
        raw = {k: (str(v) if k in ("phone", "pincode", "state_code", "supplier_code") and v is not None else v)
               for k, v in raw.items()}
        if isinstance(raw.get("status"), str):
            raw["status"] = raw["status"].lower()
        try:
            item = SupplierIn.model_validate({k: v for k, v in raw.items() if v is not None})
        except ValidationError as exc:
            errors += [{"row": n, "field": ".".join(map(str, e["loc"])), "message": e["msg"]} for e in exc.errors()]
            continue
        key = item.gstin or ""
        if key and (key in seen or db.scalar(select(Supplier.id).where(Supplier.gstin == key))):
            errors.append({"row": n, "field": "gstin", "message": "A supplier with this GSTIN already exists."})
            continue
        seen.add(key)
        valid.append(item)
    created = 0
    if not dry_run and not errors:
        for item in valid:
            _create(db, p, item, allow_duplicate=True)
            created += 1
        audit.record(db, action="import", entity_type="supplier", summary=f"Imported {created} suppliers")
    return ok({"rows": len(rows), "valid": len(valid), "errors": errors, "created": created,
               "committed": not dry_run and not errors})


@router.get("/export")
def export_suppliers(db: DbSession, _: Annotated[Principal, require("supplier.export")]):
    rows = db.scalars(select(Supplier).order_by(Supplier.supplier_name)).all()
    data = [{c.key: getattr(r, c.key, None) for c in COLUMNS} for r in rows]
    audit.record(db, action="export", entity_type="supplier", summary=f"Exported {len(data)} suppliers")
    return Response(excel.export("Suppliers", COLUMNS, data), media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="suppliers.xlsx"'})


@router.post("", status_code=201)
def create_supplier(body: SupplierIn, db: DbSession, p: Annotated[Principal, require("supplier.create")],
                    allow_duplicate: bool = Query(False)):
    return ok(_detail(p, _create(db, p, body, allow_duplicate)))


@router.get("/{supplier_id}")
def get_supplier(supplier_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("supplier.read")]):
    return ok(_detail(p, _get(db, supplier_id)))


@router.put("/{supplier_id}")
def update_supplier(supplier_id: uuid.UUID, body: SupplierUpdate, db: DbSession,
                    p: Annotated[Principal, require("supplier.update")], allow_duplicate: bool = Query(False)):
    s = _get(db, supplier_id, lock=True)
    if body.gstin and body.gstin != s.gstin and not allow_duplicate:
        existing = db.scalar(select(Supplier).where(Supplier.gstin == body.gstin, Supplier.id != s.id))
        if existing:
            raise Conflict("DUPLICATE_GSTIN", f"{_label(existing)} already has this GSTIN.")
    before = audit.snapshot(s)
    values = body.model_dump()
    check_row_version(s, values.pop("row_version"))
    code = (values.pop("supplier_code") or "").strip().upper()
    if code and code != s.supplier_code:
        if db.scalar(select(Supplier.id).where(Supplier.supplier_code == code)):
            raise Conflict("DUPLICATE_CODE", f"Supplier code {code} is already used.")
        s.supplier_code = code
    for k, v in values.items():
        setattr(s, k, v)
    s.updated_by = p.id
    db.flush()
    audit.record(db, action="update", entity_type="supplier", entity_id=s.id, entity_label=_label(s),
                 before=before, after=audit.snapshot(s))
    return ok(_detail(p, s))


@router.delete("/{supplier_id}")
def delete_supplier(supplier_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("supplier.delete")]):
    s = _get(db, supplier_id, lock=True)
    snap, label = audit.snapshot(s), _label(s)
    with db.begin_nested():
        db.delete(s)
        db.flush()
    audit.record(db, action="delete", entity_type="supplier", entity_id=supplier_id, entity_label=label, before=snap)
    return ok({"ok": True})


# ---- child records
CHILD = {
    "contacts": (SupplierContact, "supplier_contact", "supplier.update"),
    "addresses": (SupplierAddress, "supplier_address", "supplier.update"),
    "bank-accounts": (SupplierBankAccount, "supplier_bank_account", "supplier_bank.update"),
}


def _child_out(kind: str, obj, p: Principal) -> dict:
    if kind == "contacts":
        return ContactOut.model_validate(obj).model_dump(mode="json")
    if kind == "addresses":
        return _addr(obj)
    return _bank(obj, p.can("supplier_bank.read"))


def _child_routes(kind: str, in_schema, update_schema):
    model, entity, perm = CHILD[kind]

    @router.post(f"/{{supplier_id}}/{kind}", status_code=201, name=f"add_supplier_{kind}")
    def add(supplier_id: uuid.UUID, body: in_schema, db: DbSession,  # type: ignore[valid-type]
            p: Annotated[Principal, require(perm)]):
        s = _get(db, supplier_id, lock=True)
        obj = model(supplier_id=s.id, **body.model_dump(), created_by=p.id, updated_by=p.id)
        if getattr(obj, "is_primary", False):
            for other in (s.contacts if kind == "contacts" else s.bank_accounts if kind == "bank-accounts" else []):
                other.is_primary = False
        db.add(obj)
        db.flush()
        audit.record(db, action="create", entity_type=entity, entity_id=obj.id, entity_label=s.supplier_code,
                     after=audit.snapshot(obj))
        return ok(_child_out(kind, obj, p))

    @router.put(f"/{{supplier_id}}/{kind}/{{child_id}}", name=f"update_supplier_{kind}")
    def upd(supplier_id: uuid.UUID, child_id: uuid.UUID, body: update_schema, db: DbSession,  # type: ignore[valid-type]
            p: Annotated[Principal, require(perm)]):
        s = _get(db, supplier_id, lock=True)
        obj = db.get(model, child_id)
        if obj is None or obj.supplier_id != s.id:
            raise NotFound(entity)
        before = audit.snapshot(obj)
        values = body.model_dump()
        check_row_version(obj, values.pop("row_version"))
        for k, v in values.items():
            setattr(obj, k, v)
        if getattr(obj, "is_primary", False):
            for other in (s.contacts if kind == "contacts" else s.bank_accounts if kind == "bank-accounts" else []):
                if other.id != obj.id:
                    other.is_primary = False
        obj.updated_by = p.id
        db.flush()
        audit.record(db, action="update", entity_type=entity, entity_id=obj.id, entity_label=s.supplier_code,
                     before=before, after=audit.snapshot(obj))
        return ok(_child_out(kind, obj, p))

    @router.delete(f"/{{supplier_id}}/{kind}/{{child_id}}", name=f"delete_supplier_{kind}")
    def rm(supplier_id: uuid.UUID, child_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require(perm)]):
        s = _get(db, supplier_id, lock=True)
        obj = db.get(model, child_id)
        if obj is None or obj.supplier_id != s.id:
            raise NotFound(entity)
        snap = audit.snapshot(obj)
        with db.begin_nested():
            db.delete(obj)
            db.flush()
        audit.record(db, action="delete", entity_type=entity, entity_id=child_id, entity_label=s.supplier_code,
                     before=snap)
        return ok({"ok": True})


_child_routes("contacts", ContactIn, ContactUpdate)
_child_routes("addresses", SupplierAddressIn, SupplierAddressUpdate)
_child_routes("bank-accounts", BankAccountIn, BankAccountUpdate)
