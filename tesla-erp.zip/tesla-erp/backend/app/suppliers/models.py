import uuid
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, ForeignKey, Index, Numeric, SmallInteger, String, Text
from sqlalchemy.dialects.postgresql import CITEXT
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.models import AuditColumnsMixin, Base
from app.core.security import EncryptedString
from app.customers.models import AddressColumns

SUPPLIER_STATUSES = ("active", "inactive", "blocked")


class Supplier(AuditColumnsMixin, AddressColumns, Base):
    """Supplier master (Spec §9). Address columns are the registered/billing address."""

    __tablename__ = "suppliers"
    __table_args__ = (
        CheckConstraint(f"status in {SUPPLIER_STATUSES}", name="status_valid"),
        CheckConstraint("rating is null or (rating >= 0 and rating <= 5)", name="rating_range"),
        Index("ix_suppliers_name_trgm", "supplier_name", postgresql_using="gin",
              postgresql_ops={"supplier_name": "gin_trgm_ops"}),
        Index("ix_suppliers_gstin", "gstin"),
    )

    supplier_code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    supplier_name: Mapped[str] = mapped_column(String(200), nullable=False)
    gstin: Mapped[str | None] = mapped_column(String(15))
    pan: Mapped[str | None] = mapped_column(String(10))
    phone: Mapped[str | None] = mapped_column(String(30))
    email: Mapped[str | None] = mapped_column(CITEXT)
    website: Mapped[str | None] = mapped_column(String(200))
    payment_terms: Mapped[str | None] = mapped_column(String(300))
    credit_days: Mapped[int | None] = mapped_column(SmallInteger)
    supplies: Mapped[str | None] = mapped_column(String(300))  # what they supply, free text
    rating: Mapped[Decimal | None] = mapped_column(Numeric(2, 1))
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="active", server_default="active")
    notes: Mapped[str | None] = mapped_column(Text)

    contacts: Mapped[list["SupplierContact"]] = relationship(
        back_populates="supplier", cascade="all, delete-orphan", order_by="SupplierContact.created_at", lazy="selectin")
    addresses: Mapped[list["SupplierAddress"]] = relationship(
        back_populates="supplier", cascade="all, delete-orphan", order_by="SupplierAddress.created_at", lazy="selectin")
    bank_accounts: Mapped[list["SupplierBankAccount"]] = relationship(
        back_populates="supplier", cascade="all, delete-orphan", order_by="SupplierBankAccount.created_at", lazy="selectin")


class SupplierContact(AuditColumnsMixin, Base):
    __tablename__ = "supplier_contacts"

    supplier_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("suppliers.id", ondelete="CASCADE"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    designation: Mapped[str | None] = mapped_column(String(100))
    phone: Mapped[str | None] = mapped_column(String(30))
    email: Mapped[str | None] = mapped_column(CITEXT)
    is_primary: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")

    supplier: Mapped[Supplier] = relationship(back_populates="contacts")


class SupplierAddress(AuditColumnsMixin, AddressColumns, Base):
    __tablename__ = "supplier_addresses"
    __table_args__ = (CheckConstraint("address_type in ('dispatch','office','warehouse','other')", name="type_valid"),)

    supplier_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("suppliers.id", ondelete="CASCADE"), nullable=False, index=True)
    address_type: Mapped[str] = mapped_column(String(20), nullable=False, default="dispatch")
    label: Mapped[str | None] = mapped_column(String(100))
    gstin: Mapped[str | None] = mapped_column(String(15))
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")

    supplier: Mapped[Supplier] = relationship(back_populates="addresses")


class SupplierBankAccount(AuditColumnsMixin, Base):
    """Account number encrypted at rest and masked in the API unless the user may see it in full."""

    __tablename__ = "supplier_bank_accounts"

    supplier_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("suppliers.id", ondelete="CASCADE"), nullable=False, index=True)
    account_name: Mapped[str] = mapped_column(String(200), nullable=False)
    bank_name: Mapped[str] = mapped_column(String(150), nullable=False)
    account_number: Mapped[str] = mapped_column(EncryptedString(255), nullable=False)
    ifsc: Mapped[str] = mapped_column(String(11), nullable=False)
    branch: Mapped[str | None] = mapped_column(String(150))
    is_primary: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")

    supplier: Mapped[Supplier] = relationship(back_populates="bank_accounts")
