import uuid
from datetime import datetime
from decimal import Decimal
from typing import Literal

from pydantic import EmailStr, Field, model_validator

from app.core.api import Schema
from app.core.validators import GSTIN, IFSC, PAN, Phone, Text, check_tax_identity
from app.customers.schemas import AddressIn, ContactIn, ContactOut, ContactUpdate  # noqa: F401 - shared shapes
from app.suppliers.models import SUPPLIER_STATUSES

SupplierStatus = Literal[SUPPLIER_STATUSES]  # type: ignore[valid-type]


class SupplierIn(AddressIn):
    supplier_code: Text(20) = Field(default=None, description="Leave blank to auto-number")
    supplier_name: str = Field(min_length=2, max_length=200)
    gstin: GSTIN = None
    pan: PAN = None
    phone: Phone = None
    email: EmailStr | None = None
    website: Text(200) = None
    payment_terms: Text(300) = None
    credit_days: int | None = Field(default=None, ge=0, le=365)
    supplies: Text(300) = None
    rating: Decimal | None = Field(default=None, ge=0, le=5, decimal_places=1)
    status: SupplierStatus = "active"
    notes: Text(4000) = None

    @model_validator(mode="after")
    def _identity(self):
        for k, v in check_tax_identity(self.gstin, self.pan, self.state_code).items():
            setattr(self, k, v)
        return self


class SupplierUpdate(SupplierIn):
    row_version: int


class SupplierAddressIn(AddressIn):
    address_type: Literal["dispatch", "office", "warehouse", "other"] = "dispatch"
    label: Text(100) = None
    gstin: GSTIN = None
    is_active: bool = True


class SupplierAddressUpdate(SupplierAddressIn):
    row_version: int


class BankAccountIn(Schema):
    account_name: str = Field(min_length=2, max_length=200)
    bank_name: str = Field(min_length=2, max_length=150)
    account_number: str = Field(pattern=r"^[0-9]{6,18}$")
    ifsc: IFSC
    branch: Text(150) = None
    is_primary: bool = False
    is_active: bool = True

    @model_validator(mode="after")
    def _ifsc_required(self):
        if not self.ifsc:
            raise ValueError("IFSC is required.")
        return self


class BankAccountUpdate(BankAccountIn):
    row_version: int


class SupplierListOut(Schema):
    id: uuid.UUID
    supplier_code: str
    supplier_name: str
    gstin: str | None
    phone: str | None
    email: str | None
    city: str | None
    state: str | None
    supplies: str | None
    rating: Decimal | None
    status: str
    created_at: datetime
