"""Team chat API. New messages are fetched by polling (`after_id` + `since`) — no websockets, so it works the same
behind Caddy, Cloudflare or a plain LAN."""
import uuid
from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, File, Query, UploadFile
from fastapi.responses import Response
from pydantic import Field
from sqlalchemy import func, select

from app.auth.deps import Principal, require
from app.chat import service
from app.core.api import Schema, ok
from app.core.db import DbSession
from app.core.errors import AppError
from app.platform.documents.storage import get_storage
from app.users.models import User

router = APIRouter(prefix="/chat", tags=["chat"])
Chat = Annotated[Principal, require("chat.use")]


class GroupIn(Schema):
    name: str = Field(min_length=1, max_length=120)
    description: str | None = Field(default=None, max_length=300)
    member_ids: list[uuid.UUID] = Field(default_factory=list, max_length=200)


class RenameIn(Schema):
    name: str = Field(min_length=1, max_length=120)
    description: str | None = Field(default=None, max_length=300)


class MembersIn(Schema):
    user_ids: list[uuid.UUID] = Field(min_length=1, max_length=200)


class DirectIn(Schema):
    user_id: uuid.UUID


class MessageIn(Schema):
    body: str = Field(default="", max_length=service.MAX_BODY + 100)
    reply_to_id: int | None = None
    attachment_ids: list[uuid.UUID] = Field(default_factory=list, max_length=service.MAX_ATTACHMENTS)
    mention_ids: list[uuid.UUID] = Field(default_factory=list, max_length=50)


class EditIn(Schema):
    body: str = Field(default="", max_length=service.MAX_BODY + 100)
    mention_ids: list[uuid.UUID] = Field(default_factory=list, max_length=50)


class ReadIn(Schema):
    last_id: int | None = None


def _server_time(db) -> str:
    return db.scalar(select(func.clock_timestamp())).isoformat()


# ------------------------------------------------------------------ channels
@router.get("/channels")
def channels(db: DbSession, p: Chat):
    data = service.list_channels(db, p)
    return ok(data, unread=sum(c["unread"] for c in data))


@router.get("/unread")
def unread(db: DbSession, p: Chat):
    return ok({"unread": service.total_unread(db, p)})


@router.get("/people")
def people(db: DbSession, p: Chat, q: str | None = Query(None, max_length=100)):
    stmt = select(User.id, User.full_name, User.username).where(User.is_active.is_(True))
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(User.full_name.ilike(like) | User.username.ilike(like))
    rows = db.execute(stmt.order_by(User.full_name).limit(300)).all()
    return ok([{"id": str(r.id), "full_name": r.full_name, "username": r.username, "me": r.id == p.id} for r in rows])


@router.post("/channels", status_code=201)
def create_group(body: GroupIn, db: DbSession, p: Chat):
    ch = service.create_group(db, p, body.name, body.member_ids, body.description)
    return ok(service.channel_detail(db, p, ch))


@router.post("/direct")
def direct(body: DirectIn, db: DbSession, p: Chat):
    ch = service.direct(db, p, body.user_id)
    return ok(service.channel_detail(db, p, ch))


@router.post("/projects/{project_id}")
def project_channel(project_id: uuid.UUID, db: DbSession, p: Chat):
    ch = service.project_channel(db, p, project_id)
    return ok(service.channel_detail(db, p, ch))


@router.get("/channels/{channel_id}")
def channel(channel_id: uuid.UUID, db: DbSession, p: Chat):
    ch, _ = service.channel_for(db, p, channel_id)
    return ok(service.channel_detail(db, p, ch))


@router.put("/channels/{channel_id}")
def rename(channel_id: uuid.UUID, body: RenameIn, db: DbSession, p: Chat):
    ch, _ = service.channel_for(db, p, channel_id, write=True)
    service.rename(db, p, ch, body.name, body.description)
    return ok(service.channel_detail(db, p, ch))


@router.delete("/channels/{channel_id}")
def archive(channel_id: uuid.UUID, db: DbSession, p: Chat):
    ch, _ = service.channel_for(db, p, channel_id, write=True)
    service.archive(db, p, ch)
    return ok({"ok": True})


@router.post("/channels/{channel_id}/members")
def add_members(channel_id: uuid.UUID, body: MembersIn, db: DbSession, p: Chat):
    ch, _ = service.channel_for(db, p, channel_id, write=True)
    service.add_members(db, p, ch, body.user_ids)
    return ok(service.channel_detail(db, p, ch))


@router.delete("/channels/{channel_id}/members/{user_id}")
def remove_member(channel_id: uuid.UUID, user_id: uuid.UUID, db: DbSession, p: Chat):
    ch, _ = service.channel_for(db, p, channel_id, write=True)
    service.remove_member(db, p, ch, user_id)
    return ok({"ok": True})


@router.post("/channels/{channel_id}/leave")
def leave(channel_id: uuid.UUID, db: DbSession, p: Chat):
    ch, _ = service.channel_for(db, p, channel_id)
    service.leave(db, p, ch)
    return ok({"ok": True})


@router.post("/channels/{channel_id}/read")
def mark_read(channel_id: uuid.UUID, body: ReadIn, db: DbSession, p: Chat):
    ch, m = service.channel_for(db, p, channel_id)
    return ok({"last_read_id": service.mark_read(db, ch, m, body.last_id)})


# ------------------------------------------------------------------ messages
@router.get("/channels/{channel_id}/messages")
def messages(channel_id: uuid.UUID, db: DbSession, p: Chat,
             before_id: int | None = Query(None, ge=1), after_id: int | None = Query(None, ge=0),
             around_id: int | None = Query(None, ge=1), since: datetime | None = None,
             limit: int = Query(service.PAGE, ge=1, le=100)):
    ch, m = service.channel_for(db, p, channel_id)
    server_time = _server_time(db)
    rows, has_older = service.list_messages(db, ch, before_id=before_id, after_id=after_id, around_id=around_id,
                                            since=since, limit=limit)
    return ok(service.messages_out(db, p, rows), has_older=has_older, server_time=server_time,
              last_read_id=m.last_read_id, last_message_id=ch.last_message_id or 0)


@router.post("/channels/{channel_id}/messages", status_code=201)
def post(channel_id: uuid.UUID, body: MessageIn, db: DbSession, p: Chat):
    ch, _ = service.channel_for(db, p, channel_id, write=True)
    msg = service.post(db, p, ch, body=body.body, reply_to_id=body.reply_to_id, attachment_ids=body.attachment_ids,
                       mention_ids=body.mention_ids)
    return ok(service.messages_out(db, p, [msg])[0])


@router.put("/channels/{channel_id}/messages/{message_id}")
def edit(channel_id: uuid.UUID, message_id: int, body: EditIn, db: DbSession, p: Chat):
    ch, _ = service.channel_for(db, p, channel_id, write=True)
    msg = service.get_message(db, ch, message_id, lock=True)
    service.edit(db, p, ch, msg, body.body, body.mention_ids)
    return ok(service.messages_out(db, p, [msg])[0])


@router.delete("/channels/{channel_id}/messages/{message_id}")
def delete(channel_id: uuid.UUID, message_id: int, db: DbSession, p: Chat):
    ch, _ = service.channel_for(db, p, channel_id)
    msg = service.get_message(db, ch, message_id, lock=True)
    service.delete(db, p, ch, msg)
    return ok(service.messages_out(db, p, [msg])[0])


@router.get("/channels/{channel_id}/search")
def search(channel_id: uuid.UUID, db: DbSession, p: Chat, q: str = Query(min_length=2, max_length=100)):
    ch, _ = service.channel_for(db, p, channel_id)
    return ok(service.messages_out(db, p, service.search(db, ch, q.strip())))


# ------------------------------------------------------------------ attachments
@router.post("/channels/{channel_id}/attachments", status_code=201)
async def upload(channel_id: uuid.UUID, db: DbSession, p: Chat, file: UploadFile = File(...)):
    ch, _ = service.channel_for(db, p, channel_id, write=True)
    data = await file.read()
    a, doc = service.upload(db, p, ch, file.filename or "file", data)
    return ok(service.attachment_out(a, doc))


@router.get("/attachments/{document_id}")
def attachment(document_id: uuid.UUID, db: DbSession, p: Chat, thumb: bool = False, inline: bool = False):
    a, doc = service.attachment_for(db, p, document_id)
    storage = get_storage()
    if thumb:
        if not a.thumb_key:
            raise AppError("NO_PREVIEW", "This file has no preview.", status_code=404)
        return Response(storage.get(a.thumb_key), media_type="image/jpeg",
                        headers={"Cache-Control": "private, max-age=86400"})
    safe = doc.file_name.replace('"', "")
    disposition = "inline" if inline and doc.content_type in (*service.IMAGE_TYPES, "application/pdf") else "attachment"
    return Response(storage.get(doc.storage_key), media_type=doc.content_type,
                    headers={"Content-Disposition": f'{disposition}; filename="{safe}"',
                             "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff"})

