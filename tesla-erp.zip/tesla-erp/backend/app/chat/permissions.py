from app.core.permissions import register

# Team chat. 'use' = read and post in the channels you belong to, start direct messages and groups.
# 'moderate' = delete anyone's message (audited), rename or close any group channel.
register("chat", "Team chat", ("use", "moderate"))
