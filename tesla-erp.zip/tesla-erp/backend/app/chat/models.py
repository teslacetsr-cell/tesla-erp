"""Team chat: channels (company-wide, groups, direct messages, project rooms), members, messages, attachments.

Messages use an increasing bigint id so "load older" and "anything new?" are simple id comparisons, and a
member's read position is just the last message id they have seen.
"""
import uuid
from datetime import datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Identity,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.models import AuditColumnsMixin, Base

CHANNEL_KINDS = ("company", "group", "direct", "project")


class ChatChannel(AuditColumnsMixin, Base):
    """`company` = the one channel everybody with a login is in (membership is implicit).
    `direct` = 1:1 conversation, identified by `direct_key` (the two user ids, sorted).
    `project` = room for a project team, one per project."""

    __tablename__ = "chat_channels"
    __table_args__ = (
        CheckConstraint("kind in ('company', 'group', 'direct', 'project')", name="kind_valid"),
        Index("uq_chat_channels_company", "kind", unique=True, postgresql_where="kind = 'company'"),
    )

    kind: Mapped[str] = mapped_column(String(10), nullable=False)
    name: Mapped[str | None] = mapped_column(String(120))
    description: Mapped[str | None] = mapped_column(String(300))
    direct_key: Mapped[str | None] = mapped_column(String(80), unique=True)
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), unique=True)
    is_archived: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    last_message_id: Mapped[int | None] = mapped_column(BigInteger)
    last_message_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class ChatMember(Base):
    """Membership and read position. For the company channel a row is created the first time the user opens chat."""

    __tablename__ = "chat_members"
    __table_args__ = (UniqueConstraint("channel_id", "user_id"), Index("ix_chat_members_user_id", "user_id"))

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    channel_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("chat_channels.id", ondelete="CASCADE"), nullable=False)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    last_read_id: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0, server_default="0")
    joined_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    added_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))


class ChatMessage(Base):
    __tablename__ = "chat_messages"
    __table_args__ = (
        Index("ix_chat_messages_channel_id_id", "channel_id", "id"),
        Index("ix_chat_messages_channel_updated", "channel_id", "updated_at"),
        CheckConstraint("char_length(body) <= 4000", name="body_length"),
    )

    id: Mapped[int] = mapped_column(BigInteger, Identity(always=False), primary_key=True)
    channel_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("chat_channels.id", ondelete="CASCADE"), nullable=False)
    sender_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False, default="", server_default="")
    reply_to_id: Mapped[int | None] = mapped_column(ForeignKey("chat_messages.id", ondelete="SET NULL"))
    mentions: Mapped[list | None] = mapped_column(JSONB)  # user ids (strings) mentioned with @
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    # Bumped on edit/delete so open chat windows pick the change up on their next poll.
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    edited_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    deleted_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))


class ChatAttachment(Base):
    """A file or photo on a message. The bytes and metadata live in `documents` (entity_type 'chat_channel',
    entity_id = channel), so storage backends, size limits and type checks are the same as everywhere else.
    `message_id` is empty between upload and send."""

    __tablename__ = "chat_attachments"
    __table_args__ = (Index("ix_chat_attachments_message_id", "message_id"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    channel_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("chat_channels.id", ondelete="CASCADE"), nullable=False,
                                                  index=True)
    message_id: Mapped[int | None] = mapped_column(ForeignKey("chat_messages.id", ondelete="CASCADE"))
    document_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("documents.id", ondelete="RESTRICT"), nullable=False,
                                                   unique=True)
    thumb_key: Mapped[str | None] = mapped_column(String(500))
    width: Mapped[int | None] = mapped_column(Integer)
    height: Mapped[int | None] = mapped_column(Integer)
    uploaded_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
