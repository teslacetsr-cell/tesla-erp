"""Team chat business rules: who may see which channel, posting, editing, deleting, unread counts, attachments."""
import io
import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy import and_, func, or_, select, update
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.chat.models import ChatAttachment, ChatChannel, ChatMember, ChatMessage
from app.core.errors import AppError, Forbidden, NotFound
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.platform.documents.models import Document
from app.platform.documents.storage import get_storage
from app.platform.notifications.service import notify
from app.users.models import User

COMPANY_CHANNEL_NAME = "Tesla Team"
MAX_BODY = 4000
MAX_ATTACHMENTS = 10
EDIT_WINDOW = timedelta(minutes=15)
IMAGE_TYPES = ("image/jpeg", "image/png", "image/webp")
PAGE = 40


def now() -> datetime:
    return datetime.now(UTC)


# ------------------------------------------------------------------ channels & membership
def ensure_company_channel(db: Session, user_id: uuid.UUID | None = None) -> ChatChannel:
    ch = db.scalar(select(ChatChannel).where(ChatChannel.kind == "company"))
    if ch is None:
        ch = ChatChannel(kind="company", name=COMPANY_CHANNEL_NAME,
                         description="Everyone in the company. Share news, ask questions, say hello.",
                         created_by=user_id, updated_by=user_id)
        db.add(ch)
        db.flush()
    return ch


def _member(db: Session, channel_id: uuid.UUID, user_id: uuid.UUID) -> ChatMember | None:
    return db.scalar(select(ChatMember).where(ChatMember.channel_id == channel_id, ChatMember.user_id == user_id))


def _add_member(db: Session, ch: ChatChannel, user_id: uuid.UUID, added_by: uuid.UUID | None) -> ChatMember:
    m = _member(db, ch.id, user_id)
    if m is None:
        # New members can scroll back through the history, but only messages after they joined count as unread.
        # ON CONFLICT: two browser tabs may open chat for the first time at the same moment.
        db.execute(pg_insert(ChatMember).values(
            id=uuid.uuid4(), channel_id=ch.id, user_id=user_id, added_by=added_by, last_read_id=ch.last_message_id or 0,
        ).on_conflict_do_nothing(index_elements=["channel_id", "user_id"]))
        m = _member(db, ch.id, user_id)
    return m


def _require_use(p: Principal) -> None:
    if not p.can("chat.use"):
        raise Forbidden("You do not have access to team chat.")


def channel_for(db: Session, p: Principal, channel_id: uuid.UUID, *, write: bool = False) -> tuple[ChatChannel, ChatMember]:
    """The channel, if the user is a member. Everybody is a member of the company channel."""
    _require_use(p)
    ch = db.get(ChatChannel, channel_id)
    if ch is None or ch.is_archived:
        raise NotFound("chat_channel")
    if ch.kind == "company":
        m = _add_member(db, ch, p.id, None)
    else:
        m = _member(db, ch.id, p.id)
        if m is None:
            raise Forbidden("You are not a member of this conversation.", code="NOT_A_MEMBER")
    if write and not p.user.is_active:
        raise Forbidden("Your login is deactivated.")
    return ch, m


def member_ids(db: Session, ch: ChatChannel) -> list[uuid.UUID]:
    if ch.kind == "company":
        return list(db.scalars(select(User.id).where(User.is_active.is_(True))))
    return list(db.scalars(select(ChatMember.user_id).where(ChatMember.channel_id == ch.id)))


def _names(db: Session, ids) -> dict[uuid.UUID, str]:
    ids = {i for i in ids if i}
    if not ids:
        return {}
    return dict(db.execute(select(User.id, User.full_name).where(User.id.in_(ids))).all())


def _active_user(db: Session, user_id: uuid.UUID) -> User:
    u = db.get(User, user_id)
    if u is None or not u.is_active:
        raise AppError("USER_NOT_AVAILABLE", "That person does not have an active login.")
    return u


def _label(db: Session, ch: ChatChannel, viewer_id: uuid.UUID | None = None) -> str:
    if ch.kind != "direct":
        return ch.name or "Conversation"
    ids = [uuid.UUID(x) for x in (ch.direct_key or "").split(":") if x]
    other = [i for i in ids if i != viewer_id] or ids
    return _names(db, other).get(other[0], "Direct message") if other else "Direct message"


def unread_by_channel(db: Session, user_id: uuid.UUID) -> dict[uuid.UUID, int]:
    rows = db.execute(
        select(ChatMessage.channel_id, func.count())
        .join(ChatMember, and_(ChatMember.channel_id == ChatMessage.channel_id, ChatMember.user_id == user_id))
        .join(ChatChannel, ChatChannel.id == ChatMessage.channel_id)
        .where(ChatMessage.id > ChatMember.last_read_id, ChatMessage.sender_id != user_id,
               ChatMessage.deleted_at.is_(None), ChatChannel.is_archived.is_(False))
        .group_by(ChatMessage.channel_id)).all()
    return dict(rows)


def total_unread(db: Session, p: Principal) -> int:
    if not p.can("chat.use"):
        return 0
    ch = ensure_company_channel(db)
    _add_member(db, ch, p.id, None)
    return sum(unread_by_channel(db, p.id).values())


def list_channels(db: Session, p: Principal) -> list[dict]:
    _require_use(p)
    company = ensure_company_channel(db)
    _add_member(db, company, p.id, None)
    chans = list(db.scalars(
        select(ChatChannel).join(ChatMember, ChatMember.channel_id == ChatChannel.id)
        .where(ChatMember.user_id == p.id, ChatChannel.is_archived.is_(False))))
    unread = unread_by_channel(db, p.id)
    last_ids = [c.last_message_id for c in chans if c.last_message_id]
    lasts = {m.id: m for m in db.scalars(select(ChatMessage).where(ChatMessage.id.in_(last_ids)))} if last_ids else {}
    names = _names(db, [m.sender_id for m in lasts.values()])
    counts = dict(db.execute(select(ChatMember.channel_id, func.count()).where(
        ChatMember.channel_id.in_([c.id for c in chans])).group_by(ChatMember.channel_id)).all())
    active_users = db.scalar(select(func.count()).select_from(User).where(User.is_active.is_(True))) or 0
    out = []
    for c in chans:
        last = lasts.get(c.last_message_id) if c.last_message_id else None
        preview = None
        if last is not None:
            text = "Message deleted" if last.deleted_at else (last.body or "📎 Attachment")
            preview = {"sender": names.get(last.sender_id, ""), "text": text[:120], "mine": last.sender_id == p.id}
        out.append({
            "id": str(c.id), "kind": c.kind, "name": _label(db, c, p.id), "description": c.description,
            "project_id": str(c.project_id) if c.project_id else None,
            "unread": unread.get(c.id, 0), "last_message_at": c.last_message_at.isoformat() if c.last_message_at else None,
            "last_message": preview,
            "member_count": active_users if c.kind == "company" else counts.get(c.id, 0),
        })
    # company channel first, then most recent activity
    out.sort(key=lambda x: (x["kind"] != "company", -(datetime.fromisoformat(x["last_message_at"]).timestamp()
                                                       if x["last_message_at"] else 0)))
    return out


def channel_detail(db: Session, p: Principal, ch: ChatChannel) -> dict:
    ids = member_ids(db, ch)
    users = db.execute(select(User.id, User.full_name, User.username, User.is_active).where(User.id.in_(ids))
                       .order_by(User.full_name)).all() if ids else []
    is_owner = ch.created_by == p.id
    manage = ch.kind in ("group", "project") and (is_owner or p.can("chat.moderate"))
    return {
        "id": str(ch.id), "kind": ch.kind, "name": _label(db, ch, p.id), "description": ch.description,
        "project_id": str(ch.project_id) if ch.project_id else None,
        "created_by": str(ch.created_by) if ch.created_by else None,
        "members": [{"id": str(u.id), "full_name": u.full_name, "username": u.username, "is_active": u.is_active}
                    for u in users],
        "can_rename": manage, "can_archive": ch.kind == "group" and manage,
        "can_add_members": ch.kind == "group", "can_remove_members": manage and ch.kind == "group",
        "can_leave": ch.kind in ("group", "project"),
    }


def create_group(db: Session, p: Principal, name: str, members: list[uuid.UUID], description: str | None = None
                 ) -> ChatChannel:
    _require_use(p)
    name = name.strip()
    if not name:
        raise AppError("NAME_REQUIRED", "Give the group a name.")
    ch = ChatChannel(kind="group", name=name[:120], description=description, created_by=p.id, updated_by=p.id)
    db.add(ch)
    db.flush()
    ids = {p.id, *members}
    for uid in ids:
        if uid != p.id:
            _active_user(db, uid)
        _add_member(db, ch, uid, p.id)
    names = _names(db, ids)
    audit.record(db, action="create", entity_type="chat_channel", entity_id=ch.id, entity_label=ch.name,
                 summary=f"Created chat group '{ch.name}' with {', '.join(sorted(names.values()))}")
    return ch


def _manage(p: Principal, ch: ChatChannel) -> None:
    if ch.kind not in ("group", "project"):
        raise AppError("NOT_A_GROUP", "Only group and project conversations can be changed.")
    if ch.created_by != p.id and not p.can("chat.moderate"):
        raise Forbidden("Only the person who created this group, or a moderator, can do this.")


def rename(db: Session, p: Principal, ch: ChatChannel, name: str, description: str | None) -> None:
    _manage(p, ch)
    name = name.strip()
    if not name:
        raise AppError("NAME_REQUIRED", "Give the group a name.")
    old = ch.name
    ch.name, ch.description, ch.updated_by = name[:120], description, p.id
    audit.record(db, action="update", entity_type="chat_channel", entity_id=ch.id, entity_label=ch.name,
                 before={"name": old}, after={"name": ch.name}, summary=f"Renamed chat group '{old}' to '{ch.name}'")


def archive(db: Session, p: Principal, ch: ChatChannel) -> None:
    if ch.kind != "group":
        raise AppError("NOT_A_GROUP", "Only group conversations can be closed.")
    _manage(p, ch)
    ch.is_archived, ch.updated_by = True, p.id
    audit.record(db, action="delete", entity_type="chat_channel", entity_id=ch.id, entity_label=ch.name,
                 summary=f"Closed chat group '{ch.name}' (messages kept)")


def add_members(db: Session, p: Principal, ch: ChatChannel, user_ids: list[uuid.UUID]) -> None:
    if ch.kind != "group":
        raise AppError("NOT_A_GROUP", "People can be added to group conversations only.")
    added = []
    for uid in set(user_ids):
        if _member(db, ch.id, uid) is None:
            _active_user(db, uid)
            _add_member(db, ch, uid, p.id)
            added.append(uid)
    if added:
        names = _names(db, added)
        audit.record(db, action="update", entity_type="chat_channel", entity_id=ch.id, entity_label=ch.name,
                     summary=f"Added {', '.join(sorted(names.values()))} to chat group '{ch.name}'")


def remove_member(db: Session, p: Principal, ch: ChatChannel, user_id: uuid.UUID) -> None:
    if user_id == p.id:
        return leave(db, p, ch)
    if ch.kind != "group":
        raise AppError("NOT_A_GROUP", "People can be removed from group conversations only.")
    _manage(p, ch)
    m = _member(db, ch.id, user_id)
    if m is None:
        raise NotFound("member")
    db.delete(m)
    audit.record(db, action="update", entity_type="chat_channel", entity_id=ch.id, entity_label=ch.name,
                 summary=f"Removed {_names(db, [user_id]).get(user_id, 'a member')} from chat group '{ch.name}'")


def leave(db: Session, p: Principal, ch: ChatChannel) -> None:
    if ch.kind not in ("group", "project"):
        raise AppError("CANNOT_LEAVE", "You cannot leave this conversation.")
    m = _member(db, ch.id, p.id)
    if m is not None:
        db.delete(m)
        audit.record(db, action="update", entity_type="chat_channel", entity_id=ch.id, entity_label=ch.name,
                     summary=f"{p.user.full_name} left chat '{ch.name}'")


def direct(db: Session, p: Principal, other_id: uuid.UUID) -> ChatChannel:
    _require_use(p)
    if other_id == p.id:
        raise AppError("SELF_MESSAGE", "Pick someone else to message.")
    other = _active_user(db, other_id)
    key = ":".join(sorted([str(p.id), str(other_id)]))
    ch = db.scalar(select(ChatChannel).where(ChatChannel.direct_key == key))
    if ch is None:
        ch = ChatChannel(kind="direct", direct_key=key, created_by=p.id, updated_by=p.id)
        db.add(ch)
        db.flush()
        _add_member(db, ch, p.id, p.id)
        _add_member(db, ch, other_id, p.id)
        audit.record(db, action="create", entity_type="chat_channel", entity_id=ch.id,
                     entity_label=f"{p.user.full_name} ↔ {other.full_name}",
                     summary=f"Started a direct conversation between {p.user.full_name} and {other.full_name}")
    return ch


def project_channel(db: Session, p: Principal, project_id: uuid.UUID) -> ChatChannel:
    """Open (creating on first use) the project's chat room. Members = the project team, kept in step each time it
    is opened; whoever opens it from the project page also joins."""
    from app.projects import service as projects

    _require_use(p)
    prj = projects.get(db, project_id)
    projects.check(p, prj, "read")
    team = {prj.project_manager_id, prj.created_by, *[m.user_id for m in prj.members], p.id} - {None}
    team = set(db.scalars(select(User.id).where(User.id.in_(team), User.is_active.is_(True))))
    ch = db.scalar(select(ChatChannel).where(ChatChannel.project_id == prj.id))
    if ch is None:
        ch = ChatChannel(kind="project", project_id=prj.id, name=f"{prj.project_number} {prj.name}"[:120],
                         description="Project team chat", created_by=p.id, updated_by=p.id)
        db.add(ch)
        db.flush()
        audit.record(db, action="create", entity_type="chat_channel", entity_id=ch.id, entity_label=ch.name,
                     summary=f"Opened project chat '{ch.name}' for {len(team)} people")
    elif ch.is_archived:
        ch.is_archived = False
    existing = set(db.scalars(select(ChatMember.user_id).where(ChatMember.channel_id == ch.id)))
    for uid in team - existing:
        _add_member(db, ch, uid, p.id)
    return ch


# ------------------------------------------------------------------ messages
def _excerpt(text: str, n: int = 140) -> str:
    text = " ".join(text.split())
    return text if len(text) <= n else text[: n - 1] + "…"


def messages_out(db: Session, p: Principal, msgs: list[ChatMessage]) -> list[dict]:
    if not msgs:
        return []
    ids = [m.id for m in msgs]
    reply_ids = {m.reply_to_id for m in msgs if m.reply_to_id}
    replies = {r.id: r for r in db.scalars(select(ChatMessage).where(ChatMessage.id.in_(reply_ids)))} if reply_ids else {}
    names = _names(db, [m.sender_id for m in msgs] + [r.sender_id for r in replies.values()])
    att_rows = db.execute(
        select(ChatAttachment, Document).join(Document, Document.id == ChatAttachment.document_id)
        .where(ChatAttachment.message_id.in_(ids), Document.status == "available")
        .order_by(ChatAttachment.created_at)).all()
    atts: dict[int, list] = {}
    for a, d in att_rows:
        atts.setdefault(a.message_id, []).append(attachment_out(a, d))
    moderate = p.can("chat.moderate")
    t = now()
    out = []
    for m in msgs:
        deleted = m.deleted_at is not None
        mine = m.sender_id == p.id
        r = replies.get(m.reply_to_id) if m.reply_to_id else None
        out.append({
            "id": m.id, "channel_id": str(m.channel_id), "sender_id": str(m.sender_id),
            "sender_name": names.get(m.sender_id, "Former user"),
            "body": "" if deleted else m.body, "deleted": deleted,
            "created_at": m.created_at.isoformat(), "edited_at": m.edited_at.isoformat() if m.edited_at else None,
            "mentions": [] if deleted else (m.mentions or []),
            "reply_to": None if r is None else {
                "id": r.id, "sender_name": names.get(r.sender_id, "Former user"),
                "body": "Message deleted" if r.deleted_at else _excerpt(r.body or "📎 Attachment"), "deleted": r.deleted_at is not None},
            "attachments": [] if deleted else atts.get(m.id, []),
            "can_edit": mine and not deleted and t - m.created_at <= EDIT_WINDOW,
            "can_delete": not deleted and (mine or moderate),
        })
    return out


def attachment_out(a: ChatAttachment, d: Document) -> dict:
    return {"id": str(d.id), "file_name": d.file_name, "content_type": d.content_type, "size_bytes": d.size_bytes,
            "is_image": d.content_type in IMAGE_TYPES, "has_thumb": bool(a.thumb_key),
            "width": a.width, "height": a.height}


def list_messages(db: Session, ch: ChatChannel, *, before_id: int | None = None, after_id: int | None = None,
                  around_id: int | None = None, since: datetime | None = None, limit: int = PAGE
                  ) -> tuple[list[ChatMessage], bool]:
    """Returns (messages oldest→newest, has_older)."""
    base = select(ChatMessage).where(ChatMessage.channel_id == ch.id)
    if after_id is not None:
        # polling: anything newer, plus anything edited/deleted recently (30 s overlap covers commit races)
        cond = ChatMessage.id > after_id
        if since is not None:
            cond = or_(cond, ChatMessage.updated_at > since - timedelta(seconds=30))
        rows = list(db.scalars(base.where(cond).order_by(ChatMessage.id).limit(200)))
        return rows, False
    if around_id is not None:
        older = list(db.scalars(base.where(ChatMessage.id <= around_id).order_by(ChatMessage.id.desc()).limit(limit // 2 + 1)))
        newer = list(db.scalars(base.where(ChatMessage.id > around_id).order_by(ChatMessage.id).limit(limit // 2)))
        has_older = len(older) > limit // 2
        older = older[: limit // 2]
        return list(reversed(older)) + newer, has_older
    stmt = base
    if before_id is not None:
        stmt = stmt.where(ChatMessage.id < before_id)
    rows = list(db.scalars(stmt.order_by(ChatMessage.id.desc()).limit(limit + 1)))
    has_older = len(rows) > limit
    return list(reversed(rows[:limit])), has_older


def _mentions(db: Session, ch: ChatChannel, body: str, requested: list[uuid.UUID], sender: uuid.UUID) -> list[uuid.UUID]:
    """Keep requested mentions that are channel members and whose '@Name' is still in the text."""
    if not requested:
        return []
    allowed = set(member_ids(db, ch))
    names = _names(db, [u for u in requested if u in allowed])
    low = body.lower()
    return [u for u, n in names.items() if u != sender and f"@{n.lower()}" in low]


def post(db: Session, p: Principal, ch: ChatChannel, *, body: str, reply_to_id: int | None,
         attachment_ids: list[uuid.UUID], mention_ids: list[uuid.UUID]) -> ChatMessage:
    body = (body or "").strip()
    if len(body) > MAX_BODY:
        raise AppError("MESSAGE_TOO_LONG", f"Messages can be at most {MAX_BODY:,} characters.")
    if len(attachment_ids) > MAX_ATTACHMENTS:
        raise AppError("TOO_MANY_FILES", f"Send at most {MAX_ATTACHMENTS} files in one message.")
    if not body and not attachment_ids:
        raise AppError("EMPTY_MESSAGE", "Type a message or attach a file.")
    if ch.kind == "direct":
        others = [u for u in member_ids(db, ch) if u != p.id]
        if others and not db.scalar(select(User.is_active).where(User.id == others[0])):
            raise AppError("USER_NOT_AVAILABLE", "This person no longer has an active login.")
    if reply_to_id is not None:
        r = db.get(ChatMessage, reply_to_id)
        if r is None or r.channel_id != ch.id:
            raise NotFound("message")
    atts = []
    for aid in dict.fromkeys(attachment_ids):
        a = db.scalar(select(ChatAttachment).where(ChatAttachment.document_id == aid))
        if a is None or a.channel_id != ch.id or a.uploaded_by != p.id or a.message_id is not None:
            raise AppError("ATTACHMENT_NOT_FOUND", "One of the files was not found. Attach it again.")
        atts.append(a)
    mentioned = _mentions(db, ch, body, mention_ids, p.id)
    msg = ChatMessage(channel_id=ch.id, sender_id=p.id, body=body, reply_to_id=reply_to_id,
                      mentions=[str(u) for u in mentioned] or None)
    db.add(msg)
    db.flush()
    db.refresh(msg)
    for a in atts:
        a.message_id = msg.id
    ch.last_message_id, ch.last_message_at = msg.id, msg.created_at
    me = _member(db, ch.id, p.id)
    if me is not None:
        me.last_read_id = msg.id
    if mentioned:
        where = "a direct message" if ch.kind == "direct" else _label(db, ch, None)
        notify(db, mentioned, event="chat.mention", title=f"{p.user.full_name} mentioned you in {where}",
               body=_excerpt(body, 200), link=f"/chat?c={ch.id}&m={msg.id}", exclude=p.id)
    db.flush()
    return msg


def get_message(db: Session, ch: ChatChannel, message_id: int, lock: bool = False) -> ChatMessage:
    m = db.get(ChatMessage, message_id, with_for_update=lock or None)
    if m is None or m.channel_id != ch.id:
        raise NotFound("message")
    return m


def edit(db: Session, p: Principal, ch: ChatChannel, m: ChatMessage, body: str, mention_ids: list[uuid.UUID]) -> None:
    if m.sender_id != p.id:
        raise Forbidden("You can edit only your own messages.")
    if m.deleted_at is not None:
        raise AppError("MESSAGE_DELETED", "This message was deleted.")
    if now() - m.created_at > EDIT_WINDOW:
        raise AppError("EDIT_WINDOW_OVER", "Messages can be edited for 15 minutes after sending.")
    body = (body or "").strip()
    if len(body) > MAX_BODY:
        raise AppError("MESSAGE_TOO_LONG", f"Messages can be at most {MAX_BODY:,} characters.")
    has_files = db.scalar(select(func.count()).select_from(ChatAttachment).where(ChatAttachment.message_id == m.id))
    if not body and not has_files:
        raise AppError("EMPTY_MESSAGE", "A message cannot be empty. Delete it instead.")
    before = {str(u) for u in (m.mentions or [])}
    mentioned = _mentions(db, ch, body, mention_ids + [uuid.UUID(u) for u in before], p.id)
    m.body, m.edited_at, m.updated_at = body, now(), now()
    m.mentions = [str(u) for u in mentioned] or None
    new = [u for u in mentioned if str(u) not in before]
    if new:
        where = "a direct message" if ch.kind == "direct" else _label(db, ch, None)
        notify(db, new, event="chat.mention", title=f"{p.user.full_name} mentioned you in {where}",
               body=_excerpt(body, 200), link=f"/chat?c={ch.id}&m={m.id}", exclude=p.id)


def delete(db: Session, p: Principal, ch: ChatChannel, m: ChatMessage) -> None:
    if m.deleted_at is not None:
        return
    mine = m.sender_id == p.id
    if not mine and not p.can("chat.moderate"):
        raise Forbidden("You can delete only your own messages.")
    excerpt = _excerpt(m.body or "", 200)
    m.deleted_at, m.deleted_by, m.updated_at, m.body, m.mentions = now(), p.id, now(), "", None
    # Files leave every list; the bytes stay in storage (as with every other document) for recovery.
    doc_ids = list(db.scalars(select(ChatAttachment.document_id).where(ChatAttachment.message_id == m.id)))
    if doc_ids:
        db.execute(update(Document).where(Document.id.in_(doc_ids)).values(status="deleted", is_latest=False))
    if not mine:
        sender = _names(db, [m.sender_id]).get(m.sender_id, "a former user")
        audit.record(db, action="delete", entity_type="chat_message", entity_id=m.id, entity_label=_label(db, ch, None),
                     summary=f"Moderator removed a message by {sender} in '{_label(db, ch, None)}'"
                             f"{f': “{excerpt}”' if excerpt else ''}{f' ({len(doc_ids)} file(s))' if doc_ids else ''}")


def mark_read(db: Session, ch: ChatChannel, member: ChatMember, last_id: int | None) -> int:
    top = ch.last_message_id or 0
    target = top if last_id is None else min(last_id, top)
    if target > member.last_read_id:
        member.last_read_id = target
    return member.last_read_id


def search(db: Session, ch: ChatChannel, q: str, limit: int = 50) -> list[ChatMessage]:
    like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
    return list(db.scalars(select(ChatMessage).where(
        ChatMessage.channel_id == ch.id, ChatMessage.deleted_at.is_(None), ChatMessage.body.ilike(like, escape="\\"))
        .order_by(ChatMessage.id.desc()).limit(limit)))


# ------------------------------------------------------------------ attachments
def _thumbnail(data: bytes) -> tuple[bytes, int, int] | None:
    try:
        from PIL import Image, ImageOps

        with Image.open(io.BytesIO(data)) as im:
            im = ImageOps.exif_transpose(im)
            w, h = im.size
            im.thumbnail((480, 480))
            if im.mode not in ("RGB", "L"):
                bg = Image.new("RGB", im.size, (255, 255, 255))
                bg.paste(im, mask=im.convert("RGBA").split()[-1])
                im = bg
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=78, optimize=True)
            return buf.getvalue(), w, h
    except Exception:  # noqa: BLE001 - an image we cannot read is still sent, just without a preview
        return None


def upload(db: Session, p: Principal, ch: ChatChannel, file_name: str, data: bytes) -> tuple[ChatAttachment, Document]:
    doc = documents.upload(db, entity_type="chat_channel", entity_id=ch.id, category="chat", file_name=file_name,
                           data=data, user_id=p.id, audit_log=False)
    a = ChatAttachment(channel_id=ch.id, document_id=doc.id, uploaded_by=p.id)
    if doc.content_type in IMAGE_TYPES:
        t = _thumbnail(data)
        if t is not None:
            thumb, a.width, a.height = t
            a.thumb_key = doc.storage_key + ".thumb.jpg"
            get_storage().put(a.thumb_key, thumb, "image/jpeg")
    db.add(a)
    db.flush()
    return a, doc


def attachment_for(db: Session, p: Principal, document_id: uuid.UUID) -> tuple[ChatAttachment, Document]:
    """Only members of the channel the file was sent in may fetch it."""
    a = db.scalar(select(ChatAttachment).where(ChatAttachment.document_id == document_id))
    if a is None:
        raise NotFound("file")
    channel_for(db, p, a.channel_id)
    doc = db.get(Document, document_id)
    if doc is None or doc.status != "available":
        raise NotFound("file")
    if a.message_id is None and a.uploaded_by != p.id:
        raise NotFound("file")
    return a, doc
