"""Salary records (confidential) and labour cost from attendance (Spec §26, architecture Q3).

Salary amounts are stored encrypted and are visible only with the `salary` permission (HR, Directors). Nothing about
an individual's pay is written to the audit log or shown on project pages: labour cost reaches a project as one
total per project per month ("12.5 man-days").
"""
import json
import uuid
from collections import defaultdict
from datetime import date
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.core.errors import AppError, Conflict, Forbidden, NotFound
from app.core.money import round_amount
from app.hr.attendance import DAY_VALUE, month_bounds
from app.hr.models import Attendance, Employee, SalaryRecord
from app.platform.audit import service as audit
from app.platform.settings import service as settings
from app.projects.models import Project

Z = Decimal("0")
EARNINGS = ("basic", "hra", "conveyance", "special_allowance", "other_allowance")
DEDUCTIONS = ("employee_pf", "employee_esi", "professional_tax", "tds", "other_deduction")
EMPLOYER = ("employer_pf", "employer_esi", "gratuity", "other_employer")
ALL = EARNINGS + DEDUCTIONS + EMPLOYER + ("labour_day_rate",)
LABOUR_NS = uuid.UUID("6b0c3f0e-2c4f-4b7e-9a51-0b6c1b1e7a11")


def _need(p: Principal, action: str) -> None:
    if not p.can(f"salary.{action}"):
        raise Forbidden("Salary details are visible only to HR and Directors.", code="CONFIDENTIAL")


def parse(rec: SalaryRecord) -> dict[str, Decimal]:
    raw = json.loads(rec.components or "{}")
    return {k: Decimal(str(raw.get(k) or 0)) for k in ALL}


def summarise(c: dict[str, Decimal]) -> dict[str, Decimal]:
    gross = sum((c[k] for k in EARNINGS), Z)
    ded = sum((c[k] for k in DEDUCTIONS), Z)
    employer = sum((c[k] for k in EMPLOYER), Z)
    return {"gross": gross, "deductions": ded, "net": gross - ded, "ctc_monthly": gross + employer,
            "ctc_annual": (gross + employer) * 12}


def record_out(rec: SalaryRecord) -> dict:
    c = parse(rec)
    s = summarise(c)
    return {"id": str(rec.id), "effective_from": rec.effective_from.isoformat(), "remarks": rec.remarks,
            "components": {k: str(round_amount(v)) for k, v in c.items()},
            **{k: str(round_amount(v)) for k, v in s.items()}, "created_at": rec.created_at.isoformat()}


def list_records(db: Session, p: Principal, employee_id: uuid.UUID) -> list[dict]:
    _need(p, "read")
    return [record_out(r) for r in db.scalars(select(SalaryRecord).where(SalaryRecord.employee_id == employee_id)
                                              .order_by(SalaryRecord.effective_from.desc()))]


def add_record(db: Session, p: Principal, employee_id: uuid.UUID, data) -> SalaryRecord:
    _need(p, "create")
    emp = db.get(Employee, employee_id)
    if emp is None:
        raise NotFound("employee")
    if db.scalar(select(SalaryRecord.id).where(SalaryRecord.employee_id == emp.id,
                                               SalaryRecord.effective_from == data.effective_from)):
        raise Conflict("SALARY_EXISTS", "There is already a salary record from that date. Add one from a new date.")
    comps = {k: str(round_amount(getattr(data, k) or Z)) for k in ALL}
    if summarise({k: Decimal(v) for k, v in comps.items()})["gross"] <= 0:
        raise AppError("NO_EARNINGS", "Enter the earnings (at least the basic).")
    rec = SalaryRecord(employee_id=emp.id, effective_from=data.effective_from, components=json.dumps(comps),
                       remarks=data.remarks, created_by=p.id, updated_by=p.id)
    db.add(rec)
    db.flush()
    # deliberately no amounts in the audit log
    audit.record(db, action="salary", entity_type="employee", entity_id=emp.id,
                 entity_label=f"{emp.employee_code} {emp.full_name}",
                 summary=f"Salary record added, effective {data.effective_from:%d %b %Y}")
    return rec


def effective(db: Session, employee_id: uuid.UUID, on: date) -> SalaryRecord | None:
    return db.scalar(select(SalaryRecord).where(SalaryRecord.employee_id == employee_id,
                                                SalaryRecord.effective_from <= on)
                     .order_by(SalaryRecord.effective_from.desc()).limit(1))


def day_rate(db: Session, company_id: uuid.UUID, employee_id: uuid.UUID, on: date) -> Decimal | None:
    rec = effective(db, employee_id, on)
    if rec is None:
        return None
    c = parse(rec)
    if c["labour_day_rate"] > 0:
        return c["labour_day_rate"]
    per_month = Decimal(settings.get_setting(db, company_id, "hr.labour_days_per_month") or 26)
    return summarise(c)["ctc_monthly"] / per_month


# ------------------------------------------------------------------ labour cost from attendance
def labour_preview(db: Session, p: Principal, month: str) -> dict:
    """Days worked at each project site in the month × each person's day rate, totalled per project."""
    if not p.can("labour_cost.create"):
        raise Forbidden()
    d1, d2 = month_bounds(month)
    per_prj: dict[uuid.UUID, dict] = defaultdict(lambda: {"man_days": Z, "amount": Z, "people": set()})
    missing: set[str] = set()
    for a in db.scalars(select(Attendance).where(Attendance.att_date.between(d1, d2), Attendance.project_id.is_not(None))):
        days = DAY_VALUE.get(a.status)
        if not days:
            continue
        rate = day_rate(db, p.company_id, a.employee_id, a.att_date)
        if rate is None:
            missing.add(db.scalar(select(Employee.full_name).where(Employee.id == a.employee_id)))
            continue
        r = per_prj[a.project_id]
        r["man_days"] += days
        r["amount"] += days * rate
        r["people"].add(a.employee_id)
    names = dict(db.execute(select(Project.id, Project.project_number)).all())
    rows = [{"project_id": str(k), "project_number": names.get(k), "man_days": f"{v['man_days']:g}",
             "people": len(v["people"]), "amount": str(round_amount(v["amount"]))} for k, v in per_prj.items()]
    rows.sort(key=lambda r: r["project_number"] or "")
    return {"month": month, "rows": rows, "total": str(round_amount(sum((Decimal(r["amount"]) for r in rows), Z))),
            "without_salary": sorted(missing)}


def post_labour(db: Session, p: Principal, month: str) -> dict:
    """Post (or re-post) the month's labour cost to each project. Re-posting reverses the earlier figure first, so a
    corrected attendance or salary can simply be posted again."""
    from app.costing import service as costing

    pv = labour_preview(db, p, month)
    d1, d2 = month_bounds(month)
    posted = 0
    for r in pv["rows"]:
        pid = uuid.UUID(r["project_id"])
        src = uuid.uuid5(LABOUR_NS, f"{pid}:{month}")
        costing.reverse_source(db, source_type="labour_attendance", source_id=src, reason="re-posted", user_id=p.id,
                               cost_date=d2)
        costing.record(db, project_id=pid, cost_head="labour", amount=Decimal(r["amount"]),
                       description=f"Staff labour from attendance, {d1:%b %Y}: {r['man_days']} man-days, {r['people']} people",
                       source_type="labour_attendance", source_id=src, source_number=f"LAB-{month}", cost_date=d2,
                       user_id=p.id, quantity=Decimal(r["man_days"]), unit="man-days", party="Own staff")
        posted += 1
    # projects that had labour posted earlier for this month but none now: clear them
    from app.costing.models import ProjectCostEntry

    stale = db.scalars(select(ProjectCostEntry.project_id).where(
        ProjectCostEntry.source_type == "labour_attendance", ProjectCostEntry.source_number == f"LAB-{month}",
        ProjectCostEntry.project_id.not_in([uuid.UUID(r["project_id"]) for r in pv["rows"]] or [uuid.uuid4()]))).all()
    for pid in set(stale):
        costing.reverse_source(db, source_type="labour_attendance", source_id=uuid.uuid5(LABOUR_NS, f"{pid}:{month}"),
                               reason="no site attendance any more", user_id=p.id, cost_date=d2)
    audit.record(db, action="labour_posting", entity_type="attendance", entity_label=f"Labour {month}",
                 summary=f"Labour cost posted to {posted} project(s), total ₹{pv['total']}")
    return pv
