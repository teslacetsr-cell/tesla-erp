"""Employee records that follow user accounts.

Every person who can sign in is also an employee: creating a user creates (or links) the matching employee record,
so expenses, attendance and leave (which belong to an employee) work from the first day. The built-in `admin`
account is a system login, not a person, and is left out.
"""
import uuid

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import AppError, Conflict
from app.hr.models import Department, Designation, Employee
from app.platform.audit import service as audit
from app.platform.numbering import service as numbering
from app.users.models import User

SYSTEM_USERNAMES = {"admin"}


def employee_for_user(db: Session, user_id: uuid.UUID) -> Employee | None:
    return db.scalar(select(Employee).where(Employee.user_id == user_id))


def free_code(db: Session, company_id: uuid.UUID) -> str:
    """Next employee code, skipping any code HR already typed in by hand."""
    for _ in range(1000):
        code = numbering.next_number(db, company_id, "EMPLOYEE")
        if not db.scalar(select(Employee.id).where(Employee.employee_code == code)):
            return code
    raise AppError("NUMBERING_EXHAUSTED", "Could not find a free employee code.")


def _check_refs(db: Session, department_id, designation_id, division_id) -> None:
    from app.company.models import BusinessDivision

    for model, val, name in ((Department, department_id, "department"), (Designation, designation_id, "designation"),
                             (BusinessDivision, division_id, "division")):
        if val and db.get(model, val) is None:
            raise AppError("INVALID_REFERENCE", f"The chosen {name} does not exist.", details={"field": f"{name}_id"})


def ensure_employee(db: Session, user: User, *, company_id: uuid.UUID, actor_id: uuid.UUID | None,
                    employee_id: uuid.UUID | None = None, department_id=None, designation_id=None,
                    division_id=None) -> Employee | None:
    """Link the user to an employee: the one chosen, else an unlinked employee with the same email, else a new one.
    Returns the employee (None for system accounts). Safe to call repeatedly."""
    if user.username in SYSTEM_USERNAMES:
        return None
    existing = employee_for_user(db, user.id)
    if existing is not None:
        return existing
    _check_refs(db, department_id, designation_id, division_id)
    emp: Employee | None = None
    if employee_id:
        emp = db.get(Employee, employee_id, with_for_update=True)
        if emp is None:
            raise AppError("EMPLOYEE_NOT_FOUND", "The chosen employee does not exist.", details={"field": "employee_id"})
        if emp.user_id and emp.user_id != user.id:
            raise Conflict("EMPLOYEE_ALREADY_LINKED", f"{emp.full_name} already has a login.")
    elif user.email:
        emp = db.scalar(select(Employee).where(Employee.email == user.email, Employee.user_id.is_(None))
                        .with_for_update())
    by = actor_id or user.id
    if emp is not None:
        before = audit.snapshot(emp)
        emp.user_id, emp.updated_by = user.id, by
        for k, v in (("department_id", department_id), ("designation_id", designation_id), ("division_id", division_id)):
            if v and getattr(emp, k) is None:
                setattr(emp, k, v)
        emp.phone = emp.phone or user.phone
        db.flush()
        audit.record(db, action="update", entity_type="employee", entity_id=emp.id,
                     entity_label=f"{emp.employee_code} {emp.full_name}", summary=f"Linked to login {user.username}",
                     before=before, after=audit.snapshot(emp))
        return emp
    email = user.email
    if email and db.scalar(select(Employee.id).where(Employee.email == email)):
        email = None  # another (already linked) employee uses it; keep the record without an email
    emp = Employee(employee_code=free_code(db, company_id), full_name=user.full_name,
                   email=email, phone=user.phone, user_id=user.id, department_id=department_id,
                   designation_id=designation_id, division_id=division_id, is_active=user.is_active,
                   created_by=by, updated_by=by)
    db.add(emp)
    db.flush()
    audit.record(db, action="create", entity_type="employee", entity_id=emp.id,
                 entity_label=f"{emp.employee_code} {emp.full_name}",
                 summary=f"Created automatically with login {user.username}", after=audit.snapshot(emp))
    return emp


def sync_from_user(db: Session, user: User, actor_id: uuid.UUID) -> None:
    """Keep the linked employee's name, email and phone in step with the login."""
    emp = employee_for_user(db, user.id)
    if emp is None:
        return
    changes = {}
    if emp.full_name != user.full_name:
        changes["full_name"] = user.full_name
    if user.email and (emp.email or "").lower() != user.email.lower() and not db.scalar(
            select(Employee.id).where(Employee.email == user.email, Employee.id != emp.id)):
        changes["email"] = user.email
    if user.phone and emp.phone != user.phone:
        changes["phone"] = user.phone
    if not changes:
        return
    before = audit.snapshot(emp)
    for k, v in changes.items():
        setattr(emp, k, v)
    emp.updated_by = actor_id
    db.flush()
    audit.record(db, action="update", entity_type="employee", entity_id=emp.id,
                 entity_label=f"{emp.employee_code} {emp.full_name}", summary="Updated from the user account",
                 before=before, after=audit.snapshot(emp))


def backfill(db: Session, company_id: uuid.UUID, actor_id: uuid.UUID | None) -> int:
    """Give every existing login an employee record (run by `seed core` on each deploy). Returns how many were added."""
    linked = select(Employee.user_id).where(Employee.user_id.is_not(None))
    users = db.scalars(select(User).where(User.id.not_in(linked), User.username.not_in(SYSTEM_USERNAMES))
                       .order_by(User.created_at)).all()
    for u in users:
        ensure_employee(db, u, company_id=company_id, actor_id=actor_id)
    return len(users)
