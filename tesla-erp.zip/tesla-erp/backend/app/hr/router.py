import uuid
from datetime import date
from typing import Annotated

from fastapi import APIRouter, Depends, Query
from pydantic import EmailStr, Field
from sqlalchemy import or_, select

from app.auth.deps import Principal, require
from app.core.api import ListParams, Schema, ok, paginate
from app.core.crud import master_routes
from app.core.db import DbSession
from app.core.errors import AppError, Conflict, NotFound
from app.core.models import check_row_version
from app.core.validators import Phone
from app.hr.models import Department, Designation, Employee
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.platform.numbering import service as numbering
from app.users.models import User

router = APIRouter(tags=["organisation"])
documents.register_entity("employee", "employee", Employee)


class DepartmentIn(Schema):
    code: str = Field(min_length=1, max_length=20, pattern=r"^[A-Z0-9_-]+$")
    name: str = Field(min_length=2, max_length=120)
    is_active: bool = True


class DepartmentUpdate(DepartmentIn):
    row_version: int


class DesignationIn(Schema):
    name: str = Field(min_length=2, max_length=120)
    is_active: bool = True


class DesignationUpdate(DesignationIn):
    row_version: int


master_routes(router, path="/departments", entity="department", model=Department, perm="org_master",
              create_schema=DepartmentIn, update_schema=DepartmentUpdate,
              out=lambda d: {"id": str(d.id), "code": d.code, "name": d.name, "is_active": d.is_active,
                             "row_version": d.row_version},
              search=("code", "name"), sortable=("code", "name"), default_sort="name", label=lambda d: d.name)
master_routes(router, path="/designations", entity="designation", model=Designation, perm="org_master",
              create_schema=DesignationIn, update_schema=DesignationUpdate,
              out=lambda d: {"id": str(d.id), "name": d.name, "is_active": d.is_active, "row_version": d.row_version},
              search=("name",), sortable=("name",), default_sort="name", label=lambda d: d.name)


# ------------------------------------------------------------------ employees (basic; extended in Phase 8)
class EmployeeIn(Schema):
    employee_code: str | None = Field(default=None, max_length=20, description="Leave blank to auto-number")
    full_name: str = Field(min_length=2, max_length=150)
    email: EmailStr | None = None
    phone: Phone = None
    department_id: uuid.UUID | None = None
    designation_id: uuid.UUID | None = None
    division_id: uuid.UUID | None = None
    reports_to_id: uuid.UUID | None = None
    user_id: uuid.UUID | None = None
    date_of_joining: date | None = None
    is_active: bool = True


class EmployeeUpdate(EmployeeIn):
    row_version: int


def employee_out(e: Employee) -> dict:
    return {
        "id": str(e.id), "employee_code": e.employee_code, "full_name": e.full_name, "email": e.email,
        "phone": e.phone, "department_id": str(e.department_id) if e.department_id else None,
        "department": e.department.name if e.department else None,
        "designation_id": str(e.designation_id) if e.designation_id else None,
        "designation": e.designation.name if e.designation else None,
        "division_id": str(e.division_id) if e.division_id else None,
        "division": e.division.name if e.division else None,
        "reports_to_id": str(e.reports_to_id) if e.reports_to_id else None,
        "user_id": str(e.user_id) if e.user_id else None,
        "date_of_joining": e.date_of_joining.isoformat() if e.date_of_joining else None,
        "is_active": e.is_active, "row_version": e.row_version,
    }


def _validate_links(db, body: EmployeeIn, employee_id: uuid.UUID | None) -> None:
    if body.user_id:
        if db.get(User, body.user_id) is None:
            raise AppError("USER_NOT_FOUND", "The linked user does not exist.")
        other = db.scalar(select(Employee.id).where(Employee.user_id == body.user_id))
        if other and other != employee_id:
            raise Conflict("USER_ALREADY_LINKED", "That user is already linked to another employee.")
    if body.reports_to_id and body.reports_to_id == employee_id:
        raise AppError("INVALID_MANAGER", "An employee cannot report to themselves.")


@router.get("/employees")
def list_employees(db: DbSession, _: Annotated[Principal, require("employee.read")],
                   params: Annotated[ListParams, Depends()], is_active: bool | None = Query(None),
                   department_id: uuid.UUID | None = None):
    stmt = select(Employee)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(Employee.full_name.ilike(like), Employee.employee_code.ilike(like),
                              Employee.email.ilike(like), Employee.phone.ilike(like)))
    if is_active is not None:
        stmt = stmt.where(Employee.is_active.is_(is_active))
    if department_id:
        stmt = stmt.where(Employee.department_id == department_id)
    rows, meta = paginate(db, stmt, params, default_sort=Employee.full_name,
                          sortable={"full_name": Employee.full_name, "employee_code": Employee.employee_code,
                                    "date_of_joining": Employee.date_of_joining})
    return {"data": [employee_out(e) for e in rows], "meta": meta.model_dump()}


@router.post("/employees", status_code=201)
def create_employee(body: EmployeeIn, db: DbSession, p: Annotated[Principal, require("employee.create")]):
    _validate_links(db, body, None)
    data = body.model_dump()
    code = (data.pop("employee_code") or "").strip().upper() or numbering.next_number(db, p.company_id, "EMPLOYEE")
    e = Employee(employee_code=code, **data, created_by=p.id, updated_by=p.id)
    db.add(e)
    db.flush()
    audit.record(db, action="create", entity_type="employee", entity_id=e.id, entity_label=f"{code} {e.full_name}",
                 after=audit.snapshot(e))
    return ok(employee_out(e))


@router.get("/employees/{employee_id}")
def get_employee(employee_id: uuid.UUID, db: DbSession, _: Annotated[Principal, require("employee.read")]):
    e = db.get(Employee, employee_id)
    if e is None:
        raise NotFound("employee")
    return ok(employee_out(e))


@router.put("/employees/{employee_id}")
def update_employee(employee_id: uuid.UUID, body: EmployeeUpdate, db: DbSession,
                    p: Annotated[Principal, require("employee.update")]):
    e = db.get(Employee, employee_id)
    if e is None:
        raise NotFound("employee")
    _validate_links(db, body, e.id)
    before = audit.snapshot(e)
    data = body.model_dump()
    check_row_version(e, data.pop("row_version"))
    code = (data.pop("employee_code") or "").strip().upper()
    if code:
        e.employee_code = code
    for k, v in data.items():
        setattr(e, k, v)
    e.updated_by = p.id
    db.flush()
    audit.record(db, action="update", entity_type="employee", entity_id=e.id,
                 entity_label=f"{e.employee_code} {e.full_name}", before=before, after=audit.snapshot(e))
    return ok(employee_out(e))
