import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, Numeric, String, Text
from sqlalchemy.dialects.postgresql import CITEXT, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.company.models import BusinessDivision
from app.core.models import AuditColumnsMixin, Base
from app.core.security import EncryptedString


class Department(AuditColumnsMixin, Base):
    __tablename__ = "departments"

    code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class Designation(AuditColumnsMixin, Base):
    __tablename__ = "designations"

    name: Mapped[str] = mapped_column(CITEXT, unique=True, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class Employee(AuditColumnsMixin, Base):
    """Minimal employee record (Phase 1). Owned by HR; extended in Phase 8 with personal, bank and salary data."""

    __tablename__ = "employees"

    employee_code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    full_name: Mapped[str] = mapped_column(String(150), nullable=False)
    email: Mapped[str | None] = mapped_column(CITEXT, unique=True)
    phone: Mapped[str | None] = mapped_column(String(20))
    department_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("departments.id", ondelete="RESTRICT"))
    designation_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("designations.id", ondelete="RESTRICT"))
    division_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("business_divisions.id", ondelete="RESTRICT"))
    reports_to_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("employees.id", ondelete="RESTRICT"))
    user_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), unique=True)
    date_of_joining: Mapped[date | None] = mapped_column(Date)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")
    # Phase 8 — personal (shown to HR / Directors and the employee themself)
    date_of_birth: Mapped[date | None] = mapped_column(Date)
    gender: Mapped[str | None] = mapped_column(String(20))
    blood_group: Mapped[str | None] = mapped_column(String(5))
    marital_status: Mapped[str | None] = mapped_column(String(15))
    personal_email: Mapped[str | None] = mapped_column(String(150))
    emergency_contact_name: Mapped[str | None] = mapped_column(String(150))
    emergency_contact_phone: Mapped[str | None] = mapped_column(String(20))
    emergency_contact_relation: Mapped[str | None] = mapped_column(String(50))
    current_address: Mapped[str | None] = mapped_column(Text)
    permanent_address: Mapped[str | None] = mapped_column(Text)
    pan: Mapped[str | None] = mapped_column(EncryptedString(255))
    bank_name: Mapped[str | None] = mapped_column(String(150))
    bank_account_name: Mapped[str | None] = mapped_column(String(150))
    bank_account_number: Mapped[str | None] = mapped_column(EncryptedString(255))
    bank_ifsc: Mapped[str | None] = mapped_column(String(11))
    # Phase 8 — employment
    employment_type: Mapped[str] = mapped_column(String(15), nullable=False, default="permanent",
                                                 server_default="permanent")
    confirmation_date: Mapped[date | None] = mapped_column(Date)
    exit_date: Mapped[date | None] = mapped_column(Date)
    exit_reason: Mapped[str | None] = mapped_column(String(300))
    work_location: Mapped[str | None] = mapped_column(String(150))
    weekly_off: Mapped[str] = mapped_column(String(10), nullable=False, default="sun", server_default="sun")

    department: Mapped[Department | None] = relationship(lazy="selectin")
    designation: Mapped[Designation | None] = relationship(lazy="selectin")
    division: Mapped[BusinessDivision | None] = relationship(lazy="selectin")


# ================================================================== Phase 8: HR
# Personal and bank details live on the employee row; the sensitive ones are encrypted at rest and shown only to
# HR / Directors (permission employee_private) and to the employee themself.

EMPLOYMENT_TYPES = ("permanent", "probation", "contract", "trainee", "consultant")
ATTENDANCE_STATUSES = ("present", "half_day", "absent", "on_leave", "on_duty", "holiday", "weekly_off")
LEAVE_STATUSES = ("pending", "approved", "rejected", "cancelled")
DAYS = Numeric(5, 1)


def _in(col: str, values: tuple[str, ...]) -> str:
    return f"{col} in ({', '.join(repr(v) for v in values)})"


class Holiday(AuditColumnsMixin, Base):
    __tablename__ = "holidays"

    holiday_date: Mapped[date] = mapped_column(Date, unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    is_optional: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class LeaveType(AuditColumnsMixin, Base):
    __tablename__ = "leave_types"

    code: Mapped[str] = mapped_column(String(10), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(80), nullable=False)
    annual_quota: Mapped[Decimal | None] = mapped_column(DAYS)   # null = no limit (e.g. loss of pay)
    paid: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")
    carry_forward: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    max_carry_forward: Mapped[Decimal | None] = mapped_column(DAYS)
    allow_half_day: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class LeaveAdjustment(AuditColumnsMixin, Base):
    """Opening balance, carry-forward or credit/debit of leave for one year (signed days)."""

    __tablename__ = "leave_adjustments"
    __table_args__ = (Index("ix_leave_adjustments_emp_year", "employee_id", "year"),)

    employee_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("employees.id", ondelete="RESTRICT"), nullable=False)
    leave_type_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("leave_types.id", ondelete="RESTRICT"), nullable=False)
    year: Mapped[int] = mapped_column(nullable=False)
    days: Mapped[Decimal] = mapped_column(DAYS, nullable=False)
    reason: Mapped[str] = mapped_column(String(300), nullable=False)


class LeaveRequest(AuditColumnsMixin, Base):
    __tablename__ = "leave_requests"
    __table_args__ = (CheckConstraint(_in("status", LEAVE_STATUSES), name="status_valid"),
                      CheckConstraint("to_date >= from_date", name="dates_order"),
                      CheckConstraint("days > 0", name="days_positive"),
                      CheckConstraint("half_day in ('none','first','second')", name="half_valid"),
                      Index("ix_leave_requests_emp", "employee_id", "from_date"),
                      Index("ix_leave_requests_status", "status"))

    employee_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("employees.id", ondelete="RESTRICT"), nullable=False)
    leave_type_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("leave_types.id", ondelete="RESTRICT"), nullable=False)
    from_date: Mapped[date] = mapped_column(Date, nullable=False)
    to_date: Mapped[date] = mapped_column(Date, nullable=False)
    half_day: Mapped[str] = mapped_column(String(6), nullable=False, default="none", server_default="none")
    days: Mapped[Decimal] = mapped_column(DAYS, nullable=False)
    reason: Mapped[str] = mapped_column(String(500), nullable=False)
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="pending", server_default="pending")
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    status_reason: Mapped[str | None] = mapped_column(String(500))


class Attendance(AuditColumnsMixin, Base):
    __tablename__ = "attendance"
    __table_args__ = (CheckConstraint(_in("status", ATTENDANCE_STATUSES), name="status_valid"),
                      CheckConstraint("source in ('self','hr','leave')", name="source_valid"),
                      Index("uq_attendance_emp_date", "employee_id", "att_date", unique=True),
                      Index("ix_attendance_date", "att_date"), Index("ix_attendance_project", "project_id"))

    employee_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("employees.id", ondelete="RESTRICT"), nullable=False)
    att_date: Mapped[date] = mapped_column(Date, nullable=False)
    status: Mapped[str] = mapped_column(String(12), nullable=False)
    check_in_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    check_out_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    check_in_lat: Mapped[Decimal | None] = mapped_column(Numeric(9, 6))
    check_in_lng: Mapped[Decimal | None] = mapped_column(Numeric(9, 6))
    check_in_accuracy_m: Mapped[int | None] = mapped_column()
    check_out_lat: Mapped[Decimal | None] = mapped_column(Numeric(9, 6))
    check_out_lng: Mapped[Decimal | None] = mapped_column(Numeric(9, 6))
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="RESTRICT"))
    work_hours: Mapped[Decimal | None] = mapped_column(Numeric(5, 2))
    source: Mapped[str] = mapped_column(String(6), nullable=False, default="self", server_default="self")
    leave_request_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True),
                                                               ForeignKey("leave_requests.id", ondelete="SET NULL"))
    remarks: Mapped[str | None] = mapped_column(String(300))


class SalaryRecord(AuditColumnsMixin, Base):
    """A salary structure from a date. The amounts are stored encrypted (JSON) and shown only to HR / Directors."""

    __tablename__ = "salary_records"
    __table_args__ = (Index("uq_salary_records_emp_from", "employee_id", "effective_from", unique=True),)

    employee_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("employees.id", ondelete="RESTRICT"), nullable=False)
    effective_from: Mapped[date] = mapped_column(Date, nullable=False)
    components: Mapped[str] = mapped_column(EncryptedString(4000), nullable=False)
    remarks: Mapped[str | None] = mapped_column(String(300))
