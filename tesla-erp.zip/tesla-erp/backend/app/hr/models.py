import uuid
from datetime import date

from sqlalchemy import Boolean, Date, ForeignKey, String
from sqlalchemy.dialects.postgresql import CITEXT
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.models import AuditColumnsMixin, Base


class Department(AuditColumnsMixin, Base):
    __tablename__ = "departments"

    code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class Designation(AuditColumnsMixin, Base):
    __tablename__ = "designations"

    name: Mapped[str] = mapped_column(CITEXT, unique=True, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class Employee(AuditColumnsMixin, Base):
    """Minimal employee record (Phase 1). Owned by HR; extended in Phase 8 with personal, bank and salary data."""

    __tablename__ = "employees"

    employee_code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    full_name: Mapped[str] = mapped_column(String(150), nullable=False)
    email: Mapped[str | None] = mapped_column(CITEXT, unique=True)
    phone: Mapped[str | None] = mapped_column(String(20))
    department_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("departments.id", ondelete="RESTRICT"))
    designation_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("designations.id", ondelete="RESTRICT"))
    division_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("business_divisions.id", ondelete="RESTRICT"))
    reports_to_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("employees.id", ondelete="RESTRICT"))
    user_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), unique=True)
    date_of_joining: Mapped[date | None] = mapped_column(Date)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")

    department: Mapped[Department | None] = relationship(lazy="selectin")
    designation: Mapped[Designation | None] = relationship(lazy="selectin")
