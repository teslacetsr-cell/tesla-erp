"""Phase 8 HR API: self-service (check-in/out, my leave), leave, attendance, employee profile, salary, labour cost."""
import uuid
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from pydantic import EmailStr, Field, model_validator
from sqlalchemy import func, select

from app.auth.deps import CurrentUser, Principal, require
from app.core import excel
from app.core.api import ListParams, Schema, ok
from app.core.crud import master_routes
from app.core.db import DbSession
from app.core.errors import AppError, Forbidden, NotFound
from app.core.validators import Phone, Text
from app.crm.service import today
from app.hr import attendance as att
from app.hr import leave, salary
from app.hr.models import ATTENDANCE_STATUSES, EMPLOYMENT_TYPES, Employee, Holiday, LeaveAdjustment, LeaveRequest, LeaveType
from app.hr.router import employee_out
from app.hr.service import employee_for_user
from app.platform.approvals import service as approvals
from app.platform.approvals.router import request_out
from app.platform.audit import service as audit
from app.platform.settings import service as settings
from app.projects.models import Project, ProjectMember

router = APIRouter(tags=["hr"])
D = Decimal


# ------------------------------------------------------------------ schemas
class GeoIn(Schema):
    lat: Decimal | None = Field(default=None, ge=-90, le=90, max_digits=9, decimal_places=6)
    lng: Decimal | None = Field(default=None, ge=-180, le=180, max_digits=9, decimal_places=6)
    accuracy_m: int | None = Field(default=None, ge=0, le=100000)
    remarks: Text(300) = None


class CheckInIn(GeoIn):
    project_id: uuid.UUID | None = None
    on_duty: bool = False   # working away from office / site (client visit, travel)


class MarkIn(Schema):
    employee_id: uuid.UUID
    att_date: date
    status: Literal[ATTENDANCE_STATUSES]  # type: ignore[valid-type]
    project_id: uuid.UUID | None = None
    check_in_at: datetime | None = None
    check_out_at: datetime | None = None
    remarks: Text(300) = None


class LeaveIn(Schema):
    employee_id: uuid.UUID | None = None
    leave_type_id: uuid.UUID
    from_date: date
    to_date: date
    half_day: Literal["none", "first", "second"] = "none"
    reason: str = Field(min_length=3, max_length=500)


class ReasonIn(Schema):
    reason: Text(500) = None


class AdjustmentIn(Schema):
    employee_id: uuid.UUID
    leave_type_id: uuid.UUID
    year: int = Field(ge=2000, le=2100)
    days: Decimal = Field(max_digits=5, decimal_places=1)
    reason: str = Field(min_length=3, max_length=300)


class LeaveTypeIn(Schema):
    code: str = Field(min_length=1, max_length=10, pattern=r"^[A-Z0-9_-]+$")
    name: str = Field(min_length=2, max_length=80)
    annual_quota: Decimal | None = Field(default=None, ge=0, max_digits=5, decimal_places=1)
    paid: bool = True
    carry_forward: bool = False
    max_carry_forward: Decimal | None = Field(default=None, ge=0, max_digits=5, decimal_places=1)
    allow_half_day: bool = True
    is_active: bool = True


class LeaveTypeUpdate(LeaveTypeIn):
    row_version: int


class HolidayIn(Schema):
    holiday_date: date
    name: str = Field(min_length=2, max_length=120)
    is_optional: bool = False
    is_active: bool = True


class HolidayUpdate(HolidayIn):
    row_version: int


class SelfProfileIn(Schema):
    personal_email: EmailStr | None = None
    blood_group: Text(5) = None
    emergency_contact_name: Text(150) = None
    emergency_contact_phone: Phone = None
    emergency_contact_relation: Text(50) = None
    current_address: Text(1000) = None
    permanent_address: Text(1000) = None


class PrivateIn(SelfProfileIn):
    date_of_birth: date | None = None
    gender: Literal["male", "female", "other"] | None = None
    marital_status: Literal["single", "married", "other"] | None = None
    pan: Text(10) = None
    bank_name: Text(150) = None
    bank_account_name: Text(150) = None
    bank_account_number: Text(30) = None
    bank_ifsc: str | None = Field(default=None, pattern=r"^[A-Z]{4}0[A-Z0-9]{6}$")
    employment_type: Literal[EMPLOYMENT_TYPES] = "permanent"  # type: ignore[valid-type]
    confirmation_date: date | None = None
    exit_date: date | None = None
    exit_reason: Text(300) = None
    work_location: Text(150) = None
    weekly_off: str = Field(default="sun", pattern=r"^(mon|tue|wed|thu|fri|sat|sun)(,(mon|tue|wed|thu|fri|sat|sun))?$")
    row_version: int

    @model_validator(mode="after")
    def _pan(self):
        if self.pan:
            from app.core.india import validate_pan

            self.pan = validate_pan(self.pan.upper())
        return self


class SalaryIn(Schema):
    effective_from: date
    remarks: Text(300) = None
    basic: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    hra: Decimal = Field(default=D(0), ge=0, max_digits=12, decimal_places=2)
    conveyance: Decimal = Field(default=D(0), ge=0, max_digits=12, decimal_places=2)
    special_allowance: Decimal = Field(default=D(0), ge=0, max_digits=12, decimal_places=2)
    other_allowance: Decimal = Field(default=D(0), ge=0, max_digits=12, decimal_places=2)
    employee_pf: Decimal = Field(default=D(0), ge=0, max_digits=12, decimal_places=2)
    employee_esi: Decimal = Field(default=D(0), ge=0, max_digits=12, decimal_places=2)
    professional_tax: Decimal = Field(default=D(0), ge=0, max_digits=12, decimal_places=2)
    tds: Decimal = Field(default=D(0), ge=0, max_digits=12, decimal_places=2)
    other_deduction: Decimal = Field(default=D(0), ge=0, max_digits=12, decimal_places=2)
    employer_pf: Decimal = Field(default=D(0), ge=0, max_digits=12, decimal_places=2)
    employer_esi: Decimal = Field(default=D(0), ge=0, max_digits=12, decimal_places=2)
    gratuity: Decimal = Field(default=D(0), ge=0, max_digits=12, decimal_places=2)
    other_employer: Decimal = Field(default=D(0), ge=0, max_digits=12, decimal_places=2)
    labour_day_rate: Decimal = Field(default=D(0), ge=0, max_digits=12, decimal_places=2)


class MonthIn(Schema):
    month: str = Field(pattern=r"^\d{4}-\d{2}$")


# ------------------------------------------------------------------ helpers
def _d(v) -> str | None:
    return v.isoformat() if v else None


def _xlsx(data: bytes, name: str) -> Response:
    return Response(data, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{name}.xlsx"'})


PRIVATE_FIELDS = ("date_of_birth", "gender", "marital_status", "personal_email", "blood_group",
                  "emergency_contact_name", "emergency_contact_phone", "emergency_contact_relation", "current_address",
                  "permanent_address", "bank_name", "bank_account_name", "bank_ifsc", "employment_type",
                  "confirmation_date", "exit_date", "exit_reason", "work_location", "weekly_off")


def private_out(e: Employee) -> dict:
    out = {k: (_d(getattr(e, k)) if isinstance(getattr(e, k), date) else getattr(e, k)) for k in PRIVATE_FIELDS}
    out["pan"] = e.pan
    out["bank_account_number"] = e.bank_account_number
    return out


def _upcoming_holidays(db, days: int = 90) -> list[dict]:
    t = today()
    return [{"date": d.isoformat(), "name": n, "optional": o} for d, n, o in db.execute(
        select(Holiday.holiday_date, Holiday.name, Holiday.is_optional)
        .where(Holiday.holiday_date.between(t, t + timedelta(days=days))).order_by(Holiday.holiday_date)).all()]


def _my_projects(db, user_id) -> list[dict]:
    rows = db.execute(select(Project.id, Project.project_number, Project.name).where(
        Project.status.not_in(("completed", "cancelled")),
        (Project.project_manager_id == user_id) | Project.id.in_(select(ProjectMember.project_id)
                                                                  .where(ProjectMember.user_id == user_id)))
                      .order_by(Project.project_number.desc())).all()
    return [{"id": str(i), "number": n, "name": nm} for i, n, nm in rows]


def leave_out(db, p: Principal, lr: LeaveRequest, detail: bool = False) -> dict:
    emp = db.get(Employee, lr.employee_id)
    t = db.get(LeaveType, lr.leave_type_id)
    me = employee_for_user(db, p.id)
    out = {"id": str(lr.id), "employee_id": str(emp.id), "employee": emp.full_name, "leave_type": t.name,
           "leave_type_code": t.code, "from_date": _d(lr.from_date), "to_date": _d(lr.to_date), "half_day": lr.half_day,
           "days": f"{lr.days:g}", "reason": lr.reason, "status": lr.status, "status_reason": lr.status_reason,
           "created_at": lr.created_at.isoformat()}
    if detail:
        pending = approvals.pending_for(db, "leave_request", lr.id)
        mine = me is not None and me.id == emp.id
        hr = p.scope("leave_request.update") == "all"
        out |= {"approval": request_out(db, p, pending) if pending else None,
                "approvals": [request_out(db, p, r) for r in approvals.history(db, "leave_request", lr.id)],
                "balances": leave.balances(db, emp, lr.from_date.year) if (mine or hr) else None,
                "can": {"cancel": lr.status in ("pending", "approved") and (hr or (mine and (
                    lr.status == "pending" or lr.from_date > today()))),
                    "decide": bool(pending and approvals.can_decide(p, pending))}}
    return out


# ------------------------------------------------------------------ self-service
@router.get("/hr/me")
def my_hr(db: DbSession, p: CurrentUser):
    emp = employee_for_user(db, p.id)
    if emp is None:
        return ok({"employee": None})
    t = today()
    row = db.scalar(select(att.Attendance).where(att.Attendance.employee_id == emp.id, att.Attendance.att_date == t))
    recent = db.scalars(select(LeaveRequest).where(LeaveRequest.employee_id == emp.id)
                        .order_by(LeaveRequest.from_date.desc()).limit(8)).all()
    return ok({
        "employee": employee_out(emp), "private": private_out(emp), "today": att.att_out(row),
        "is_holiday": bool(leave.holidays_between(db, t, t)), "is_weekly_off": leave.is_weekly_off(emp, t),
        "balances": leave.balances(db, emp, t.year), "holidays": _upcoming_holidays(db),
        "leave": [leave_out(db, p, lr) for lr in recent], "projects": _my_projects(db, p.id),
        "gps": bool(settings.get_setting(db, p.company_id, "hr.attendance_gps")),
        "leave_types": [{"id": str(x.id), "code": x.code, "name": x.name, "allow_half_day": x.allow_half_day}
                        for x in db.scalars(select(LeaveType).where(LeaveType.is_active.is_(True)).order_by(LeaveType.code))],
        "can": {"check_in": p.can("attendance.create"), "apply_leave": p.can("leave_request.create")},
    })


@router.post("/hr/me/check-in")
def check_in(body: CheckInIn, db: DbSession, p: CurrentUser):
    return ok(att.att_out(att.check_in(db, p, body)))


@router.post("/hr/me/check-out")
def check_out(body: GeoIn, db: DbSession, p: CurrentUser):
    return ok(att.att_out(att.check_out(db, p, body)))


@router.get("/hr/me/attendance")
def my_attendance(db: DbSession, p: CurrentUser, month: str = Query(pattern=r"^\d{4}-\d{2}$")):
    emp = employee_for_user(db, p.id)
    if emp is None:
        raise AppError("NO_EMPLOYEE_RECORD", "Your login is not linked to an employee record.")
    return ok(att.register(db, month, [emp.id]))


@router.put("/hr/me/profile")
def my_profile(body: SelfProfileIn, db: DbSession, p: CurrentUser):
    emp = employee_for_user(db, p.id)
    if emp is None:
        raise AppError("NO_EMPLOYEE_RECORD", "Your login is not linked to an employee record.")
    before = private_out(emp)
    for k, v in body.model_dump().items():
        setattr(emp, k, str(v) if k == "personal_email" and v else v)
    emp.updated_by = p.id
    db.flush()
    audit.record(db, action="update", entity_type="employee", entity_id=emp.id,
                 entity_label=f"{emp.employee_code} {emp.full_name}", summary="Personal details updated by the employee",
                 before={k: before[k] for k in body.model_dump()}, after={k: private_out(emp)[k] for k in body.model_dump()})
    return ok(private_out(emp))


# ------------------------------------------------------------------ leave
master_routes(router, path="/leave-types", entity="leave_type", model=LeaveType, perm="hr_master",
              create_schema=LeaveTypeIn, update_schema=LeaveTypeUpdate,
              out=lambda t: {"id": str(t.id), "code": t.code, "name": t.name,
                             "annual_quota": str(t.annual_quota) if t.annual_quota is not None else None,
                             "paid": t.paid, "carry_forward": t.carry_forward,
                             "max_carry_forward": str(t.max_carry_forward) if t.max_carry_forward is not None else None,
                             "allow_half_day": t.allow_half_day, "is_active": t.is_active, "row_version": t.row_version},
              search=("code", "name"), sortable=("code", "name"), default_sort="code", label=lambda t: t.code)
master_routes(router, path="/holidays", entity="holiday", model=Holiday, perm="hr_master",
              create_schema=HolidayIn, update_schema=HolidayUpdate,
              out=lambda h: {"id": str(h.id), "holiday_date": h.holiday_date.isoformat(), "name": h.name,
                             "is_optional": h.is_optional, "is_active": h.is_active, "row_version": h.row_version},
              search=("name",), sortable=("holiday_date", "name"), default_sort="holiday_date",
              label=lambda h: f"{h.holiday_date} {h.name}")


@router.get("/hr/holidays")
def holiday_list(db: DbSession, _: CurrentUser, year: int | None = None):
    y = year or today().year
    return ok([{"date": d.isoformat(), "name": n, "optional": o} for d, n, o in db.execute(
        select(Holiday.holiday_date, Holiday.name, Holiday.is_optional)
        .where(Holiday.holiday_date.between(date(y, 1, 1), date(y, 12, 31))).order_by(Holiday.holiday_date)).all()])


@router.post("/leave-requests", status_code=201)
def apply_leave(body: LeaveIn, db: DbSession, p: Annotated[Principal, require("leave_request.create")]):
    return ok(leave_out(db, p, leave.apply(db, p, body), detail=True))


@router.get("/leave-requests")
def list_leave(db: DbSession, p: CurrentUser, params: Annotated[ListParams, Depends()], status: str | None = None,
               employee_id: uuid.UUID | None = None, mine: bool = False, date_from: date | None = None,
               date_to: date | None = None):
    if not p.can("leave_request.read") and not p.can("leave_request.create"):
        raise Forbidden()
    rows, meta = leave.list_requests(db, p, params, status=status, employee_id=employee_id, mine=mine,
                                     date_from=date_from, date_to=date_to)
    return {"data": [leave_out(db, p, r) for r in rows], "meta": meta.model_dump()}


@router.get("/leave-requests/{lid}")
def get_leave(lid: uuid.UUID, db: DbSession, p: CurrentUser):
    lr = leave.get(db, lid)
    leave.check(db, p, lr, "read")
    return ok(leave_out(db, p, lr, detail=True))


@router.post("/leave-requests/{lid}/cancel")
def cancel_leave(lid: uuid.UUID, body: ReasonIn, db: DbSession, p: CurrentUser):
    return ok(leave_out(db, p, leave.cancel(db, p, lid, body.reason), detail=True))


@router.get("/leave/balances")
def leave_balances(db: DbSession, p: CurrentUser, employee_id: uuid.UUID | None = None, year: int | None = None):
    me = employee_for_user(db, p.id)
    emp = db.get(Employee, employee_id) if employee_id else me
    if emp is None:
        raise NotFound("employee")
    if (me is None or emp.id != me.id) and not (p.can("hr_master.read") or p.scope("leave_request.read") == "all"):
        raise Forbidden()
    return ok(leave.balances(db, emp, year or today().year))


def _balance_report(db, year: int) -> tuple[list[dict], list[str]]:
    types = [t.code for t in db.scalars(select(LeaveType).where(LeaveType.is_active.is_(True)).order_by(LeaveType.code))]
    rows = []
    for e in db.scalars(select(Employee).where(Employee.is_active.is_(True)).order_by(Employee.full_name)):
        b = {x["code"]: x for x in leave.balances(db, e, year)}
        rows.append({"employee_id": str(e.id), "employee_code": e.employee_code, "name": e.full_name,
                     "balances": {c: {"available": b[c]["available"], "taken": b[c]["taken"], "pending": b[c]["pending"]}
                                  for c in types}})
    return rows, types


@router.get("/leave/balances/report")
def leave_balance_report(db: DbSession, _: Annotated[Principal, require("hr_master.read")], year: int | None = None):
    rows, types = _balance_report(db, year or today().year)
    return ok({"year": year or today().year, "types": types, "rows": rows})


@router.get("/leave/balances/export")
def leave_balance_export(db: DbSession, _: Annotated[Principal, require("hr_master.read")], year: int | None = None):
    y = year or today().year
    rows, types = _balance_report(db, y)
    cols = [excel.Column("employee_code", "Code", 10), excel.Column("name", "Employee", 28)]
    for c in types:
        cols += [excel.Column(f"{c}_taken", f"{c} taken", 10), excel.Column(f"{c}_available", f"{c} available", 12)]
    data = [{"employee_code": r["employee_code"], "name": r["name"],
             **{f"{c}_{k}": (D(r["balances"][c][k]) if r["balances"][c][k] is not None else None)
                for c in types for k in ("taken", "available")}} for r in rows]
    return _xlsx(excel.export(f"Leave {y}", cols, data), f"leave-balances-{y}")


@router.post("/leave-adjustments", status_code=201)
def leave_adjustment(body: AdjustmentIn, db: DbSession, p: Annotated[Principal, require("hr_master.create")]):
    emp = db.get(Employee, body.employee_id)
    t = db.get(LeaveType, body.leave_type_id)
    if emp is None or t is None:
        raise NotFound("employee")
    a = LeaveAdjustment(**body.model_dump(), created_by=p.id, updated_by=p.id)
    db.add(a)
    db.flush()
    audit.record(db, action="leave_adjustment", entity_type="employee", entity_id=emp.id,
                 entity_label=f"{emp.employee_code} {emp.full_name}",
                 summary=f"{t.code} {body.year}: {body.days:+g} day(s) — {body.reason}")
    return ok(leave.balances(db, emp, body.year))


# ------------------------------------------------------------------ attendance (HR)
@router.get("/attendance/register")
def attendance_register(db: DbSession, p: Annotated[Principal, require("attendance.read")],
                        month: str = Query(pattern=r"^\d{4}-\d{2}$")):
    if p.scope("attendance.read") != "all":
        me = employee_for_user(db, p.id)
        return ok(att.register(db, month, [me.id] if me else []))
    return ok(att.register(db, month))


@router.get("/attendance/register/export")
def attendance_export(db: DbSession, p: Annotated[Principal, require("attendance.export")],
                      month: str = Query(pattern=r"^\d{4}-\d{2}$")):
    if p.scope("attendance.read") != "all":
        raise Forbidden()
    reg = att.register(db, month)
    cols = [excel.Column("code", "Code", 9), excel.Column("name", "Employee", 26)] + \
        [excel.Column(f"d{i}", d[8:], 4) for i, d in enumerate(reg["dates"])] + \
        [excel.Column(k, t, 9) for k, t in (("present", "Present"), ("leave", "Leave"), ("absent", "Absent"),
                                             ("unmarked", "Unmarked"))]
    data = [{"code": r["employee_code"], "name": r["name"], **{f"d{i}": c["code"] for i, c in enumerate(r["days"])},
             **{k: (D(r["totals"][k]) if k != "unmarked" else r["totals"][k]) for k in ("present", "leave", "absent", "unmarked")}}
            for r in reg["rows"]]
    audit.record(db, action="export", entity_type="attendance", summary=f"Attendance register {month}")
    return _xlsx(excel.export(f"Attendance {month}", cols, data), f"attendance-{month}")


@router.get("/attendance/today")
def attendance_today(db: DbSession, p: Annotated[Principal, require("attendance.read")]):
    if p.scope("attendance.read") != "all":
        raise Forbidden()
    return ok(att.today_summary(db) | {"on_leave_today": leave.on_leave_today(db)})


@router.get("/attendance/projects")
def attendance_projects(db: DbSession, p: Annotated[Principal, require("attendance.update")]):
    """Open projects to pick a site when HR marks a day (HR may not have access to the projects module)."""
    rows = db.execute(select(Project.id, Project.project_number, Project.name)
                      .where(Project.status.not_in(("completed", "cancelled"))).order_by(Project.project_number.desc())).all()
    return ok([{"id": str(i), "project_number": n, "name": nm} for i, n, nm in rows])


@router.post("/attendance/mark")
def attendance_mark(body: MarkIn, db: DbSession, p: Annotated[Principal, require("attendance.update")]):
    return ok(att.att_out(att.mark(db, p, body)))


@router.get("/hr/summary")
def hr_summary(db: DbSession, p: CurrentUser):
    if p.scope("attendance.read") != "all" and p.scope("leave_request.read") != "all":
        raise Forbidden()
    pending = db.scalar(select(func.count()).select_from(LeaveRequest).where(LeaveRequest.status == "pending")) or 0
    out = {"today": att.today_summary(db), "on_leave_today": leave.on_leave_today(db), "pending_leave": pending}
    if p.can("employee_private.read"):
        t = today()
        soon = []
        for e in db.scalars(select(Employee).where(Employee.is_active.is_(True), Employee.date_of_birth.is_not(None))):
            try:
                nxt = e.date_of_birth.replace(year=t.year)
            except ValueError:  # 29 Feb
                nxt = date(t.year, 3, 1)
            if nxt < t:
                nxt = nxt.replace(year=t.year + 1) if not (nxt.month == 2 and nxt.day == 29) else date(t.year + 1, 3, 1)
            if (nxt - t).days <= 14:
                soon.append({"name": e.full_name, "date": nxt.isoformat()})
        out["birthdays"] = sorted(soon, key=lambda x: x["date"])
    return ok(out)


# ------------------------------------------------------------------ profile, private details, salary
@router.get("/employees/{employee_id}/profile")
def employee_profile(employee_id: uuid.UUID, db: DbSession, p: CurrentUser):
    e = db.get(Employee, employee_id)
    if e is None:
        raise NotFound("employee")
    me = employee_for_user(db, p.id)
    self_ = me is not None and me.id == e.id
    if not (self_ or p.can("employee.read")):
        raise Forbidden()
    private = self_ or p.can("employee_private.read")
    t = today()
    projects = _my_projects(db, e.user_id) if e.user_id else []
    reports = [{"id": str(i), "name": n} for i, n in db.execute(
        select(Employee.id, Employee.full_name).where(Employee.reports_to_id == e.id, Employee.is_active.is_(True))).all()]
    manager = db.scalar(select(Employee.full_name).where(Employee.id == e.reports_to_id)) if e.reports_to_id else None
    hr_view = private or p.scope("leave_request.read") == "all"
    month = t.strftime("%Y-%m")
    return ok({
        **employee_out(e), "reports_to": manager, "team": reports, "projects": projects,
        "private": private_out(e) if private else None,
        "balances": leave.balances(db, e, t.year) if hr_view else None,
        "attendance_month": att.register(db, month, [e.id])["rows"][0]["totals"]
        if (self_ or p.scope("attendance.read") == "all") else None,
        "can": {"private": p.can("employee_private.update"), "salary": p.can("salary.read"),
                "salary_add": p.can("salary.create"), "edit": p.can("employee.update"),
                "adjust_leave": p.can("hr_master.create"), "mark": p.scope("attendance.update") == "all"},
    })


@router.put("/employees/{employee_id}/private")
def update_private(employee_id: uuid.UUID, body: PrivateIn, db: DbSession,
                   p: Annotated[Principal, require("employee_private.update")]):
    from app.core.models import check_row_version

    e = db.get(Employee, employee_id)
    if e is None:
        raise NotFound("employee")
    check_row_version(e, body.row_version)
    data = body.model_dump(exclude={"row_version"})
    changed = [k for k, v in data.items() if (str(v) if v is not None else None) !=
               (str(getattr(e, k)) if getattr(e, k) is not None else None)]
    for k, v in data.items():
        setattr(e, k, str(v) if k == "personal_email" and v else v)
    e.updated_by = p.id
    e.row_version += 1
    db.flush()
    # names of the changed fields only — no personal values in the audit log
    audit.record(db, action="update_private", entity_type="employee", entity_id=e.id,
                 entity_label=f"{e.employee_code} {e.full_name}",
                 summary="Personal / employment details changed: " + (", ".join(changed) or "none"))
    return ok(private_out(e) | {"row_version": e.row_version})


@router.get("/employees/{employee_id}/salary")
def salary_records(employee_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("salary.read")]):
    return ok(salary.list_records(db, p, employee_id))


@router.post("/employees/{employee_id}/salary", status_code=201)
def add_salary(employee_id: uuid.UUID, body: SalaryIn, db: DbSession, p: Annotated[Principal, require("salary.create")]):
    return ok(salary.record_out(salary.add_record(db, p, employee_id, body)))


@router.get("/hr/labour-cost")
def labour_cost_preview(db: DbSession, p: Annotated[Principal, require("labour_cost.create")],
                        month: str = Query(pattern=r"^\d{4}-\d{2}$")):
    return ok(salary.labour_preview(db, p, month))


@router.post("/hr/labour-cost/post")
def labour_cost_post(body: MonthIn, db: DbSession, p: Annotated[Principal, require("labour_cost.create")]):
    return ok(salary.post_labour(db, p, body.month))
