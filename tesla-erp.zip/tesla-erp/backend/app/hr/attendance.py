"""Attendance (Spec §26): employees check in and out from their phone (with location when the phone allows it), HR
marks and corrects, a monthly register shows everyone, and days worked at a project site feed labour cost."""
import calendar
import uuid
from datetime import date
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.core.errors import AppError, Forbidden, NotFound
from app.crm.service import now, today
from app.hr.leave import holidays_between, is_weekly_off
from app.hr.models import Attendance, Employee
from app.hr.service import employee_for_user
from app.platform.audit import service as audit
from app.platform.settings import service as settings
from app.projects.models import Project

Z = Decimal("0")
CODES = {"present": "P", "half_day": "½", "absent": "A", "on_leave": "L", "on_duty": "OD", "holiday": "H",
         "weekly_off": "WO"}
DAY_VALUE = {"present": Decimal(1), "on_duty": Decimal(1), "half_day": Decimal("0.5")}


def _me(db: Session, p: Principal) -> Employee:
    emp = employee_for_user(db, p.id)
    if emp is None:
        raise AppError("NO_EMPLOYEE_RECORD", "Your login is not linked to an employee record. Ask HR to link it.")
    if not emp.is_active:
        raise AppError("EMPLOYEE_INACTIVE", "Your employee record is inactive.")
    return emp


def _row(db: Session, emp_id: uuid.UUID, d: date, lock: bool = True) -> Attendance | None:
    stmt = select(Attendance).where(Attendance.employee_id == emp_id, Attendance.att_date == d)
    return db.scalar(stmt.with_for_update() if lock else stmt)


def _project(db: Session, pid) -> Project | None:
    if not pid:
        return None
    prj = db.get(Project, pid)
    if prj is None:
        raise NotFound("project")
    if prj.status in ("completed", "cancelled"):
        raise AppError("PROJECT_CLOSED", f"Project {prj.project_number} is {prj.status}.")
    return prj


def check_in(db: Session, p: Principal, data) -> Attendance:
    if not p.can("attendance.create"):
        raise Forbidden()
    emp = _me(db, p)
    t = today()
    prj = _project(db, data.project_id)
    row = _row(db, emp.id, t)
    if row is not None and row.check_in_at is not None:
        raise AppError("ALREADY_CHECKED_IN", f"You checked in today at {row.check_in_at.astimezone().strftime('%I:%M %p')}.")
    if row is not None and row.status == "on_leave":
        raise AppError("ON_LEAVE", "You are on approved leave today. Cancel the leave first if you are working.")
    if row is None:
        row = Attendance(employee_id=emp.id, att_date=t, status="present", source="self", created_by=p.id)
        db.add(row)
    row.status = "on_duty" if data.on_duty else "present"
    row.check_in_at, row.project_id, row.remarks, row.updated_by = now(), prj.id if prj else None, data.remarks, p.id
    row.check_in_lat, row.check_in_lng, row.check_in_accuracy_m = data.lat, data.lng, data.accuracy_m
    db.flush()
    audit.record(db, action="check_in", entity_type="attendance", entity_id=row.id, entity_label=f"{emp.full_name} {t}",
                 summary=f"Checked in{' at ' + prj.project_number if prj else ''}"
                         + (" (location captured)" if data.lat is not None else " (no location)"))
    return row


def check_out(db: Session, p: Principal, data) -> Attendance:
    emp = _me(db, p)
    row = _row(db, emp.id, today())
    if row is None or row.check_in_at is None:
        raise AppError("NOT_CHECKED_IN", "You have not checked in today.")
    if row.check_out_at is not None:
        raise AppError("ALREADY_CHECKED_OUT", "You have already checked out today.")
    row.check_out_at, row.check_out_lat, row.check_out_lng = now(), data.lat, data.lng
    hours = Decimal((row.check_out_at - row.check_in_at).total_seconds() / 3600).quantize(Decimal("0.01"))
    row.work_hours, row.updated_by = hours, p.id
    if data.remarks:
        row.remarks = data.remarks
    min_full = Decimal(str(settings.get_setting(db, p.company_id, "hr.full_day_hours") or 0))
    if min_full and hours < min_full / 2 and row.status == "present":
        row.status = "half_day"
    db.flush()
    audit.record(db, action="check_out", entity_type="attendance", entity_id=row.id,
                 entity_label=f"{emp.full_name} {row.att_date}", summary=f"Checked out after {hours} h")
    return row


def mark(db: Session, p: Principal, data) -> Attendance:
    """HR marks or corrects a day for anyone (absent, present, on duty, holiday…)."""
    if p.scope("attendance.update") != "all":
        raise Forbidden("Only HR can mark or correct attendance.")
    emp = db.get(Employee, data.employee_id)
    if emp is None:
        raise NotFound("employee")
    if data.att_date > today():
        raise AppError("FUTURE_DATE", "Attendance cannot be marked for a future date.")
    prj = _project(db, data.project_id) if data.project_id else None
    row = _row(db, emp.id, data.att_date)
    before = audit.snapshot(row) if row else None
    if row is None:
        row = Attendance(employee_id=emp.id, att_date=data.att_date, status=data.status, source="hr", created_by=p.id)
        db.add(row)
    row.status, row.project_id, row.source, row.updated_by = data.status, prj.id if prj else None, "hr", p.id
    row.remarks = data.remarks
    if data.check_in_at is not None:
        row.check_in_at = data.check_in_at
    if data.check_out_at is not None:
        row.check_out_at = data.check_out_at
    if row.check_in_at and row.check_out_at:
        row.work_hours = Decimal((row.check_out_at - row.check_in_at).total_seconds() / 3600).quantize(Decimal("0.01"))
    db.flush()
    audit.record(db, action="mark" if before is None else "correct", entity_type="attendance", entity_id=row.id,
                 entity_label=f"{emp.full_name} {data.att_date}", summary=f"{data.status} (by HR)"
                 + (f": {data.remarks}" if data.remarks else ""), before=before, after=audit.snapshot(row))
    return row


def month_bounds(month: str) -> tuple[date, date]:
    try:
        y, m = (int(x) for x in month.split("-"))
        return date(y, m, 1), date(y, m, calendar.monthrange(y, m)[1])
    except (ValueError, TypeError) as exc:
        raise AppError("INVALID_MONTH", "Month must look like 2026-10.") from exc


def register(db: Session, month: str, employee_ids: list[uuid.UUID] | None = None) -> dict:
    """Monthly register: one row per employee, one cell per day, with totals."""
    d1, d2 = month_bounds(month)
    t = today()
    hol = holidays_between(db, d1, d2)
    stmt = select(Employee).where(Employee.is_active.is_(True)).order_by(Employee.full_name)
    if employee_ids is not None:
        stmt = select(Employee).where(Employee.id.in_(employee_ids))
    emps = db.scalars(stmt).all()
    rows = {(a.employee_id, a.att_date): a for a in db.scalars(select(Attendance).where(
        Attendance.att_date.between(d1, d2), Attendance.employee_id.in_([e.id for e in emps])))}
    prj = dict(db.execute(select(Project.id, Project.project_number)).all())
    days = [date(d1.year, d1.month, i) for i in range(1, d2.day + 1)]
    out = []
    for e in emps:
        cells, tot = [], {"present": Z, "absent": Z, "leave": Z, "holiday": 0, "weekly_off": 0, "unmarked": 0}
        for d in days:
            a = rows.get((e.id, d))
            if a is not None:
                st = a.status
            elif d in hol:
                st = "holiday"
            elif is_weekly_off(e, d):
                st = "weekly_off"
            else:
                st = None
            if st in ("present", "on_duty"):
                tot["present"] += 1
            elif st == "half_day":
                tot["present"] += Decimal("0.5")
                tot["leave" if a is not None and a.source == "leave" else "absent"] += Decimal("0.5")
            elif st == "absent":
                tot["absent"] += 1
            elif st == "on_leave":
                tot["leave"] += 1
            elif st in ("holiday", "weekly_off"):
                tot[st] += 1
            elif d <= t and (e.date_of_joining is None or d >= e.date_of_joining):
                tot["unmarked"] += 1
            cells.append({"date": d.isoformat(), "status": st, "code": CODES.get(st, ""),
                          "project": prj.get(a.project_id) if a is not None and a.project_id else None,
                          "project_id": str(a.project_id) if a is not None and a.project_id else None,
                          "in": a.check_in_at.isoformat() if a is not None and a.check_in_at else None,
                          "out": a.check_out_at.isoformat() if a is not None and a.check_out_at else None,
                          "hours": str(a.work_hours) if a is not None and a.work_hours is not None else None,
                          "located": bool(a is not None and a.check_in_lat is not None)})
        out.append({"employee_id": str(e.id), "employee_code": e.employee_code, "name": e.full_name, "days": cells,
                    "totals": {k: (f"{v:g}" if isinstance(v, Decimal) else v) for k, v in tot.items()}})
    return {"month": month, "dates": [d.isoformat() for d in days], "holidays": {k.isoformat(): v for k, v in hol.items()},
            "rows": out}


def today_summary(db: Session) -> dict:
    t = today()
    total = db.scalar(select(func.count()).select_from(Employee).where(Employee.is_active.is_(True))) or 0
    rows = db.scalars(select(Attendance).where(Attendance.att_date == t)).all()
    by: dict[str, int] = {}
    for a in rows:
        by[a.status] = by.get(a.status, 0) + 1
    marked = len(rows)
    return {"date": t.isoformat(), "employees": total, "present": by.get("present", 0) + by.get("on_duty", 0),
            "half_day": by.get("half_day", 0), "on_leave": by.get("on_leave", 0), "absent": by.get("absent", 0),
            "not_marked": max(total - marked, 0), "holiday": bool(holidays_between(db, t, t))}


def att_out(a: Attendance | None) -> dict | None:
    if a is None:
        return None
    return {"id": str(a.id), "date": a.att_date.isoformat(), "status": a.status,
            "check_in_at": a.check_in_at.isoformat() if a.check_in_at else None,
            "check_out_at": a.check_out_at.isoformat() if a.check_out_at else None,
            "work_hours": str(a.work_hours) if a.work_hours is not None else None,
            "project_id": str(a.project_id) if a.project_id else None,
            "located": a.check_in_lat is not None, "source": a.source, "remarks": a.remarks}
