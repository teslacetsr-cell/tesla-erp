"""Holidays, working days, leave balances and leave requests (Spec §26).

A leave request counts working days only (weekly off and company holidays are skipped). It goes to the employee's
line manager (approval rules → Leave requests, default: Line manager). When approved, those days are marked
"on leave" in attendance; cancelling an approved leave clears them again.
"""
import uuid
from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy import delete, func, or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.core.api import ListParams, paginate
from app.core.errors import AppError, Conflict, Forbidden, NotFound
from app.crm.service import now, today
from app.hr.models import Attendance, Employee, Holiday, LeaveAdjustment, LeaveRequest, LeaveType
from app.hr.service import employee_for_user
from app.platform.approvals import service as approvals
from app.platform.audit import service as audit
from app.platform.notifications.service import notify, users_with_roles

Z = Decimal("0")
WEEKDAYS = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")


# ------------------------------------------------------------------ calendar
def holidays_between(db: Session, d1: date, d2: date) -> dict[date, str]:
    return dict(db.execute(select(Holiday.holiday_date, Holiday.name).where(
        Holiday.holiday_date.between(d1, d2), Holiday.is_optional.is_(False))).all())


def is_weekly_off(emp: Employee, d: date) -> bool:
    offs = (emp.weekly_off or "sun").split(",")
    return WEEKDAYS[d.weekday()] in offs


def working_days(db: Session, emp: Employee, d1: date, d2: date) -> list[date]:
    hol = holidays_between(db, d1, d2)
    out, d = [], d1
    while d <= d2:
        if not is_weekly_off(emp, d) and d not in hol:
            out.append(d)
        d += timedelta(days=1)
    return out


# ------------------------------------------------------------------ balances
def balances(db: Session, emp: Employee, year: int) -> list[dict]:
    """Per leave type: quota, adjustments (opening / carry-forward), taken (approved), pending, available."""
    y1, y2 = date(year, 1, 1), date(year, 12, 31)
    taken = dict(db.execute(select(LeaveRequest.leave_type_id, func.sum(LeaveRequest.days)).where(
        LeaveRequest.employee_id == emp.id, LeaveRequest.status == "approved",
        LeaveRequest.from_date.between(y1, y2)).group_by(LeaveRequest.leave_type_id)).all())
    pending = dict(db.execute(select(LeaveRequest.leave_type_id, func.sum(LeaveRequest.days)).where(
        LeaveRequest.employee_id == emp.id, LeaveRequest.status == "pending",
        LeaveRequest.from_date.between(y1, y2)).group_by(LeaveRequest.leave_type_id)).all())
    adj = dict(db.execute(select(LeaveAdjustment.leave_type_id, func.sum(LeaveAdjustment.days)).where(
        LeaveAdjustment.employee_id == emp.id, LeaveAdjustment.year == year).group_by(LeaveAdjustment.leave_type_id)).all())
    out = []
    for t in db.scalars(select(LeaveType).where(LeaveType.is_active.is_(True)).order_by(LeaveType.code)):
        q = t.annual_quota
        a, tk, pd = Decimal(adj.get(t.id, Z)), Decimal(taken.get(t.id, Z)), Decimal(pending.get(t.id, Z))
        out.append({"leave_type_id": str(t.id), "code": t.code, "name": t.name, "paid": t.paid,
                    "quota": str(q) if q is not None else None, "adjustments": str(a), "taken": str(tk),
                    "pending": str(pd), "available": str((q or Z) + a - tk - pd) if q is not None else None})
    return out


# ------------------------------------------------------------------ requests
def _own_employee(db: Session, p: Principal) -> Employee | None:
    return employee_for_user(db, p.id)


def check(db: Session, p: Principal, lr: LeaveRequest, action: str) -> None:
    scope = p.scope(f"leave_request.{action}")
    me = _own_employee(db, p)
    if me is not None and lr.employee_id == me.id and action in ("read", "create"):
        return
    req = approvals.pending_for(db, "leave_request", lr.id)
    if action == "read" and req is not None and approvals.can_decide(p, req):
        return  # the approver can see what they approve
    if action == "read" and me is not None and db.scalar(select(Employee.reports_to_id).where(Employee.id == lr.employee_id)) == me.id:
        return  # a line manager sees their team's leave
    if scope is None or scope == "own":
        raise Forbidden("You can only see your own leave.", code="OUT_OF_SCOPE")


def get(db: Session, lid: uuid.UUID, lock: bool = False) -> LeaveRequest:
    lr = db.get(LeaveRequest, lid, with_for_update=lock or None)
    if lr is None:
        raise NotFound("leave_request")
    return lr


def compute_days(db: Session, emp: Employee, t: LeaveType, d1: date, d2: date, half_day: str) -> Decimal:
    if d2 < d1:
        raise AppError("INVALID_DATES", "The leave ends before it starts.", details={"field": "to_date"})
    if d1.year != d2.year:
        raise AppError("SPANS_YEARS", "Leave across the year end must be applied as two requests (one per year).")
    if half_day != "none":
        if d1 != d2:
            raise AppError("HALF_DAY_ONE_DATE", "A half day is for a single date.", details={"field": "half_day"})
        if not t.allow_half_day:
            raise AppError("NO_HALF_DAY", f"{t.name} cannot be taken as a half day.")
    days = Decimal(len(working_days(db, emp, d1, d2)))
    if days == 0:
        raise AppError("NO_WORKING_DAYS", "Those dates are all weekly offs or holidays.")
    return Decimal("0.5") if half_day != "none" else days


def apply(db: Session, p: Principal, data) -> LeaveRequest:
    me = _own_employee(db, p)
    emp_id = data.employee_id or (me.id if me else None)
    if emp_id is None:
        raise AppError("NO_EMPLOYEE_RECORD", "Your login is not linked to an employee record. Ask HR to link it.")
    if (me is None or emp_id != me.id) and p.scope("leave_request.update") != "all":
        raise Forbidden("You can only apply for your own leave.", code="OUT_OF_SCOPE")
    emp = db.get(Employee, emp_id)
    if emp is None or not emp.is_active:
        raise AppError("INVALID_EMPLOYEE", "Choose an active employee.")
    t = db.get(LeaveType, data.leave_type_id)
    if t is None or not t.is_active:
        raise AppError("INVALID_LEAVE_TYPE", "Choose a leave type.", details={"field": "leave_type_id"})
    days = compute_days(db, emp, t, data.from_date, data.to_date, data.half_day)
    clash = db.scalar(select(LeaveRequest).where(
        LeaveRequest.employee_id == emp.id, LeaveRequest.status.in_(("pending", "approved")),
        LeaveRequest.from_date <= data.to_date, LeaveRequest.to_date >= data.from_date))
    if clash is not None:
        raise Conflict("LEAVE_OVERLAP", f"There is already a {clash.status} leave from {clash.from_date:%d %b} to "
                                        f"{clash.to_date:%d %b}.")
    if t.annual_quota is not None:
        bal = next(b for b in balances(db, emp, data.from_date.year) if b["leave_type_id"] == str(t.id))
        if days > Decimal(bal["available"]):
            raise AppError("INSUFFICIENT_LEAVE", f"Only {bal['available']} day(s) of {t.name} are available "
                                                 f"({days} asked).", details={"available": bal["available"]})
    lr = LeaveRequest(employee_id=emp.id, leave_type_id=t.id, from_date=data.from_date, to_date=data.to_date,
                      half_day=data.half_day, days=days, reason=data.reason, status="pending", created_by=p.id,
                      updated_by=p.id)
    db.add(lr)
    db.flush()
    label = f"{emp.full_name} · {t.code} {days:g} day(s) · {data.from_date:%d %b}" + \
        (f"–{data.to_date:%d %b}" if data.to_date != data.from_date else "")
    req = approvals.start(db, p, entity_type="leave_request", entity_id=lr.id, label=label, amount=days,
                          division_id=emp.division_id)
    if req is None:
        _approve(db, p, lr)
    audit.record(db, action="create", entity_type="leave_request", entity_id=lr.id, entity_label=label,
                 summary=f"{t.name}: {data.reason}" + ("" if req else " — no approval rule applies, approved"))
    return lr


def _approve(db: Session, p: Principal, lr: LeaveRequest) -> None:
    lr.status, lr.decided_at, lr.updated_by = "approved", now(), p.id
    emp = db.get(Employee, lr.employee_id)
    status = "half_day" if lr.half_day != "none" else "on_leave"
    for d in working_days(db, emp, lr.from_date, lr.to_date):
        row = db.scalar(select(Attendance).where(Attendance.employee_id == emp.id, Attendance.att_date == d))
        if row is None:
            db.add(Attendance(employee_id=emp.id, att_date=d, status=status, source="leave", leave_request_id=lr.id,
                              remarks="Approved leave", created_by=p.id, updated_by=p.id))
        elif row.check_in_at is None:  # never overwrite a day the employee actually checked in
            row.status, row.source, row.leave_request_id, row.updated_by = status, "leave", lr.id, p.id
    db.flush()
    if emp.user_id:
        notify(db, [emp.user_id], event="leave.approved", exclude=p.id, title="Your leave is approved",
               body=f"{lr.from_date:%d %b} – {lr.to_date:%d %b} ({lr.days:g} day(s))", link="/hr/me")


def _on_approved(db: Session, p: Principal, req) -> None:
    lr = get(db, req.entity_id, lock=True)
    if lr.status == "pending":
        _approve(db, p, lr)
        lr.row_version += 1


def _on_rejected(db: Session, p: Principal, req, comment: str) -> None:
    lr = get(db, req.entity_id, lock=True)
    lr.status, lr.status_reason, lr.decided_at = "rejected", comment[:500], now()
    lr.row_version += 1


def _subject(db: Session, lid: uuid.UUID) -> uuid.UUID | None:
    return db.scalar(select(Employee.user_id).join(LeaveRequest, LeaveRequest.employee_id == Employee.id)
                     .where(LeaveRequest.id == lid))


approvals.register("leave_request", approvals.Handler(
    label="Leave request", href=lambda i: f"/hr/leave/view?id={i}", on_approved=_on_approved,
    on_rejected=_on_rejected, owners=lambda db, i: [x for x in [_subject(db, i)] if x], subject=_subject))


def cancel(db: Session, p: Principal, lid: uuid.UUID, reason: str | None) -> LeaveRequest:
    lr = get(db, lid, lock=True)
    me = _own_employee(db, p)
    mine = me is not None and lr.employee_id == me.id
    hr = p.scope("leave_request.update") == "all"
    if not (mine or hr):
        raise Forbidden()
    if lr.status not in ("pending", "approved"):
        raise AppError("INVALID_TRANSITION", f"A {lr.status} leave cannot be cancelled.")
    if lr.status == "approved" and lr.from_date <= today() and not hr:
        raise AppError("LEAVE_STARTED", "Leave that has started can be cancelled only by HR.")
    approvals.withdraw(db, p, "leave_request", lr.id)
    if lr.status == "approved":
        db.execute(delete(Attendance).where(Attendance.leave_request_id == lr.id, Attendance.source == "leave"))
    lr.status, lr.status_reason, lr.updated_by = "cancelled", (reason or "")[:500] or None, p.id
    lr.row_version += 1
    db.flush()
    audit.record(db, action="cancel", entity_type="leave_request", entity_id=lr.id,
                 entity_label=f"Leave {lr.from_date:%d %b}", summary=reason)
    if not mine:
        emp = db.get(Employee, lr.employee_id)
        if emp.user_id:
            notify(db, [emp.user_id], event="leave.cancelled", title="Your leave was cancelled by HR",
                   body=reason or "", link="/hr/me")
    return lr


def list_requests(db: Session, p: Principal, params: ListParams, *, status=None, employee_id=None, mine=False,
                  date_from=None, date_to=None):
    stmt = select(LeaveRequest)
    me = _own_employee(db, p)
    if p.scope("leave_request.read") != "all" or mine:
        stmt = stmt.where(LeaveRequest.employee_id == (me.id if me else None))
    for col, val in ((LeaveRequest.status, status), (LeaveRequest.employee_id, employee_id)):
        if val:
            stmt = stmt.where(col == val)
    if date_from:
        stmt = stmt.where(LeaveRequest.to_date >= date_from)
    if date_to:
        stmt = stmt.where(LeaveRequest.from_date <= date_to)
    if params.q:
        stmt = stmt.where(or_(LeaveRequest.reason.ilike(f"%{params.q}%"), LeaveRequest.employee_id.in_(
            select(Employee.id).where(Employee.full_name.ilike(f"%{params.q}%")))))
    return paginate(db, stmt, params, default_sort=LeaveRequest.from_date.desc(), sortable={
        "from_date": LeaveRequest.from_date, "created_at": LeaveRequest.created_at})


def on_leave_today(db: Session) -> list[dict]:
    t = today()
    rows = db.execute(select(Employee.full_name, LeaveType.code, LeaveRequest.to_date)
                      .join(Employee, Employee.id == LeaveRequest.employee_id)
                      .join(LeaveType, LeaveType.id == LeaveRequest.leave_type_id)
                      .where(LeaveRequest.status == "approved", LeaveRequest.from_date <= t,
                             LeaveRequest.to_date >= t)).all()
    return [{"name": n, "type": c, "until": u.isoformat()} for n, c, u in rows]


def hr_people(db: Session) -> list[uuid.UUID]:
    return users_with_roles(db, ["HR"])
