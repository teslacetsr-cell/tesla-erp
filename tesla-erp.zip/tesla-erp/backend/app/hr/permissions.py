from app.core.permissions import register

register("org_master", "Departments & designations", ("create", "read", "update", "delete"))
register("employee", "Employees", ("create", "read", "update", "delete", "export"))
# Phase 8
register("employee_private", "Employee personal, ID and bank details (HR only)", ("read", "update"))
# 'own' scope: the employee's own records. Everyone marks their own attendance and applies for their own leave.
register("attendance", "Attendance (create = mark own; update = HR marks / corrects anyone's)",
         ("create", "read", "update", "export"), scoped=("read",))
register("leave_request", "Leave requests (approve = HR approval step; line managers approve their team regardless)",
         ("create", "read", "update", "approve", "export"), scoped=("read",))
register("hr_master", "Leave types, holidays and leave balances", ("create", "read", "update", "delete"))
register("salary", "Salary records (confidential)", ("create", "read", "export"))
register("labour_cost", "Post labour cost to projects from attendance", ("create",))
