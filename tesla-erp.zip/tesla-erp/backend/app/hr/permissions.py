from app.core.permissions import register

register("org_master", "Departments & designations", ("create", "read", "update", "delete"))
register("employee", "Employees", ("create", "read", "update", "delete", "export"))
