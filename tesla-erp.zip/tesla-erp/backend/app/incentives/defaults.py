"""The standard Tesla Consulting Engineers scheme: seeded once, and restorable from Incentive Setup."""
from decimal import Decimal

CATEGORIES = [  # (code, name)
    ("solar", "Solar project"),
    ("solar_doc", "Solar documentation only"),
    ("solar_cr", "Solar completion report only"),
    ("consulting", "Consulting only"),
    ("electrical", "Electrical project"),
    ("lps", "Lightning protection project"),
]

ROLES = [  # (code, name)
    ("am", "Assistant Manager – Solar & Lightning Protection"),
    ("bde", "Business Development Executive"),
    ("je", "Jr. Engineer – Electrical Designs"),
    ("pe", "Project Engineer"),
    ("acc", "Accountant"),
    ("oa", "Office Assistant"),
    ("dm", "Draftsman"),
]

NONCONS = ["solar", "solar_doc", "solar_cr", "electrical", "lps"]


def _r(role, label, cats, trigger, basis, value, govt="any", tender="any", ei=False):
    return {"role": role, "label": label, "categories": cats, "trigger": trigger, "basis": basis,
            "value": Decimal(str(value)), "govt": govt, "tender": tender, "requires_ei_kseb": ei}


RULES = [
    _r("am", "Solar subsidy received & final docs submitted", ["solar"], "subsidy", "pct", 0.1),
    _r("am", "Solar final payment received", ["solar"], "billPaid", "pct", 0.1),
    _r("am", "Documentation-only projects", ["solar_doc"], "billPaid", "pct", 0.05),
    _r("am", "Electrical & lightning protection", ["electrical", "lps"], "billPaid", "pct", 0.05, govt="no"),
    _r("bde", "Consulting-only", ["consulting"], "billPaid", "pct", 5),
    _r("bde", "Govt projects", NONCONS, "billPaid", "pct", 0.2, govt="yes", tender="no"),
    _r("bde", "Govt projects started from tendering", NONCONS, "billPaid", "pct", 0.25, govt="yes", tender="yes"),
    _r("bde", "Other electrical projects", ["electrical"], "billPaid", "pct", 0.5, govt="no"),
    _r("bde", "Lightning protection", ["lps"], "billPaid", "pct", 2, govt="no"),
    _r("je", "Consulting-only", ["consulting"], "billPaid", "pct", 2.5),
    _r("je", "Solar", ["solar"], "billPaid", "pct", 0.05),
    _r("je", "EI & KSEB documentation", ["*"], "finalPaid", "fixed", 1000, ei=True),
    _r("pe", "Solar", ["solar"], "billPaid", "pct", 0.5),
    _r("pe", "Other electrical", ["electrical"], "billPaid", "pct", 0.1),
    _r("pe", "Lightning protection", ["lps"], "billPaid", "pct", 0.25),
    _r("acc", "All account statements proper", ["*"], "monthly", "pct", 0.1),
    _r("oa", "Solar subsidy received & final docs submitted", ["solar"], "subsidy", "pct", 0.05),
    _r("oa", "Solar final payment received", ["solar"], "billPaid", "pct", 0.05),
    _r("oa", "Documentation-only", ["solar_doc"], "billPaid", "pct", 0.025),
    _r("oa", "Solar completion report only", ["solar_cr"], "billPaid", "pct", 5),
    _r("oa", "All other billing", ["consulting", "electrical", "lps"], "billPaid", "pct", 0.01),
    _r("dm", "Consulting-only", ["consulting"], "billPaid", "pct", 0.5),
    _r("dm", "Solar", ["solar"], "billPaid", "pct", 0.025),
    _r("dm", "EI & KSEB documentation", ["*"], "finalPaid", "fixed", 250, ei=True),
]

WELFARE_PCT = Decimal("0.5")
ELIGIBLE_AFTER_MONTHS = 3          # incentives start 3 months after the date of joining
