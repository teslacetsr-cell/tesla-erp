"""Incentives: loading ERP data into the engine, months (draft / approve & lock / unlock), payment follow-up,
project incentive settings, performance ratings, reports and scheme setup."""
import uuid
from collections import defaultdict
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.core.errors import AppError, Conflict, Forbidden, NotFound
from app.crm.models import Enquiry, Lead
from app.crm.service import now, today
from app.customers.models import Customer
from app.finance.models import CreditNote, Invoice, Receipt, ReceiptAllocation
from app.hr.models import Employee
from app.incentives import defaults
from app.incentives import engine as E
from app.incentives.models import (
    CRITERIA,
    IncentiveBillFollowup,
    IncentiveCategory,
    IncentiveLine,
    IncentiveMonth,
    IncentivePayout,
    IncentiveRole,
    IncentiveRoleMember,
    IncentiveRule,
    PerformanceRating,
    ProjectIncentiveSettings,
)
from app.platform.audit import service as audit
from app.platform.settings import service as settings
from app.projects.models import Project
from app.quotations.models import Quotation
from app.sales.models import SalesOrder

Z = Decimal("0")


def plain(v) -> str:
    """Decimal without trailing zeros or exponent: 1000.0000 → '1000', 0.0500 → '0.05'."""
    return format(Decimal(v).normalize(), "f")
CLOSED = ("cancelled",)


# ============================================================================================ months & FY
def check_ym(ym: str) -> str:
    try:
        y, m = (int(x) for x in ym.split("-"))
        if not (2000 <= y <= 2100 and 1 <= m <= 12):
            raise ValueError
    except (ValueError, AttributeError) as exc:
        raise AppError("INVALID_MONTH", "Month must look like 2026-11.") from exc
    return f"{y:04d}-{m:02d}"


def fy_of(ym: str) -> int:
    y, m = (int(x) for x in ym.split("-"))
    return y if m >= 4 else y - 1


def fy_months(fy: int) -> list[str]:
    return [f"{fy + (1 if i >= 9 else 0):04d}-{(i + 3) % 12 + 1:02d}" for i in range(12)]


def current_ym() -> str:
    t = today()
    return f"{t.year:04d}-{t.month:02d}"


def welfare_pct(db: Session, company_id) -> Decimal:
    raw = settings.get_setting(db, company_id, "incentive.welfare_pct")
    try:
        v = Decimal(str(raw))
        return v if v >= 0 else defaults.WELFARE_PCT
    except (InvalidOperation, ValueError):
        return defaults.WELFARE_PCT


# ============================================================================================ scheme
def load_rules(db: Session) -> list[E.Rule]:
    roles = {r.id: r for r in db.scalars(select(IncentiveRole).where(IncentiveRole.is_active.is_(True)))}
    out = []
    for r in db.scalars(select(IncentiveRule).where(IncentiveRule.is_active.is_(True))
                        .order_by(IncentiveRule.sort_order, IncentiveRule.created_at)):
        if r.role_id in roles:
            out.append(E.Rule(id=r.id, role_id=str(r.role_id), role_name=roles[r.role_id].name, label=r.label,
                              trigger=r.trigger, basis=r.basis, value=Decimal(r.value),
                              categories=tuple(r.categories or ["*"]), govt=r.govt, tender=r.tender,
                              requires_ei_kseb=r.requires_ei_kseb))
    return out


def eligible_after(db: Session, company_id=None) -> int:
    from app.auth.deps import default_company_id

    raw = settings.get_setting(db, company_id or default_company_id(db), "incentive.eligible_after_months")
    try:
        return max(0, int(raw))
    except (TypeError, ValueError):
        return 3


def eligible_from(joined: date | None, months: int) -> date | None:
    """First day an employee can earn incentives; None when the date of joining is not recorded."""
    return E.add_months(joined, months) if joined else None


def load_members(db: Session) -> dict:
    months = eligible_after(db)
    out: dict = defaultdict(list)
    for m, e in db.execute(select(IncentiveRoleMember, Employee).join(Employee, Employee.id == IncentiveRoleMember.employee_id)
                           .order_by(Employee.full_name)):
        out[str(m.role_id)].append(E.Member(str(e.id), e.full_name, active=bool(m.is_active and e.is_active),
                                            eligible_from=eligible_from(e.date_of_joining, months)))
    return dict(out)


# ============================================================================================ bills from invoices
def _paid_dates(db: Session, invoices: list[Invoice]) -> dict:
    """Invoice id -> date it became paid in full through receipts / credit notes (the last of them)."""
    ids = [i.id for i in invoices if i.payment_status == "paid"]
    if not ids:
        return {}
    last: dict = {}
    for iid, d in db.execute(select(ReceiptAllocation.invoice_id, func.max(Receipt.receipt_date))
                             .join(Receipt, Receipt.id == ReceiptAllocation.receipt_id)
                             .where(ReceiptAllocation.invoice_id.in_(ids), ReceiptAllocation.is_active.is_(True),
                                    Receipt.status == "posted").group_by(ReceiptAllocation.invoice_id)):
        last[iid] = d
    for iid, d in db.execute(select(CreditNote.invoice_id, func.max(CreditNote.cn_date))
                             .where(CreditNote.invoice_id.in_(ids)).group_by(CreditNote.invoice_id)):
        if d and (last.get(iid) is None or d > last[iid]):
            last[iid] = d
    return last


def _credited_taxable(db: Session, ids: list) -> dict:
    if not ids:
        return {}
    return dict(db.execute(select(CreditNote.invoice_id, func.sum(CreditNote.taxable))
                           .where(CreditNote.invoice_id.in_(ids)).group_by(CreditNote.invoice_id)).all())


def _tender_projects(db: Session, so_ids: list) -> set:
    """Sales orders whose enquiry or lead came from tendering."""
    if not so_ids:
        return set()
    rows = db.execute(select(SalesOrder.id, Enquiry.source, Lead.source)
                      .join(Quotation, Quotation.id == SalesOrder.quotation_id)
                      .join(Enquiry, Enquiry.id == Quotation.enquiry_id)
                      .outerjoin(Lead, Lead.id == Enquiry.lead_id)
                      .where(SalesOrder.id.in_(so_ids))).all()
    return {so for so, es, ls in rows if es == "tender" or ls == "tender"}


def default_settings(db: Session, prj: Project) -> dict:
    cust = db.get(Customer, prj.customer_id)
    tender = bool(prj.sales_order_id and prj.sales_order_id in _tender_projects(db, [prj.sales_order_id]))
    return {"category_code": None, "is_govt": bool(cust and cust.customer_type == "government"), "from_tender": tender,
            "ei_kseb": False, "subsidy_done": False, "subsidy_date": None, "team": {}}


class Data:
    """Everything the engine needs, loaded once per request."""

    def __init__(self, db: Session):
        self.db = db
        self.rules = load_rules(db)
        self.members = load_members(db)
        invoices = db.scalars(select(Invoice).where(Invoice.status == "issued")).all()
        self.invoices = {i.id: i for i in invoices}
        paid = _paid_dates(db, invoices)
        credited = _credited_taxable(db, [i.id for i in invoices])
        follow = {f.invoice_id: f for f in db.scalars(select(IncentiveBillFollowup))}
        self.followups = follow
        prjs = {p.id: p for p in db.scalars(select(Project).where(Project.status.not_in(CLOSED)))}
        by_so = {p.sales_order_id: p.id for p in prjs.values() if p.sales_order_id}
        sets = {s.project_id: s for s in db.scalars(select(ProjectIncentiveSettings))}
        custs = dict(db.execute(select(Customer.id, Customer.customer_name)).all())
        gov_custs = set(db.scalars(select(Customer.id).where(Customer.customer_type == "government")))
        tender_sos = _tender_projects(db, [p.sales_order_id for p in prjs.values() if p.sales_order_id])
        self.projects: dict = {}
        self.bill_info: dict = {}
        for pid, p in prjs.items():
            s = sets.get(pid)
            self.projects[pid] = E.Project(
                id=pid, label=f"{p.project_number} · {p.name}", client=custs.get(p.customer_id, ""),
                category=s.category_code if s else None,
                is_govt=s.is_govt if s else p.customer_id in gov_custs,
                from_tender=s.from_tender if s else (p.sales_order_id in tender_sos),
                ei_kseb=s.ei_kseb if s else False, contract_value=Decimal(p.contract_value or 0),
                subsidy_done=s.subsidy_done if s else False, subsidy_date=s.subsidy_date if s else None,
                team=dict(s.team or {}) if s else {})
        for inv in invoices:
            pid = inv.project_id if inv.project_id in self.projects else by_so.get(inv.sales_order_id)
            if pid is None:     # billing without a project: counted in totals, no category
                pid = f"inv:{inv.id}"
                self.projects[pid] = E.Project(id=None, label=inv.subject or "No project", client=custs.get(inv.customer_id, ""),
                                               category=None, is_govt=inv.customer_id in gov_custs)
            amount = Decimal(inv.taxable) - Decimal(credited.get(inv.id) or 0)
            paid_date = paid.get(inv.id)
            manual = False
            f = follow.get(inv.id)
            if paid_date is None and f is not None and f.state == "paid" and f.confirmed_paid_date:
                paid_date, manual = f.confirmed_paid_date, True
            b = E.Bill(id=inv.id, number=inv.invoice_number or "", bill_date=inv.invoice_date, amount=amount,
                       final=inv.bill_type == "final", paid_date=paid_date)
            self.projects[pid].bills.append(b)
            self.bill_info[inv.id] = {"project_key": pid, "manual": manual}

    @property
    def project_list(self) -> list[E.Project]:
        return list(self.projects.values())

    def live_lines(self, ym: str, accounts_proper: bool) -> list[E.Line]:
        return E.lines_for_month(ym, self.rules, self.project_list, self.members, accounts_proper)


# ============================================================================================ month records
def get_month(db: Session, ym: str, lock: bool = False) -> IncentiveMonth | None:
    stmt = select(IncentiveMonth).where(IncentiveMonth.ym == ym)
    return db.scalar(stmt.with_for_update() if lock else stmt)


def ensure_month(db: Session, p: Principal, ym: str) -> IncentiveMonth:
    m = get_month(db, ym, lock=True)
    if m is None:
        m = IncentiveMonth(ym=ym, created_by=p.id, updated_by=p.id)
        db.add(m)
        db.flush()
    return m


def _line_out(ln) -> dict:
    """Engine line or snapshot row → API dict."""
    if isinstance(ln, IncentiveLine):
        return {"employee_id": str(ln.employee_id), "employee_name": ln.employee_name,
                "role_id": str(ln.role_id) if ln.role_id else None, "role_name": ln.role_name,
                "rule_id": str(ln.rule_id) if ln.rule_id else None, "rule": ln.rule_label, "trigger": ln.trigger,
                "project_id": str(ln.project_id) if ln.project_id else None, "project": ln.project_label,
                "client": ln.client or "", "category": ln.category_code,
                "invoice_id": str(ln.invoice_id) if ln.invoice_id else None, "ref": ln.basis_ref,
                "base": str(Decimal(ln.base).quantize(Decimal("0.01"))), "basis": ln.rate_basis,
                "rate": plain(Decimal(ln.rate_value)), "split": ln.split,
                "amount": str(Decimal(ln.amount).quantize(Decimal("0.01"))),
                "date": ln.event_date.isoformat() if ln.event_date else None}
    return {"employee_id": str(ln.employee_id), "employee_name": ln.employee_name, "role_id": ln.role_id,
            "role_name": ln.role_name, "rule_id": str(ln.rule_id), "rule": ln.rule_label, "trigger": ln.trigger,
            "project_id": str(ln.project_id) if ln.project_id else None, "project": ln.project_label,
            "client": ln.client or "", "category": ln.category, "invoice_id": str(ln.invoice_id) if ln.invoice_id else None,
            "ref": ln.basis_ref, "base": str(ln.base.quantize(Decimal("0.01"))), "basis": ln.rate_basis,
            "rate": plain(ln.rate_value), "split": ln.split, "amount": str(ln.amount.quantize(Decimal("0.01"))),
            "date": ln.event_date.isoformat() if ln.event_date else None}


def month_lines(db: Session, data: Data, ym: str) -> tuple[list[dict], IncentiveMonth | None]:
    m = get_month(db, ym)
    if m is not None and m.status == "locked":
        rows = db.scalars(select(IncentiveLine).where(IncentiveLine.month_id == m.id)
                          .order_by(IncentiveLine.employee_name, IncentiveLine.created_at)).all()
        return [_line_out(r) for r in rows], m
    return [_line_out(ln) for ln in data.live_lines(ym, bool(m and m.accounts_proper))], m


def _sum(lines: list[dict], key: str | None = None) -> dict | Decimal:
    if key is None:
        return sum((Decimal(ln["amount"]) for ln in lines), Z)
    out: dict = defaultdict(lambda: Z)
    for ln in lines:
        out[ln[key]] += Decimal(ln["amount"])
    return dict(out)


def billed_for(db: Session, data: Data, ym: str, m: IncentiveMonth | None, pct: Decimal) -> tuple[Decimal, Decimal]:
    if m is not None and m.status == "locked" and m.billed_amount is not None:
        return Decimal(m.billed_amount), Decimal(m.welfare_amount or 0)
    billed = E.billed_in(ym, data.project_list)[0]
    return billed, E.welfare(billed, pct)


def set_accounts_proper(db: Session, p: Principal, ym: str, value: bool) -> IncentiveMonth:
    m = ensure_month(db, p, ym)
    if m.status == "locked":
        raise Conflict("MONTH_LOCKED", "This month is approved and locked. Unlock it first to change it.")
    m.accounts_proper, m.updated_by = value, p.id
    audit.record(db, action="update", entity_type="incentive_month", entity_id=m.id, entity_label=ym,
                 summary=f"All account statements proper: {'yes' if value else 'no'}")
    return m


def lock(db: Session, p: Principal, ym: str) -> IncentiveMonth:
    m = ensure_month(db, p, ym)
    if m.status == "locked":
        raise Conflict("MONTH_LOCKED", "This month is already approved and locked.")
    data = Data(db)
    lines = data.live_lines(ym, m.accounts_proper)
    pct = welfare_pct(db, p.company_id)
    billed = E.billed_in(ym, data.project_list)[0]
    by = {"created_by": p.id, "updated_by": p.id}
    for ln in lines:
        db.add(IncentiveLine(month_id=m.id, employee_id=uuid.UUID(str(ln.employee_id)), employee_name=ln.employee_name,
                             role_id=uuid.UUID(str(ln.role_id)), role_name=ln.role_name, rule_id=ln.rule_id,
                             rule_label=ln.rule_label, trigger=ln.trigger, project_id=ln.project_id,
                             project_label=ln.project_label, client=ln.client or None, category_code=ln.category,
                             invoice_id=ln.invoice_id, basis_ref=ln.basis_ref, base=ln.base, rate_basis=ln.rate_basis,
                             rate_value=ln.rate_value, split=ln.split, amount=ln.amount, event_date=ln.event_date, **by))
    m.status, m.locked_at, m.locked_by, m.updated_by = "locked", now(), p.id, p.id
    m.welfare_pct, m.billed_amount, m.welfare_amount = pct, billed, E.welfare(billed, pct)
    total = sum((ln.amount for ln in lines), Z)
    audit.record(db, action="approve", entity_type="incentive_month", entity_id=m.id, entity_label=ym,
                 summary=f"Approved & locked {ym}: {len(lines)} lines, ₹{total.quantize(Decimal('0.01'))}")
    return m


def unlock(db: Session, p: Principal, ym: str) -> IncentiveMonth:
    if not p.can("incentive_unlock.approve"):
        raise Forbidden("Only an administrator can unlock an approved month.")
    m = get_month(db, ym, lock=True)
    if m is None or m.status != "locked":
        raise Conflict("NOT_LOCKED", "This month is not locked.")
    paid = db.scalar(select(func.count()).select_from(IncentivePayout).where(IncentivePayout.month_id == m.id))
    if paid:
        raise Conflict("PAID_OUT", "Incentives for this month are already marked paid out. Undo those first.")
    db.execute(delete(IncentiveLine).where(IncentiveLine.month_id == m.id))
    m.status, m.locked_at, m.locked_by, m.updated_by = "draft", None, None, p.id
    m.welfare_pct = m.billed_amount = m.welfare_amount = None
    audit.record(db, action="unlock", entity_type="incentive_month", entity_id=m.id, entity_label=ym,
                 summary=f"Unlocked {ym}: snapshot deleted, recalculating from live data")
    return m


def mark_paid(db: Session, p: Principal, ym: str, employee_id: uuid.UUID, paid_on: date, note: str | None) -> IncentivePayout:
    m = get_month(db, ym, lock=True)
    if m is None or m.status != "locked":
        raise Conflict("NOT_LOCKED", "Approve & lock the month before marking incentives paid.")
    amt = db.scalar(select(func.sum(IncentiveLine.amount)).where(IncentiveLine.month_id == m.id,
                                                                 IncentiveLine.employee_id == employee_id))
    if not amt:
        raise NotFound("incentive_line")
    if db.scalar(select(IncentivePayout.id).where(IncentivePayout.month_id == m.id, IncentivePayout.employee_id == employee_id)):
        raise Conflict("ALREADY_PAID", "Already marked paid out.")
    row = IncentivePayout(month_id=m.id, employee_id=employee_id, paid_on=paid_on,
                          amount=Decimal(amt).quantize(Decimal("0.01")), note=note, created_by=p.id, updated_by=p.id)
    db.add(row)
    db.flush()
    emp = db.get(Employee, employee_id)
    audit.record(db, action="paid", entity_type="incentive_month", entity_id=m.id, entity_label=ym,
                 summary=f"Incentive {ym} paid out to {emp.full_name if emp else employee_id} on {paid_on:%d %b %Y}")
    return row


def undo_paid(db: Session, p: Principal, ym: str, employee_id: uuid.UUID) -> None:
    m = get_month(db, ym)
    row = m and db.scalar(select(IncentivePayout).where(IncentivePayout.month_id == m.id,
                                                       IncentivePayout.employee_id == employee_id))
    if not row:
        raise NotFound("payout")
    db.delete(row)
    audit.record(db, action="update", entity_type="incentive_month", entity_id=m.id, entity_label=ym,
                 summary="Paid-out mark removed")


# ============================================================================================ register / dashboard
def register_view(db: Session, p: Principal, ym: str, employee_id: uuid.UUID | None = None) -> dict:
    data = Data(db)
    lines, m = month_lines(db, data, ym)
    if employee_id is not None:
        lines = [ln for ln in lines if ln["employee_id"] == str(employee_id)]
    pct = Decimal(m.welfare_pct) if m is not None and m.welfare_pct is not None else welfare_pct(db, p.company_id)
    billed, wf = billed_for(db, data, ym, m, pct)
    payouts = {str(x.employee_id): {"paid_on": x.paid_on.isoformat(), "amount": str(x.amount)}
               for x in (db.scalars(select(IncentivePayout).where(IncentivePayout.month_id == m.id)) if m else [])}
    groups: dict = {}
    for ln in lines:
        g = groups.setdefault(ln["employee_id"], {"employee_id": ln["employee_id"], "name": ln["employee_name"],
                                                  "roles": [], "lines": [], "total": Z})
        g["lines"].append(ln)
        g["total"] += Decimal(ln["amount"])
        if ln["role_name"] not in g["roles"]:
            g["roles"].append(ln["role_name"])
    emps = sorted(groups.values(), key=lambda g: -g["total"])
    for g in emps:
        g["total"] = str(g["total"].quantize(Decimal("0.01")))
        g["paid"] = payouts.get(g["employee_id"])
    return {"ym": ym, "status": m.status if m else "draft", "accounts_proper": bool(m and m.accounts_proper),
            "locked_at": m.locked_at.isoformat() if m and m.locked_at else None,
            "has_monthly_rule": any(r.trigger == "monthly" for r in data.rules),
            "total": str(_sum(lines).quantize(Decimal("0.01"))), "employees": emps,
            "billed": str(billed.quantize(Decimal("0.01"))), "welfare": str(wf.quantize(Decimal("0.01"))),
            "welfare_pct": plain(pct),
            "can": {"approve": p.can("incentive.approve"), "unlock": p.can("incentive_unlock.approve"),
                    "accounts": p.can("incentive.approve")}}


def _open_bills(data: Data) -> list[tuple[E.Project, E.Bill]]:
    out = [(p, b) for p in data.project_list for b in p.bills if b.paid_date is None]
    return sorted(out, key=lambda x: x[1].bill_date or date.min)


def _pending_subsidy(data: Data) -> list[E.Project]:
    return [p for p in data.project_list if p.id is not None and p.category == "solar" and not p.subsidy_done]


def _cat_names(db: Session) -> dict:
    return dict(db.execute(select(IncentiveCategory.code, IncentiveCategory.name)).all())


def dashboard(db: Session, p: Principal, ym: str) -> dict:
    data = Data(db)
    lines, m = month_lines(db, data, ym)
    pct = Decimal(m.welfare_pct) if m is not None and m.welfare_pct is not None else welfare_pct(db, p.company_id)
    billed, bcat, bn = E.billed_in(ym, data.project_list)
    collected, ccat, cn = E.collected_in(ym, data.project_list)
    _, wf = billed_for(db, data, ym, m, pct)
    fy_wf = Z
    for x in fy_months(fy_of(ym)):
        if x > ym:
            break
        mx = get_month(db, x)
        fy_wf += billed_for(db, data, x, mx, Decimal(mx.welfare_pct) if mx and mx.welfare_pct is not None else pct)[1]
    open_ = _open_bills(data)
    outstanding = Z
    for _, b in open_:
        inv = data.invoices.get(b.id)
        if inv is None:
            continue
        gst_factor = (Decimal(inv.grand_total) / Decimal(inv.taxable)) if inv.taxable else Decimal(1)
        outstanding += b.amount - (Decimal(inv.received) / gst_factor if gst_factor else Z)
    names = _cat_names(db)
    cats = [{"code": c, "name": names.get(c, c or "Not categorised"), "billed": str(bcat.get(c, Z)),
             "collected": str(ccat.get(c, Z))} for c in list(names) + [None] if c in bcat or c in ccat or c in names]
    per_emp = _sum(lines, "employee_id")
    names_e = {ln["employee_id"]: (ln["employee_name"], ln["role_name"]) for ln in lines}
    roles_of = _roles_of_employees(db)
    for eid, (nm, rl) in [(str(e.employee_id), (e.name, None)) for ms in data.members.values() for e in ms if e.active]:
        names_e.setdefault(eid, (nm, rl))
    emp_rows = sorted(({"employee_id": eid, "name": nm, "roles": roles_of.get(eid, [rl] if rl else []),
                        "amount": str(per_emp.get(eid, Z).quantize(Decimal("0.01")))} for eid, (nm, rl) in names_e.items()),
                      key=lambda r: -Decimal(r["amount"]))
    return {"ym": ym, "billed": str(billed), "billed_count": bn, "collected": str(collected), "collected_count": cn,
            "incentives": str(_sum(lines).quantize(Decimal("0.01"))), "status": m.status if m else "draft",
            "welfare_pct": plain(pct), "welfare": str(wf.quantize(Decimal("0.01"))),
            "welfare_fy": str(fy_wf.quantize(Decimal("0.01"))), "outstanding": str(outstanding.quantize(Decimal("0.01"))),
            "open_bills": len(open_), "pending_subsidy": len(_pending_subsidy(data)), "categories": cats,
            "employees": emp_rows}


def _roles_of_employees(db: Session) -> dict:
    out: dict = defaultdict(list)
    for eid, name in db.execute(select(IncentiveRoleMember.employee_id, IncentiveRole.name)
                                .join(IncentiveRole, IncentiveRole.id == IncentiveRoleMember.role_id)
                                .where(IncentiveRoleMember.is_active.is_(True), IncentiveRole.is_active.is_(True))):
        out[str(eid)].append(name)
    return dict(out)


# ============================================================================================ payment follow-up
def followup_view(db: Session) -> dict:
    data = Data(db)
    names = _cat_names(db)
    t = today()
    rows = []
    for prj, b in _open_bills(data):
        inv = data.invoices[b.id]
        f = data.followups.get(inv.id)
        rows.append({"invoice_id": str(inv.id), "invoice_number": inv.invoice_number, "bill_date": inv.invoice_date.isoformat(),
                     "age_days": (t - inv.invoice_date).days, "project_id": str(prj.id) if prj.id else None,
                     "project": prj.label if prj.id else None, "client": prj.client,
                     "category": names.get(prj.category, prj.category) if prj.category else None,
                     "is_govt": prj.is_govt, "amount": str(b.amount), "total": str(inv.grand_total),
                     "received": str(inv.received + inv.credited), "balance": str(inv.balance),
                     "final": b.final, "customer_id": str(inv.customer_id),
                     "state": f.state if f else "open", "last_checked": f.last_checked.isoformat() if f and f.last_checked else None,
                     "part_amount": str(f.confirmed_amount) if f and f.state == "partial" and f.confirmed_amount is not None else None,
                     "note": f.note if f else None})
    subsidy = [{"project_id": str(x.id), "project": x.label, "client": x.client, "value": str(x.value)}
               for x in _pending_subsidy(data)]
    confirmed = []
    for inv_id, f in data.followups.items():
        inv = data.invoices.get(inv_id)
        if inv is not None and f.state == "paid" and data.bill_info.get(inv_id, {}).get("manual"):
            confirmed.append({"invoice_id": str(inv_id), "invoice_number": inv.invoice_number,
                              "paid_date": f.confirmed_paid_date.isoformat() if f.confirmed_paid_date else None,
                              "amount": str(f.confirmed_amount) if f.confirmed_amount is not None else None})
    return {"bills": rows, "subsidy": subsidy, "manually_confirmed": confirmed}


def _followup(db: Session, p: Principal, invoice_id: uuid.UUID) -> tuple[Invoice, IncentiveBillFollowup]:
    inv = db.get(Invoice, invoice_id)
    if inv is None or inv.status != "issued":
        raise NotFound("issued invoice")
    f = db.scalar(select(IncentiveBillFollowup).where(IncentiveBillFollowup.invoice_id == invoice_id).with_for_update())
    if f is None:
        f = IncentiveBillFollowup(invoice_id=invoice_id, created_by=p.id, updated_by=p.id)
        db.add(f)
    return inv, f


def _month_locked(db: Session, d: date | None) -> bool:
    m = d and get_month(db, E.ym_of(d))
    return bool(m and m.status == "locked")


def confirm_paid(db: Session, p: Principal, invoice_id: uuid.UUID, paid_date: date, amount: Decimal | None,
                 note: str | None) -> None:
    inv, f = _followup(db, p, invoice_id)
    if paid_date > today():
        raise AppError("FUTURE_DATE", "The payment date can't be in the future.")
    if paid_date < inv.invoice_date:
        raise AppError("BEFORE_BILL", "The payment date is before the bill date.")
    if _month_locked(db, paid_date):
        raise Conflict("MONTH_LOCKED", f"{E.ym_of(paid_date)} is approved and locked. Choose a later date or ask an "
                                       "administrator to unlock it.")
    f.state, f.confirmed_paid_date, f.confirmed_amount = "paid", paid_date, amount if amount is not None else inv.grand_total
    f.last_checked, f.note, f.updated_by = paid_date, note, p.id
    db.flush()
    audit.record(db, action="update", entity_type="invoice", entity_id=inv.id, entity_label=inv.invoice_number,
                 summary=f"Confirmed paid in full on {paid_date:%d %b %Y} (incentives)")


def part_paid(db: Session, p: Principal, invoice_id: uuid.UUID, on: date, amount: Decimal, note: str | None) -> None:
    inv, f = _followup(db, p, invoice_id)
    f.state, f.confirmed_paid_date, f.confirmed_amount, f.last_checked, f.note, f.updated_by = \
        "partial", None, amount, on, note, p.id
    db.flush()
    audit.record(db, action="update", entity_type="invoice", entity_id=inv.id, entity_label=inv.invoice_number,
                 summary=f"Part paid ₹{amount} noted on {on:%d %b %Y} (incentives)")


def not_yet(db: Session, p: Principal, invoice_id: uuid.UUID, note: str | None) -> None:
    inv, f = _followup(db, p, invoice_id)
    if f.state == "paid":
        f.state, f.confirmed_paid_date = "open", None
    f.last_checked, f.updated_by = today(), p.id
    if note:
        f.note = note
    db.flush()


def reopen(db: Session, p: Principal, invoice_id: uuid.UUID) -> None:
    inv, f = _followup(db, p, invoice_id)
    if f.state == "paid" and _month_locked(db, f.confirmed_paid_date):
        raise Conflict("MONTH_LOCKED", "The month this payment counts in is approved and locked.")
    f.state, f.confirmed_paid_date, f.confirmed_amount, f.updated_by = "open", None, None, p.id
    db.flush()
    audit.record(db, action="update", entity_type="invoice", entity_id=inv.id, entity_label=inv.invoice_number,
                 summary="Manual paid-in-full confirmation removed (incentives)")


# ============================================================================================ project settings
def project_settings(db: Session, prj: Project) -> dict:
    s = db.scalar(select(ProjectIncentiveSettings).where(ProjectIncentiveSettings.project_id == prj.id))
    d = default_settings(db, prj) if s is None else {
        "category_code": s.category_code, "is_govt": s.is_govt, "from_tender": s.from_tender, "ei_kseb": s.ei_kseb,
        "subsidy_done": s.subsidy_done, "subsidy_date": s.subsidy_date, "team": dict(s.team or {})}
    d["subsidy_date"] = d["subsidy_date"].isoformat() if d["subsidy_date"] else None
    d["saved"] = s is not None
    d["row_version"] = s.row_version if s else None
    roles = []
    rule_roles = {r.role_id for r in load_rules(db) if r.trigger != "monthly"}
    members = load_members(db)
    for r in db.scalars(select(IncentiveRole).where(IncentiveRole.is_active.is_(True)).order_by(IncentiveRole.sort_order)):
        if str(r.id) in rule_roles:
            roles.append({"id": str(r.id), "name": r.name, "choice": d["team"].get(str(r.id), "all"),
                          "employees": [{"id": str(m.employee_id), "name": m.name, "active": m.active,
                                         "eligible_from": m.eligible_from.isoformat() if m.eligible_from else None}
                                        for m in members.get(str(r.id), [])]})
    d["roles"] = roles
    d["categories"] = [{"code": c.code, "name": c.name} for c in db.scalars(
        select(IncentiveCategory).where(IncentiveCategory.is_active.is_(True)).order_by(IncentiveCategory.sort_order))]
    d["contract_value"] = str(prj.contract_value)
    return d


def save_project_settings(db: Session, p: Principal, prj: Project, data) -> None:
    if data.category_code and not db.scalar(select(IncentiveCategory.id).where(IncentiveCategory.code == data.category_code)):
        raise AppError("UNKNOWN_CATEGORY", "Choose a project category from the list.")
    valid_roles = {str(r) for r in db.scalars(select(IncentiveRole.id))}
    team = {}
    for rid, choice in (data.team or {}).items():
        if rid not in valid_roles:
            continue
        if choice not in ("all", "none"):
            try:
                uuid.UUID(choice)
            except ValueError as exc:
                raise AppError("INVALID_TEAM", "Choose a person, 'All in role' or 'Nobody' for each role.") from exc
        team[rid] = choice
    if data.subsidy_done and data.subsidy_date is None:
        data.subsidy_date = today()
    s = db.scalar(select(ProjectIncentiveSettings).where(ProjectIncentiveSettings.project_id == prj.id).with_for_update())
    old_sub = s.subsidy_date if s and s.subsidy_done else None
    new_sub = data.subsidy_date if data.subsidy_done else None
    if old_sub != new_sub and (_month_locked(db, old_sub) or _month_locked(db, new_sub)):
        raise Conflict("MONTH_LOCKED", "The subsidy milestone falls in a month that is approved and locked.")
    if s is None:
        s = ProjectIncentiveSettings(project_id=prj.id, created_by=p.id)
        db.add(s)
    s.category_code, s.is_govt, s.from_tender, s.ei_kseb = data.category_code or None, data.is_govt, data.from_tender, data.ei_kseb
    s.subsidy_done, s.subsidy_date, s.team, s.updated_by = data.subsidy_done, new_sub, team, p.id
    db.flush()
    audit.record(db, action="update", entity_type="project", entity_id=prj.id, entity_label=prj.project_number,
                 summary="Incentive settings updated")


def subsidy_done(db: Session, p: Principal, prj: Project, on: date) -> None:
    if on > today():
        raise AppError("FUTURE_DATE", "The date can't be in the future.")
    if _month_locked(db, on):
        raise Conflict("MONTH_LOCKED", f"{E.ym_of(on)} is approved and locked.")
    s = db.scalar(select(ProjectIncentiveSettings).where(ProjectIncentiveSettings.project_id == prj.id).with_for_update())
    if s is None:
        d = default_settings(db, prj)
        s = ProjectIncentiveSettings(project_id=prj.id, created_by=p.id, category_code=d["category_code"],
                                     is_govt=d["is_govt"], from_tender=d["from_tender"], team={})
        db.add(s)
    s.subsidy_done, s.subsidy_date, s.updated_by = True, on, p.id
    db.flush()
    audit.record(db, action="update", entity_type="project", entity_id=prj.id, entity_label=prj.project_number,
                 summary=f"Solar subsidy received & final documents submitted on {on:%d %b %Y}")


# ============================================================================================ performance
def band(avg: Decimal | None) -> str | None:
    if avg is None:
        return None
    if avg >= Decimal("4.5"):
        return "Outstanding"
    if avg >= Decimal("3.5"):
        return "Strong"
    if avg >= Decimal("2.5"):
        return "Meets expectations"
    return "Needs improvement"


def performance_view(db: Session, ym: str) -> dict:
    data = Data(db)
    lines, _ = month_lines(db, data, ym)
    fy_lines = []
    for x in fy_months(fy_of(ym)):
        if x > ym:
            break
        fy_lines += month_lines(db, data, x)[0] if x != ym else lines
    fy_tot = _sum(fy_lines, "employee_id")
    ratings = {str(r.employee_id): r for r in db.scalars(select(PerformanceRating).where(PerformanceRating.ym == ym))}
    roles_of = _roles_of_employees(db)
    people: dict = {}
    for ms in data.members.values():
        for m in ms:
            if m.active:
                people[str(m.employee_id)] = m.name
    for ln in lines:
        people.setdefault(ln["employee_id"], ln["employee_name"])
    rows = []
    for eid, name in sorted(people.items(), key=lambda x: x[1]):
        mine = [ln for ln in lines if ln["employee_id"] == eid]
        seen, value = set(), Z
        for ln in mine:
            k = (ln["project_id"], ln["ref"])
            if ln["project_id"] and k not in seen and Decimal(ln["base"]):
                seen.add(k)
                value += Decimal(ln["base"])
        r = ratings.get(eid)
        scores = {c: getattr(r, c) if r else None for c in CRITERIA}
        given = [v for v in scores.values() if v]
        avg = (Decimal(sum(given)) / len(CRITERIA)).quantize(Decimal("0.1")) if len(given) == len(CRITERIA) else None
        rows.append({"employee_id": eid, "name": name, "roles": roles_of.get(eid, []),
                     "projects": len({ln["project_id"] for ln in mine if ln["project_id"]}), "value": str(value),
                     "incentive": str(sum((Decimal(ln["amount"]) for ln in mine), Z).quantize(Decimal("0.01"))),
                     "incentive_fy": str(fy_tot.get(eid, Z).quantize(Decimal("0.01"))), "ratings": scores,
                     "remarks": r.remarks if r else None, "average": str(avg) if avg is not None else None,
                     "band": band(avg)})
    return {"ym": ym, "criteria": list(CRITERIA), "employees": rows}


def save_rating(db: Session, p: Principal, ym: str, employee_id: uuid.UUID, data) -> None:
    if db.get(Employee, employee_id) is None:
        raise NotFound("employee")
    r = db.scalar(select(PerformanceRating).where(PerformanceRating.ym == ym, PerformanceRating.employee_id == employee_id)
                  .with_for_update())
    if r is None:
        r = PerformanceRating(ym=ym, employee_id=employee_id, created_by=p.id)
        db.add(r)
    for c in CRITERIA:
        setattr(r, c, getattr(data, c))
    r.remarks, r.updated_by = data.remarks, p.id
    db.flush()


# ============================================================================================ reports
def reports(db: Session, p: Principal, fy: int) -> dict:
    data = Data(db)
    names = _cat_names(db)
    months = fy_months(fy)
    pct_now = welfare_pct(db, p.company_id)
    billing, collections, inc, wf, status = [], [], [], [], []
    for ym in months:
        b, bc, _ = E.billed_in(ym, data.project_list)
        c, cc, _ = E.collected_in(ym, data.project_list)
        lines, m = month_lines(db, data, ym)
        pct = Decimal(m.welfare_pct) if m is not None and m.welfare_pct is not None else pct_now
        billing.append({"total": str(b), "by": {str(k): str(v) for k, v in bc.items()}})
        collections.append({"total": str(c), "by": {str(k): str(v) for k, v in cc.items()}})
        inc.append(str(_sum(lines).quantize(Decimal("0.01"))))
        wf.append(str(billed_for(db, data, ym, m, pct)[1].quantize(Decimal("0.01"))))
        status.append(m.status if m else "draft")
    cats = [{"code": c, "name": n} for c, n in names.items()] + [{"code": "None", "name": "Not categorised"}]
    return {"fy": fy, "label": f"FY {fy}-{str(fy + 1)[2:]}", "months": months, "categories": cats, "billing": billing,
            "collections": collections, "incentives": inc, "welfare": wf, "status": status,
            "welfare_pct": plain(pct_now)}


# ============================================================================================ my statement
def my_statement(db: Session, p: Principal, ym: str) -> dict:
    from app.hr.service import employee_for_user

    emp = employee_for_user(db, p.id)
    if emp is None:
        return {"employee": None}
    data = Data(db)
    lines, m = month_lines(db, data, ym)
    mine = [ln for ln in lines if ln["employee_id"] == str(emp.id)]
    fy = []
    for x in fy_months(fy_of(ym)):
        if x > current_ym():
            break
        ls, mx = (lines, m) if x == ym else month_lines(db, data, x)
        amt = sum((Decimal(ln["amount"]) for ln in ls if ln["employee_id"] == str(emp.id)), Z)
        paid = mx and db.scalar(select(IncentivePayout).where(IncentivePayout.month_id == mx.id,
                                                             IncentivePayout.employee_id == emp.id))
        fy.append({"ym": x, "amount": str(amt.quantize(Decimal("0.01"))), "status": mx.status if mx else "draft",
                   "paid_on": paid.paid_on.isoformat() if paid else None})
    elig = eligible_from(emp.date_of_joining, eligible_after(db, p.company_id))
    return {"employee": {"id": str(emp.id), "name": emp.full_name, "code": emp.employee_code,
                         "eligible_from": elig.isoformat() if elig else None},
            "roles": _roles_of_employees(db).get(str(emp.id), []), "ym": ym, "status": m.status if m else "draft",
            "lines": mine, "total": str(sum((Decimal(ln["amount"]) for ln in mine), Z).quantize(Decimal("0.01"))),
            "fy": fy}


# ============================================================================================ setup
def setup_view(db: Session, p: Principal) -> dict:
    roles = db.scalars(select(IncentiveRole).order_by(IncentiveRole.sort_order, IncentiveRole.name)).all()
    rules = db.scalars(select(IncentiveRule).order_by(IncentiveRule.sort_order, IncentiveRule.created_at)).all()
    members = db.execute(select(IncentiveRoleMember, Employee).join(Employee, Employee.id == IncentiveRoleMember.employee_id)
                         .order_by(Employee.full_name)).all()
    months = eligible_after(db, p.company_id)

    def elig(e: Employee) -> str | None:
        d = eligible_from(e.date_of_joining, months)
        return d.isoformat() if d else None

    return {
        "categories": [{"id": str(c.id), "code": c.code, "name": c.name, "is_active": c.is_active, "sort_order": c.sort_order}
                       for c in db.scalars(select(IncentiveCategory).order_by(IncentiveCategory.sort_order))],
        "roles": [{"id": str(r.id), "code": r.code, "name": r.name, "is_active": r.is_active, "sort_order": r.sort_order,
                   "members": [{"id": str(m.id), "employee_id": str(e.id), "name": e.full_name, "code": e.employee_code,
                                "is_active": m.is_active, "employee_active": e.is_active,
                                "joined": e.date_of_joining.isoformat() if e.date_of_joining else None,
                                "eligible_from": elig(e)}
                               for m, e in members if m.role_id == r.id],
                   "rules": [rule_out(x) for x in rules if x.role_id == r.id]} for r in roles],
        "welfare_pct": plain(welfare_pct(db, p.company_id)),
        "eligible_after_months": months,
        "triggers": {"billPaid": "Each bill paid in full", "finalPaid": "Final bill paid in full (once per project)",
                     "subsidy": "Subsidy received & final docs submitted", "monthly": "Monthly, if all account statements are proper"},
    }


def rule_out(r: IncentiveRule) -> dict:
    return {"id": str(r.id), "role_id": str(r.role_id), "label": r.label, "categories": list(r.categories or ["*"]),
            "govt": r.govt, "tender": r.tender, "requires_ei_kseb": r.requires_ei_kseb, "trigger": r.trigger,
            "basis": r.basis, "value": plain(Decimal(r.value)), "is_active": r.is_active,
            "sort_order": r.sort_order}


def _code_from(name: str, existing: set) -> str:
    base = "".join(ch.lower() if ch.isalnum() else "_" for ch in name).strip("_")[:24] or "x"
    code, n = base, 2
    while code in existing:
        code, n = f"{base[:21]}_{n}", n + 1
    return code


def save_category(db: Session, p: Principal, cat_id: uuid.UUID | None, data) -> IncentiveCategory:
    if cat_id:
        c = db.get(IncentiveCategory, cat_id)
        if c is None:
            raise NotFound("category")
    else:
        existing = set(db.scalars(select(IncentiveCategory.code)))
        code = (data.code or "").strip().lower() or _code_from(data.name, existing)
        if code in existing:
            raise Conflict("DUPLICATE", "A category with this code already exists.")
        c = IncentiveCategory(code=code, created_by=p.id)
        db.add(c)
    c.name, c.is_active, c.updated_by = data.name.strip(), data.is_active, p.id
    if data.sort_order is not None:
        c.sort_order = data.sort_order
    db.flush()
    audit.record(db, action="update", entity_type="incentive_setup", entity_label=c.name, summary="Category saved")
    return c


def save_role(db: Session, p: Principal, role_id: uuid.UUID | None, data) -> IncentiveRole:
    if role_id:
        r = db.get(IncentiveRole, role_id)
        if r is None:
            raise NotFound("role")
    else:
        r = IncentiveRole(code=_code_from(data.name, set(db.scalars(select(IncentiveRole.code)))), created_by=p.id)
        db.add(r)
    r.name, r.is_active, r.updated_by = data.name.strip(), data.is_active, p.id
    if data.sort_order is not None:
        r.sort_order = data.sort_order
    db.flush()
    audit.record(db, action="update", entity_type="incentive_setup", entity_label=r.name, summary="Role saved")
    return r


def save_rule(db: Session, p: Principal, rule_id: uuid.UUID | None, data) -> IncentiveRule:
    if db.get(IncentiveRole, data.role_id) is None:
        raise NotFound("role")
    codes = set(db.scalars(select(IncentiveCategory.code)))
    cats = ["*"] if not data.categories or "*" in data.categories else [c for c in data.categories if c in codes]
    if not cats:
        raise AppError("NO_CATEGORIES", "Choose at least one project category, or All categories.")
    if rule_id:
        r = db.get(IncentiveRule, rule_id)
        if r is None:
            raise NotFound("rule")
        before = rule_out(r)
    else:
        r, before = IncentiveRule(created_by=p.id), None
        db.add(r)
    r.role_id, r.label, r.categories, r.govt, r.tender = data.role_id, data.label.strip(), cats, data.govt, data.tender
    r.requires_ei_kseb, r.trigger, r.basis, r.value, r.is_active = data.requires_ei_kseb, data.trigger, data.basis, data.value, data.is_active
    r.updated_by = p.id
    if data.sort_order is not None:
        r.sort_order = data.sort_order
    db.flush()
    audit.record(db, action="update" if before else "create", entity_type="incentive_rule", entity_id=r.id,
                 entity_label=r.label, before=before, after=rule_out(r))
    return r


def delete_rule(db: Session, p: Principal, rule_id: uuid.UUID) -> None:
    r = db.get(IncentiveRule, rule_id)
    if r is None:
        raise NotFound("rule")
    audit.record(db, action="delete", entity_type="incentive_rule", entity_id=r.id, entity_label=r.label, before=rule_out(r))
    db.delete(r)     # locked months keep their snapshot (rule_id becomes empty there)
    db.flush()


def save_member(db: Session, p: Principal, role_id: uuid.UUID, employee_id: uuid.UUID, active: bool) -> None:
    if db.get(IncentiveRole, role_id) is None or db.get(Employee, employee_id) is None:
        raise NotFound("role or employee")
    m = db.scalar(select(IncentiveRoleMember).where(IncentiveRoleMember.role_id == role_id,
                                                    IncentiveRoleMember.employee_id == employee_id))
    if m is None:
        m = IncentiveRoleMember(role_id=role_id, employee_id=employee_id, created_by=p.id)
        db.add(m)
    m.is_active, m.updated_by = active, p.id
    db.flush()
    audit.record(db, action="update", entity_type="incentive_setup", entity_label=str(employee_id),
                 summary=f"Role membership {'active' if active else 'inactive'}")


def remove_member(db: Session, p: Principal, member_id: uuid.UUID) -> None:
    m = db.get(IncentiveRoleMember, member_id)
    if m is None:
        raise NotFound("member")
    db.delete(m)
    db.flush()


def set_eligible_after(db: Session, p: Principal, months: int) -> None:
    settings.set_setting(db, p.company_id, "incentive.eligible_after_months", months, p.id)


def set_welfare(db: Session, p: Principal, pct: Decimal) -> None:
    settings.set_setting(db, p.company_id, "incentive.welfare_pct", plain(pct), p.id)


def seed_standard(db: Session, user_id, restore: bool = False) -> None:
    """Create the standard categories, roles and rules. With restore=True the standard roles' rules are replaced by the
    standard rates (custom roles, custom categories and employee assignments are kept)."""
    by = {"created_by": user_id, "updated_by": user_id}
    cats = {c.code: c for c in db.scalars(select(IncentiveCategory))}
    for i, (code, name) in enumerate(defaults.CATEGORIES):
        if code not in cats:
            db.add(IncentiveCategory(code=code, name=name, sort_order=(i + 1) * 10, **by))
        elif restore:
            cats[code].name, cats[code].is_active = name, True
    roles = {r.code: r for r in db.scalars(select(IncentiveRole))}
    for i, (code, name) in enumerate(defaults.ROLES):
        if code not in roles:
            roles[code] = IncentiveRole(code=code, name=name, sort_order=(i + 1) * 10, **by)
            db.add(roles[code])
        elif restore:
            roles[code].name, roles[code].is_active = name, True
    db.flush()
    std_role_ids = [roles[c].id for c, _ in defaults.ROLES]
    have_rules = db.scalar(select(IncentiveRule.id).limit(1)) is not None
    if have_rules and not restore:
        return
    if restore:
        db.execute(delete(IncentiveRule).where(IncentiveRule.role_id.in_(std_role_ids)))
    for i, r in enumerate(defaults.RULES):
        db.add(IncentiveRule(role_id=roles[r["role"]].id, label=r["label"], categories=r["categories"], govt=r["govt"],
                             tender=r["tender"], requires_ei_kseb=r["requires_ei_kseb"], trigger=r["trigger"],
                             basis=r["basis"], value=r["value"], sort_order=(i + 1) * 10, **by))
    db.flush()


def restore_standard(db: Session, p: Principal) -> None:
    seed_standard(db, p.id, restore=True)
    set_welfare(db, p, defaults.WELFARE_PCT)
    set_eligible_after(db, p, defaults.ELIGIBLE_AFTER_MONTHS)
    audit.record(db, action="update", entity_type="incentive_setup", entity_label="Standard rates",
                 summary="Standard roles, categories and rates restored")


def lines_rows_for_export(db: Session, ym: str) -> list[dict]:
    data = Data(db)
    lines, _ = month_lines(db, data, ym)
    names = _cat_names(db)
    return [{"ym": ym, "employee": ln["employee_name"], "role": ln["role_name"], "project": ln["project"],
             "client": ln["client"], "category": names.get(ln["category"], ln["category"] or ""), "basis": ln["ref"],
             "scheme": ln["rule"], "base": Decimal(ln["base"]),
             "rate": (f"{ln['rate']}%" if ln["basis"] == "pct" else f"₹{ln['rate']} fixed"), "split": ln["split"],
             "amount": Decimal(ln["amount"]), "date": ln["date"]} for ln in lines]


def stamp() -> str:
    return datetime.now().strftime("%Y%m%d")
