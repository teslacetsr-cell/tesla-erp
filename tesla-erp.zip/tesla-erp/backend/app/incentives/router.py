"""Incentive & performance API (menu: Incentives)."""
import csv
import io
import uuid
from datetime import date
from decimal import Decimal
from html import escape
from typing import Annotated, Literal

from fastapi import APIRouter, Query
from fastapi.responses import Response
from pydantic import Field

from app.auth.deps import CurrentUser, Principal, require
from app.core import excel
from app.core.api import Schema, ok
from app.core.db import DbSession
from app.core.errors import Forbidden, NotFound
from app.incentives import service as svc
from app.platform.audit import service as audit
from app.projects.models import Project

router = APIRouter(tags=["incentives"])
YM = Annotated[str, Query(pattern=r"^\d{4}-\d{2}$")]


def _ym(ym: str | None) -> str:
    return svc.check_ym(ym) if ym else svc.current_ym()


# ------------------------------------------------------------------ schemas
class AccountsIn(Schema):
    accounts_proper: bool


class PaidIn(Schema):
    employee_id: uuid.UUID
    paid_on: date | None = None
    note: str | None = Field(None, max_length=500)


class ConfirmIn(Schema):
    paid_date: date
    amount: Decimal | None = Field(None, ge=0, max_digits=16, decimal_places=2)
    note: str | None = Field(None, max_length=500)


class PartIn(Schema):
    on: date | None = None
    amount: Decimal = Field(ge=0, max_digits=16, decimal_places=2)
    note: str | None = Field(None, max_length=500)


class NoteIn(Schema):
    note: str | None = Field(None, max_length=500)


class SubsidyIn(Schema):
    on: date | None = None


class ProjectSettingsIn(Schema):
    category_code: str | None = Field(None, max_length=30)
    is_govt: bool = False
    from_tender: bool = False
    ei_kseb: bool = False
    subsidy_done: bool = False
    subsidy_date: date | None = None
    team: dict[str, str] = Field(default_factory=dict)


Score = Annotated[int | None, Field(None, ge=1, le=5)]


class RatingIn(Schema):
    quality: Score = None
    timeliness: Score = None
    follow_up: Score = None
    teamwork: Score = None
    learning: Score = None
    remarks: str | None = Field(None, max_length=500)


class CategoryIn(Schema):
    name: str = Field(min_length=2, max_length=120)
    code: str | None = Field(None, max_length=30, pattern=r"^[a-z0-9_]*$")
    is_active: bool = True
    sort_order: int | None = Field(None, ge=0, le=10000)


class RoleIn(Schema):
    name: str = Field(min_length=2, max_length=160)
    is_active: bool = True
    sort_order: int | None = Field(None, ge=0, le=10000)


class RuleIn(Schema):
    role_id: uuid.UUID
    label: str = Field(min_length=2, max_length=200)
    categories: list[str] = Field(default_factory=lambda: ["*"], max_length=50)
    govt: Literal["any", "yes", "no"] = "any"
    tender: Literal["any", "yes", "no"] = "any"
    requires_ei_kseb: bool = False
    trigger: Literal["billPaid", "finalPaid", "subsidy", "monthly"]
    basis: Literal["pct", "fixed"]
    value: Decimal = Field(ge=0, le=Decimal("10000000"), max_digits=14, decimal_places=4)
    is_active: bool = True
    sort_order: int | None = Field(None, ge=0, le=10000)


class MemberIn(Schema):
    employee_id: uuid.UUID
    is_active: bool = True


class EligibilityIn(Schema):
    months: int = Field(ge=0, le=36)


class WelfareIn(Schema):
    welfare_pct: Decimal = Field(ge=0, le=100, max_digits=7, decimal_places=4)


# ------------------------------------------------------------------ dashboard / register
@router.get("/incentives/dashboard")
def dashboard(db: DbSession, p: Annotated[Principal, require("incentive.read")], ym: YM | None = None):
    return ok(svc.dashboard(db, p, _ym(ym)))


@router.get("/incentives/register")
def register(db: DbSession, p: Annotated[Principal, require("incentive.read")], ym: YM | None = None):
    return ok(svc.register_view(db, p, _ym(ym)))


@router.put("/incentives/months/{ym}/accounts")
def accounts(ym: str, body: AccountsIn, db: DbSession, p: Annotated[Principal, require("incentive.approve")]):
    svc.set_accounts_proper(db, p, svc.check_ym(ym), body.accounts_proper)
    return ok(svc.register_view(db, p, svc.check_ym(ym)))


@router.post("/incentives/months/{ym}/lock")
def lock(ym: str, db: DbSession, p: Annotated[Principal, require("incentive.approve")]):
    svc.lock(db, p, svc.check_ym(ym))
    return ok(svc.register_view(db, p, svc.check_ym(ym)))


@router.post("/incentives/months/{ym}/unlock")
def unlock(ym: str, db: DbSession, p: Annotated[Principal, require("incentive.approve")]):
    svc.unlock(db, p, svc.check_ym(ym))
    return ok(svc.register_view(db, p, svc.check_ym(ym)))


@router.post("/incentives/months/{ym}/paid")
def mark_paid(ym: str, body: PaidIn, db: DbSession, p: Annotated[Principal, require("incentive.approve")]):
    from app.crm.service import today

    svc.mark_paid(db, p, svc.check_ym(ym), body.employee_id, body.paid_on or today(), body.note)
    return ok(svc.register_view(db, p, svc.check_ym(ym)))


@router.delete("/incentives/months/{ym}/paid/{employee_id}")
def undo_paid(ym: str, employee_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("incentive.approve")]):
    svc.undo_paid(db, p, svc.check_ym(ym), employee_id)
    return ok(svc.register_view(db, p, svc.check_ym(ym)))


EXPORT_COLUMNS = [
    excel.Column("ym", "Month", 10), excel.Column("employee", "Employee", 24), excel.Column("role", "Role", 30),
    excel.Column("project", "Project", 36), excel.Column("client", "Client", 26), excel.Column("category", "Category", 22),
    excel.Column("basis", "Basis", 22), excel.Column("scheme", "Scheme", 34), excel.Column("base", "Base (before GST)", 16),
    excel.Column("rate", "Rate", 12), excel.Column("split", "Split", 8), excel.Column("amount", "Amount", 14),
    excel.Column("date", "Date", 12),
]


@router.get("/incentives/register/export")
def export(db: DbSession, p: Annotated[Principal, require("incentive.export")], ym: YM | None = None,
           fmt: Literal["xlsx", "csv"] = "xlsx"):
    ym = _ym(ym)
    rows = svc.lines_rows_for_export(db, ym)
    audit.record(db, action="export", entity_type="incentive_month", entity_label=ym, summary=f"Exported {len(rows)} lines")
    if fmt == "csv":
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow([c.header for c in EXPORT_COLUMNS])
        for r in rows:
            w.writerow([r[c.key] if r[c.key] is not None else "" for c in EXPORT_COLUMNS])
        return Response(("﻿" + buf.getvalue()).encode(), media_type="text/csv",
                        headers={"Content-Disposition": f'attachment; filename="incentives-{ym}.csv"'})
    return Response(excel.export(f"Incentives {ym}", EXPORT_COLUMNS, rows), media_type=excel.XLSX,
                    headers={"Content-Disposition": f'attachment; filename="incentives-{ym}.xlsx"'})


def _statement_pdf(db, view: dict, emp_name: str, emp_code: str | None, ym: str, status: str) -> bytes:
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    from app.platform import pdfkit as K

    K.fonts()
    st = K.styles()
    y, m = (int(x) for x in ym.split("-"))
    label = date(y, m, 1).strftime("%B %Y")
    story = K.letterhead(db, st) + [
        Paragraph("INCENTIVE STATEMENT", st["title"]), Spacer(1, 2 * mm),
        Paragraph(f"<b>Employee</b> {escape(emp_name)}{f' ({escape(emp_code)})' if emp_code else ''} · <b>Month</b> {label}"
                  f" · <b>Status</b> {'Approved' if status == 'locked' else 'Draft — may still change'}", st["base"]),
        Spacer(1, 3 * mm)]
    rows = [[Paragraph(f"<b>{h}</b>", st["cellr"] if i >= 3 else st["cell"]) for i, h in
             enumerate(["Project", "Basis", "Scheme", "Base (₹)", "Rate", "Amount (₹)"])]]
    total = Decimal(0)
    for ln in view["lines"]:
        total += Decimal(ln["amount"])
        rate = f"{ln['rate']}%" if ln["basis"] == "pct" else f"₹{ln['rate']}"
        rows.append([Paragraph(f"{escape(ln['project'])}<br/><font size=6.8 color='#6b7280'>{escape(ln['client'])}</font>", st["cell"]),
                     Paragraph(escape(ln["ref"]), st["cell"]),
                     Paragraph(escape(ln["rule"]) + (f" (÷{ln['split']})" if ln["split"] > 1 else ""), st["cell"]),
                     Paragraph(K.money(Decimal(ln["base"])) if Decimal(ln["base"]) else "—", st["cellr"]),
                     Paragraph(rate, st["cellr"]), Paragraph(K.money(Decimal(ln["amount"])), st["cellr"])])
    rows.append(["", "", Paragraph("<b>Total</b>", st["cell"]), "", "", Paragraph(f"<b>{K.money(total)}</b>", st["cellr"])])
    t = Table(rows, colWidths=[52 * mm, 30 * mm, 44 * mm, 24 * mm, 16 * mm, 24 * mm], repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), K.TINT), ("LINEBELOW", (0, 0), (-1, -1), 0.3, K.LINE),
                           ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story += [t, Spacer(1, 4 * mm),
              Paragraph("Amounts are calculated on bill values before GST, on bills paid in full and milestones reached "
                        "in the month.", st["small"])]
    sign = Table([[Paragraph("Prepared by", st["small"]), Paragraph("Approved by", st["small"]),
                   Paragraph("Received by", st["small"])]], colWidths=[60 * mm] * 3)
    sign.setStyle(TableStyle([("TOPPADDING", (0, 0), (-1, -1), 16 * mm)]))
    story.append(sign)
    buf = io.BytesIO()
    name = f"Incentive {ym} {emp_name}"
    SimpleDocTemplate(buf, pagesize=K.PAGE, leftMargin=K.MARGIN, rightMargin=K.MARGIN, topMargin=10 * mm,
                      bottomMargin=14 * mm, title=name).build(
        story, canvasmaker=K.numbered_canvas(name, None if status == "locked" else "DRAFT"))
    return buf.getvalue()


@router.get("/incentives/statement/{employee_id}.pdf")
def statement_pdf(employee_id: uuid.UUID, db: DbSession, p: CurrentUser, ym: YM | None = None):
    from app.hr.models import Employee
    from app.hr.service import employee_for_user

    ym = _ym(ym)
    emp = db.get(Employee, employee_id)
    if emp is None:
        raise NotFound("employee")
    me = employee_for_user(db, p.id)
    if not p.can("incentive.read") and not (me and me.id == emp.id):
        raise Forbidden("You can see only your own incentive statement.")
    view = svc.register_view(db, p, ym, employee_id)
    lines = [ln for g in view["employees"] for ln in g["lines"]]
    pdf = _statement_pdf(db, {"lines": lines}, emp.full_name, emp.employee_code, ym, view["status"])
    return Response(pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="incentive-{ym}-{emp.employee_code or emp.id}.pdf"'})


@router.get("/incentives/me")
def my_statement(db: DbSession, p: CurrentUser, ym: YM | None = None):
    return ok(svc.my_statement(db, p, _ym(ym)))


# ------------------------------------------------------------------ payment follow-up
@router.get("/incentives/followup")
def followup(db: DbSession, p: Annotated[Principal, require("incentive_followup.update")]):
    return ok(svc.followup_view(db))


@router.post("/incentives/followup/{invoice_id}/paid")
def followup_paid(invoice_id: uuid.UUID, body: ConfirmIn, db: DbSession,
                  p: Annotated[Principal, require("incentive_followup.update")]):
    svc.confirm_paid(db, p, invoice_id, body.paid_date, body.amount, body.note)
    return ok(svc.followup_view(db))


@router.post("/incentives/followup/{invoice_id}/part")
def followup_part(invoice_id: uuid.UUID, body: PartIn, db: DbSession,
                  p: Annotated[Principal, require("incentive_followup.update")]):
    from app.crm.service import today

    svc.part_paid(db, p, invoice_id, body.on or today(), body.amount, body.note)
    return ok(svc.followup_view(db))


@router.post("/incentives/followup/{invoice_id}/not-yet")
def followup_not_yet(invoice_id: uuid.UUID, body: NoteIn, db: DbSession,
                     p: Annotated[Principal, require("incentive_followup.update")]):
    svc.not_yet(db, p, invoice_id, body.note)
    return ok(svc.followup_view(db))


@router.post("/incentives/followup/{invoice_id}/reopen")
def followup_reopen(invoice_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("incentive_followup.update")]):
    svc.reopen(db, p, invoice_id)
    return ok(svc.followup_view(db))


def _project(db, pid: uuid.UUID) -> Project:
    prj = db.get(Project, pid)
    if prj is None:
        raise NotFound("project")
    return prj


@router.post("/incentives/projects/{project_id}/subsidy")
def subsidy(project_id: uuid.UUID, body: SubsidyIn, db: DbSession,
            p: Annotated[Principal, require("incentive_followup.update")]):
    from app.crm.service import today

    svc.subsidy_done(db, p, _project(db, project_id), body.on or today())
    return ok(svc.followup_view(db))


# ------------------------------------------------------------------ project incentive settings
@router.get("/projects/{project_id}/incentive")
def get_project_settings(project_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("project.read")]):
    from app.projects import service as projects

    prj = _project(db, project_id)
    projects.check(p, prj, "read")
    out = svc.project_settings(db, prj)
    out["can_edit"] = p.can("incentive.update")
    return ok(out)


@router.put("/projects/{project_id}/incentive")
def put_project_settings(project_id: uuid.UUID, body: ProjectSettingsIn, db: DbSession,
                         p: Annotated[Principal, require("incentive.update")]):
    prj = _project(db, project_id)
    svc.save_project_settings(db, p, prj, body)
    out = svc.project_settings(db, prj)
    out["can_edit"] = True
    return ok(out)


# ------------------------------------------------------------------ performance
@router.get("/incentives/performance")
def performance(db: DbSession, p: Annotated[Principal, require("performance.read")], ym: YM | None = None):
    out = svc.performance_view(db, _ym(ym))
    out["can_rate"] = p.can("performance.update")
    return ok(out)


@router.put("/incentives/performance/{ym}/{employee_id}")
def rate(ym: str, employee_id: uuid.UUID, body: RatingIn, db: DbSession,
         p: Annotated[Principal, require("performance.update")]):
    svc.save_rating(db, p, svc.check_ym(ym), employee_id, body)
    out = svc.performance_view(db, svc.check_ym(ym))
    out["can_rate"] = True
    return ok(out)


# ------------------------------------------------------------------ reports
@router.get("/incentives/reports")
def reports(db: DbSession, p: Annotated[Principal, require("incentive.read")], fy: int | None = Query(None, ge=2000, le=2100)):
    return ok(svc.reports(db, p, fy if fy is not None else svc.fy_of(svc.current_ym())))


# ------------------------------------------------------------------ setup
@router.get("/incentives/setup")
def setup(db: DbSession, p: Annotated[Principal, require("incentive.read")]):
    out = svc.setup_view(db, p)
    out["can_edit"] = p.can("incentive.update")
    return ok(out)


def _setup(db, p):
    out = svc.setup_view(db, p)
    out["can_edit"] = True
    return ok(out)


@router.post("/incentives/categories")
def add_category(body: CategoryIn, db: DbSession, p: Annotated[Principal, require("incentive.update")]):
    svc.save_category(db, p, None, body)
    return _setup(db, p)


@router.put("/incentives/categories/{cid}")
def edit_category(cid: uuid.UUID, body: CategoryIn, db: DbSession, p: Annotated[Principal, require("incentive.update")]):
    svc.save_category(db, p, cid, body)
    return _setup(db, p)


@router.post("/incentives/roles")
def add_role(body: RoleIn, db: DbSession, p: Annotated[Principal, require("incentive.update")]):
    svc.save_role(db, p, None, body)
    return _setup(db, p)


@router.put("/incentives/roles/{rid}")
def edit_role(rid: uuid.UUID, body: RoleIn, db: DbSession, p: Annotated[Principal, require("incentive.update")]):
    svc.save_role(db, p, rid, body)
    return _setup(db, p)


@router.post("/incentives/roles/{rid}/members")
def add_member(rid: uuid.UUID, body: MemberIn, db: DbSession, p: Annotated[Principal, require("incentive.update")]):
    svc.save_member(db, p, rid, body.employee_id, body.is_active)
    return _setup(db, p)


@router.delete("/incentives/members/{mid}")
def remove_member(mid: uuid.UUID, db: DbSession, p: Annotated[Principal, require("incentive.update")]):
    svc.remove_member(db, p, mid)
    return _setup(db, p)


@router.post("/incentives/rules")
def add_rule(body: RuleIn, db: DbSession, p: Annotated[Principal, require("incentive.update")]):
    svc.save_rule(db, p, None, body)
    return _setup(db, p)


@router.put("/incentives/rules/{rule_id}")
def edit_rule(rule_id: uuid.UUID, body: RuleIn, db: DbSession, p: Annotated[Principal, require("incentive.update")]):
    svc.save_rule(db, p, rule_id, body)
    return _setup(db, p)


@router.delete("/incentives/rules/{rule_id}")
def delete_rule(rule_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("incentive.update")]):
    svc.delete_rule(db, p, rule_id)
    return _setup(db, p)


@router.put("/incentives/welfare")
def welfare(body: WelfareIn, db: DbSession, p: Annotated[Principal, require("incentive.update")]):
    svc.set_welfare(db, p, body.welfare_pct)
    return _setup(db, p)


@router.put("/incentives/eligibility")
def eligibility(body: EligibilityIn, db: DbSession, p: Annotated[Principal, require("incentive.update")]):
    svc.set_eligible_after(db, p, body.months)
    return _setup(db, p)


@router.post("/incentives/restore-standard")
def restore(db: DbSession, p: Annotated[Principal, require("incentive.update")]):
    svc.restore_standard(db, p)
    return _setup(db, p)
