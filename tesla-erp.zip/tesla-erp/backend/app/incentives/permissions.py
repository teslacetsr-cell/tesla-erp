from app.core.permissions import register

register("incentive", "Employee incentives: dashboard, register, reports (update = scheme setup and project incentive "
         "settings; approve = approve & lock a month and mark incentives paid out)",
         ("read", "update", "approve", "export"))
register("incentive_unlock", "Unlock an approved incentive month (deletes its snapshot and recalculates)", ("approve",))
register("incentive_followup", "Payment follow-up for incentives: confirm bills paid in full, part paid, not yet",
         ("update",))
register("performance", "Employee performance: view and enter monthly ratings", ("read", "update"))
