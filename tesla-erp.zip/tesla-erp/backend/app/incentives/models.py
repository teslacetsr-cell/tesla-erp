"""Employee incentive & performance (Tesla Consulting Engineers incentive policy).

Reuses employees, customers, projects, invoices, receipts and credit notes — none of them is copied. New tables hold
only what did not exist:

* ``incentive_categories`` — project categories (solar, solar documentation only, …); admins add more.
* ``incentive_roles`` / ``incentive_role_members`` — incentive roles and which ERP employees hold them.
* ``incentive_rules`` — the scheme: who earns what, on which projects, when (editable; no code change needed).
* ``project_incentive_settings`` — per project: category, Govt, from tender, EI & KSEB docs, subsidy milestone and the
  team per role ("all" = split among everyone active in the role, "none", or one employee id).
* ``incentive_bill_followups`` — payment follow-up per invoice: last checked, a manual "confirmed paid in full" (date and
  amount) for bills whose money is not (yet) entered as receipts, and part-payment notes.
* ``incentive_months`` — one row per month: accounts-statements-proper tick, draft / locked, who locked it.
* ``incentive_lines`` — the snapshot saved when a month is approved & locked (locked months never change).
* ``incentive_payouts`` — "paid out" per employee per locked month.
* ``performance_ratings`` — manager ratings (1–5 on five criteria) per employee per month; never reduce incentives.
"""
import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Integer, Numeric, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.models import AuditColumnsMixin, Base
from app.core.money import AMOUNT

TRIGGERS = ("billPaid", "finalPaid", "subsidy", "monthly")
BASES = ("pct", "fixed")
TRISTATE = ("any", "yes", "no")
MONTH_STATUSES = ("draft", "locked")
FOLLOWUP_STATES = ("open", "partial", "paid")
CRITERIA = ("quality", "timeliness", "follow_up", "teamwork", "learning")


def _in(col: str, values: tuple[str, ...]) -> str:
    return f"{col} in ({', '.join(repr(v) for v in values)})"


class IncentiveCategory(AuditColumnsMixin, Base):
    __tablename__ = "incentive_categories"

    code: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=100, server_default="100")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class IncentiveRole(AuditColumnsMixin, Base):
    __tablename__ = "incentive_roles"

    code: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=100, server_default="100")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class IncentiveRoleMember(AuditColumnsMixin, Base):
    __tablename__ = "incentive_role_members"
    __table_args__ = (UniqueConstraint("role_id", "employee_id", name="uq_incentive_role_members_role_emp"),)

    role_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("incentive_roles.id", ondelete="CASCADE"), nullable=False)
    employee_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("employees.id", ondelete="RESTRICT"), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class IncentiveRule(AuditColumnsMixin, Base):
    __tablename__ = "incentive_rules"
    __table_args__ = (
        CheckConstraint(_in("trigger", TRIGGERS), name="trigger_valid"),
        CheckConstraint(_in("basis", BASES), name="basis_valid"),
        CheckConstraint(_in("govt", TRISTATE), name="govt_valid"),
        CheckConstraint(_in("tender", TRISTATE), name="tender_valid"),
        CheckConstraint("value >= 0", name="value_nonneg"),
    )

    role_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("incentive_roles.id", ondelete="CASCADE"), nullable=False)
    label: Mapped[str] = mapped_column(String(200), nullable=False)
    categories: Mapped[list] = mapped_column(JSONB, nullable=False, default=lambda: ["*"])  # category codes, or ["*"]
    govt: Mapped[str] = mapped_column(String(3), nullable=False, default="any", server_default="any")
    tender: Mapped[str] = mapped_column(String(3), nullable=False, default="any", server_default="any")
    requires_ei_kseb: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    trigger: Mapped[str] = mapped_column(String(10), nullable=False)
    basis: Mapped[str] = mapped_column(String(5), nullable=False)
    value: Mapped[Decimal] = mapped_column(Numeric(14, 4), nullable=False)   # % or ₹
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=100, server_default="100")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class ProjectIncentiveSettings(AuditColumnsMixin, Base):
    __tablename__ = "project_incentive_settings"

    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), unique=True, nullable=False)
    category_code: Mapped[str | None] = mapped_column(String(30))
    is_govt: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    from_tender: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    ei_kseb: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    subsidy_done: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    subsidy_date: Mapped[date | None] = mapped_column(Date)
    team: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)   # role id -> "all" | "none" | employee id


class IncentiveBillFollowup(AuditColumnsMixin, Base):
    __tablename__ = "incentive_bill_followups"
    __table_args__ = (CheckConstraint(_in("state", FOLLOWUP_STATES), name="state_valid"),)

    invoice_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("invoices.id", ondelete="CASCADE"), unique=True, nullable=False)
    state: Mapped[str] = mapped_column(String(8), nullable=False, default="open", server_default="open")
    confirmed_paid_date: Mapped[date | None] = mapped_column(Date)       # manual "paid in full"
    confirmed_amount: Mapped[Decimal | None] = mapped_column(AMOUNT)     # received incl. GST, as told
    last_checked: Mapped[date | None] = mapped_column(Date)
    note: Mapped[str | None] = mapped_column(String(500))


class IncentiveMonth(AuditColumnsMixin, Base):
    __tablename__ = "incentive_months"
    __table_args__ = (CheckConstraint(_in("status", MONTH_STATUSES), name="status_valid"),
                      CheckConstraint("ym ~ '^[0-9]{4}-(0[1-9]|1[0-2])$'", name="ym_valid"))

    ym: Mapped[str] = mapped_column(String(7), unique=True, nullable=False)     # "2026-11"
    accounts_proper: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    status: Mapped[str] = mapped_column(String(6), nullable=False, default="draft", server_default="draft")
    locked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    locked_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    welfare_pct: Mapped[Decimal | None] = mapped_column(Numeric(7, 4))          # frozen at lock
    welfare_amount: Mapped[Decimal | None] = mapped_column(AMOUNT)
    billed_amount: Mapped[Decimal | None] = mapped_column(AMOUNT)


class IncentiveLine(AuditColumnsMixin, Base):
    """Snapshot line of a locked month."""
    __tablename__ = "incentive_lines"

    month_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("incentive_months.id", ondelete="CASCADE"), nullable=False,
                                                index=True)
    employee_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("employees.id", ondelete="RESTRICT"), nullable=False)
    employee_name: Mapped[str] = mapped_column(String(160), nullable=False)
    role_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("incentive_roles.id", ondelete="SET NULL"))
    role_name: Mapped[str] = mapped_column(String(160), nullable=False)
    rule_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("incentive_rules.id", ondelete="SET NULL"))
    rule_label: Mapped[str] = mapped_column(String(200), nullable=False)
    trigger: Mapped[str] = mapped_column(String(10), nullable=False)
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="SET NULL"))
    project_label: Mapped[str] = mapped_column(String(300), nullable=False)
    client: Mapped[str | None] = mapped_column(String(200))
    category_code: Mapped[str | None] = mapped_column(String(30))
    invoice_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("invoices.id", ondelete="SET NULL"))
    basis_ref: Mapped[str] = mapped_column(String(120), nullable=False)       # "Bill TCE/2627/0003", "Subsidy & docs"
    base: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False)
    rate_basis: Mapped[str] = mapped_column(String(5), nullable=False)
    rate_value: Mapped[Decimal] = mapped_column(Numeric(14, 4), nullable=False)
    split: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 4), nullable=False)
    event_date: Mapped[date | None] = mapped_column(Date)


class IncentivePayout(AuditColumnsMixin, Base):
    __tablename__ = "incentive_payouts"
    __table_args__ = (UniqueConstraint("month_id", "employee_id", name="uq_incentive_payouts_month_emp"),)

    month_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("incentive_months.id", ondelete="CASCADE"), nullable=False)
    employee_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("employees.id", ondelete="RESTRICT"), nullable=False)
    paid_on: Mapped[date] = mapped_column(Date, nullable=False)
    amount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False)
    note: Mapped[str | None] = mapped_column(Text)


class PerformanceRating(AuditColumnsMixin, Base):
    __tablename__ = "performance_ratings"
    __table_args__ = (UniqueConstraint("ym", "employee_id", name="uq_performance_ratings_ym_emp"),
                      *[CheckConstraint(f"{c} is null or {c} between 1 and 5", name=f"{c}_range") for c in CRITERIA])

    ym: Mapped[str] = mapped_column(String(7), nullable=False)
    employee_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("employees.id", ondelete="RESTRICT"), nullable=False)
    quality: Mapped[int | None] = mapped_column(Integer)
    timeliness: Mapped[int | None] = mapped_column(Integer)
    follow_up: Mapped[int | None] = mapped_column(Integer)
    teamwork: Mapped[int | None] = mapped_column(Integer)
    learning: Mapped[int | None] = mapped_column(Integer)
    remarks: Mapped[str | None] = mapped_column(String(500))
