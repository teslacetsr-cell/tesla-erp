"""The incentive calculation, as pure functions over plain data (no database), so it can be tested exactly.

Rules (Tesla Consulting Engineers incentive policy; all amounts BEFORE GST):

* billPaid  — each bill paid in full: pct × the bill's amount before GST, or a fixed amount per bill.
* finalPaid — the bill marked final is paid in full: a fixed amount once per project (pct uses the contract value).
* subsidy   — solar subsidy received and final documents submitted: pct × contract value (the sum of the project's
              bills when the contract value is 0).
* monthly   — once a month, only when "all account statements proper" is ticked: pct × the month's collections from
              bills paid in full (on projects the rule applies to).

Who receives it: the employee(s) assigned to the role on the project — one person, nobody, or "all in role" (default),
which splits equally among the role's active employees. Monthly rules always split among all active employees in the
role. The month an amount counts in is the month of the paid date (or the subsidy date).

Eligibility: an employee earns incentives only from `eligible_from` (date of joining + the qualifying period, 3 months
by default), judged on the date the incentive is earned (paid date, subsidy date, or the last day of the month for
monthly rules). Before that date the employee is left out of "all in role" splits — the others share as if they were
not in the role — and an amount on a project where they are the one named person is not paid to anyone.
"""
import calendar
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal

Z = Decimal("0")
HUNDRED = Decimal("100")
Q4 = Decimal("0.0001")


@dataclass(frozen=True)
class Rule:
    id: object
    role_id: object
    label: str
    trigger: str                      # billPaid | finalPaid | subsidy | monthly
    basis: str                        # pct | fixed
    value: Decimal
    categories: tuple = ("*",)
    govt: str = "any"                 # any | yes | no
    tender: str = "any"
    requires_ei_kseb: bool = False
    role_name: str = ""


@dataclass
class Bill:
    id: object
    number: str
    bill_date: date | None
    amount: Decimal                   # before GST (net of credit notes)
    final: bool = False
    paid_date: date | None = None     # set when paid in full


@dataclass
class Project:
    id: object
    label: str
    category: str | None
    client: str = ""
    is_govt: bool = False
    from_tender: bool = False
    ei_kseb: bool = False
    contract_value: Decimal = Z
    subsidy_done: bool = False
    subsidy_date: date | None = None
    team: dict = field(default_factory=dict)          # role id -> "all" | "none" | employee id
    bills: list[Bill] = field(default_factory=list)

    @property
    def value(self) -> Decimal:
        return self.contract_value if self.contract_value else sum((b.amount for b in self.bills), Z)


@dataclass(frozen=True)
class Member:
    employee_id: object
    name: str
    active: bool = True
    eligible_from: date | None = None     # None = eligible (no qualifying period known)

    def eligible_on(self, when: date | None) -> bool:
        return self.eligible_from is None or (when is not None and when >= self.eligible_from)


@dataclass
class Line:
    employee_id: object
    employee_name: str
    role_id: object
    role_name: str
    rule_id: object
    rule_label: str
    trigger: str
    project_id: object | None
    project_label: str
    client: str
    category: str | None
    invoice_id: object | None
    basis_ref: str
    base: Decimal
    rate_basis: str
    rate_value: Decimal
    split: int
    amount: Decimal
    event_date: date | None


def ym_of(d: date | None) -> str | None:
    return f"{d.year:04d}-{d.month:02d}" if d else None


def matches(r: Rule, p: Project) -> bool:
    cats = tuple(r.categories or ("*",))
    if "*" not in cats and p.category not in cats:
        return False
    if (r.govt == "yes" and not p.is_govt) or (r.govt == "no" and p.is_govt):
        return False
    if (r.tender == "yes" and not p.from_tender) or (r.tender == "no" and p.from_tender):
        return False
    return not (r.requires_ei_kseb and not p.ei_kseb)


def add_months(d: date, n: int) -> date:
    y, m = divmod(d.month - 1 + n, 12)
    y, m = d.year + y, m + 1
    return date(y, m, min(d.day, calendar.monthrange(y, m)[1]))


def month_end(ym: str) -> date:
    y, m = (int(x) for x in ym.split("-"))
    return date(y, m, calendar.monthrange(y, m)[1])


def recipients(p: Project | None, role_id, members: dict, when: date | None = None) -> list[Member]:
    """Who shares an amount on a project for a role, earned on `when`. `members` maps role id -> list[Member]
    (active and inactive)."""
    active = [m for m in members.get(role_id, []) if m.active]
    eligible = [m for m in active if m.eligible_on(when)]
    if p is None:
        return eligible
    choice = (p.team or {}).get(str(role_id), "all")
    if choice == "none":
        return []
    if choice in ("all", None, ""):
        return eligible
    chosen = [m for m in active if str(m.employee_id) == str(choice)]
    if chosen:                     # the named person: theirs alone, nothing while still in the qualifying period
        return [m for m in chosen if m.eligible_on(when)]
    return eligible                # a person no longer in the role: fall back to everyone in it


def amount_of(r: Rule, base: Decimal) -> Decimal:
    return base * r.value / HUNDRED if r.basis == "pct" else r.value


def paid_in(b: Bill, ym: str) -> bool:
    return b.paid_date is not None and ym_of(b.paid_date) == ym


def lines_for_month(ym: str, rules: list[Rule], projects: list[Project], members: dict,
                    accounts_proper: bool) -> list[Line]:
    out: list[Line] = []

    def push(r: Rule, p: Project | None, ref: str, base: Decimal, amt: Decimal, rc: list[Member],
             invoice_id=None, when: date | None = None) -> None:
        if not rc or not amt:
            return
        share = (amt / len(rc)).quantize(Q4)
        for m in rc:
            out.append(Line(m.employee_id, m.name, r.role_id, r.role_name, r.id, r.label, r.trigger,
                            p.id if p else None, p.label if p else "Month total", p.client if p else "",
                            p.category if p else None, invoice_id, ref, base, r.basis, r.value, len(rc), share, when))

    for p in projects:
        for b in p.bills:
            if not paid_in(b, ym):
                continue
            for r in rules:
                if not matches(r, p):
                    continue
                if r.trigger == "billPaid":
                    push(r, p, f"Bill {b.number}", b.amount, amount_of(r, b.amount), recipients(p, r.role_id, members, b.paid_date),
                         b.id, b.paid_date)
                elif r.trigger == "finalPaid" and b.final:
                    base = p.value if r.basis == "pct" else Z
                    push(r, p, f"Final bill {b.number}", base, amount_of(r, p.value), recipients(p, r.role_id, members, b.paid_date),
                         b.id, b.paid_date)
        if p.subsidy_done and ym_of(p.subsidy_date) == ym:
            for r in rules:
                if r.trigger == "subsidy" and matches(r, p):
                    push(r, p, "Subsidy & final docs", p.value, amount_of(r, p.value), recipients(p, r.role_id, members, p.subsidy_date),
                         None, p.subsidy_date)
    if accounts_proper:
        for r in rules:
            if r.trigger != "monthly":
                continue
            base = sum((b.amount for p in projects if matches(r, p) for b in p.bills if paid_in(b, ym)), Z)
            end = month_end(ym)
            push(r, None, f"Collections {ym}", base, amount_of(r, base), recipients(None, r.role_id, members, end),
                 when=end)
    return out


def totals_by_employee(lines: list[Line]) -> dict:
    t: dict = defaultdict(lambda: Z)
    for ln in lines:
        t[ln.employee_id] += ln.amount
    return dict(t)


def billed_in(ym: str, projects: list[Project]) -> tuple[Decimal, dict, int]:
    total, by_cat, n = Z, defaultdict(lambda: Z), 0
    for p in projects:
        for b in p.bills:
            if ym_of(b.bill_date) == ym:
                total += b.amount
                by_cat[p.category] += b.amount
                n += 1
    return total, dict(by_cat), n


def collected_in(ym: str, projects: list[Project]) -> tuple[Decimal, dict, int]:
    total, by_cat, n = Z, defaultdict(lambda: Z), 0
    for p in projects:
        for b in p.bills:
            if paid_in(b, ym):
                total += b.amount
                by_cat[p.category] += b.amount
                n += 1
    return total, dict(by_cat), n


def welfare(billed: Decimal, pct: Decimal) -> Decimal:
    return billed * pct / HUNDRED
