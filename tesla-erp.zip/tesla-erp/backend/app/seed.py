"""Seed data.

    python -m app.seed core   # every environment: company, numbering, roles/permissions, first admin
    python -m app.seed demo   # development/staging only: Spec §46 sample data + one user per role

Idempotent: safe to run repeatedly.
"""
import sys
from datetime import date
from decimal import Decimal
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

import app.models  # noqa: F401 - every table registered, so foreign keys between modules resolve
from app.company.models import BusinessDivision, Company
from app.core.config import get_settings
from app.core.db import SessionLocal
from app.core.security import hash_password
from app.customers.models import Customer, CustomerContact, CustomerSite
from app.hr.models import Department, Designation, Employee
from app.platform.documents import service as documents
from app.platform.numbering.models import NumberingFormat
from app.platform.numbering.service import DEFAULT_FORMATS
from app.products.models import Brand, Item, ItemCategory, TaxRate, Unit, Warehouse
from app.suppliers.models import Supplier, SupplierContact
from app.users.bootstrap import sync_permissions
from app.users.models import Role, User, UserRole

LOGO = Path(__file__).parent / "assets" / "tce-logo.png"


def _get_or_create(session: Session, cls, lookup: dict, **values):
    obj = session.scalar(select(cls).filter_by(**lookup))
    if obj is None:
        obj = cls(**lookup, **values)
        session.add(obj)
        session.flush()
    return obj


def seed_core(session: Session) -> Company:
    s = get_settings()
    company = _get_or_create(
        session, Company, {"code": "TCE"},
        company_name="Tesla Consulting Engineers", legal_name="Tesla Consulting Engineers",
        tagline="Empowering Safety, Protecting Lives", state="Kerala", state_code="32", is_default=True,
    )
    for f in DEFAULT_FORMATS:
        _get_or_create(session, NumberingFormat, {"company_id": company.id, "doc_type": f["doc_type"]},
                       label=f["label"], pattern=f["pattern"], period=f["period"], max_length=f.get("max_length"))
    sync_permissions(session)
    admin = session.scalar(select(User).where(User.username == "admin"))
    if admin is None:
        admin = User(username="admin", email=s.seed_admin_email, full_name="System Administrator",
                     password_hash=hash_password(s.seed_admin_password), must_change_password=True)
        session.add(admin)
        session.flush()
        session.add(UserRole(user_id=admin.id, role_id=session.scalar(select(Role.id).where(Role.code == "ADMIN"))))
    seed_org_masters(session, company, admin.id)
    seed_sales_setup(session, company, admin.id)
    seed_purchase_setup(session, company, admin.id)
    seed_finance_setup(session, company, admin.id)
    seed_hr_setup(session, company, admin.id)
    from app.hr.service import backfill

    backfill(session, company.id, admin.id)  # every login gets an employee record (Phase 7)
    from app.crm.service import backfill_prospect_customers

    backfill_prospect_customers(session, company.id, admin.id)  # open prospect leads get a customer record

    from app.chat.service import ensure_company_channel

    ensure_company_channel(session, admin.id)  # "Tesla Team": everyone with a login is in it
    if company.logo_document_id is None and LOGO.exists():
        doc = documents.upload(session, entity_type="company", entity_id=company.id, category="logo",
                               file_name="tce-logo.png", data=LOGO.read_bytes(), user_id=admin.id)
        company.logo_document_id = doc.id
    session.flush()
    return company


DIVISIONS = [
    ("CONSULT", "Electrical Consultancy"), ("CONTRACT", "Electrical Contracting"),
    ("LPS", "Lightning Protection Systems"), ("SPS", "Surge Protection Systems"), ("SAFETY", "Electrical Safety"),
    ("SOLAR", "Solar EPC & Components"), ("EV", "EV Charging Infrastructure"),
    ("TEST", "Testing & Commissioning"), ("AMC", "Maintenance / AMC"),
]
DEPARTMENTS = [("MGMT", "Management"), ("SALES", "Sales"), ("PROJ", "Projects"), ("PUR", "Purchase"),
               ("STORE", "Stores"), ("ACC", "Accounts"), ("HR", "Human Resources"), ("SRV", "Service")]
DESIGNATIONS = ["Director", "Manager", "Sales Engineer", "Project Manager", "Site Engineer", "Purchase Executive",
                "Store Keeper", "Accountant", "HR Executive", "Technician"]


def seed_org_masters(session: Session, company: Company, user_id) -> None:
    """Starter divisions, departments and designations (Spec §7) — only into an EMPTY list, so a list the
    company has already edited is never touched. Without these, the employee form has nothing to pick."""
    by = {"created_by": user_id, "updated_by": user_id}
    if session.scalar(select(BusinessDivision.id).where(BusinessDivision.company_id == company.id).limit(1)) is None:
        for code, name in DIVISIONS:
            session.add(BusinessDivision(company_id=company.id, code=code, name=name, **by))
    if session.scalar(select(Department.id).limit(1)) is None:
        for code, name in DEPARTMENTS:
            session.add(Department(code=code, name=name, **by))
    if session.scalar(select(Designation.id).limit(1)) is None:
        for name in DESIGNATIONS:
            session.add(Designation(name=name, **by))
    session.flush()


QUOTATION_TERMS = [
    ("payment", "Standard payment", "50% advance along with the purchase order; balance 50% against delivery / completion.", True, 10),
    ("delivery", "Standard delivery", "Materials within 3–4 weeks from receipt of a confirmed purchase order and advance. "
                                      "Installation follows as per site readiness.", True, 10),
    ("warranty", "Standard warranty", "12 months from commissioning or 18 months from supply, whichever is earlier, against "
                                      "manufacturing defects. Damage from misuse, third-party work or events beyond the "
                                      "equipment's rating is not covered.", True, 10),
    ("general", "Prices and taxes", "Prices are in Indian Rupees. GST is charged as shown; any change in tax rates at the "
                                    "time of billing will apply.", True, 10),
    ("general", "Customer scope", "Civil work, scaffolding, core cutting, site access, lifts and power supply are in the "
                                  "customer's scope unless included in the BOQ.", True, 20),
    ("general", "Measured quantities", "Quantities are estimated from the site survey; billing will be on actual measured "
                                       "quantities at the quoted rates.", True, 30),
    ("general", "Extra work", "Any work beyond the BOQ will be quoted and carried out only after written approval.", True, 40),
    ("general", "Title", "Materials remain the property of Tesla Consulting Engineers until paid in full.", False, 50),
]


def seed_sales_setup(session: Session, company: Company, user_id) -> None:
    """Phase 3 starting point, added only where nothing exists yet: the Spec §30 approval rule and a terms library."""
    from decimal import Decimal

    from app.core.money import format_inr
    from app.platform.approvals.models import ApprovalPolicy
    from app.platform.settings.models import AppSetting
    from app.quotations.models import QuotationTerm

    by = {"created_by": user_id, "updated_by": user_id}
    if session.scalar(select(ApprovalPolicy.id).where(ApprovalPolicy.entity_type == "quotation").limit(1)) is None:
        # Carry over the Phase 1 setting if it had been changed; otherwise the spec's ₹5 lakh.
        old = session.scalar(select(AppSetting.value).where(AppSetting.company_id == company.id,
                                                            AppSetting.key == "approvals.quotation_director_threshold"))
        limit = Decimal(str(old)) if isinstance(old, int | float) and old >= 0 else Decimal("500000")
        session.add(ApprovalPolicy(entity_type="quotation", name=f"Quotations above ₹{format_inr(limit)[:-3]} (before GST)",
                                   min_amount=limit, steps=["MANAGER", "DIRECTOR"], **by))
    if session.scalar(select(QuotationTerm.id).limit(1)) is None:
        for cat, title, text, default, order in QUOTATION_TERMS:
            session.add(QuotationTerm(category=cat, title=title, text=text, is_default=default, sort_order=order, **by))
    session.flush()


def seed_purchase_setup(session: Session, company: Company, user_id) -> None:
    """Phase 5 starting point, added only where nothing exists yet: approval rules for purchase requests, purchase
    orders and stock adjustments, and a main store."""
    from app.core.money import format_inr
    from app.platform.approvals.models import ApprovalPolicy
    from app.platform.settings.models import AppSetting

    by = {"created_by": user_id, "updated_by": user_id}

    def missing(entity: str) -> bool:
        return session.scalar(select(ApprovalPolicy.id).where(ApprovalPolicy.entity_type == entity).limit(1)) is None

    if missing("purchase_request"):
        session.add(ApprovalPolicy(entity_type="purchase_request", name="All purchase requests", min_amount=Decimal("0"),
                                   steps=["MANAGER"], **by))
    if missing("purchase_order"):
        # Carry over the Phase 1 setting "purchase value needing Director approval" if it had been changed.
        old = session.scalar(select(AppSetting.value).where(AppSetting.company_id == company.id,
                                                            AppSetting.key == "approvals.purchase_director_threshold"))
        limit = Decimal(str(old)) if isinstance(old, int | float) and old >= 0 else Decimal("200000")
        session.add(ApprovalPolicy(entity_type="purchase_order", name="All purchase orders", min_amount=Decimal("0"),
                                   steps=["MANAGER"], **by))
        session.add(ApprovalPolicy(entity_type="purchase_order",
                                   name=f"Purchase orders above ₹{format_inr(limit)[:-3]} (before GST)",
                                   min_amount=limit, steps=["MANAGER", "DIRECTOR"], **by))
    if missing("stock_adjustment"):
        session.add(ApprovalPolicy(entity_type="stock_adjustment", name="All stock adjustments", min_amount=Decimal("0"),
                                   steps=["MANAGER"], **by))
    if session.scalar(select(Warehouse.id).where(Warehouse.company_id == company.id).limit(1)) is None:
        session.add(Warehouse(company_id=company.id, code="MAIN", name="Main Store", warehouse_type="main", **by))
    session.flush()


EXPENSE_CATEGORIES = [  # (name, ledger, needs project, needs receipt)
    ("Travel — bus / train / flight", "Travelling & Conveyance", False, True),
    ("Local conveyance / fuel", "Travelling & Conveyance", False, False),
    ("Food & lodging (site)", "Travelling & Conveyance", True, True),
    ("Site consumables", "Site Expenses", True, True),
    ("Labour charges (daily wages)", "Labour Charges", True, True),
    ("Tools & equipment hire", "Tools & Equipment Hire", True, True),
    ("Courier & printing", "Office & Administrative Expenses", False, True),
    ("Mobile & internet", "Communication Expenses", False, True),
]


def seed_finance_setup(session: Session, company: Company, user_id) -> None:
    """Phase 7 starting point: the chart of accounts, expense categories (only into an empty list), and approval
    rules for expense claims (Manager → Accounts, Spec §30) and for supplier bills that differ from the PO/GRN."""
    from app.finance import gl
    from app.finance.models import ExpenseCategory, LedgerAccount
    from app.platform.approvals.models import ApprovalPolicy

    by = {"created_by": user_id, "updated_by": user_id}
    gl.seed_accounts(session, user_id)
    if session.scalar(select(ExpenseCategory.id).limit(1)) is None:
        accounts = {a.name: a.id for a in session.scalars(select(LedgerAccount))}
        for name, ledger, prj, rcpt in EXPENSE_CATEGORIES:
            if ledger in accounts:
                session.add(ExpenseCategory(name=name, account_id=accounts[ledger], needs_project=prj,
                                            needs_receipt=rcpt, **by))
    for entity, name, steps in (("expense", "All expense claims", ["MANAGER", "ACCOUNTS"]),
                                ("supplier_invoice", "Bills that differ from the PO / GRN", ["MANAGER"]),
                                ("material_issue", "All material issues", ["PROJECT_MANAGER"])):
        if session.scalar(select(ApprovalPolicy.id).where(ApprovalPolicy.entity_type == entity).limit(1)) is None:
            session.add(ApprovalPolicy(entity_type=entity, name=name, min_amount=Decimal("0"), steps=steps, **by))
    session.flush()


LEAVE_TYPES = [  # code, name, annual quota (None = no limit), paid, carry forward, max carry
    ("CL", "Casual leave", "12", True, False, None),
    ("SL", "Sick leave", "12", True, False, None),
    ("EL", "Earned leave", "15", True, True, "30"),
    ("LOP", "Leave without pay", None, False, False, None),
]
FIXED_HOLIDAYS = [((1, 26), "Republic Day"), ((5, 1), "May Day"), ((8, 15), "Independence Day"),
                  ((10, 2), "Gandhi Jayanti"), ((12, 25), "Christmas")]


def seed_hr_setup(session: Session, company: Company, user_id) -> None:
    """Phase 8 starting point, only into empty lists: leave types, this and next year's fixed national holidays (add
    Onam, Vishu and other festival dates in HR → Holidays), and the leave approval rule (the line manager)."""
    from app.crm.service import today
    from app.hr.models import Holiday, LeaveType
    from app.platform.approvals.models import ApprovalPolicy

    by = {"created_by": user_id, "updated_by": user_id}
    if session.scalar(select(LeaveType.id).limit(1)) is None:
        for code, name, quota, paid, cf, maxcf in LEAVE_TYPES:
            session.add(LeaveType(code=code, name=name, annual_quota=Decimal(quota) if quota else None, paid=paid,
                                  carry_forward=cf, max_carry_forward=Decimal(maxcf) if maxcf else None, **by))
    if session.scalar(select(Holiday.id).limit(1)) is None:
        y = today().year
        for year in (y, y + 1):
            for (m, d), name in FIXED_HOLIDAYS:
                session.add(Holiday(holiday_date=date(year, m, d), name=name, **by))
    if session.scalar(select(ApprovalPolicy.id).where(ApprovalPolicy.entity_type == "leave_request").limit(1)) is None:
        session.add(ApprovalPolicy(entity_type="leave_request", name="All leave requests", min_amount=Decimal("0"),
                                   steps=["LINE_MANAGER"], **by))
    session.flush()


DEMO_USERS = [
    ("director", "Director", "DIRECTOR"), ("manager", "Operations Manager", "MANAGER"),
    ("sales1", "Anil Kumar (Sales)", "SALES"), ("sales2", "Divya Menon (Sales)", "SALES"),
    ("pm1", "Rahul Nair (Project Manager)", "PROJECT_MANAGER"), ("engineer1", "Arjun Das (Site Engineer)", "SITE_ENGINEER"),
    ("purchase1", "Meera Thomas (Purchase)", "PURCHASE"), ("store1", "Suresh Babu (Store)", "STORE"),
    ("accounts1", "Lakshmi Iyer (Accounts)", "ACCOUNTS"), ("hr1", "Nisha Varghese (HR)", "HR"),
    ("employee1", "Vishnu Prasad (Employee)", "EMPLOYEE"),
]
DEMO_PASSWORD = "Tesla@Demo2026"

CATEGORIES = [
    ("LP", "Lightning Protection"), ("SPD", "Surge Protection"), ("EARTH", "Earthing"), ("ELEC", "Electrical"),
    ("SOLAR", "Solar"), ("EV", "EV Charging"), ("CABLE", "Cable"), ("PANEL", "Panel"), ("SWG", "Switchgear"),
    ("PPE", "PPE"), ("TOOLS", "Tools"), ("CONS", "Consumables"), ("SVC", "Services"),
]
def seed_demo(session: Session, company: Company) -> None:
    admin = session.scalar(select(User).where(User.username == "admin"))
    by = {"created_by": admin.id, "updated_by": admin.id}
    roles = {r.code: r for r in session.scalars(select(Role))}
    users = {}
    for username, name, role in DEMO_USERS:
        u = session.scalar(select(User).where(User.username == username))
        if u is None:
            u = User(username=username, email=f"{username}@teslace-demo.in", full_name=name,
                     password_hash=hash_password(DEMO_PASSWORD), must_change_password=False, **by)
            session.add(u)
            session.flush()
            session.add(UserRole(user_id=u.id, role_id=roles[role].id))
        users[username] = u

    for code, name in DIVISIONS:
        _get_or_create(session, BusinessDivision, {"company_id": company.id, "code": code}, name=name, **by)
    depts = {}
    for code, name in DEPARTMENTS:
        depts[code] = _get_or_create(session, Department, {"code": code}, name=name, **by)
    desig = {}
    for name in DESIGNATIONS:
        desig[name] = _get_or_create(session, Designation, {"name": name}, **by)
    for i, (username, dept, d) in enumerate([
        ("director", "MGMT", "Director"), ("manager", "MGMT", "Manager"), ("sales1", "SALES", "Sales Engineer"),
        ("sales2", "SALES", "Sales Engineer"), ("pm1", "PROJ", "Project Manager"),
        ("engineer1", "PROJ", "Site Engineer"), ("purchase1", "PUR", "Purchase Executive"),
        ("store1", "STORE", "Store Keeper"), ("accounts1", "ACC", "Accountant"), ("hr1", "HR", "HR Executive"),
        ("employee1", "SRV", "Technician"),
    ], start=1):
        u = users[username]
        _get_or_create(session, Employee, {"employee_code": f"TCE{i:04d}"}, full_name=u.full_name.split(" (")[0],
                       email=u.email, department_id=depts[dept].id, designation_id=desig[d].id, user_id=u.id,
                       date_of_joining=date(2024, 4, 1), **by)

    cats = {code: _get_or_create(session, ItemCategory, {"code": code}, name=name, **by) for code, name in CATEGORIES}
    units = {}
    for code, name, dec in [("NOS", "Numbers", 0), ("SET", "Set", 0), ("M", "Metre", 2), ("KG", "Kilogram", 3),
                            ("LOT", "Lot", 0), ("JOB", "Job", 0)]:
        units[code] = _get_or_create(session, Unit, {"code": code}, name=name, decimals=dec, **by)
    _get_or_create(session, Unit, {"code": "ROLL50"}, name="Roll (50 m)", decimals=0, base_unit_id=units["M"].id,
                   factor=Decimal("50"), **by)
    taxes = {}
    for rate in (0, 5, 12, 18, 28):
        taxes[rate] = _get_or_create(session, TaxRate, {"code": f"GST{rate}"}, name=f"GST {rate}%",
                                     rate=Decimal(rate), effective_from=date(2017, 7, 1), **by)
    brands = {n: _get_or_create(session, Brand, {"name": n}, **by) for n in ["DEHN", "Generic", "Waaree", "Delta"]}
    _get_or_create(session, Warehouse, {"company_id": company.id, "code": "MAIN"}, name="Main Store — Thrissur",
                   warehouse_type="main", in_charge_id=users["store1"].id, **by)

    items = [
        ("DEHN-SPD-T12", "DEHN SPD Type 1+2, 3+NPE", "SPD", "DEHN", "DV M TNC 255", "NOS", "85363000", 18, 14200, 16000, True),
        ("LP-AT-16", "Air Terminal, copper, 16 mm × 1 m", "LP", "DEHN", "AT-16", "NOS", "85359090", 18, 1850, 2400, False),
        ("LP-CT-25X3", "Copper Tape 25 × 3 mm", "LP", "Generic", None, "M", "74072990", 18, 620, 780, False),
        ("EA-GI-50X6", "GI Strip 50 × 6 mm", "EARTH", "Generic", None, "M", "72125090", 18, 160, 210, False),
        ("EA-ELEC-3M", "Earth Electrode, copper-bonded, 17.2 mm × 3 m", "EARTH", "Generic", "CBE-3000", "NOS", "85469090", 18, 2900, 3600, False),
        ("SOL-MOD-545", "Solar Module 545 Wp mono PERC", "SOLAR", "Waaree", "WSMDi-545", "NOS", "85414300", 12, 13200, 15500, True),
        ("SOL-INV-10K", "Solar Inverter 10 kW on-grid, 3-phase", "SOLAR", "Delta", "RPI M10A", "NOS", "85044010", 12, 98000, 112000, True),
        ("EV-AC-7K", "EV Charger 7.4 kW AC wallbox", "EV", "Delta", "AC Mini Plus", "NOS", "85044090", 18, 42000, 52000, True),
    ]
    for code, name, cat, brand, model, unit, hsn, gst, pp, sp, serial in items:
        _get_or_create(session, Item, {"item_code": code}, item_name=name, item_type="goods",
                       category_id=cats[cat].id, brand_id=brands[brand].id, model=model, unit_id=units[unit].id,
                       hsn_sac=hsn, tax_rate_id=taxes[gst].id, purchase_price=Decimal(pp), selling_price=Decimal(sp),
                       minimum_stock=Decimal(5 if unit == "NOS" else 50), reorder_level=Decimal(10 if unit == "NOS" else 100),
                       serial_number_required=serial, **by)
    _get_or_create(session, Item, {"item_code": "SVC-LPS-INST"}, item_name="LPS installation & commissioning",
                   item_type="service", category_id=cats["SVC"].id, unit_id=units["JOB"].id, hsn_sac="995461",
                   tax_rate_id=taxes[18].id, **by)

    abc = _get_or_create(
        session, Customer, {"customer_code": "CUS00001"}, customer_name="ABC Hospital", customer_type="hospital",
        company_name="ABC Healthcare Pvt Ltd", phone="0487 2330000", email="facilities@abchospital-demo.in",
        address_line1="East Fort", city="Thrissur", district="Thrissur", state="Kerala", state_code="32",
        pincode="680005", default_payment_terms="50% advance, balance against delivery", credit_limit=Decimal("1000000"),
        credit_days=30, assigned_sales_person_id=users["sales1"].id, **by)
    if not abc.contacts:
        session.add(CustomerContact(customer_id=abc.id, name="Mr. Joseph Mathew", designation="Facilities Manager",
                                    phone="98470 00000", email="joseph@abchospital-demo.in", is_primary=True, **by))
        session.add(CustomerSite(customer_id=abc.id, site_name="ABC Hospital — Main Block", address_line1="East Fort",
                                 city="Thrissur", state="Kerala", state_code="32", pincode="680005",
                                 contact_name="Mr. Joseph Mathew", contact_phone="98470 00000", **by))
    dehn = _get_or_create(
        session, Supplier, {"supplier_code": "SUP00001"}, supplier_name="DEHN India Pvt Ltd",
        supplies="Lightning & surge protection, earthing", city="Bengaluru", state="Karnataka", state_code="29",
        payment_terms="30 days from invoice", credit_days=30, rating=Decimal("4.5"), **by)
    if not dehn.contacts:
        session.add(SupplierContact(supplier_id=dehn.id, name="Sales Desk", phone="080 0000 0000",
                                    email="sales@dehn-demo.in", is_primary=True, **by))
    # Keep auto-numbering ahead of the hand-seeded codes.
    from sqlalchemy import text as sql

    for doc_type, used in (("CUSTOMER", 1), ("SUPPLIER", 1), ("EMPLOYEE", len(DEMO_USERS))):
        session.execute(sql("""
            INSERT INTO document_sequences (id, company_id, doc_type, period_key, last_value)
            VALUES (gen_random_uuid(), :c, :t, '-', :v)
            ON CONFLICT (company_id, doc_type, period_key)
            DO UPDATE SET last_value = GREATEST(document_sequences.last_value, EXCLUDED.last_value)
        """), {"c": company.id, "t": doc_type, "v": used})
    session.flush()
    seed_demo_hr(session, company, users)
    seed_demo_crm(session, company, users, abc)
    seed_demo_chat(session, users)
    # The sample project "ABC Hospital Lightning Protection Project" is seeded in Phase 4 with the projects module.


def seed_demo_chat(session: Session, users: dict) -> None:
    """A few messages in the company channel and one direct conversation — only into an empty channel."""
    from app.auth.deps import Principal
    from app.chat import service as chat
    from app.chat.models import ChatMessage

    ch = chat.ensure_company_channel(session)
    if session.scalar(select(ChatMessage.id).where(ChatMessage.channel_id == ch.id).limit(1)) is not None:
        return

    def who(username: str) -> Principal:
        return Principal(user=users[username], company_id=session.scalar(select(Company.id).limit(1)),
                         permissions={"chat.use": "all"})

    first = chat.post(session, who("director"), ch, reply_to_id=None, attachment_ids=[], mention_ids=[],
                      body="Good morning team! This is our new team chat. Share site updates, photos and questions "
                           "here.\nFor one-to-one messages, use the + button and pick a person.")
    chat.post(session, who("pm1"), ch, reply_to_id=first.id, attachment_ids=[], mention_ids=[],
              body="Thank you sir. ABC Hospital LPS work: air terminals on the main block are done today.")
    chat.post(session, who("store1"), ch, reply_to_id=None, attachment_ids=[], mention_ids=[users["pm1"].id],
              body="@" + users["pm1"].full_name + " 50 m copper tape is ready at the main store for pickup tomorrow.")
    dm = chat.direct(session, who("sales1"), users["pm1"].id)
    chat.post(session, who("sales1"), dm, reply_to_id=None, attachment_ids=[], mention_ids=[],
              body="Hi, can you share the site photos of ABC Hospital for the customer review meeting?")
    session.flush()


def seed_demo_hr(session: Session, company: Company, users: dict) -> None:
    """Phase 8 sample: reporting lines, personal details, salary records for two people, and a few days of
    attendance and leave."""
    import json
    from datetime import datetime, time, timedelta
    from zoneinfo import ZoneInfo

    from app.crm.service import today
    from app.hr.models import Attendance, LeaveRequest, LeaveType, SalaryRecord

    IST = ZoneInfo("Asia/Kolkata")

    emp = {u: session.scalar(select(Employee).where(Employee.user_id == users[u].id)) for u in users}
    if session.scalar(select(SalaryRecord.id).limit(1)) is not None:
        return
    admin = session.scalar(select(User).where(User.username == "admin"))
    by = {"created_by": admin.id, "updated_by": admin.id}
    lines = {"manager": "director", "sales1": "manager", "sales2": "manager", "pm1": "manager", "engineer1": "pm1",
             "purchase1": "manager", "store1": "manager", "accounts1": "director", "hr1": "director",
             "employee1": "pm1"}
    for u, m in lines.items():
        emp[u].reports_to_id = emp[m].id
    e = emp["engineer1"]
    e.date_of_birth, e.gender, e.blood_group = date(1996, 10, 12), "male", "B+"
    e.emergency_contact_name, e.emergency_contact_phone, e.emergency_contact_relation = "Leela Das", "9847055501", "Mother"
    e.current_address, e.work_location = "Ayyanthole, Thrissur 680003", "Thrissur / sites"
    e.bank_name, e.bank_account_name, e.bank_account_number, e.bank_ifsc = \
        "State Bank of India", "Arjun Das", "30211234567", "SBIN0070182"
    for u, basic, hra, special, rate in (("engineer1", 18000, 7200, 6800, 1450), ("employee1", 13000, 5200, 3800, 0),
                                         ("pm1", 32000, 12800, 15200, 0)):
        comps = {"basic": basic, "hra": hra, "special_allowance": special, "employee_pf": round(basic * 0.12),
                 "employer_pf": round(basic * 0.12), "professional_tax": 208, "labour_day_rate": rate}
        session.add(SalaryRecord(employee_id=emp[u].id, effective_from=date(2026, 4, 1),
                                 components=json.dumps({k: str(v) for k, v in comps.items()}), remarks="FY 2026-27", **by))
    session.flush()
    prj_id = None  # attendance is linked to the ABC Hospital project once it exists (seed_demo_projects)
    t = today()
    d, n = t - timedelta(days=1), 0
    while n < 4:
        if d.weekday() != 6:
            for u in ("engineer1", "employee1"):
                session.add(Attendance(employee_id=emp[u].id, att_date=d, status="present", source="self",
                                       check_in_at=datetime.combine(d, time(9, 5), IST), project_id=prj_id,
                                       check_out_at=datetime.combine(d, time(17, 50), IST), work_hours=Decimal("8.75"),
                                       check_in_lat=Decimal("10.527600"), check_in_lng=Decimal("76.214400"),
                                       check_in_accuracy_m=18, created_by=users[u].id, updated_by=users[u].id))
            n += 1
        d -= timedelta(days=1)
    cl = session.scalar(select(LeaveType).where(LeaveType.code == "CL"))
    nxt = t + timedelta(days=7)
    while nxt.weekday() == 6:
        nxt += timedelta(days=1)
    session.add(LeaveRequest(employee_id=emp["sales2"].id, leave_type_id=cl.id, from_date=nxt, to_date=nxt,
                             half_day="none", days=Decimal("1"), reason="Family function in Kottayam",
                             status="pending", created_by=users["sales2"].id, updated_by=users["sales2"].id))
    session.flush()
    from app.platform.approvals.models import ApprovalRequest

    lr = session.scalar(select(LeaveRequest).where(LeaveRequest.employee_id == emp["sales2"].id))
    session.add(ApprovalRequest(entity_type="leave_request", entity_id=lr.id,
                                entity_label=f"Divya Menon · CL 1 day(s) · {nxt:%d %b}", amount=Decimal("1"),
                                policy_name="All leave requests", steps=["LINE_MANAGER"], current_step=0,
                                status="pending", requested_by=users["sales2"].id,
                                line_manager_id=users["manager"].id))
    session.flush()


def seed_demo_crm(session: Session, company: Company, users: dict, abc: Customer) -> None:
    """Phase 2 sample pipeline: the ABC Hospital lead taken through enquiry and a completed site visit, plus
    prospects at earlier stages. Loaded once (skipped when any lead exists)."""
    from datetime import datetime, time, timedelta
    from zoneinfo import ZoneInfo

    from app.crm.models import CrmActivity, Enquiry, Lead, SiteVisit
    from app.platform.numbering.service import next_number

    if session.scalar(select(Lead.id).limit(1)) is not None:
        return
    ist = ZoneInfo("Asia/Kolkata")
    today = datetime.now(ist).date()
    s1, s2, eng = users["sales1"], users["sales2"], users["engineer1"]
    lps = session.scalar(select(BusinessDivision).where(BusinessDivision.code == "LPS"))
    solar = session.scalar(select(BusinessDivision).where(BusinessDivision.code == "SOLAR"))
    ev = session.scalar(select(BusinessDivision).where(BusinessDivision.code == "EV"))
    site = session.scalar(select(CustomerSite).where(CustomerSite.customer_id == abc.id).limit(1))

    def lead(**kw) -> Lead:
        obj = Lead(lead_number=next_number(session, company.id, "LEAD", on=today), created_by=kw["sales_person_id"],
                   updated_by=kw["sales_person_id"], status_changed_at=datetime.now(ist), **kw)
        session.add(obj)
        session.flush()
        return obj

    l1 = lead(title="Lightning protection for ABC Hospital main block", customer_id=abc.id, source="existing_customer",
              division_id=lps.id if lps else None, requirement="External LPS to IS/IEC 62305 for the 6-storey main "
              "block, with SPDs on the main LT panel.", estimated_value=Decimal("550000"), probability=60,
              expected_closing_date=today + timedelta(days=30), sales_person_id=s1.id, status="site_visit")
    enq = Enquiry(enquiry_number=next_number(session, company.id, "ENQ", on=today), lead_id=l1.id, customer_id=abc.id,
                  site_id=site.id if site else None, division_id=l1.division_id, subject=l1.title,
                  description=l1.requirement, enquiry_date=today, required_by=today + timedelta(days=45),
                  source="existing_customer", priority="high", estimated_value=Decimal("550000"),
                  sales_person_id=s1.id, status="evaluation", status_changed_at=datetime.now(ist),
                  created_by=s1.id, updated_by=s1.id)
    session.add(enq)
    session.flush()
    session.add(SiteVisit(
        visit_number=next_number(session, company.id, "SV", on=today), enquiry_id=enq.id, lead_id=l1.id,
        customer_id=abc.id, site_id=site.id if site else None, site_location="ABC Hospital — Main Block, East Fort, Thrissur",
        visit_date=today - timedelta(days=1), visit_time=time(10, 30), engineer_id=eng.id, status="completed",
        purpose="Survey for external lightning protection and surge protection",
        observations="Roof area approx. 1,200 m² with water tanks and a lift machine room. No existing air "
                     "terminals. Existing earth pits near the DG room are dry and corroded.",
        requirements="Complete external LPS, 4 down conductors, test joints, new earth pits; Type 1+2 SPD on main LT panel.",
        measurements=[{"label": "Building height", "value": "22", "unit": "m"},
                      {"label": "Roof area", "value": "1200", "unit": "m²"},
                      {"label": "Earth pit 1 resistance", "value": "8.4", "unit": "Ω"},
                      {"label": "Earth pit 2 resistance", "value": "11.2", "unit": "Ω"}],
        recommendations="Class III LPS with mesh 15 m × 15 m. Replace both earth pits with copper-bonded electrodes "
                        "(target below 1 Ω combined). Install DEHN Type 1+2 SPD at the main LT panel.",
        customer_rep_name="Mr. Joseph Mathew", customer_rep_designation="Facilities Manager",
        customer_rep_phone="98470 00000", follow_up_date=today + timedelta(days=2),
        completed_at=datetime.now(ist), created_by=s1.id, updated_by=eng.id))
    session.add(CrmActivity(enquiry_id=enq.id, kind="follow_up", subject="Send LPS proposal and BOQ to Mr. Joseph",
                            activity_at=datetime.now(ist), due_at=datetime.combine(today + timedelta(days=2), time(10, 0), ist),
                            assigned_to_id=s1.id, created_by=s1.id, updated_by=s1.id))

    l2 = lead(title="50 kW rooftop solar — St. Mary's School", company_name="St. Mary's Higher Secondary School",
              contact_name="Fr. Thomas Kurian", contact_phone="94470 11111", city="Irinjalakuda", source="referral",
              division_id=solar.id if solar else None, requirement="On-grid rooftop solar on the school block, net metering.",
              estimated_value=Decimal("2400000"), probability=30, expected_closing_date=today + timedelta(days=60),
              sales_person_id=s2.id, status="contacted")
    session.add(CrmActivity(lead_id=l2.id, kind="call", subject="Intro call — interested, wants a site survey",
                            activity_at=datetime.now(ist) - timedelta(days=1), created_by=s2.id, updated_by=s2.id))
    session.add(CrmActivity(lead_id=l2.id, kind="follow_up", subject="Call Fr. Thomas to fix a survey date",
                            activity_at=datetime.now(ist), due_at=datetime.combine(today, time(15, 0), ist),
                            assigned_to_id=s2.id, created_by=s2.id, updated_by=s2.id))
    lead(title="EV chargers for mall parking", company_name="Sobha City Mall", contact_name="Facilities Desk",
         contact_phone="0487 2440000", city="Thrissur", source="website", division_id=ev.id if ev else None,
         requirement="6 × 7.4 kW AC chargers for visitor parking.", estimated_value=Decimal("360000"),
         sales_person_id=s1.id, status="new")
    lost = lead(title="Earthing audit — textile unit", company_name="Kairali Textiles", contact_name="Mr. Anand",
                contact_phone="94000 22222", city="Palakkad", source="phone", sales_person_id=s2.id, status="lost",
                estimated_value=Decimal("45000"))
    lost.lost_reason = "Went with a local contractor on price"
    session.flush()
    from app.crm.service import backfill_prospect_customers

    backfill_prospect_customers(session, company.id, None)  # prospects are customers too (CUS code, "prospect")
    seed_demo_sales(session, company, enq)


def seed_demo_sales(session: Session, company: Company, enq) -> None:
    """Phase 3 sample: the ABC Hospital BOQ and a quotation sent from it (R0)."""
    from app.auth.deps import Principal, load_permissions
    from app.boq import service as boq_service
    from app.boq.lines import LineIn
    from app.boq.schemas import BoqIn
    from app.quotations import service as qs
    from app.quotations.schemas import QuotationIn

    pm = session.scalar(select(User).where(User.username == "pm1"))
    sales = session.scalar(select(User).where(User.username == "sales1"))

    def principal(u: User) -> Principal:
        perms, roles = load_permissions(session, u.id)
        return Principal(user=u, company_id=company.id, permissions=perms, role_codes=roles)

    items = {i.item_code: i for i in session.scalars(select(Item))}

    def ln(code, qty, section, rate=None, remarks=None):
        it = items[code]
        return LineIn(section=section, item_id=it.id, description=it.item_name, hsn_sac=it.hsn_sac,
                      technical_specification=it.technical_specification, quantity=Decimal(qty), unit=it.unit.code,
                      rate=Decimal(rate) if rate else it.selling_price, tax_rate=it.tax_rate.rate, remarks=remarks)

    lines = [
        ln("LP-AT-16", "16", "External lightning protection", remarks="On roof parapet, 10 m mesh"),
        ln("LP-CT-25X3", "240", "External lightning protection"),
        ln("EA-ELEC-3M", "6", "Earthing"),
        ln("EA-GI-50X6", "80", "Earthing"),
        ln("DEHN-SPD-T12", "2", "Surge protection", remarks="Main LT panel and DG panel"),
        ln("SVC-LPS-INST", "1", "Installation", rate="65000"),
    ]
    boq = boq_service.create(session, principal(pm), BoqIn(
        title="Lightning & surge protection — ABC Hospital main block", enquiry_id=enq.id, items=lines))
    boq_service.set_status(session, principal(pm), boq.id, "final")
    p = principal(sales)
    q = qs.create(session, p, QuotationIn(enquiry_id=enq.id, boq_id=boq.id, subject=boq.title))
    qs.submit(session, p, q.id, None)
    qs.send(session, p, q.id, None)
    session.flush()
    seed_demo_projects(session, principal, q)


def seed_demo_projects(session: Session, principal, q) -> None:
    """Phase 4 sample: the customer accepts the quotation → sales order → the ABC Hospital project with a team,
    milestones, tasks, an issue and two daily site reports that record installation."""
    from datetime import timedelta

    from app.crm.service import today
    from app.projects import service as ps
    from app.projects.schemas import InstallationIn, IssueIn, MemberIn, MilestoneIn, ProjectIn, SiteReportIn, TaskIn
    from app.quotations import service as qs
    from app.sales import service as sales
    from app.sales.schemas import FromQuotationIn

    users = {u.username: u for u in session.scalars(select(User))}
    sp, pmp = principal(users["sales1"]), principal(users["pm1"])
    eng = users["engineer1"]
    qs.accept(session, sp, q.id, None)
    d0 = today()
    so = sales.create_from_quotation(session, sp, q.id, FromQuotationIn(
        so_date=d0 - timedelta(days=12), customer_po_number="ABCH/ENGG/PO/2026/118",
        customer_po_date=d0 - timedelta(days=13), expected_completion=d0 + timedelta(days=40)))
    prj = ps.create(session, pmp, ProjectIn(
        sales_order_id=so.id, name="ABC Hospital Lightning Protection Project", project_manager_id=users["pm1"].id,
        start_date=d0 - timedelta(days=8), target_end_date=d0 + timedelta(days=40), priority="high",
        members=[MemberIn(user_id=eng.id, role="Site Engineer"),
                 MemberIn(user_id=users["employee1"].id, role="Technician")]))
    ps.set_status(session, pmp, prj.id, "active", None)
    for i, (name, days, done) in enumerate([("Material at site", -3, True), ("Air terminals and conductors", 14, False),
                                            ("Earthing and testing", 28, False), ("Handover", 40, False)]):
        ps.save_milestone(session, pmp, prj.id, MilestoneIn(
            name=name, due_date=d0 + timedelta(days=days), sort_order=i,
            completed_on=d0 - timedelta(days=4) if done else None))
    for title, who, due, status in [
        ("Survey roof and mark air terminal positions", eng, -6, "done"),
        ("Fix air terminals on roof parapet", eng, 5, "in_progress"),
        ("Run down conductors on east and west faces", users["employee1"], 12, "todo"),
        ("Excavate and install chemical earth electrodes", eng, -1, "todo"),
        ("Earth resistance test and report", eng, 30, "todo"),
    ]:
        t = ps.create_task(session, pmp, prj.id, TaskIn(title=title, assigned_to=who.id,
                                                          due_date=d0 + timedelta(days=due)))
        if status != "todo":
            ps.set_task_status(session, pmp, t.id, status, None)
    ps.create_issue(session, principal(eng), prj.id, IssueIn(
        title="Roof access blocked by chiller maintenance", severity="high",
        description="Chiller contractor occupies the north roof until Friday; air terminals there are on hold."))
    lines = {ln.line_no: ln for ln in ps.boq_lines(session, prj.id)}
    ep = principal(eng)
    ps.create_report(session, ep, prj.id, SiteReportIn(
        report_date=d0 - timedelta(days=2), manpower=6, weather="Sunny",
        work_done="Air terminals fixed on the south and east parapet. Conductor tape laid on the east face.",
        next_plan="Continue west face conductors.", progress_pct=20,
        installations=[InstallationIn(boq_line_id=lines[1].id, quantity=Decimal("6"), location="South & east parapet"),
                       InstallationIn(boq_line_id=lines[2].id, quantity=Decimal("80"), location="East face")]))
    ps.create_report(session, ep, prj.id, SiteReportIn(
        report_date=d0 - timedelta(days=1), manpower=5, weather="Light rain in the afternoon",
        work_done="Four more air terminals on the west parapet. Conductor tape on the west face.",
        hindrances="North roof blocked by chiller maintenance.", progress_pct=30,
        installations=[InstallationIn(boq_line_id=lines[1].id, quantity=Decimal("4"), location="West parapet"),
                       InstallationIn(boq_line_id=lines[2].id, quantity=Decimal("60"), location="West face")]))
    session.flush()
    seed_demo_procurement(session, principal, prj)


def seed_demo_procurement(session: Session, principal, prj) -> None:
    """Phase 5 sample: opening stock in the main store, a site store for the ABC Hospital project, a material
    request from site → purchase request → approved purchase order to DEHN → a partial GRN into the site store, and
    a transfer of strip and tape from the main store to site."""
    from datetime import timedelta

    from app.crm.service import today
    from app.inventory import service as inv
    from app.inventory.schemas import AdjustmentIn, AdjustmentLineIn, TransferIn, TransferLineIn
    from app.platform.approvals import service as approvals
    from app.projects import service as ps
    from app.purchase import service as pur
    from app.purchase.schemas import GrnIn, GrnLineIn, MaterialRequestIn, MrLineIn, PoLineIn, PrLineIn, PurchaseOrderIn, PurchaseRequestIn

    users = {u.username: u for u in session.scalars(select(User))}
    store, buyer, mgr = principal(users["store1"]), principal(users["purchase1"]), principal(users["manager"])
    items = {i.item_code: i for i in session.scalars(select(Item))}
    main = session.scalar(select(Warehouse).where(Warehouse.code == "MAIN"))
    d0 = today()

    def approve(entity: str, eid) -> None:
        req = approvals.pending_for(session, entity, eid)
        if req is not None:
            approvals.decide(session, mgr, req.id, "approved", None)

    serials = [f"DV{2026090 + n}" for n in range(3)]
    adj = inv.create_adjustment(session, store, AdjustmentIn(
        adjustment_date=d0 - timedelta(days=20), warehouse_id=main.id, reason_type="opening",
        reason="Opening stock at go-live (physical count 10 Sep)", lines=[
            AdjustmentLineIn(item_id=items["LP-AT-16"].id, quantity=Decimal("40"), unit_cost=Decimal("1850")),
            AdjustmentLineIn(item_id=items["LP-CT-25X3"].id, quantity=Decimal("500"), unit_cost=Decimal("610")),
            AdjustmentLineIn(item_id=items["EA-GI-50X6"].id, quantity=Decimal("300"), unit_cost=Decimal("158")),
            AdjustmentLineIn(item_id=items["EA-ELEC-3M"].id, quantity=Decimal("4"), unit_cost=Decimal("2900")),
            AdjustmentLineIn(item_id=items["DEHN-SPD-T12"].id, quantity=Decimal("3"), unit_cost=Decimal("14200"),
                             serial_nos=serials),
            AdjustmentLineIn(item_id=items["EV-AC-7K"].id, quantity=Decimal("2"), unit_cost=Decimal("42000"),
                             serial_nos=["EVW-7K-1101", "EVW-7K-1102"]),
        ]))
    inv.submit_adjustment(session, store, adj.id, None)
    approve("stock_adjustment", adj.id)

    site = inv.create_site_store(session, principal(users["pm1"]), prj.id)
    lines = {ln.line_no: ln for ln in ps.boq_lines(session, prj.id)}
    inv.create_transfer(session, store, TransferIn(
        transfer_date=d0 - timedelta(days=9), from_warehouse_id=main.id, to_warehouse_id=site.id, vehicle_no="KL 08 BK 4521",
        notes="First lot for ABC Hospital", post=True, lines=[
            TransferLineIn(item_id=items["LP-AT-16"].id, quantity=Decimal("16")),
            TransferLineIn(item_id=items["LP-CT-25X3"].id, quantity=Decimal("240"))]))

    eng = principal(users["engineer1"])
    mr = pur.create_mr(session, eng, MaterialRequestIn(
        request_date=d0 - timedelta(days=6), project_id=prj.id, required_by=d0 + timedelta(days=4), priority="high",
        purpose="Earthing and surge protection for the main block", lines=[
            MrLineIn(item_id=items["EA-ELEC-3M"].id, description=items["EA-ELEC-3M"].item_name, unit="NOS",
                     quantity=Decimal("6"), project_boq_line_id=lines[3].id),
            MrLineIn(item_id=items["EA-GI-50X6"].id, description=items["EA-GI-50X6"].item_name, unit="M",
                     quantity=Decimal("80"), project_boq_line_id=lines[4].id),
            MrLineIn(item_id=items["DEHN-SPD-T12"].id, description=items["DEHN-SPD-T12"].item_name, unit="NOS",
                     quantity=Decimal("2"), project_boq_line_id=lines[5].id)]))
    pur.submit_mr(session, eng, mr.id)
    ml = {ln.line_no: ln for ln in mr.lines}
    pr = pur.create_pr(session, buyer, PurchaseRequestIn(
        pr_date=d0 - timedelta(days=5), project_id=prj.id, warehouse_id=site.id, required_by=d0 + timedelta(days=4),
        priority="high", notes="Electrodes and SPDs for ABC Hospital (GI strip goes from the main store)", lines=[
            PrLineIn(item_id=items["EA-ELEC-3M"].id, description=ml[1].description, unit="NOS", quantity=Decimal("6"),
                     estimated_rate=Decimal("2900"), mr_line_id=ml[1].id),
            PrLineIn(item_id=items["DEHN-SPD-T12"].id, description=ml[3].description, unit="NOS", quantity=Decimal("2"),
                     estimated_rate=Decimal("14200"), mr_line_id=ml[3].id)]))
    pur.submit_pr(session, buyer, pr.id, None)
    approve("purchase_request", pr.id)
    pl = {ln.line_no: ln for ln in pr.lines}
    dehn = session.scalar(select(Supplier).where(Supplier.supplier_code == "SUP00001"))

    def po_line(item, pr_line, qty, rate, disc="0"):
        return PoLineIn(item_id=item.id, description=item.item_name, hsn_sac=item.hsn_sac, quantity=Decimal(qty),
                        unit=item.unit.code, rate=Decimal(rate), discount_pct=Decimal(disc), tax_rate=item.tax_rate.rate,
                        technical_specification=item.technical_specification, pr_line_id=pr_line.id)
    po = pur.create_po(session, buyer, PurchaseOrderIn(
        po_date=d0 - timedelta(days=4), supplier_id=dehn.id, project_id=prj.id, warehouse_id=site.id,
        expected_delivery=d0 + timedelta(days=2), supplier_quote_ref="DEHN/KER/Q/2026/311",
        payment_terms="30 days from receipt of material and invoice", delivery_terms="Door delivery to site, freight included",
        terms=["Quote our PO number on the invoice and delivery challan.",
               "Serial numbers of SPDs must be printed on the delivery challan.",
               "Material is subject to inspection at site; rejected material will be returned at your cost."],
        items=[po_line(items["EA-ELEC-3M"], pl[1], "6", "2900", "5"),
               po_line(items["DEHN-SPD-T12"], pl[2], "2", "14200", "3")]))
    pur.submit_po(session, buyer, po.id, None)
    approve("purchase_order", po.id)
    pur.po_action(session, buyer, po.id, "send", None)
    it = {x.line_no: x for x in po.items}
    pur.create_grn(session, store, GrnIn(
        purchase_order_id=po.id, grn_date=d0 - timedelta(days=1), supplier_invoice_no="DI/2627/08812",
        supplier_invoice_date=d0 - timedelta(days=2), delivery_challan_no="DC-4471", vehicle_no="KL 07 CQ 1180",
        notes="SPD second unit to follow next week.", lines=[
            GrnLineIn(po_line_id=it[1].id, accepted_qty=Decimal("5"), rejected_qty=Decimal("1"),
                      rejection_reason="Copper bonding damaged in transit"),
            GrnLineIn(po_line_id=it[2].id, accepted_qty=Decimal("1"), serial_nos=["DV2026311"])]))
    session.flush()
    seed_demo_finance(session, principal, prj, po)
    seed_demo_costing(session, principal, prj, site)


def seed_demo_costing(session: Session, principal, prj, site) -> None:
    """Phase 6 sample: the store issues material from the site store to the ABC Hospital project (approved by the
    project manager), a little comes back, and a labour contractor's work is entered."""
    from sqlalchemy import update as sql_update

    from app.hr.models import Attendance

    # the demo site engineer's and technician's recent attendance was at this project's site
    session.execute(sql_update(Attendance).where(Attendance.project_id.is_(None), Attendance.source == "self")
                    .values(project_id=prj.id))
    from datetime import timedelta

    from app.costing import service as costing
    from app.costing.schemas import CostEntryIn, IssueIn, IssueLineIn
    from app.crm.service import today
    from app.inventory.models import StockBalance, StockSerial
    from app.platform.approvals import service as approvals

    users = {u.username: u for u in session.scalars(select(User))}
    store, pm = principal(users["store1"]), principal(users["pm1"])
    d0 = today()
    lines = []
    for bal in session.scalars(select(StockBalance).where(StockBalance.warehouse_id == site.id, StockBalance.quantity > 0)):
        item = session.get(Item, bal.item_id)
        qty = (bal.quantity / 2).quantize(Decimal("1")) or bal.quantity
        serials = [s.serial_no for s in session.scalars(select(StockSerial).where(
            StockSerial.item_id == item.id, StockSerial.warehouse_id == site.id, StockSerial.status == "in_stock"))][:int(qty)] \
            if item.serial_number_required else []
        lines.append(IssueLineIn(item_id=item.id, quantity=qty, serial_nos=serials))
    if not lines:
        return
    issue = costing.create_issue(session, store, IssueIn(project_id=prj.id, warehouse_id=site.id,
                                                         issue_date=d0 - timedelta(days=1), issued_to="Arjun Das (site)",
                                                         lines=lines, submit=True))
    req = approvals.pending_for(session, "material_issue", issue.id)
    if req is not None:
        approvals.decide(session, pm, req.id, "approved", None)
    plain = next((ln for ln in issue.lines if not ln.serial_nos), None)
    if plain is not None and plain.quantity >= 2:
        costing.create_issue(session, store, IssueIn(project_id=prj.id, warehouse_id=site.id, issue_date=d0,
                                                     notes="Unused after earthing work", lines=[
                                                         IssueLineIn(item_id=plain.item_id, quantity=Decimal("1"))]),
                             kind="return")
    costing.add_manual(session, pm, prj.id, CostEntryIn(
        cost_head="labour", cost_date=d0 - timedelta(days=1), amount=Decimal("18500"), quantity=Decimal("21"),
        unit="man-days", party="Sree Durga Labour Contractors", reference="MR-0917",
        description="Earthing and down-conductor labour, week of 21 Sep"))
    session.flush()


def seed_demo_finance(session: Session, principal, prj, po) -> None:
    """Phase 7 sample: the first running bill on the ABC Hospital order, part paid with TDS; DEHN's bill for what
    arrived, part paid; a paid travel claim and a site claim waiting for approval."""
    from datetime import timedelta

    from app.company.models import Company
    from app.core.india import gstin_check_char
    from app.crm.service import today
    from app.finance import expenses as ex
    from app.finance import invoices as fi
    from app.finance import payables as fp
    from app.finance import receipts as fr
    from app.finance.models import ExpenseCategory
    from app.finance.schemas import (
        AllocationIn,
        ExpenseIn,
        InvoiceIn,
        InvoiceLineIn,
        ReceiptIn,
        SupplierInvoiceIn,
        SupplierInvoiceLineIn,
        SupplierPaymentIn,
    )
    from app.platform.approvals import service as approvals
    from app.platform.documents import service as documents
    from app.sales.models import SalesOrder

    company = session.scalar(select(Company).where(Company.code == "TCE"))
    if not company.gstin:  # demo GSTIN (Kerala), so tax invoices can be issued
        company.gstin = "32AAAFT1234A1Z" + gstin_check_char("32AAAFT1234A1Z")
        company.pan = company.pan or "AAAFT1234A"
        company.address_line1 = company.address_line1 or "Round North"
        company.city, company.pincode = company.city or "Thrissur", company.pincode or "680001"
        company.bank_name = company.bank_name or "State Bank of India"
        company.ifsc = company.ifsc or "SBIN0000000"
    users = {u.username: u for u in session.scalars(select(User))}
    acc, mgr = principal(users["accounts1"]), principal(users["manager"])
    d0 = today()
    so = session.get(SalesOrder, prj.sales_order_id)
    lines = [InvoiceLineIn(so_item_id=it.id, section=it.section, item_id=it.item_id, description=it.description,
                           hsn_sac=it.hsn_sac, quantity=(it.quantity / 2).quantize(Decimal("1")) or it.quantity,
                           unit=it.unit, rate=it.rate, discount_pct=it.discount_pct, tax_rate=it.tax_rate)
             for it in so.items if it.item_id][:4]
    inv = fi.create(session, acc, InvoiceIn(sales_order_id=so.id, invoice_date=d0 - timedelta(days=3), bill_type="running",
                                            items=lines, retention_pct=Decimal("5")))
    fi.issue(session, acc, inv.id, None)
    paid = (inv.grand_total * Decimal("0.5")).quantize(Decimal("1"))
    tds = (inv.taxable * Decimal("0.02")).quantize(Decimal("0.01"))
    fr.create(session, acc, ReceiptIn(customer_id=inv.customer_id, receipt_date=d0, project_id=prj.id, mode="neft",
                                      reference_no="UTR SBIN2026100100421", amount=paid - tds, tds_amount=tds,
                                      allocations=[AllocationIn(document_id=inv.id, amount=paid - tds, tds=tds)]))
    bill_lines = [SupplierInvoiceLineIn(po_item_id=it.id, item_id=it.item_id, description=it.description,
                                        hsn_sac=it.hsn_sac, quantity=it.received_qty, unit=it.unit, rate=it.rate,
                                        discount_pct=it.discount_pct, tax_rate=it.tax_rate)
                  for it in po.items if it.received_qty > 0]
    bill = fp.create_bill(session, acc, SupplierInvoiceIn(
        supplier_id=po.supplier_id, supplier_invoice_no="DI/2627/08812", supplier_invoice_date=d0 - timedelta(days=2),
        purchase_order_id=po.id, items=bill_lines))
    fp.submit_bill(session, acc, bill.id, None)
    fp.create_payment(session, acc, SupplierPaymentIn(
        supplier_id=po.supplier_id, payment_date=d0, mode="neft", reference_no="UTR HDFC2026100100877",
        amount=Decimal("15000"), allocations=[AllocationIn(document_id=bill.id, amount=Decimal("15000"))]))
    cats = {c.name: c for c in session.scalars(select(ExpenseCategory))}
    eng = principal(users["engineer1"])
    trip = ex.create(session, eng, ExpenseIn(category_id=cats["Local conveyance / fuel"].id, project_id=prj.id,
                                             expense_date=d0 - timedelta(days=6), amount=Decimal("1240"),
                                             description="Fuel: Thrissur ↔ ABC Hospital site, 4 trips for earthing work"))
    ex.submit(session, eng, trip.id, None)
    for who in (mgr, acc):
        req = approvals.pending_for(session, "expense", trip.id)
        if req is not None:
            approvals.decide(session, who, req.id, "approved", None)
    from app.finance.schemas import ExpensePayIn

    ex.pay(session, acc, trip.id, ExpensePayIn(paid_at=d0, payment_mode="upi", payment_reference="UPI 627512004411"))
    food = ex.create(session, eng, ExpenseIn(category_id=cats["Food & lodging (site)"].id, project_id=prj.id,
                                             expense_date=d0 - timedelta(days=2), amount=Decimal("860"),
                                             description="Lunch for 4 technicians — LPS down conductor work"))
    documents.upload(session, entity_type="expense", entity_id=food.id, category="receipt",
                     file_name="hotel-bill.pdf", data=_tiny_pdf("Hotel Annapoorna — ₹860"), user_id=eng.id)
    ex.submit(session, eng, food.id, None)
    session.flush()


def _tiny_pdf(text: str) -> bytes:
    import io

    from reportlab.pdfgen import canvas

    buf = io.BytesIO()
    c = canvas.Canvas(buf)
    c.drawString(72, 720, text.encode("ascii", "replace").decode())
    c.save()
    return buf.getvalue()


def main(argv: list[str]) -> None:
    what = argv[1] if len(argv) > 1 else "core"
    if what == "demo" and get_settings().environment == "production":
        raise SystemExit("Refusing to load demo data into production.")
    with SessionLocal() as session:
        company = seed_core(session)
        if what == "demo":
            seed_demo(session, company)
        session.commit()
    print(f"Seed '{what}' complete.")


if __name__ == "__main__":
    main(sys.argv)
