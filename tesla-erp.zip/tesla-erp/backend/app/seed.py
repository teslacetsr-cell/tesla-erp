"""Seed data.

    python -m app.seed core   # every environment: company, numbering, roles/permissions, first admin
    python -m app.seed demo   # development/staging only: Spec §46 sample data + one user per role

Idempotent: safe to run repeatedly.
"""
import sys
from datetime import date
from decimal import Decimal
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.company.models import BusinessDivision, Company
from app.core.config import get_settings
from app.core.db import SessionLocal
from app.core.security import hash_password
from app.customers.models import Customer, CustomerContact, CustomerSite
from app.hr.models import Department, Designation, Employee
from app.platform.documents import service as documents
from app.platform.numbering.models import NumberingFormat
from app.platform.numbering.service import DEFAULT_FORMATS
from app.products.models import Brand, Item, ItemCategory, TaxRate, Unit, Warehouse
from app.suppliers.models import Supplier, SupplierContact
from app.users.bootstrap import sync_permissions
from app.users.models import Role, User, UserRole

LOGO = Path(__file__).parent / "assets" / "tce-logo.png"


def _get_or_create(session: Session, cls, lookup: dict, **values):
    obj = session.scalar(select(cls).filter_by(**lookup))
    if obj is None:
        obj = cls(**lookup, **values)
        session.add(obj)
        session.flush()
    return obj


def seed_core(session: Session) -> Company:
    s = get_settings()
    company = _get_or_create(
        session, Company, {"code": "TCE"},
        company_name="Tesla Consulting Engineers", legal_name="Tesla Consulting Engineers",
        tagline="Empowering Safety, Protecting Lives", state="Kerala", state_code="32", is_default=True,
    )
    for f in DEFAULT_FORMATS:
        _get_or_create(session, NumberingFormat, {"company_id": company.id, "doc_type": f["doc_type"]},
                       label=f["label"], pattern=f["pattern"], period=f["period"], max_length=f.get("max_length"))
    sync_permissions(session)
    admin = session.scalar(select(User).where(User.username == "admin"))
    if admin is None:
        admin = User(username="admin", email=s.seed_admin_email, full_name="System Administrator",
                     password_hash=hash_password(s.seed_admin_password), must_change_password=True)
        session.add(admin)
        session.flush()
        session.add(UserRole(user_id=admin.id, role_id=session.scalar(select(Role.id).where(Role.code == "ADMIN"))))
    seed_org_masters(session, company, admin.id)
    if company.logo_document_id is None and LOGO.exists():
        doc = documents.upload(session, entity_type="company", entity_id=company.id, category="logo",
                               file_name="tce-logo.png", data=LOGO.read_bytes(), user_id=admin.id)
        company.logo_document_id = doc.id
    session.flush()
    return company


DIVISIONS = [
    ("CONSULT", "Electrical Consultancy"), ("CONTRACT", "Electrical Contracting"),
    ("LPS", "Lightning Protection Systems"), ("SPS", "Surge Protection Systems"), ("SAFETY", "Electrical Safety"),
    ("SOLAR", "Solar EPC & Components"), ("EV", "EV Charging Infrastructure"),
    ("TEST", "Testing & Commissioning"), ("AMC", "Maintenance / AMC"),
]
DEPARTMENTS = [("MGMT", "Management"), ("SALES", "Sales"), ("PROJ", "Projects"), ("PUR", "Purchase"),
               ("STORE", "Stores"), ("ACC", "Accounts"), ("HR", "Human Resources"), ("SRV", "Service")]
DESIGNATIONS = ["Director", "Manager", "Sales Engineer", "Project Manager", "Site Engineer", "Purchase Executive",
                "Store Keeper", "Accountant", "HR Executive", "Technician"]


def seed_org_masters(session: Session, company: Company, user_id) -> None:
    """Starter divisions, departments and designations (Spec §7) — only into an EMPTY list, so a list the
    company has already edited is never touched. Without these, the employee form has nothing to pick."""
    by = {"created_by": user_id, "updated_by": user_id}
    if session.scalar(select(BusinessDivision.id).where(BusinessDivision.company_id == company.id).limit(1)) is None:
        for code, name in DIVISIONS:
            session.add(BusinessDivision(company_id=company.id, code=code, name=name, **by))
    if session.scalar(select(Department.id).limit(1)) is None:
        for code, name in DEPARTMENTS:
            session.add(Department(code=code, name=name, **by))
    if session.scalar(select(Designation.id).limit(1)) is None:
        for name in DESIGNATIONS:
            session.add(Designation(name=name, **by))
    session.flush()


DEMO_USERS = [
    ("director", "Director", "DIRECTOR"), ("manager", "Operations Manager", "MANAGER"),
    ("sales1", "Anil Kumar (Sales)", "SALES"), ("sales2", "Divya Menon (Sales)", "SALES"),
    ("pm1", "Rahul Nair (Project Manager)", "PROJECT_MANAGER"), ("engineer1", "Arjun Das (Site Engineer)", "SITE_ENGINEER"),
    ("purchase1", "Meera Thomas (Purchase)", "PURCHASE"), ("store1", "Suresh Babu (Store)", "STORE"),
    ("accounts1", "Lakshmi Iyer (Accounts)", "ACCOUNTS"), ("hr1", "Nisha Varghese (HR)", "HR"),
    ("employee1", "Vishnu Prasad (Employee)", "EMPLOYEE"),
]
DEMO_PASSWORD = "Tesla@Demo2026"

CATEGORIES = [
    ("LP", "Lightning Protection"), ("SPD", "Surge Protection"), ("EARTH", "Earthing"), ("ELEC", "Electrical"),
    ("SOLAR", "Solar"), ("EV", "EV Charging"), ("CABLE", "Cable"), ("PANEL", "Panel"), ("SWG", "Switchgear"),
    ("PPE", "PPE"), ("TOOLS", "Tools"), ("CONS", "Consumables"), ("SVC", "Services"),
]
def seed_demo(session: Session, company: Company) -> None:
    admin = session.scalar(select(User).where(User.username == "admin"))
    by = {"created_by": admin.id, "updated_by": admin.id}
    roles = {r.code: r for r in session.scalars(select(Role))}
    users = {}
    for username, name, role in DEMO_USERS:
        u = session.scalar(select(User).where(User.username == username))
        if u is None:
            u = User(username=username, email=f"{username}@teslace-demo.in", full_name=name,
                     password_hash=hash_password(DEMO_PASSWORD), must_change_password=False, **by)
            session.add(u)
            session.flush()
            session.add(UserRole(user_id=u.id, role_id=roles[role].id))
        users[username] = u

    for code, name in DIVISIONS:
        _get_or_create(session, BusinessDivision, {"company_id": company.id, "code": code}, name=name, **by)
    depts = {}
    for code, name in DEPARTMENTS:
        depts[code] = _get_or_create(session, Department, {"code": code}, name=name, **by)
    desig = {}
    for name in DESIGNATIONS:
        desig[name] = _get_or_create(session, Designation, {"name": name}, **by)
    for i, (username, dept, d) in enumerate([
        ("director", "MGMT", "Director"), ("manager", "MGMT", "Manager"), ("sales1", "SALES", "Sales Engineer"),
        ("sales2", "SALES", "Sales Engineer"), ("pm1", "PROJ", "Project Manager"),
        ("engineer1", "PROJ", "Site Engineer"), ("purchase1", "PUR", "Purchase Executive"),
        ("store1", "STORE", "Store Keeper"), ("accounts1", "ACC", "Accountant"), ("hr1", "HR", "HR Executive"),
        ("employee1", "SRV", "Technician"),
    ], start=1):
        u = users[username]
        _get_or_create(session, Employee, {"employee_code": f"TCE{i:04d}"}, full_name=u.full_name.split(" (")[0],
                       email=u.email, department_id=depts[dept].id, designation_id=desig[d].id, user_id=u.id,
                       date_of_joining=date(2024, 4, 1), **by)

    cats = {code: _get_or_create(session, ItemCategory, {"code": code}, name=name, **by) for code, name in CATEGORIES}
    units = {}
    for code, name, dec in [("NOS", "Numbers", 0), ("SET", "Set", 0), ("M", "Metre", 2), ("KG", "Kilogram", 3),
                            ("LOT", "Lot", 0), ("JOB", "Job", 0)]:
        units[code] = _get_or_create(session, Unit, {"code": code}, name=name, decimals=dec, **by)
    _get_or_create(session, Unit, {"code": "ROLL50"}, name="Roll (50 m)", decimals=0, base_unit_id=units["M"].id,
                   factor=Decimal("50"), **by)
    taxes = {}
    for rate in (0, 5, 12, 18, 28):
        taxes[rate] = _get_or_create(session, TaxRate, {"code": f"GST{rate}"}, name=f"GST {rate}%",
                                     rate=Decimal(rate), effective_from=date(2017, 7, 1), **by)
    brands = {n: _get_or_create(session, Brand, {"name": n}, **by) for n in ["DEHN", "Generic", "Waaree", "Delta"]}
    _get_or_create(session, Warehouse, {"company_id": company.id, "code": "MAIN"}, name="Main Store — Thrissur",
                   warehouse_type="main", in_charge_id=users["store1"].id, **by)

    items = [
        ("DEHN-SPD-T12", "DEHN SPD Type 1+2, 3+NPE", "SPD", "DEHN", "DV M TNC 255", "NOS", "85363000", 18, 14200, 16000, True),
        ("LP-AT-16", "Air Terminal, copper, 16 mm × 1 m", "LP", "DEHN", "AT-16", "NOS", "85359090", 18, 1850, 2400, False),
        ("LP-CT-25X3", "Copper Tape 25 × 3 mm", "LP", "Generic", None, "M", "74072990", 18, 620, 780, False),
        ("EA-GI-50X6", "GI Strip 50 × 6 mm", "EARTH", "Generic", None, "M", "72125090", 18, 160, 210, False),
        ("EA-ELEC-3M", "Earth Electrode, copper-bonded, 17.2 mm × 3 m", "EARTH", "Generic", "CBE-3000", "NOS", "85469090", 18, 2900, 3600, False),
        ("SOL-MOD-545", "Solar Module 545 Wp mono PERC", "SOLAR", "Waaree", "WSMDi-545", "NOS", "85414300", 12, 13200, 15500, True),
        ("SOL-INV-10K", "Solar Inverter 10 kW on-grid, 3-phase", "SOLAR", "Delta", "RPI M10A", "NOS", "85044010", 12, 98000, 112000, True),
        ("EV-AC-7K", "EV Charger 7.4 kW AC wallbox", "EV", "Delta", "AC Mini Plus", "NOS", "85044090", 18, 42000, 52000, True),
    ]
    for code, name, cat, brand, model, unit, hsn, gst, pp, sp, serial in items:
        _get_or_create(session, Item, {"item_code": code}, item_name=name, item_type="goods",
                       category_id=cats[cat].id, brand_id=brands[brand].id, model=model, unit_id=units[unit].id,
                       hsn_sac=hsn, tax_rate_id=taxes[gst].id, purchase_price=Decimal(pp), selling_price=Decimal(sp),
                       minimum_stock=Decimal(5 if unit == "NOS" else 50), reorder_level=Decimal(10 if unit == "NOS" else 100),
                       serial_number_required=serial, **by)
    _get_or_create(session, Item, {"item_code": "SVC-LPS-INST"}, item_name="LPS installation & commissioning",
                   item_type="service", category_id=cats["SVC"].id, unit_id=units["JOB"].id, hsn_sac="995461",
                   tax_rate_id=taxes[18].id, **by)

    abc = _get_or_create(
        session, Customer, {"customer_code": "CUS00001"}, customer_name="ABC Hospital", customer_type="hospital",
        company_name="ABC Healthcare Pvt Ltd", phone="0487 2330000", email="facilities@abchospital-demo.in",
        address_line1="East Fort", city="Thrissur", district="Thrissur", state="Kerala", state_code="32",
        pincode="680005", default_payment_terms="50% advance, balance against delivery", credit_limit=Decimal("1000000"),
        credit_days=30, assigned_sales_person_id=users["sales1"].id, **by)
    if not abc.contacts:
        session.add(CustomerContact(customer_id=abc.id, name="Mr. Joseph Mathew", designation="Facilities Manager",
                                    phone="98470 00000", email="joseph@abchospital-demo.in", is_primary=True, **by))
        session.add(CustomerSite(customer_id=abc.id, site_name="ABC Hospital — Main Block", address_line1="East Fort",
                                 city="Thrissur", state="Kerala", state_code="32", pincode="680005",
                                 contact_name="Mr. Joseph Mathew", contact_phone="98470 00000", **by))
    dehn = _get_or_create(
        session, Supplier, {"supplier_code": "SUP00001"}, supplier_name="DEHN India Pvt Ltd",
        supplies="Lightning & surge protection, earthing", city="Bengaluru", state="Karnataka", state_code="29",
        payment_terms="30 days from invoice", credit_days=30, rating=Decimal("4.5"), **by)
    if not dehn.contacts:
        session.add(SupplierContact(supplier_id=dehn.id, name="Sales Desk", phone="080 0000 0000",
                                    email="sales@dehn-demo.in", is_primary=True, **by))
    # Keep auto-numbering ahead of the hand-seeded codes.
    from sqlalchemy import text as sql

    for doc_type, used in (("CUSTOMER", 1), ("SUPPLIER", 1), ("EMPLOYEE", len(DEMO_USERS))):
        session.execute(sql("""
            INSERT INTO document_sequences (id, company_id, doc_type, period_key, last_value)
            VALUES (gen_random_uuid(), :c, :t, '-', :v)
            ON CONFLICT (company_id, doc_type, period_key)
            DO UPDATE SET last_value = GREATEST(document_sequences.last_value, EXCLUDED.last_value)
        """), {"c": company.id, "t": doc_type, "v": used})
    session.flush()
    seed_demo_crm(session, company, users, abc)
    # The sample project "ABC Hospital Lightning Protection Project" is seeded in Phase 4 with the projects module.


def seed_demo_crm(session: Session, company: Company, users: dict, abc: Customer) -> None:
    """Phase 2 sample pipeline: the ABC Hospital lead taken through enquiry and a completed site visit, plus
    prospects at earlier stages. Loaded once (skipped when any lead exists)."""
    from datetime import datetime, time, timedelta
    from zoneinfo import ZoneInfo

    from app.crm.models import CrmActivity, Enquiry, Lead, SiteVisit
    from app.platform.numbering.service import next_number

    if session.scalar(select(Lead.id).limit(1)) is not None:
        return
    ist = ZoneInfo("Asia/Kolkata")
    today = datetime.now(ist).date()
    s1, s2, eng = users["sales1"], users["sales2"], users["engineer1"]
    lps = session.scalar(select(BusinessDivision).where(BusinessDivision.code == "LPS"))
    solar = session.scalar(select(BusinessDivision).where(BusinessDivision.code == "SOLAR"))
    ev = session.scalar(select(BusinessDivision).where(BusinessDivision.code == "EV"))
    site = session.scalar(select(CustomerSite).where(CustomerSite.customer_id == abc.id).limit(1))

    def lead(**kw) -> Lead:
        obj = Lead(lead_number=next_number(session, company.id, "LEAD", on=today), created_by=kw["sales_person_id"],
                   updated_by=kw["sales_person_id"], status_changed_at=datetime.now(ist), **kw)
        session.add(obj)
        session.flush()
        return obj

    l1 = lead(title="Lightning protection for ABC Hospital main block", customer_id=abc.id, source="existing_customer",
              division_id=lps.id if lps else None, requirement="External LPS to IS/IEC 62305 for the 6-storey main "
              "block, with SPDs on the main LT panel.", estimated_value=Decimal("550000"), probability=60,
              expected_closing_date=today + timedelta(days=30), sales_person_id=s1.id, status="site_visit")
    enq = Enquiry(enquiry_number=next_number(session, company.id, "ENQ", on=today), lead_id=l1.id, customer_id=abc.id,
                  site_id=site.id if site else None, division_id=l1.division_id, subject=l1.title,
                  description=l1.requirement, enquiry_date=today, required_by=today + timedelta(days=45),
                  source="existing_customer", priority="high", estimated_value=Decimal("550000"),
                  sales_person_id=s1.id, status="evaluation", status_changed_at=datetime.now(ist),
                  created_by=s1.id, updated_by=s1.id)
    session.add(enq)
    session.flush()
    session.add(SiteVisit(
        visit_number=next_number(session, company.id, "SV", on=today), enquiry_id=enq.id, lead_id=l1.id,
        customer_id=abc.id, site_id=site.id if site else None, site_location="ABC Hospital — Main Block, East Fort, Thrissur",
        visit_date=today - timedelta(days=1), visit_time=time(10, 30), engineer_id=eng.id, status="completed",
        purpose="Survey for external lightning protection and surge protection",
        observations="Roof area approx. 1,200 m² with water tanks and a lift machine room. No existing air "
                     "terminals. Existing earth pits near the DG room are dry and corroded.",
        requirements="Complete external LPS, 4 down conductors, test joints, new earth pits; Type 1+2 SPD on main LT panel.",
        measurements=[{"label": "Building height", "value": "22", "unit": "m"},
                      {"label": "Roof area", "value": "1200", "unit": "m²"},
                      {"label": "Earth pit 1 resistance", "value": "8.4", "unit": "Ω"},
                      {"label": "Earth pit 2 resistance", "value": "11.2", "unit": "Ω"}],
        recommendations="Class III LPS with mesh 15 m × 15 m. Replace both earth pits with copper-bonded electrodes "
                        "(target below 1 Ω combined). Install DEHN Type 1+2 SPD at the main LT panel.",
        customer_rep_name="Mr. Joseph Mathew", customer_rep_designation="Facilities Manager",
        customer_rep_phone="98470 00000", follow_up_date=today + timedelta(days=2),
        completed_at=datetime.now(ist), created_by=s1.id, updated_by=eng.id))
    session.add(CrmActivity(enquiry_id=enq.id, kind="follow_up", subject="Send LPS proposal and BOQ to Mr. Joseph",
                            activity_at=datetime.now(ist), due_at=datetime.combine(today + timedelta(days=2), time(10, 0), ist),
                            assigned_to_id=s1.id, created_by=s1.id, updated_by=s1.id))

    l2 = lead(title="50 kW rooftop solar — St. Mary's School", company_name="St. Mary's Higher Secondary School",
              contact_name="Fr. Thomas Kurian", contact_phone="94470 11111", city="Irinjalakuda", source="referral",
              division_id=solar.id if solar else None, requirement="On-grid rooftop solar on the school block, net metering.",
              estimated_value=Decimal("2400000"), probability=30, expected_closing_date=today + timedelta(days=60),
              sales_person_id=s2.id, status="contacted")
    session.add(CrmActivity(lead_id=l2.id, kind="call", subject="Intro call — interested, wants a site survey",
                            activity_at=datetime.now(ist) - timedelta(days=1), created_by=s2.id, updated_by=s2.id))
    session.add(CrmActivity(lead_id=l2.id, kind="follow_up", subject="Call Fr. Thomas to fix a survey date",
                            activity_at=datetime.now(ist), due_at=datetime.combine(today, time(15, 0), ist),
                            assigned_to_id=s2.id, created_by=s2.id, updated_by=s2.id))
    lead(title="EV chargers for mall parking", company_name="Sobha City Mall", contact_name="Facilities Desk",
         contact_phone="0487 2440000", city="Thrissur", source="website", division_id=ev.id if ev else None,
         requirement="6 × 7.4 kW AC chargers for visitor parking.", estimated_value=Decimal("360000"),
         sales_person_id=s1.id, status="new")
    lost = lead(title="Earthing audit — textile unit", company_name="Kairali Textiles", contact_name="Mr. Anand",
                contact_phone="94000 22222", city="Palakkad", source="phone", sales_person_id=s2.id, status="lost",
                estimated_value=Decimal("45000"))
    lost.lost_reason = "Went with a local contractor on price"
    session.flush()


def main(argv: list[str]) -> None:
    what = argv[1] if len(argv) > 1 else "core"
    if what == "demo" and get_settings().environment == "production":
        raise SystemExit("Refusing to load demo data into production.")
    with SessionLocal() as session:
        company = seed_core(session)
        if what == "demo":
            seed_demo(session, company)
        session.commit()
    print(f"Seed '{what}' complete.")


if __name__ == "__main__":
    main(sys.argv)
