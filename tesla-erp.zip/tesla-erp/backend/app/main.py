"""FastAPI application factory."""
import ipaddress
import logging
import time
import uuid
from pathlib import Path

from fastapi import APIRouter, FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from sqlalchemy import text

from app.core.config import get_settings
from app.core.context import RequestContext, request_ctx
from app.core.db import engine
from app.core.errors import install_error_handlers

log = logging.getLogger("app")

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'",
    # geolocation=(self): site visits may record the phone's GPS position (Phase 2). Photos use the file picker,
    # which the camera policy does not affect.
    "Permissions-Policy": "camera=(), microphone=(), geolocation=(self)",
    "Cache-Control": "no-store",
}


# The web UI (served by this process on-premise) needs scripts/styles from itself; Next.js emits inline bootstrap
# scripts, hence 'unsafe-inline'. Everything else stays locked to the same origin.
UI_CSP = ("default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
          "img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; "
          "base-uri 'self'; form-action 'self'")


def _valid_ip(value: str | None) -> str | None:
    try:
        return str(ipaddress.ip_address(value)) if value else None
    except ValueError:
        return None


def create_app() -> FastAPI:
    settings = get_settings()
    is_prod = settings.environment == "production"
    app = FastAPI(
        title=settings.app_name,
        version="0.1.0",
        docs_url=None if is_prod else "/api/docs",
        redoc_url=None,
        openapi_url=None if is_prod else "/api/openapi.json",
    )
    install_error_handlers(app)

    @app.middleware("http")
    async def context_and_headers(request: Request, call_next):
        rid = request.headers.get("x-request-id", "")[:32] or uuid.uuid4().hex[:16]
        ip = request.client.host if request.client else None
        # Trust forwarding headers only from our own proxy: the cloud load balancer, or on-premise the
        # Cloudflare Tunnel connector, which runs on the server itself and so connects from localhost.
        if settings.trust_proxy_headers or (settings.deployment == "onprem" and ip in ("127.0.0.1", "::1")):
            ip = (request.headers.get("cf-connecting-ip")
                  or request.headers.get("x-forwarded-for", "").split(",")[0].strip() or ip)
        ip = _valid_ip(ip)
        token = request_ctx.set(RequestContext(request_id=rid, ip=ip, user_agent=request.headers.get("user-agent")))
        started = time.perf_counter()
        try:
            response = await call_next(request)
        finally:
            request_ctx.reset(token)
        response.headers["X-Request-ID"] = rid
        path = request.url.path
        is_ui = settings.frontend_dir is not None and not path.startswith(("/api/", "/healthz", "/readyz"))
        for k, v in SECURITY_HEADERS.items():
            if k == "Content-Security-Policy" and (path.startswith("/api/docs") or is_ui):
                continue
            if k == "Cache-Control" and is_ui:
                continue
            response.headers.setdefault(k, v)
        if is_ui:
            response.headers.setdefault("Content-Security-Policy", UI_CSP)
            response.headers.setdefault(
                "Cache-Control", "public, max-age=31536000, immutable" if path.startswith("/_next/static/") else "no-cache")
        if settings.cookie_secure:
            response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
        log.info("%s %s %s %.0fms", request.method, request.url.path, response.status_code,
                 (time.perf_counter() - started) * 1000)
        return response

    from app import registry  # noqa: F401 - every module's permission codes must be registered in the API process
    from app.auth.router import router as auth_router
    from app.boq.router import router as boq_router
    from app.company.router import router as company_router
    from app.costing.router import router as costing_router
    from app.crm.router import router as crm_router
    from app.customers.router import router as customers_router
    from app.finance.router import router as finance_router
    from app.hr.router import router as hr_router
    from app.hr.router_p8 import router as hr_p8_router
    from app.inventory.router import router as inventory_router
    from app.platform.approvals.router import router as approvals_router
    from app.platform.notifications.router import router as notifications_router
    from app.platform.router import router as platform_router
    from app.products.router import router as products_router
    from app.projects.router import router as projects_router
    from app.purchase.router import router as purchase_router
    from app.quotations.router import router as quotations_router
    from app.sales.router import router as sales_router
    from app.suppliers.router import router as suppliers_router
    from app.users.router import router as users_router

    api = APIRouter(prefix="/api/v1")
    for r in (auth_router, users_router, company_router, hr_p8_router, hr_router, customers_router, suppliers_router,
              products_router, crm_router, boq_router, sales_router, quotations_router, projects_router,
              inventory_router, purchase_router, costing_router, finance_router, approvals_router, notifications_router, platform_router):
        api.include_router(r)
    app.include_router(api)

    @app.get("/healthz", include_in_schema=False)
    def healthz():
        return {"status": "ok"}

    @app.get("/readyz", include_in_schema=False)
    def readyz():
        with engine.connect() as c:
            c.execute(text("select 1"))
        return {"status": "ready"}

    if settings.frontend_dir:
        _mount_frontend(app, Path(settings.frontend_dir))
    return app


def _mount_frontend(app: FastAPI, root: Path) -> None:
    """Serve the statically exported web UI (Next.js `output: export`, trailing slashes) from this process."""
    root = root.resolve()
    if not (root / "index.html").exists():
        raise RuntimeError(f"FRONTEND_DIR {root} does not contain a built web UI (index.html missing)")

    # HEAD too: the browser's router probes pages with HEAD requests before prefetching them.
    @app.api_route("/{path:path}", methods=["GET", "HEAD"], include_in_schema=False)
    def ui(path: str):
        if path.startswith("api/"):
            return JSONResponse(status_code=404, content={"error": {"code": "NOT_FOUND", "message": "Not found."}})
        target = (root / path).resolve()
        if root != target and root not in target.parents:
            return FileResponse(root / "404.html", status_code=404)
        if target.is_file():
            return FileResponse(target)
        if (target / "index.html").is_file():
            return FileResponse(target / "index.html")
        if target.with_suffix(".html").is_file():
            return FileResponse(target.with_suffix(".html"))
        return FileResponse(root / "404.html", status_code=404) if (root / "404.html").exists() else \
            JSONResponse(status_code=404, content={"error": {"code": "NOT_FOUND", "message": "Not found."}})


app = create_app()
