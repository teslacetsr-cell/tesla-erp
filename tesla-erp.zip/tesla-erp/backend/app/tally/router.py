"""Tally sync API.

* ``/tally-agent/*`` — the connector on the Tally PC (docs/TALLY_CONNECTOR.md §2). Authenticated by a connector key
  (``Authorization: Bearer tck_…``, stored hashed), never by a user session.
* ``/tally/*`` — the Finance → Tally Sync screen (permissions ``tally.read`` / ``tally.update``).
"""
import threading
import time
import uuid
from collections import defaultdict, deque
from datetime import date
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Query, Request
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import or_, select

from app.auth.deps import Principal, require
from app.core.api import ListParams, Schema, ok, paginate
from app.core.context import request_ctx
from app.core.db import DbSession
from app.core.errors import AppError, NotFound, Unauthorized
from app.tally import service as svc
from app.tally.models import TallyConnectorKey, TallyJob

router = APIRouter(tags=["tally"])

# ============================================================================================ agent auth + throttle
_lock = threading.Lock()
_hits: dict[str, deque] = defaultdict(deque)
KEY_LIMIT_PER_MINUTE = 600      # a healthy connector makes a few calls a minute; a backlog drain ~ 2 per job
BAD_KEY_LIMIT_PER_MINUTE = 30


def _throttle(bucket: str, limit: int) -> None:
    now = time.monotonic()
    with _lock:
        q = _hits[bucket]
        while q and now - q[0] > 60:
            q.popleft()
        if len(q) >= limit:
            raise AppError("RATE_LIMITED", "Too many requests from the connector; slow down.", status_code=429)
        q.append(now)


def connector_key(request: Request, db: DbSession) -> TallyConnectorKey:
    ip = request_ctx.get().ip or (request.client.host if request.client else "?")
    header = request.headers.get("authorization", "")
    key = header[7:].strip() if header.lower().startswith("bearer ") else ""
    k = svc.authenticate(db, key) if key else None
    if k is None:
        _throttle(f"bad:{ip}", BAD_KEY_LIMIT_PER_MINUTE)
        raise Unauthorized("Unknown or revoked connector key. Create a new key in Finance → Tally Sync.",
                           code="BAD_CONNECTOR_KEY")
    _throttle(f"key:{k.id}", KEY_LIMIT_PER_MINUTE)
    k.last_seen_at, k.last_ip = svc.utcnow(), ip
    return k


Agent = Annotated[TallyConnectorKey, Depends(connector_key)]


class _AgentBody(BaseModel):
    model_config = ConfigDict(extra="ignore")


class HeartbeatIn(_AgentBody):
    agent_version: str | None = Field(default=None, max_length=100)
    host: str | None = Field(default=None, max_length=200)
    tally_url: str | None = Field(default=None, max_length=300)
    tally_ok: bool | None = None
    tally_error: str | None = Field(default=None, max_length=2000)
    tally_company: str | None = Field(default=None, max_length=300)
    tally_version: str | None = Field(default=None, max_length=200)


class LeaseIn(_AgentBody):
    limit: int = Field(default=20, ge=1, le=200)


class ResultIn(_AgentBody):
    ok: bool
    status_code: int | None = None
    response: str | None = None
    error: str | None = Field(default=None, max_length=5000)
    elapsed_ms: int | None = Field(default=None, ge=0)


@router.post("/tally-agent/heartbeat")
def agent_heartbeat(body: HeartbeatIn, k: Agent, db: DbSession):
    return ok(svc.heartbeat(db, k, body, k.last_ip))


@router.post("/tally-agent/jobs/lease")
def agent_lease(body: LeaseIn, k: Agent, db: DbSession):
    st = svc.find_settings(db)
    if st is None or not st.enabled:
        return ok([])
    return ok(svc.lease(db, k, body.limit))


@router.post("/tally-agent/jobs/{job_id}/result")
def agent_result(job_id: str, body: ResultIn, k: Agent, db: DbSession):
    try:
        jid = uuid.UUID(job_id)
    except ValueError as exc:
        raise NotFound("job") from exc
    return ok(svc.record_result(db, k, jid, body))


# ============================================================================================ screen API
class SettingsIn(Schema):
    enabled: bool
    poll_seconds: int = Field(ge=30, le=3600)
    tally_company: str | None = Field(default=None, max_length=200)
    start_date: date | None = None
    voucher_types: dict[str, Literal["erp", "tally"]] = {}
    create_party_ledgers: bool = True
    row_version: int | None = None


class KeyIn(Schema):
    name: str = Field(min_length=2, max_length=80)


class MapItem(Schema):
    kind: Literal["account", "gst", "customer", "supplier", "project"]
    erp_key: str = Field(min_length=1, max_length=80)
    tally_name: str | None = Field(default=None, max_length=200)


class MappingIn(Schema):
    items: list[MapItem] = Field(max_length=2000)


class BackfillIn(Schema):
    from_date: date | None = None


class SkipIn(Schema):
    reason: str = Field(min_length=3, max_length=300)


@router.get("/tally/status")
def tally_status(db: DbSession, p: Principal = require("tally.read")):
    return ok(svc.status(db, p))


@router.put("/tally/settings")
def tally_settings(body: SettingsIn, db: DbSession, p: Principal = require("tally.update")):
    return ok(svc.settings_out(svc.update_settings(db, p, body)))


@router.post("/tally/keys")
def tally_create_key(body: KeyIn, db: DbSession, p: Principal = require("tally.update")):
    k, key = svc.create_key(db, p, body.name)
    return ok({**svc.key_out(k), "key": key})


@router.post("/tally/keys/{key_id}/revoke")
def tally_revoke_key(key_id: uuid.UUID, db: DbSession, p: Principal = require("tally.update")):
    return ok(svc.key_out(svc.revoke_key(db, p, key_id)))


@router.get("/tally/mapping")
def tally_mapping(db: DbSession, p: Principal = require("tally.read")):
    return ok(svc.mapping_out(db))


@router.put("/tally/mapping")
def tally_save_mapping(body: MappingIn, db: DbSession, p: Principal = require("tally.update")):
    changed = svc.save_mapping(db, p, body.items)
    return ok({"changed": changed, **svc.mapping_out(db)})


@router.post("/tally/ledgers/push")
def tally_push_ledgers(db: DbSession, p: Principal = require("tally.update")):
    return ok(svc.job_out(svc.queue_account_ledgers(db, p)))


@router.post("/tally/backfill")
def tally_backfill(body: BackfillIn, db: DbSession, p: Principal = require("tally.update")):
    return ok(svc.backfill(db, p, body.from_date))


@router.get("/tally/jobs")
def tally_jobs(db: DbSession, params: Annotated[ListParams, Depends()], p: Principal = require("tally.read"),
               status: Annotated[str | None, Query(max_length=20)] = None,
               entity_type: Annotated[str | None, Query(max_length=40)] = None,
               entity_id: uuid.UUID | None = None):
    stmt = select(TallyJob)
    if status == "open":
        stmt = stmt.where(TallyJob.status.in_(("pending", "leased")))
    elif status:
        stmt = stmt.where(TallyJob.status == status)
    if entity_type:
        stmt = stmt.where(TallyJob.entity_type == entity_type)
    if entity_id:
        stmt = stmt.where(TallyJob.entity_id == entity_id)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(TallyJob.label.ilike(like), TallyJob.doc_number.ilike(like),
                              TallyJob.last_error.ilike(like)))
    rows, meta = paginate(db, stmt, params, default_sort=TallyJob.seq.desc(),
                          sortable={"seq": TallyJob.seq, "doc_date": TallyJob.doc_date, "status": TallyJob.status,
                                    "updated_at": TallyJob.updated_at})
    deps = svc.waiting_labels(db, rows)
    return {"data": [svc.job_out(j, deps) for j in rows], "meta": meta.model_dump()}


@router.get("/tally/jobs/{job_id}")
def tally_job(job_id: uuid.UUID, db: DbSession, p: Principal = require("tally.read")):
    j = db.get(TallyJob, job_id)
    if j is None:
        raise NotFound("job")
    return ok(svc.job_out(j, svc.waiting_labels(db, [j]), full=True))


@router.post("/tally/jobs/retry-failed")
def tally_retry_failed(db: DbSession, p: Principal = require("tally.update")):
    return ok(svc.retry_failed(db, p))


@router.post("/tally/jobs/{job_id}/retry")
def tally_retry(job_id: uuid.UUID, db: DbSession, p: Principal = require("tally.update")):
    return ok(svc.job_out(svc.retry(db, p, job_id)))


@router.post("/tally/jobs/{job_id}/skip")
def tally_skip(job_id: uuid.UUID, body: SkipIn, db: DbSession, p: Principal = require("tally.update")):
    return ok(svc.job_out(svc.skip(db, p, job_id, body.reason)))


@router.get("/tally/doc-status")
def tally_doc_status(entity_type: Annotated[str, Query(max_length=40)], entity_id: uuid.UUID, db: DbSession,
                     p: Principal = require("tally.read")):
    return ok(svc.doc_status(db, entity_type, entity_id))


@router.post("/tally/reconciliations")
def tally_reconcile(db: DbSession, p: Principal = require("tally.update")):
    return ok(svc.reconciliation_out(svc.request_reconciliation(db, p)))


@router.get("/tally/reconciliations/latest")
def tally_latest_reconciliation(db: DbSession, p: Principal = require("tally.read")):
    return ok(svc.reconciliation_out(svc.latest_reconciliation(db)))
