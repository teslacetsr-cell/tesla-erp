from app.core.permissions import register

register("tally", "Tally sync: connector keys, settings, ledger mapping, queue and retry, reconciliation",
         ("read", "update"))
