"""ERP documents → Tally vouchers and ledger masters, through the ledger mapping.

The amounts are exactly those the document posted to the ERP journal (see app/finance/*), so the books on both sides
agree. Differences from the ERP journal, by design:
* the ERP's single *Sundry Debtors* / *Sundry Creditors* control ledgers become one Tally ledger per party, with
  bill-wise allocations (New Ref = the invoice / supplier bill number, Agst Ref when money settles it);
* GST can go to one ledger per rate when the mapping says so (e.g. "Output CGST 9%").
"""
from __future__ import annotations

import uuid
from collections import defaultdict
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.india import GST_STATE_CODES
from app.customers.models import Customer
from app.finance.models import (
    CreditNote,
    ExpenseCategory,
    ExpenseClaim,
    Invoice,
    LedgerAccount,
    Receipt,
    SupplierInvoice,
    SupplierPayment,
)
from app.hr.models import Employee
from app.suppliers.models import Supplier
from app.tally import xml as X
from app.tally.models import TallyLedgerMap

Z = Decimal("0")

# settings key -> (Tally voucher type, plain label)
VOUCHER_TYPES: dict[str, tuple[str, str]] = {
    "sales": ("Sales", "Sales invoices"),
    "credit_note": ("Credit Note", "Credit notes"),
    "receipt": ("Receipt", "Money received from customers"),
    "purchase": ("Purchase", "Supplier bills"),
    "payment": ("Payment", "Payments to suppliers"),
    "expense": ("Journal", "Expense claims (approved → Journal, paid → Payment)"),
}
# ERP document type -> settings key
ENTITY_VTYPE = {"invoice": "sales", "credit_note": "credit_note", "receipt": "receipt",
                "supplier_invoice": "purchase", "supplier_payment": "payment", "expense": "expense",
                "expense_payment": "expense"}
ENTITY_TALLY_TYPE = {"invoice": "Sales", "credit_note": "Credit Note", "receipt": "Receipt",
                     "supplier_invoice": "Purchase", "supplier_payment": "Payment", "expense": "Journal",
                     "expense_payment": "Payment"}
ENTITY_LABEL = {"invoice": "Sales", "credit_note": "Credit note", "receipt": "Receipt",
                "supplier_invoice": "Purchase bill", "supplier_payment": "Supplier payment",
                "expense": "Expense", "expense_payment": "Expense payment"}
# Control ledgers replaced by party ledgers in Tally
PARTY_CONTROL_KEYS = ("debtors", "creditors")
GST_KEYS = {"output_cgst": "Central Tax", "output_sgst": "State Tax", "output_igst": "Integrated Tax",
            "input_cgst": "Central Tax", "input_sgst": "State Tax", "input_igst": "Integrated Tax"}
DEFAULT_GROUP = {"asset": "Current Assets", "liability": "Current Liabilities", "income": "Indirect Incomes",
                 "expense": "Indirect Expenses", "equity": "Capital Account"}


def remote_id(entity_type: str, entity_id: uuid.UUID) -> str:
    return f"erp-{entity_type}-{entity_id}"


def rate_key(rate: Decimal) -> str:
    return f"{Decimal(rate).normalize():f}"


class BuildError(Exception):
    """The document cannot be turned into a Tally voucher (plain message for the Tally Sync screen)."""


class Mapper:
    """ERP → Tally names. Without an override the ERP name is used."""

    def __init__(self, db: Session):
        self.db = db
        self.over = {(m.kind, m.erp_key): m.tally_name for m in db.scalars(select(TallyLedgerMap))}
        self.accounts = {a.id: a for a in db.scalars(select(LedgerAccount))}
        self.by_key = {a.system_key: a for a in self.accounts.values() if a.system_key}

    def account(self, account_id: uuid.UUID) -> str:
        a = self.accounts.get(account_id)
        if a is None:
            raise BuildError("A ledger used by this document no longer exists.")
        return self.over.get(("account", str(a.id))) or a.name

    def system(self, key: str) -> str:
        a = self.by_key.get(key)
        if a is None:
            raise BuildError(f"The '{key}' ledger is missing in the ERP.")
        return self.account(a.id)

    def gst(self, key: str, rate: Decimal | None) -> str:
        if rate is not None:
            name = self.over.get(("gst", f"{key}@{rate_key(rate)}"))
            if name:
                return name
        return self.system(key)

    def customer(self, c: Customer) -> str:
        return self.over.get(("customer", str(c.id))) or c.customer_name

    def supplier(self, s: Supplier) -> str:
        return self.over.get(("supplier", str(s.id))) or s.supplier_name

    def cost_centre(self, project_id: uuid.UUID | None) -> str | None:
        return self.over.get(("project", str(project_id))) if project_id else None


# ---------------------------------------------------------------------------------------------- helpers
def _split_by_rate(items, comp: str, header: Decimal) -> dict[Decimal | None, Decimal]:
    """GST of one kind (cgst/sgst/igst) per total-GST rate from the lines, corrected so it adds up to the header."""
    buckets: dict[Decimal | None, Decimal] = defaultdict(lambda: Z)
    for it in items:
        v = getattr(it, comp) or Z
        if v:
            buckets[Decimal(it.tax_rate)] += v
    diff = Decimal(header) - sum(buckets.values(), Z)
    if diff:
        if buckets:
            biggest = max(buckets, key=lambda k: buckets[k])
            buckets[biggest] += diff
        else:
            buckets[None] += diff
    return {k: v for k, v in buckets.items() if v}


def _share(amount: Decimal, weights: dict[Decimal | None, Decimal]) -> dict[Decimal | None, Decimal]:
    """Split ``amount`` in proportion to ``weights`` (credit note GST in the invoice's own proportion)."""
    total = sum(weights.values(), Z)
    if not amount:
        return {}
    if not total:
        return {None: amount}
    out = {k: (amount * w / total).quantize(Decimal("0.01")) for k, w in weights.items()}
    diff = amount - sum(out.values(), Z)
    if diff:
        biggest = max(out, key=lambda k: abs(out[k]))
        out[biggest] += diff
    return {k: v for k, v in out.items() if v}


def _gst_entries(m: Mapper, side: str, splits: dict[str, dict], sign: int) -> list[X.Entry]:
    out = []
    for comp, buckets in splits.items():
        key = f"{side}_{comp}"
        for rate, value in buckets.items():
            out.append(X.Entry(m.gst(key, rate), sign * value))
    return out


def _state_name(code: str | None) -> str | None:
    return GST_STATE_CODES.get(code or "") or None


def party_master(m: Mapper, kind: str, party) -> X.LedgerMaster:
    if kind == "customer":
        name, parent = m.customer(party), "Sundry Debtors"
    else:
        name, parent = m.supplier(party), "Sundry Creditors"
    place = ", ".join(x for x in (party.city, party.district if party.district != party.city else None) if x)
    address = [x for x in (party.address_line1, party.address_line2, place) if x]
    state = party.state or _state_name(party.state_code) or (_state_name(party.gstin[:2]) if party.gstin else None)
    return X.LedgerMaster(name=name, parent=parent, gstin=party.gstin, state=state, address=address,
                          pincode=party.pincode, bill_wise=True)


def account_masters(m: Mapper) -> list[X.LedgerMaster]:
    """Every active ERP ledger (except the debtor / creditor control ledgers), plus per-rate GST ledgers."""
    out: list[X.LedgerMaster] = []
    seen: set[str] = set()
    for a in sorted(m.accounts.values(), key=lambda a: a.code):
        if not a.is_active or a.system_key in PARTY_CONTROL_KEYS:
            continue
        name = m.account(a.id)
        if name in seen:
            continue
        seen.add(name)
        out.append(X.LedgerMaster(name=name, parent=a.group_name or DEFAULT_GROUP.get(a.account_type, "Suspense A/c"),
                                  gst_duty_head=GST_KEYS.get(a.system_key or "")))
    for (kind, key), name in sorted(m.over.items()):
        if kind != "gst" or name in seen:
            continue
        base, _, rate = key.partition("@")
        if base not in GST_KEYS:
            continue
        seen.add(name)
        half = Decimal(rate) / 2 if "igst" not in base else Decimal(rate)
        out.append(X.LedgerMaster(name=name, parent="Duties & Taxes", gst_duty_head=GST_KEYS[base], gst_rate=half))
    return out


# ---------------------------------------------------------------------------------------------- documents
def _invoice(db: Session, m: Mapper, inv: Invoice, action: str) -> X.Voucher:
    if not inv.invoice_number:
        raise BuildError("This invoice has not been issued.")
    c = db.get(Customer, inv.customer_id)
    party = m.customer(c)
    snap = inv.customer_snapshot or {}
    splits = {k: _split_by_rate(inv.items, k, getattr(inv, k)) for k in ("cgst", "sgst", "igst")}
    entries = [X.Entry(party, inv.grand_total, bills=[X.BillRef(inv.invoice_number, "New Ref", inv.grand_total)]),
               X.Entry(m.system("sales"), -inv.taxable, cost_centre=m.cost_centre(inv.project_id)),
               *_gst_entries(m, "output", splits, -1),
               X.Entry(m.system("round_off"), -inv.round_off)]
    narration = "; ".join(x for x in (inv.subject, f"Customer PO {inv.customer_po_number}" if inv.customer_po_number
                                      else None, f"RA bill {inv.ra_bill_no}" if inv.ra_bill_no else None) if x)
    return X.Voucher(remote_id=remote_id("invoice", inv.id), vch_type="Sales", number=inv.invoice_number,
                     vdate=inv.invoice_date, entries=entries, party=party, narration=narration or None,
                     party_gstin=snap.get("gstin") or c.gstin, party_state=snap.get("state") or c.state,
                     place_of_supply=_state_name(inv.place_of_supply), action=action)


def _credit_note(db: Session, m: Mapper, cn: CreditNote, action: str) -> X.Voucher:
    inv = db.get(Invoice, cn.invoice_id)
    c = db.get(Customer, cn.customer_id)
    party = m.customer(c)
    splits = {k: _share(getattr(cn, k), _split_by_rate(inv.items, k, getattr(inv, k))) for k in ("cgst", "sgst", "igst")}
    entries = [X.Entry(m.system("sales"), cn.taxable, cost_centre=m.cost_centre(inv.project_id)),
               *_gst_entries(m, "output", splits, +1),
               X.Entry(m.system("round_off"), cn.round_off),
               X.Entry(party, -cn.total, bills=[X.BillRef(inv.invoice_number, "Agst Ref", -cn.total)])]
    return X.Voucher(remote_id=remote_id("credit_note", cn.id), vch_type="Credit Note", number=cn.cn_number,
                     vdate=cn.cn_date, entries=entries, party=party, reference=inv.invoice_number,
                     reference_date=inv.invoice_date,
                     narration=f"Against invoice {inv.invoice_number}: {cn.reason}", party_gstin=c.gstin,
                     party_state=c.state, place_of_supply=_state_name(inv.place_of_supply), action=action)


def _bank(m: Mapper, mode: str | None) -> str:
    return m.system("cash" if mode == "cash" else "bank")


def _receipt(db: Session, m: Mapper, r: Receipt, action: str) -> X.Voucher:
    c = db.get(Customer, r.customer_id)
    party = m.customer(c)
    bills = []
    for a in r.allocations:
        if a.is_active:
            number = db.scalar(select(Invoice.invoice_number).where(Invoice.id == a.invoice_id))
            bills.append(X.BillRef(number, "Agst Ref", -(a.amount + a.tds)))
    if r.unallocated > 0:
        bills.append(X.BillRef(r.receipt_number, "On Account", -r.unallocated))
    entries = [X.Entry(_bank(m, r.mode), r.amount), X.Entry(m.system("tds_receivable"), r.tds_amount),
               X.Entry(party, -(r.amount + r.tds_amount), bills=bills)]
    narration = f"{r.mode.upper()}" + (f" {r.reference_no}" if r.reference_no else "") + (
        f", TDS ₹{r.tds_amount}" if r.tds_amount else "") + (f". {r.notes}" if r.notes else "")
    return X.Voucher(remote_id=remote_id("receipt", r.id), vch_type="Receipt", number=r.receipt_number,
                     vdate=r.receipt_date, entries=entries, party=party, narration=narration, action=action)


def _bill(db: Session, m: Mapper, b: SupplierInvoice, action: str) -> X.Voucher:
    if not b.bill_number:
        raise BuildError("This bill has not been posted.")
    s = db.get(Supplier, b.supplier_id)
    party = m.supplier(s)
    splits = {k: _split_by_rate(b.items, k, getattr(b, k)) for k in ("cgst", "sgst", "igst")}
    entries = [X.Entry(m.account(b.account_id), b.taxable, cost_centre=m.cost_centre(b.project_id)),
               *_gst_entries(m, "input", splits, +1),
               X.Entry(m.system("round_off"), b.round_off),
               X.Entry(party, -b.grand_total, bills=[X.BillRef(b.supplier_invoice_no, "New Ref", -b.grand_total)])]
    return X.Voucher(remote_id=remote_id("supplier_invoice", b.id), vch_type="Purchase", number=b.bill_number,
                     vdate=b.supplier_invoice_date, entries=entries, party=party, reference=b.supplier_invoice_no,
                     reference_date=b.supplier_invoice_date,
                     narration=f"{s.supplier_name} invoice {b.supplier_invoice_no}" + (f". {b.notes}" if b.notes else ""),
                     party_gstin=s.gstin, party_state=s.state, place_of_supply=_state_name(b.place_of_supply),
                     action=action)


def _payment(db: Session, m: Mapper, pay: SupplierPayment, action: str) -> X.Voucher:
    s = db.get(Supplier, pay.supplier_id)
    party = m.supplier(s)
    bills = []
    for a in pay.allocations:
        if a.is_active:
            ref = db.scalar(select(SupplierInvoice.supplier_invoice_no).where(SupplierInvoice.id == a.supplier_invoice_id))
            bills.append(X.BillRef(ref, "Agst Ref", a.amount + a.tds))
    if pay.unallocated > 0:
        bills.append(X.BillRef(pay.payment_number, "On Account", pay.unallocated))
    entries = [X.Entry(party, pay.amount + pay.tds_amount, bills=bills), X.Entry(_bank(m, pay.mode), -pay.amount),
               X.Entry(m.system("tds_payable"), -pay.tds_amount)]
    narration = f"{pay.mode.upper()}" + (f" {pay.reference_no}" if pay.reference_no else "") + (
        f", TDS ₹{pay.tds_amount} deducted" if pay.tds_amount else "") + (f". {pay.notes}" if pay.notes else "")
    return X.Voucher(remote_id=remote_id("supplier_payment", pay.id), vch_type="Payment", number=pay.payment_number,
                     vdate=pay.payment_date, entries=entries, party=party, narration=narration, action=action)


def _expense(db: Session, m: Mapper, e: ExpenseClaim, action: str) -> X.Voucher:
    if not e.expense_number or e.approved_at is None:
        raise BuildError("This expense claim has not been approved.")
    cat = db.get(ExpenseCategory, e.category_id)
    emp = db.get(Employee, e.employee_id)
    entries = [X.Entry(m.account(cat.account_id), e.amount, cost_centre=m.cost_centre(e.project_id)),
               X.Entry(m.system("employee_payable"), -e.amount)]
    return X.Voucher(remote_id=remote_id("expense", e.id), vch_type="Journal", number=e.expense_number,
                     vdate=e.expense_date, entries=entries,
                     narration=f"{emp.full_name} ({emp.employee_code}) — {cat.name}: {e.description}", action=action)


def _expense_payment(db: Session, m: Mapper, e: ExpenseClaim, action: str) -> X.Voucher:
    if e.paid_at is None:
        raise BuildError("This expense claim has not been paid.")
    emp = db.get(Employee, e.employee_id)
    entries = [X.Entry(m.system("employee_payable"), e.amount), X.Entry(_bank(m, e.payment_mode), -e.amount)]
    return X.Voucher(remote_id=remote_id("expense_payment", e.id), vch_type="Payment", number=e.expense_number,
                     vdate=e.paid_at, entries=entries,
                     narration=f"Expense claim paid to {emp.full_name} ({(e.payment_mode or '').upper()}"
                               + (f" {e.payment_reference}" if e.payment_reference else "") + ")", action=action)


DOCS = {
    "invoice": (Invoice, _invoice), "credit_note": (CreditNote, _credit_note), "receipt": (Receipt, _receipt),
    "supplier_invoice": (SupplierInvoice, _bill), "supplier_payment": (SupplierPayment, _payment),
    "expense": (ExpenseClaim, _expense), "expense_payment": (ExpenseClaim, _expense_payment),
}


def load(db: Session, entity_type: str, entity_id: uuid.UUID):
    cls = DOCS[entity_type][0]
    doc = db.get(cls, entity_id)
    if doc is None:
        raise BuildError("The document no longer exists.")
    return doc


def build_voucher(db: Session, m: Mapper, entity_type: str, entity_id: uuid.UUID, action: str = "Create") -> X.Voucher:
    doc = load(db, entity_type, entity_id)
    return DOCS[entity_type][1](db, m, doc, action)


def doc_facts(db: Session, entity_type: str, doc) -> dict:
    """Number, date and party of an ERP document (for the queue and the sync record)."""
    if entity_type == "invoice":
        return {"number": doc.invoice_number, "date": doc.invoice_date, "party": ("customer", doc.customer_id)}
    if entity_type == "credit_note":
        return {"number": doc.cn_number, "date": doc.cn_date, "party": ("customer", doc.customer_id)}
    if entity_type == "receipt":
        return {"number": doc.receipt_number, "date": doc.receipt_date, "party": ("customer", doc.customer_id)}
    if entity_type == "supplier_invoice":
        return {"number": doc.bill_number, "date": doc.supplier_invoice_date, "party": ("supplier", doc.supplier_id)}
    if entity_type == "supplier_payment":
        return {"number": doc.payment_number, "date": doc.payment_date, "party": ("supplier", doc.supplier_id)}
    if entity_type == "expense":
        return {"number": doc.expense_number, "date": doc.expense_date, "party": None}
    if entity_type == "expense_payment":
        return {"number": doc.expense_number, "date": doc.paid_at, "party": None}
    raise KeyError(entity_type)
