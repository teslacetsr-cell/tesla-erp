"""TallyPrime XML: import envelopes (ledger masters, vouchers), export requests, and reading Tally's replies.

Pure functions — no database. Amount convention used by the builders: ``dr`` is positive for a debit and negative
for a credit (as in the ERP journal). Tally writes the opposite: a debit is a *negative* AMOUNT with
``ISDEEMEDPOSITIVE`` Yes, a credit a positive AMOUNT with No. Every voucher must balance to zero.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, InvalidOperation
from xml.sax.saxutils import escape, quoteattr

Z = Decimal("0")
CENT = Decimal("0.01")


class VoucherNotBalanced(ValueError):
    pass


def tally_date(d: date) -> str:
    return d.strftime("%Y%m%d")


def amt(v: Decimal) -> str:
    return f"{Decimal(v).quantize(CENT):.2f}"


def _t(tag: str, value) -> str:
    if value is None or value == "":
        return ""
    return f"<{tag}>{escape(str(value))}</{tag}>"


# ---------------------------------------------------------------------------------------------- envelopes
def import_envelope(report: str, company: str | None, body: str) -> str:
    sv = f"<STATICVARIABLES>{_t('SVCURRENTCOMPANY', company)}</STATICVARIABLES>" if company else ""
    return ("<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA>"
            f"<REQUESTDESC><REPORTNAME>{escape(report)}</REPORTNAME>{sv}</REQUESTDESC>"
            f'<REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF">{body}</TALLYMESSAGE></REQUESTDATA>'
            "</IMPORTDATA></BODY></ENVELOPE>")


# ---------------------------------------------------------------------------------------------- masters
@dataclass
class LedgerMaster:
    name: str
    parent: str
    gstin: str | None = None
    state: str | None = None
    address: list[str] = field(default_factory=list)
    pincode: str | None = None
    bill_wise: bool = False
    gst_duty_head: str | None = None      # "Central Tax" | "State Tax" | "Integrated Tax" for GST ledgers
    gst_rate: Decimal | None = None
    action: str = "Create"


def ledger_xml(m: LedgerMaster) -> str:
    parts = [f"<LEDGER NAME={quoteattr(m.name)} ACTION={quoteattr(m.action)}>",
             f"<NAME.LIST><NAME>{escape(m.name)}</NAME></NAME.LIST>", _t("PARENT", m.parent),
             f"<ISBILLWISEON>{'Yes' if m.bill_wise else 'No'}</ISBILLWISEON><AFFECTSSTOCK>No</AFFECTSSTOCK>"]
    if m.bill_wise:  # a party
        parts += [_t("PARTYGSTIN", m.gstin), f"<GSTREGISTRATIONTYPE>{'Regular' if m.gstin else 'Unregistered'}"
                  "</GSTREGISTRATIONTYPE>", _t("LEDSTATENAME", m.state), "<COUNTRYOFRESIDENCE>India</COUNTRYOFRESIDENCE>",
                  _t("PINCODE", m.pincode)]
        if m.address:
            parts.append("<ADDRESS.LIST>" + "".join(_t("ADDRESS", a[:100]) for a in m.address if a) + "</ADDRESS.LIST>")
    if m.gst_duty_head:
        parts += ["<TAXTYPE>GST</TAXTYPE>", _t("GSTDUTYHEAD", m.gst_duty_head)]
        if m.gst_rate is not None:
            parts.append(_t("RATEOFTAXCALCULATION", f"{Decimal(m.gst_rate).normalize():f}"))
    parts.append("</LEDGER>")
    return "".join(parts)


def masters_envelope(company: str | None, ledgers: list[LedgerMaster]) -> str:
    return import_envelope("All Masters", company, "".join(ledger_xml(m) for m in ledgers))


# ---------------------------------------------------------------------------------------------- vouchers
@dataclass
class BillRef:
    name: str
    bill_type: str          # "New Ref" | "Agst Ref" | "On Account" | "Advance"
    dr: Decimal


@dataclass
class Entry:
    ledger: str
    dr: Decimal                               # + debit, - credit
    bills: list[BillRef] = field(default_factory=list)
    cost_centre: str | None = None


@dataclass
class Voucher:
    remote_id: str
    vch_type: str                             # Sales, Credit Note, Receipt, Purchase, Payment, Journal
    number: str
    vdate: date
    entries: list[Entry]
    party: str | None = None
    narration: str | None = None
    reference: str | None = None              # supplier invoice no. / original invoice no.
    reference_date: date | None = None
    party_gstin: str | None = None
    party_state: str | None = None
    place_of_supply: str | None = None        # state name
    action: str = "Create"


def _entry_xml(e: Entry) -> str:
    tally_amount = -Decimal(e.dr)
    out = [f"<ALLLEDGERENTRIES.LIST><LEDGERNAME>{escape(e.ledger)}</LEDGERNAME>",
           f"<ISDEEMEDPOSITIVE>{'Yes' if e.dr > 0 else 'No'}</ISDEEMEDPOSITIVE>",
           f"<ISPARTYLEDGER>{'Yes' if e.bills else 'No'}</ISPARTYLEDGER>",
           f"<AMOUNT>{amt(tally_amount)}</AMOUNT>"]
    for b in e.bills:
        name = f"<NAME>{escape(b.name)}</NAME>" if b.name and b.bill_type != "On Account" else ""
        out.append(f"<BILLALLOCATIONS.LIST>{name}<BILLTYPE>{escape(b.bill_type)}</BILLTYPE>"
                   f"<AMOUNT>{amt(-Decimal(b.dr))}</AMOUNT></BILLALLOCATIONS.LIST>")
    if e.cost_centre:
        out.append("<CATEGORYALLOCATIONS.LIST><CATEGORY>Primary Cost Category</CATEGORY><ISDEEMEDPOSITIVE>"
                   f"{'Yes' if e.dr > 0 else 'No'}</ISDEEMEDPOSITIVE><COSTCENTREALLOCATIONS.LIST>"
                   f"<NAME>{escape(e.cost_centre)}</NAME><AMOUNT>{amt(tally_amount)}</AMOUNT>"
                   "</COSTCENTREALLOCATIONS.LIST></CATEGORYALLOCATIONS.LIST>")
    out.append("</ALLLEDGERENTRIES.LIST>")
    return "".join(out)


def merge_entries(entries: list[Entry]) -> list[Entry]:
    """Drop zero lines and merge lines for the same ledger (and cost centre) without bill allocations."""
    out: list[Entry] = []
    for e in entries:
        d = Decimal(e.dr).quantize(CENT)
        if d == 0 and not e.bills:
            continue
        same = next((o for o in out if o.ledger == e.ledger and o.cost_centre == e.cost_centre
                     and not o.bills and not e.bills and (o.dr > 0) == (d > 0)), None)
        if same is not None:
            same.dr += d
        else:
            out.append(Entry(e.ledger, d, list(e.bills), e.cost_centre))
    return out


def voucher_xml(v: Voucher) -> str:
    entries = merge_entries(v.entries)
    total = sum((e.dr for e in entries), Z)
    if total != 0:
        raise VoucherNotBalanced(f"{v.vch_type} {v.number}: debits and credits differ by {total}")
    if not entries:
        raise VoucherNotBalanced(f"{v.vch_type} {v.number}: nothing to send")
    head = [f"<VOUCHER REMOTEID={quoteattr(v.remote_id)} VCHTYPE={quoteattr(v.vch_type)} "
            f"ACTION={quoteattr(v.action)} OBJVIEW=\"Accounting Voucher View\">",
            f"<DATE>{tally_date(v.vdate)}</DATE>", _t("VOUCHERTYPENAME", v.vch_type), _t("VOUCHERNUMBER", v.number),
            _t("REFERENCE", v.reference),
            _t("REFERENCEDATE", tally_date(v.reference_date) if v.reference_date else None),
            _t("PARTYLEDGERNAME", v.party), _t("PARTYNAME", v.party), _t("PARTYGSTIN", v.party_gstin),
            _t("STATENAME", v.party_state), _t("PLACEOFSUPPLY", v.place_of_supply),
            _t("NARRATION", (v.narration or "")[:1000] or None),
            "<PERSISTEDVIEW>Accounting Voucher View</PERSISTEDVIEW>"]
    return "".join(head) + "".join(_entry_xml(e) for e in entries) + "</VOUCHER>"


def cancel_voucher_xml(remote_id: str, vch_type: str, number: str, vdate: date, narration: str | None) -> str:
    return (f"<VOUCHER REMOTEID={quoteattr(remote_id)} DATE={quoteattr(tally_date(vdate))} "
            f"TAGNAME=\"Voucher Number\" TAGVALUE={quoteattr(number)} VCHTYPE={quoteattr(vch_type)} ACTION=\"Cancel\">"
            f"<DATE>{tally_date(vdate)}</DATE>{_t('VOUCHERTYPENAME', vch_type)}{_t('VOUCHERNUMBER', number)}"
            f"{_t('NARRATION', (narration or '')[:500] or None)}</VOUCHER>")


def vouchers_envelope(company: str | None, vouchers_xml: str) -> str:
    return import_envelope("Vouchers", company, vouchers_xml)


# ---------------------------------------------------------------------------------------------- export requests
def ledger_balances_request(company: str | None) -> str:
    sv = _t("SVCURRENTCOMPANY", company)
    return ("<ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE>"
            "<ID>TCE Ledger Balances</ID></HEADER><BODY><DESC><STATICVARIABLES>"
            f"<SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>{sv}</STATICVARIABLES>"
            "<TDL><TDLMESSAGE><COLLECTION NAME=\"TCE Ledger Balances\" ISMODIFY=\"No\"><TYPE>Ledger</TYPE>"
            "<FETCH>NAME, PARENT, CLOSINGBALANCE, PARTYGSTIN</FETCH></COLLECTION></TDLMESSAGE></TDL>"
            "</DESC></BODY></ENVELOPE>")


# ---------------------------------------------------------------------------------------------- replies
@dataclass
class ImportReply:
    recognised: bool
    created: int = 0
    altered: int = 0
    deleted: int = 0
    cancelled: int = 0
    errors: int = 0
    exceptions: int = 0
    last_vch_id: str | None = None
    line_errors: list[str] = field(default_factory=list)

    @property
    def duplicate_only(self) -> bool:
        """Every error says the thing is already in Tally (voucher number / ledger exists)."""
        return bool(self.line_errors) and all("already exists" in e.lower() for e in self.line_errors)

    @property
    def success(self) -> bool:
        if not self.recognised:
            return False
        if self.errors == 0 and self.exceptions == 0 and not self.line_errors:
            return True
        return self.duplicate_only and self.exceptions == 0

    @property
    def message(self) -> str:
        if not self.recognised:
            return "Tally sent a reply the ERP could not read."
        if self.line_errors:
            return "; ".join(self.line_errors)[:2000]
        if self.errors or self.exceptions:
            return f"Tally reported {self.errors} error(s) and {self.exceptions} exception(s) without details."
        return (f"Created {self.created}, altered {self.altered}, cancelled {self.cancelled}"
                + (f", deleted {self.deleted}" if self.deleted else ""))


def _int(text: str, tag: str) -> int:
    m = re.search(rf"<{tag}>\s*(-?\d+)\s*</{tag}>", text)
    return int(m.group(1)) if m else 0


def _unescape(s: str) -> str:
    return (s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"').replace("&apos;", "'")
            .replace("&amp;", "&"))


def parse_import_reply(text: str | None) -> ImportReply:
    t = text or ""
    line_errors = [_unescape(m.strip()) for m in re.findall(r"<LINEERROR>(.*?)</LINEERROR>", t, re.S) if m.strip()]
    recognised = bool(re.search(r"<(CREATED|ERRORS|LINEERROR)>", t))
    r = ImportReply(recognised=recognised, created=_int(t, "CREATED"), altered=_int(t, "ALTERED"),
                    deleted=_int(t, "DELETED"), cancelled=_int(t, "CANCELLED"), errors=_int(t, "ERRORS"),
                    exceptions=_int(t, "EXCEPTIONS"), line_errors=line_errors)
    m = re.search(r"<LASTVCHID>\s*(\d+)\s*</LASTVCHID>", t)
    if m and m.group(1) != "0":
        r.last_vch_id = m.group(1)
    if line_errors and r.errors == 0:
        r.errors = len(line_errors)
    return r


def _dec(text: str | None) -> Decimal:
    s = (text or "").strip().replace(",", "")
    m = re.match(r"^-?\d+(\.\d+)?", s)
    if not m:
        return Z
    try:
        v = Decimal(m.group(0))
    except InvalidOperation:
        return Z
    # "1234.00 Dr" / "Cr" suffixes: Tally writes debit balances as negative numbers; honour an explicit suffix.
    if re.search(r"\bDr\b", s) and v > 0:
        v = -v
    return v


@dataclass
class TallyLedgerBalance:
    name: str
    parent: str
    closing: Decimal        # Tally's sign: negative = debit balance

    @property
    def dr_balance(self) -> Decimal:
        return -self.closing


def parse_ledger_export(text: str | None) -> list[TallyLedgerBalance]:
    """``<LEDGER NAME="…"><PARENT>…</PARENT><CLOSINGBALANCE>-1234.00</CLOSINGBALANCE>…`` anywhere in the reply.

    Read with regular expressions rather than an XML parser: Tally's replies are not always well-formed, and the text
    comes from outside (no entity expansion, no DOCTYPE processing)."""
    t = (text or "").lstrip("\ufeff")
    out: list[TallyLedgerBalance] = []
    for m in re.finditer(r"<LEDGER\b([^>]*)>(.*?)</LEDGER>", t, re.S):
        attrs, body = m.group(1), m.group(2)
        name_attr = re.search(r'\bNAME="([^"]*)"', attrs)
        name_el = re.search(r"<NAME>(.*?)</NAME>", body, re.S)
        name = _unescape(name_attr.group(1) if name_attr else (name_el.group(1) if name_el else "")).strip()
        if not name:
            continue
        parent = re.search(r"<PARENT[^>]*>(.*?)</PARENT>", body, re.S)
        closing = re.search(r"<CLOSINGBALANCE[^>]*>(.*?)</CLOSINGBALANCE>", body, re.S)
        out.append(TallyLedgerBalance(name, _unescape(parent.group(1)).strip() if parent else "",
                                      _dec(closing.group(1) if closing else None)))
    return out


def export_error(text: str | None) -> str | None:
    """A LINEERROR in an export reply (e.g. the company is not open in Tally)."""
    m = re.search(r"<LINEERROR>(.*?)</LINEERROR>", text or "", re.S)
    return _unescape(m.group(1).strip()) if m else None
