"""Called by the finance services when a document is issued / posted / changed / cancelled.

Runs inside the caller's transaction (so a queued job exists exactly when the document does), but in a SAVEPOINT and
behind a catch-all: a Tally problem — a missing ledger, a bug here — must never block or roll back the ERP document.
"""
import logging
import uuid

from sqlalchemy.orm import Session

log = logging.getLogger("app.tally")


def _safe(db: Session, what: str, fn) -> None:
    try:
        with db.begin_nested():
            fn()
    except Exception:  # noqa: BLE001 — by design
        log.exception("Tally sync: could not queue %s", what)


def document_posted(db: Session, entity_type: str, entity_id: uuid.UUID) -> None:
    from app.tally import service

    _safe(db, f"{entity_type} {entity_id}", lambda: service.enqueue_document(db, entity_type, entity_id))


def document_changed(db: Session, entity_type: str, entity_id: uuid.UUID) -> None:
    from app.tally import service

    _safe(db, f"change of {entity_type} {entity_id}", lambda: service.document_changed(db, entity_type, entity_id))


def document_cancelled(db: Session, entity_type: str, entity_id: uuid.UUID) -> None:
    from app.tally import service

    _safe(db, f"cancel of {entity_type} {entity_id}", lambda: service.document_cancelled(db, entity_type, entity_id))
