"""Tally sync: settings, connector keys, the job queue (enqueue / lease / result / retry), backfill, reconciliation.

Queue rules
* Jobs are leased in ``(priority, seq)`` order — ledger masters (10) before vouchers (20) before exports (30) — and a
  job whose ``depends_on`` job is not finished yet is held back (e.g. a voucher waits for its party's ledger, an alter
  or cancel waits for the voucher's create). ``SELECT … FOR UPDATE SKIP LOCKED`` makes concurrent leases safe.
* A lease lasts 10 minutes; a job not reported back by then is handed out again.
* Tally unreachable (``ok: false``) → the job (and the rest of its lease batch) goes back to pending; nothing is lost.
* Tally answered with errors → ``failed`` with Tally's LINEERROR text; Accounts fix the cause and press Retry, which
  rebuilds the XML with the current ledger mapping. "Already exists" counts as done (the voucher / ledger is in Tally).
* Each document is pushed once (``tally_sync_records``). After that, a change of allocations is an *Alter* of the same
  voucher and an ERP cancellation is a *Cancel* of it; if the voucher never reached Tally the pending job is dropped.
"""
from __future__ import annotations

import hashlib
import logging
import secrets
import uuid
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal
from zoneinfo import ZoneInfo

from sqlalchemy import and_, func, or_, select, update
from sqlalchemy.orm import Session

from app.core.context import request_ctx
from app.core.errors import AppError, NotFound
from app.customers.models import Customer
from app.finance.models import (
    CreditNote,
    ExpenseClaim,
    Invoice,
    JournalLine,
    Receipt,
    SupplierInvoice,
    SupplierPayment,
)
from app.platform.audit import service as audit
from app.platform.notifications.service import notify, users_with_roles
from app.suppliers.models import Supplier
from app.tally import builders as B
from app.tally import xml as X
from app.tally.models import (
    TallyConnectorKey,
    TallyJob,
    TallyLedgerMap,
    TallyReconciliation,
    TallySettings,
    TallySyncRecord,
)

log = logging.getLogger("app.tally")
Z = Decimal("0")
IST = ZoneInfo("Asia/Kolkata")
LEASE_SECONDS = 600
PRIO_MASTER, PRIO_VOUCHER, PRIO_EXPORT = 10, 20, 30
MAX_STORED_RESPONSE = 100_000
KEY_PREFIX = "tck_"


def utcnow() -> datetime:
    return datetime.now(UTC)


def _uid() -> uuid.UUID | None:
    return request_ctx.get().user_id


# ============================================================================================ settings
def find_settings(db: Session) -> TallySettings | None:
    return db.scalar(select(TallySettings).order_by(TallySettings.created_at).limit(1))


def get_settings(db: Session, company_id: uuid.UUID) -> TallySettings:
    st = db.scalar(select(TallySettings).where(TallySettings.company_id == company_id))
    if st is None:
        from app.company.models import Company

        company = db.get(Company, company_id)
        st = TallySettings(company_id=company_id, enabled=False, poll_seconds=60,
                           tally_company=company.company_name if company else None,
                           voucher_types={k: "tally" for k in B.VOUCHER_TYPES}, create_party_ledgers=True,
                           created_by=_uid(), updated_by=_uid())
        db.add(st)
        db.flush()
    return st


def settings_out(st: TallySettings) -> dict:
    return {"enabled": st.enabled, "poll_seconds": st.poll_seconds, "tally_company": st.tally_company,
            "start_date": st.start_date.isoformat() if st.start_date else None,
            "voucher_types": {k: st.voucher_types.get(k, "tally") for k in B.VOUCHER_TYPES},
            "create_party_ledgers": st.create_party_ledgers, "row_version": st.row_version,
            "voucher_type_labels": {k: {"tally_type": v[0], "label": v[1]} for k, v in B.VOUCHER_TYPES.items()}}


def update_settings(db: Session, p, data) -> TallySettings:
    from app.core.models import check_row_version

    st = get_settings(db, p.company_id)
    check_row_version(st, data.row_version)
    before = settings_out(st)
    vts = dict(st.voucher_types or {})
    for k, v in (data.voucher_types or {}).items():
        if k not in B.VOUCHER_TYPES or v not in ("erp", "tally"):
            raise AppError("INVALID_SETTING", f"Unknown voucher type or choice: {k} = {v}.")
        vts[k] = v
    if any(v == "erp" for v in vts.values()) and not data.start_date:
        raise AppError("START_DATE_REQUIRED", "Choose the date from which ERP entries are sent to Tally (usually the "
                                              "first day after the last entry already typed into Tally).",
                       details={"field": "start_date"})
    st.enabled, st.poll_seconds, st.tally_company = data.enabled, data.poll_seconds, data.tally_company or None
    st.start_date, st.voucher_types, st.create_party_ledgers = data.start_date, vts, data.create_party_ledgers
    st.updated_by, st.row_version = p.id, st.row_version + 1
    db.flush()
    audit.record(db, action="update", entity_type="tally_settings", entity_id=st.id, entity_label="Tally sync settings",
                 before=before, after=settings_out(st))
    return st


def push_enabled(st: TallySettings | None, entity_type: str, on: date | None) -> bool:
    if st is None or st.start_date is None or on is None:
        return False
    return (st.voucher_types or {}).get(B.ENTITY_VTYPE[entity_type]) == "erp" and on >= st.start_date


# ============================================================================================ connector keys
def hash_key(key: str) -> str:
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def create_key(db: Session, p, name: str) -> tuple[TallyConnectorKey, str]:
    key = KEY_PREFIX + secrets.token_urlsafe(32)
    k = TallyConnectorKey(name=name, key_prefix=key[:12], key_hash=hash_key(key), created_by=p.id, updated_by=p.id)
    db.add(k)
    db.flush()
    audit.record(db, action="create", entity_type="tally_connector_key", entity_id=k.id, entity_label=name,
                 summary=f"Connector key {k.key_prefix}… created")
    return k, key


def revoke_key(db: Session, p, key_id: uuid.UUID) -> TallyConnectorKey:
    k = db.get(TallyConnectorKey, key_id, with_for_update=True)
    if k is None:
        raise NotFound("connector_key")
    if k.revoked_at is None:
        k.revoked_at, k.revoked_by, k.updated_by, k.row_version = utcnow(), p.id, p.id, k.row_version + 1
        db.flush()
        audit.record(db, action="revoke", entity_type="tally_connector_key", entity_id=k.id, entity_label=k.name,
                     summary=f"Connector key {k.key_prefix}… revoked")
    return k


def authenticate(db: Session, key: str) -> TallyConnectorKey | None:
    if not key.startswith(KEY_PREFIX) or len(key) > 200:
        return None
    k = db.scalar(select(TallyConnectorKey).where(TallyConnectorKey.key_hash == hash_key(key)))
    if k is None or k.revoked_at is not None:
        return None
    return k


def key_out(k: TallyConnectorKey, poll_seconds: int = 60) -> dict:
    online = bool(k.last_seen_at and k.revoked_at is None
                  and utcnow() - k.last_seen_at <= timedelta(seconds=max(3 * poll_seconds + 30, 180)))
    return {"id": str(k.id), "name": k.name, "key_prefix": k.key_prefix, "created_at": k.created_at.isoformat(),
            "revoked_at": k.revoked_at.isoformat() if k.revoked_at else None,
            "last_seen_at": k.last_seen_at.isoformat() if k.last_seen_at else None, "online": online,
            "host": k.host, "agent_version": k.agent_version, "tally_url": k.tally_url, "tally_ok": k.tally_ok,
            "tally_error": k.tally_error, "tally_company": k.tally_company, "tally_version": k.tally_version,
            "last_ip": k.last_ip}


def heartbeat(db: Session, k: TallyConnectorKey, body, ip: str | None) -> dict:
    st = find_settings(db)
    k.last_seen_at, k.last_ip = utcnow(), ip
    k.host, k.agent_version, k.tally_url = (body.host or "")[:120] or None, (body.agent_version or "")[:40] or None, \
        (body.tally_url or "")[:200] or None
    k.tally_ok, k.tally_error = body.tally_ok, (body.tally_error or "")[:500] or None
    k.tally_company, k.tally_version = (body.tally_company or "")[:200] or None, (body.tally_version or "")[:80] or None
    db.flush()
    return {"poll_seconds": st.poll_seconds if st else 60, "enabled": bool(st and st.enabled),
            "company": st.tally_company if st else None,
            "server_time": datetime.now(IST).isoformat(timespec="seconds")}


# ============================================================================================ building XML
def _company(db: Session) -> str | None:
    st = find_settings(db)
    return st.tally_company if st else None


def build_xml(db: Session, job: TallyJob, m: B.Mapper | None = None) -> str:
    """(Re)build a job's XML from the ERP data and the current mapping. Raises BuildError."""
    m = m or B.Mapper(db)
    company = _company(db)
    if job.action == "ledgers":
        return X.masters_envelope(company, B.account_masters(m))
    if job.action == "export_ledgers":
        return X.ledger_balances_request(company)
    if job.action == "master":
        cls = Customer if job.entity_type == "customer" else Supplier
        party = db.get(cls, job.entity_id)
        if party is None:
            raise B.BuildError("The party no longer exists.")
        return X.masters_envelope(company, [B.party_master(m, job.entity_type, party)])
    if job.action == "cancel":
        rec = _record(db, job.entity_type, job.entity_id)
        doc = B.load(db, job.entity_type, job.entity_id)
        facts = B.doc_facts(db, job.entity_type, doc)
        reason = getattr(doc, "status_reason", None)
        return X.vouchers_envelope(company, X.cancel_voucher_xml(
            rec.remote_id if rec else B.remote_id(job.entity_type, job.entity_id), B.ENTITY_TALLY_TYPE[job.entity_type],
            facts["number"], facts["date"], f"Cancelled in the ERP: {reason}" if reason else "Cancelled in the ERP"))
    v = B.build_voucher(db, m, job.entity_type, job.entity_id, "Alter" if job.action == "alter" else "Create")
    try:
        return X.vouchers_envelope(company, X.voucher_xml(v))
    except X.VoucherNotBalanced as exc:
        raise B.BuildError(str(exc)) from exc


def _fill_xml(db: Session, job: TallyJob, m: B.Mapper | None = None) -> bool:
    try:
        job.xml = build_xml(db, job, m)
        return True
    except B.BuildError as exc:
        job.xml, job.status, job.last_error = None, "failed", f"Could not prepare the entry: {exc}"
        return False


def _new_job(db: Session, **kw) -> TallyJob:
    job = TallyJob(created_by=_uid(), updated_by=_uid(), **kw)
    db.add(job)
    db.flush()
    return job


# ============================================================================================ enqueue (hooks)
def _record(db: Session, entity_type: str, entity_id: uuid.UUID, lock: bool = False) -> TallySyncRecord | None:
    stmt = select(TallySyncRecord).where(TallySyncRecord.entity_type == entity_type,
                                         TallySyncRecord.entity_id == entity_id)
    return db.scalar(stmt.with_for_update() if lock else stmt)


def _open_job(job: TallyJob | None) -> TallyJob | None:
    """The job as a dependency, unless it is already finished."""
    return job if job is not None and job.status not in ("done", "cancelled") else None


def ensure_party(db: Session, st: TallySettings, kind: str, party_id: uuid.UUID, m: B.Mapper) -> TallyJob | None:
    """Queue the party's ledger master once. Returns the (unfinished) master job to depend on."""
    rec = _record(db, kind, party_id)
    if rec is not None:
        return _open_job(db.get(TallyJob, rec.create_job_id)) if rec.create_job_id else None
    if not st.create_party_ledgers:
        return None
    party = db.get(Customer if kind == "customer" else Supplier, party_id)
    name = m.customer(party) if kind == "customer" else m.supplier(party)
    job = _new_job(db, priority=PRIO_MASTER, kind="import", action="master", entity_type=kind, entity_id=party_id,
                   label=f"Ledger: {name}", doc_number=None)
    _fill_xml(db, job, m)
    db.add(TallySyncRecord(entity_type=kind, entity_id=party_id, tally_name=name,
                           remote_id=B.remote_id(kind, party_id), state="queued", create_job_id=job.id,
                           last_job_id=job.id, created_by=_uid(), updated_by=_uid()))
    db.flush()
    return job


def enqueue_document(db: Session, entity_type: str, entity_id: uuid.UUID) -> TallyJob | None:
    """A document was issued / posted: queue it once, if its voucher type is pushed and it is on/after the start date."""
    st = find_settings(db)
    if _record(db, entity_type, entity_id) is not None:
        return None
    doc = B.load(db, entity_type, entity_id)
    facts = B.doc_facts(db, entity_type, doc)
    if not push_enabled(st, entity_type, facts["date"]):
        return None
    m = B.Mapper(db)
    dep = ensure_party(db, st, *facts["party"], m) if facts["party"] else None
    job = _new_job(db, priority=PRIO_VOUCHER, kind="import", action="create",
                   voucher_type=B.ENTITY_VTYPE[entity_type], entity_type=entity_type, entity_id=entity_id,
                   doc_number=facts["number"], doc_date=facts["date"],
                   label=f"{B.ENTITY_LABEL[entity_type]} {facts['number']}", depends_on_id=dep.id if dep else None)
    db.add(TallySyncRecord(entity_type=entity_type, entity_id=entity_id, voucher_type=B.ENTITY_VTYPE[entity_type],
                           doc_number=facts["number"], remote_id=B.remote_id(entity_type, entity_id), state="queued",
                           create_job_id=job.id, last_job_id=job.id, created_by=_uid(), updated_by=_uid()))
    db.flush()
    if not _fill_xml(db, job, m):
        _sync_failed(db, job)
    return job


def document_changed(db: Session, entity_type: str, entity_id: uuid.UUID) -> TallyJob | None:
    """Allocations of a receipt / payment changed after it was queued: re-send it (alter) or rebuild the pending job."""
    rec = _record(db, entity_type, entity_id, lock=True)
    if rec is None or rec.cancelled_in_erp or rec.state == "cancelled":
        return None
    create = db.get(TallyJob, rec.create_job_id) if rec.create_job_id else None
    if create is not None and create.status in ("pending", "failed"):
        if create.status == "pending":
            _fill_xml(db, create)
        return create
    pending_alter = db.scalar(select(TallyJob).where(TallyJob.entity_type == entity_type, TallyJob.entity_id == entity_id,
                                                     TallyJob.action == "alter", TallyJob.status == "pending"))
    if pending_alter is not None:
        _fill_xml(db, pending_alter)
        return pending_alter
    job = _new_job(db, priority=PRIO_VOUCHER, kind="import", action="alter", voucher_type=rec.voucher_type,
                   entity_type=entity_type, entity_id=entity_id, doc_number=rec.doc_number,
                   doc_date=create.doc_date if create else None,
                   label=f"{B.ENTITY_LABEL[entity_type]} {rec.doc_number} (changed)",
                   depends_on_id=_open_job(create).id if _open_job(create) else None)
    _fill_xml(db, job)
    rec.last_job_id = job.id
    db.flush()
    return job


def document_cancelled(db: Session, entity_type: str, entity_id: uuid.UUID) -> TallyJob | None:
    """Cancelled in the ERP: drop it if it never reached Tally, otherwise cancel the Tally voucher."""
    rec = _record(db, entity_type, entity_id, lock=True)
    if rec is None or rec.cancelled_in_erp:
        return None
    rec.cancelled_in_erp = True
    unsent = db.scalars(select(TallyJob).where(TallyJob.entity_type == entity_type, TallyJob.entity_id == entity_id,
                                               TallyJob.status.in_(("pending", "failed")))).all()
    create = db.get(TallyJob, rec.create_job_id) if rec.create_job_id else None
    for j in unsent:
        j.status, j.last_error = "cancelled", "Cancelled in the ERP before it reached Tally — not sent."
    if create is not None and create.status == "cancelled":
        rec.state = "cancelled"
        db.flush()
        return None
    job = _new_job(db, priority=PRIO_VOUCHER, kind="import", action="cancel", voucher_type=rec.voucher_type,
                   entity_type=entity_type, entity_id=entity_id, doc_number=rec.doc_number,
                   doc_date=create.doc_date if create else None,
                   label=f"{B.ENTITY_LABEL[entity_type]} {rec.doc_number} (cancel)",
                   depends_on_id=_open_job(create).id if _open_job(create) else None)
    _fill_xml(db, job)
    rec.last_job_id = job.id
    db.flush()
    return job


def queue_account_ledgers(db: Session, p) -> TallyJob:
    job = _new_job(db, priority=PRIO_MASTER, kind="import", action="ledgers", label="ERP ledgers (create missing in Tally)")
    if not _fill_xml(db, job):
        raise AppError("BUILD_FAILED", job.last_error or "Could not prepare the ledger list.")
    audit.record(db, action="create", entity_type="tally_job", entity_id=job.id, entity_label=job.label,
                 summary="Queued the ERP ledger list for Tally")
    return job


# ============================================================================================ backfill
def backfill(db: Session, p, from_date: date | None) -> dict:
    st = get_settings(db, p.company_id)
    if st.start_date is None:
        raise AppError("START_DATE_REQUIRED", "Set the start date in the settings first.")
    start = max(from_date or st.start_date, st.start_date)
    docs: list[tuple[date, int, str, str, uuid.UUID]] = []

    def add(rank, et, rows):
        for d, n, i in rows:
            docs.append((d, rank, n or "", et, i))

    add(1, "invoice", db.execute(select(Invoice.invoice_date, Invoice.invoice_number, Invoice.id).where(
        Invoice.status.in_(("issued", "cancelled")), Invoice.invoice_number.is_not(None), Invoice.invoice_date >= start)))
    add(2, "credit_note", db.execute(select(CreditNote.cn_date, CreditNote.cn_number, CreditNote.id).where(
        CreditNote.cn_date >= start)))
    add(3, "receipt", db.execute(select(Receipt.receipt_date, Receipt.receipt_number, Receipt.id).where(
        Receipt.status == "posted", Receipt.receipt_date >= start)))
    add(1, "supplier_invoice", db.execute(select(SupplierInvoice.supplier_invoice_date, SupplierInvoice.bill_number,
                                                 SupplierInvoice.id).where(SupplierInvoice.status == "posted",
                                                                           SupplierInvoice.supplier_invoice_date >= start)))
    add(3, "supplier_payment", db.execute(select(SupplierPayment.payment_date, SupplierPayment.payment_number,
                                                 SupplierPayment.id).where(SupplierPayment.status == "posted",
                                                                           SupplierPayment.payment_date >= start)))
    add(1, "expense", db.execute(select(ExpenseClaim.expense_date, ExpenseClaim.expense_number, ExpenseClaim.id).where(
        ExpenseClaim.status.in_(("approved", "paid")), ExpenseClaim.expense_date >= start)))
    add(4, "expense_payment", db.execute(select(ExpenseClaim.paid_at, ExpenseClaim.expense_number, ExpenseClaim.id).where(
        ExpenseClaim.status == "paid", ExpenseClaim.paid_at >= start)))
    done = set(db.execute(select(TallySyncRecord.entity_type, TallySyncRecord.entity_id)).all())
    queued: dict[str, int] = {}
    for _d, _r, _n, et, eid in sorted(docs):
        if (et, eid) in done:
            continue
        if enqueue_document(db, et, eid) is not None:
            queued[et] = queued.get(et, 0) + 1
    total = sum(queued.values())
    audit.record(db, action="backfill", entity_type="tally_settings", entity_id=st.id, entity_label="Tally sync",
                 summary=f"Queued {total} entr{'y' if total == 1 else 'ies'} from {start:%d %b %Y}")
    return {"from_date": start.isoformat(), "queued": total, "by_type": queued}


# ============================================================================================ lease & result
def lease(db: Session, k: TallyConnectorKey, limit: int) -> list[dict]:
    limit = max(1, min(int(limit or 20), 50))
    now = utcnow()
    candidates = db.scalars(
        select(TallyJob).where(or_(TallyJob.status == "pending",
                                   and_(TallyJob.status == "leased", TallyJob.leased_until < now)))
        .order_by(TallyJob.priority, TallyJob.seq).limit(max(limit * 5, 100))
        .with_for_update(skip_locked=True)).all()
    dep_ids = {j.depends_on_id for j in candidates if j.depends_on_id}
    dep_status = dict(db.execute(select(TallyJob.id, TallyJob.status).where(TallyJob.id.in_(dep_ids))).all()) \
        if dep_ids else {}
    batch, chosen, out = uuid.uuid4(), set(), []
    m = None
    for j in candidates:
        if len(out) >= limit:
            break
        if j.depends_on_id and j.depends_on_id not in chosen and dep_status.get(j.depends_on_id) not in (
                "done", "cancelled", None):
            continue
        if not j.xml:
            m = m or B.Mapper(db)
            if not _fill_xml(db, j, m):
                _sync_failed(db, j)
                continue
        j.status, j.attempts, j.leased_until = "leased", j.attempts + 1, now + timedelta(seconds=LEASE_SECONDS)
        j.lease_batch, j.leased_key_id, j.sent_at = batch, k.id, now
        chosen.add(j.id)
        out.append({"id": str(j.id), "kind": j.kind, "label": j.label, "xml": j.xml, "attempt": j.attempts})
    db.flush()
    return out


def _sync_failed(db: Session, job: TallyJob) -> None:
    if job.entity_type and job.entity_id:
        rec = _record(db, job.entity_type, job.entity_id)
        if rec is not None:
            rec.last_error = job.last_error
            if job.action in ("create", "master"):
                rec.state = "failed"
    users = users_with_roles(db, ["ACCOUNTS"])
    notify(db, users, event="tally.failed", title=f"Tally did not accept: {job.label}",
           body=(job.last_error or "")[:300], link="/finance/tally?tab=queue&status=failed")


def _sync_done(db: Session, job: TallyJob) -> None:
    if not (job.entity_type and job.entity_id):
        return
    rec = _record(db, job.entity_type, job.entity_id)
    if rec is None:
        return
    rec.last_error = None
    if job.action == "cancel":
        rec.state = "cancelled"
    elif rec.state != "cancelled":
        rec.state, rec.in_tally_at = "in_tally", rec.in_tally_at or utcnow()
        if job.tally_voucher_id:
            rec.tally_voucher_id = job.tally_voucher_id


def record_result(db: Session, k: TallyConnectorKey, job_id: uuid.UUID, body) -> dict:
    job = db.get(TallyJob, job_id, with_for_update=True)
    if job is None:
        raise NotFound("job")
    if job.status in ("done", "cancelled", "failed"):
        return {"status": "done" if job.status != "failed" else "failed",
                "message": f"Already recorded ({job.status}); this result is ignored."}
    now = utcnow()
    job.elapsed_ms, job.leased_until, job.updated_at = body.elapsed_ms, None, now
    if not body.ok:
        job.status = "pending"
        job.last_error = f"Tally could not be reached: {body.error or 'no answer'}"[:2000]
        # The connector stops after a Tally failure; later jobs of the same lease go back to the queue now.
        if job.lease_batch:
            db.execute(update(TallyJob).where(TallyJob.lease_batch == job.lease_batch, TallyJob.status == "leased",
                                              TallyJob.seq > job.seq)
                       .values(status="pending", leased_until=None, attempts=TallyJob.attempts - 1))
        db.flush()
        return {"status": "retry", "message": "Kept in the queue; it will be sent again."}
    text = body.response or ""
    job.tally_response = text[:MAX_STORED_RESPONSE]
    if body.error:  # e.g. "response too large"
        job.status, job.last_error = "failed", f"Tally's reply could not be used: {body.error}"
    elif job.kind == "export":
        err = X.export_error(text)
        if err or not text.strip():
            job.status, job.last_error = "failed", f"Tally: {err or 'empty reply'}"
        else:
            job.status, job.last_error = "done", None
            _finish_reconciliation(db, job, text)
    else:
        rep = X.parse_import_reply(text)
        if rep.success:
            job.status, job.tally_voucher_id = "done", rep.last_vch_id
            job.last_error = ("Already in Tally: " + "; ".join(rep.line_errors))[:2000] if rep.line_errors else None
        else:
            job.status, job.last_error = "failed", f"Tally: {rep.message}"
    if job.status == "done":
        job.done_at = now
        _sync_done(db, job)
    else:
        _sync_failed(db, job)
        if job.kind == "export":
            _fail_reconciliation(db, job)
    db.flush()
    return {"status": job.status, "message": job.last_error or "ok"}


# ============================================================================================ retry / skip
def retry(db: Session, p, job_id: uuid.UUID, *, m: B.Mapper | None = None, audit_it: bool = True) -> TallyJob:
    job = db.get(TallyJob, job_id, with_for_update=True)
    if job is None:
        raise NotFound("job")
    if job.status != "failed":
        raise AppError("NOT_FAILED", "Only an entry that Tally did not accept can be retried.")
    if not _fill_xml(db, job, m):
        db.flush()
        raise AppError("BUILD_FAILED", job.last_error or "Could not prepare the entry.")
    job.status, job.leased_until, job.updated_by = "pending", None, p.id
    if job.entity_type and job.entity_id:
        rec = _record(db, job.entity_type, job.entity_id)
        if rec is not None and rec.state == "failed":
            rec.state = "queued"
    db.flush()
    if audit_it:
        audit.record(db, action="retry", entity_type="tally_job", entity_id=job.id, entity_label=job.label,
                     summary="Sent to Tally again")
    return job


def retry_failed(db: Session, p) -> dict:
    m = B.Mapper(db)
    ids = list(db.scalars(select(TallyJob.id).where(TallyJob.status == "failed").order_by(TallyJob.priority,
                                                                                          TallyJob.seq)))
    ok, still = 0, 0
    for i in ids:
        try:
            with db.begin_nested():
                retry(db, p, i, m=m, audit_it=False)
            ok += 1
        except AppError:
            still += 1
    if ids:
        audit.record(db, action="retry", entity_type="tally_job", entity_id="all-failed", entity_label="Tally queue",
                     summary=f"Retried {ok} entr{'y' if ok == 1 else 'ies'}" + (f"; {still} still cannot be prepared"
                                                                               if still else ""))
    return {"retried": ok, "not_ready": still}


def skip(db: Session, p, job_id: uuid.UUID, reason: str) -> TallyJob:
    job = db.get(TallyJob, job_id, with_for_update=True)
    if job is None:
        raise NotFound("job")
    if job.status not in ("failed", "pending"):
        raise AppError("INVALID_TRANSITION", "Only a waiting or failed entry can be taken off the queue.")
    job.status, job.last_error, job.updated_by = "cancelled", f"Not sent — {reason}"[:2000], p.id
    if job.entity_type and job.entity_id:
        rec = _record(db, job.entity_type, job.entity_id)
        if rec is not None and job.action in ("create", "master"):
            rec.state, rec.last_error = "cancelled", job.last_error
    db.flush()
    audit.record(db, action="skip", entity_type="tally_job", entity_id=job.id, entity_label=job.label,
                 summary=f"Taken off the Tally queue: {reason}")
    return job


# ============================================================================================ queue views
def job_out(j: TallyJob, deps: dict | None = None, full: bool = False) -> dict:
    out = {"id": str(j.id), "seq": j.seq, "kind": j.kind, "action": j.action, "label": j.label,
           "voucher_type": j.voucher_type, "entity_type": j.entity_type,
           "entity_id": str(j.entity_id) if j.entity_id else None, "doc_number": j.doc_number,
           "doc_date": j.doc_date.isoformat() if j.doc_date else None, "status": j.status, "attempts": j.attempts,
           "last_error": j.last_error, "tally_voucher_id": j.tally_voucher_id,
           "created_at": j.created_at.isoformat() if j.created_at else None,
           "updated_at": j.updated_at.isoformat() if j.updated_at else None,
           "sent_at": j.sent_at.isoformat() if j.sent_at else None,
           "done_at": j.done_at.isoformat() if j.done_at else None,
           "waiting_for": (deps or {}).get(j.depends_on_id)}
    if full:
        out["xml"], out["tally_response"] = j.xml, j.tally_response
    return out


def waiting_labels(db: Session, jobs: list[TallyJob]) -> dict:
    ids = {j.depends_on_id for j in jobs if j.depends_on_id and j.status == "pending"}
    if not ids:
        return {}
    return {i: lbl for i, lbl, st in db.execute(select(TallyJob.id, TallyJob.label, TallyJob.status)
                                                .where(TallyJob.id.in_(ids))) if st not in ("done", "cancelled")}


def counts(db: Session) -> dict:
    rows = dict(db.execute(select(TallyJob.status, func.count()).group_by(TallyJob.status)).all())
    return {s: rows.get(s, 0) for s in ("pending", "leased", "done", "failed", "cancelled")}


def doc_status(db: Session, entity_type: str, entity_id: uuid.UUID) -> dict:
    rec = _record(db, entity_type, entity_id)
    if rec is None:
        return {"state": None}
    last = db.get(TallyJob, rec.last_job_id) if rec.last_job_id else None
    state = rec.state
    if last is not None and last.status == "failed":
        state = "failed"
    elif last is not None and last.status in ("pending", "leased") and rec.state == "in_tally":
        state = "updating"
    return {"state": state, "doc_number": rec.doc_number, "last_error": (last.last_error if last else None)
            or rec.last_error, "in_tally_at": rec.in_tally_at.isoformat() if rec.in_tally_at else None,
            "job_id": str(last.id) if last else None, "cancelled_in_erp": rec.cancelled_in_erp}


# ============================================================================================ mapping
def mapping_out(db: Session) -> dict:
    from app.products.models import TaxRate
    from app.projects.models import Project

    m = B.Mapper(db)
    accounts = []
    for a in sorted(m.accounts.values(), key=lambda a: a.code):
        if a.system_key in B.PARTY_CONTROL_KEYS:
            continue
        accounts.append({"kind": "account", "erp_key": str(a.id), "erp_name": a.name, "code": a.code,
                         "group": a.group_name, "is_active": a.is_active, "default": a.name,
                         "tally_name": m.over.get(("account", str(a.id)))})
    rates = sorted({Decimal(r) for r in db.scalars(select(TaxRate.rate)) if r and Decimal(r) > 0})
    gst = []
    for key, label in (("output_cgst", "Output CGST"), ("output_sgst", "Output SGST"), ("output_igst", "Output IGST"),
                       ("input_cgst", "Input CGST"), ("input_sgst", "Input SGST"), ("input_igst", "Input IGST")):
        if key not in m.by_key:
            continue
        for r in rates:
            part = r if "igst" in key else r / 2
            gst.append({"kind": "gst", "erp_key": f"{key}@{B.rate_key(r)}",
                        "erp_name": f"{label} — on {B.rate_key(r)}% GST ({B.rate_key(part)}%)",
                        "default": m.system(key), "tally_name": m.over.get(("gst", f"{key}@{B.rate_key(r)}"))})
    parties = []
    party_ids = {(r.entity_type, r.entity_id) for r in db.scalars(select(TallySyncRecord).where(
        TallySyncRecord.entity_type.in_(("customer", "supplier"))))}
    party_ids |= {(k, uuid.UUID(v)) for (k, v) in m.over if k in ("customer", "supplier")}
    for kind, pid in party_ids:
        party = db.get(Customer if kind == "customer" else Supplier, pid)
        if party is None:
            continue
        default = party.customer_name if kind == "customer" else party.supplier_name
        parties.append({"kind": kind, "erp_key": str(pid), "erp_name": default, "default": default,
                        "tally_name": m.over.get((kind, str(pid))),
                        "in_tally": (_record(db, kind, pid) or TallySyncRecord(state="queued")).state == "in_tally"})
    parties.sort(key=lambda r: (r["kind"], r["erp_name"].lower()))
    projects = [{"kind": "project", "erp_key": str(pid), "erp_name": f"{num} — {name}", "default": None,
                 "tally_name": m.over.get(("project", str(pid)))}
                for pid, num, name in db.execute(select(Project.id, Project.project_number, Project.name)
                                                 .where(Project.status != "cancelled").order_by(Project.project_number))]
    return {"accounts": accounts, "gst": gst, "parties": parties, "projects": projects}


def save_mapping(db: Session, p, items) -> int:
    changed = 0
    for it in items:
        if it.kind not in ("account", "gst", "customer", "supplier", "project"):
            raise AppError("INVALID_MAPPING", f"Unknown mapping kind '{it.kind}'.")
        if it.kind != "gst":
            try:
                uuid.UUID(it.erp_key)
            except ValueError as exc:
                raise AppError("INVALID_MAPPING", "Invalid ERP reference in the mapping.") from exc
        row = db.scalar(select(TallyLedgerMap).where(TallyLedgerMap.kind == it.kind, TallyLedgerMap.erp_key == it.erp_key))
        name = (it.tally_name or "").strip()
        if not name:
            if row is not None:
                db.delete(row)
                changed += 1
            continue
        if row is None:
            db.add(TallyLedgerMap(kind=it.kind, erp_key=it.erp_key, tally_name=name, created_by=p.id, updated_by=p.id))
            changed += 1
        elif row.tally_name != name:
            row.tally_name, row.updated_by, row.row_version = name, p.id, row.row_version + 1
            changed += 1
    db.flush()
    if changed:
        # Entries still waiting are rebuilt with the new names (those already leased go out as they are).
        m = B.Mapper(db)
        for job in db.scalars(select(TallyJob).where(TallyJob.status == "pending").order_by(TallyJob.seq)):
            if not _fill_xml(db, job, m):
                _sync_failed(db, job)
        db.flush()
        audit.record(db, action="update", entity_type="tally_mapping", entity_id="mapping", entity_label="Tally ledger mapping",
                     summary=f"{changed} ledger name(s) changed")
    return changed


# ============================================================================================ reconciliation
def request_reconciliation(db: Session, p) -> TallyReconciliation:
    job = _new_job(db, priority=PRIO_EXPORT, kind="export", action="export_ledgers", label="Ledger balances from Tally")
    _fill_xml(db, job)
    rec = TallyReconciliation(job_id=job.id, status="waiting", created_by=p.id, updated_by=p.id)
    db.add(rec)
    db.flush()
    audit.record(db, action="create", entity_type="tally_reconciliation", entity_id=rec.id,
                 entity_label="Reconciliation", summary="Asked Tally for ledger balances")
    return rec


def _fail_reconciliation(db: Session, job: TallyJob) -> None:
    for r in db.scalars(select(TallyReconciliation).where(TallyReconciliation.job_id == job.id,
                                                          TallyReconciliation.status == "waiting")):
        r.status, r.error, r.finished_at = "failed", job.last_error, utcnow()


def erp_balances(db: Session) -> tuple[dict, dict]:
    """(party balances {(type, id): Dr+}, ledger balances {account_id: Dr+}) from the ERP journal."""
    m = B.Mapper(db)
    control = [m.by_key[k].id for k in B.PARTY_CONTROL_KEYS if k in m.by_key]
    party = {(t, i): Decimal(v) for t, i, v in db.execute(
        select(JournalLine.party_type, JournalLine.party_id, func.sum(JournalLine.debit - JournalLine.credit))
        .where(JournalLine.account_id.in_(control), JournalLine.party_id.is_not(None))
        .group_by(JournalLine.party_type, JournalLine.party_id))}
    accounts = {a: Decimal(v) for a, v in db.execute(
        select(JournalLine.account_id, func.sum(JournalLine.debit - JournalLine.credit)).group_by(JournalLine.account_id))}
    return party, accounts


def _row(group: str, erp_name: str, tally_name: str, erp: Decimal, tally: Decimal | None) -> dict:
    diff = erp - (tally or Z)
    status = "missing_in_tally" if tally is None and erp != 0 else ("match" if diff == 0 else "different")
    return {"group": group, "erp_name": erp_name, "tally_name": tally_name, "erp": str(erp),
            "tally": None if tally is None else str(tally), "difference": str(diff), "status": status}


def build_reconciliation(db: Session, ledgers: list[X.TallyLedgerBalance]) -> tuple[list[dict], dict]:
    m = B.Mapper(db)
    tally = {lb.name.lower(): lb for lb in ledgers}
    party_bal, acc_bal = erp_balances(db)
    rows: list[dict] = []
    party_ids = {k for k in party_bal} | {
        (r.entity_type, r.entity_id) for r in db.scalars(select(TallySyncRecord).where(
            TallySyncRecord.entity_type.in_(("customer", "supplier"))))}
    for kind in ("customer", "supplier"):
        group = "Customers" if kind == "customer" else "Suppliers"
        items = []
        for t, pid in party_ids:
            if t != kind:
                continue
            p = db.get(Customer if kind == "customer" else Supplier, pid)
            if p is None:
                continue
            name = m.customer(p) if kind == "customer" else m.supplier(p)
            lb = tally.get(name.lower())
            items.append(_row(group, p.customer_name if kind == "customer" else p.supplier_name, name,
                              party_bal.get((kind, pid), Z), lb.dr_balance if lb else None))
        rows += sorted(items, key=lambda r: r["erp_name"].lower())
    for key, group_name, label in (("debtors", "Sundry Debtors", "All customers (Sundry Debtors)"),
                                   ("creditors", "Sundry Creditors", "All suppliers (Sundry Creditors)")):
        if key in m.by_key:
            t_total = sum((lb.dr_balance for lb in ledgers if lb.parent.lower() == group_name.lower()), Z)
            rows.append(_row("Totals", label, f"Group: {group_name}", acc_bal.get(m.by_key[key].id, Z), t_total))
    for a in sorted(m.accounts.values(), key=lambda a: a.code):
        if a.system_key in B.PARTY_CONTROL_KEYS:
            continue
        names = {m.account(a.id)}
        if a.system_key in B.GST_KEYS:
            names |= {v for (k, key), v in m.over.items() if k == "gst" and key.startswith(f"{a.system_key}@")}
        found = [tally[n.lower()] for n in names if n.lower() in tally]
        erp = acc_bal.get(a.id, Z)
        if erp == 0 and not found:
            continue
        rows.append(_row("Ledgers", a.name, ", ".join(sorted(names)), erp,
                         sum((lb.dr_balance for lb in found), Z) if found else None))
    summary = {"rows": len(rows), "different": sum(r["status"] != "match" for r in rows),
               "tally_ledgers": len(ledgers), "as_of": datetime.now(IST).isoformat(timespec="seconds")}
    return rows, summary


def _finish_reconciliation(db: Session, job: TallyJob, text: str) -> None:
    recs = db.scalars(select(TallyReconciliation).where(TallyReconciliation.job_id == job.id,
                                                        TallyReconciliation.status == "waiting")).all()
    if not recs:
        return
    ledgers = X.parse_ledger_export(text)
    rows, summary = build_reconciliation(db, ledgers)
    for r in recs:
        r.rows, r.summary, r.status, r.finished_at = rows, summary, "done", utcnow()


def reconciliation_out(r: TallyReconciliation | None) -> dict | None:
    if r is None:
        return None
    return {"id": str(r.id), "status": r.status, "rows": r.rows, "summary": r.summary, "error": r.error,
            "created_at": r.created_at.isoformat(), "finished_at": r.finished_at.isoformat() if r.finished_at else None}


def latest_reconciliation(db: Session) -> TallyReconciliation | None:
    return db.scalar(select(TallyReconciliation).order_by(TallyReconciliation.created_at.desc()).limit(1))


def status(db: Session, p) -> dict:
    st = get_settings(db, p.company_id)
    keys = db.scalars(select(TallyConnectorKey).order_by(TallyConnectorKey.created_at.desc())).all()
    keys_out = [key_out(k, st.poll_seconds) for k in keys]
    active = [k for k in keys_out if not k["revoked_at"]]
    seen = sorted((k for k in active if k["last_seen_at"]), key=lambda k: k["last_seen_at"], reverse=True)
    last_done = db.scalar(select(func.max(TallyJob.done_at)))
    return {"settings": settings_out(st), "keys": keys_out, "connector": seen[0] if seen else None,
            "counts": counts(db), "last_done_at": last_done.isoformat() if last_done else None,
            "ledgers_queued": db.scalar(select(func.count()).select_from(TallyJob).where(TallyJob.action == "ledgers")) or 0,
            "reconciliation": reconciliation_out(latest_reconciliation(db))}

