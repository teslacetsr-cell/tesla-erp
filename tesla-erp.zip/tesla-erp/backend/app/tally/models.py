"""Tally connector tables (Phase 11).

* ``tally_connector_keys`` — keys the office PC's connector authenticates with. Only a SHA-256 hash is stored; the key
  itself is shown once. The last heartbeat (host, versions, whether Tally answered) is kept on the key.
* ``tally_settings`` — one row per company: sending on/paused, poll interval, Tally company name, the date from which
  ERP documents are pushed, and for each voucher type where it is entered ("one place per entry").
* ``tally_ledger_maps`` — overrides of the Tally ledger name for ERP ledgers, GST-rate ledgers, parties and project
  cost centres. Without an override the ERP name is used.
* ``tally_jobs`` — the queue the connector leases from, in dependency order (masters before vouchers).
* ``tally_sync_records`` — one row per ERP document / party pushed, so each is sent to Tally once.
* ``tally_reconciliations`` — ERP-vs-Tally balance comparisons.
"""
import uuid
from datetime import date, datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    Date,
    DateTime,
    ForeignKey,
    Identity,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.models import AuditColumnsMixin, Base

JOB_STATUSES = ("pending", "leased", "done", "failed", "cancelled")
JOB_KINDS = ("import", "export")
SYNC_STATES = ("queued", "in_tally", "failed", "cancelled")
MAP_KINDS = ("account", "gst", "customer", "supplier", "project")


def _in(col: str, values: tuple[str, ...]) -> str:
    return f"{col} in ({', '.join(repr(v) for v in values)})"


class TallyConnectorKey(AuditColumnsMixin, Base):
    __tablename__ = "tally_connector_keys"

    name: Mapped[str] = mapped_column(String(80), nullable=False)
    key_prefix: Mapped[str] = mapped_column(String(12), nullable=False)          # "tck_AbCdEfGh" — to recognise it
    key_hash: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)  # sha256 hex
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    revoked_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    last_seen_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_ip: Mapped[str | None] = mapped_column(String(45))
    host: Mapped[str | None] = mapped_column(String(120))
    agent_version: Mapped[str | None] = mapped_column(String(40))
    tally_url: Mapped[str | None] = mapped_column(String(200))
    tally_ok: Mapped[bool | None] = mapped_column(Boolean)
    tally_error: Mapped[str | None] = mapped_column(String(500))
    tally_company: Mapped[str | None] = mapped_column(String(200))
    tally_version: Mapped[str | None] = mapped_column(String(80))


class TallySettings(AuditColumnsMixin, Base):
    __tablename__ = "tally_settings"
    __table_args__ = (CheckConstraint("poll_seconds between 30 and 3600", name="poll_range"),)

    company_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), unique=True,
                                                  nullable=False)
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    poll_seconds: Mapped[int] = mapped_column(Integer, nullable=False, default=60, server_default="60")
    tally_company: Mapped[str | None] = mapped_column(String(200))
    start_date: Mapped[date | None] = mapped_column(Date)
    # voucher type -> "erp" (entered in the ERP, pushed to Tally) | "tally" (entered in Tally only; not pushed)
    voucher_types: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict, server_default="{}")
    create_party_ledgers: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class TallyLedgerMap(AuditColumnsMixin, Base):
    __tablename__ = "tally_ledger_maps"
    __table_args__ = (UniqueConstraint("kind", "erp_key"), CheckConstraint(_in("kind", MAP_KINDS), name="kind_valid"))

    kind: Mapped[str] = mapped_column(String(10), nullable=False)
    erp_key: Mapped[str] = mapped_column(String(80), nullable=False)   # ledger id, "output_cgst@18", party/project id
    tally_name: Mapped[str] = mapped_column(String(200), nullable=False)


class TallyJob(AuditColumnsMixin, Base):
    __tablename__ = "tally_jobs"
    __table_args__ = (CheckConstraint(_in("status", JOB_STATUSES), name="status_valid"),
                      CheckConstraint(_in("kind", JOB_KINDS), name="kind_valid"),
                      Index("ix_tally_jobs_queue", "status", "priority", "seq"),
                      Index("ix_tally_jobs_entity", "entity_type", "entity_id"))

    seq: Mapped[int] = mapped_column(BigInteger, Identity(), unique=True, nullable=False)  # queue order
    priority: Mapped[int] = mapped_column(Integer, nullable=False, default=20, server_default="20")
    kind: Mapped[str] = mapped_column(String(10), nullable=False, default="import", server_default="import")
    action: Mapped[str] = mapped_column(String(20), nullable=False)   # create | alter | cancel | masters | ledgers
    label: Mapped[str] = mapped_column(String(200), nullable=False)
    voucher_type: Mapped[str | None] = mapped_column(String(20))      # sales, receipt … (settings key)
    entity_type: Mapped[str | None] = mapped_column(String(40))
    entity_id: Mapped[uuid.UUID | None] = mapped_column()
    doc_number: Mapped[str | None] = mapped_column(String(40))
    doc_date: Mapped[date | None] = mapped_column(Date)
    depends_on_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("tally_jobs.id", ondelete="SET NULL"))
    xml: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="pending", server_default="pending")
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    leased_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    lease_batch: Mapped[uuid.UUID | None] = mapped_column()
    leased_key_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("tally_connector_keys.id", ondelete="SET NULL"))
    last_error: Mapped[str | None] = mapped_column(Text)
    tally_response: Mapped[str | None] = mapped_column(Text)
    tally_voucher_id: Mapped[str | None] = mapped_column(String(40))
    elapsed_ms: Mapped[int | None] = mapped_column(Integer)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    done_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class TallySyncRecord(AuditColumnsMixin, Base):
    """Each ERP document (or party ledger) is sent to Tally once; later changes are alters / cancels of it."""

    __tablename__ = "tally_sync_records"
    __table_args__ = (UniqueConstraint("entity_type", "entity_id"),
                      CheckConstraint(_in("state", SYNC_STATES), name="state_valid"))

    entity_type: Mapped[str] = mapped_column(String(40), nullable=False)
    entity_id: Mapped[uuid.UUID] = mapped_column(nullable=False)
    voucher_type: Mapped[str | None] = mapped_column(String(20))
    doc_number: Mapped[str | None] = mapped_column(String(40))
    tally_name: Mapped[str | None] = mapped_column(String(200))   # party ledger name, for masters
    remote_id: Mapped[str] = mapped_column(String(60), nullable=False)
    state: Mapped[str] = mapped_column(String(10), nullable=False, default="queued", server_default="queued")
    create_job_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("tally_jobs.id", ondelete="SET NULL"))
    last_job_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("tally_jobs.id", ondelete="SET NULL"))
    cancelled_in_erp: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    tally_voucher_id: Mapped[str | None] = mapped_column(String(40))
    last_error: Mapped[str | None] = mapped_column(Text)
    in_tally_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class TallyReconciliation(AuditColumnsMixin, Base):
    __tablename__ = "tally_reconciliations"
    __table_args__ = (CheckConstraint("status in ('waiting','done','failed')", name="status_valid"),)

    job_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("tally_jobs.id", ondelete="SET NULL"))
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="waiting", server_default="waiting")
    rows: Mapped[list] = mapped_column(JSONB, nullable=False, default=list, server_default="[]")
    summary: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict, server_default="{}")
    error: Mapped[str | None] = mapped_column(Text)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
