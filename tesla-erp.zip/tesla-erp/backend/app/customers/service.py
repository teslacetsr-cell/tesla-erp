"""Customer master business logic (Spec §8, §43)."""
import uuid
from typing import Any

from pydantic import ValidationError
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.core.api import ListParams, paginate
from app.core.errors import AppError, Conflict, Forbidden, NotFound
from app.core.models import check_row_version
from app.customers.models import Customer, CustomerAddress, CustomerContact, CustomerSite
from app.customers.schemas import CustomerIn, CustomerUpdate
from app.platform.audit import service as audit
from app.platform.numbering import service as numbering
from app.users.models import User


def enforce_scope(p: Principal, action: str, customer: Customer) -> None:
    """'own' scope: the user may act only on customers assigned to them (or unassigned ones they created)."""
    scope = p.scope(f"customer.{action}")
    if scope is None:
        raise Forbidden()
    if scope == "own":
        mine = customer.assigned_sales_person_id == p.id or (
            customer.assigned_sales_person_id is None and customer.created_by == p.id
        )
        if not mine:
            raise Forbidden("You can only change customers assigned to you.", code="OUT_OF_SCOPE")


def can_edit(p: Principal, customer: Customer) -> bool:
    try:
        enforce_scope(p, "update", customer)
        return True
    except Forbidden:
        return False


def list_customers(session: Session, params: ListParams, *, customer_type: str | None, status: str | None,
                   sales_person_id: uuid.UUID | None, state_code: str | None, prospect: bool | None = None):
    stmt = select(Customer)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(
            Customer.customer_name.ilike(like), Customer.customer_code.ilike(like), Customer.gstin.ilike(like),
            Customer.phone.ilike(like), Customer.email.ilike(like), Customer.city.ilike(like),
            Customer.company_name.ilike(like),
            Customer.id.in_(select(CustomerContact.customer_id).where(or_(
                CustomerContact.name.ilike(like), CustomerContact.phone.ilike(like), CustomerContact.email.ilike(like)))),
        ))
    if customer_type:
        stmt = stmt.where(Customer.customer_type == customer_type)
    if status:
        stmt = stmt.where(Customer.status == status)
    if sales_person_id:
        stmt = stmt.where(Customer.assigned_sales_person_id == sales_person_id)
    if state_code:
        stmt = stmt.where(Customer.state_code == state_code)
    if prospect is not None:
        stmt = stmt.where(Customer.is_prospect.is_(prospect))
    return paginate(session, stmt, params, default_sort=Customer.customer_name, sortable={
        "customer_name": Customer.customer_name, "customer_code": Customer.customer_code,
        "city": Customer.city, "created_at": Customer.created_at, "status": Customer.status,
    })


def sales_person_names(session: Session, ids: set[uuid.UUID]) -> dict[uuid.UUID, str]:
    if not ids:
        return {}
    return dict(session.execute(select(User.id, User.full_name).where(User.id.in_(ids))).all())


def get(session: Session, customer_id: uuid.UUID, *, lock: bool = False) -> Customer:
    c = session.get(Customer, customer_id, with_for_update=lock or None)
    if c is None:
        raise NotFound("customer")
    return c


def duplicates(session: Session, *, name: str | None, gstin: str | None, phone: str | None,
               exclude: uuid.UUID | None = None) -> list[dict[str, Any]]:
    conds = []
    if gstin:
        conds.append(Customer.gstin == gstin.upper())
    if phone:
        digits = "".join(ch for ch in phone if ch.isdigit())[-10:]
        if len(digits) == 10:
            conds.append(func.regexp_replace(Customer.phone, "[^0-9]", "", "g").like(f"%{digits}"))
    if name and len(name.strip()) >= 3:
        conds.append(func.similarity(Customer.customer_name, name) > 0.45)
    if not conds:
        return []
    stmt = select(Customer).where(or_(*conds))
    if exclude:
        stmt = stmt.where(Customer.id != exclude)
    rows = session.scalars(stmt.limit(10)).all()
    out = []
    for c in rows:
        reasons = []
        if gstin and c.gstin == gstin.upper():
            reasons.append("same GSTIN")
        if phone and c.phone and "".join(ch for ch in c.phone if ch.isdigit())[-10:] == "".join(
                ch for ch in phone if ch.isdigit())[-10:]:
            reasons.append("same phone")
        if not reasons:
            reasons.append("similar name")
        out.append({"id": str(c.id), "customer_code": c.customer_code, "customer_name": c.customer_name,
                    "gstin": c.gstin, "city": c.city, "reasons": reasons})
    return out


def _check_sales_person(session: Session, user_id: uuid.UUID | None) -> None:
    if user_id is not None:
        u = session.get(User, user_id)
        if u is None or not u.is_active:
            raise AppError("INVALID_SALES_PERSON", "The assigned salesperson must be an active user.")


def create(session: Session, p: Principal, data: CustomerIn, *, allow_duplicate: bool = False,
           source: str | None = None) -> Customer:
    _check_sales_person(session, data.assigned_sales_person_id)
    if data.gstin and not allow_duplicate:
        existing = session.scalar(select(Customer).where(Customer.gstin == data.gstin))
        if existing:
            raise Conflict("DUPLICATE_GSTIN",
                           f"{existing.customer_name} ({existing.customer_code}) already has this GSTIN.",
                           details={"customer_id": str(existing.id)})
    values = data.model_dump()
    values["is_prospect"] = bool(values.get("is_prospect")) and not values.get("gstin")
    code = (values.pop("customer_code") or "").strip().upper()
    if not code:
        code = numbering.next_free_code(session, p.company_id, "CUSTOMER", Customer.customer_code)
    elif session.scalar(select(Customer.id).where(Customer.customer_code == code)):
        raise Conflict("DUPLICATE_CODE", f"Customer code {code} is already used.")
    # A salesperson creating a customer becomes its owner unless someone else is chosen.
    if values.get("assigned_sales_person_id") is None and "SALES" in p.role_codes:
        values["assigned_sales_person_id"] = p.id
    c = Customer(customer_code=code, **values, source=source, created_by=p.id, updated_by=p.id)
    session.add(c)
    session.flush()
    audit.record(session, action="create", entity_type="customer", entity_id=c.id,
                 entity_label=f"{c.customer_code} {c.customer_name}", after=audit.snapshot(c))
    return c


def update(session: Session, p: Principal, customer_id: uuid.UUID, data: CustomerUpdate,
           *, allow_duplicate: bool = False) -> Customer:
    c = get(session, customer_id, lock=True)
    enforce_scope(p, "update", c)
    values = data.model_dump()
    new_owner = values.get("assigned_sales_person_id")
    if new_owner != c.assigned_sales_person_id:
        if p.scope("customer.update") == "own":
            raise Forbidden("Only a manager can reassign a customer to another salesperson.", code="OUT_OF_SCOPE")
        _check_sales_person(session, new_owner)
    if data.gstin and data.gstin != c.gstin and not allow_duplicate:
        existing = session.scalar(select(Customer).where(Customer.gstin == data.gstin, Customer.id != c.id))
        if existing:
            raise Conflict("DUPLICATE_GSTIN",
                           f"{existing.customer_name} ({existing.customer_code}) already has this GSTIN.",
                           details={"customer_id": str(existing.id)})
    before = audit.snapshot(c)
    check_row_version(c, values.pop("row_version"))
    code = (values.pop("customer_code") or "").strip().upper()
    if code and code != c.customer_code:
        if session.scalar(select(Customer.id).where(Customer.customer_code == code)):
            raise Conflict("DUPLICATE_CODE", f"Customer code {code} is already used.")
        c.customer_code = code
    prospect = values.pop("is_prospect")
    for k, v in values.items():
        setattr(c, k, v)
    if prospect is not None:
        c.is_prospect = prospect
    if c.is_prospect and c.gstin:  # completing the GSTIN "upgrades" a prospect to a regular customer
        c.is_prospect = False
    c.updated_by = p.id
    session.flush()
    audit.record(session, action="update", entity_type="customer", entity_id=c.id,
                 entity_label=f"{c.customer_code} {c.customer_name}", before=before, after=audit.snapshot(c))
    return c


def delete(session: Session, p: Principal, customer_id: uuid.UUID) -> None:
    """Hard delete only when nothing references the customer; otherwise the caller gets IN_USE (deactivate)."""
    c = get(session, customer_id, lock=True)
    enforce_scope(p, "delete", c)
    snap = audit.snapshot(c)
    label = f"{c.customer_code} {c.customer_name}"
    with session.begin_nested():
        session.delete(c)
        session.flush()
    audit.record(session, action="delete", entity_type="customer", entity_id=customer_id, entity_label=label,
                 before=snap)


# ------------------------------------------------------------------ child records
CHILD_MODELS = {"contacts": CustomerContact, "addresses": CustomerAddress, "sites": CustomerSite}
CHILD_ENTITY = {"contacts": "customer_contact", "addresses": "customer_address", "sites": "customer_site"}


def _child_label(obj) -> str:
    return getattr(obj, "name", None) or getattr(obj, "site_name", None) or getattr(obj, "label", None) or \
        getattr(obj, "address_line1", None) or str(obj.id)


def add_child(session: Session, p: Principal, customer_id: uuid.UUID, kind: str, data) -> Any:
    c = get(session, customer_id, lock=True)
    enforce_scope(p, "update", c)
    model = CHILD_MODELS[kind]
    obj = model(customer_id=c.id, **data.model_dump(), created_by=p.id, updated_by=p.id)
    if kind == "contacts" and obj.is_primary:
        for other in c.contacts:
            other.is_primary = False
    session.add(obj)
    session.flush()
    audit.record(session, action="create", entity_type=CHILD_ENTITY[kind], entity_id=obj.id,
                 entity_label=f"{c.customer_code}: {_child_label(obj)}", after=audit.snapshot(obj))
    return obj


def update_child(session: Session, p: Principal, customer_id: uuid.UUID, kind: str, child_id: uuid.UUID, data) -> Any:
    c = get(session, customer_id, lock=True)
    enforce_scope(p, "update", c)
    obj = session.get(CHILD_MODELS[kind], child_id)
    if obj is None or obj.customer_id != c.id:
        raise NotFound(CHILD_ENTITY[kind])
    before = audit.snapshot(obj)
    values = data.model_dump()
    check_row_version(obj, values.pop("row_version"))
    for k, v in values.items():
        setattr(obj, k, v)
    if kind == "contacts" and obj.is_primary:
        for other in c.contacts:
            if other.id != obj.id:
                other.is_primary = False
    obj.updated_by = p.id
    session.flush()
    audit.record(session, action="update", entity_type=CHILD_ENTITY[kind], entity_id=obj.id,
                 entity_label=f"{c.customer_code}: {_child_label(obj)}", before=before, after=audit.snapshot(obj))
    return obj


def delete_child(session: Session, p: Principal, customer_id: uuid.UUID, kind: str, child_id: uuid.UUID) -> None:
    c = get(session, customer_id, lock=True)
    enforce_scope(p, "update", c)
    obj = session.get(CHILD_MODELS[kind], child_id)
    if obj is None or obj.customer_id != c.id:
        raise NotFound(CHILD_ENTITY[kind])
    snap, label = audit.snapshot(obj), _child_label(obj)
    with session.begin_nested():
        session.delete(obj)
        session.flush()
    audit.record(session, action="delete", entity_type=CHILD_ENTITY[kind], entity_id=child_id,
                 entity_label=f"{c.customer_code}: {label}", before=snap)


# ------------------------------------------------------------------ import
def import_rows(session: Session, p: Principal, rows: list[tuple[int, dict]], *, commit: bool) -> dict:
    """Validate every row first. Nothing is saved unless every row is valid (all-or-nothing)."""
    errors: list[dict] = []
    valid: list[CustomerIn] = []
    seen_codes: set[str] = set()
    seen_gstins: set[str] = set()
    owners = {u.email.lower(): u.id for u in session.scalars(select(User).where(User.is_active.is_(True)))}
    for n, raw in rows:
        raw = dict(raw)
        owner_email = (raw.pop("sales_person_email", None) or "").lower()
        if owner_email:
            if owner_email not in owners:
                errors.append({"row": n, "field": "Sales person email", "message": "No active user with this email."})
                continue
            raw["assigned_sales_person_id"] = owners[owner_email]
        for k in ("customer_type", "status"):
            if isinstance(raw.get(k), str):
                raw[k] = raw[k].strip().lower()
        for k in ("phone", "pincode", "state_code", "customer_code"):
            if raw.get(k) is not None:
                raw[k] = str(raw[k])
        try:
            item = CustomerIn.model_validate({k: v for k, v in raw.items() if v is not None})
        except ValidationError as exc:
            for e in exc.errors():
                errors.append({"row": n, "field": ".".join(str(x) for x in e["loc"]), "message": e["msg"]})
            continue
        if item.customer_code:
            code = item.customer_code.upper()
            if code in seen_codes or session.scalar(select(Customer.id).where(Customer.customer_code == code)):
                errors.append({"row": n, "field": "customer_code", "message": f"Code {code} already exists."})
                continue
            seen_codes.add(code)
        if item.gstin:
            if item.gstin in seen_gstins or session.scalar(select(Customer.id).where(Customer.gstin == item.gstin)):
                errors.append({"row": n, "field": "gstin", "message": "A customer with this GSTIN already exists."})
                continue
            seen_gstins.add(item.gstin)
        valid.append(item)
    created = 0
    if commit and not errors:
        for item in valid:
            create(session, p, item, allow_duplicate=True)
            created += 1
    return {"rows": len(rows), "valid": len(valid), "errors": errors, "created": created,
            "committed": commit and not errors}
