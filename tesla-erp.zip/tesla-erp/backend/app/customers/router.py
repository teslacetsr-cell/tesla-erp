import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, File, Query, UploadFile
from fastapi.responses import Response
from sqlalchemy import select

from app.auth.deps import Principal, require
from app.core import excel
from app.core.api import ListParams, ok
from app.core.db import DbSession
from app.customers import service
from app.customers.models import CUSTOMER_STATUSES, CUSTOMER_TYPES, Customer
from app.customers.schemas import (
    AddressOut,
    ContactIn,
    ContactOut,
    ContactUpdate,
    CustomerAddressIn,
    CustomerAddressUpdate,
    CustomerIn,
    CustomerListOut,
    CustomerOut,
    CustomerUpdate,
    SiteIn,
    SiteOut,
    SiteUpdate,
)
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.users.models import User

router = APIRouter(prefix="/customers", tags=["customers"])
documents.register_entity("customer", "customer", Customer)

COLUMNS = [
    excel.Column("customer_code", "Customer code", 14, note="Leave blank to auto-number"),
    excel.Column("customer_name", "Customer name", 32, required=True),
    excel.Column("customer_type", "Type", 14, choices=CUSTOMER_TYPES),
    excel.Column("company_name", "Company name", 28),
    excel.Column("gstin", "GSTIN", 18),
    excel.Column("pan", "PAN", 12),
    excel.Column("phone", "Phone", 16),
    excel.Column("email", "Email", 26),
    excel.Column("website", "Website", 22),
    excel.Column("address_line1", "Address line 1", 30),
    excel.Column("address_line2", "Address line 2", 30),
    excel.Column("city", "City", 16),
    excel.Column("district", "District", 16),
    excel.Column("state", "State", 16),
    excel.Column("state_code", "State code", 10, note="GST state code, e.g. 32 for Kerala"),
    excel.Column("pincode", "PIN code", 10),
    excel.Column("default_payment_terms", "Payment terms", 30),
    excel.Column("credit_limit", "Credit limit", 14),
    excel.Column("credit_days", "Credit days", 10),
    excel.Column("sales_person_email", "Sales person email", 26, note="Email of an ERP user"),
    excel.Column("status", "Status", 10, choices=CUSTOMER_STATUSES),
]


def _detail(db, p: Principal, c: Customer) -> dict:
    out = CustomerOut.model_validate(c).model_dump(mode="json")
    names = service.sales_person_names(db, {c.assigned_sales_person_id} - {None})
    out["assigned_sales_person"] = names.get(c.assigned_sales_person_id)
    out["can_edit"] = service.can_edit(p, c)
    return out


@router.get("")
def list_customers(db: DbSession, _: Annotated[Principal, require("customer.read")],
                   params: Annotated[ListParams, Depends()], customer_type: str | None = None,
                   status: str | None = None, sales_person_id: uuid.UUID | None = None,
                   state_code: str | None = None, prospect: bool | None = None):
    rows, meta = service.list_customers(db, params, customer_type=customer_type, status=status,
                                        sales_person_id=sales_person_id, state_code=state_code, prospect=prospect)
    names = service.sales_person_names(db, {r.assigned_sales_person_id for r in rows} - {None})
    data = []
    for r in rows:
        d = CustomerListOut.model_validate(r).model_dump(mode="json")
        d["assigned_sales_person"] = names.get(r.assigned_sales_person_id)
        data.append(d)
    return {"data": data, "meta": meta.model_dump()}


@router.get("/sales-people")
def sales_people(db: DbSession, _: Annotated[Principal, require("customer.read")]):
    """Active users who can own customers (Sales, Managers, Directors) — for the salesperson picker."""
    from app.users.models import Role, UserRole

    rows = db.execute(
        select(User.id, User.full_name).join(UserRole, UserRole.user_id == User.id).join(Role, Role.id == UserRole.role_id)
        .where(User.is_active.is_(True), Role.code.in_(["SALES", "MANAGER", "DIRECTOR"]))
        .distinct().order_by(User.full_name)
    ).all()
    return ok([{"id": str(i), "name": n} for i, n in rows])


@router.get("/duplicate-check")
def duplicate_check(db: DbSession, _: Annotated[Principal, require("customer.read")],
                    name: str | None = Query(None, max_length=200), gstin: str | None = Query(None, max_length=15),
                    phone: str | None = Query(None, max_length=30), exclude: uuid.UUID | None = None):
    return ok(service.duplicates(db, name=name, gstin=gstin, phone=phone, exclude=exclude))


@router.get("/import-template")
def import_template(_: Annotated[Principal, require("customer.create")]):
    data = excel.template("Customers", COLUMNS, example={
        "customer_name": "ABC Hospital", "customer_type": "hospital", "gstin": "32AABCA1234A1Z5",
        "phone": "0487 2330000", "city": "Thrissur", "state_code": "32", "pincode": "680001", "status": "active"})
    return Response(data, media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="customer-import-template.xlsx"'})


@router.post("/import")
async def import_customers(db: DbSession, p: Annotated[Principal, require("customer.create")],
                           file: UploadFile = File(...), dry_run: bool = Query(True)):
    rows = excel.read(await file.read(), COLUMNS)
    report = service.import_rows(db, p, rows, commit=not dry_run)
    if report["committed"]:
        audit.record(db, action="import", entity_type="customer", summary=f"Imported {report['created']} customers")
    return ok(report)


@router.get("/export")
def export_customers(db: DbSession, p: Annotated[Principal, require("customer.export")],
                     params: Annotated[ListParams, Depends()], customer_type: str | None = None,
                     status: str | None = None):
    params.page, params.page_size = 1, 100000
    rows, _ = service.list_customers(db, params, customer_type=customer_type, status=status, sales_person_id=None,
                                     state_code=None)
    emails = dict(db.execute(select(User.id, User.email)).all())
    data = [{**{c.key: getattr(r, c.key, None) for c in COLUMNS},
             "sales_person_email": emails.get(r.assigned_sales_person_id)} for r in rows]
    audit.record(db, action="export", entity_type="customer", summary=f"Exported {len(data)} customers")
    return Response(excel.export("Customers", COLUMNS, data), media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="customers.xlsx"'})


@router.post("", status_code=201)
def create_customer(body: CustomerIn, db: DbSession, p: Annotated[Principal, require("customer.create")],
                    allow_duplicate: bool = Query(False)):
    return ok(_detail(db, p, service.create(db, p, body, allow_duplicate=allow_duplicate)))


@router.get("/{customer_id}")
def get_customer(customer_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("customer.read")]):
    return ok(_detail(db, p, service.get(db, customer_id)))


@router.put("/{customer_id}")
def update_customer(customer_id: uuid.UUID, body: CustomerUpdate, db: DbSession,
                    p: Annotated[Principal, require("customer.update")], allow_duplicate: bool = Query(False)):
    return ok(_detail(db, p, service.update(db, p, customer_id, body, allow_duplicate=allow_duplicate)))


@router.delete("/{customer_id}")
def delete_customer(customer_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("customer.delete")]):
    service.delete(db, p, customer_id)
    return ok({"ok": True})


# ---- contacts / addresses / sites
def _child_routes(kind: str, in_schema, update_schema, out_schema):
    @router.post(f"/{{customer_id}}/{kind}", status_code=201, name=f"add_customer_{kind}")
    def add(customer_id: uuid.UUID, body: in_schema, db: DbSession,  # type: ignore[valid-type]
            p: Annotated[Principal, require("customer.update")]):
        return ok(out_schema.model_validate(service.add_child(db, p, customer_id, kind, body)).model_dump(mode="json"))

    @router.put(f"/{{customer_id}}/{kind}/{{child_id}}", name=f"update_customer_{kind}")
    def upd(customer_id: uuid.UUID, child_id: uuid.UUID, body: update_schema, db: DbSession,  # type: ignore[valid-type]
            p: Annotated[Principal, require("customer.update")]):
        obj = service.update_child(db, p, customer_id, kind, child_id, body)
        return ok(out_schema.model_validate(obj).model_dump(mode="json"))

    @router.delete(f"/{{customer_id}}/{kind}/{{child_id}}", name=f"delete_customer_{kind}")
    def rm(customer_id: uuid.UUID, child_id: uuid.UUID, db: DbSession,
           p: Annotated[Principal, require("customer.update")]):
        service.delete_child(db, p, customer_id, kind, child_id)
        return ok({"ok": True})


_child_routes("contacts", ContactIn, ContactUpdate, ContactOut)
_child_routes("addresses", CustomerAddressIn, CustomerAddressUpdate, AddressOut)
_child_routes("sites", SiteIn, SiteUpdate, SiteOut)
