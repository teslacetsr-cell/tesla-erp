from app.core.permissions import register

# update/delete support scope: a salesperson may edit only customers assigned to them.
register("customer", "Customers", ("create", "read", "update", "delete", "export", "print"), scoped=("update", "delete"))
