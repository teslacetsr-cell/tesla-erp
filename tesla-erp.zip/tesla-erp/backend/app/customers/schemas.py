import uuid
from datetime import datetime
from decimal import Decimal
from typing import Literal

from pydantic import EmailStr, Field, model_validator

from app.core.api import Schema
from app.core.money import Money
from app.core.validators import GSTIN, PAN, Phone, Pincode, StateCode, Text, check_tax_identity
from app.customers.models import CUSTOMER_STATUSES, CUSTOMER_TYPES

CustomerType = Literal[CUSTOMER_TYPES]  # type: ignore[valid-type]
CustomerStatus = Literal[CUSTOMER_STATUSES]  # type: ignore[valid-type]


class AddressIn(Schema):
    address_line1: Text(200) = None
    address_line2: Text(200) = None
    city: Text(100) = None
    district: Text(100) = None
    state: Text(100) = None
    state_code: StateCode = None
    pincode: Pincode = None
    country: str = Field(default="India", max_length=60)


class CustomerIn(AddressIn):
    customer_code: Text(20) = Field(default=None, description="Leave blank to auto-number")
    customer_name: str = Field(min_length=2, max_length=200)
    customer_type: CustomerType = "company"
    company_name: Text(200) = None
    gstin: GSTIN = None
    pan: PAN = None
    phone: Phone = None
    email: EmailStr | None = None
    website: Text(200) = None
    default_payment_terms: Text(300) = None
    credit_limit: Decimal | None = Field(default=None, ge=0, max_digits=18, decimal_places=2)
    credit_days: int | None = Field(default=None, ge=0, le=365)
    assigned_sales_person_id: uuid.UUID | None = None
    status: CustomerStatus = "active"
    notes: Text(4000) = None

    @model_validator(mode="after")
    def _identity(self):
        for k, v in check_tax_identity(self.gstin, self.pan, self.state_code).items():
            setattr(self, k, v)
        return self


class CustomerUpdate(CustomerIn):
    row_version: int


class ContactIn(Schema):
    name: str = Field(min_length=2, max_length=150)
    designation: Text(100) = None
    phone: Phone = None
    email: EmailStr | None = None
    is_primary: bool = False
    is_active: bool = True


class ContactUpdate(ContactIn):
    row_version: int


class CustomerAddressIn(AddressIn):
    address_type: Literal["shipping", "delivery", "office", "other"] = "shipping"
    label: Text(100) = None
    gstin: GSTIN = None
    is_active: bool = True

    @model_validator(mode="after")
    def _identity(self):
        for k, v in check_tax_identity(self.gstin, None, self.state_code).items():
            if k != "pan":
                setattr(self, k, v)
        return self


class CustomerAddressUpdate(CustomerAddressIn):
    row_version: int


class SiteIn(AddressIn):
    site_name: str = Field(min_length=2, max_length=200)
    contact_name: Text(150) = None
    contact_phone: Phone = None
    latitude: Decimal | None = Field(default=None, ge=-90, le=90, decimal_places=6)
    longitude: Decimal | None = Field(default=None, ge=-180, le=180, decimal_places=6)
    notes: Text(2000) = None
    is_active: bool = True

    @model_validator(mode="after")
    def _state(self):
        for k, v in check_tax_identity(None, None, self.state_code).items():
            setattr(self, k, v)
        return self


class SiteUpdate(SiteIn):
    row_version: int


class _Child(Schema):
    id: uuid.UUID
    row_version: int
    is_active: bool


class ContactOut(_Child):
    name: str
    designation: str | None
    phone: str | None
    email: str | None
    is_primary: bool


class AddressOut(_Child):
    address_type: str
    label: str | None
    gstin: str | None
    address_line1: str | None
    address_line2: str | None
    city: str | None
    district: str | None
    state: str | None
    state_code: str | None
    pincode: str | None
    country: str


class SiteOut(_Child):
    site_name: str
    contact_name: str | None
    contact_phone: str | None
    address_line1: str | None
    address_line2: str | None
    city: str | None
    district: str | None
    state: str | None
    state_code: str | None
    pincode: str | None
    country: str
    latitude: Decimal | None
    longitude: Decimal | None
    notes: str | None


class CustomerListOut(Schema):
    id: uuid.UUID
    customer_code: str
    customer_name: str
    customer_type: str
    gstin: str | None
    phone: str | None
    email: str | None
    city: str | None
    state: str | None
    status: str
    assigned_sales_person_id: uuid.UUID | None
    assigned_sales_person: str | None = None
    created_at: datetime


class CustomerOut(CustomerListOut):
    company_name: str | None
    pan: str | None
    website: str | None
    address_line1: str | None
    address_line2: str | None
    district: str | None
    state_code: str | None
    pincode: str | None
    country: str
    default_payment_terms: str | None
    credit_limit: Money | None
    credit_days: int | None
    notes: str | None
    row_version: int
    updated_at: datetime
    contacts: list[ContactOut]
    addresses: list[AddressOut]
    sites: list[SiteOut]
    can_edit: bool = False
