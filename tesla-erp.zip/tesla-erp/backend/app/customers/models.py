import uuid
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, ForeignKey, Index, Numeric, SmallInteger, String, Text
from sqlalchemy.dialects.postgresql import CITEXT
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.models import AuditColumnsMixin, Base
from app.core.money import AMOUNT

CUSTOMER_TYPES = ("individual", "company", "government", "hospital", "builder", "consultant", "contractor",
                  "institution", "other")
CUSTOMER_STATUSES = ("active", "inactive", "blocked")


class AddressColumns:
    address_line1: Mapped[str | None] = mapped_column(String(200))
    address_line2: Mapped[str | None] = mapped_column(String(200))
    city: Mapped[str | None] = mapped_column(String(100))
    district: Mapped[str | None] = mapped_column(String(100))
    state: Mapped[str | None] = mapped_column(String(100))
    state_code: Mapped[str | None] = mapped_column(String(2))  # GST state code → place of supply
    pincode: Mapped[str | None] = mapped_column(String(6))
    country: Mapped[str] = mapped_column(String(60), nullable=False, default="India", server_default="India")


class Customer(AuditColumnsMixin, AddressColumns, Base):
    """The one customer master (Spec §8, §43). Every other module references it by id.

    The address columns here are the billing address.
    """

    __tablename__ = "customers"
    __table_args__ = (
        CheckConstraint(f"customer_type in {CUSTOMER_TYPES}", name="type_valid"),
        CheckConstraint(f"status in {CUSTOMER_STATUSES}", name="status_valid"),
        CheckConstraint("credit_limit is null or credit_limit >= 0", name="credit_limit_nonneg"),
        Index("ix_customers_name_trgm", "customer_name", postgresql_using="gin",
              postgresql_ops={"customer_name": "gin_trgm_ops"}),
        Index("ix_customers_gstin", "gstin"),
    )

    customer_code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    customer_name: Mapped[str] = mapped_column(String(200), nullable=False)
    customer_type: Mapped[str] = mapped_column(String(20), nullable=False, default="company")
    company_name: Mapped[str | None] = mapped_column(String(200))
    gstin: Mapped[str | None] = mapped_column(String(15))
    pan: Mapped[str | None] = mapped_column(String(10))
    phone: Mapped[str | None] = mapped_column(String(30))
    email: Mapped[str | None] = mapped_column(CITEXT)
    website: Mapped[str | None] = mapped_column(String(200))
    default_payment_terms: Mapped[str | None] = mapped_column(String(300))
    credit_limit: Mapped[Decimal | None] = mapped_column(AMOUNT)
    credit_days: Mapped[int | None] = mapped_column(SmallInteger)
    assigned_sales_person_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="active", server_default="active")
    notes: Mapped[str | None] = mapped_column(Text)

    contacts: Mapped[list["CustomerContact"]] = relationship(
        back_populates="customer", cascade="all, delete-orphan", order_by="CustomerContact.created_at", lazy="selectin")
    addresses: Mapped[list["CustomerAddress"]] = relationship(
        back_populates="customer", cascade="all, delete-orphan", order_by="CustomerAddress.created_at", lazy="selectin")
    sites: Mapped[list["CustomerSite"]] = relationship(
        back_populates="customer", cascade="all, delete-orphan", order_by="CustomerSite.created_at", lazy="selectin")


class CustomerContact(AuditColumnsMixin, Base):
    __tablename__ = "customer_contacts"

    customer_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("customers.id", ondelete="CASCADE"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    designation: Mapped[str | None] = mapped_column(String(100))
    phone: Mapped[str | None] = mapped_column(String(30))
    email: Mapped[str | None] = mapped_column(CITEXT)
    is_primary: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")

    customer: Mapped[Customer] = relationship(back_populates="contacts")


class CustomerAddress(AuditColumnsMixin, AddressColumns, Base):
    """Additional addresses (shipping/delivery/other). The billing address lives on the customer row."""

    __tablename__ = "customer_addresses"
    __table_args__ = (CheckConstraint("address_type in ('shipping','delivery','office','other')", name="type_valid"),)

    customer_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("customers.id", ondelete="CASCADE"), nullable=False, index=True)
    address_type: Mapped[str] = mapped_column(String(20), nullable=False, default="shipping")
    label: Mapped[str | None] = mapped_column(String(100))
    gstin: Mapped[str | None] = mapped_column(String(15))  # a customer may be registered in several states
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")

    customer: Mapped[Customer] = relationship(back_populates="addresses")


class CustomerSite(AuditColumnsMixin, AddressColumns, Base):
    """A physical site where work happens. One customer can have many (Spec §8)."""

    __tablename__ = "customer_sites"

    customer_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("customers.id", ondelete="CASCADE"), nullable=False, index=True)
    site_name: Mapped[str] = mapped_column(String(200), nullable=False)
    contact_name: Mapped[str | None] = mapped_column(String(150))
    contact_phone: Mapped[str | None] = mapped_column(String(30))
    latitude: Mapped[Decimal | None] = mapped_column(Numeric(9, 6))
    longitude: Mapped[Decimal | None] = mapped_column(Numeric(9, 6))
    notes: Mapped[str | None] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")

    customer: Mapped[Customer] = relationship(back_populates="sites")
