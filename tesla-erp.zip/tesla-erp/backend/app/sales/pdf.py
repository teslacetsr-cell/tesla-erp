"""Sales order acknowledgement PDF: the confirmed order as agreed — lines, GST, totals and terms."""
import io
from collections import defaultdict
from decimal import Decimal
from html import escape

from reportlab.lib.units import mm
from reportlab.platypus import KeepTogether, ListFlowable, ListItem, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from sqlalchemy.orm import Session

from app.boq.pdf import lines_table, totals_table
from app.core.gst import amount_in_words
from app.platform import pdfkit as K
from app.sales.models import SalesOrder


def _date(d) -> str:
    return d.strftime("%d %b %Y") if d else "—"


def _rate(r: Decimal) -> str:
    return f"{r.normalize():f}"


def build(db: Session, so: SalesOrder) -> bytes:
    K.fonts()
    st = K.styles()
    cust = so.customer_snapshot or {}
    story = K.letterhead(db, st)
    head = Table([[Paragraph("ORDER ACKNOWLEDGEMENT", st["title"]), Paragraph(
        f"<b>SO No.</b> {escape(so.so_number)}<br/><b>Date</b> {_date(so.so_date)}"
        + (f"<br/><b>Our quotation</b> {escape(so.quotation_number)}" if so.quotation_number else ""),
        st["right"])]], colWidths=[None, 75 * mm])
    head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "BOTTOM"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                              ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    story += [head, Spacer(1, 3 * mm)]
    to = [Paragraph("Customer", st["label"]), Paragraph(f"<b>{escape(cust.get('name') or '')}</b>", st["base"])]
    to += [Paragraph(escape(a), st["base"]) for a in cust.get("address") or []]
    if cust.get("gstin"):
        to.append(Paragraph(f"GSTIN {escape(cust['gstin'])}", st["base"]))
    right = []
    if so.customer_po_number:
        right += [Paragraph("Your order", st["label"]),
                  Paragraph(f"{escape(so.customer_po_number)}"
                            + (f" dated {_date(so.customer_po_date)}" if so.customer_po_date else ""), st["base"])]
    if cust.get("site"):
        right += [Spacer(1, 1.5 * mm), Paragraph("Project site", st["label"]),
                  Paragraph(escape(cust["site"]["name"]), st["base"])]
        if cust["site"].get("address"):
            right.append(Paragraph(escape(cust["site"]["address"]), st["small"]))
    if so.expected_completion:
        right += [Spacer(1, 1.5 * mm), Paragraph("Expected completion", st["label"]),
                  Paragraph(_date(so.expected_completion), st["base"])]
    right += [Spacer(1, 1.5 * mm), Paragraph(
        f"Place of supply: {escape(cust.get('place_of_supply') or so.place_of_supply or '—')} · "
        f"{'Inter-state (IGST)' if so.inter_state else 'Intra-state (CGST + SGST)'}", st["small"])]
    box = Table([[to, right]], colWidths=[92 * mm, None])
    box.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("BOX", (0, 0), (-1, -1), 0.5, K.LINE),
                             ("LINEAFTER", (0, 0), (0, 0), 0.5, K.LINE), ("TOPPADDING", (0, 0), (-1, -1), 5),
                             ("BOTTOMPADDING", (0, 0), (-1, -1), 5), ("LEFTPADDING", (0, 0), (-1, -1), 6)]))
    story += [box, Spacer(1, 3 * mm), Paragraph(f"<b>Subject:</b> {escape(so.subject)}", st["base"]),
              Spacer(1, 2 * mm),
              K.p("We thank you for your order and confirm acceptance on the terms below.", st["base"]),
              Spacer(1, 3 * mm), lines_table(so.items, st), Spacer(1, 3 * mm)]
    by_rate: dict[Decimal, dict] = defaultdict(lambda: {"cgst": Decimal(0), "sgst": Decimal(0), "igst": Decimal(0)})
    for it in so.items:
        for k in ("cgst", "sgst", "igst"):
            by_rate[it.tax_rate][k] += getattr(it, k)
    rows = [("Total", K.money(so.gross), False)]
    if so.line_discount:
        rows.append(("Less: discount", "− " + K.money(so.line_discount), False))
    if so.special_discount:
        rows.append(("Less: special discount", "− " + K.money(so.special_discount), False))
    rows.append(("Taxable value", K.money(so.taxable), True))
    for rate in sorted(by_rate):
        t = by_rate[rate]
        if so.inter_state and t["igst"]:
            rows.append((f"IGST @ {_rate(rate)} %", K.money(t["igst"]), False))
        elif not so.inter_state and t["cgst"]:
            half = _rate(rate / 2)
            rows += [(f"CGST @ {half} %", K.money(t["cgst"]), False), (f"SGST @ {half} %", K.money(t["sgst"]), False)]
    if so.round_off:
        rows.append(("Round off", ("+ " if so.round_off > 0 else "− ") + K.money(abs(so.round_off)), False))
    rows.append(("Order value (₹)", K.money(so.grand_total), True))
    story.append(KeepTogether([totals_table(rows, st, width=95 * mm), Spacer(1, 1.5 * mm),
                               Paragraph(f"<b>In words:</b> {escape(amount_in_words(so.grand_total))}", st["base"])]))
    commercial = [("Payment", so.payment_terms), ("Delivery", so.delivery_terms), ("Warranty", so.warranty)]
    rows = [[Paragraph(f"<b>{k}</b>", st["cell"]), K.p(v, st["cell"])] for k, v in commercial if v]
    if rows:
        ct = Table(rows, colWidths=[28 * mm, None])
        ct.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, -1), 0.3, K.LINE),
                                ("LEFTPADDING", (0, 0), (-1, -1), 2)]))
        story += [Paragraph("Commercial terms", st["h"]), ct]
    if so.terms:
        story += [Paragraph("Terms and conditions", st["h"]),
                  ListFlowable([ListItem(K.p(t, st["base"]), leftIndent=10) for t in so.terms], bulletType="1",
                               bulletFontName="DejaVu", bulletFontSize=8, leftIndent=12)]
    company = K.company_snapshot(db)
    name = (company or {}).get("company_name") or "Tesla Consulting Engineers"
    story.append(KeepTogether([Spacer(1, 6 * mm), Paragraph(f"For <b>{escape(name)}</b>", st["base"]),
                               Spacer(1, 14 * mm), Paragraph("Authorised Signatory", st["base"])]))
    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=K.PAGE, leftMargin=K.MARGIN, rightMargin=K.MARGIN, topMargin=10 * mm,
                      bottomMargin=14 * mm, title=f"Sales order {so.so_number}", author=name).build(
        story, canvasmaker=K.numbered_canvas(f"Sales order {so.so_number}",
                                             "CANCELLED" if so.status == "cancelled" else None))
    return buf.getvalue()
