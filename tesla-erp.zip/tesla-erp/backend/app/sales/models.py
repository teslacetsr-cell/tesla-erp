"""Sales orders (Spec §15): created from the ACCEPTED revision of a quotation, inheriting its lines, prices, taxes
and terms exactly. Commercial content (lines, rates, discounts, terms) can only be changed by users holding
`sales_order_commercial.update`, with a reason, and every such change is audited."""
import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, SmallInteger, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.boq.models import LineColumns
from app.core.models import AuditColumnsMixin, Base
from app.core.money import AMOUNT

SO_STATUSES = ("confirmed", "in_progress", "completed", "cancelled")


class SalesOrder(AuditColumnsMixin, Base):
    __tablename__ = "sales_orders"
    __table_args__ = (
        CheckConstraint("status in ('confirmed','in_progress','completed','cancelled')", name="status_valid"),
        Index("ix_sales_orders_customer_id", "customer_id"), Index("ix_sales_orders_status", "status"),
    )

    so_number: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    quotation_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("quotations.id", ondelete="RESTRICT"), unique=True)
    quotation_revision_no: Mapped[int | None] = mapped_column(SmallInteger)
    quotation_number: Mapped[str | None] = mapped_column(String(40))
    customer_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("customers.id", ondelete="RESTRICT"), nullable=False)
    enquiry_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("enquiries.id", ondelete="RESTRICT"))
    site_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("customer_sites.id", ondelete="RESTRICT"))
    contact_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("customer_contacts.id", ondelete="SET NULL"))
    division_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("business_divisions.id", ondelete="RESTRICT"))
    sales_person_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    subject: Mapped[str] = mapped_column(String(200), nullable=False)
    so_date: Mapped[date] = mapped_column(Date, nullable=False)
    customer_po_number: Mapped[str | None] = mapped_column(String(60))
    customer_po_date: Mapped[date | None] = mapped_column(Date)
    expected_completion: Mapped[date | None] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="confirmed", server_default="confirmed")
    status_reason: Mapped[str | None] = mapped_column(String(500))
    notes: Mapped[str | None] = mapped_column(Text)
    # commercial content (locked)
    place_of_supply: Mapped[str | None] = mapped_column(String(2))
    inter_state: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    payment_terms: Mapped[str | None] = mapped_column(Text)
    delivery_terms: Mapped[str | None] = mapped_column(Text)
    warranty: Mapped[str | None] = mapped_column(Text)
    terms: Mapped[list] = mapped_column(JSONB, nullable=False, default=list, server_default="[]")
    special_discount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    gross: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    line_discount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    taxable: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    cgst: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    sgst: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    igst: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    round_off: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    grand_total: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    customer_snapshot: Mapped[dict | None] = mapped_column(JSONB)
    commercial_changed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    items: Mapped[list["SalesOrderItem"]] = relationship(order_by="SalesOrderItem.line_no", cascade="all, delete-orphan",
                                                         lazy="selectin")


class SalesOrderItem(AuditColumnsMixin, LineColumns, Base):
    __tablename__ = "sales_order_items"

    sales_order_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("sales_orders.id", ondelete="CASCADE"), nullable=False,
                                                      index=True)
    special_discount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
