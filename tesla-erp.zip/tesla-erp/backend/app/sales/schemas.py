from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import Field

from app.boq.lines import LineIn
from app.core.api import Schema
from app.core.validators import Text


class FromQuotationIn(Schema):
    so_date: date | None = None
    customer_po_number: Text(60) = None
    customer_po_date: date | None = None
    expected_completion: date | None = None
    notes: Text(4000) = None


class SalesOrderUpdate(Schema):
    customer_po_number: Text(60) = None
    customer_po_date: date | None = None
    expected_completion: date | None = None
    notes: Text(4000) = None
    row_version: int


class CommercialIn(Schema):
    items: list[LineIn] = Field(min_length=1, max_length=1000)
    special_discount: Decimal = Field(default=Decimal("0"), ge=0, max_digits=18, decimal_places=2)
    payment_terms: Text(2000) = None
    delivery_terms: Text(2000) = None
    warranty: Text(2000) = None
    terms: list[str] = Field(default_factory=list, max_length=40)
    reason: str = Field(min_length=5, max_length=500, description="Why the confirmed order is being changed")
    row_version: int


class SoStatusIn(Schema):
    status: Literal["in_progress", "completed", "cancelled"]
    reason: Text(500) = None
