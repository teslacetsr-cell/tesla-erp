"""Sales order rules (Spec §15)."""
import uuid

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.boq import lines as L
from app.core.api import ListParams, paginate
from app.core.errors import AppError, Conflict, Forbidden, NotFound
from app.core.models import check_row_version
from app.core.money import round_amount
from app.crm.service import now, today
from app.customers.models import Customer
from app.platform.audit import service as audit
from app.platform.numbering import service as numbering
from app.quotations import service as quotations
from app.quotations.models import Quotation
from app.sales.models import SalesOrder, SalesOrderItem

LINE_FIELDS = ("line_no", "section", "item_id", "description", "technical_specification", "hsn_sac", "quantity", "unit",
               "rate", "discount_pct", "tax_rate", "amount", "discount_amount", "special_discount", "taxable", "cgst",
               "sgst", "igst", "total", "remarks")
TOTALS = ("gross", "line_discount", "special_discount", "taxable", "cgst", "sgst", "igst", "round_off", "grand_total")


def check(p: Principal, so: SalesOrder, action: str) -> None:
    scope = p.scope(f"sales_order.{action}")
    if scope is None:
        raise Forbidden()
    if scope == "own" and p.id not in (so.sales_person_id, so.created_by):
        raise Forbidden("You can only work on sales orders assigned to you.", code="OUT_OF_SCOPE")


def allowed(p: Principal, so: SalesOrder, action: str) -> bool:
    try:
        check(p, so, action)
        return True
    except Forbidden:
        return False


def get(db: Session, so_id: uuid.UUID, lock: bool = False) -> SalesOrder:
    so = db.get(SalesOrder, so_id, with_for_update=lock or None)
    if so is None:
        raise NotFound("sales_order")
    return so


def list_orders(db: Session, p: Principal, params: ListParams, *, status=None, customer_id=None):
    stmt = select(SalesOrder)
    scope = p.scope("sales_order.read")
    if scope is None:
        raise Forbidden()
    if scope == "own":
        stmt = stmt.where(or_(SalesOrder.sales_person_id == p.id, SalesOrder.created_by == p.id))
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(SalesOrder.so_number.ilike(like), SalesOrder.subject.ilike(like),
                              SalesOrder.customer_po_number.ilike(like), SalesOrder.quotation_number.ilike(like),
                              SalesOrder.customer_id.in_(select(Customer.id).where(Customer.customer_name.ilike(like)))))
    if status:
        stmt = stmt.where(SalesOrder.status == status)
    if customer_id:
        stmt = stmt.where(SalesOrder.customer_id == customer_id)
    return paginate(db, stmt, params, default_sort=SalesOrder.created_at.desc(), sortable={
        "so_number": SalesOrder.so_number, "so_date": SalesOrder.so_date, "grand_total": SalesOrder.grand_total,
        "status": SalesOrder.status, "created_at": SalesOrder.created_at})


def create_from_quotation(db: Session, p: Principal, quotation_id: uuid.UUID, data) -> SalesOrder:
    """Copies the ACCEPTED revision exactly: every line, price, tax and total, the terms and the customer details
    frozen when it was sent."""
    q: Quotation = quotations.get(db, quotation_id, lock=True)
    quotations.check(p, q, "read")
    if q.status != "accepted" or q.accepted_revision_no is None:
        raise AppError("NOT_ACCEPTED", "Only an accepted quotation can become a sales order.")
    if db.scalar(select(SalesOrder.id).where(SalesOrder.quotation_id == q.id)):
        raise Conflict("SO_EXISTS", "A sales order already exists for this quotation.")
    rev = next(r for r in q.revisions if r.revision_no == q.accepted_revision_no)
    so = SalesOrder(
        so_number=numbering.next_number(db, p.company_id, "SO", on=data.so_date or today()),
        quotation_id=q.id, quotation_revision_no=rev.revision_no,
        quotation_number=f"{q.quotation_number}-R{rev.revision_no}" if rev.revision_no else q.quotation_number,
        customer_id=q.customer_id, enquiry_id=q.enquiry_id, site_id=q.site_id, contact_id=q.contact_id,
        division_id=q.division_id, sales_person_id=q.sales_person_id, subject=q.subject,
        so_date=data.so_date or today(), customer_po_number=data.customer_po_number,
        customer_po_date=data.customer_po_date, expected_completion=data.expected_completion, notes=data.notes,
        status="confirmed", place_of_supply=rev.place_of_supply, inter_state=rev.inter_state,
        payment_terms=rev.payment_terms, delivery_terms=rev.delivery_terms, warranty=rev.warranty,
        terms=list(rev.terms), customer_snapshot=rev.customer_snapshot or quotations.customer_snapshot(db, q, rev),
        created_by=p.id, updated_by=p.id,
        **{k: getattr(rev, k) for k in TOTALS})
    for it in rev.items:
        so.items.append(SalesOrderItem(**{k: getattr(it, k) for k in LINE_FIELDS}, created_by=p.id, updated_by=p.id))
    db.add(so)
    db.flush()
    audit.record(db, action="create", entity_type="sales_order", entity_id=so.id,
                 entity_label=f"{so.so_number} {so.subject}",
                 summary=f"From quotation {so.quotation_number}: {len(so.items)} lines, ₹{so.taxable} before GST, "
                         f"₹{so.grand_total} total")
    return so


def update(db: Session, p: Principal, so_id: uuid.UUID, data) -> SalesOrder:
    """Order details that are not commercial: customer PO, dates, notes."""
    so = get(db, so_id, lock=True)
    check(p, so, "update")
    if so.status == "cancelled":
        raise AppError("SO_CANCELLED", "This order is cancelled.")
    before = audit.snapshot(so)
    check_row_version(so, data.row_version)
    for k in ("customer_po_number", "customer_po_date", "expected_completion", "notes"):
        setattr(so, k, getattr(data, k))
    so.updated_by = p.id
    db.flush()
    audit.record(db, action="update", entity_type="sales_order", entity_id=so.id, entity_label=so.so_number,
                 before=before, after=audit.snapshot(so))
    return so


def update_commercial(db: Session, p: Principal, so_id: uuid.UUID, data) -> SalesOrder:
    """Change lines / rates / discounts / terms after confirmation — restricted and always with a reason."""
    if not p.can("sales_order_commercial.update"):
        raise Forbidden("Changing prices, quantities or terms of a confirmed order needs special permission.",
                        code="COMMERCIAL_LOCKED")
    so = get(db, so_id, lock=True)
    check(p, so, "read")
    if so.status in ("completed", "cancelled"):
        raise AppError("SO_CLOSED", f"This order is {so.status}.")
    check_row_version(so, data.row_version)
    L.validate(db, data.items)
    rows, t = L.compute(data.items, inter_state=so.inter_state, special_discount=data.special_discount)
    before = {"lines": len(so.items), "taxable": str(so.taxable), "grand_total": str(so.grand_total)}
    so.items.clear()
    db.flush()
    for r in rows:
        so.items.append(SalesOrderItem(**r, created_by=p.id, updated_by=p.id))
    so.special_discount = round_amount(data.special_discount)
    for k in TOTALS:
        if k != "special_discount":
            setattr(so, k, round_amount(getattr(t, k)))
    for k in ("payment_terms", "delivery_terms", "warranty", "terms"):
        setattr(so, k, getattr(data, k))
    so.commercial_changed_at, so.updated_by = now(), p.id
    db.flush()
    audit.record(db, action="commercial_change", entity_type="sales_order", entity_id=so.id,
                 entity_label=so.so_number,
                 summary=f"Reason: {data.reason}. Lines {before['lines']} → {len(so.items)}, before GST "
                         f"₹{before['taxable']} → ₹{so.taxable}, total ₹{before['grand_total']} → ₹{so.grand_total}")
    from app.projects.service import sync_from_order

    so.sync_warnings = sync_from_order(db, p, so)  # not a column: returned to the screen once
    return so


NEXT = {"confirmed": ("in_progress", "cancelled"), "in_progress": ("completed", "cancelled"), "completed": (),
        "cancelled": ()}


def set_status(db: Session, p: Principal, so_id: uuid.UUID, status: str, reason: str | None) -> SalesOrder:
    from app.projects.models import Project

    so = get(db, so_id, lock=True)
    check(p, so, "update")
    if status not in NEXT.get(so.status, ()):
        raise AppError("INVALID_TRANSITION", f"A {so.status.replace('_', ' ')} order cannot become {status.replace('_', ' ')}.")
    if status == "cancelled":
        if not reason:
            raise AppError("REASON_REQUIRED", "Say why the order is cancelled.", details={"field": "reason"})
        live = db.scalar(select(Project.project_number).where(Project.sales_order_id == so.id,
                                                              Project.status != "cancelled"))
        if live:
            raise Conflict("PROJECT_ACTIVE", f"Project {live} is running for this order. Cancel the project first.")
    before = so.status
    so.status, so.updated_by = status, p.id
    so.status_reason = reason if status == "cancelled" else so.status_reason
    so.row_version += 1
    db.flush()
    audit.record(db, action="status", entity_type="sales_order", entity_id=so.id, entity_label=so.so_number,
                 summary=f"{before} → {status}" + (f": {reason}" if reason else ""))
    return so


def mark_in_progress(db: Session, so: SalesOrder, user_id) -> None:
    """Called when a project starts for the order."""
    if so.status == "confirmed":
        so.status, so.updated_by = "in_progress", user_id
        audit.record(db, action="status", entity_type="sales_order", entity_id=so.id, entity_label=so.so_number,
                     summary="confirmed → in_progress (project created)")

