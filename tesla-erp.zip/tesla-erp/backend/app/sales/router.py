import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from sqlalchemy import select

from app.auth.deps import Principal, require
from app.boq import lines as L
from app.company.models import BusinessDivision
from app.core import excel
from app.core.api import ListParams, ok
from app.core.db import DbSession
from app.crm.models import Enquiry
from app.customers.models import Customer, CustomerSite
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.sales import pdf, service
from app.sales.models import SalesOrder
from app.sales.schemas import CommercialIn, FromQuotationIn, SalesOrderUpdate, SoStatusIn
from app.users.models import User

router = APIRouter(tags=["sales"])
documents.register_entity("sales_order", "sales_order", SalesOrder,
                          check=lambda p, so, action: service.check(p, so, "read" if action == "read" else "update"))


def so_out(db, p: Principal, so: SalesOrder, detail: bool = False) -> dict:
    from app.projects.models import Project

    c = db.get(Customer, so.customer_id)
    out = {
        "id": str(so.id), "so_number": so.so_number, "subject": so.subject, "status": so.status,
        "so_date": so.so_date.isoformat(), "customer_id": str(so.customer_id),
        "customer": {"id": str(c.id), "name": c.customer_name, "code": c.customer_code, "city": c.city} if c else None,
        "quotation_id": str(so.quotation_id) if so.quotation_id else None, "quotation_number": so.quotation_number,
        "customer_po_number": so.customer_po_number, "taxable": str(so.taxable), "grand_total": str(so.grand_total),
        "sales_person": db.scalar(select(User.full_name).where(User.id == so.sales_person_id)) if so.sales_person_id else None,
        "row_version": so.row_version,
    }
    if not detail:
        return out
    projects = db.execute(select(Project.id, Project.project_number, Project.status)
                          .where(Project.sales_order_id == so.id)).all()
    commercial = p.can("sales_order_commercial.update") and so.status not in ("completed", "cancelled")
    q_status, replaced_by = None, None
    if so.quotation_id:
        from app.quotations.models import Quotation

        q_status = db.scalar(select(Quotation.status).where(Quotation.id == so.quotation_id))
        if so.status == "cancelled":
            live = service.live_order(db, so.quotation_id)
            replaced_by = {"id": str(live.id), "so_number": live.so_number} if live else None
    out |= {
        "quotation_status": q_status, "replaced_by": replaced_by,
        "enquiry_id": str(so.enquiry_id) if so.enquiry_id else None,
        "enquiry_number": db.scalar(select(Enquiry.enquiry_number).where(Enquiry.id == so.enquiry_id)) if so.enquiry_id else None,
        "site_id": str(so.site_id) if so.site_id else None,
        "site": db.scalar(select(CustomerSite.site_name).where(CustomerSite.id == so.site_id)) if so.site_id else None,
        "division": db.scalar(select(BusinessDivision.name).where(BusinessDivision.id == so.division_id)) if so.division_id else None,
        "division_id": str(so.division_id) if so.division_id else None,
        "sales_person_id": str(so.sales_person_id) if so.sales_person_id else None,
        "customer_po_date": so.customer_po_date.isoformat() if so.customer_po_date else None,
        "expected_completion": so.expected_completion.isoformat() if so.expected_completion else None,
        "notes": so.notes, "status_reason": so.status_reason, "place_of_supply": so.place_of_supply,
        "inter_state": so.inter_state, "payment_terms": so.payment_terms, "delivery_terms": so.delivery_terms,
        "warranty": so.warranty, "terms": so.terms, "customer_snapshot": so.customer_snapshot,
        "commercial_changed_at": so.commercial_changed_at.isoformat() if so.commercial_changed_at else None,
        **{k: str(getattr(so, k)) for k in service.TOTALS},
        "items": [L.line_out(i) for i in so.items],
        "tax_summary": [{"rate": f"{r.normalize():f}", "cgst": str(sum(i.cgst for i in so.items if i.tax_rate == r)),
                         "sgst": str(sum(i.sgst for i in so.items if i.tax_rate == r)),
                         "igst": str(sum(i.igst for i in so.items if i.tax_rate == r))}
                        for r in sorted({i.tax_rate for i in so.items})],
        "projects": [{"id": str(i), "project_number": n, "status": s} for i, n, s in projects],
        "sync_warnings": getattr(so, "sync_warnings", None) or [],
        "can": {"update": service.allowed(p, so, "update") and so.status != "cancelled", "commercial": commercial,
                "create_project": p.can("project.create") and so.status in ("confirmed", "in_progress")
                and not any(s != "cancelled" for _, _, s in projects),
                "start": service.allowed(p, so, "update") and so.status == "confirmed",
                "complete": service.allowed(p, so, "update") and so.status == "in_progress",
                "cancel": service.allowed(p, so, "update") and so.status in ("confirmed", "in_progress"),
                "print": p.can("sales_order.print"), "quotation": p.can("quotation.read"),
                # the customer came back after cancelling: order the same accepted quotation again
                "place_again": so.status == "cancelled" and q_status == "accepted" and replaced_by is None
                and p.can("sales_order.create")},
    }
    return out


@router.get("/sales-orders")
def list_orders(db: DbSession, p: Annotated[Principal, require("sales_order.read")],
                params: Annotated[ListParams, Depends()], status: str | None = Query(None),
                customer_id: uuid.UUID | None = None):
    rows, meta = service.list_orders(db, p, params, status=status, customer_id=customer_id)
    return {"data": [so_out(db, p, s) for s in rows], "meta": meta.model_dump()}


EXPORT_COLUMNS = [
    excel.Column("so_number", "SO number", 22), excel.Column("so_date", "Date", 12),
    excel.Column("customer", "Customer", 32), excel.Column("subject", "Subject", 40),
    excel.Column("quotation_number", "Quotation", 24), excel.Column("customer_po_number", "Customer PO", 18),
    excel.Column("taxable", "Value before GST (₹)", 18), excel.Column("grand_total", "Order value (₹)", 16),
    excel.Column("status", "Status", 12), excel.Column("sales_person", "Salesperson", 20),
]


@router.get("/sales-orders/export")
def export_orders(db: DbSession, p: Annotated[Principal, require("sales_order.export")],
                  params: Annotated[ListParams, Depends()], status: str | None = Query(None)):
    from decimal import Decimal

    params.page, params.page_size = 1, 5000
    rows, _ = service.list_orders(db, p, params, status=status)
    data = []
    for so in rows:
        r = so_out(db, p, so)
        r |= {"customer": (r["customer"] or {}).get("name"), "taxable": Decimal(r["taxable"]),
              "grand_total": Decimal(r["grand_total"]), "status": so.status.replace("_", " ")}
        data.append(r)
    audit.record(db, action="export", entity_type="sales_order", summary=f"Exported {len(data)} sales orders")
    return Response(excel.export("Sales orders", EXPORT_COLUMNS, data), media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="sales-orders.xlsx"'})


@router.get("/sales-orders/summary")
def so_summary(db: DbSession, p: Annotated[Principal, require("sales_order.read")]):
    from decimal import Decimal

    from sqlalchemy import func, or_

    stmt = select(SalesOrder.status, func.count(), func.coalesce(func.sum(SalesOrder.taxable), 0)).group_by(
        SalesOrder.status)
    if p.scope("sales_order.read") == "own":
        stmt = stmt.where(or_(SalesOrder.sales_person_id == p.id, SalesOrder.created_by == p.id))
    by = {s: (n, v) for s, n, v in db.execute(stmt).all()}
    open_ = [by.get(s, (0, Decimal(0))) for s in ("confirmed", "in_progress")]
    so_value = sum((v for _, v in open_), Decimal(0))
    # Open projects whose work is not already counted through an open sales order: projects started without an
    # order, and projects still running after their order was marked completed.
    prj_value, prj_count = Decimal(0), 0
    if p.scope("sales_order.read") == "all" and p.can("project.read"):
        from app.projects.models import Project

        row = db.execute(select(func.count(), func.coalesce(func.sum(Project.contract_value), 0))
                         .outerjoin(SalesOrder, SalesOrder.id == Project.sales_order_id)
                         .where(Project.status.not_in(("completed", "cancelled")),
                                or_(Project.sales_order_id.is_(None),
                                    SalesOrder.status.not_in(("confirmed", "in_progress"))))).one()
        prj_count, prj_value = row[0], Decimal(row[1])
    return ok({"open_count": sum(n for n, _ in open_), "open_value": str(so_value + prj_value),
               "open_order_value": str(so_value), "open_project_value": str(prj_value),
               "open_projects_without_order": prj_count,
               "confirmed": by.get("confirmed", (0, 0))[0], "in_progress": by.get("in_progress", (0, 0))[0],
               "completed": by.get("completed", (0, 0))[0]})


@router.post("/quotations/{quotation_id}/sales-order", status_code=201)
def from_quotation(quotation_id: uuid.UUID, body: FromQuotationIn, db: DbSession,
                   p: Annotated[Principal, require("sales_order.create")]):
    return ok(so_out(db, p, service.create_from_quotation(db, p, quotation_id, body), detail=True))


@router.get("/sales-orders/{so_id}")
def get_order(so_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("sales_order.read")]):
    so = service.get(db, so_id)
    service.check(p, so, "read")
    return ok(so_out(db, p, so, detail=True))


@router.put("/sales-orders/{so_id}")
def update_order(so_id: uuid.UUID, body: SalesOrderUpdate, db: DbSession,
                 p: Annotated[Principal, require("sales_order.update")]):
    return ok(so_out(db, p, service.update(db, p, so_id, body), detail=True))


@router.get("/sales-orders/{so_id}/pdf")
def order_pdf(so_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("sales_order.print")]):
    so = service.get(db, so_id)
    service.check(p, so, "read")
    audit.record(db, action="print", entity_type="sales_order", entity_id=so.id, entity_label=so.so_number)
    name = so.so_number.replace("/", "-")
    return Response(pdf.build(db, so), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{name}.pdf"', "Cache-Control": "no-store"})


@router.put("/sales-orders/{so_id}/commercial")
def update_commercial(so_id: uuid.UUID, body: CommercialIn, db: DbSession,
                      p: Annotated[Principal, require("sales_order.read")]):
    return ok(so_out(db, p, service.update_commercial(db, p, so_id, body), detail=True))


@router.post("/sales-orders/{so_id}/status")
def order_status(so_id: uuid.UUID, body: SoStatusIn, db: DbSession, p: Annotated[Principal, require("sales_order.update")]):
    return ok(so_out(db, p, service.set_status(db, p, so_id, body.status, body.reason), detail=True))
