from app.core.permissions import register

register("sales_order", "Sales orders", ("create", "read", "update", "delete", "export", "print"),
         scoped=("read", "update"))
# Changing rates, quantities, discounts or terms of a confirmed order is a separate, restricted right (Spec §15).
register("sales_order_commercial", "Sales order prices & terms (change after confirmation)", ("update",))
