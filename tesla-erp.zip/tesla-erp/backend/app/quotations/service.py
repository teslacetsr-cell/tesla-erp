"""Quotation workflow (Spec §14, §30). Every change of state is an explicit action:

    draft ──submit──► pending_approval ──(approvers)──► approved ──send──► sent ──► negotiation
      ▲                     │ rejected by an approver                      │  │
      └──── withdraw ◄──────┘ (back to draft, with the comment)            │  └─► accepted / rejected / expired
                                                                          └─ revise ─► new revision Rn+1 (draft)
    Below the approval threshold, submit goes straight to approved. cancel is possible until accepted.

The number TCE/QTN/2026-27/0001 is given on first submit; revisions show as …/0001-R1.
"""
import uuid
from datetime import UTC, date, datetime, timedelta

from sqlalchemy import or_, select, update
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.boq import lines as L
from app.boq.models import Boq
from app.boq.service import to_line_in
from app.company.models import BusinessDivision
from app.core.api import ListParams, paginate
from app.core.errors import AppError, Forbidden, NotFound
from app.core.models import check_row_version
from app.core.money import round_amount
from app.crm import service as crm
from app.crm.models import Enquiry
from app.crm.schemas import StatusIn
from app.customers.models import Customer, CustomerContact, CustomerSite
from app.platform import pdfkit
from app.platform.approvals import service as approvals
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.platform.numbering import service as numbering
from app.platform.settings import service as settings
from app.quotations.models import Quotation, QuotationItem, QuotationRevision, QuotationTerm
from app.quotations.schemas import QuotationIn, QuotationUpdate
from app.users.models import User

OPEN = ("draft", "pending_approval", "approved", "sent", "negotiation")


# ------------------------------------------------------------------ scope
def _own(p: Principal):
    return or_(Quotation.sales_person_id == p.id, Quotation.created_by == p.id)


def scope_clause(p: Principal, action: str = "read"):
    scope = p.scope(f"quotation.{action}")
    if scope is None:
        raise Forbidden()
    return _own(p) if scope == "own" else None


def allowed(p: Principal, q: Quotation, action: str) -> bool:
    scope = p.scope(f"quotation.{action}")
    if scope is None:
        return False
    return scope != "own" or q.sales_person_id == p.id or q.created_by == p.id


def check(p: Principal, q: Quotation, action: str) -> None:
    if p.scope(f"quotation.{action}") is None:
        raise Forbidden()
    if not allowed(p, q, action):
        raise Forbidden("You can only work on quotations assigned to you.", code="OUT_OF_SCOPE")


def get(db: Session, quotation_id: uuid.UUID, lock: bool = False) -> Quotation:
    q = db.get(Quotation, quotation_id, with_for_update=lock or None)
    if q is None:
        raise NotFound("quotation")
    return q


def list_quotations(db: Session, p: Principal, params: ListParams, *, status=None, customer_id=None, enquiry_id=None,
                    sales_person_id=None, open_only=False):
    stmt = select(Quotation)
    if (c := scope_clause(p)) is not None:
        stmt = stmt.where(c)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(Quotation.quotation_number.ilike(like), Quotation.subject.ilike(like),
                              Quotation.customer_id.in_(select(Customer.id).where(Customer.customer_name.ilike(like)))))
    for col, val in ((Quotation.status, status), (Quotation.customer_id, customer_id),
                     (Quotation.enquiry_id, enquiry_id), (Quotation.sales_person_id, sales_person_id)):
        if val:
            stmt = stmt.where(col == val)
    if open_only:
        stmt = stmt.where(Quotation.status.in_(OPEN))
    return paginate(db, stmt, params, default_sort=Quotation.updated_at.desc(), sortable={
        "quotation_number": Quotation.quotation_number, "subject": Quotation.subject, "status": Quotation.status,
        "created_at": Quotation.created_at, "updated_at": Quotation.updated_at})


# ------------------------------------------------------------------ helpers
def _today() -> date:
    return crm.today()


def default_terms(db: Session) -> dict:
    rows = db.scalars(select(QuotationTerm).where(QuotationTerm.is_active.is_(True), QuotationTerm.is_default.is_(True))
                      .order_by(QuotationTerm.sort_order, QuotationTerm.title)).all()
    pick = lambda cat: next((r.text for r in rows if r.category == cat), None)  # noqa: E731
    return {"payment_terms": pick("payment"), "delivery_terms": pick("delivery"), "warranty": pick("warranty"),
            "terms": [r.text for r in rows if r.category in ("general", "validity")]}


def _header_refs(db: Session, p: Principal, data: QuotationIn, current: Quotation | None) -> dict:
    values = data.model_dump(include={"customer_id", "enquiry_id", "boq_id", "site_id", "contact_id", "division_id",
                                      "sales_person_id", "subject"})
    enq = None
    if data.enquiry_id:
        enq = db.get(Enquiry, data.enquiry_id)
        if enq is None:
            raise AppError("INVALID_ENQUIRY", "The enquiry does not exist.")
        if current is None or current.enquiry_id != enq.id:
            crm.check(p, "enquiry", enq, "read")
        if data.customer_id and data.customer_id != enq.customer_id:
            raise AppError("CUSTOMER_MISMATCH", "The enquiry belongs to a different customer.")
        values["customer_id"] = enq.customer_id
        values["site_id"] = data.site_id or enq.site_id
        values["contact_id"] = data.contact_id or enq.contact_id
        values["division_id"] = data.division_id or enq.division_id
        values["sales_person_id"] = data.sales_person_id or enq.sales_person_id
    customer = db.get(Customer, values["customer_id"])
    if customer is None:
        raise AppError("INVALID_CUSTOMER", "The customer does not exist.")
    if customer.status == "blocked":
        raise AppError("CUSTOMER_BLOCKED", f"{customer.customer_name} is blocked.")
    if values["site_id"]:
        s = db.get(CustomerSite, values["site_id"])
        if s is None or s.customer_id != customer.id:
            raise AppError("INVALID_SITE", "The site does not belong to this customer.")
    if values["contact_id"]:
        c = db.get(CustomerContact, values["contact_id"])
        if c is None or c.customer_id != customer.id:
            raise AppError("INVALID_CONTACT", "The contact does not belong to this customer.")
    if values["division_id"] and db.get(BusinessDivision, values["division_id"]) is None:
        raise AppError("INVALID_DIVISION", "The business division does not exist.")
    if values["sales_person_id"]:
        u = db.get(User, values["sales_person_id"])
        if u is None or not u.is_active:
            raise AppError("INVALID_USER", "The salesperson must be an active user.")
    elif "SALES" in p.role_codes:
        values["sales_person_id"] = p.id
    if values["boq_id"] and db.get(Boq, values["boq_id"]) is None:
        raise AppError("INVALID_BOQ", "The BOQ does not exist.")
    return values


def _fill_revision(db: Session, p: Principal, q: Quotation, rev: QuotationRevision, data, lines: list[L.LineIn]) -> None:
    """Copy editable fields and (re)compute lines and totals on an unlocked revision."""
    if rev.locked:
        raise AppError("REVISION_LOCKED", "This revision was sent to the customer and can never be changed. Revise it.")
    fields = data.model_dump(include={"kind_attention", "intro_text", "payment_terms", "delivery_terms", "warranty",
                                      "technical_notes", "terms", "special_discount"})
    for k, v in fields.items():
        setattr(rev, k, v)
    rev.quotation_date = data.quotation_date or rev.quotation_date or _today()
    days = int(settings.get_setting(db, p.company_id, "quotation.default_validity_days") or 30)
    rev.valid_until = data.valid_until or rev.valid_until or rev.quotation_date + timedelta(days=days)
    if rev.valid_until < rev.quotation_date:
        raise AppError("INVALID_VALIDITY", "'Valid until' must be on or after the quotation date.")
    customer = db.get(Customer, q.customer_id)
    site = db.get(CustomerSite, q.site_id) if q.site_id else None
    rev.place_of_supply = L.place_of_supply(customer, site)
    rev.inter_state = L.inter_state_for(db, p.company_id, rev.place_of_supply)
    if lines:
        L.validate(db, lines)
        rows, t = L.compute(lines, inter_state=rev.inter_state, special_discount=rev.special_discount)
    else:
        if rev.special_discount:
            raise AppError("CALCULATION_ERROR", "Add lines before giving a special discount.")
        rows, t = [], None
    rev.items.clear()
    db.flush()
    for r in rows:
        rev.items.append(QuotationItem(**r, created_by=p.id, updated_by=p.id))
    for k in ("gross", "line_discount", "taxable", "cgst", "sgst", "igst", "round_off", "grand_total"):
        setattr(rev, k, round_amount(getattr(t, k)) if t else round_amount(0))
    rev.updated_by = p.id


def _label(q: Quotation) -> str:
    return f"{q.display_number} {q.subject}"


# ------------------------------------------------------------------ create / edit
def create(db: Session, p: Principal, data: QuotationIn) -> Quotation:
    values = _header_refs(db, p, data, None)
    q = Quotation(**values, status="draft", status_changed_at=crm.now(), current_revision_no=0,
                  created_by=p.id, updated_by=p.id)
    db.add(q)
    db.flush()
    defaults = default_terms(db)
    fields = data.model_copy()
    for k in ("payment_terms", "delivery_terms", "warranty"):
        if getattr(fields, k) is None:
            setattr(fields, k, defaults[k])
    if not fields.terms:
        fields.terms = defaults["terms"]
    lines = list(data.items)
    if not lines and q.boq_id:
        lines = [to_line_in(i) for i in db.get(Boq, q.boq_id).items]
    if fields.kind_attention is None and q.contact_id:
        c = db.get(CustomerContact, q.contact_id)
        fields.kind_attention = c.name if c else None
    rev = QuotationRevision(quotation_id=q.id, revision_no=0, created_by=p.id, updated_by=p.id)
    q.revisions.append(rev)
    _fill_revision(db, p, q, rev, fields, lines)
    db.flush()
    audit.record(db, action="create", entity_type="quotation", entity_id=q.id, entity_label=_label(q),
                 summary=f"{len(rev.items)} lines, ₹{rev.taxable} before GST, ₹{rev.grand_total} total")
    return q


def update_draft(db: Session, p: Principal, quotation_id: uuid.UUID, data: QuotationUpdate) -> Quotation:
    q = get(db, quotation_id, lock=True)
    check(p, q, "update")
    if q.status != "draft":
        raise AppError("NOT_DRAFT", "Only a draft can be edited. Withdraw it from approval, or revise a sent quotation.")
    check_row_version(q, data.row_version)
    rev = q.current
    before = {"taxable": str(rev.taxable), "grand_total": str(rev.grand_total), "lines": len(rev.items)}
    values = _header_refs(db, p, data, q)
    if values["customer_id"] != q.customer_id and q.quotation_number:
        raise AppError("CUSTOMER_LOCKED", "The customer of a numbered quotation cannot change. Make a new quotation.")
    for k, v in values.items():
        setattr(q, k, v)
    q.updated_by = p.id
    db.flush()
    _fill_revision(db, p, q, rev, data, list(data.items))
    db.flush()
    audit.record(db, action="update", entity_type="quotation", entity_id=q.id, entity_label=_label(q),
                 summary=f"R{rev.revision_no}: lines {before['lines']} → {len(rev.items)}, before GST "
                         f"₹{before['taxable']} → ₹{rev.taxable}, total ₹{before['grand_total']} → ₹{rev.grand_total}")
    return q


def _status(db: Session, q: Quotation, status: str, summary: str, reason: str | None = None) -> None:
    before = q.status
    q.status, q.status_changed_at = status, crm.now()
    if reason is not None:
        q.status_reason = reason
    q.row_version += 1
    db.flush()
    audit.record(db, action="status", entity_type="quotation", entity_id=q.id, entity_label=_label(q),
                 summary=f"{before} → {status}: {summary}")


def _expect(q: Quotation, *statuses: str, row_version: int | None = None) -> None:
    if q.status not in statuses:
        raise AppError("INVALID_TRANSITION", f"Not possible while the quotation is {q.status.replace('_', ' ')}.")
    if row_version is not None and row_version != q.row_version:
        check_row_version(q, row_version)


# ------------------------------------------------------------------ workflow
def submit(db: Session, p: Principal, quotation_id: uuid.UUID, row_version: int | None) -> Quotation:
    q = get(db, quotation_id, lock=True)
    check(p, q, "update")
    _expect(q, "draft", row_version=row_version)
    rev = q.current
    if not rev.items:
        raise AppError("NO_LINES", "Add at least one line before submitting.")
    if rev.valid_until < _today():
        raise AppError("VALIDITY_PASSED", "'Valid until' is in the past. Change it before submitting.")
    if q.quotation_number is None:
        q.quotation_number = numbering.next_number(db, p.company_id, "QTN", on=rev.quotation_date)
    rev.submitted_at, rev.last_rejection = datetime.now(UTC), None
    # Approval is decided on the value before GST (Spec §30, Q7).
    req = approvals.start(db, p, entity_type="quotation", entity_id=q.id, label=f"{q.display_number} · {q.subject}",
                          amount=rev.taxable, division_id=q.division_id)
    if req is None:
        rev.approved_at = datetime.now(UTC)
        _status(db, q, "approved", f"no approval needed for ₹{rev.taxable} before GST")
    else:
        _status(db, q, "pending_approval", f"sent for approval ({req.policy_name})")
    return q


def withdraw(db: Session, p: Principal, quotation_id: uuid.UUID, row_version: int | None) -> Quotation:
    """Back to draft (to edit): from pending approval, or approved but not yet sent. Any approval is voided."""
    q = get(db, quotation_id, lock=True)
    check(p, q, "update")
    _expect(q, "pending_approval", "approved", row_version=row_version)
    approvals.withdraw(db, p, "quotation", q.id)
    q.current.approved_at = None
    _status(db, q, "draft", "withdrawn for changes")
    return q


def _on_approved(db: Session, p: Principal, req) -> None:
    q = get(db, req.entity_id, lock=True)
    if q.status != "pending_approval":
        return
    q.current.approved_at = datetime.now(UTC)
    _status(db, q, "approved", f"approved ({req.policy_name})")


def _on_rejected(db: Session, p: Principal, req, comment: str) -> None:
    q = get(db, req.entity_id, lock=True)
    if q.status != "pending_approval":
        return
    q.current.last_rejection = f"{p.user.full_name}: {comment}"
    _status(db, q, "draft", f"returned by {p.user.full_name}: {comment}")


def send(db: Session, p: Principal, quotation_id: uuid.UUID, row_version: int | None) -> Quotation:
    """Mark as sent to the customer: freezes customer/company details, locks the revision for ever, files the PDF."""
    from app.quotations import pdf

    q = get(db, quotation_id, lock=True)
    check(p, q, "update")
    _expect(q, "approved", row_version=row_version)
    rev = q.current
    rev.customer_snapshot = customer_snapshot(db, q, rev)
    rev.company_snapshot = pdfkit.company_snapshot(db)
    rev.sent_at = datetime.now(UTC)
    q.first_sent_at = q.first_sent_at or rev.sent_at
    db.flush()
    data = pdf.build(db, q, rev)
    doc = documents.upload(db, entity_type="quotation", entity_id=q.id, category="quotation",
                           file_name=f"{q.display_number.replace('/', '-')}.pdf", data=data, user_id=p.id,
                           title=f"Quotation {q.display_number}")
    rev.pdf_document_id = doc.id
    _status(db, q, "sent", f"R{rev.revision_no} sent to the customer")
    enq = db.get(Enquiry, q.enquiry_id) if q.enquiry_id else None
    crm._advance_enquiry(enq, "quoted")
    crm._advance_lead(enq.lead if enq else None, "quotation")
    return q


def mark_negotiation(db: Session, p: Principal, quotation_id: uuid.UUID, row_version: int | None) -> Quotation:
    q = get(db, quotation_id, lock=True)
    check(p, q, "update")
    _expect(q, "sent", row_version=row_version)
    _status(db, q, "negotiation", "customer is negotiating")
    enq = db.get(Enquiry, q.enquiry_id) if q.enquiry_id else None
    crm._advance_lead(enq.lead if enq else None, "negotiation")
    return q


def revise(db: Session, p: Principal, quotation_id: uuid.UUID, change_note: str | None,
           row_version: int | None) -> Quotation:
    """New revision Rn+1, copied from the current one; the old revision stays exactly as it was."""
    q = get(db, quotation_id, lock=True)
    check(p, q, "update")
    _expect(q, "sent", "negotiation", "rejected", "expired", row_version=row_version)
    old = q.current
    days = int(settings.get_setting(db, p.company_id, "quotation.default_validity_days") or 30)
    new = QuotationRevision(
        quotation_id=q.id, revision_no=old.revision_no + 1, change_note=change_note, quotation_date=_today(),
        valid_until=_today() + timedelta(days=days), kind_attention=old.kind_attention, intro_text=old.intro_text,
        payment_terms=old.payment_terms, delivery_terms=old.delivery_terms, warranty=old.warranty,
        technical_notes=old.technical_notes, terms=list(old.terms), special_discount=old.special_discount,
        created_by=p.id, updated_by=p.id)
    q.revisions.append(new)
    q.current_revision_no = new.revision_no
    db.flush()
    from app.quotations.schemas import RevisionFields

    fields = RevisionFields(quotation_date=new.quotation_date, valid_until=new.valid_until,
                            kind_attention=new.kind_attention, intro_text=new.intro_text,
                            payment_terms=new.payment_terms, delivery_terms=new.delivery_terms, warranty=new.warranty,
                            technical_notes=new.technical_notes, terms=new.terms, special_discount=new.special_discount)
    _fill_revision(db, p, q, new, fields, [to_line_in(i) for i in old.items])
    q.status_reason = None
    _status(db, q, "draft", f"revision R{new.revision_no} started" + (f": {change_note}" if change_note else ""))
    return q


def accept(db: Session, p: Principal, quotation_id: uuid.UUID, row_version: int | None) -> Quotation:
    q = get(db, quotation_id, lock=True)
    check(p, q, "update")
    _expect(q, "sent", "negotiation", row_version=row_version)
    q.accepted_revision_no = q.current_revision_no
    _status(db, q, "accepted", f"customer accepted R{q.current_revision_no}")
    enq = db.get(Enquiry, q.enquiry_id) if q.enquiry_id else None
    if enq is not None and enq.status not in ("won", "lost", "cancelled"):
        crm._set_status(db, "enquiry", enq, enq.enquiry_number, StatusIn(status="won"))
        if enq.lead is not None and enq.lead.status not in ("won", "lost"):
            crm._set_status(db, "lead", enq.lead, enq.lead.lead_number, StatusIn(status="won"))
    return q


def customer_rejected(db: Session, p: Principal, quotation_id: uuid.UUID, reason: str | None,
                      row_version: int | None) -> Quotation:
    q = get(db, quotation_id, lock=True)
    check(p, q, "update")
    _expect(q, "sent", "negotiation", row_version=row_version)
    if not reason:
        raise AppError("REASON_REQUIRED", "Say why the customer rejected it.", details={"field": "reason"})
    _status(db, q, "rejected", f"customer rejected: {reason}", reason=reason)
    return q


def cancel(db: Session, p: Principal, quotation_id: uuid.UUID, reason: str | None, row_version: int | None) -> Quotation:
    q = get(db, quotation_id, lock=True)
    check(p, q, "update")
    _expect(q, "draft", "pending_approval", "approved", "sent", "negotiation", "rejected", "expired",
            row_version=row_version)
    approvals.withdraw(db, p, "quotation", q.id)
    _status(db, q, "cancelled", f"cancelled{': ' + reason if reason else ''}", reason=reason)
    return q


def delete(db: Session, p: Principal, quotation_id: uuid.UUID) -> None:
    q = get(db, quotation_id, lock=True)
    check(p, q, "delete")
    if q.quotation_number is not None:
        raise AppError("NUMBERED", "A numbered quotation is kept for the record. Cancel it instead.")
    label = _label(q)
    db.delete(q)
    db.flush()
    audit.record(db, action="delete", entity_type="quotation", entity_id=quotation_id, entity_label=label)


def expire_due(db: Session) -> int:
    """Sent / negotiating quotations whose validity has passed become expired (run by the worker)."""
    today = _today()
    ids = list(db.scalars(select(Quotation.id).join(QuotationRevision, (QuotationRevision.quotation_id == Quotation.id)
                                                    & (QuotationRevision.revision_no == Quotation.current_revision_no))
                          .where(Quotation.status.in_(("sent", "negotiation")), QuotationRevision.valid_until < today)))
    if ids:
        db.execute(update(Quotation).where(Quotation.id.in_(ids)).values(
            status="expired", status_changed_at=crm.now(), row_version=Quotation.row_version + 1))
        for qid in ids:
            audit.record(db, action="status", entity_type="quotation", entity_id=qid, summary="validity passed → expired")
    return len(ids)


# ------------------------------------------------------------------ snapshot
def customer_snapshot(db: Session, q: Quotation, rev: QuotationRevision) -> dict:
    c = db.get(Customer, q.customer_id)
    site = db.get(CustomerSite, q.site_id) if q.site_id else None
    contact = db.get(CustomerContact, q.contact_id) if q.contact_id else None
    place = c.city if not c.district or (c.city or "").lower() == c.district.lower() else f"{c.city}, {c.district}"
    addr = [x for x in (c.address_line1, c.address_line2, place,
                        " ".join(x for x in (c.state, c.pincode) if x)) if x]
    return {
        "name": c.company_name or c.customer_name, "customer_name": c.customer_name, "code": c.customer_code,
        "address": addr, "gstin": c.gstin, "state": c.state, "state_code": c.state_code, "phone": c.phone,
        "email": c.email,
        "site": {"name": site.site_name, "address": ", ".join(x for x in (site.address_line1, site.city, site.state) if x)}
        if site else None,
        "contact": {"name": contact.name, "designation": contact.designation, "phone": contact.phone,
                    "email": contact.email} if contact else None,
        "place_of_supply": rev.place_of_supply,
    }


def _handler_owners(db: Session, qid: uuid.UUID) -> list[uuid.UUID]:
    q = db.get(Quotation, qid)
    return [x for x in (q.sales_person_id, q.created_by) if x] if q else []


approvals.register("quotation", approvals.Handler(
    label="Quotation", href=lambda qid: f"/sales/quotations/view?id={qid}", on_approved=_on_approved,
    on_rejected=_on_rejected, owners=_handler_owners))
