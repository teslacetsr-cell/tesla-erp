"""Quotations (Spec §14) with immutable revisions.

`quotations` is the header: customer, links, status and which revision is current. Each `quotation_revisions` row
holds its own complete set of lines, terms and totals. Once a revision has been sent to the customer it is locked
forever: changing a sent quotation creates the next revision (R1, R2…). The customer and company details printed on a
sent revision are frozen into it, and its PDF is filed at the moment of sending.
"""
import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, SmallInteger, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.boq.models import LineColumns
from app.core.models import AuditColumnsMixin, Base
from app.core.money import AMOUNT

QUOTATION_STATUSES = ("draft", "pending_approval", "approved", "sent", "negotiation", "accepted", "rejected", "expired",
                      "cancelled")
TERM_CATEGORIES = ("payment", "delivery", "warranty", "validity", "general")


def _in(col: str, values) -> str:
    return f"{col} in ({', '.join(repr(v) for v in values)})"


class Quotation(AuditColumnsMixin, Base):
    __tablename__ = "quotations"
    __table_args__ = (
        CheckConstraint(_in("status", QUOTATION_STATUSES), name="status_valid"),
        Index("ix_quotations_status", "status"), Index("ix_quotations_customer_id", "customer_id"),
        Index("ix_quotations_enquiry_id", "enquiry_id"), Index("ix_quotations_sales_person_id", "sales_person_id"),
    )

    quotation_number: Mapped[str | None] = mapped_column(String(30), unique=True)  # given when first submitted
    customer_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("customers.id", ondelete="RESTRICT"), nullable=False)
    enquiry_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("enquiries.id", ondelete="RESTRICT"))
    boq_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("boqs.id", ondelete="RESTRICT"))
    site_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("customer_sites.id", ondelete="RESTRICT"))
    contact_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("customer_contacts.id", ondelete="SET NULL"))
    division_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("business_divisions.id", ondelete="RESTRICT"))
    sales_person_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    subject: Mapped[str] = mapped_column(String(200), nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="draft", server_default="draft")
    status_changed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    status_reason: Mapped[str | None] = mapped_column(String(500))  # customer's rejection / cancellation reason
    current_revision_no: Mapped[int] = mapped_column(SmallInteger, nullable=False, default=0, server_default="0")
    accepted_revision_no: Mapped[int | None] = mapped_column(SmallInteger)
    first_sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    revisions: Mapped[list["QuotationRevision"]] = relationship(
        back_populates="quotation", order_by="QuotationRevision.revision_no", cascade="all, delete-orphan",
        lazy="selectin")

    @property
    def current(self) -> "QuotationRevision":
        return next(r for r in self.revisions if r.revision_no == self.current_revision_no)

    @property
    def display_number(self) -> str:
        base = self.quotation_number or "DRAFT"
        return f"{base}-R{self.current_revision_no}" if self.current_revision_no else base


class QuotationRevision(AuditColumnsMixin, Base):
    __tablename__ = "quotation_revisions"
    __table_args__ = (UniqueConstraint("quotation_id", "revision_no"),
                      CheckConstraint("valid_until >= quotation_date", name="validity_after_date"),
                      CheckConstraint("special_discount >= 0", name="special_discount_nonneg"))

    quotation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("quotations.id", ondelete="CASCADE"), nullable=False,
                                                    index=True)
    revision_no: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    change_note: Mapped[str | None] = mapped_column(String(500))
    quotation_date: Mapped[date] = mapped_column(Date, nullable=False)
    valid_until: Mapped[date] = mapped_column(Date, nullable=False)
    kind_attention: Mapped[str | None] = mapped_column(String(150))
    intro_text: Mapped[str | None] = mapped_column(Text)
    place_of_supply: Mapped[str | None] = mapped_column(String(2))
    inter_state: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    payment_terms: Mapped[str | None] = mapped_column(Text)
    delivery_terms: Mapped[str | None] = mapped_column(Text)
    warranty: Mapped[str | None] = mapped_column(Text)
    technical_notes: Mapped[str | None] = mapped_column(Text)
    terms: Mapped[list] = mapped_column(JSONB, nullable=False, default=list, server_default="[]")
    special_discount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    gross: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    line_discount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    taxable: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    cgst: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    sgst: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    igst: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    round_off: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    grand_total: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_rejection: Mapped[str | None] = mapped_column(Text)  # internal approver's comment, shown on the draft
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))  # set once: locks the revision
    customer_snapshot: Mapped[dict | None] = mapped_column(JSONB)
    company_snapshot: Mapped[dict | None] = mapped_column(JSONB)
    pdf_document_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("documents.id", ondelete="SET NULL"))

    quotation: Mapped[Quotation] = relationship(back_populates="revisions")
    items: Mapped[list["QuotationItem"]] = relationship(order_by="QuotationItem.line_no", cascade="all, delete-orphan",
                                                        lazy="selectin")

    @property
    def locked(self) -> bool:
        return self.sent_at is not None


class QuotationItem(AuditColumnsMixin, LineColumns, Base):
    __tablename__ = "quotation_items"

    revision_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("quotation_revisions.id", ondelete="CASCADE"),
                                                   nullable=False, index=True)
    special_discount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False, default=Decimal("0"), server_default="0")


class QuotationTerm(AuditColumnsMixin, Base):
    """Terms library: standard clauses picked into quotations (payment, delivery, warranty, general)."""

    __tablename__ = "quotation_terms"
    __table_args__ = (CheckConstraint(_in("category", TERM_CATEGORIES), name="category_valid"),)

    category: Mapped[str] = mapped_column(String(20), nullable=False)
    title: Mapped[str] = mapped_column(String(120), nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    is_default: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=100, server_default="100")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")
