import uuid
from datetime import date
from decimal import Decimal

from pydantic import Field, model_validator

from app.boq.lines import LineIn
from app.core.api import Schema
from app.core.validators import Text


class RevisionFields(Schema):
    """What can change between revisions."""

    quotation_date: date | None = None
    valid_until: date | None = None
    kind_attention: Text(150) = None
    intro_text: Text(2000) = None
    payment_terms: Text(2000) = None
    delivery_terms: Text(2000) = None
    warranty: Text(2000) = None
    technical_notes: Text(8000) = None
    terms: list[str] = Field(default_factory=list, max_length=40)
    special_discount: Decimal = Field(default=Decimal("0"), ge=0, max_digits=18, decimal_places=2)
    items: list[LineIn] = Field(default_factory=list, max_length=1000)

    @model_validator(mode="after")
    def _check(self):
        self.terms = [t.strip()[:1000] for t in self.terms if t and t.strip()]
        if self.quotation_date and self.valid_until and self.valid_until < self.quotation_date:
            raise ValueError("'Valid until' must be on or after the quotation date.")
        return self


class QuotationIn(RevisionFields):
    customer_id: uuid.UUID | None = None
    enquiry_id: uuid.UUID | None = None
    boq_id: uuid.UUID | None = None          # copy lines from this BOQ when no items are given
    site_id: uuid.UUID | None = None
    contact_id: uuid.UUID | None = None
    division_id: uuid.UUID | None = None
    sales_person_id: uuid.UUID | None = None
    subject: str = Field(min_length=3, max_length=200)

    @model_validator(mode="after")
    def _party(self):
        if not self.customer_id and not self.enquiry_id:
            raise ValueError("Choose the enquiry or the customer this quotation is for.")
        return self


class QuotationUpdate(QuotationIn):
    row_version: int


class ActionIn(Schema):
    reason: Text(500) = None
    row_version: int | None = None


class ReviseIn(Schema):
    change_note: Text(500) = None
    row_version: int | None = None
