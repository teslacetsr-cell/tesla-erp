from app.core.permissions import register

# 'own' scope: a salesperson works on quotations assigned to them (or that they created).
register("quotation", "Quotations", ("create", "read", "update", "delete", "approve", "export", "print"),
         scoped=("read", "update", "delete", "print"))
register("quotation_term", "Quotation terms library", ("create", "read", "update", "delete"))
