import uuid
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from pydantic import Field
from sqlalchemy import func, select

from app.auth.deps import Principal, require
from app.boq import lines as L
from app.company.models import BusinessDivision
from app.core import excel
from app.core.api import ListParams, Schema, ok
from app.core.crud import master_routes
from app.core.db import DbSession
from app.core.errors import AppError, NotFound
from app.crm.models import Enquiry
from app.customers.models import Customer, CustomerSite
from app.platform.approvals import service as approvals
from app.platform.approvals.router import request_out
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.platform.documents.models import Document
from app.platform.documents.storage import get_storage
from app.quotations import pdf, service
from app.quotations.models import TERM_CATEGORIES, Quotation, QuotationRevision, QuotationTerm
from app.quotations.schemas import ActionIn, QuotationIn, QuotationUpdate, ReviseIn
from app.users.models import User

router = APIRouter(tags=["quotations"])
documents.register_entity("quotation", "quotation", Quotation,
                          check=lambda p, q, action: service.check(p, q, "read" if action == "read" else "update"))


# ------------------------------------------------------------------ output
def _names(db, rows: list[Quotation]) -> tuple[dict, dict, dict]:
    uids = {r.sales_person_id for r in rows} | {r.created_by for r in rows}
    users = dict(db.execute(select(User.id, User.full_name).where(User.id.in_(uids - {None}))).all()) if rows else {}
    custs = {c.id: c for c in db.scalars(select(Customer).where(Customer.id.in_({r.customer_id for r in rows})))} \
        if rows else {}
    enqs = dict(db.execute(select(Enquiry.id, Enquiry.enquiry_number).where(
        Enquiry.id.in_({r.enquiry_id for r in rows} - {None}))).all()) if rows else {}
    return users, custs, enqs


def revision_out(db, rev: QuotationRevision, full: bool) -> dict:
    out = {
        "revision_no": rev.revision_no, "change_note": rev.change_note, "quotation_date": rev.quotation_date.isoformat(),
        "valid_until": rev.valid_until.isoformat(), "taxable": str(rev.taxable), "grand_total": str(rev.grand_total),
        "submitted_at": rev.submitted_at.isoformat() if rev.submitted_at else None,
        "approved_at": rev.approved_at.isoformat() if rev.approved_at else None,
        "sent_at": rev.sent_at.isoformat() if rev.sent_at else None, "locked": rev.locked,
        "pdf_document_id": str(rev.pdf_document_id) if rev.pdf_document_id else None,
    }
    if full:
        tax_rates = sorted({i.tax_rate for i in rev.items})
        out |= {
            "kind_attention": rev.kind_attention, "intro_text": rev.intro_text, "payment_terms": rev.payment_terms,
            "delivery_terms": rev.delivery_terms, "warranty": rev.warranty, "technical_notes": rev.technical_notes,
            "terms": rev.terms, "special_discount": str(rev.special_discount), "place_of_supply": rev.place_of_supply,
            "inter_state": rev.inter_state, "gross": str(rev.gross), "line_discount": str(rev.line_discount),
            "cgst": str(rev.cgst), "sgst": str(rev.sgst), "igst": str(rev.igst), "round_off": str(rev.round_off),
            "last_rejection": rev.last_rejection, "items": [L.line_out(i) for i in rev.items],
            "tax_summary": [{"rate": f"{r.normalize():f}",
                             "taxable": str(sum(i.taxable for i in rev.items if i.tax_rate == r)),
                             "cgst": str(sum(i.cgst for i in rev.items if i.tax_rate == r)),
                             "sgst": str(sum(i.sgst for i in rev.items if i.tax_rate == r)),
                             "igst": str(sum(i.igst for i in rev.items if i.tax_rate == r))} for r in tax_rates],
        }
    return out


def quotation_out(db, p: Principal, q: Quotation, names, detail: bool = False) -> dict:
    users, custs, enqs = names
    c = custs.get(q.customer_id)
    rev = q.current
    out = {
        "id": str(q.id), "quotation_number": q.quotation_number, "display_number": q.display_number,
        "subject": q.subject, "status": q.status, "status_reason": q.status_reason,
        "customer_id": str(q.customer_id),
        "customer": {"id": str(c.id), "name": c.customer_name, "code": c.customer_code, "city": c.city} if c else None,
        "enquiry_id": str(q.enquiry_id) if q.enquiry_id else None, "enquiry_number": enqs.get(q.enquiry_id),
        "boq_id": str(q.boq_id) if q.boq_id else None,
        "sales_person_id": str(q.sales_person_id) if q.sales_person_id else None,
        "sales_person": users.get(q.sales_person_id), "current_revision_no": q.current_revision_no,
        "accepted_revision_no": q.accepted_revision_no, "quotation_date": rev.quotation_date.isoformat(),
        "valid_until": rev.valid_until.isoformat(), "taxable": str(rev.taxable), "grand_total": str(rev.grand_total),
        "updated_at": q.updated_at.isoformat(), "row_version": q.row_version,
    }
    if not detail:
        return out
    pending = approvals.pending_for(db, "quotation", q.id)
    upd = service.allowed(p, q, "update")
    s = q.status
    from app.sales.models import SalesOrder

    so = db.execute(select(SalesOrder.id, SalesOrder.so_number).where(SalesOrder.quotation_id == q.id)).first()
    out |= {
        "site_id": str(q.site_id) if q.site_id else None,
        "site": db.scalar(select(CustomerSite.site_name).where(CustomerSite.id == q.site_id)) if q.site_id else None,
        "contact_id": str(q.contact_id) if q.contact_id else None,
        "division_id": str(q.division_id) if q.division_id else None,
        "division": db.scalar(select(BusinessDivision.name).where(BusinessDivision.id == q.division_id))
        if q.division_id else None,
        "created_by": users.get(q.created_by), "created_at": q.created_at.isoformat(),
        "current": revision_out(db, rev, True),
        "revisions": [revision_out(db, r, False) for r in reversed(q.revisions)],
        "approval": request_out(db, p, pending) if pending else None,
        "approvals": [request_out(db, p, r) for r in approvals.history(db, "quotation", q.id)],
        "sales_order": {"id": str(so[0]), "so_number": so[1]} if so else None,
        "can": {
            "edit": upd and s == "draft", "submit": upd and s == "draft",
            "withdraw": upd and s in ("pending_approval", "approved"), "send": upd and s == "approved",
            "negotiation": upd and s == "sent", "revise": upd and s in ("sent", "negotiation", "rejected", "expired"),
            "accept": upd and s in ("sent", "negotiation"), "reject": upd and s in ("sent", "negotiation"),
            "cancel": upd and s not in ("accepted", "cancelled"),
            "delete": service.allowed(p, q, "delete") and q.quotation_number is None,
            "print": service.allowed(p, q, "print"),
            "decide": bool(pending and approvals.can_decide(p, pending)),
            "create_sales_order": s == "accepted" and so is None and p.can("sales_order.create"),
        },
    }
    return out


def _detail(db, p, q: Quotation) -> dict:
    return quotation_out(db, p, q, _names(db, [q]), detail=True)


# ------------------------------------------------------------------ list & summary
def _filters(status: str | None = Query(None), customer_id: uuid.UUID | None = None,
             enquiry_id: uuid.UUID | None = None, sales_person_id: uuid.UUID | None = None, open_only: bool = False):
    return {"status": status, "customer_id": customer_id, "enquiry_id": enquiry_id,
            "sales_person_id": sales_person_id, "open_only": open_only}


@router.get("/quotations")
def list_quotations(db: DbSession, p: Annotated[Principal, require("quotation.read")],
                    params: Annotated[ListParams, Depends()], f: Annotated[dict, Depends(_filters)]):
    rows, meta = service.list_quotations(db, p, params, **f)
    names = _names(db, rows)
    return {"data": [quotation_out(db, p, q, names) for q in rows], "meta": meta.model_dump()}


EXPORT_COLUMNS = [
    excel.Column("display_number", "Quotation no.", 24), excel.Column("quotation_date", "Date", 12),
    excel.Column("customer", "Customer", 30), excel.Column("subject", "Subject", 40),
    excel.Column("enquiry_number", "Enquiry", 20), excel.Column("taxable", "Value before GST (₹)", 16),
    excel.Column("grand_total", "Grand total (₹)", 16), excel.Column("valid_until", "Valid until", 12),
    excel.Column("sales_person", "Salesperson", 20), excel.Column("status", "Status", 14),
]


@router.get("/quotations/export")
def export_quotations(db: DbSession, p: Annotated[Principal, require("quotation.read", "quotation.export")],
                      params: Annotated[ListParams, Depends()], f: Annotated[dict, Depends(_filters)]):
    params.page, params.page_size = 1, 100000
    rows, _ = service.list_quotations(db, p, params, **f)
    names = _names(db, rows)
    data = []
    for q in rows:
        d = quotation_out(db, p, q, names)
        d["customer"] = d["customer"]["name"] if d["customer"] else None
        for k in ("taxable", "grand_total"):
            d[k] = q.current.taxable if k == "taxable" else q.current.grand_total
        data.append(d)
    audit.record(db, action="export", entity_type="quotation", summary=f"Exported {len(data)} quotations")
    return Response(excel.export("Quotations", EXPORT_COLUMNS, data), media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="quotations.xlsx"'})


@router.get("/quotations/summary")
def quotations_summary(db: DbSession, p: Annotated[Principal, require("quotation.read")]):
    stmt = select(Quotation.status, func.count()).group_by(Quotation.status)
    if (c := service.scope_clause(p)) is not None:
        stmt = stmt.where(c)
    counts = dict(db.execute(stmt).all())
    return ok({"by_status": counts, "awaiting_my_approval": len(approvals.inbox(db, p))})


@router.get("/quotations/defaults")
def quotation_defaults(db: DbSession, p: Annotated[Principal, require("quotation.create")]):
    from app.platform.settings import service as settings

    return ok(service.default_terms(db) | {
        "validity_days": int(settings.get_setting(db, p.company_id, "quotation.default_validity_days") or 30),
        "gst_rates": sorted((f"{r:f}" for r in L.gst_rates(db)), key=float)})


# ------------------------------------------------------------------ CRUD
@router.post("/quotations", status_code=201)
def create_quotation(body: QuotationIn, db: DbSession, p: Annotated[Principal, require("quotation.create")]):
    return ok(_detail(db, p, service.create(db, p, body)))


@router.get("/quotations/{quotation_id}")
def get_quotation(quotation_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("quotation.read")]):
    q = service.get(db, quotation_id)
    service.check(p, q, "read")
    return ok(_detail(db, p, q))


@router.get("/quotations/{quotation_id}/revisions/{revision_no}")
def get_revision(quotation_id: uuid.UUID, revision_no: int, db: DbSession,
                 p: Annotated[Principal, require("quotation.read")]):
    q = service.get(db, quotation_id)
    service.check(p, q, "read")
    rev = next((r for r in q.revisions if r.revision_no == revision_no), None)
    if rev is None:
        raise NotFound("revision")
    return ok(revision_out(db, rev, True))


@router.put("/quotations/{quotation_id}")
def update_quotation(quotation_id: uuid.UUID, body: QuotationUpdate, db: DbSession,
                     p: Annotated[Principal, require("quotation.update")]):
    return ok(_detail(db, p, service.update_draft(db, p, quotation_id, body)))


@router.delete("/quotations/{quotation_id}")
def delete_quotation(quotation_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("quotation.delete")]):
    service.delete(db, p, quotation_id)
    return ok({"ok": True})


@router.post("/quotations/{quotation_id}/revise", status_code=201)
def revise_quotation(quotation_id: uuid.UUID, body: ReviseIn, db: DbSession,
                     p: Annotated[Principal, require("quotation.update")]):
    return ok(_detail(db, p, service.revise(db, p, quotation_id, body.change_note, body.row_version)))


Action = Literal["submit", "withdraw", "send", "negotiation", "accept", "reject", "cancel"]


@router.post("/quotations/{quotation_id}/{action}")
def quotation_action(quotation_id: uuid.UUID, action: Action, body: ActionIn, db: DbSession,
                     p: Annotated[Principal, require("quotation.update")]):
    rv = body.row_version
    fn = {
        "submit": lambda: service.submit(db, p, quotation_id, rv),
        "withdraw": lambda: service.withdraw(db, p, quotation_id, rv),
        "send": lambda: service.send(db, p, quotation_id, rv),
        "negotiation": lambda: service.mark_negotiation(db, p, quotation_id, rv),
        "accept": lambda: service.accept(db, p, quotation_id, rv),
        "reject": lambda: service.customer_rejected(db, p, quotation_id, body.reason, rv),
        "cancel": lambda: service.cancel(db, p, quotation_id, body.reason, rv),
    }[action]
    return ok(_detail(db, p, fn()))


@router.get("/quotations/{quotation_id}/revisions/{revision_no}/pdf")
def revision_pdf(quotation_id: uuid.UUID, revision_no: int, db: DbSession,
                 p: Annotated[Principal, require("quotation.print")]):
    """A sent revision returns exactly the PDF filed when it was sent; others are rendered now (DRAFT until approved)."""
    q = service.get(db, quotation_id)
    service.check(p, q, "print")
    rev = next((r for r in q.revisions if r.revision_no == revision_no), None)
    if rev is None:
        raise NotFound("revision")
    base = (q.quotation_number or "DRAFT").replace("/", "-") + (f"-R{rev.revision_no}" if rev.revision_no else "")
    if rev.pdf_document_id:
        doc = db.get(Document, rev.pdf_document_id)
        data = get_storage().get(doc.storage_key)
    else:
        if not rev.items:
            raise AppError("NO_LINES", "Add lines before printing.")
        data = pdf.build(db, q, rev)
    audit.record(db, action="print", entity_type="quotation", entity_id=q.id, entity_label=q.display_number,
                 summary=f"PDF of R{rev.revision_no}")
    return Response(data, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{base}.pdf"', "Cache-Control": "no-store"})


# ------------------------------------------------------------------ terms library
class TermIn(Schema):
    category: Literal[TERM_CATEGORIES]  # type: ignore[valid-type]
    title: str = Field(min_length=2, max_length=120)
    text: str = Field(min_length=2, max_length=2000)
    is_default: bool = False
    sort_order: int = Field(default=100, ge=0, le=10000)
    is_active: bool = True


class TermUpdate(TermIn):
    row_version: int


master_routes(router, path="/quotation-terms", entity="quotation_term", model=QuotationTerm, perm="quotation_term",
              create_schema=TermIn, update_schema=TermUpdate,
              out=lambda t: {"id": str(t.id), "category": t.category, "title": t.title, "text": t.text,
                             "is_default": t.is_default, "sort_order": t.sort_order, "is_active": t.is_active,
                             "row_version": t.row_version},
              search=("title", "text"), sortable=("category", "title", "sort_order"), default_sort="sort_order",
              label=lambda t: t.title)

