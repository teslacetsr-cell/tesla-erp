"""Quotation PDF on Tesla letterhead (Spec §14): company and customer details, project/site, dates and validity,
the priced BOQ, discounts, CGST/SGST or IGST by rate, round-off, grand total in words, commercial terms, technical
notes, terms and conditions, bank details and signature. Draft/unapproved copies carry a DRAFT watermark."""
import io
from collections import defaultdict
from decimal import Decimal
from html import escape

from reportlab.lib.units import mm
from reportlab.platypus import KeepTogether, ListFlowable, ListItem, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from sqlalchemy.orm import Session

from app.boq.pdf import lines_table, totals_table
from app.core.gst import amount_in_words
from app.crm.models import Enquiry
from app.platform import pdfkit as K
from app.quotations.models import Quotation, QuotationRevision
from app.users.models import User


def _date(d) -> str:
    return d.strftime("%d %b %Y") if d else "—"


def _rate(r: Decimal) -> str:
    return f"{r.normalize():f}"


def build(db: Session, q: Quotation, rev: QuotationRevision) -> bytes:
    from app.quotations.service import customer_snapshot  # frozen copy if sent, live otherwise

    K.fonts()
    st = K.styles()
    cust = rev.customer_snapshot or customer_snapshot(db, q, rev)
    company = rev.company_snapshot or K.company_snapshot(db)
    live_company = K.company(db)
    number = q.quotation_number or "DRAFT"
    rev_label = f"R{rev.revision_no}"
    shown = f"{number}-{rev_label}" if rev.revision_no else number
    approved = rev.approved_at is not None or rev.sent_at is not None

    story = K.letterhead(db, st, snapshot=rev.company_snapshot)
    head = Table([[Paragraph("QUOTATION", st["title"]), Paragraph(
        f"<b>No.</b> {escape(shown)}<br/><b>Date</b> {_date(rev.quotation_date)}"
        f"<br/><b>Valid until</b> {_date(rev.valid_until)}", st["right"])]], colWidths=[None, 70 * mm])
    head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "BOTTOM"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                              ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    story += [head, Spacer(1, 3 * mm)]

    to = [Paragraph("To", st["label"]), Paragraph(f"<b>{escape(cust['name'])}</b>", st["base"])]
    to += [Paragraph(escape(a), st["base"]) for a in cust.get("address") or []]
    if cust.get("gstin"):
        to.append(Paragraph(f"GSTIN {escape(cust['gstin'])}", st["base"]))
    if cust.get("state"):
        to.append(Paragraph(f"State: {escape(cust['state'])} ({escape(cust.get('state_code') or '')})", st["small"]))
    right = []
    attn = rev.kind_attention or (cust.get("contact") or {}).get("name")
    if attn:
        c = cust.get("contact") or {}
        right += [Paragraph("Kind attention", st["label"]), Paragraph(f"<b>{escape(attn)}</b>", st["base"])]
        for x in (c.get("designation"), c.get("phone"), c.get("email")):
            if x:
                right.append(Paragraph(escape(x), st["small"]))
    if cust.get("site"):
        right += [Spacer(1, 1.5 * mm), Paragraph("Project site", st["label"]),
                  Paragraph(escape(cust["site"]["name"]), st["base"])]
        if cust["site"].get("address"):
            right.append(Paragraph(escape(cust["site"]["address"]), st["small"]))
    enq = db.get(Enquiry, q.enquiry_id) if q.enquiry_id else None
    if enq:
        right += [Spacer(1, 1.5 * mm), Paragraph("Your enquiry", st["label"]),
                  Paragraph(f"{escape(enq.enquiry_number)} dated {_date(enq.enquiry_date)}", st["small"])]
    right += [Spacer(1, 1.5 * mm), Paragraph(
        f"Place of supply: {escape(cust.get('place_of_supply') or rev.place_of_supply or '—')} · "
        f"{'Inter-state (IGST)' if rev.inter_state else 'Intra-state (CGST + SGST)'}", st["small"])]
    box = Table([[to, right]], colWidths=[92 * mm, None])
    box.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("BOX", (0, 0), (-1, -1), 0.5, K.LINE),
                             ("LINEAFTER", (0, 0), (0, 0), 0.5, K.LINE), ("TOPPADDING", (0, 0), (-1, -1), 5),
                             ("BOTTOMPADDING", (0, 0), (-1, -1), 5), ("LEFTPADDING", (0, 0), (-1, -1), 6)]))
    story += [box, Spacer(1, 3 * mm), Paragraph(f"<b>Subject:</b> {escape(q.subject)}", st["base"]), Spacer(1, 2 * mm)]
    intro = rev.intro_text or ("Dear Sir / Madam,\nWith reference to "
                               + (f"your enquiry {enq.enquiry_number}" if enq else "your requirement")
                               + ", we are pleased to submit our offer as below.")
    story += [K.p(intro, st["base"]), Spacer(1, 3 * mm), lines_table(rev.items, st), Spacer(1, 3 * mm)]

    # totals, with GST shown per rate
    by_rate: dict[Decimal, dict] = defaultdict(lambda: {"cgst": Decimal(0), "sgst": Decimal(0), "igst": Decimal(0)})
    for it in rev.items:
        r = by_rate[it.tax_rate]
        r["cgst"] += it.cgst
        r["sgst"] += it.sgst
        r["igst"] += it.igst
    rows = [("Total", K.money(rev.gross), False)]
    if rev.line_discount:
        rows.append(("Less: discount", "− " + K.money(rev.line_discount), False))
    if rev.special_discount:
        rows.append(("Less: special discount", "− " + K.money(rev.special_discount), False))
    rows.append(("Taxable value", K.money(rev.taxable), True))
    for rate in sorted(by_rate):
        t = by_rate[rate]
        if rev.inter_state:
            if t["igst"]:
                rows.append((f"IGST @ {_rate(rate)} %", K.money(t["igst"]), False))
        else:
            if t["cgst"]:
                half = _rate(rate / 2)
                rows += [(f"CGST @ {half} %", K.money(t["cgst"]), False), (f"SGST @ {half} %", K.money(t["sgst"]), False)]
    if rev.round_off:
        rows.append(("Round off", ("+ " if rev.round_off > 0 else "− ") + K.money(abs(rev.round_off)), False))
    rows.append(("Grand total (₹)", K.money(rev.grand_total), True))
    story += [KeepTogether([totals_table(rows, st, width=95 * mm), Spacer(1, 1.5 * mm),
                            Paragraph(f"<b>In words:</b> {escape(amount_in_words(rev.grand_total))}", st["base"])])]

    # commercial terms
    commercial = [("Payment", rev.payment_terms), ("Delivery", rev.delivery_terms), ("Warranty", rev.warranty),
                  ("Validity", f"This offer is valid until {_date(rev.valid_until)}.")]
    ct = Table([[Paragraph(f"<b>{k}</b>", st["cell"]), K.p(v, st["cell"])] for k, v in commercial if v],
               colWidths=[28 * mm, None])
    ct.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, -1), 0.3, K.LINE),
                            ("LEFTPADDING", (0, 0), (-1, -1), 2)]))
    story += [Paragraph("Commercial terms", st["h"]), ct]
    if rev.technical_notes:
        story += [Paragraph("Technical specifications", st["h"]), K.p(rev.technical_notes, st["base"])]
    if rev.terms:
        story += [Paragraph("Terms and conditions", st["h"]),
                  ListFlowable([ListItem(K.p(t, st["base"]), leftIndent=10) for t in rev.terms], bulletType="1",
                               bulletFontName="DejaVu", bulletFontSize=8, leftIndent=12)]
    c = live_company
    if c and (c.bank_name or c.account_number):
        bank = [("Bank", c.bank_name), ("Account name", c.bank_account_name or c.legal_name),
                ("Account number", c.account_number), ("IFSC", c.ifsc), ("Branch", c.branch)]
        bt = Table([[Paragraph(k, st["label"]), K.p(v, st["cell"])] for k, v in bank if v], colWidths=[28 * mm, 70 * mm],
                   hAlign="LEFT")
        bt.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.5, K.LINE), ("TOPPADDING", (0, 0), (-1, -1), 2),
                                ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
        story += [Paragraph("Bank details", st["h"]), bt]

    sp = db.get(User, q.sales_person_id) if q.sales_person_id else None
    name = (company or {}).get("company_name") or "Tesla Consulting Engineers"
    closing = [Spacer(1, 5 * mm),
               Paragraph("We trust our offer meets your requirement and look forward to your valued order.", st["base"]),
               Spacer(1, 5 * mm), Paragraph(f"For <b>{escape(name)}</b>", st["base"]), Spacer(1, 14 * mm),
               Paragraph("Authorised Signatory", st["base"])]
    if sp:
        closing.append(Paragraph(f"Contact: {escape(sp.full_name)}{' · ' + escape(sp.email) if sp.email else ''}",
                                 st["small"]))
    story.append(KeepTogether(closing))

    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=K.PAGE, leftMargin=K.MARGIN, rightMargin=K.MARGIN, topMargin=10 * mm,
                      bottomMargin=14 * mm, title=f"Quotation {shown}", author=name).build(
        story, canvasmaker=K.numbered_canvas(f"Quotation {shown}", None if approved else "DRAFT"))
    return buf.getvalue()
