"""Off-site database backups in a separate S3-compatible bucket (Cloudflare R2 on the VPS).

    python -m app.ops.offsite upload /backups/tce_erp_20260927_0130.dump   # after pg_dump succeeded
    python -m app.ops.offsite fail "pg_dump: connection refused"             # record a failed night
    python -m app.ops.offsite list
    python -m app.ops.offsite download daily/tce_erp_20260927_0130.dump /backups/restore.dump

Layout in the bucket:
    daily/tce_erp_YYYYMMDD_HHMM.dump     kept: BACKUP_KEEP_DAILY   (default 30)
    weekly/…   (Sunday's backup)         kept: BACKUP_KEEP_WEEKLY  (default 12)
    monthly/…  (1st of the month)        kept: BACKUP_KEEP_MONTHLY (default 24)
Each object carries its SHA-256 in metadata; downloads are verified against it.
The result of every run is written to STATUS_FILE, which Settings → System and the dashboard show.
"""
import hashlib
import json
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from app.core.config import get_settings

IST = ZoneInfo("Asia/Kolkata")


def _client():
    import boto3
    from botocore.config import Config

    s = get_settings()
    if not s.backup_bucket:
        raise SystemExit("BACKUP_BUCKET is not set")
    return boto3.client(
        "s3", endpoint_url=s.storage_endpoint, region_name=s.storage_region,
        aws_access_key_id=s.backup_access_key or s.storage_access_key,
        aws_secret_access_key=s.backup_secret_key or s.storage_secret_key,
        config=Config(signature_version="s3v4", retries={"max_attempts": 8, "mode": "standard"}),
    ), s.backup_bucket


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def write_status(data: dict) -> None:
    f = get_settings().status_file
    if not f:
        return
    p = Path(f)
    try:
        current = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    except ValueError:
        current = {}
    current["backup"] = {**current.get("backup", {}), **data}
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(current, indent=2), encoding="utf-8")
    tmp.replace(p)


def _keys(client, bucket: str, prefix: str) -> list[str]:
    keys, token = [], None
    while True:
        kw = {"Bucket": bucket, "Prefix": prefix}
        if token:
            kw["ContinuationToken"] = token
        r = client.list_objects_v2(**kw)
        keys += [o["Key"] for o in r.get("Contents", [])]
        if not r.get("IsTruncated"):
            return sorted(keys)
        token = r["NextContinuationToken"]


def _prune(client, bucket: str, prefix: str, keep: int) -> list[str]:
    old = _keys(client, bucket, prefix)[:-keep] if keep > 0 else []
    for k in old:
        client.delete_object(Bucket=bucket, Key=k)
    return old


def upload(path: Path, now: datetime | None = None) -> str:
    """Upload a finished dump, add weekly/monthly copies, prune old copies. Returns the daily key."""
    s = get_settings()
    now = now or datetime.now(IST)
    client, bucket = _client()
    digest = sha256(path)
    size = path.stat().st_size
    key = f"daily/{path.name}"
    meta = {"sha256": digest, "created": now.isoformat()}
    with open(path, "rb") as fh:
        client.put_object(Bucket=bucket, Key=key, Body=fh, Metadata=meta, ContentType="application/octet-stream")
    head = client.head_object(Bucket=bucket, Key=key)
    if head["ContentLength"] != size or head.get("Metadata", {}).get("sha256") != digest:
        raise RuntimeError("Uploaded backup does not match the local file")
    copies = (["weekly"] if now.weekday() == 6 else []) + (["monthly"] if now.day == 1 else [])
    for folder in copies:
        client.copy_object(Bucket=bucket, Key=f"{folder}/{path.name}", CopySource={"Bucket": bucket, "Key": key},
                           Metadata=meta, MetadataDirective="REPLACE")
    _prune(client, bucket, "daily/", s.backup_keep_daily)
    _prune(client, bucket, "weekly/", s.backup_keep_weekly)
    _prune(client, bucket, "monthly/", s.backup_keep_monthly)
    write_status({"running": False, "ok": True, "last_success": now.isoformat(), "last_attempt": now.isoformat(),
                  "file": f"{bucket}/{key}", "size_bytes": size, "sha256": digest, "error": None})
    return key


def fail(message: str, now: datetime | None = None) -> None:
    now = now or datetime.now(IST)
    write_status({"running": False, "ok": False, "last_attempt": now.isoformat(), "last_failure": now.isoformat(),
                  "error": message[:500]})


def listing() -> list[dict]:
    client, bucket = _client()
    out = []
    for prefix in ("daily/", "weekly/", "monthly/"):
        for k in _keys(client, bucket, prefix):
            h = client.head_object(Bucket=bucket, Key=k)
            out.append({"key": k, "size": h["ContentLength"], "modified": h["LastModified"].isoformat()})
    return out


def download(key: str, dest: Path) -> Path:
    client, bucket = _client()
    expected = client.head_object(Bucket=bucket, Key=key).get("Metadata", {}).get("sha256")
    tmp = dest.with_name(dest.name + ".part")
    client.download_file(bucket, key, str(tmp))
    if expected and sha256(tmp) != expected:
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"{key}: checksum mismatch — the download is damaged")
    tmp.replace(dest)
    return dest


def main(argv: list[str]) -> int:
    if len(argv) < 2 or argv[1] not in ("upload", "fail", "list", "download"):
        print(__doc__)
        return 2
    cmd = argv[1]
    try:
        if cmd == "upload":
            print("uploaded", upload(Path(argv[2])))
        elif cmd == "fail":
            fail(" ".join(argv[2:]) or "backup failed")
        elif cmd == "list":
            for row in listing():
                print(f"{row['key']:<50} {row['size']:>12,}  {row['modified']}")
        else:
            print("downloaded", download(argv[2], Path(argv[3])))
        return 0
    except Exception as exc:  # noqa: BLE001 - recorded for the status page, then reported to cron
        if cmd == "upload":
            fail(f"upload failed: {type(exc).__name__}: {exc}")
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
