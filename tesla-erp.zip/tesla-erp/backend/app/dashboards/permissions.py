from app.core.permissions import register

# The management dashboard: sales funnel, billing and collections, receivables, cash, top projects and margins.
register("dashboard", "Management dashboard (company-wide sales, billing, cash and project margins)", ("read",))
