"""Director / Manager dashboard (Spec §33; plan Phase 10 exit: loads in under 2 seconds on production-sized data).

Everything is aggregated in SQL in one request (`GET /dashboard/director`) and computed from the same ledgers and
rules as the reports, so the tiles reconcile with them:
  * billed / collected by month = the *Billing vs collections* report;
  * receivables ageing = Finance → Receivables and the *Receivables ageing* report;
  * cash position = the Bank and Cash ledgers in the journal (trial balance);
  * project margin = Projects → Profitability.
"""
from datetime import date, datetime, time, timedelta
from decimal import Decimal

from sqlalchemy import func, literal, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.core.money import round_amount
from app.crm.service import IST, today

Z = Decimal("0")


def _s(v) -> str:
    return str(round_amount(Decimal(v or 0)))


def fy_bounds(t: date) -> tuple[date, date]:
    start = date(t.year if t.month >= 4 else t.year - 1, 4, 1)
    return start, date(start.year + 1, 3, 31)


def _months(start: date) -> list[date]:
    return [date(start.year + (start.month + i - 1) // 12, (start.month + i - 1) % 12 + 1, 1) for i in range(12)]


def funnel(db: Session, start: date, end: date) -> list[dict]:
    from app.crm.models import Enquiry, Lead
    from app.quotations.models import Quotation, QuotationRevision
    from app.sales.models import SalesOrder

    t0 = datetime.combine(start, time.min, IST)
    t1 = datetime.combine(end + timedelta(days=1), time.min, IST)
    leads = db.execute(select(func.count(), func.coalesce(func.sum(Lead.estimated_value), 0))
                       .where(Lead.created_at >= t0, Lead.created_at < t1)).one()
    won = db.scalar(select(func.count()).select_from(Lead).where(Lead.created_at >= t0, Lead.created_at < t1,
                                                                 Lead.status == "won")) or 0
    enq = db.execute(select(func.count(), func.coalesce(func.sum(Enquiry.estimated_value), 0))
                     .where(Enquiry.enquiry_date.between(start, end), Enquiry.status != "cancelled")).one()
    rev = QuotationRevision
    qtn = db.execute(select(func.count(), func.coalesce(func.sum(rev.taxable), 0))
                     .select_from(Quotation)
                     .join(rev, (rev.quotation_id == Quotation.id) & (rev.revision_no == Quotation.current_revision_no))
                     .where(Quotation.first_sent_at >= t0, Quotation.first_sent_at < t1)).one()
    so = db.execute(select(func.count(), func.coalesce(func.sum(SalesOrder.taxable), 0))
                    .where(SalesOrder.so_date.between(start, end), SalesOrder.status != "cancelled")).one()
    return [
        {"stage": "leads", "label": "Leads", "count": leads[0], "value": _s(leads[1]), "note": f"{won} won",
         "href": "/crm/leads"},
        {"stage": "enquiries", "label": "Enquiries", "count": enq[0], "value": _s(enq[1]), "href": "/crm/enquiries"},
        {"stage": "quotations", "label": "Quotations sent", "count": qtn[0], "value": _s(qtn[1]),
         "href": "/sales/quotations"},
        {"stage": "orders", "label": "Orders", "count": so[0], "value": _s(so[1]), "href": "/sales/orders"},
    ]


def monthly(db: Session, start: date, end: date) -> list[dict]:
    """Order intake, billing (before and with GST, net of credit notes) and collections (incl. TDS) per month."""
    from app.finance.models import CreditNote, Invoice, Receipt
    from app.sales.models import SalesOrder

    zero = literal(0)
    so = select(SalesOrder.so_date.label("d"), SalesOrder.taxable.label("o"), zero.label("b"), zero.label("bg"),
                zero.label("c")).where(SalesOrder.status != "cancelled", SalesOrder.so_date.between(start, end))
    inv = select(Invoice.invoice_date, zero, Invoice.taxable, Invoice.grand_total, zero) \
        .where(Invoice.status.in_(("issued", "cancelled")), Invoice.invoice_date.between(start, end))
    cn = select(CreditNote.cn_date, zero, -CreditNote.taxable, -CreditNote.total, zero) \
        .where(CreditNote.cn_date.between(start, end))
    rc = select(Receipt.receipt_date, zero, zero, zero, Receipt.amount + Receipt.tds_amount) \
        .where(Receipt.status == "posted", Receipt.receipt_date.between(start, end))
    u = so.union_all(inv, cn, rc).subquery()
    m = func.date_trunc("month", u.c.d)
    got = {mm.date(): (o, b, bg, c) for mm, o, b, bg, c in db.execute(
        select(m, func.sum(u.c.o), func.sum(u.c.b), func.sum(u.c.bg), func.sum(u.c.c)).group_by(m))}
    out = []
    for d in _months(start):
        o, b, bg, c = got.get(d, (0, 0, 0, 0))
        out.append({"month": d.strftime("%b %Y"), "short": d.strftime("%b"), "order_intake": _s(o), "billed": _s(b),
                    "billed_gross": _s(bg), "collected": _s(c)})
    return out


def cash_position(db: Session) -> dict:
    from app.finance.models import JournalLine, LedgerAccount

    rows = dict(db.execute(select(LedgerAccount.system_key, func.sum(JournalLine.debit - JournalLine.credit))
                           .join(LedgerAccount, LedgerAccount.id == JournalLine.account_id)
                           .where(LedgerAccount.system_key.in_(("bank", "cash")))
                           .group_by(LedgerAccount.system_key)).all())
    bank, cash = Decimal(rows.get("bank") or 0), Decimal(rows.get("cash") or 0)
    return {"bank": _s(bank), "cash": _s(cash), "total": _s(bank + cash)}


def top_projects(db: Session, limit: int = 10) -> list[dict]:
    from app.costing.service import CLOSED, profitability
    from app.customers.models import Customer
    from app.projects.models import Project

    out = []
    rows = db.execute(select(Project, Customer.customer_name).join(Customer, Customer.id == Project.customer_id)
                      .where(Project.status.not_in(CLOSED))
                      .order_by(Project.contract_value.desc(), Project.project_number).limit(limit)).all()
    for prj, cust in rows:
        pr = profitability(db, prj)
        out.append({"id": str(prj.id), "project_number": prj.project_number, "name": prj.name, "customer": cust,
                    "status": prj.status, "progress_pct": prj.progress_pct, "contract_value": _s(prj.contract_value),
                    "target_end_date": prj.target_end_date.isoformat() if prj.target_end_date else None,
                    "late": bool(prj.target_end_date and prj.target_end_date < today()),
                    "billed": pr["actual"]["revenue"], "cost": pr["actual"]["cost"], "profit": pr["actual"]["profit"],
                    "margin_pct": pr["actual"]["margin_pct"], "estimated_margin_pct": pr["estimated"]["margin_pct"]})
    return out


def approvals_pending(db: Session, p: Principal) -> dict:
    from app.platform.approvals import service as approvals
    from app.platform.approvals.models import ApprovalRequest

    rows = db.execute(select(ApprovalRequest.entity_type, func.count(), func.min(ApprovalRequest.requested_at))
                      .where(ApprovalRequest.status == "pending").group_by(ApprovalRequest.entity_type)).all()
    oldest = min((r[2] for r in rows), default=None)
    return {"total": sum(r[1] for r in rows), "mine": len(approvals.inbox(db, p)),
            "by_type": {r[0]: r[1] for r in rows},
            "oldest_days": (today() - oldest.astimezone(IST).date()).days if oldest else None}


def director(db: Session, p: Principal) -> dict:
    from app.finance import reports as fin

    t = today()
    start, end = fy_bounds(t)
    months = monthly(db, start, end)
    billed_gross = sum((Decimal(m["billed_gross"]) for m in months), Z)
    collected = sum((Decimal(m["collected"]) for m in months), Z)
    rec = fin.receivables(db, t)["totals"]
    pay = fin.payables(db, t)["totals"]
    overdue = sum((Decimal(rec[k]) for k in ("d0_30", "d31_60", "d61_90", "d90")), Z)
    cash = cash_position(db)
    return {
        "as_of": t.isoformat(), "fy": {"start": start.isoformat(), "end": end.isoformat(),
                                       "label": f"FY {start.year}-{str(start.year + 1)[2:]}"},
        "funnel": funnel(db, start, end),
        "months": months,
        "totals": {"order_intake": _s(sum((Decimal(m["order_intake"]) for m in months), Z)),
                   "billed": _s(sum((Decimal(m["billed"]) for m in months), Z)),
                   "billed_gross": _s(billed_gross), "collected": _s(collected),
                   "collection_pct": _s(collected * 100 / billed_gross) if billed_gross else None},
        "receivables": {**rec, "overdue": _s(overdue),
                        "net": _s(Decimal(rec["outstanding"]) - Decimal(rec["advance"]))},
        "payables": {"outstanding": pay["outstanding"], "advance": pay["advance"],
                     "net": _s(Decimal(pay["outstanding"]) - Decimal(pay["advance"]))},
        "cash": {**cash, "receivable": _s(Decimal(rec["outstanding"]) - Decimal(rec["advance"])),
                 "payable": _s(Decimal(pay["outstanding"]) - Decimal(pay["advance"]))},
        "top_projects": top_projects(db),
        "approvals": approvals_pending(db, p),
    }
