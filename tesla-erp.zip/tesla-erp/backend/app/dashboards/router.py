"""Dashboards API (Spec §33). Role tiles come from each module's /summary endpoint; the management dashboard is
one aggregated call."""
from typing import Annotated

from fastapi import APIRouter

from app.auth.deps import Principal, require
from app.core.api import ok
from app.core.db import DbSession
from app.dashboards import service

router = APIRouter(tags=["dashboards"])


@router.get("/dashboard/director")
def director_dashboard(db: DbSession, p: Annotated[Principal, require("dashboard.read")]):
    return ok(service.director(db, p))
