"""Import every model so SQLAlchemy metadata (and Alembic autogenerate) sees all tables."""
from app.auth.models import RefreshToken, UserMFA  # noqa: F401
from app.boq.models import Boq, BoqItem  # noqa: F401
from app.chat.models import ChatAttachment, ChatChannel, ChatMember, ChatMessage  # noqa: F401
from app.company.models import BusinessDivision, Company  # noqa: F401
from app.core.models import Base  # noqa: F401
from app.costing.models import MaterialIssue, MaterialIssueLine, ProjectBudget, ProjectCostEntry  # noqa: F401
from app.crm.models import CrmActivity, Enquiry, Lead, SiteVisit  # noqa: F401
from app.customers.models import Customer, CustomerAddress, CustomerContact, CustomerSite  # noqa: F401
from app.finance.models import (  # noqa: F401
                                 CreditNote,
                                 ExpenseCategory,
                                 ExpenseClaim,
                                 Invoice,
                                 InvoiceItem,
                                 JournalEntry,
                                 JournalLine,
                                 LedgerAccount,
                                 Receipt,
                                 ReceiptAllocation,
                                 SupplierInvoice,
                                 SupplierInvoiceItem,
                                 SupplierPayment,
                                 SupplierPaymentAllocation,
)
from app.hr.models import (  # noqa: F401
                                 Attendance,
                                 Department,
                                 Designation,
                                 Employee,
                                 Holiday,
                                 LeaveAdjustment,
                                 LeaveRequest,
                                 LeaveType,
                                 SalaryRecord,
)
from app.incentives.models import (  # noqa: F401
                                 IncentiveBillFollowup,
                                 IncentiveCategory,
                                 IncentiveLine,
                                 IncentiveMonth,
                                 IncentivePayout,
                                 IncentiveRole,
                                 IncentiveRoleMember,
                                 IncentiveRule,
                                 PerformanceRating,
                                 ProjectIncentiveSettings,
)
from app.inventory.models import (  # noqa: F401
                                 StockAdjustment,
                                 StockAdjustmentLine,
                                 StockBalance,
                                 StockBatch,
                                 StockSerial,
                                 StockTransaction,
                                 StockTransfer,
                                 StockTransferLine,
)
from app.platform.approvals.models import ApprovalAction, ApprovalPolicy, ApprovalRequest  # noqa: F401
from app.platform.audit.models import AuditLog  # noqa: F401
from app.platform.documents.models import Document  # noqa: F401
from app.platform.jobs.models import Job  # noqa: F401
from app.platform.notifications.models import AlertRun, Notification, NotificationPreference  # noqa: F401
from app.platform.numbering.models import DocumentSequence, NumberingFormat  # noqa: F401
from app.platform.search_indexes import INDEXES as _SEARCH_INDEXES  # noqa: F401 - trigram indexes for search
from app.platform.settings.models import AppSetting  # noqa: F401
from app.products.models import Brand, Item, ItemCategory, TaxRate, Unit, Warehouse  # noqa: F401
from app.projects.models import (  # noqa: F401
                                 InstallationEntry,
                                 Project,
                                 ProjectBoqLine,
                                 ProjectIssue,
                                 ProjectMember,
                                 ProjectMilestone,
                                 ProjectTask,
                                 SiteReport,
)
from app.purchase.models import (  # noqa: F401
                                 Grn,
                                 GrnLine,
                                 MaterialRequest,
                                 MaterialRequestLine,
                                 PurchaseOrder,
                                 PurchaseOrderItem,
                                 PurchaseRequest,
                                 PurchaseRequestLine,
)
from app.purchase.rfq_models import Rfq, RfqLine, VendorQuotation, VendorQuotationLine  # noqa: F401
from app.quotations.models import Quotation, QuotationItem, QuotationRevision, QuotationTerm  # noqa: F401
from app.sales.models import SalesOrder, SalesOrderItem  # noqa: F401
from app.suppliers.models import Supplier, SupplierAddress, SupplierBankAccount, SupplierContact  # noqa: F401
from app.tally.models import (  # noqa: F401
                                 TallyConnectorKey,
                                 TallyJob,
                                 TallyLedgerMap,
                                 TallyReconciliation,
                                 TallySettings,
                                 TallySyncRecord,
)
from app.users.models import Permission, Role, RolePermission, User, UserRole  # noqa: F401
