"""Import every model so SQLAlchemy metadata (and Alembic autogenerate) sees all tables."""
from app.auth.models import RefreshToken, UserMFA  # noqa: F401
from app.company.models import BusinessDivision, Company  # noqa: F401
from app.core.models import Base  # noqa: F401
from app.customers.models import Customer, CustomerAddress, CustomerContact, CustomerSite  # noqa: F401
from app.hr.models import Department, Designation, Employee  # noqa: F401
from app.platform.audit.models import AuditLog  # noqa: F401
from app.platform.documents.models import Document  # noqa: F401
from app.platform.jobs.models import Job  # noqa: F401
from app.platform.numbering.models import DocumentSequence, NumberingFormat  # noqa: F401
from app.platform.settings.models import AppSetting  # noqa: F401
from app.products.models import Brand, Item, ItemCategory, TaxRate, Unit, Warehouse  # noqa: F401
from app.suppliers.models import Supplier, SupplierAddress, SupplierBankAccount, SupplierContact  # noqa: F401
from app.users.models import Permission, Role, RolePermission, User, UserRole  # noqa: F401
