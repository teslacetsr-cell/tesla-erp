"""Background worker: `python -m app.worker`. Runs queued jobs (notification emails, PDFs), the housekeeping,
the nightly stock check and the daily alerts (app/platform/notifications/alerts.py)."""
import logging
import signal
import time

from app.core.db import SessionLocal
from app.platform.jobs.service import run_pending

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("worker")
_running = True


def _stop(*_):
    global _running
    _running = False


PERIODIC_SECONDS = 1800  # housekeeping every 30 minutes


def housekeeping() -> None:
    """Time-based state changes: quotations whose validity has passed become Expired."""
    from app.quotations.service import expire_due

    with SessionLocal() as db:
        n = expire_due(db)
        db.commit()
    if n:
        log.info("marked %d quotation(s) expired", n)


_last_stock_check: str | None = None


def stock_check() -> None:
    """Once a night (after 02:00 India time): rebuild every stock balance from the ledger and compare it with the
    cached balance. Any difference is logged and the administrators are told (Architecture §7.1)."""
    global _last_stock_check
    from app.crm.service import now
    from app.inventory.ledger import verify
    from app.platform.notifications.service import notify, users_with_roles

    t = now()
    day = t.date().isoformat()
    if t.hour < 2 or _last_stock_check == day:
        return
    _last_stock_check = day
    with SessionLocal() as db:
        problems = verify(db)
        if problems:
            log.error("stock ledger check: %d balance(s) differ from the ledger: %s", len(problems), problems[:5])
            notify(db, users_with_roles(db, ["ADMIN"]), event="stock.mismatch",
                   title=f"Stock check: {len(problems)} balance(s) differ from the ledger",
                   body="Open Inventory → Stock → Check ledger, and contact support.", link="/inventory/stock")
            db.commit()
        else:
            log.info("stock ledger check: all balances match the ledger")


def daily_alerts() -> None:
    """Once a day after `alerts.run_hour` (India time): overdue invoices, bills due, late projects, low stock… and
    the daily digest emails. Checks at most every 5 minutes; idempotent per day."""
    from app.platform.notifications.alerts import maybe_run

    maybe_run(SessionLocal)


def main() -> None:
    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)
    log.info("worker started")
    import app.inventory.service  # noqa: F401 - registers the stock adjustment approval handler
    import app.models  # noqa: F401 - every table registered
    import app.platform.notifications.service  # noqa: F401 - registers the notification delivery job
    import app.purchase.service  # noqa: F401 - registers the purchase request / order approval handlers
    import app.quotations.router  # noqa: F401 - registers the quotation approval handler
    import app.registry  # noqa: F401 - approval handlers and permission codes

    last = 0.0
    while _running:
        if time.monotonic() - last > PERIODIC_SECONDS:
            last = time.monotonic()
            try:
                housekeeping()
                stock_check()
            except Exception:  # noqa: BLE001
                log.exception("housekeeping error")
        try:
            daily_alerts()
        except Exception:  # noqa: BLE001 - keep the worker alive; errors are logged
            log.exception("daily alerts error")
        try:
            n = run_pending(SessionLocal, limit=20)
        except Exception:  # noqa: BLE001 - keep the worker alive; errors are logged
            log.exception("worker loop error")
            n = 0
        if n == 0:
            time.sleep(2)
    log.info("worker stopped")


if __name__ == "__main__":
    main()
