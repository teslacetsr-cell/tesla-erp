"""Background worker: `python -m app.worker`. Runs queued jobs (PDFs, emails, reminders from later phases)."""
import logging
import signal
import time

from app.core.db import SessionLocal
from app.platform.jobs.service import run_pending

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("worker")
_running = True


def _stop(*_):
    global _running
    _running = False


def main() -> None:
    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)
    log.info("worker started")
    while _running:
        try:
            n = run_pending(SessionLocal, limit=20)
        except Exception:  # noqa: BLE001 - keep the worker alive; errors are logged
            log.exception("worker loop error")
            n = 0
        if n == 0:
            time.sleep(2)
    log.info("worker stopped")


if __name__ == "__main__":
    main()
