"""Report registry: what a report is, its filters and columns, who may run it, and the runner that shapes results.

A report is registered with `@report(...)` on its `run(db, p, f) -> {"rows": [...], "totals": {...}}` function.
`run` aggregates in SQL (no per-row queries) and returns raw values (Decimal, date, int, str); the runner formats
them for JSON (money as strings, never floats), fills totals for money / quantity columns that `run` did not total
itself, and caps the rows at MAX_ROWS.
"""
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Any

from sqlalchemy import func

from app.auth.deps import Principal
from app.core.errors import AppError
from app.core.money import round_amount, round_qty
from app.crm.service import today

MAX_ROWS = 5000
Z = Decimal("0")
GROUPS = ("Sales & CRM", "Projects", "Purchase", "Inventory", "Finance", "HR")
COL_TYPES = ("text", "date", "money", "qty", "int", "pct")


@dataclass(frozen=True)
class Col:
    key: str
    label: str
    type: str = "text"
    width: int = 14            # characters (Excel); the PDF scales the widths to the page
    total: bool | None = None  # None: money and qty columns are totalled

    @property
    def totalled(self) -> bool:
        return self.total if self.total is not None else self.type in ("money", "qty")

    def out(self) -> dict:
        return {"key": self.key, "label": self.label, "type": self.type, "width": self.width}


# ------------------------------------------------------------------ filters
@dataclass
class Filters:
    date_from: date | None = None
    date_to: date | None = None
    as_of: date | None = None
    month: str | None = None
    customer_id: uuid.UUID | None = None
    supplier_id: uuid.UUID | None = None
    project_id: uuid.UUID | None = None
    employee_id: uuid.UUID | None = None
    user_id: uuid.UUID | None = None
    division_id: uuid.UUID | None = None
    warehouse_id: uuid.UUID | None = None
    item_id: uuid.UUID | None = None
    status: str | None = None
    source: str | None = None
    group_by: str | None = None

    def month_bounds(self) -> tuple[date, date]:
        y, m = (int(x) for x in (self.month or today().strftime("%Y-%m")).split("-"))
        start = date(y, m, 1)
        end = date(y + (m == 12), m % 12 + 1, 1) - timedelta(days=1)
        return start, end


# Filter kinds the UI knows how to draw. `source` names an option list served by GET /reports/options/{source}.
FILTER_DEFS: dict[str, dict] = {
    "period": {"type": "daterange", "label": "Period", "keys": ["date_from", "date_to"]},
    "as_of": {"type": "date", "label": "As on", "keys": ["as_of"]},
    "month": {"type": "month", "label": "Month", "keys": ["month"]},
    "customer_id": {"type": "select", "label": "Customer", "source": "customers"},
    "supplier_id": {"type": "select", "label": "Supplier", "source": "suppliers"},
    "project_id": {"type": "select", "label": "Project", "source": "projects"},
    "employee_id": {"type": "select", "label": "Employee", "source": "employees"},
    "user_id": {"type": "select", "label": "User", "source": "users"},
    "division_id": {"type": "select", "label": "Division", "source": "divisions"},
    "warehouse_id": {"type": "select", "label": "Warehouse", "source": "warehouses"},
    "item_id": {"type": "select", "label": "Item", "source": "items"},
    "status": {"type": "select", "label": "Status"},
    "source": {"type": "select", "label": "Source"},
    "group_by": {"type": "select", "label": "Group by"},
}
UUID_FILTERS = ("customer_id", "supplier_id", "project_id", "employee_id", "user_id", "division_id", "warehouse_id",
                "item_id")
SOURCES = ("customers", "suppliers", "projects", "employees", "users", "divisions", "warehouses", "items")


def _label(v: str) -> str:
    return v.replace("_", " ").capitalize()


def options(values) -> list[dict]:
    """[("value", "Label")…] or plain values → [{value, label}]."""
    return [{"value": v[0], "label": v[1]} if isinstance(v, tuple) else {"value": v, "label": _label(v)} for v in values]


# ------------------------------------------------------------------ reports
@dataclass
class Report:
    key: str
    title: str
    group: str
    description: str
    perm: tuple[str, ...]                  # any one of these permissions lets the user run it
    run: Callable[..., dict]
    columns: list[Col] | Callable[[Filters], list[Col]]
    filters: list[tuple[str, dict]] = field(default_factory=list)
    period: str | None = "fy"              # default period: fy | month | None
    need_all: bool = False                 # the permission's scope must be 'all' (own records have their own pages)

    def allowed(self, p: Principal) -> bool:
        for code in self.perm:
            scope = p.scope(code)
            if scope is not None and (not self.need_all or scope == "all"):
                return True
        return False

    def cols(self, f: Filters) -> list[Col]:
        return self.columns(f) if callable(self.columns) else self.columns

    def filter_keys(self) -> set[str]:
        return {name for name, _ in self.filters}

    def default_filters(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        t = today()
        names = self.filter_keys()
        if "period" in names and self.period:
            if self.period == "month":
                out["date_from"] = t.replace(day=1)
                out["date_to"] = date(t.year + (t.month == 12), t.month % 12 + 1, 1) - timedelta(days=1)
            else:
                start = date(t.year if t.month >= 4 else t.year - 1, 4, 1)
                out["date_from"], out["date_to"] = start, date(start.year + 1, 3, 31)
        if "as_of" in names:
            out["as_of"] = t
        if "month" in names:
            out["month"] = t.strftime("%Y-%m")
        for name, extra in self.filters:
            if "default" in extra:
                out[name] = extra["default"]
        return out

    def catalog_entry(self) -> dict:
        defaults = self.default_filters()
        filters = []
        for name, extra in self.filters:
            d = {"name": name, **FILTER_DEFS[name], **{k: v for k, v in extra.items() if k != "default"}}
            if "options" in d:
                d["options"] = options(d["options"])
            keys = d.pop("keys", [name])
            d["keys"] = keys
            d["default"] = {k: _jsonable(defaults.get(k)) for k in keys if defaults.get(k) is not None}
            filters.append(d)
        return {"key": self.key, "title": self.title, "group": self.group, "description": self.description,
                "filters": filters, "columns": [c.out() for c in self.cols(Filters())]}


REPORTS: dict[str, Report] = {}


def report(key: str, title: str, group: str, description: str, *, perm: str | tuple[str, ...],
           columns, filters=(), period: str | None = "fy", need_all: bool = False):
    if group not in GROUPS:
        raise ValueError(group)

    def deco(fn):
        flt = [(x, {}) if isinstance(x, str) else x for x in filters]
        for name, _ in flt:
            if name not in FILTER_DEFS:
                raise ValueError(f"{key}: unknown filter {name}")
        REPORTS[key] = Report(key=key, title=title, group=group, description=description,
                              perm=(perm,) if isinstance(perm, str) else tuple(perm), run=fn, columns=columns,
                              filters=flt, period=period, need_all=need_all)
        return fn

    return deco


# ------------------------------------------------------------------ parsing & running
def parse_filters(r: Report, query: dict[str, str]) -> Filters:
    """Query-string values → Filters, starting from the report's defaults. Unknown or blank keys are ignored."""
    vals = r.default_filters()
    allowed = set()
    for name, extra in r.filters:
        d = {**FILTER_DEFS[name], **extra}
        allowed.update(d.get("keys", [name]))
    for k, raw in query.items():
        if k not in allowed:
            continue
        v = (raw or "").strip()
        if not v or v == "-":
            vals.pop(k, None)   # explicitly cleared ("-": the UI's "all / no limit")
            continue
        try:
            if k in ("date_from", "date_to", "as_of"):
                vals[k] = date.fromisoformat(v)
            elif k in UUID_FILTERS:
                vals[k] = uuid.UUID(v)
            elif k == "month":
                datetime.strptime(v, "%Y-%m")
                vals[k] = v
            else:
                vals[k] = v[:40]
        except ValueError as exc:
            raise AppError("INVALID_FILTER", f"'{v}' is not a valid value for {k}.", details={"field": k}) from exc
    for name, extra in r.filters:
        opts = extra.get("options")
        if opts and vals.get(name) is not None:
            allowed_vals = {o[0] if isinstance(o, tuple) else o for o in opts}
            if vals[name] not in allowed_vals:
                raise AppError("INVALID_FILTER", f"'{vals[name]}' is not a valid {name.replace('_', ' ')}.",
                               details={"field": name})
    if vals.get("date_from") and vals.get("date_to") and vals["date_from"] > vals["date_to"]:
        raise AppError("INVALID_FILTER", "The period starts after it ends.", details={"field": "date_from"})
    return Filters(**vals)


def _jsonable(v: Any) -> Any:
    if isinstance(v, (date, datetime)):
        return v.isoformat()[:10] if isinstance(v, date) and not isinstance(v, datetime) else v.isoformat()
    if isinstance(v, uuid.UUID):
        return str(v)
    if isinstance(v, Decimal):
        return str(v)
    return v


def fmt(c: Col, v: Any) -> Any:
    if v is None or v == "":
        return None
    if c.type == "money":
        return str(round_amount(v))
    if c.type == "qty":
        return str(round_qty(v))
    if c.type == "pct":
        return str(Decimal(v).quantize(Decimal("0.01")))
    if c.type == "int":
        return int(v)
    if c.type == "date":
        return v.isoformat()[:10] if isinstance(v, (date, datetime)) else str(v)
    return str(v) if not isinstance(v, str) else v


def execute(db, p: Principal, r: Report, f: Filters) -> dict:
    res = r.run(db, p, f)
    cols = r.cols(f)
    rows = res["rows"]
    totals = dict(res.get("totals") or {})
    for c in cols:
        if c.totalled and c.key not in totals:
            totals[c.key] = sum((Decimal(x[c.key]) for x in rows if x.get(c.key) not in (None, "")), Z)
    out_rows = [{**{c.key: fmt(c, x.get(c.key)) for c in cols},
                 **({"_link": x["_link"]} if x.get("_link") else {})} for x in rows[:MAX_ROWS]]
    by_key = {c.key: c for c in cols}
    out_totals = {k: (fmt(by_key[k], v) if k in by_key else _jsonable(v)) for k, v in totals.items()}
    applied = {k: _jsonable(v) for k, v in vars(f).items() if v is not None}
    return {"key": r.key, "title": r.title, "columns": [c.out() for c in cols], "rows": out_rows,
            "totals": out_totals, "filters_applied": applied, "row_count": len(rows),
            "truncated": len(rows) > MAX_ROWS}


# ------------------------------------------------------------------ SQL helpers used by the report modules
def ist_date(col):
    """The IST calendar date of a timestamptz column."""
    return func.date(func.timezone("Asia/Kolkata", col))


def between(stmt, col, f: Filters):
    if f.date_from:
        stmt = stmt.where(col >= f.date_from)
    if f.date_to:
        stmt = stmt.where(col <= f.date_to)
    return stmt


def eq(stmt, pairs):
    """Adds col == value for every pair whose value is set."""
    for col, val in pairs:
        if val is not None:
            stmt = stmt.where(col == val)
    return stmt


def D(v) -> Decimal:
    return Decimal(v) if v is not None else Z


def pct(num, den) -> Decimal | None:
    num, den = D(num), D(den)
    return (num * 100 / den) if den else None
