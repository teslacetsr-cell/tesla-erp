"""Reports (Phase 10): every register and summary report, with common filters and Excel / PDF export.

`registry` holds the framework (filters, columns, the report catalog and the runner); the report definitions live
in one module per area and register themselves on import (see `catalog`)."""
