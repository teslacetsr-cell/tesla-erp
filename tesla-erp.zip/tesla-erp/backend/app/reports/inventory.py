"""Inventory reports: stock summary, stock movement, low stock, material issue register."""
from decimal import Decimal

from sqlalchemy import and_, case, false, func, or_, select, true
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.costing.models import ISSUE_STATUSES, MaterialIssue, MaterialIssueLine
from app.inventory.models import StockBalance, StockTransaction
from app.products.models import Item, Unit, Warehouse
from app.projects import service as projects
from app.projects.models import Project
from app.purchase.models import PurchaseOrder, PurchaseOrderItem
from app.reports.registry import Col, D, Filters, between, eq, ist_date, report

Z = Decimal("0")


@report("stock_summary", "Stock summary", "Inventory",
        "Stock on hand per item and warehouse, valued at weighted average cost.",
        perm="stock.read", filters=["warehouse_id", "item_id"], period=None,
        columns=[Col("warehouse", "Warehouse", width=18), Col("item_code", "Item code", width=14),
                 Col("item_name", "Item", width=34), Col("unit", "Unit", width=6),
                 Col("quantity", "Quantity", "qty", 11, False), Col("wac", "Avg cost", "money", 12, False),
                 Col("value", "Value", "money", 15), Col("last_movement", "Last movement", "date", 12)])
def stock_summary(db: Session, p: Principal, f: Filters) -> dict:
    B = StockBalance
    stmt = (select(B.item_id, Warehouse.name, Item.item_code, Item.item_name, Unit.code, B.quantity, B.value,
                   ist_date(B.last_movement_at))
            .join(Item, Item.id == B.item_id).join(Unit, Unit.id == Item.unit_id)
            .join(Warehouse, Warehouse.id == B.warehouse_id)
            .where(or_(B.quantity != 0, B.value != 0)))
    stmt = eq(stmt, ((B.warehouse_id, f.warehouse_id), (B.item_id, f.item_id)))
    rows = []
    for iid, wh, code, name, unit, q, v, last in db.execute(stmt.order_by(Warehouse.name, Item.item_name)):
        rows.append({"warehouse": wh, "item_code": code, "item_name": name, "unit": unit, "quantity": q,
                     "wac": (v / q) if q else None, "value": v, "last_movement": last,
                     "_link": f"/inventory/stock/view?id={iid}"})
    return {"rows": rows}


@report("stock_movement", "Stock movement", "Inventory",
        "For each item and warehouse in the period: opening stock, receipts, issues and closing stock, with values.",
        perm="stock.read", filters=["period", "warehouse_id", "item_id"], period="month",
        columns=[Col("warehouse", "Warehouse", width=16), Col("item_code", "Item code", width=13),
                 Col("item_name", "Item", width=30), Col("unit", "Unit", width=6),
                 Col("opening_qty", "Opening qty", "qty", 10, False), Col("opening_value", "Opening value", "money", 13),
                 Col("in_qty", "In qty", "qty", 9, False), Col("in_value", "In value", "money", 13),
                 Col("out_qty", "Out qty", "qty", 9, False), Col("out_value", "Out value", "money", 13),
                 Col("closing_qty", "Closing qty", "qty", 10, False), Col("closing_value", "Closing value", "money", 13)])
def stock_movement(db: Session, p: Principal, f: Filters) -> dict:
    T = StockTransaction
    before = T.txn_date < f.date_from if f.date_from else false()
    within = and_(true(), *([T.txn_date >= f.date_from] if f.date_from else []), *([T.txn_date <= f.date_to] if f.date_to else []))
    inbound, outbound = and_(within, T.quantity > 0), and_(within, T.quantity < 0)

    def s(expr, cond):
        return func.coalesce(func.sum(case((cond, expr), else_=0)), 0)

    stmt = (select(Warehouse.name, Item.item_code, Item.item_name, Unit.code,
                   s(T.quantity, before), s(T.value, before), s(T.quantity, inbound), s(T.value, inbound),
                   s(-T.quantity, outbound), s(-T.value, outbound))
            .join(Item, Item.id == T.item_id).join(Unit, Unit.id == Item.unit_id)
            .join(Warehouse, Warehouse.id == T.warehouse_id)
            .group_by(Warehouse.name, Item.id, Item.item_code, Item.item_name, Unit.code))
    if f.date_to:
        stmt = stmt.where(T.txn_date <= f.date_to)
    stmt = eq(stmt, ((T.warehouse_id, f.warehouse_id), (T.item_id, f.item_id)))
    rows = []
    for wh, code, name, unit, oq, ov, iq, iv, xq, xv in db.execute(stmt.order_by(Warehouse.name, Item.item_name)):
        if not any((oq, iq, xq, ov, iv, xv)):
            continue
        rows.append({"warehouse": wh, "item_code": code, "item_name": name, "unit": unit, "opening_qty": oq,
                     "opening_value": ov, "in_qty": iq, "in_value": iv, "out_qty": xq, "out_value": xv,
                     "closing_qty": oq + iq - xq, "closing_value": ov + iv - xv})
    return {"rows": rows}


@report("low_stock", "Low stock", "Inventory",
        "Items whose stock is below their minimum or reorder level, with the quantity already on order.",
        perm="stock.read", filters=["warehouse_id"], period=None,
        columns=[Col("item_code", "Item code", width=14), Col("item_name", "Item", width=34),
                 Col("unit", "Unit", width=6), Col("in_stock", "In stock", "qty", 10, False),
                 Col("minimum", "Minimum", "qty", 10, False), Col("reorder_level", "Reorder level", "qty", 10, False),
                 Col("shortfall", "Shortfall", "qty", 10, False), Col("on_order", "On order", "qty", 10, False),
                 Col("level", "Level", width=16)])
def low_stock(db: Session, p: Principal, f: Filters) -> dict:
    bal = select(StockBalance.item_id.label("item_id"), func.sum(StockBalance.quantity).label("q")) \
        .group_by(StockBalance.item_id)
    if f.warehouse_id:
        bal = bal.where(StockBalance.warehouse_id == f.warehouse_id)
    bal = bal.subquery()
    po = (select(PurchaseOrderItem.item_id.label("item_id"),
                 func.sum(PurchaseOrderItem.quantity - PurchaseOrderItem.received_qty).label("q"))
          .join(PurchaseOrder, PurchaseOrder.id == PurchaseOrderItem.purchase_order_id)
          .where(PurchaseOrder.status.in_(("approved", "sent", "partially_received")),
                 PurchaseOrderItem.item_id.is_not(None)))
    if f.warehouse_id:
        po = po.where(PurchaseOrder.warehouse_id == f.warehouse_id)
    po = po.group_by(PurchaseOrderItem.item_id).subquery()
    qty = func.coalesce(bal.c.q, 0)
    stmt = (select(Item.id, Item.item_code, Item.item_name, Unit.code, qty, Item.minimum_stock, Item.reorder_level,
                   func.coalesce(po.c.q, 0))
            .join(Unit, Unit.id == Item.unit_id).outerjoin(bal, bal.c.item_id == Item.id)
            .outerjoin(po, po.c.item_id == Item.id)
            .where(Item.is_active.is_(True), Item.item_type == "goods",
                   or_(and_(Item.minimum_stock > 0, qty < Item.minimum_stock),
                       and_(Item.reorder_level > 0, qty < Item.reorder_level))))
    rows = []
    for iid, code, name, unit, q, mn, ro, oo in db.execute(stmt.order_by(Item.item_name)):
        target = max(mn, ro)
        rows.append({"item_code": code, "item_name": name, "unit": unit, "in_stock": q, "minimum": mn,
                     "reorder_level": ro, "shortfall": target - q, "on_order": oo,
                     "level": "Below minimum" if mn and q < mn else "Below reorder level",
                     "_link": f"/items/view?id={iid}"})
    return {"rows": rows}


@report("material_issue_register", "Material issue register", "Inventory",
        "Material issued to projects and returned from them; returns count negative so the value is net of returns.",
        perm="material_issue.read",
        filters=["period", "project_id", "warehouse_id", ("status", {"options": ISSUE_STATUSES, "default": "posted"})],
        period="month",
        columns=[Col("issue_number", "Number", width=14), Col("issue_date", "Date", "date", 11),
                 Col("kind", "Type", width=8), Col("project_number", "Project no.", width=13),
                 Col("project", "Project", width=24), Col("warehouse", "Store", width=14),
                 Col("issued_to", "Issued to", width=16), Col("lines", "Lines", "int", 6, True),
                 Col("excess", "Excess", width=7), Col("status", "Status", width=12),
                 Col("value", "Net value", "money", 14)])
def material_issue_register(db: Session, p: Principal, f: Filters) -> dict:
    M = MaterialIssue
    n = select(MaterialIssueLine.issue_id.label("iid"), func.count().label("n")).group_by(MaterialIssueLine.issue_id) \
        .subquery()
    val = func.coalesce(func.nullif(M.value, 0), M.estimated_value)
    stmt = (select(M.id, M.issue_number, M.issue_date, M.kind, Project.project_number, Project.name, Warehouse.name,
                   M.issued_to, func.coalesce(n.c.n, 0), M.has_excess, M.status, case((M.kind == "return", -val), else_=val))
            .join(Project, Project.id == M.project_id).join(Warehouse, Warehouse.id == M.warehouse_id)
            .outerjoin(n, n.c.iid == M.id))
    clause = projects.scope_clause(p, "material_issue.read")
    if clause is not None:
        stmt = stmt.where(clause)
    stmt = between(stmt, M.issue_date, f)
    stmt = eq(stmt, ((M.project_id, f.project_id), (M.warehouse_id, f.warehouse_id), (M.status, f.status)))
    rows = []
    for i, num, d, kind, pn, pname, wh, to, lines, excess, st, v in db.execute(
            stmt.order_by(M.issue_date.desc(), M.issue_number.desc().nulls_first())):
        rows.append({"issue_number": num or "DRAFT", "issue_date": d, "kind": kind, "project_number": pn,
                     "project": pname, "warehouse": wh, "issued_to": to, "lines": lines,
                     "excess": "Yes" if excess else None, "status": st.replace("_", " "), "value": D(v),
                     "_link": f"/inventory/issues/view?id={i}"})
    return {"rows": rows}
