"""Project reports: status register, task register (employee-wise), site reports, BOQ vs installed."""
from decimal import Decimal

from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session, aliased

from app.auth.deps import Principal
from app.costing.models import ProjectCostEntry
from app.crm.service import today
from app.customers.models import Customer
from app.finance.models import CreditNote, Invoice, Receipt
from app.projects import service as projects
from app.projects.models import PROJECT_STATUSES, TASK_STATUSES, Project, ProjectBoqLine, ProjectTask, SiteReport
from app.reports.registry import Col, D, Filters, between, eq, ist_date, pct, report
from app.users.models import User

Z = Decimal("0")
CLOSED = ("completed", "cancelled")


def _scoped(stmt, p: Principal, code: str):
    clause = projects.scope_clause(p, code)
    return stmt.where(clause) if clause is not None else stmt


def _project_money(db: Session, ids: list) -> dict:
    """Per project, in four grouped queries: billed (before GST, net of credit notes), collected, actual cost.
    An invoice or receipt belongs to the project when it names the project or the project's sales order — the
    same rule as finance.reports.project_finance."""
    if not ids:
        return {}
    belongs_inv = or_(Invoice.project_id == Project.id,
                      and_(Project.sales_order_id.is_not(None), Invoice.sales_order_id == Project.sales_order_id))
    inv = dict((pid, (D(t), D(r))) for pid, t, r in db.execute(
        select(Project.id, func.sum(Invoice.taxable), func.sum(Invoice.received)).join(Invoice, belongs_inv)
        .where(Project.id.in_(ids), Invoice.status.in_(("issued", "cancelled"))).group_by(Project.id)))
    cn = dict(db.execute(
        select(Project.id, func.sum(CreditNote.taxable)).join(Invoice, belongs_inv)
        .join(CreditNote, CreditNote.invoice_id == Invoice.id).where(Project.id.in_(ids)).group_by(Project.id)).all())
    belongs_rct = or_(Receipt.project_id == Project.id,
                      and_(Project.sales_order_id.is_not(None), Receipt.sales_order_id == Project.sales_order_id))
    adv = dict(db.execute(
        select(Project.id, func.sum(Receipt.amount + Receipt.tds_amount - Receipt.allocated)).join(Receipt, belongs_rct)
        .where(Project.id.in_(ids), Receipt.status == "posted").group_by(Project.id)).all())
    cost = dict(db.execute(select(ProjectCostEntry.project_id, func.sum(ProjectCostEntry.amount))
                           .where(ProjectCostEntry.project_id.in_(ids)).group_by(ProjectCostEntry.project_id)).all())
    out = {}
    for pid in ids:
        billed, received = inv.get(pid, (Z, Z))
        out[pid] = {"billed": billed - D(cn.get(pid)), "collected": received + D(adv.get(pid)), "cost": D(cost.get(pid))}
    return out


@report("project_status", "Project status register", "Projects",
        "Every project with its manager, progress, target date and lateness, contract value, billing, collections, "
        "actual cost and margin.",
        perm="project.read",
        filters=[("status", {"options": [("open", "Open (not completed / cancelled)")] + list(PROJECT_STATUSES),
                             "default": "open"}),
                 "customer_id", ("user_id", {"label": "Project manager"}), "division_id"],
        period=None,
        columns=[Col("project_number", "Project no.", width=14), Col("name", "Project", width=28),
                 Col("customer", "Customer", width=24), Col("manager", "Project manager", width=16),
                 Col("status", "Status", width=10), Col("progress", "Progress %", "int", 9),
                 Col("start_date", "Start", "date", 11), Col("target_date", "Target", "date", 11),
                 Col("days_late", "Days late", "int", 8), Col("contract_value", "Contract value", "money", 15),
                 Col("billed", "Billed (before GST)", "money", 15), Col("collected", "Collected", "money", 14),
                 Col("actual_cost", "Actual cost", "money", 14), Col("margin", "Margin", "money", 14),
                 Col("margin_pct", "Margin %", "pct", 8)])
def project_status(db: Session, p: Principal, f: Filters) -> dict:
    pm = aliased(User)
    stmt = (select(Project.id, Project.project_number, Project.name, Customer.customer_name, pm.full_name,
                   Project.status, Project.progress_pct, Project.start_date, Project.target_end_date,
                   Project.actual_end_date, Project.contract_value)
            .join(Customer, Customer.id == Project.customer_id).outerjoin(pm, pm.id == Project.project_manager_id))
    stmt = _scoped(stmt, p, "project.read")
    if f.status == "open":
        stmt = stmt.where(Project.status.not_in(CLOSED))
    elif f.status:
        stmt = stmt.where(Project.status == f.status)
    stmt = eq(stmt, ((Project.customer_id, f.customer_id), (Project.project_manager_id, f.user_id),
                     (Project.division_id, f.division_id)))
    data = db.execute(stmt.order_by(Project.project_number.desc())).all()
    money = _project_money(db, [r[0] for r in data])
    see_billing, see_cost = p.can("invoice.read") or p.can("project_cost.read"), p.can("project_cost.read")
    t = today()
    rows = []
    for pid, num, name, cust, mgr, st, prog, start, target, actual, cv in data:
        m = money[pid]
        end = actual or t
        late = (end - target).days if target and end > target and (st not in CLOSED or actual) else 0
        r = {"project_number": num, "name": name, "customer": cust, "manager": mgr, "status": st.replace("_", " "),
             "progress": prog, "start_date": start, "target_date": target, "days_late": late or None,
             "contract_value": cv, "_link": f"/projects/view?id={pid}"}
        if see_billing:
            r |= {"billed": m["billed"], "collected": m["collected"]}
        if see_cost:
            r |= {"actual_cost": m["cost"], "margin": m["billed"] - m["cost"],
                  "margin_pct": pct(m["billed"] - m["cost"], m["billed"])}
        rows.append(r)
    tb = sum((D(r.get("billed")) for r in rows), Z)
    tc = sum((D(r.get("actual_cost")) for r in rows), Z)
    return {"rows": rows, "totals": {"margin_pct": pct(tb - tc, tb) if see_cost else None}}


# ------------------------------------------------------------------ tasks
def _task_cols(f: Filters) -> list[Col]:
    if f.group_by == "assignee":
        return [Col("assignee", "Assignee", width=22), Col("total", "Tasks", "int", 8, True),
                Col("open", "Open", "int", 8, True), Col("in_progress", "In progress", "int", 9, True),
                Col("blocked", "Blocked", "int", 8, True), Col("overdue", "Overdue", "int", 8, True),
                Col("done_in_period", "Done in period", "int", 10, True), Col("oldest_overdue_days", "Oldest overdue (days)", "int", 12)]
    return [Col("assignee", "Assignee", width=18), Col("project_number", "Project no.", width=13),
            Col("project", "Project", width=24), Col("title", "Task", width=30), Col("priority", "Priority", width=9),
            Col("start_date", "Start", "date", 11), Col("due_date", "Due", "date", 11),
            Col("status", "Status", width=11), Col("overdue_days", "Days overdue", "int", 9),
            Col("completed_on", "Completed", "date", 11)]


@report("task_register", "Task register (employee-wise)", "Projects",
        "Project tasks by assignee with due date, status and days overdue — or a per-employee summary of open, "
        "overdue and completed tasks.",
        perm="site_work.read",
        filters=["period", ("group_by", {"options": [("task", "Task (detail)"), ("assignee", "Employee (summary)")],
                                         "default": "task"}),
                 ("user_id", {"label": "Assignee"}), "project_id",
                 ("status", {"options": [("open", "Open (not done)"), ("overdue", "Overdue")] + list(TASK_STATUSES)})],
        period="month", columns=_task_cols)
def task_register(db: Session, p: Principal, f: Filters) -> dict:
    """Detail: tasks due in the period, plus every task still open from before it (overdue work does not drop out).
    Summary: open / overdue counts as of today and tasks completed in the period, per assignee."""
    u = aliased(User)
    t = today()
    base_filter = []
    clause = projects.scope_clause(p, "site_work.read")
    if clause is not None:
        base_filter.append(or_(clause, ProjectTask.assigned_to == p.id))
    if f.user_id:
        base_filter.append(ProjectTask.assigned_to == f.user_id)
    if f.project_id:
        base_filter.append(ProjectTask.project_id == f.project_id)
    if f.status == "open":
        base_filter.append(ProjectTask.status != "done")
    elif f.status == "overdue":
        base_filter.append(and_(ProjectTask.status != "done", ProjectTask.due_date < t))
    elif f.status:
        base_filter.append(ProjectTask.status == f.status)
    done_on = ist_date(ProjectTask.completed_at)
    in_period = []
    if f.date_from:
        in_period.append(done_on >= f.date_from)
    if f.date_to:
        in_period.append(done_on <= f.date_to)
    is_open = ProjectTask.status != "done"
    overdue = and_(is_open, ProjectTask.due_date < t)
    if f.group_by == "assignee":
        name = func.coalesce(u.full_name, "(unassigned)")
        stmt = (select(name, func.count(), func.count().filter(is_open),
                       func.count().filter(ProjectTask.status == "in_progress"),
                       func.count().filter(ProjectTask.status == "blocked"), func.count().filter(overdue),
                       func.count().filter(and_(ProjectTask.status == "done", *in_period)),
                       func.max(t - ProjectTask.due_date).filter(overdue))
                .select_from(ProjectTask).join(Project, Project.id == ProjectTask.project_id)
                .outerjoin(u, u.id == ProjectTask.assigned_to).where(*base_filter).group_by(name).order_by(name))
        keys = ("assignee", "total", "open", "in_progress", "blocked", "overdue", "done_in_period", "oldest_overdue_days")
        return {"rows": [dict(zip(keys, v, strict=True)) for v in db.execute(stmt)]}
    rng = []
    if f.date_from:
        rng.append(ProjectTask.due_date >= f.date_from)
    if f.date_to:
        rng.append(ProjectTask.due_date <= f.date_to)
    window = None
    if rng:
        # due in the period, or still open from before it (or with no due date), or completed in the period
        window = or_(and_(*rng), and_(is_open, or_(ProjectTask.due_date.is_(None),
                                                   ProjectTask.due_date < (f.date_from or t))),
                     and_(ProjectTask.status == "done", *in_period))
    stmt = (select(ProjectTask.project_id, u.full_name, Project.project_number, Project.name, ProjectTask.title,
                   ProjectTask.priority, ProjectTask.start_date, ProjectTask.due_date, ProjectTask.status, done_on)
            .join(Project, Project.id == ProjectTask.project_id).outerjoin(u, u.id == ProjectTask.assigned_to)
            .where(*base_filter))
    if window is not None:
        stmt = stmt.where(window)
    rows = []
    for pid, who, pn, pname, title, prio, start, due, st, done in db.execute(
            stmt.order_by(u.full_name.nulls_last(), ProjectTask.due_date.nulls_last(), Project.project_number)):
        od = (t - due).days if st != "done" and due and due < t else None
        rows.append({"assignee": who or "(unassigned)", "project_number": pn, "project": pname, "title": title,
                     "priority": prio, "start_date": start, "due_date": due, "status": st.replace("_", " "),
                     "overdue_days": od, "completed_on": done, "_link": f"/projects/view?id={pid}&tab=tasks"})
    return {"rows": rows}


@report("site_report_register", "Site report register", "Projects",
        "Daily site reports: date, project, work done, manpower, weather, hindrances and progress.",
        perm="site_work.read", filters=["period", "project_id"], period="month",
        columns=[Col("report_date", "Date", "date", 11), Col("project_number", "Project no.", width=13),
                 Col("project", "Project", width=24), Col("work_done", "Work done", width=40),
                 Col("manpower", "Manpower", "int", 9, True), Col("weather", "Weather", width=10),
                 Col("hindrances", "Hindrances", width=26), Col("progress", "Progress %", "int", 9),
                 Col("reported_by", "Reported by", width=16)])
def site_report_register(db: Session, p: Principal, f: Filters) -> dict:
    u = aliased(User)
    stmt = (select(SiteReport.project_id, SiteReport.report_date, Project.project_number, Project.name,
                   SiteReport.work_done, SiteReport.manpower, SiteReport.weather, SiteReport.hindrances,
                   SiteReport.progress_pct, u.full_name)
            .join(Project, Project.id == SiteReport.project_id).outerjoin(u, u.id == SiteReport.created_by))
    stmt = _scoped(stmt, p, "site_work.read")
    stmt = between(stmt, SiteReport.report_date, f)
    stmt = eq(stmt, ((SiteReport.project_id, f.project_id),))
    keys = ("report_date", "project_number", "project", "work_done", "manpower", "weather", "hindrances", "progress",
            "reported_by")
    return {"rows": [dict(zip(keys, v, strict=True)) | {"_link": f"/projects/view?id={pid}&tab=site"}
                     for pid, *v in db.execute(stmt.order_by(SiteReport.report_date.desc(), Project.project_number))]}


@report("boq_vs_installed", "BOQ vs installed", "Projects",
        "Per project BOQ line: approved, procured, issued and installed quantities and what remains to install.",
        perm="project.read",
        filters=["project_id", ("status", {"options": [("open", "Open projects")] + list(PROJECT_STATUSES),
                                           "default": "open"}), "customer_id"],
        period=None,
        columns=[Col("project_number", "Project no.", width=13), Col("line_no", "Line", "int", 6),
                 Col("section", "Section", width=14), Col("description", "Description", width=36),
                 Col("unit", "Unit", width=6), Col("approved", "Approved", "qty", 10, False),
                 Col("procured", "Procured", "qty", 10, False), Col("issued", "Issued", "qty", 10, False),
                 Col("installed", "Installed", "qty", 10, False), Col("remaining", "Remaining", "qty", 10, False),
                 Col("installed_pct", "Installed %", "pct", 9), Col("contract_amount", "Contract amount", "money", 14),
                 Col("installed_value", "Installed value", "money", 14)])
def boq_vs_installed(db: Session, p: Principal, f: Filters) -> dict:
    L = ProjectBoqLine
    stmt = (select(L.project_id, Project.project_number, L.line_no, L.section, L.description, L.unit, L.approved_qty,
                   L.procured_qty, L.issued_qty, L.installed_qty, L.contract_amount, L.rate)
            .join(Project, Project.id == L.project_id))
    stmt = _scoped(stmt, p, "project.read")
    if f.status == "open":
        stmt = stmt.where(Project.status.not_in(CLOSED))
    elif f.status:
        stmt = stmt.where(Project.status == f.status)
    stmt = eq(stmt, ((L.project_id, f.project_id), (Project.customer_id, f.customer_id)))
    rows = []
    for pid, pn, ln, sec, desc, unit, ap, pr, iss, ins, amt, rate in db.execute(
            stmt.order_by(Project.project_number.desc(), L.line_no)):
        rows.append({"project_number": pn, "line_no": ln, "section": sec, "description": desc, "unit": unit,
                     "approved": ap, "procured": pr, "issued": iss, "installed": ins, "remaining": ap - ins,
                     "installed_pct": pct(ins, ap), "contract_amount": amt, "installed_value": ins * rate,
                     "_link": f"/projects/view?id={pid}&tab=boq"})
    return {"rows": rows}

