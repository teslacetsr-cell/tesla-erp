"""Sales & CRM reports: leads, conversion, enquiries, site visits, follow-ups, quotations, sales orders and sales."""
from decimal import Decimal

from sqlalchemy import and_, func, literal, or_, select
from sqlalchemy.orm import Session, aliased

from app.auth.deps import Principal
from app.crm import service as crm
from app.crm.models import ENQUIRY_STATUSES, LEAD_SOURCES, LEAD_STATUSES, VISIT_STATUSES, CrmActivity, Enquiry, Lead, SiteVisit
from app.customers.models import Customer
from app.finance.models import CreditNote, Invoice
from app.quotations import service as quotes
from app.quotations.models import QUOTATION_STATUSES, Quotation, QuotationRevision
from app.reports.registry import Col, D, Filters, between, eq, ist_date, pct, report
from app.sales.models import SO_STATUSES, SalesOrder
from app.users.models import User

Z = Decimal("0")
BILLED_STATUSES = ("issued", "cancelled")   # a cancelled invoice is offset by its full-value credit note


def _scoped(stmt, clause):
    return stmt.where(clause) if clause is not None else stmt


def _party(lead_customer, lead_company, lead_contact):
    return func.coalesce(lead_customer, lead_company, lead_contact)


# ------------------------------------------------------------------ leads
@report("lead_register", "Lead register", "Sales & CRM",
        "Every lead with its stage, source, salesperson, value, probability and expected closing date.",
        perm="lead.read",
        filters=["period", ("status", {"options": LEAD_STATUSES}), ("source", {"options": LEAD_SOURCES}),
                 ("user_id", {"label": "Salesperson"}), "customer_id", "division_id"],
        columns=[Col("lead_number", "Lead no.", width=14), Col("lead_date", "Date", "date", 11),
                 Col("title", "Title", width=30), Col("party", "Customer / prospect", width=26),
                 Col("city", "City", width=12), Col("source", "Source", width=12),
                 Col("salesperson", "Salesperson", width=16), Col("status", "Status", width=11),
                 Col("value", "Est. value", "money", 14), Col("probability", "Prob. %", "int", 8),
                 Col("weighted", "Weighted value", "money", 14), Col("expected_close", "Expected close", "date", 12),
                 Col("lost_reason", "Lost reason", width=22)])
def lead_register(db: Session, p: Principal, f: Filters) -> dict:
    sp = aliased(User)
    d = ist_date(Lead.created_at)
    stmt = (select(Lead.id, Lead.lead_number, d.label("d"), Lead.title,
                   _party(Customer.customer_name, Lead.company_name, Lead.contact_name), Lead.city, Lead.source,
                   sp.full_name, Lead.status, Lead.estimated_value, Lead.probability, Lead.expected_closing_date,
                   Lead.lost_reason)
            .outerjoin(Customer, Customer.id == Lead.customer_id).outerjoin(sp, sp.id == Lead.sales_person_id))
    stmt = _scoped(stmt, crm.scope_clause(p, "lead", "read"))
    stmt = between(stmt, d, f)
    stmt = eq(stmt, ((Lead.status, f.status), (Lead.source, f.source), (Lead.sales_person_id, f.user_id),
                     (Lead.customer_id, f.customer_id), (Lead.division_id, f.division_id)))
    rows = []
    for i, num, dt, title, party, city, src, spn, st, val, prob, close, lost in db.execute(
            stmt.order_by(d.desc(), Lead.lead_number.desc())):
        rows.append({"lead_number": num, "lead_date": dt, "title": title, "party": party, "city": city,
                     "source": src.replace("_", " "), "salesperson": spn, "status": st, "value": val,
                     "probability": prob, "weighted": (val * prob / 100) if val is not None and prob is not None else None,
                     "expected_close": close, "lost_reason": lost, "_link": f"/crm/leads/view?id={i}"})
    return {"rows": rows}


def _conversion_cols(f: Filters) -> list[Col]:
    head = "Source" if f.group_by == "source" else "Salesperson"
    return [Col("group", head, width=22), Col("leads", "Leads", "int", 8, True), Col("open", "Open", "int", 8, True),
            Col("won", "Won", "int", 8, True), Col("lost", "Lost", "int", 8, True), Col("win_pct", "Win %", "pct", 8),
            Col("pipeline", "Open pipeline", "money", 14), Col("value_won", "Value won", "money", 14),
            Col("value_lost", "Value lost", "money", 14), Col("lost_reasons", "Lost reasons", width=34)]


@report("lead_conversion", "Lead conversion (win / loss)", "Sales & CRM",
        "Leads won and lost by salesperson or by source: counts, win rate, value won and lost, and why leads were lost.",
        perm="lead.read",
        filters=["period", ("group_by", {"options": [("salesperson", "Salesperson"), ("source", "Source")],
                                         "default": "salesperson"}), "division_id"],
        columns=_conversion_cols)
def lead_conversion(db: Session, p: Principal, f: Filters) -> dict:
    sp = aliased(User)
    grp = Lead.source if f.group_by == "source" else func.coalesce(sp.full_name, "(unassigned)")
    val = func.coalesce(Lead.estimated_value, 0)
    won, lost = Lead.status == "won", Lead.status == "lost"
    stmt = (select(grp.label("g"), func.count(),
                   func.count().filter(Lead.status.not_in(("won", "lost"))), func.count().filter(won),
                   func.count().filter(lost), func.coalesce(func.sum(val).filter(Lead.status.not_in(("won", "lost"))), 0),
                   func.coalesce(func.sum(val).filter(won), 0), func.coalesce(func.sum(val).filter(lost), 0),
                   func.string_agg(func.distinct(Lead.lost_reason), "; ").filter(lost))
            .outerjoin(sp, sp.id == Lead.sales_person_id).group_by(grp))
    stmt = _scoped(stmt, crm.scope_clause(p, "lead", "read"))
    stmt = between(stmt, ist_date(Lead.created_at), f)
    stmt = eq(stmt, ((Lead.division_id, f.division_id),))
    rows = []
    for g, n, op, w, lo, pipe, vw, vl, reasons in db.execute(stmt.order_by(func.count().desc(), grp)):
        rows.append({"group": g.replace("_", " ") if f.group_by == "source" else g, "leads": n, "open": op,
                     "won": w, "lost": lo, "win_pct": pct(w, w + lo), "pipeline": pipe, "value_won": vw,
                     "value_lost": vl, "lost_reasons": reasons})
    tw, tl = sum(r["won"] for r in rows), sum(r["lost"] for r in rows)
    return {"rows": rows, "totals": {"win_pct": pct(tw, tw + tl)}}


# ------------------------------------------------------------------ enquiries & visits
@report("enquiry_register", "Enquiry register", "Sales & CRM",
        "Enquiries with customer, subject, priority, estimated value, salesperson and status.",
        perm="enquiry.read",
        filters=["period", ("status", {"options": ENQUIRY_STATUSES}), "customer_id",
                 ("user_id", {"label": "Salesperson"}), "division_id"],
        columns=[Col("enquiry_number", "Enquiry no.", width=14), Col("enquiry_date", "Date", "date", 11),
                 Col("customer", "Customer", width=26), Col("subject", "Subject", width=30),
                 Col("source", "Source", width=11), Col("priority", "Priority", width=9),
                 Col("value", "Est. value", "money", 14), Col("salesperson", "Salesperson", width=16),
                 Col("required_by", "Required by", "date", 11), Col("status", "Status", width=11),
                 Col("lead_number", "Lead", width=13), Col("lost_reason", "Lost reason", width=22)])
def enquiry_register(db: Session, p: Principal, f: Filters) -> dict:
    sp = aliased(User)
    stmt = (select(Enquiry.id, Enquiry.enquiry_number, Enquiry.enquiry_date, Customer.customer_name, Enquiry.subject,
                   Enquiry.source, Enquiry.priority, Enquiry.estimated_value, sp.full_name, Enquiry.required_by,
                   Enquiry.status, Lead.lead_number, Enquiry.lost_reason)
            .join(Customer, Customer.id == Enquiry.customer_id).outerjoin(sp, sp.id == Enquiry.sales_person_id)
            .outerjoin(Lead, Lead.id == Enquiry.lead_id))
    stmt = _scoped(stmt, crm.scope_clause(p, "enquiry", "read"))
    stmt = between(stmt, Enquiry.enquiry_date, f)
    stmt = eq(stmt, ((Enquiry.status, f.status), (Enquiry.customer_id, f.customer_id),
                     (Enquiry.sales_person_id, f.user_id), (Enquiry.division_id, f.division_id)))
    keys = ("enquiry_number", "enquiry_date", "customer", "subject", "source", "priority", "value", "salesperson",
            "required_by", "status", "lead_number", "lost_reason")
    rows = []
    for i, *vals in db.execute(stmt.order_by(Enquiry.enquiry_date.desc(), Enquiry.enquiry_number.desc())):
        r = dict(zip(keys, vals, strict=True))
        r["source"] = (r["source"] or "").replace("_", " ") or None
        rows.append(r | {"_link": f"/crm/enquiries/view?id={i}"})
    return {"rows": rows}


@report("site_visit_register", "Site visit register", "Sales & CRM",
        "Site visits by date with customer, location, engineer, purpose, status and follow-up date.",
        perm="site_visit.read",
        filters=["period", ("status", {"options": VISIT_STATUSES}), "customer_id", ("user_id", {"label": "Engineer"})],
        period="month",
        columns=[Col("visit_number", "Visit no.", width=14), Col("visit_date", "Date", "date", 11),
                 Col("customer", "Customer", width=26), Col("location", "Location", width=24),
                 Col("engineer", "Engineer", width=16), Col("purpose", "Purpose", width=26),
                 Col("status", "Status", width=11), Col("enquiry_number", "Enquiry", width=13),
                 Col("follow_up_date", "Follow-up", "date", 11)])
def site_visit_register(db: Session, p: Principal, f: Filters) -> dict:
    eng = aliased(User)
    stmt = (select(SiteVisit.id, SiteVisit.visit_number, SiteVisit.visit_date, Customer.customer_name,
                   SiteVisit.site_location, eng.full_name, SiteVisit.purpose, SiteVisit.status, Enquiry.enquiry_number,
                   SiteVisit.follow_up_date)
            .join(Customer, Customer.id == SiteVisit.customer_id).outerjoin(eng, eng.id == SiteVisit.engineer_id)
            .outerjoin(Enquiry, Enquiry.id == SiteVisit.enquiry_id))
    stmt = _scoped(stmt, crm.scope_clause(p, "site_visit", "read"))
    stmt = between(stmt, SiteVisit.visit_date, f)
    stmt = eq(stmt, ((SiteVisit.status, f.status), (SiteVisit.customer_id, f.customer_id),
                     (SiteVisit.engineer_id, f.user_id)))
    keys = ("visit_number", "visit_date", "customer", "location", "engineer", "purpose", "status", "enquiry_number",
            "follow_up_date")
    return {"rows": [dict(zip(keys, vals, strict=True)) | {"_link": f"/crm/site-visits/view?id={i}"}
                     for i, *vals in db.execute(stmt.order_by(SiteVisit.visit_date.desc(), SiteVisit.visit_number.desc()))]}


@report("followup_compliance", "Follow-up compliance", "Sales & CRM",
        "Per person: follow-ups falling due in the period, done on time, done late, still overdue and not yet due.",
        perm=("lead.read", "enquiry.read"), filters=["period", ("user_id", {"label": "Assigned to"})], period="month",
        columns=[Col("user", "Assigned to", width=22), Col("due", "Due", "int", 8, True),
                 Col("on_time", "Done on time", "int", 10, True), Col("late", "Done late", "int", 10, True),
                 Col("overdue", "Overdue (open)", "int", 10, True), Col("upcoming", "Not yet due", "int", 10, True),
                 Col("compliance_pct", "On-time %", "pct", 10)])
def followup_compliance(db: Session, p: Principal, f: Filters) -> dict:
    u = aliased(User)
    now = crm.now()
    due = ist_date(CrmActivity.due_at)
    done_on_time = and_(CrmActivity.done_at.is_not(None), CrmActivity.done_at <= CrmActivity.due_at)
    done_late = and_(CrmActivity.done_at.is_not(None), CrmActivity.done_at > CrmActivity.due_at)
    stmt = (select(func.coalesce(u.full_name, "(unassigned)"), func.count(), func.count().filter(done_on_time),
                   func.count().filter(done_late),
                   func.count().filter(and_(CrmActivity.done_at.is_(None), CrmActivity.due_at < now)),
                   func.count().filter(and_(CrmActivity.done_at.is_(None), CrmActivity.due_at >= now)))
            .outerjoin(u, u.id == CrmActivity.assigned_to_id)
            .where(CrmActivity.kind == "follow_up").group_by(u.full_name))
    # Follow-ups on leads / enquiries the user may see; with 'own' scope only, just their own follow-ups.
    wide = any(p.scope(c) not in (None, "own") for c in ("lead.read", "enquiry.read"))
    if not wide:
        stmt = stmt.where(CrmActivity.assigned_to_id == p.id)
    else:
        parts = []
        if p.scope("lead.read") not in (None, "own"):
            parts.append(CrmActivity.lead_id.is_not(None))
        if p.scope("enquiry.read") not in (None, "own"):
            parts.append(CrmActivity.enquiry_id.is_not(None))
        parts.append(CrmActivity.assigned_to_id == p.id)
        stmt = stmt.where(or_(*parts))
    stmt = between(stmt, due, f)
    stmt = eq(stmt, ((CrmActivity.assigned_to_id, f.user_id),))
    rows = []
    for name, n, ot, late, od, up in db.execute(stmt.order_by(u.full_name)):
        rows.append({"user": name, "due": n, "on_time": ot, "late": late, "overdue": od, "upcoming": up,
                     "compliance_pct": pct(ot, n - up)})
    t = {k: sum(r[k] for r in rows) for k in ("due", "on_time", "upcoming")}
    return {"rows": rows, "totals": {"compliance_pct": pct(t["on_time"], t["due"] - t["upcoming"])}}


# ------------------------------------------------------------------ quotations & orders
@report("quotation_register", "Quotation register", "Sales & CRM",
        "Quotations with their latest revision: date, customer, salesperson, value before and after GST, approval and status.",
        perm="quotation.read",
        filters=["period", ("status", {"options": QUOTATION_STATUSES}), "customer_id",
                 ("user_id", {"label": "Salesperson"}), "division_id"],
        columns=[Col("number", "Quotation no.", width=18), Col("revision", "Rev.", "int", 5),
                 Col("quotation_date", "Date", "date", 11), Col("customer", "Customer", width=26),
                 Col("subject", "Subject", width=30), Col("salesperson", "Salesperson", width=16),
                 Col("taxable", "Value before GST", "money", 15), Col("grand_total", "Total with GST", "money", 15),
                 Col("approved_on", "Approved on", "date", 11), Col("valid_until", "Valid until", "date", 11),
                 Col("status", "Status", width=12)])
def quotation_register(db: Session, p: Principal, f: Filters) -> dict:
    sp = aliased(User)
    rev = QuotationRevision
    stmt = (select(Quotation.id, Quotation.quotation_number, Quotation.current_revision_no, rev.quotation_date,
                   Customer.customer_name, Quotation.subject, sp.full_name, rev.taxable, rev.grand_total,
                   ist_date(rev.approved_at), rev.valid_until, Quotation.status)
            .join(rev, and_(rev.quotation_id == Quotation.id, rev.revision_no == Quotation.current_revision_no))
            .join(Customer, Customer.id == Quotation.customer_id).outerjoin(sp, sp.id == Quotation.sales_person_id))
    stmt = _scoped(stmt, quotes.scope_clause(p, "read"))
    stmt = between(stmt, rev.quotation_date, f)
    stmt = eq(stmt, ((Quotation.status, f.status), (Quotation.customer_id, f.customer_id),
                     (Quotation.sales_person_id, f.user_id), (Quotation.division_id, f.division_id)))
    rows = []
    for i, num, r, d, cust, subj, spn, tx, gt, appr, valid, st in db.execute(
            stmt.order_by(rev.quotation_date.desc(), Quotation.quotation_number.desc().nulls_first())):
        base = num or "DRAFT"
        rows.append({"number": f"{base}-R{r}" if r else base, "revision": r, "quotation_date": d, "customer": cust,
                     "subject": subj, "salesperson": spn, "taxable": tx, "grand_total": gt, "approved_on": appr,
                     "valid_until": valid, "status": st.replace("_", " "), "_link": f"/sales/quotations/view?id={i}"})
    return {"rows": rows}


def billed_by_order(db: Session):
    """Subquery: sales_order_id → billed before GST (issued invoices less credit notes)."""
    inv = (select(Invoice.sales_order_id.label("so_id"), Invoice.taxable.label("amt"))
           .where(Invoice.status.in_(BILLED_STATUSES), Invoice.sales_order_id.is_not(None)))
    cn = (select(Invoice.sales_order_id.label("so_id"), (-CreditNote.taxable).label("amt"))
          .join(Invoice, Invoice.id == CreditNote.invoice_id).where(Invoice.sales_order_id.is_not(None)))
    u = inv.union_all(cn).subquery()
    return select(u.c.so_id, func.sum(u.c.amt).label("billed")).group_by(u.c.so_id).subquery()


@report("sales_order_register", "Sales order register", "Sales & CRM",
        "Sales orders with value before GST, amount billed so far (net of credit notes) and the balance to bill.",
        perm="sales_order.read",
        filters=["period", ("status", {"options": SO_STATUSES}), "customer_id", ("user_id", {"label": "Salesperson"}),
                 "division_id"],
        columns=[Col("so_number", "SO no.", width=16), Col("so_date", "Date", "date", 11),
                 Col("customer", "Customer", width=26), Col("subject", "Subject", width=28),
                 Col("salesperson", "Salesperson", width=16), Col("quotation_number", "Quotation", width=16),
                 Col("customer_po", "Customer PO", width=14), Col("value", "Value before GST", "money", 15),
                 Col("grand_total", "Total with GST", "money", 15), Col("billed", "Billed", "money", 14),
                 Col("balance", "Balance to bill", "money", 14), Col("status", "Status", width=11)])
def sales_order_register(db: Session, p: Principal, f: Filters) -> dict:
    sp = aliased(User)
    b = billed_by_order(db)
    stmt = (select(SalesOrder.id, SalesOrder.so_number, SalesOrder.so_date, Customer.customer_name, SalesOrder.subject,
                   sp.full_name, SalesOrder.quotation_number, SalesOrder.customer_po_number, SalesOrder.taxable,
                   SalesOrder.grand_total, func.coalesce(b.c.billed, 0), SalesOrder.status)
            .join(Customer, Customer.id == SalesOrder.customer_id).outerjoin(sp, sp.id == SalesOrder.sales_person_id)
            .outerjoin(b, b.c.so_id == SalesOrder.id))
    if p.scope("sales_order.read") == "own":
        stmt = stmt.where(or_(SalesOrder.sales_person_id == p.id, SalesOrder.created_by == p.id))
    stmt = between(stmt, SalesOrder.so_date, f)
    stmt = eq(stmt, ((SalesOrder.status, f.status), (SalesOrder.customer_id, f.customer_id),
                     (SalesOrder.sales_person_id, f.user_id), (SalesOrder.division_id, f.division_id)))
    rows = []
    for i, num, d, cust, subj, spn, qn, po, val, gt, billed, st in db.execute(
            stmt.order_by(SalesOrder.so_date.desc(), SalesOrder.so_number.desc())):
        bal = Z if st == "cancelled" else val - D(billed)
        rows.append({"so_number": num, "so_date": d, "customer": cust, "subject": subj, "salesperson": spn,
                     "quotation_number": qn, "customer_po": po, "value": val, "grand_total": gt, "billed": billed,
                     "balance": bal, "status": st.replace("_", " "), "_link": f"/sales/orders/view?id={i}"})
    return {"rows": rows}


# ------------------------------------------------------------------ sales (from invoices)
def _sales_union(f: Filters):
    """Issued invoices (by invoice date) and credit notes (by credit-note date, negative) in the period."""
    inv = select(Invoice.customer_id.label("customer_id"), Invoice.invoice_date.label("d"),
                 Invoice.taxable.label("taxable"), (Invoice.cgst + Invoice.sgst + Invoice.igst).label("gst"),
                 Invoice.grand_total.label("total"), literal(1).label("inv"), literal(0).label("cn"),
                 Invoice.taxable.label("inv_taxable"), literal(0).label("cn_taxable")
                 ).where(Invoice.status.in_(BILLED_STATUSES))
    inv = between(inv, Invoice.invoice_date, f)
    cn = select(CreditNote.customer_id, CreditNote.cn_date, -CreditNote.taxable,
                -(CreditNote.cgst + CreditNote.sgst + CreditNote.igst), -CreditNote.total, literal(0), literal(1),
                literal(0), CreditNote.taxable)
    cn = between(cn, CreditNote.cn_date, f)
    if f.customer_id:
        inv = inv.where(Invoice.customer_id == f.customer_id)
        cn = cn.where(CreditNote.customer_id == f.customer_id)
    return inv.union_all(cn).subquery()


SALES_COLS = [Col("invoices", "Invoices", "int", 9, True), Col("credit_notes", "Credit notes", "int", 9, True),
              Col("invoiced", "Invoiced (before GST)", "money", 16), Col("credited", "Credit notes (before GST)", "money", 16),
              Col("net_taxable", "Net sales before GST", "money", 16), Col("gst", "GST", "money", 14),
              Col("total", "Net sales with GST", "money", 16)]


def _sales_aggs(u):
    return (func.sum(u.c.inv), func.sum(u.c.cn), func.sum(u.c.inv_taxable), func.sum(u.c.cn_taxable),
            func.sum(u.c.taxable), func.sum(u.c.gst), func.sum(u.c.total))


def _sales_row(vals) -> dict:
    return dict(zip(("invoices", "credit_notes", "invoiced", "credited", "net_taxable", "gst", "total"), vals, strict=True))


@report("sales_by_customer", "Sales by customer", "Sales & CRM",
        "Issued invoices less credit notes per customer in the period, before GST and with GST.",
        perm="invoice.read", filters=["period", "customer_id"],
        columns=[Col("customer", "Customer", width=28), Col("gstin", "GSTIN", width=16)] + SALES_COLS)
def sales_by_customer(db: Session, p: Principal, f: Filters) -> dict:
    u = _sales_union(f)
    stmt = (select(Customer.id, Customer.customer_name, Customer.gstin, *_sales_aggs(u))
            .join(Customer, Customer.id == u.c.customer_id).group_by(Customer.id)
            .order_by(func.sum(u.c.taxable).desc()))
    return {"rows": [{"customer": n, "gstin": g, **_sales_row(v)} for _, n, g, *v in db.execute(stmt)]}


@report("sales_by_month", "Sales by month", "Sales & CRM",
        "Issued invoices less credit notes month by month, before GST and with GST.",
        perm="invoice.read", filters=["period", "customer_id"],
        columns=[Col("month", "Month", width=12)] + SALES_COLS)
def sales_by_month(db: Session, p: Principal, f: Filters) -> dict:
    u = _sales_union(f)
    m = func.date_trunc("month", u.c.d)
    stmt = select(m, *_sales_aggs(u)).group_by(m).order_by(m)
    return {"rows": [{"month": mm.strftime("%b %Y"), **_sales_row(v)} for mm, *v in db.execute(stmt)]}

