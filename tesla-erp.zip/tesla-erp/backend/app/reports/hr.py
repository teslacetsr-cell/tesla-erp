"""HR reports: leave register, monthly attendance summary, headcount."""
import uuid
from decimal import Decimal

from sqlalchemy import String, and_, cast, func, or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.company.models import BusinessDivision
from app.hr import attendance as att
from app.hr.models import LEAVE_STATUSES, Department, Designation, Employee, LeaveRequest, LeaveType
from app.reports.registry import Col, Filters, eq, ist_date, report

Z = Decimal("0")


@report("leave_register", "Leave register", "HR",
        "Leave applications overlapping the period: employee, department, leave type, dates, days and status.",
        perm="leave_request.read", need_all=True,
        filters=["period", "employee_id", ("status", {"options": LEAVE_STATUSES}), "division_id"], period="month",
        columns=[Col("employee_code", "Code", width=9), Col("employee", "Employee", width=22),
                 Col("department", "Department", width=16), Col("leave_type", "Leave type", width=16),
                 Col("from_date", "From", "date", 11), Col("to_date", "To", "date", 11),
                 Col("half_day", "Half day", width=8), Col("days", "Days", "qty", 7),
                 Col("status", "Status", width=10), Col("reason", "Reason", width=28),
                 Col("decided_on", "Decided on", "date", 11)])
def leave_register(db: Session, p: Principal, f: Filters) -> dict:
    L = LeaveRequest
    stmt = (select(Employee.employee_code, Employee.full_name, Department.name, LeaveType.name, L.from_date, L.to_date,
                   L.half_day, L.days, L.status, L.reason, ist_date(L.decided_at), L.id)
            .join(Employee, Employee.id == L.employee_id).join(LeaveType, LeaveType.id == L.leave_type_id)
            .outerjoin(Department, Department.id == Employee.department_id))
    if f.date_from:
        stmt = stmt.where(L.to_date >= f.date_from)
    if f.date_to:
        stmt = stmt.where(L.from_date <= f.date_to)
    stmt = eq(stmt, ((L.employee_id, f.employee_id), (L.status, f.status), (Employee.division_id, f.division_id)))
    keys = ("employee_code", "employee", "department", "leave_type", "from_date", "to_date", "half_day", "days",
            "status", "reason", "decided_on")
    rows = []
    for *v, lid in db.execute(stmt.order_by(L.from_date, Employee.full_name)):
        r = dict(zip(keys, v, strict=True))
        r["half_day"] = None if r["half_day"] == "none" else r["half_day"]
        rows.append(r | {"_link": f"/hr/leave/view?id={lid}"})
    return {"rows": rows}


@report("attendance_summary", "Attendance summary", "HR",
        "Per employee for a month: days present, on leave, absent, holidays, weekly offs and days not marked "
        "(the totals of the attendance register).",
        perm="attendance.read", need_all=True, filters=["month", "employee_id", "division_id"], period=None,
        columns=[Col("employee_code", "Code", width=9), Col("employee", "Employee", width=24),
                 Col("department", "Department", width=16), Col("present", "Present", "qty", 9),
                 Col("leave", "Leave", "qty", 8), Col("absent", "Absent", "qty", 8),
                 Col("holiday", "Holidays", "int", 8, True), Col("weekly_off", "Weekly offs", "int", 8, True),
                 Col("unmarked", "Not marked", "int", 8, True)])
def attendance_summary(db: Session, p: Principal, f: Filters) -> dict:
    d1, d2 = f.month_bounds()
    month = d1.strftime("%Y-%m")
    emp = (select(Employee.id, Employee.employee_code, Department.name)
           .outerjoin(Department, Department.id == Employee.department_id)
           .where(or_(Employee.is_active.is_(True), and_(Employee.exit_date.is_not(None), Employee.exit_date >= d1)),
                  or_(Employee.date_of_joining.is_(None), Employee.date_of_joining <= d2)))
    emp = eq(emp, ((Employee.id, f.employee_id), (Employee.division_id, f.division_id)))
    emps = {e: dept for e, _, dept in db.execute(emp)}
    reg = att.register(db, month, list(emps)) if emps else {"rows": []}
    rows = []
    for r in sorted(reg["rows"], key=lambda x: x["name"]):
        t = r["totals"]
        rows.append({"employee_code": r["employee_code"], "employee": r["name"],
                     "department": emps.get(uuid.UUID(r["employee_id"])),
                     "present": Decimal(t["present"]), "leave": Decimal(t["leave"]), "absent": Decimal(t["absent"]),
                     "holiday": t["holiday"], "weekly_off": t["weekly_off"], "unmarked": t["unmarked"]})
    return {"rows": rows}


def _headcount_cols(f: Filters) -> list[Col]:
    head = {"designation": "Designation", "division": "Division"}.get(f.group_by or "", "Department")
    return [Col("group", head, width=24), Col("headcount", "Active employees", "int", 10, True),
            Col("permanent", "Permanent", "int", 9, True), Col("probation", "Probation", "int", 9, True),
            Col("contract", "Contract / other", "int", 10, True), Col("joined", "Joined in period", "int", 10, True),
            Col("exited", "Left in period", "int", 10, True)]


@report("headcount", "Headcount", "HR",
        "Active employees by department, designation or division, by employment type, with joiners and leavers in the "
        "period.",
        perm="employee.read",
        filters=["period", ("group_by", {"options": [("department", "Department"), ("designation", "Designation"),
                                                     ("division", "Division")], "default": "department"})],
        columns=_headcount_cols)
def headcount(db: Session, p: Principal, f: Filters) -> dict:
    if f.group_by == "designation":
        grp, join = Designation.name, (Designation, Designation.id == Employee.designation_id)
    elif f.group_by == "division":
        grp, join = BusinessDivision.name, (BusinessDivision, BusinessDivision.id == Employee.division_id)
    else:
        grp, join = Department.name, (Department, Department.id == Employee.department_id)
    g = func.coalesce(cast(grp, String), "(not set)")
    active = Employee.is_active.is_(True)
    joined = [Employee.date_of_joining.is_not(None)]
    exited = [Employee.exit_date.is_not(None)]
    if f.date_from:
        joined.append(Employee.date_of_joining >= f.date_from)
        exited.append(Employee.exit_date >= f.date_from)
    if f.date_to:
        joined.append(Employee.date_of_joining <= f.date_to)
        exited.append(Employee.exit_date <= f.date_to)
    stmt = (select(g, func.count().filter(active),
                   func.count().filter(and_(active, Employee.employment_type == "permanent")),
                   func.count().filter(and_(active, Employee.employment_type == "probation")),
                   func.count().filter(and_(active, Employee.employment_type.not_in(("permanent", "probation")))),
                   func.count().filter(and_(*joined)), func.count().filter(and_(*exited)))
            .select_from(Employee).outerjoin(*join).group_by(g).order_by(g))
    keys = ("group", "headcount", "permanent", "probation", "contract", "joined", "exited")
    return {"rows": [dict(zip(keys, v, strict=True)) for v in db.execute(stmt) if any(v[1:])]}
