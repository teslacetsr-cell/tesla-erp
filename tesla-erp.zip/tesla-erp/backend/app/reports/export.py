"""Excel and PDF output of a report result (see registry.execute for the result's shape)."""
import io
import re
from datetime import date, datetime
from decimal import Decimal
from html import escape

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from sqlalchemy.orm import Session

from app.core import excel
from app.core.money import format_inr
from app.platform import pdfkit as K

PAGE = landscape(A4)
MARGIN = 10 * mm
NUMERIC = ("money", "qty", "int", "pct")
_FMT = {"money": "#,##0.00", "qty": "#,##0.###", "int": "0", "pct": "0.00"}


def _num(v):
    return float(Decimal(v)) if v not in (None, "") else None


def _date(v):
    return date.fromisoformat(v[:10]) if v else None


def display(t: str, v) -> str:
    """A value as printed on paper."""
    if v in (None, ""):
        return ""
    if t == "money":
        return format_inr(v)
    if t == "qty":
        d = Decimal(v).normalize()
        return f"{d:,f}" if d != d.to_integral_value() else f"{int(d):,}"
    if t == "pct":
        return f"{Decimal(v):.2f}%"
    if t == "date":
        return _date(v).strftime("%d %b %Y")
    return str(v)


# ------------------------------------------------------------------ Excel
def xlsx(res: dict, filters_label: str, generated_by: str) -> bytes:
    cols = [excel.Column(c["key"], c["label"], max(c["width"], 6)) for c in res["columns"]]
    types = [c["type"] for c in res["columns"]]
    wb = Workbook()
    ws = wb.active
    ws.title = re.sub(r"[\\/*?:\[\]]", "-", res["title"])[:31]
    ws.cell(row=1, column=1, value=res["title"]).font = Font(bold=True, size=14)
    ws.cell(row=2, column=1, value=filters_label or "No filters").font = Font(italic=True, color="555555")
    stamp = datetime.now(K.IST).strftime("%d %b %Y %I:%M %p IST")
    ws.cell(row=3, column=1, value=f"Generated {stamp} by {generated_by} · {res['row_count']} rows"
            + (" (first 5000 shown)" if res.get("truncated") else "")).font = Font(color="777777", size=9)
    head = 4
    for i, col in enumerate(cols, start=1):
        c = ws.cell(row=head, column=i, value=col.header)
        c.fill = PatternFill("solid", fgColor="D90000")
        c.font = Font(bold=True, color="FFFFFF")
        c.alignment = Alignment(vertical="center", wrap_text=True, horizontal="right" if types[i - 1] in NUMERIC else "left")
        ws.column_dimensions[get_column_letter(i)].width = col.width
    ws.row_dimensions[head].height = 30

    def put(row_no: int, values: dict, bold: bool = False):
        for i, (col, t) in enumerate(zip(cols, types, strict=True), start=1):
            v = values.get(col.key)
            if t in NUMERIC:
                v = _num(v)
            elif t == "date":
                v = _date(v)
            cell = ws.cell(row=row_no, column=i, value=v)
            if t in _FMT:
                cell.number_format = _FMT[t]
            elif t == "date":
                cell.number_format = "dd-mmm-yyyy"
            if bold:
                cell.font = Font(bold=True)

    r = head
    for row in res["rows"]:
        r += 1
        put(r, row)
    last_data = r
    if res["totals"] and any(v not in (None, "") for v in res["totals"].values()):
        r += 1
        put(r, res["totals"], bold=True)
        if res["totals"].get(cols[0].key) in (None, ""):
            c = ws.cell(row=r, column=1, value="Total")
            c.font, c.number_format = Font(bold=True), "General"
    ws.freeze_panes = ws.cell(row=head + 1, column=1)
    if last_data > head:
        ws.auto_filter.ref = f"A{head}:{get_column_letter(len(cols))}{last_data}"
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ------------------------------------------------------------------ PDF
def _canvas(footer_left: str):
    generated = datetime.now(K.IST).strftime("%d %b %Y, %I:%M %p IST")

    class NumberedCanvas(rl_canvas.Canvas):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._pages = []

        def showPage(self):  # noqa: N802 - ReportLab API
            self._pages.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            total = len(self._pages)
            for state in self._pages:
                self.__dict__.update(state)
                w = PAGE[0]
                self.saveState()
                self.setFont("DejaVu", 6.8)
                self.setFillColor(K.MUTED)
                self.drawString(MARGIN, 6 * mm, f"{footer_left} · generated {generated}")
                self.drawRightString(w - MARGIN, 6 * mm, f"Page {self._pageNumber} of {total}")
                self.restoreState()
                super().showPage()
            super().save()

    return NumberedCanvas


def pdf(db: Session, res: dict, filters_label: str, generated_by: str) -> bytes:
    K.fonts()
    st = K.styles()
    cols = res["columns"]
    n = len(cols)
    size = 7.2 if n <= 10 else 6.4 if n <= 14 else 5.8
    cell = st["cell"].clone("rc", fontSize=size, leading=size + 2)
    head_l = st["cellb"].clone("rh", fontSize=size, leading=size + 2)
    head_r = head_l.clone("rhr", alignment=2)
    avail = PAGE[0] - 2 * MARGIN
    weights = [max(c["width"], 5) for c in cols]
    widths = [avail * w / sum(weights) for w in weights]
    # characters that fit in a column on one line; longer text wraps (as a Paragraph), shorter stays a plain string
    fits = [max(int(w / (size * 0.55)), 3) for w in widths]

    def row_cells(values: dict, bold: bool = False, label: str | None = None) -> list:
        out = []
        for i, (c, fit) in enumerate(zip(cols, fits, strict=True)):
            s = label if (i == 0 and label) else display(c["type"], values.get(c["key"]))
            if c["type"] == "text" and len(s) > fit:
                out.append(Paragraph(f"<b>{escape(s)}</b>" if bold else escape(s), cell))
            else:
                out.append(s)
        return out

    data = [[Paragraph(escape(c["label"]), head_r if c["type"] in NUMERIC else head_l) for c in cols]]
    data += [row_cells(r) for r in res["rows"]]
    has_totals = bool(res["totals"]) and any(v not in (None, "") for v in res["totals"].values())
    if has_totals:
        tot = res["totals"]
        data.append(row_cells(tot, bold=True, label="Total" if tot.get(cols[0]["key"]) in (None, "") else None))
    if len(data) == 1:
        data.append([Paragraph("No records for these filters.", cell)] + [""] * (n - 1))
    t = Table(data, colWidths=widths, repeatRows=1)
    style = [("FONT", (0, 1), (-1, -1), "DejaVu", size), ("LEADING", (0, 1), (-1, -1), size + 2),
             ("BACKGROUND", (0, 0), (-1, 0), K.TINT), ("LINEBELOW", (0, 0), (-1, -1), 0.25, K.LINE),
             ("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 1.6),
             ("BOTTOMPADDING", (0, 0), (-1, -1), 1.6), ("LEFTPADDING", (0, 0), (-1, -1), 3.5),
             ("RIGHTPADDING", (0, 0), (-1, -1), 3.5)]
    for i, c in enumerate(cols):
        if c["type"] in NUMERIC:
            style.append(("ALIGN", (i, 1), (i, -1), "RIGHT"))
    if has_totals:
        style += [("FONT", (0, -1), (-1, -1), "DejaVu-Bold", size), ("BACKGROUND", (0, -1), (-1, -1), K.TINT),
                  ("LINEABOVE", (0, -1), (-1, -1), 0.6, colors.HexColor("#9ca3af"))]
    t.setStyle(TableStyle(style))
    count = f"{res['row_count']} record{'s' if res['row_count'] != 1 else ''}" + \
        (" (first 5000 shown — narrow the filters)" if res.get("truncated") else "")
    story = K.letterhead(db, st) + [
        Paragraph(escape(res["title"]), st["title"]), Spacer(1, 1.5 * mm),
        Paragraph(escape(filters_label or "No filters"), st["base"]),
        Paragraph(escape(f"{count} · prepared by {generated_by}"), st["small"]), Spacer(1, 3 * mm), t]
    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=PAGE, leftMargin=MARGIN, rightMargin=MARGIN, topMargin=9 * mm,
                      bottomMargin=12 * mm, title=res["title"]).build(story, canvasmaker=_canvas(res["title"]))
    return buf.getvalue()
