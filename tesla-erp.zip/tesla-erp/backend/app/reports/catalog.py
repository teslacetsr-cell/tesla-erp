"""Loads every report module (each registers its reports on import), and serves the option lists and the readable
filter line shared by the API and the exports."""
import uuid

from sqlalchemy import select
from sqlalchemy.orm import Session

import app.reports.projects  # noqa: F401 - registers the project reports
from app.auth.deps import Principal
from app.company.models import BusinessDivision
from app.customers.models import Customer
from app.hr.models import Employee
from app.products.models import Item, Warehouse
from app.projects import service as projects
from app.projects.models import Project
from app.reports import finance, hr, inventory, purchase, sales  # noqa: F401
from app.reports.registry import FILTER_DEFS, GROUPS, REPORTS, Filters, Report
from app.suppliers.models import Supplier
from app.users.models import User

OPTION_LIMIT = 5000


def visible(p: Principal) -> list[Report]:
    return [r for r in REPORTS.values() if r.allowed(p)]


def catalog(p: Principal) -> list[dict]:
    mine = visible(p)
    return [{"group": g, "reports": [r.catalog_entry() for r in mine if r.group == g]}
            for g in GROUPS if any(r.group == g for r in mine)]


def source_allowed(p: Principal, source: str) -> bool:
    return any(FILTER_DEFS[name].get("source") == source for r in visible(p) for name in r.filter_keys())


def option_list(db: Session, p: Principal, source: str) -> list[dict]:
    if source == "customers":
        q = select(Customer.id, Customer.customer_name, Customer.customer_code).order_by(Customer.customer_name)
    elif source == "suppliers":
        q = select(Supplier.id, Supplier.supplier_name, Supplier.supplier_code).order_by(Supplier.supplier_name)
    elif source == "projects":
        q = select(Project.id, Project.project_number + " " + Project.name, Project.status) \
            .order_by(Project.project_number.desc())
        if p.can("project.read") and (clause := projects.scope_clause(p, "project.read")) is not None:
            q = q.where(clause)
    elif source == "employees":
        q = select(Employee.id, Employee.full_name, Employee.employee_code).order_by(Employee.full_name)
    elif source == "users":
        q = select(User.id, User.full_name, User.username).where(User.is_active.is_(True)).order_by(User.full_name)
    elif source == "divisions":
        q = select(BusinessDivision.id, BusinessDivision.name, BusinessDivision.code).order_by(BusinessDivision.name)
    elif source == "warehouses":
        q = select(Warehouse.id, Warehouse.name, Warehouse.code).where(Warehouse.is_active.is_(True)) \
            .order_by(Warehouse.name)
    elif source == "items":
        q = select(Item.id, Item.item_name, Item.item_code).where(Item.item_type == "goods").order_by(Item.item_name)
    else:
        return []
    return [{"value": str(i), "label": label, "hint": hint} for i, label, hint in db.execute(q.limit(OPTION_LIMIT))]


_LOOKUP = {"customer_id": (Customer, Customer.customer_name), "supplier_id": (Supplier, Supplier.supplier_name),
           "project_id": (Project, Project.project_number), "employee_id": (Employee, Employee.full_name),
           "user_id": (User, User.full_name), "division_id": (BusinessDivision, BusinessDivision.name),
           "warehouse_id": (Warehouse, Warehouse.name), "item_id": (Item, Item.item_name)}


def describe(db: Session, r: Report, f: Filters) -> str:
    """'Period: 01 Apr 2026 – 31 Mar 2027 · Customer: ABC Hospitals · Status: Issued' for titles and exports."""
    parts = []
    for name, extra in r.filters:
        d = {**FILTER_DEFS[name], **extra}
        label = d["label"]
        if name == "period":
            if f.date_from or f.date_to:
                a = f.date_from.strftime("%d %b %Y") if f.date_from else "start"
                b = f.date_to.strftime("%d %b %Y") if f.date_to else "today"
                parts.append(f"{label}: {a} – {b}")
            continue
        if name == "as_of":
            if f.as_of:
                parts.append(f"{label} {f.as_of:%d %b %Y}")
            continue
        if name == "month":
            if f.month:
                parts.append(f"{label}: {f.month_bounds()[0]:%B %Y}")
            continue
        v = getattr(f, name, None)
        if v is None:
            continue
        if name in _LOOKUP:
            model, col = _LOOKUP[name]
            text = db.scalar(select(col).where(model.id == v)) if isinstance(v, uuid.UUID) else None
            parts.append(f"{label}: {text or v}")
        else:
            opts = {o[0]: o[1] for o in d.get("options", []) if isinstance(o, tuple)}
            parts.append(f"{label}: {opts.get(v, str(v).replace('_', ' ').capitalize())}")
    return " · ".join(parts)
