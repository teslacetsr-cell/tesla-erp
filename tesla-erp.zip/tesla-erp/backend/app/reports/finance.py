"""Finance reports: sales register, credit notes, receipts, ageing, supplier bills and payments, expense claims,
billing vs collections."""
from decimal import Decimal

from sqlalchemy import func, literal, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.customers.models import Customer
from app.finance import reports as fin
from app.finance.models import (
    EXPENSE_STATUSES,
    PAYMENT_MODES,
    SUPPLIER_INVOICE_STATUSES,
    CreditNote,
    ExpenseCategory,
    ExpenseClaim,
    Invoice,
    InvoiceItem,
    Receipt,
    SupplierInvoice,
    SupplierPayment,
)
from app.hr.models import Employee
from app.projects.models import Project
from app.purchase.models import PurchaseOrder
from app.reports.registry import Col, D, Filters, between, eq, report
from app.suppliers.models import Supplier

Z = Decimal("0")
TAX_COLS = [Col("taxable", "Taxable value", "money", 15), Col("cgst", "CGST", "money", 12),
            Col("sgst", "SGST", "money", 12), Col("igst", "IGST", "money", 12)]


@report("sales_register", "Sales register", "Finance",
        "Invoice-wise register of issued sales invoices (GSTR-1 style): GSTIN, place of supply, taxable value, "
        "CGST / SGST / IGST and invoice total. A cancelled invoice stays listed (status cancelled); the credit note that "
        "cancels it is in the credit note register — exactly as the GST summary counts them.",
        perm="finance_report.read",
        filters=["period", "customer_id", ("status", {"options": [("issued", "Issued"), ("cancelled", "Cancelled")]})],
        period="month",
        columns=[Col("invoice_date", "Date", "date", 11), Col("invoice_number", "Invoice no.", width=16),
                 Col("customer", "Customer", width=26), Col("gstin", "GSTIN", width=16),
                 Col("place_of_supply", "POS", width=5), Col("bill_type", "Type", width=8)] + TAX_COLS +
                [Col("round_off", "Round off", "money", 9), Col("total", "Invoice total", "money", 15),
                 Col("status", "Status", width=9)])
def sales_register(db: Session, p: Principal, f: Filters) -> dict:
    # Tax columns are summed from the invoice lines, as the GST summary does, so the two always reconcile.
    items = (select(InvoiceItem.invoice_id.label("iid"), func.sum(InvoiceItem.taxable).label("taxable"),
                    func.sum(InvoiceItem.cgst).label("cgst"), func.sum(InvoiceItem.sgst).label("sgst"),
                    func.sum(InvoiceItem.igst).label("igst")).group_by(InvoiceItem.invoice_id).subquery())
    gstin = func.coalesce(Invoice.customer_snapshot["gstin"].astext, Customer.gstin)
    stmt = (select(Invoice.id, Invoice.invoice_date, Invoice.invoice_number, Customer.customer_name, gstin,
                   Invoice.place_of_supply, Invoice.bill_type, func.coalesce(items.c.taxable, 0),
                   func.coalesce(items.c.cgst, 0), func.coalesce(items.c.sgst, 0), func.coalesce(items.c.igst, 0),
                   Invoice.round_off, Invoice.grand_total, Invoice.status)
            .join(Customer, Customer.id == Invoice.customer_id).outerjoin(items, items.c.iid == Invoice.id)
            .where(Invoice.status.in_(("issued", "cancelled"))))
    stmt = between(stmt, Invoice.invoice_date, f)
    stmt = eq(stmt, ((Invoice.customer_id, f.customer_id), (Invoice.status, f.status)))
    keys = ("invoice_date", "invoice_number", "customer", "gstin", "place_of_supply", "bill_type", "taxable", "cgst",
            "sgst", "igst", "round_off", "total", "status")
    return {"rows": [dict(zip(keys, v, strict=True)) | {"_link": f"/sales/invoices/view?id={i}"}
                     for i, *v in db.execute(stmt.order_by(Invoice.invoice_date, Invoice.invoice_number))]}


@report("credit_note_register", "Credit note register", "Finance",
        "Credit notes against issued invoices: date, number, invoice, customer, reason and the GST reversed.",
        perm="finance_report.read", filters=["period", "customer_id"], period="month",
        columns=[Col("cn_date", "Date", "date", 11), Col("cn_number", "Credit note no.", width=16),
                 Col("invoice_number", "Against invoice", width=16), Col("customer", "Customer", width=26),
                 Col("gstin", "GSTIN", width=16), Col("reason", "Reason", width=28),
                 Col("cancels", "Cancels invoice", width=9)] + TAX_COLS +
                [Col("total", "Total", "money", 14)])
def credit_note_register(db: Session, p: Principal, f: Filters) -> dict:
    C = CreditNote
    stmt = (select(C.invoice_id, C.cn_date, C.cn_number, Invoice.invoice_number, Customer.customer_name, Customer.gstin,
                   C.reason, C.cancels_invoice, C.taxable, C.cgst, C.sgst, C.igst, C.total)
            .join(Invoice, Invoice.id == C.invoice_id).join(Customer, Customer.id == C.customer_id))
    stmt = between(stmt, C.cn_date, f)
    stmt = eq(stmt, ((C.customer_id, f.customer_id),))
    rows = []
    for iid, d, num, inv, cust, gstin, reason, cancels, *amts in db.execute(stmt.order_by(C.cn_date, C.cn_number)):
        rows.append({"cn_date": d, "cn_number": num, "invoice_number": inv, "customer": cust, "gstin": gstin,
                     "reason": reason, "cancels": "Yes" if cancels else None,
                     **dict(zip(("taxable", "cgst", "sgst", "igst", "total"), amts, strict=True)),
                     "_link": f"/sales/invoices/view?id={iid}"})
    return {"rows": rows}


@report("receipt_register", "Receipt register", "Finance",
        "Money received from customers: date, number, customer, mode and reference, amount, TDS deducted, how much is "
        "allocated to invoices and the advance left.",
        perm="receipt.read",
        filters=["period", "customer_id", "project_id",
                 ("status", {"options": [("posted", "Posted"), ("cancelled", "Cancelled")], "default": "posted"}),
                 ("source", {"label": "Mode", "options": PAYMENT_MODES})],
        period="month",
        columns=[Col("receipt_date", "Date", "date", 11), Col("receipt_number", "Receipt no.", width=18),
                 Col("customer", "Customer", width=26), Col("project", "Project", width=13),
                 Col("mode", "Mode", width=7), Col("reference_no", "Reference", width=16),
                 Col("amount", "Amount received", "money", 14), Col("tds", "TDS", "money", 11),
                 Col("total", "Total credited", "money", 14), Col("allocated", "Allocated", "money", 14),
                 Col("unallocated", "Advance", "money", 13), Col("status", "Status", width=9)])
def receipt_register(db: Session, p: Principal, f: Filters) -> dict:
    R = Receipt
    stmt = (select(R.id, R.receipt_date, R.receipt_number, Customer.customer_name, Project.project_number, R.mode,
                   R.reference_no, R.amount, R.tds_amount, R.amount + R.tds_amount, R.allocated,
                   R.amount + R.tds_amount - R.allocated, R.status)
            .join(Customer, Customer.id == R.customer_id).outerjoin(Project, Project.id == R.project_id))
    stmt = between(stmt, R.receipt_date, f)
    stmt = eq(stmt, ((R.customer_id, f.customer_id), (R.project_id, f.project_id), (R.status, f.status),
                     (R.mode, f.source)))
    keys = ("receipt_date", "receipt_number", "customer", "project", "mode", "reference_no", "amount", "tds", "total",
            "allocated", "unallocated", "status")
    return {"rows": [dict(zip(keys, v, strict=True)) | {"_link": f"/finance/receipts/view?id={i}"}
                     for i, *v in db.execute(stmt.order_by(R.receipt_date, R.receipt_number))]}


AGEING_COLS = [Col("not_due", "Not yet due", "money", 13), Col("d0_30", "1–30 days", "money", 13),
               Col("d31_60", "31–60 days", "money", 13), Col("d61_90", "61–90 days", "money", 13),
               Col("d90", "Over 90 days", "money", 13)]


@report("receivables_ageing", "Receivables ageing", "Finance",
        "Outstanding sales invoices per customer by age (from the due date), retention held back, advances and net "
        "receivable — the same figures as Finance → Receivables.",
        perm="receivable.read", filters=["as_of", "customer_id"], period=None,
        columns=[Col("customer", "Customer", width=28), Col("invoices", "Invoices", "int", 8, True)] + AGEING_COLS +
                [Col("retention", "Retention", "money", 13), Col("outstanding", "Outstanding", "money", 14),
                 Col("advance", "Advance", "money", 13), Col("net", "Net receivable", "money", 14)])
def receivables_ageing(db: Session, p: Principal, f: Filters) -> dict:
    res = fin.receivables(db, f.as_of, f.customer_id)
    rows = [{**r, "_link": f"/finance/statement?type=customer&id={r['customer_id']}"} for r in res["rows"]]
    totals = dict(res["totals"])
    totals["net"] = str(D(totals["outstanding"]) - D(totals["advance"]))
    return {"rows": rows, "totals": totals}


@report("payables_ageing", "Payables ageing", "Finance",
        "Unpaid supplier bills per supplier by age (from the due date), advances paid and net payable — the same "
        "figures as Finance → Payables.",
        perm="payable.read", filters=["as_of", "supplier_id"], period=None,
        columns=[Col("supplier", "Supplier", width=28), Col("bills", "Bills", "int", 8, True)] + AGEING_COLS +
                [Col("outstanding", "Outstanding", "money", 14), Col("advance", "Advance paid", "money", 13),
                 Col("net", "Net payable", "money", 14)])
def payables_ageing(db: Session, p: Principal, f: Filters) -> dict:
    res = fin.payables(db, f.as_of, f.supplier_id)
    rows = [{**r, "_link": f"/finance/statement?type=supplier&id={r['supplier_id']}"} for r in res["rows"]]
    totals = dict(res["totals"])
    totals["net"] = str(D(totals["outstanding"]) - D(totals["advance"]))
    return {"rows": rows, "totals": totals}


@report("supplier_bill_register", "Supplier bill register", "Finance",
        "Supplier bills (purchase invoices): our bill number, the supplier's invoice, PO, project, GST break-up, "
        "total, amount paid and balance.",
        perm="supplier_invoice.read",
        filters=["period", "supplier_id", "project_id",
                 ("status", {"options": SUPPLIER_INVOICE_STATUSES, "default": "posted"})],
        period="month",
        columns=[Col("bill_date", "Bill date", "date", 11), Col("bill_number", "Our ref.", width=16),
                 Col("supplier_invoice_no", "Supplier invoice", width=16), Col("supplier", "Supplier", width=24),
                 Col("gstin", "GSTIN", width=16), Col("po_number", "PO", width=14), Col("project", "Project", width=13)]
                + TAX_COLS +
                [Col("total", "Total", "money", 14), Col("paid", "Paid", "money", 13), Col("balance", "Balance", "money", 13),
                 Col("due_date", "Due", "date", 11), Col("status", "Status", width=12)])
def supplier_bill_register(db: Session, p: Principal, f: Filters) -> dict:
    B = SupplierInvoice
    stmt = (select(B.id, B.supplier_invoice_date, B.bill_number, B.supplier_invoice_no, Supplier.supplier_name,
                   Supplier.gstin, PurchaseOrder.po_number, Project.project_number, B.taxable, B.cgst, B.sgst, B.igst,
                   B.grand_total, B.paid, B.grand_total - B.paid, B.due_date, B.status)
            .join(Supplier, Supplier.id == B.supplier_id).outerjoin(PurchaseOrder, PurchaseOrder.id == B.purchase_order_id)
            .outerjoin(Project, Project.id == B.project_id))
    stmt = between(stmt, B.supplier_invoice_date, f)
    stmt = eq(stmt, ((B.supplier_id, f.supplier_id), (B.project_id, f.project_id), (B.status, f.status)))
    keys = ("bill_date", "bill_number", "supplier_invoice_no", "supplier", "gstin", "po_number", "project", "taxable",
            "cgst", "sgst", "igst", "total", "paid", "balance", "due_date", "status")
    rows = []
    for i, *v in db.execute(stmt.order_by(B.supplier_invoice_date, B.bill_number)):
        r = dict(zip(keys, v, strict=True))
        r["status"] = r["status"].replace("_", " ")
        rows.append(r | {"_link": f"/finance/bills/view?id={i}"})
    return {"rows": rows}


@report("supplier_payment_register", "Supplier payment register", "Finance",
        "Payments to suppliers: date, number, supplier, mode and reference, amount paid, TDS deducted, allocated to "
        "bills and the advance left.",
        perm="supplier_payment.read",
        filters=["period", "supplier_id",
                 ("status", {"options": [("posted", "Posted"), ("cancelled", "Cancelled")], "default": "posted"}),
                 ("source", {"label": "Mode", "options": PAYMENT_MODES})],
        period="month",
        columns=[Col("payment_date", "Date", "date", 11), Col("payment_number", "Payment no.", width=18),
                 Col("supplier", "Supplier", width=26), Col("po_number", "PO", width=14), Col("mode", "Mode", width=7),
                 Col("reference_no", "Reference", width=16), Col("amount", "Amount paid", "money", 14),
                 Col("tds", "TDS", "money", 11), Col("allocated", "Allocated", "money", 14),
                 Col("unallocated", "Advance", "money", 13), Col("status", "Status", width=9)])
def supplier_payment_register(db: Session, p: Principal, f: Filters) -> dict:
    S = SupplierPayment
    stmt = (select(S.id, S.payment_date, S.payment_number, Supplier.supplier_name, PurchaseOrder.po_number, S.mode,
                   S.reference_no, S.amount, S.tds_amount, S.allocated, S.amount + S.tds_amount - S.allocated, S.status)
            .join(Supplier, Supplier.id == S.supplier_id)
            .outerjoin(PurchaseOrder, PurchaseOrder.id == S.purchase_order_id))
    stmt = between(stmt, S.payment_date, f)
    stmt = eq(stmt, ((S.supplier_id, f.supplier_id), (S.status, f.status), (S.mode, f.source)))
    keys = ("payment_date", "payment_number", "supplier", "po_number", "mode", "reference_no", "amount", "tds",
            "allocated", "unallocated", "status")
    return {"rows": [dict(zip(keys, v, strict=True)) | {"_link": f"/finance/payments/view?id={i}"}
                     for i, *v in db.execute(stmt.order_by(S.payment_date, S.payment_number))]}


@report("expense_claim_register", "Expense claim register", "Finance",
        "Employee expense claims with category, project, status and amount.",
        perm="expense.read", need_all=True,
        filters=["period", "employee_id", "project_id", ("status", {"options": EXPENSE_STATUSES})],
        period="month",
        columns=[Col("expense_date", "Date", "date", 11), Col("expense_number", "Claim no.", width=16),
                 Col("employee", "Employee", width=20), Col("category", "Category", width=16),
                 Col("project", "Project", width=13), Col("description", "Description", width=30),
                 Col("bill_reference", "Bill ref.", width=12), Col("status", "Status", width=10),
                 Col("amount", "Amount", "money", 13), Col("paid_on", "Paid on", "date", 11)])
def expense_claim_register(db: Session, p: Principal, f: Filters) -> dict:
    E = ExpenseClaim
    stmt = (select(E.id, E.expense_date, E.expense_number, Employee.full_name, ExpenseCategory.name,
                   Project.project_number, E.description, E.bill_reference, E.status, E.amount, E.paid_at)
            .join(Employee, Employee.id == E.employee_id).join(ExpenseCategory, ExpenseCategory.id == E.category_id)
            .outerjoin(Project, Project.id == E.project_id))
    stmt = between(stmt, E.expense_date, f)
    stmt = eq(stmt, ((E.employee_id, f.employee_id), (E.project_id, f.project_id), (E.status, f.status)))
    keys = ("expense_date", "expense_number", "employee", "category", "project", "description", "bill_reference",
            "status", "amount", "paid_on")
    rows = []
    for i, *v in db.execute(stmt.order_by(E.expense_date, E.expense_number.nulls_first())):
        r = dict(zip(keys, v, strict=True))
        r["expense_number"] = r["expense_number"] or "DRAFT"
        rows.append(r | {"_link": f"/finance/expenses/view?id={i}"})
    return {"rows": rows}


@report("billing_vs_collections", "Billing vs collections by month", "Finance",
        "Month by month: amount billed (issued invoices less credit notes) against money collected from customers.",
        perm="finance_report.read", filters=["period", "customer_id"],
        columns=[Col("month", "Month", width=12), Col("billed", "Billed before GST", "money", 15),
                 Col("billed_gross", "Billed with GST", "money", 15), Col("collected", "Collected (incl. TDS)", "money", 15),
                 Col("tds", "of which TDS", "money", 12), Col("gap", "Billed with GST − collected", "money", 16)])
def billing_vs_collections(db: Session, p: Principal, f: Filters) -> dict:
    inv = select(Invoice.invoice_date.label("d"), Invoice.taxable.label("b"), Invoice.grand_total.label("bg"),
                 literal(0).label("c"), literal(0).label("t")).where(Invoice.status.in_(("issued", "cancelled")))
    inv = between(inv, Invoice.invoice_date, f)
    cn = between(select(CreditNote.cn_date, -CreditNote.taxable, -CreditNote.total, literal(0), literal(0)),
                 CreditNote.cn_date, f)
    rc = between(select(Receipt.receipt_date, literal(0), literal(0), Receipt.amount + Receipt.tds_amount,
                        Receipt.tds_amount).where(Receipt.status == "posted"), Receipt.receipt_date, f)
    if f.customer_id:
        inv = inv.where(Invoice.customer_id == f.customer_id)
        cn = cn.where(CreditNote.customer_id == f.customer_id)
        rc = rc.where(Receipt.customer_id == f.customer_id)
    u = inv.union_all(cn, rc).subquery()
    m = func.date_trunc("month", u.c.d)
    rows = []
    for mm, b, bg, c, t in db.execute(select(m, func.sum(u.c.b), func.sum(u.c.bg), func.sum(u.c.c), func.sum(u.c.t))
                                      .group_by(m).order_by(m)):
        rows.append({"month": mm.strftime("%b %Y"), "billed": b, "billed_gross": bg, "collected": c, "tds": t,
                     "gap": D(bg) - D(c)})
    return {"rows": rows}


