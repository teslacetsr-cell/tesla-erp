"""Purchase reports: material requests, purchase requests, purchase orders, pending deliveries, GRNs, purchases by
supplier."""
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session, aliased

from app.auth.deps import Principal
from app.crm.service import today
from app.finance.models import SupplierInvoice
from app.products.models import Item, Warehouse
from app.projects.models import Project
from app.purchase.models import (
    MR_STATUSES,
    PO_STATUSES,
    PR_STATUSES,
    Grn,
    GrnLine,
    MaterialRequest,
    MaterialRequestLine,
    PurchaseOrder,
    PurchaseOrderItem,
    PurchaseRequest,
    PurchaseRequestLine,
)
from app.reports.registry import Col, D, Filters, between, eq, ist_date, pct, report
from app.suppliers.models import Supplier
from app.users.models import User

Z = Decimal("0")
OPEN_PO = ("approved", "sent", "partially_received")


@report("material_request_register", "Material request register", "Purchase",
        "Material requests from sites and stores: date, project, store, required-by date, priority, status and lines.",
        perm="material_request.read",
        filters=["period", ("status", {"options": MR_STATUSES}), "project_id", "warehouse_id"], period="month",
        columns=[Col("mr_number", "MR no.", width=14), Col("request_date", "Date", "date", 11),
                 Col("project", "Project", width=24), Col("warehouse", "Store", width=16),
                 Col("required_by", "Required by", "date", 11), Col("priority", "Priority", width=9),
                 Col("lines", "Lines", "int", 7, True), Col("processed", "Lines processed", "int", 9, True),
                 Col("status", "Status", width=11), Col("requested_by", "Requested by", width=16),
                 Col("purpose", "Purpose", width=26)])
def material_request_register(db: Session, p: Principal, f: Filters) -> dict:
    u = aliased(User)
    lines = (select(MaterialRequestLine.request_id.label("doc_id"), func.count().label("n"),
                    func.count().filter(MaterialRequestLine.processed_qty >= MaterialRequestLine.quantity).label("done"))
             .group_by(MaterialRequestLine.request_id).subquery())
    M = MaterialRequest
    stmt = (select(M.id, M.mr_number, M.request_date, func.concat_ws(" ", Project.project_number, Project.name),
                   Warehouse.name, M.required_by, M.priority, func.coalesce(lines.c.n, 0), func.coalesce(lines.c.done, 0),
                   M.status, u.full_name, M.purpose)
            .outerjoin(Project, Project.id == M.project_id).outerjoin(Warehouse, Warehouse.id == M.warehouse_id)
            .outerjoin(u, u.id == M.created_by).outerjoin(lines, lines.c.doc_id == M.id))
    if p.scope("material_request.read") == "own":
        stmt = stmt.where(M.created_by == p.id)
    stmt = between(stmt, M.request_date, f)
    stmt = eq(stmt, ((M.status, f.status), (M.project_id, f.project_id), (M.warehouse_id, f.warehouse_id)))
    keys = ("mr_number", "request_date", "project", "warehouse", "required_by", "priority", "lines", "processed",
            "status", "requested_by", "purpose")
    rows = []
    for i, *v in db.execute(stmt.order_by(M.request_date.desc(), M.mr_number.desc().nulls_first())):
        r = dict(zip(keys, v, strict=True))
        r["mr_number"] = r["mr_number"] or "DRAFT"
        r["status"] = r["status"].replace("_", " ")
        r["project"] = r["project"] or None
        rows.append(r | {"_link": f"/purchase/material-requests/view?id={i}"})
    return {"rows": rows}


@report("purchase_request_register", "Purchase request register", "Purchase",
        "Purchase requests with project, required-by date, priority, status, lines and estimated value.",
        perm="purchase_request.read",
        filters=["period", ("status", {"options": PR_STATUSES}), "project_id"], period="month",
        columns=[Col("pr_number", "PR no.", width=14), Col("pr_date", "Date", "date", 11),
                 Col("project", "Project", width=24), Col("required_by", "Required by", "date", 11),
                 Col("priority", "Priority", width=9), Col("lines", "Lines", "int", 7, True),
                 Col("estimated_value", "Estimated value", "money", 15), Col("status", "Status", width=14),
                 Col("approved_on", "Approved on", "date", 11), Col("raised_by", "Raised by", width=16)])
def purchase_request_register(db: Session, p: Principal, f: Filters) -> dict:
    u = aliased(User)
    lines = (select(PurchaseRequestLine.request_id.label("doc_id"), func.count().label("n"))
             .group_by(PurchaseRequestLine.request_id).subquery())
    R = PurchaseRequest
    stmt = (select(R.id, R.pr_number, R.pr_date, func.concat_ws(" ", Project.project_number, Project.name), R.required_by,
                   R.priority, func.coalesce(lines.c.n, 0), R.estimated_value, R.status, ist_date(R.approved_at),
                   u.full_name)
            .outerjoin(Project, Project.id == R.project_id).outerjoin(u, u.id == R.created_by)
            .outerjoin(lines, lines.c.doc_id == R.id))
    stmt = between(stmt, R.pr_date, f)
    stmt = eq(stmt, ((R.status, f.status), (R.project_id, f.project_id)))
    keys = ("pr_number", "pr_date", "project", "required_by", "priority", "lines", "estimated_value", "status",
            "approved_on", "raised_by")
    rows = []
    for i, *v in db.execute(stmt.order_by(R.pr_date.desc(), R.pr_number.desc().nulls_first())):
        r = dict(zip(keys, v, strict=True))
        r["pr_number"] = r["pr_number"] or "DRAFT"
        r["status"] = r["status"].replace("_", " ")
        r["project"] = r["project"] or None
        rows.append(r | {"_link": f"/purchase/requests/view?id={i}"})
    return {"rows": rows}


@report("purchase_order_register", "Purchase order register", "Purchase",
        "Purchase orders with supplier, value, how much has been received and the value still pending.",
        perm="purchase_order.read",
        filters=["period", ("status", {"options": PO_STATUSES}), "supplier_id", "project_id", "warehouse_id"],
        columns=[Col("po_number", "PO no.", width=14), Col("po_date", "Date", "date", 11),
                 Col("supplier", "Supplier", width=26), Col("project", "Project", width=20),
                 Col("warehouse", "Deliver to", width=14), Col("expected_delivery", "Expected", "date", 11),
                 Col("taxable", "Value before GST", "money", 15), Col("grand_total", "Total with GST", "money", 15),
                 Col("received_value", "Received (before GST)", "money", 15), Col("received_pct", "Received %", "pct", 9),
                 Col("pending_value", "Pending (before GST)", "money", 15), Col("status", "Status", width=14)])
def purchase_order_register(db: Session, p: Principal, f: Filters) -> dict:
    POI = PurchaseOrderItem
    recv = (select(POI.purchase_order_id.label("po_id"),
                   func.sum(func.round(POI.taxable * POI.received_qty / func.nullif(POI.quantity, 0), 2)).label("rv"))
            .group_by(POI.purchase_order_id).subquery())
    P = PurchaseOrder
    stmt = (select(P.id, P.po_number, P.po_date, Supplier.supplier_name, Project.project_number, Warehouse.name,
                   P.expected_delivery, P.taxable, P.grand_total, func.coalesce(recv.c.rv, 0), P.status)
            .join(Supplier, Supplier.id == P.supplier_id).join(Warehouse, Warehouse.id == P.warehouse_id)
            .outerjoin(Project, Project.id == P.project_id).outerjoin(recv, recv.c.po_id == P.id))
    stmt = between(stmt, P.po_date, f)
    stmt = eq(stmt, ((P.status, f.status), (P.supplier_id, f.supplier_id), (P.project_id, f.project_id),
                     (P.warehouse_id, f.warehouse_id)))
    rows = []
    for i, num, d, sup, prj, wh, exp, tx, gt, rv, st in db.execute(
            stmt.order_by(P.po_date.desc(), P.po_number.desc().nulls_first())):
        pending = Z if st in ("cancelled", "closed", "draft") else max(tx - rv, Z)
        rows.append({"po_number": num or "DRAFT", "po_date": d, "supplier": sup, "project": prj, "warehouse": wh,
                     "expected_delivery": exp, "taxable": tx, "grand_total": gt, "received_value": rv,
                     "received_pct": pct(rv, tx), "pending_value": pending, "status": st.replace("_", " "),
                     "_link": f"/purchase/orders/view?id={i}"})
    tx, rv = sum((r["taxable"] for r in rows), Z), sum((D(r["received_value"]) for r in rows), Z)
    return {"rows": rows, "totals": {"received_pct": pct(rv, tx)}}


@report("pending_deliveries", "Pending deliveries", "Purchase",
        "Open purchase order lines still to be received: quantity pending, value, expected date and days late.",
        perm="purchase_order.read", filters=["supplier_id", "project_id", "warehouse_id", "item_id"], period=None,
        columns=[Col("po_number", "PO no.", width=14), Col("po_date", "PO date", "date", 11),
                 Col("supplier", "Supplier", width=24), Col("project", "Project", width=14),
                 Col("description", "Item", width=32), Col("unit", "Unit", width=6),
                 Col("ordered", "Ordered", "qty", 9, False), Col("received", "Received", "qty", 9, False),
                 Col("pending", "Pending", "qty", 9, False), Col("pending_value", "Pending value (before GST)", "money", 15),
                 Col("expected_delivery", "Expected", "date", 11), Col("days_late", "Days late", "int", 8)])
def pending_deliveries(db: Session, p: Principal, f: Filters) -> dict:
    POI, P = PurchaseOrderItem, PurchaseOrder
    stmt = (select(P.id, P.po_number, P.po_date, Supplier.supplier_name, Project.project_number,
                   func.coalesce(Item.item_name, POI.description), POI.unit, POI.quantity, POI.received_qty,
                   POI.taxable, P.expected_delivery)
            .join(P, P.id == POI.purchase_order_id).join(Supplier, Supplier.id == P.supplier_id)
            .outerjoin(Project, Project.id == P.project_id).outerjoin(Item, Item.id == POI.item_id)
            .where(P.status.in_(OPEN_PO), POI.quantity > POI.received_qty))
    stmt = eq(stmt, ((P.supplier_id, f.supplier_id), (P.project_id, f.project_id), (P.warehouse_id, f.warehouse_id),
                     (POI.item_id, f.item_id)))
    t = today()
    rows = []
    for i, num, d, sup, prj, desc, unit, q, rq, tx, exp in db.execute(
            stmt.order_by(P.expected_delivery.nulls_last(), P.po_number, POI.line_no)):
        pend = q - rq
        rows.append({"po_number": num, "po_date": d, "supplier": sup, "project": prj, "description": desc,
                     "unit": unit, "ordered": q, "received": rq, "pending": pend,
                     "pending_value": tx * pend / q if q else Z, "expected_delivery": exp,
                     "days_late": (t - exp).days if exp and exp < t else None,
                     "_link": f"/purchase/orders/view?id={i}"})
    return {"rows": rows}


@report("grn_register", "GRN register", "Purchase",
        "Goods received notes: date, PO, supplier, store, supplier invoice / challan, quantities accepted and rejected, value.",
        perm="grn.read", filters=["period", "supplier_id", "project_id", "warehouse_id"], period="month",
        columns=[Col("grn_number", "GRN no.", width=14), Col("grn_date", "Date", "date", 11),
                 Col("po_number", "PO no.", width=14), Col("supplier", "Supplier", width=24),
                 Col("warehouse", "Store", width=14), Col("project", "Project", width=13),
                 Col("supplier_invoice_no", "Supplier invoice", width=14), Col("challan", "Challan", width=12),
                 Col("lines", "Lines", "int", 6, True), Col("accepted", "Accepted qty", "qty", 10, False),
                 Col("rejected", "Rejected qty", "qty", 10, False), Col("value", "Value (before GST)", "money", 15)])
def grn_register(db: Session, p: Principal, f: Filters) -> dict:
    lines = (select(GrnLine.grn_id.label("grn_id"), func.count().label("n"), func.sum(GrnLine.accepted_qty).label("a"),
                    func.sum(GrnLine.rejected_qty).label("r")).group_by(GrnLine.grn_id).subquery())
    stmt = (select(Grn.id, Grn.grn_number, Grn.grn_date, PurchaseOrder.po_number, Supplier.supplier_name,
                   Warehouse.name, Project.project_number, Grn.supplier_invoice_no, Grn.delivery_challan_no,
                   func.coalesce(lines.c.n, 0), lines.c.a, lines.c.r, Grn.value)
            .join(PurchaseOrder, PurchaseOrder.id == Grn.purchase_order_id)
            .join(Supplier, Supplier.id == Grn.supplier_id).join(Warehouse, Warehouse.id == Grn.warehouse_id)
            .outerjoin(Project, Project.id == Grn.project_id).outerjoin(lines, lines.c.grn_id == Grn.id))
    stmt = between(stmt, Grn.grn_date, f)
    stmt = eq(stmt, ((Grn.supplier_id, f.supplier_id), (Grn.project_id, f.project_id), (Grn.warehouse_id, f.warehouse_id)))
    keys = ("grn_number", "grn_date", "po_number", "supplier", "warehouse", "project", "supplier_invoice_no", "challan",
            "lines", "accepted", "rejected", "value")
    return {"rows": [dict(zip(keys, v, strict=True)) | {"_link": f"/purchase/grn/view?id={i}"}
                     for i, *v in db.execute(stmt.order_by(Grn.grn_date.desc(), Grn.grn_number.desc()))]}


@report("purchases_by_supplier", "Purchases by supplier", "Purchase",
        "Posted supplier bills per supplier in the period: bills, value before GST, GST, total, paid and balance.",
        perm="supplier_invoice.read", filters=["period", "supplier_id", "project_id"],
        columns=[Col("supplier", "Supplier", width=28), Col("gstin", "GSTIN", width=16),
                 Col("bills", "Bills", "int", 7, True), Col("taxable", "Value before GST", "money", 15),
                 Col("gst", "GST", "money", 13), Col("total", "Total with GST", "money", 15),
                 Col("paid", "Paid", "money", 14), Col("balance", "Balance", "money", 14)])
def purchases_by_supplier(db: Session, p: Principal, f: Filters) -> dict:
    B = SupplierInvoice
    stmt = (select(Supplier.supplier_name, Supplier.gstin, func.count(), func.sum(B.taxable),
                   func.sum(B.cgst + B.sgst + B.igst), func.sum(B.grand_total), func.sum(B.paid),
                   func.sum(B.grand_total - B.paid))
            .join(Supplier, Supplier.id == B.supplier_id).where(B.status == "posted")
            .group_by(Supplier.id).order_by(func.sum(B.taxable).desc()))
    stmt = between(stmt, B.supplier_invoice_date, f)
    stmt = eq(stmt, ((B.supplier_id, f.supplier_id), (B.project_id, f.project_id)))
    keys = ("supplier", "gstin", "bills", "taxable", "gst", "total", "paid", "balance")
    return {"rows": [dict(zip(keys, v, strict=True)) for v in db.execute(stmt)]}
