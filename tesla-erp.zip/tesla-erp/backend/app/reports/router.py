"""Reports API: the catalog, running a report, and Excel / PDF export."""
import re
from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Query, Request, Response

from app.auth.deps import CurrentUser, Principal
from app.core.api import ok
from app.core.db import DbSession
from app.core.errors import Forbidden, NotFound
from app.core.excel import XLSX
from app.platform import pdfkit
from app.platform.audit import service as audit
from app.reports import catalog, export
from app.reports.registry import REPORTS, SOURCES, Report, execute, parse_filters

router = APIRouter(tags=["reports"])


def _report(p: Principal, key: str) -> Report:
    r = REPORTS.get(key)
    if r is None:
        raise NotFound("report")
    if not r.allowed(p):
        raise Forbidden("You do not have permission to run this report.")
    return r


def _query(request: Request) -> dict[str, str]:
    return {k: v for k, v in request.query_params.items() if k != "format"}


@router.get("/reports")
def list_reports(p: CurrentUser):
    return ok(catalog.catalog(p))


@router.get("/reports/options/{source}")
def report_options(source: str, db: DbSession, p: CurrentUser):
    if source not in SOURCES:
        raise NotFound("option list")
    if not catalog.source_allowed(p, source):
        raise Forbidden()
    return ok(catalog.option_list(db, p, source))


@router.get("/reports/{key}")
def run_report(key: str, request: Request, db: DbSession, p: CurrentUser):
    r = _report(p, key)
    f = parse_filters(r, _query(request))
    res = execute(db, p, r, f)
    res["filters_label"] = catalog.describe(db, r, f)
    return ok(res)


@router.get("/reports/{key}/export")
def export_report(key: str, request: Request, db: DbSession, p: CurrentUser,
                  format: Annotated[str, Query(pattern="^(xlsx|pdf)$")] = "xlsx"):  # noqa: A002 - query name
    r = _report(p, key)
    f = parse_filters(r, _query(request))
    res = execute(db, p, r, f)
    label = catalog.describe(db, r, f)
    who = p.user.full_name
    stamp = datetime.now(pdfkit.IST).strftime("%Y%m%d")
    name = f"{re.sub(r'[^a-z0-9]+', '-', r.title.lower()).strip('-')}-{stamp}"
    if format == "pdf":
        data, media, disp = export.pdf(db, res, label, who), "application/pdf", "inline"
    else:
        data, media, disp = export.xlsx(res, label, who), XLSX, "attachment"
    audit.record(db, action="export", entity_type="report", entity_label=r.key,
                 summary=f"{r.title} ({format.upper()}, {res['row_count']} rows){' — ' + label if label else ''}"[:500])
    return Response(data, media_type=media,
                    headers={"Content-Disposition": f'{disp}; filename="{name}.{format}"'})


