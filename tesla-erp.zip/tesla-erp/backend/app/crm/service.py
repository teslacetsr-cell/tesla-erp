"""CRM business rules (Spec §11, §12).

Pipeline stages move forward automatically as work happens (enquiry created → lead Qualified; visit scheduled →
Site Visit; visit completed → enquiry Technical Evaluation). Automatic moves never go backwards and never touch a
closed (won/lost/cancelled) record; people can always set a status by hand.
"""
import uuid
from datetime import date, datetime, time, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session, object_session

from app.auth.deps import Principal
from app.company.models import BusinessDivision
from app.core.api import ListParams, paginate
from app.core.errors import AppError, Conflict, Forbidden, NotFound
from app.core.models import check_row_version
from app.crm.models import (
    CLOSED_ENQUIRY,
    CLOSED_LEAD,
    ENQUIRY_STATUSES,
    LEAD_STATUSES,
    CrmActivity,
    Enquiry,
    Lead,
    SiteVisit,
)
from app.crm.schemas import (
    ActivityIn,
    ConvertIn,
    EnquiryIn,
    EnquiryUpdate,
    LeadIn,
    LeadUpdate,
    SiteVisitIn,
    SiteVisitUpdate,
    StatusIn,
)
from app.customers import service as customers
from app.customers.models import Customer, CustomerContact, CustomerSite
from app.customers.schemas import CustomerIn
from app.platform.audit import service as audit
from app.platform.numbering import service as numbering
from app.platform.settings import service as settings
from app.users.models import User

IST = ZoneInfo("Asia/Kolkata")
LEAD_ORDER = ("new", "contacted", "qualified", "site_visit", "quotation", "negotiation")
ENQUIRY_ORDER = ("open", "site_visit", "evaluation", "quoted")


def now() -> datetime:
    return datetime.now(IST)


def today() -> date:
    return now().date()


# ------------------------------------------------------------------ record-level scope
# 'own' means: assigned to me, or created by me. A site engineer also "owns" the visits assigned to them and the
# enquiries those visits belong to; a salesperson also sees the visits made for their leads and enquiries.
def _lead_own(p: Principal):
    return or_(Lead.sales_person_id == p.id, Lead.created_by == p.id)


def _enquiry_own(p: Principal):
    return or_(Enquiry.sales_person_id == p.id, Enquiry.created_by == p.id,
               Enquiry.id.in_(select(SiteVisit.enquiry_id).where(SiteVisit.engineer_id == p.id)))


def _visit_own(p: Principal):
    return or_(SiteVisit.engineer_id == p.id, SiteVisit.created_by == p.id,
               SiteVisit.enquiry_id.in_(select(Enquiry.id).where(Enquiry.sales_person_id == p.id)),
               SiteVisit.lead_id.in_(select(Lead.id).where(Lead.sales_person_id == p.id)))


_OWN = {"lead": (Lead, _lead_own), "enquiry": (Enquiry, _enquiry_own), "site_visit": (SiteVisit, _visit_own)}
_NOUN = {"lead": "leads", "enquiry": "enquiries", "site_visit": "site visits"}


def scope_clause(p: Principal, module: str, action: str):
    """WHERE clause limiting a list to the records the user may see (None = no limit)."""
    scope = p.scope(f"{module}.{action}")
    if scope is None:
        raise Forbidden()
    return _OWN[module][1](p) if scope == "own" else None


def allowed(p: Principal, module: str, obj: Any, action: str) -> bool:
    scope = p.scope(f"{module}.{action}")
    if scope is None:
        return False
    if scope != "own":
        return True
    model, own = _OWN[module]
    db = object_session(obj)
    return db.scalar(select(model.id).where(model.id == obj.id, own(p))) is not None


def check(p: Principal, module: str, obj: Any, action: str) -> None:
    if p.scope(f"{module}.{action}") is None:
        raise Forbidden()
    if not allowed(p, module, obj, action):
        raise Forbidden(f"You can only work on {_NOUN[module]} assigned to you.", code="OUT_OF_SCOPE")


# ------------------------------------------------------------------ lookups & validation
def _get(db: Session, model, obj_id: uuid.UUID, name: str, lock: bool = False):
    obj = db.get(model, obj_id, with_for_update=lock or None)
    if obj is None:
        raise NotFound(name)
    return obj


def get_lead(db: Session, lead_id: uuid.UUID, lock: bool = False) -> Lead:
    return _get(db, Lead, lead_id, "lead", lock)


def get_enquiry(db: Session, enquiry_id: uuid.UUID, lock: bool = False) -> Enquiry:
    return _get(db, Enquiry, enquiry_id, "enquiry", lock)


def get_visit(db: Session, visit_id: uuid.UUID, lock: bool = False) -> SiteVisit:
    return _get(db, SiteVisit, visit_id, "site_visit", lock)


def _active_user(db: Session, user_id: uuid.UUID | None, what: str) -> None:
    if user_id is None:
        return
    u = db.get(User, user_id)
    if u is None or not u.is_active:
        raise AppError("INVALID_USER", f"The {what} must be an active ERP user.",
                       details={"field": what.replace(" ", "_")})


def _division(db: Session, division_id: uuid.UUID | None) -> None:
    if division_id is not None and db.get(BusinessDivision, division_id) is None:
        raise AppError("INVALID_DIVISION", "The business division does not exist.")


def _customer(db: Session, customer_id: uuid.UUID) -> Customer:
    c = db.get(Customer, customer_id)
    if c is None:
        raise AppError("INVALID_CUSTOMER", "The customer does not exist.")
    if c.status == "blocked":
        raise AppError("CUSTOMER_BLOCKED", f"{c.customer_name} is blocked. Unblock the customer first.")
    return c


def _site(db: Session, customer_id: uuid.UUID, site_id: uuid.UUID | None) -> CustomerSite | None:
    if site_id is None:
        return None
    s = db.get(CustomerSite, site_id)
    if s is None or s.customer_id != customer_id:
        raise AppError("INVALID_SITE", "The site does not belong to this customer.")
    return s


def _contact(db: Session, customer_id: uuid.UUID, contact_id: uuid.UUID | None) -> None:
    if contact_id is None:
        return
    c = db.get(CustomerContact, contact_id)
    if c is None or c.customer_id != customer_id:
        raise AppError("INVALID_CONTACT", "The contact does not belong to this customer.")


def _advance_lead(lead: Lead | None, target: str) -> None:
    if lead is None or lead.status in CLOSED_LEAD:
        return
    if LEAD_ORDER.index(target) > LEAD_ORDER.index(lead.status):
        before = lead.status
        lead.status, lead.status_changed_at = target, now()
        audit.record(object_session(lead), action="status", entity_type="lead", entity_id=lead.id,
                     entity_label=lead.lead_number, summary=f"Status {before} → {target} (automatic)")


def _advance_enquiry(enq: Enquiry | None, target: str) -> None:
    if enq is None or enq.status in CLOSED_ENQUIRY:
        return
    if ENQUIRY_ORDER.index(target) > ENQUIRY_ORDER.index(enq.status):
        before = enq.status
        enq.status, enq.status_changed_at = target, now()
        audit.record(object_session(enq), action="status", entity_type="enquiry", entity_id=enq.id,
                     entity_label=enq.enquiry_number, summary=f"Status {before} → {target} (automatic)")


def _default_owner(p: Principal, value: uuid.UUID | None) -> uuid.UUID | None:
    """A salesperson's new lead/enquiry is theirs unless they pick someone else."""
    if value is None and "SALES" in p.role_codes:
        return p.id
    return value


# ------------------------------------------------------------------ leads
def list_leads(db: Session, p: Principal, params: ListParams, *, status: str | None, sales_person_id: uuid.UUID | None,
               source: str | None, customer_id: uuid.UUID | None, open_only: bool):
    stmt = select(Lead)
    if (clause := scope_clause(p, "lead", "read")) is not None:
        stmt = stmt.where(clause)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(
            Lead.lead_number.ilike(like), Lead.title.ilike(like), Lead.company_name.ilike(like),
            Lead.contact_name.ilike(like), Lead.contact_phone.ilike(like), Lead.city.ilike(like),
            Lead.customer_id.in_(select(Customer.id).where(Customer.customer_name.ilike(like)))))
    if status:
        stmt = stmt.where(Lead.status == status)
    if open_only:
        stmt = stmt.where(Lead.status.not_in(CLOSED_LEAD))
    if sales_person_id:
        stmt = stmt.where(Lead.sales_person_id == sales_person_id)
    if source:
        stmt = stmt.where(Lead.source == source)
    if customer_id:
        stmt = stmt.where(Lead.customer_id == customer_id)
    return paginate(db, stmt, params, default_sort=Lead.created_at.desc(), sortable={
        "lead_number": Lead.lead_number, "title": Lead.title, "created_at": Lead.created_at,
        "estimated_value": Lead.estimated_value, "expected_closing_date": Lead.expected_closing_date,
        "status": Lead.status})


def _lead_refs(db: Session, data: LeadIn) -> None:
    if data.customer_id:
        _customer(db, data.customer_id)
    _division(db, data.division_id)
    _active_user(db, data.sales_person_id, "sales person")


def create_lead(db: Session, p: Principal, data: LeadIn) -> Lead:
    _lead_refs(db, data)
    values = data.model_dump()
    values["sales_person_id"] = _default_owner(p, values["sales_person_id"])
    lead = Lead(lead_number=numbering.next_number(db, p.company_id, "LEAD", on=today()), **values,
                status="new", status_changed_at=now(), created_by=p.id, updated_by=p.id)
    db.add(lead)
    db.flush()
    audit.record(db, action="create", entity_type="lead", entity_id=lead.id,
                 entity_label=f"{lead.lead_number} {lead.title}", after=audit.snapshot(lead))
    return lead


def update_lead(db: Session, p: Principal, lead_id: uuid.UUID, data: LeadUpdate) -> Lead:
    lead = get_lead(db, lead_id, lock=True)
    check(p, "lead", lead, "update")
    if lead.customer_id and data.customer_id != lead.customer_id and _has_enquiries(db, lead.id):
        raise AppError("CUSTOMER_LOCKED", "This lead already has enquiries for its customer; the customer cannot change.")
    _lead_refs(db, data)
    before = audit.snapshot(lead)
    values = data.model_dump()
    check_row_version(lead, values.pop("row_version"))
    for k, v in values.items():
        setattr(lead, k, v)
    lead.updated_by = p.id
    db.flush()
    audit.record(db, action="update", entity_type="lead", entity_id=lead.id,
                 entity_label=f"{lead.lead_number} {lead.title}", before=before, after=audit.snapshot(lead))
    return lead


def _has_enquiries(db: Session, lead_id: uuid.UUID) -> bool:
    return db.scalar(select(Enquiry.id).where(Enquiry.lead_id == lead_id).limit(1)) is not None


def set_lead_status(db: Session, p: Principal, lead_id: uuid.UUID, body: StatusIn) -> Lead:
    lead = get_lead(db, lead_id, lock=True)
    check(p, "lead", lead, "update")
    if body.status not in LEAD_STATUSES:
        raise AppError("INVALID_STATUS", "Unknown lead status.", details={"allowed": LEAD_STATUSES})
    if body.row_version is not None:
        check_row_version(lead, body.row_version)
    else:
        lead.row_version += 1
    _set_status(db, "lead", lead, lead.lead_number, body)
    lead.updated_by = p.id
    return lead


def _set_status(db: Session, entity: str, obj, label: str, body: StatusIn) -> None:
    if body.status == "lost" and not body.lost_reason:
        raise AppError("LOST_REASON_REQUIRED", "Say why it was lost — this feeds the win/loss report.",
                       details={"field": "lost_reason"})
    before = obj.status
    obj.status, obj.status_changed_at = body.status, now()
    obj.lost_reason = body.lost_reason if body.status == "lost" else None
    db.flush()
    audit.record(db, action="status", entity_type=entity, entity_id=obj.id, entity_label=label,
                 summary=f"Status {before} → {body.status}" + (f": {body.lost_reason}" if body.status == "lost" else ""))


def delete_lead(db: Session, p: Principal, lead_id: uuid.UUID) -> None:
    lead = get_lead(db, lead_id, lock=True)
    check(p, "lead", lead, "delete")
    if _has_enquiries(db, lead.id) or db.scalar(select(SiteVisit.id).where(SiteVisit.lead_id == lead.id).limit(1)):
        raise Conflict("IN_USE", "This lead has enquiries or site visits. Mark it Lost instead of deleting it.")
    snap, label = audit.snapshot(lead), f"{lead.lead_number} {lead.title}"
    db.delete(lead)
    db.flush()
    audit.record(db, action="delete", entity_type="lead", entity_id=lead_id, entity_label=label, before=snap)


def convert_lead(db: Session, p: Principal, lead_id: uuid.UUID, body: ConvertIn) -> Enquiry:
    """Lead → enquiry, linking (or creating) exactly one customer. Duplicates are caught before a customer is made."""
    lead = get_lead(db, lead_id, lock=True)
    check(p, "lead", lead, "update")
    if not p.can("enquiry.create"):
        raise Forbidden("You do not have permission: enquiry.create.")
    if lead.status in CLOSED_LEAD:
        raise AppError("LEAD_CLOSED", f"This lead is {lead.status}. Reopen it before creating an enquiry.")

    customer: Customer | None = None
    if lead.customer_id:
        customer = _customer(db, lead.customer_id)
        if body.customer_id and body.customer_id != lead.customer_id:
            raise AppError("CUSTOMER_MISMATCH", "This lead is already linked to a different customer.")
    elif body.customer_id:
        customer = _customer(db, body.customer_id)
    else:
        customer = _customer_from_prospect(db, p, lead, allow_duplicate=body.allow_duplicate)
    if lead.customer_id is None:
        lead.customer_id = customer.id
        audit.record(db, action="update", entity_type="lead", entity_id=lead.id, entity_label=lead.lead_number,
                     summary=f"Linked to customer {customer.customer_code} {customer.customer_name}")
    _site(db, customer.id, body.site_id)

    enq = Enquiry(
        enquiry_number=numbering.next_number(db, p.company_id, "ENQ", on=today()), lead_id=lead.id,
        customer_id=customer.id, site_id=body.site_id, division_id=lead.division_id,
        subject=body.subject or lead.title, description=body.description or lead.requirement,
        enquiry_date=today(), required_by=body.required_by, source=lead.source, priority=body.priority,
        estimated_value=lead.estimated_value, sales_person_id=lead.sales_person_id or _default_owner(p, None),
        status="open", status_changed_at=now(), created_by=p.id, updated_by=p.id,
    )
    db.add(enq)
    db.flush()
    audit.record(db, action="create", entity_type="enquiry", entity_id=enq.id,
                 entity_label=f"{enq.enquiry_number} {enq.subject}", after=audit.snapshot(enq),
                 summary=f"Created from lead {lead.lead_number}")
    _advance_lead(lead, "qualified")
    lead.updated_by = p.id
    lead.row_version += 1
    return enq


def _customer_from_prospect(db: Session, p: Principal, lead: Lead, *, allow_duplicate: bool) -> Customer:
    if not p.can("customer.create"):
        raise Forbidden("This lead is not linked to a customer yet, and you cannot create customers. "
                        "Pick an existing customer, or ask a manager to convert it.", code="CUSTOMER_REQUIRED")
    name = lead.company_name or lead.contact_name
    candidates = customers.duplicates(db, name=name, gstin=None, phone=lead.contact_phone)
    if candidates and not allow_duplicate:
        raise Conflict("POSSIBLE_DUPLICATE_CUSTOMER",
                       "A customer that looks the same already exists. Use it, or confirm this is a new customer.",
                       details={"candidates": candidates})
    try:
        data = CustomerIn(customer_name=name, customer_type="company" if lead.company_name else "individual",
                          phone=lead.contact_phone, email=lead.contact_email, city=lead.city,
                          assigned_sales_person_id=lead.sales_person_id)
    except ValueError as exc:  # e.g. a prospect name of one character
        raise AppError("PROSPECT_INCOMPLETE", f"The prospect details cannot make a customer record: {exc}") from exc
    customer = customers.create(db, p, data, allow_duplicate=True)
    if lead.company_name and lead.contact_name:
        contact = CustomerContact(customer_id=customer.id, name=lead.contact_name, phone=lead.contact_phone,
                                  email=lead.contact_email, is_primary=True, created_by=p.id, updated_by=p.id)
        db.add(contact)
        db.flush()
    return customer


# ------------------------------------------------------------------ enquiries
def list_enquiries(db: Session, p: Principal, params: ListParams, *, status: str | None,
                   sales_person_id: uuid.UUID | None, customer_id: uuid.UUID | None, lead_id: uuid.UUID | None,
                   open_only: bool):
    stmt = select(Enquiry)
    if (clause := scope_clause(p, "enquiry", "read")) is not None:
        stmt = stmt.where(clause)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(
            Enquiry.enquiry_number.ilike(like), Enquiry.subject.ilike(like),
            Enquiry.customer_id.in_(select(Customer.id).where(or_(Customer.customer_name.ilike(like),
                                                                  Customer.customer_code.ilike(like))))))
    if status:
        stmt = stmt.where(Enquiry.status == status)
    if open_only:
        stmt = stmt.where(Enquiry.status.not_in(CLOSED_ENQUIRY))
    if sales_person_id:
        stmt = stmt.where(Enquiry.sales_person_id == sales_person_id)
    if customer_id:
        stmt = stmt.where(Enquiry.customer_id == customer_id)
    if lead_id:
        stmt = stmt.where(Enquiry.lead_id == lead_id)
    return paginate(db, stmt, params, default_sort=Enquiry.created_at.desc(), sortable={
        "enquiry_number": Enquiry.enquiry_number, "subject": Enquiry.subject, "enquiry_date": Enquiry.enquiry_date,
        "required_by": Enquiry.required_by, "created_at": Enquiry.created_at, "status": Enquiry.status,
        "estimated_value": Enquiry.estimated_value})


def _enquiry_refs(db: Session, p: Principal, data: EnquiryIn, current: Enquiry | None = None) -> Lead | None:
    _customer(db, data.customer_id)
    _site(db, data.customer_id, data.site_id)
    _contact(db, data.customer_id, data.contact_id)
    _division(db, data.division_id)
    _active_user(db, data.sales_person_id, "sales person")
    lead = None
    if data.lead_id and (current is None or current.lead_id != data.lead_id):
        lead = get_lead(db, data.lead_id, lock=True)
        check(p, "lead", lead, "read")
        if lead.customer_id and lead.customer_id != data.customer_id:
            raise AppError("CUSTOMER_MISMATCH", "The lead belongs to a different customer.")
    return lead


def create_enquiry(db: Session, p: Principal, data: EnquiryIn) -> Enquiry:
    lead = _enquiry_refs(db, p, data)
    values = data.model_dump()
    values["enquiry_date"] = values["enquiry_date"] or today()
    values["sales_person_id"] = _default_owner(p, values["sales_person_id"] or (lead.sales_person_id if lead else None))
    enq = Enquiry(enquiry_number=numbering.next_number(db, p.company_id, "ENQ", on=values["enquiry_date"]), **values,
                  status="open", status_changed_at=now(), created_by=p.id, updated_by=p.id)
    db.add(enq)
    db.flush()
    audit.record(db, action="create", entity_type="enquiry", entity_id=enq.id,
                 entity_label=f"{enq.enquiry_number} {enq.subject}", after=audit.snapshot(enq))
    if lead is not None:
        if lead.customer_id is None:
            lead.customer_id = data.customer_id
        _advance_lead(lead, "qualified")
    return enq


def update_enquiry(db: Session, p: Principal, enquiry_id: uuid.UUID, data: EnquiryUpdate) -> Enquiry:
    enq = get_enquiry(db, enquiry_id, lock=True)
    check(p, "enquiry", enq, "update")
    if data.customer_id != enq.customer_id and db.scalar(
            select(SiteVisit.id).where(SiteVisit.enquiry_id == enq.id).limit(1)):
        raise AppError("CUSTOMER_LOCKED", "This enquiry has site visits; its customer cannot change.")
    lead = _enquiry_refs(db, p, data, enq)
    before = audit.snapshot(enq)
    values = data.model_dump()
    check_row_version(enq, values.pop("row_version"))
    values["enquiry_date"] = values["enquiry_date"] or enq.enquiry_date
    for k, v in values.items():
        setattr(enq, k, v)
    enq.updated_by = p.id
    db.flush()
    if lead is not None and lead.customer_id is None:
        lead.customer_id = enq.customer_id
    audit.record(db, action="update", entity_type="enquiry", entity_id=enq.id,
                 entity_label=f"{enq.enquiry_number} {enq.subject}", before=before, after=audit.snapshot(enq))
    return enq


def set_enquiry_status(db: Session, p: Principal, enquiry_id: uuid.UUID, body: StatusIn) -> Enquiry:
    enq = get_enquiry(db, enquiry_id, lock=True)
    check(p, "enquiry", enq, "update")
    if body.status not in ENQUIRY_STATUSES:
        raise AppError("INVALID_STATUS", "Unknown enquiry status.", details={"allowed": ENQUIRY_STATUSES})
    if body.row_version is not None:
        check_row_version(enq, body.row_version)
    else:
        enq.row_version += 1
    _set_status(db, "enquiry", enq, enq.enquiry_number, body)
    enq.updated_by = p.id
    # Winning the enquiry wins the lead behind it.
    if body.status == "won" and enq.lead is not None and enq.lead.status not in CLOSED_LEAD:
        _set_status(db, "lead", enq.lead, enq.lead.lead_number, StatusIn(status="won"))
    return enq


def delete_enquiry(db: Session, p: Principal, enquiry_id: uuid.UUID) -> None:
    enq = get_enquiry(db, enquiry_id, lock=True)
    check(p, "enquiry", enq, "delete")
    if db.scalar(select(SiteVisit.id).where(SiteVisit.enquiry_id == enq.id).limit(1)):
        raise Conflict("IN_USE", "This enquiry has site visits. Cancel it instead of deleting it.")
    snap, label = audit.snapshot(enq), f"{enq.enquiry_number} {enq.subject}"
    db.delete(enq)
    db.flush()
    audit.record(db, action="delete", entity_type="enquiry", entity_id=enquiry_id, entity_label=label, before=snap)


# ------------------------------------------------------------------ site visits
def list_visits(db: Session, p: Principal, params: ListParams, *, status: str | None, engineer_id: uuid.UUID | None,
                customer_id: uuid.UUID | None, enquiry_id: uuid.UUID | None, date_from: date | None,
                date_to: date | None):
    stmt = select(SiteVisit)
    if (clause := scope_clause(p, "site_visit", "read")) is not None:
        stmt = stmt.where(clause)
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(
            SiteVisit.visit_number.ilike(like), SiteVisit.site_location.ilike(like), SiteVisit.purpose.ilike(like),
            SiteVisit.customer_id.in_(select(Customer.id).where(Customer.customer_name.ilike(like)))))
    for col, val in ((SiteVisit.status, status), (SiteVisit.engineer_id, engineer_id),
                     (SiteVisit.customer_id, customer_id), (SiteVisit.enquiry_id, enquiry_id)):
        if val:
            stmt = stmt.where(col == val)
    if date_from:
        stmt = stmt.where(SiteVisit.visit_date >= date_from)
    if date_to:
        stmt = stmt.where(SiteVisit.visit_date <= date_to)
    return paginate(db, stmt, params, default_sort=SiteVisit.visit_date.desc(), sortable={
        "visit_number": SiteVisit.visit_number, "visit_date": SiteVisit.visit_date, "status": SiteVisit.status,
        "created_at": SiteVisit.created_at})


def _site_label(site: CustomerSite | None) -> str | None:
    if site is None:
        return None
    return ", ".join(x for x in (site.site_name, site.address_line1, site.city) if x)[:300]


def _visit_values(db: Session, p: Principal, data: SiteVisitIn, current: SiteVisit | None) -> dict:
    values = data.model_dump(exclude={"measurements"})
    values["measurements"] = [m.model_dump() for m in data.measurements]
    enq = None
    if data.enquiry_id:
        enq = get_enquiry(db, data.enquiry_id)
        if current is None or current.enquiry_id != enq.id:
            check(p, "enquiry", enq, "read")
        if data.customer_id and data.customer_id != enq.customer_id:
            raise AppError("CUSTOMER_MISMATCH", "The enquiry belongs to a different customer.")
        values["customer_id"] = enq.customer_id
        values["site_id"] = data.site_id or enq.site_id
        values["lead_id"] = enq.lead_id
    else:
        values["lead_id"] = current.lead_id if current else None
    customer = _customer(db, values["customer_id"])
    site = _site(db, values["customer_id"], values["site_id"])
    if not values["site_location"] and site is not None:
        values["site_location"] = _site_label(site)
    if not values["site_location"]:  # fall back to the customer's own address
        values["site_location"] = ", ".join(x for x in (customer.address_line1, customer.city) if x)[:300] or None
    if not values["site_location"]:
        raise AppError("LOCATION_REQUIRED", "Choose a customer site or type the site location.",
                       details={"field": "site_location"})
    _active_user(db, data.engineer_id, "engineer")
    if values["engineer_id"] is None and current is None and "SITE_ENGINEER" in p.role_codes:
        values["engineer_id"] = p.id
    if not settings.get_setting(db, p.company_id, "crm.site_visit_gps"):
        values.update(latitude=None, longitude=None, location_accuracy_m=None)
    if values["latitude"] is None:
        values["location_captured_at"] = None
    elif current is None or (current.latitude, current.longitude) != (values["latitude"], values["longitude"]):
        values["location_captured_at"] = now()
    values["_enquiry"] = enq
    return values


def create_visit(db: Session, p: Principal, data: SiteVisitIn) -> SiteVisit:
    values = _visit_values(db, p, data, None)
    enq = values.pop("_enquiry")
    v = SiteVisit(visit_number=numbering.next_number(db, p.company_id, "SV", on=data.visit_date), **values,
                  status="scheduled", created_by=p.id, updated_by=p.id)
    db.add(v)
    db.flush()
    audit.record(db, action="create", entity_type="site_visit", entity_id=v.id,
                 entity_label=f"{v.visit_number} {v.site_location}", after=audit.snapshot(v))
    _advance_enquiry(enq, "site_visit")
    _advance_lead(v.lead or (enq.lead if enq else None), "site_visit")
    return v


def update_visit(db: Session, p: Principal, visit_id: uuid.UUID, data: SiteVisitUpdate) -> SiteVisit:
    v = get_visit(db, visit_id, lock=True)
    check(p, "site_visit", v, "update")
    if v.status == "cancelled":
        raise AppError("VISIT_CANCELLED", "This visit was cancelled and can no longer be changed.")
    values = _visit_values(db, p, data, v)
    values.pop("_enquiry")
    before = audit.snapshot(v)
    check_row_version(v, values.pop("row_version"))
    for k, val in values.items():
        setattr(v, k, val)
    v.updated_by = p.id
    db.flush()
    audit.record(db, action="update", entity_type="site_visit", entity_id=v.id,
                 entity_label=f"{v.visit_number} {v.site_location}", before=before, after=audit.snapshot(v))
    return v


def complete_visit(db: Session, p: Principal, visit_id: uuid.UUID, row_version: int | None) -> SiteVisit:
    v = get_visit(db, visit_id, lock=True)
    check(p, "site_visit", v, "update")
    if v.status != "scheduled":
        raise AppError("VISIT_NOT_OPEN", f"This visit is already {v.status}.")
    if not any((v.observations, v.requirements, v.recommendations)) and not v.measurements:
        raise AppError("VISIT_EMPTY", "Record the observations, requirements or measurements before completing the visit.")
    if row_version is not None:
        check_row_version(v, row_version)
    else:
        v.row_version += 1
    v.status, v.completed_at, v.updated_by = "completed", now(), p.id
    db.flush()
    audit.record(db, action="status", entity_type="site_visit", entity_id=v.id, entity_label=v.visit_number,
                 summary="Visit completed")
    _advance_enquiry(v.enquiry, "evaluation")
    # A follow-up date on the report becomes a follow-up task for the salesperson (or the engineer).
    if v.follow_up_date and (v.enquiry or v.lead):
        owner = (v.enquiry.sales_person_id if v.enquiry else v.lead.sales_person_id) or v.engineer_id or p.id
        act = CrmActivity(
            enquiry_id=v.enquiry_id, lead_id=None if v.enquiry_id else v.lead_id, kind="follow_up",
            subject=f"Follow up after site visit {v.visit_number}", notes=v.recommendations,
            activity_at=now(), due_at=datetime.combine(v.follow_up_date, time(10, 0), IST),
            assigned_to_id=owner, created_by=p.id, updated_by=p.id)
        db.add(act)
        db.flush()
    return v


def cancel_visit(db: Session, p: Principal, visit_id: uuid.UUID, reason: str | None) -> SiteVisit:
    v = get_visit(db, visit_id, lock=True)
    check(p, "site_visit", v, "update")
    if v.status != "scheduled":
        raise AppError("VISIT_NOT_OPEN", f"This visit is already {v.status}.")
    v.status, v.updated_by = "cancelled", p.id
    v.row_version += 1
    db.flush()
    audit.record(db, action="status", entity_type="site_visit", entity_id=v.id, entity_label=v.visit_number,
                 summary="Visit cancelled" + (f": {reason}" if reason else ""))
    return v


def delete_visit(db: Session, p: Principal, visit_id: uuid.UUID) -> None:
    v = get_visit(db, visit_id, lock=True)
    check(p, "site_visit", v, "delete")
    if v.status == "completed":
        raise Conflict("IN_USE", "A completed visit is part of the customer's record and cannot be deleted.")
    snap, label = audit.snapshot(v), v.visit_number
    db.delete(v)
    db.flush()
    audit.record(db, action="delete", entity_type="site_visit", entity_id=visit_id, entity_label=label, before=snap)


# ------------------------------------------------------------------ activities & follow-ups
def _activity_parent(db: Session, lead_id: uuid.UUID | None, enquiry_id: uuid.UUID | None):
    if lead_id:
        return "lead", get_lead(db, lead_id)
    return "enquiry", get_enquiry(db, enquiry_id)


def list_activities(db: Session, p: Principal, lead_id: uuid.UUID | None, enquiry_id: uuid.UUID | None) -> list[CrmActivity]:
    if bool(lead_id) == bool(enquiry_id):
        raise AppError("PARENT_REQUIRED", "Give either lead_id or enquiry_id.")
    module, parent = _activity_parent(db, lead_id, enquiry_id)
    check(p, module, parent, "read")
    col = CrmActivity.lead_id if module == "lead" else CrmActivity.enquiry_id
    stmt = select(CrmActivity).where(col == parent.id)
    if module == "lead":  # a lead's timeline includes its enquiries' activities
        stmt = select(CrmActivity).where(or_(col == parent.id, CrmActivity.enquiry_id.in_(
            select(Enquiry.id).where(Enquiry.lead_id == parent.id))))
    return list(db.scalars(stmt.order_by(func.coalesce(CrmActivity.due_at, CrmActivity.activity_at).desc())))


def add_activity(db: Session, p: Principal, data: ActivityIn) -> CrmActivity:
    module, parent = _activity_parent(db, data.lead_id, data.enquiry_id)
    check(p, module, parent, "update")
    _active_user(db, data.assigned_to_id, "assignee")
    a = CrmActivity(**data.model_dump(exclude={"activity_at", "assigned_to_id"}),
                    activity_at=data.activity_at or now(),
                    assigned_to_id=data.assigned_to_id or (p.id if data.kind == "follow_up" else None),
                    created_by=p.id, updated_by=p.id)
    db.add(a)
    db.flush()
    label = parent.lead_number if module == "lead" else parent.enquiry_number
    audit.record(db, action="create", entity_type="crm_activity", entity_id=a.id, entity_label=f"{label} {a.subject}",
                 summary=f"{a.kind.replace('_', '-')} on {module} {label}")
    return a


def _get_activity(db: Session, activity_id: uuid.UUID) -> CrmActivity:
    return _get(db, CrmActivity, activity_id, "activity", lock=True)


def _can_touch_activity(db: Session, p: Principal, a: CrmActivity) -> None:
    if a.assigned_to_id == p.id or a.created_by == p.id:
        return
    module, parent = _activity_parent(db, a.lead_id, a.enquiry_id)
    check(p, module, parent, "update")


def complete_activity(db: Session, p: Principal, activity_id: uuid.UUID, outcome: str | None) -> CrmActivity:
    a = _get_activity(db, activity_id)
    _can_touch_activity(db, p, a)
    if a.kind != "follow_up":
        raise AppError("NOT_A_FOLLOW_UP", "Only follow-ups can be marked done.")
    if a.done_at is not None:
        raise AppError("ALREADY_DONE", "This follow-up is already done.")
    a.done_at, a.done_by, a.outcome, a.updated_by = now(), p.id, outcome, p.id
    a.row_version += 1
    db.flush()
    audit.record(db, action="complete", entity_type="crm_activity", entity_id=a.id, entity_label=a.subject,
                 summary="Follow-up done" + (f": {outcome}" if outcome else ""))
    return a


def delete_activity(db: Session, p: Principal, activity_id: uuid.UUID) -> None:
    a = _get_activity(db, activity_id)
    _can_touch_activity(db, p, a)
    label = a.subject
    db.delete(a)
    db.flush()
    audit.record(db, action="delete", entity_type="crm_activity", entity_id=activity_id, entity_label=label)


def list_follow_ups(db: Session, p: Principal, params: ListParams, *, mine: bool, bucket: str | None,
                    assigned_to_id: uuid.UUID | None):
    """Open follow-ups (or done ones, bucket='done'). 'mine' = assigned to me; otherwise every follow-up on the
    leads and enquiries the user can see."""
    if not (p.can("lead.read") or p.can("enquiry.read")):
        raise Forbidden()
    stmt = select(CrmActivity).where(CrmActivity.kind == "follow_up")
    if mine:
        stmt = stmt.where(CrmActivity.assigned_to_id == p.id)
    else:
        visible = []
        if p.can("lead.read"):
            lc = scope_clause(p, "lead", "read")
            visible.append(CrmActivity.lead_id.in_(select(Lead.id).where(lc) if lc is not None else select(Lead.id)))
        if p.can("enquiry.read"):
            ec = scope_clause(p, "enquiry", "read")
            visible.append(CrmActivity.enquiry_id.in_(
                select(Enquiry.id).where(ec) if ec is not None else select(Enquiry.id)))
        stmt = stmt.where(or_(*visible, CrmActivity.assigned_to_id == p.id))
        if assigned_to_id:
            stmt = stmt.where(CrmActivity.assigned_to_id == assigned_to_id)
    start = datetime.combine(today(), time.min, IST)
    end = start + timedelta(days=1)
    if bucket == "done":
        stmt = stmt.where(CrmActivity.done_at.is_not(None))
        default = CrmActivity.done_at.desc()
    else:
        stmt = stmt.where(CrmActivity.done_at.is_(None))
        default = CrmActivity.due_at.asc()
        if bucket == "overdue":
            stmt = stmt.where(CrmActivity.due_at < start)
        elif bucket == "today":
            stmt = stmt.where(and_(CrmActivity.due_at >= start, CrmActivity.due_at < end))
        elif bucket == "upcoming":
            stmt = stmt.where(CrmActivity.due_at >= end)
    return paginate(db, stmt, params, default_sort=default, sortable={"due_at": CrmActivity.due_at})


# ------------------------------------------------------------------ dashboard
def summary(db: Session, p: Principal) -> dict:
    out: dict[str, Any] = {}
    if p.can("lead.read"):
        stmt = select(Lead.status, func.count(), func.coalesce(func.sum(Lead.estimated_value), 0)).group_by(Lead.status)
        if (c := scope_clause(p, "lead", "read")) is not None:
            stmt = stmt.where(c)
        rows = {s: (n, v) for s, n, v in db.execute(stmt).all()}
        out["leads_by_status"] = [{"status": s, "count": rows.get(s, (0, 0))[0], "value": str(rows.get(s, (0, 0))[1])}
                                  for s in LEAD_STATUSES]
    if p.can("enquiry.read"):
        stmt = select(func.count()).select_from(Enquiry).where(Enquiry.status.not_in(CLOSED_ENQUIRY))
        if (c := scope_clause(p, "enquiry", "read")) is not None:
            stmt = stmt.where(c)
        out["open_enquiries"] = db.scalar(stmt)
    if p.can("site_visit.read"):
        stmt = select(func.count()).select_from(SiteVisit).where(
            SiteVisit.status == "scheduled", SiteVisit.visit_date <= today() + timedelta(days=7))
        if (c := scope_clause(p, "site_visit", "read")) is not None:
            stmt = stmt.where(c)
        out["visits_next_7_days"] = db.scalar(stmt)
    if p.can("lead.read") or p.can("enquiry.read"):
        start = datetime.combine(today(), time.min, IST)
        base = select(func.count()).select_from(CrmActivity).where(
            CrmActivity.kind == "follow_up", CrmActivity.done_at.is_(None), CrmActivity.assigned_to_id == p.id)
        out["my_follow_ups_overdue"] = db.scalar(base.where(CrmActivity.due_at < start))
        out["my_follow_ups_today"] = db.scalar(base.where(CrmActivity.due_at >= start,
                                                          CrmActivity.due_at < start + timedelta(days=1)))
    return out
