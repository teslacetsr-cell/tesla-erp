import uuid
from datetime import date, datetime, time
from decimal import Decimal
from typing import Literal

from pydantic import EmailStr, Field, field_validator, model_validator

from app.core.api import Schema
from app.core.validators import GSTIN, Phone, Pincode, StateCode, Text, check_tax_identity
from app.crm.models import ACTIVITY_KINDS, ENQUIRY_STATUSES, LEAD_SOURCES, LEAD_STATUSES, PRIORITIES

LeadSource = Literal[LEAD_SOURCES]  # type: ignore[valid-type]
LeadStatus = Literal[LEAD_STATUSES]  # type: ignore[valid-type]
EnquiryStatus = Literal[ENQUIRY_STATUSES]  # type: ignore[valid-type]
Priority = Literal[PRIORITIES]  # type: ignore[valid-type]
ActivityKind = Literal[ACTIVITY_KINDS]  # type: ignore[valid-type]

Amount = Field(default=None, ge=0, max_digits=18, decimal_places=2)


# ------------------------------------------------------------------ leads
class LeadIn(Schema):
    title: str = Field(min_length=3, max_length=200, description="Short summary of what the customer wants")
    customer_id: uuid.UUID | None = None
    company_name: Text(200) = None
    contact_name: Text(150) = None
    contact_phone: Phone = None
    contact_email: EmailStr | None = None
    city: Text(100) = None
    source: LeadSource = "phone"
    division_id: uuid.UUID | None = None
    requirement: Text(4000) = None
    estimated_value: Decimal | None = Amount
    probability: int | None = Field(default=None, ge=0, le=100)
    expected_closing_date: date | None = None
    sales_person_id: uuid.UUID | None = None
    notes: Text(4000) = None
    # New-customer details that go only to the customer record made from the lead (not stored on the lead).
    gstin: GSTIN = None
    address_line1: Text(200) = None
    state: Text(100) = None
    state_code: StateCode = None
    pincode: Pincode = None

    @model_validator(mode="after")
    def _party(self):
        if not (self.customer_id or self.company_name or self.contact_name):
            raise ValueError("Choose an existing customer, or enter a company or contact name for the prospect.")
        if not self.customer_id and not (self.contact_phone or self.contact_email):
            raise ValueError("Enter a phone number or email so the prospect can be contacted.")
        if not self.customer_id:
            for k, v in check_tax_identity(self.gstin, None, self.state_code).items():
                if k != "pan":
                    setattr(self, k, v)
        return self


# LeadIn fields that describe the new customer only (they are written to the customer, not the lead row).
CUSTOMER_ONLY_FIELDS = {"gstin", "address_line1", "state", "state_code", "pincode"}


class LeadUpdate(LeadIn):
    row_version: int


class StatusIn(Schema):
    status: str
    lost_reason: Text(300) = None
    row_version: int | None = None


class ConvertIn(Schema):
    """Lead → enquiry. The customer is the lead's own, or `customer_id`, or a new one made from the prospect."""

    customer_id: uuid.UUID | None = None
    allow_duplicate: bool = False
    subject: Text(200) = None
    description: Text(4000) = None
    site_id: uuid.UUID | None = None
    required_by: date | None = None
    priority: Priority = "normal"


# ------------------------------------------------------------------ enquiries
class EnquiryIn(Schema):
    customer_id: uuid.UUID
    lead_id: uuid.UUID | None = None
    site_id: uuid.UUID | None = None
    contact_id: uuid.UUID | None = None
    division_id: uuid.UUID | None = None
    subject: str = Field(min_length=3, max_length=200)
    description: Text(4000) = None
    enquiry_date: date | None = None
    required_by: date | None = None
    source: LeadSource | None = None
    priority: Priority = "normal"
    estimated_value: Decimal | None = Amount
    sales_person_id: uuid.UUID | None = None


class EnquiryUpdate(EnquiryIn):
    row_version: int


# ------------------------------------------------------------------ site visits
class Measurement(Schema):
    label: str = Field(min_length=1, max_length=100)
    value: str = Field(min_length=1, max_length=50)
    unit: Text(20) = None


class SiteVisitIn(Schema):
    enquiry_id: uuid.UUID | None = None
    customer_id: uuid.UUID | None = None
    site_id: uuid.UUID | None = None
    site_location: Text(300) = None
    visit_date: date
    visit_time: time | None = None
    engineer_id: uuid.UUID | None = None
    purpose: Text(300) = None
    observations: Text(8000) = None
    requirements: Text(8000) = None
    measurements: list[Measurement] = Field(default_factory=list, max_length=100)
    recommendations: Text(8000) = None
    customer_rep_name: Text(150) = None
    customer_rep_designation: Text(100) = None
    customer_rep_phone: Phone = None
    follow_up_date: date | None = None
    latitude: Decimal | None = Field(default=None, ge=-90, le=90, max_digits=9, decimal_places=6)
    longitude: Decimal | None = Field(default=None, ge=-180, le=180, max_digits=9, decimal_places=6)
    location_accuracy_m: int | None = Field(default=None, ge=0, le=100000)

    @field_validator("latitude", "longitude", mode="before")
    @classmethod
    def _six_places(cls, v):
        # Phones report 15+ decimals; 6 places is ~10 cm, far finer than GPS accuracy.
        if v is None or v == "":
            return None
        return round(Decimal(str(v)), 6)

    @model_validator(mode="after")
    def _where(self):
        if not self.enquiry_id and not self.customer_id:
            raise ValueError("Choose the enquiry (or the customer) this visit is for.")
        if (self.latitude is None) != (self.longitude is None):
            raise ValueError("Latitude and longitude must be given together.")
        return self


class SiteVisitUpdate(SiteVisitIn):
    row_version: int


class CompleteIn(Schema):
    row_version: int | None = None


# ------------------------------------------------------------------ activities / follow-ups
class ActivityIn(Schema):
    lead_id: uuid.UUID | None = None
    enquiry_id: uuid.UUID | None = None
    kind: ActivityKind
    subject: str = Field(min_length=2, max_length=200)
    notes: Text(4000) = None
    activity_at: datetime | None = None
    due_at: datetime | None = None
    assigned_to_id: uuid.UUID | None = None

    @model_validator(mode="after")
    def _check(self):
        if bool(self.lead_id) == bool(self.enquiry_id):
            raise ValueError("An activity belongs to exactly one lead or one enquiry.")
        if self.kind == "follow_up" and self.due_at is None:
            raise ValueError("A follow-up needs a due date and time.")
        return self


class ActivityDoneIn(Schema):
    outcome: Text(300) = None
