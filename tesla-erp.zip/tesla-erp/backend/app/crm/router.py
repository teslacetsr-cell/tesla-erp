"""CRM API: /leads, /enquiries, /site-visits, /crm/activities, /crm/follow-ups, /crm/summary, /crm/people."""
import uuid
from datetime import date
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.orm import object_session

from app.auth.deps import CurrentUser, Principal, require
from app.company.models import BusinessDivision
from app.core import excel
from app.core.api import ListParams, ok
from app.core.db import DbSession
from app.core.errors import Forbidden
from app.core.money import round_amount
from app.crm import pdf, service
from app.crm.models import ENQUIRY_STATUSES, LEAD_SOURCES, LEAD_STATUSES, CrmActivity, Enquiry, Lead, SiteVisit
from app.crm.schemas import (
    ActivityDoneIn,
    ActivityIn,
    CompleteIn,
    ConvertIn,
    EnquiryIn,
    EnquiryUpdate,
    LeadIn,
    LeadUpdate,
    SiteVisitIn,
    SiteVisitUpdate,
    StatusIn,
)
from app.customers.models import Customer, CustomerContact, CustomerSite
from app.platform.audit import service as audit
from app.platform.documents import service as documents
from app.platform.settings import service as settings
from app.users.models import Role, User, UserRole

router = APIRouter(tags=["crm"])
for _entity, _model in (("lead", Lead), ("enquiry", Enquiry), ("site_visit", SiteVisit)):
    documents.register_entity(_entity, _entity, _model, check=lambda p, obj, action, m=_entity: service.check(
        p, m, obj, "read" if action == "read" else "update"))


# ------------------------------------------------------------------ output helpers
class Names:
    """Batch-loads display names for the ids referenced by a page of records (one query per table)."""

    def __init__(self, db, rows: list[Any]):
        def ids(*attrs):
            return {getattr(r, a) for r in rows for a in attrs if getattr(r, a, None)}

        self.users = dict(db.execute(select(User.id, User.full_name).where(User.id.in_(
            ids("sales_person_id", "engineer_id", "assigned_to_id", "created_by", "done_by")))).all()) if rows else {}
        self.customers = {c.id: c for c in db.scalars(select(Customer).where(Customer.id.in_(ids("customer_id"))))} \
            if rows else {}
        self.divisions = dict(db.execute(select(BusinessDivision.id, BusinessDivision.name).where(
            BusinessDivision.id.in_(ids("division_id")))).all()) if rows else {}
        self.sites = dict(db.execute(select(CustomerSite.id, CustomerSite.site_name).where(
            CustomerSite.id.in_(ids("site_id")))).all()) if rows else {}

    def customer(self, cid) -> dict | None:
        c = self.customers.get(cid)
        return {"id": str(c.id), "name": c.customer_name, "code": c.customer_code, "city": c.city,
                "is_prospect": c.is_prospect, "gstin": c.gstin, "address_line1": c.address_line1, "state": c.state,
                "state_code": c.state_code, "pincode": c.pincode} if c else None


def _s(v) -> str | None:
    return str(v) if v is not None else None


def _money(v) -> str | None:
    return str(round_amount(v)) if v is not None else None


def lead_out(p: Principal, lead: Lead, n: Names, detail: bool = False) -> dict:
    out = {
        "id": str(lead.id), "lead_number": lead.lead_number, "title": lead.title,
        "customer_id": _s(lead.customer_id), "customer": n.customer(lead.customer_id),
        "company_name": lead.company_name, "contact_name": lead.contact_name, "contact_phone": lead.contact_phone,
        "contact_email": lead.contact_email, "city": lead.city, "source": lead.source,
        "division_id": _s(lead.division_id), "division": n.divisions.get(lead.division_id),
        "estimated_value": _money(lead.estimated_value), "probability": lead.probability,
        "expected_closing_date": _s(lead.expected_closing_date),
        "sales_person_id": _s(lead.sales_person_id), "sales_person": n.users.get(lead.sales_person_id),
        "status": lead.status, "lost_reason": lead.lost_reason, "status_changed_at": _s(lead.status_changed_at),
        "created_at": lead.created_at.isoformat(), "row_version": lead.row_version,
    }
    if detail:
        out |= {"requirement": lead.requirement, "notes": lead.notes, "updated_at": lead.updated_at.isoformat(),
                "created_by": n.users.get(lead.created_by),
                "can_edit": service.allowed(p, "lead", lead, "update"),
                "can_delete": service.allowed(p, "lead", lead, "delete")}
    return out


def enquiry_out(p: Principal, e: Enquiry, n: Names, detail: bool = False) -> dict:
    out = {
        "id": str(e.id), "enquiry_number": e.enquiry_number, "subject": e.subject,
        "customer_id": str(e.customer_id), "customer": n.customer(e.customer_id),
        "lead_id": _s(e.lead_id), "lead_number": e.lead.lead_number if e.lead else None,
        "site_id": _s(e.site_id), "site": n.sites.get(e.site_id), "contact_id": _s(e.contact_id),
        "division_id": _s(e.division_id), "division": n.divisions.get(e.division_id),
        "enquiry_date": e.enquiry_date.isoformat(), "required_by": _s(e.required_by), "source": e.source,
        "priority": e.priority, "estimated_value": _money(e.estimated_value),
        "sales_person_id": _s(e.sales_person_id), "sales_person": n.users.get(e.sales_person_id),
        "status": e.status, "lost_reason": e.lost_reason, "created_at": e.created_at.isoformat(),
        "row_version": e.row_version,
    }
    if detail:
        c = object_session(e).get(CustomerContact, e.contact_id) if e.contact_id else None
        out |= {"description": e.description, "updated_at": e.updated_at.isoformat(),
                "created_by": n.users.get(e.created_by),
                "contact": {"name": c.name, "phone": c.phone, "email": c.email, "designation": c.designation}
                if c else None,
                "can_edit": service.allowed(p, "enquiry", e, "update"),
                "can_delete": service.allowed(p, "enquiry", e, "delete")}
    return out


def visit_out(p: Principal, v: SiteVisit, n: Names, detail: bool = False) -> dict:
    out = {
        "id": str(v.id), "visit_number": v.visit_number, "status": v.status,
        "customer_id": str(v.customer_id), "customer": n.customer(v.customer_id),
        "enquiry_id": _s(v.enquiry_id), "enquiry_number": v.enquiry.enquiry_number if v.enquiry else None,
        "lead_id": _s(v.lead_id), "lead_number": v.lead.lead_number if v.lead else None,
        "site_id": _s(v.site_id), "site": n.sites.get(v.site_id), "site_location": v.site_location,
        "visit_date": v.visit_date.isoformat(), "visit_time": v.visit_time.strftime("%H:%M") if v.visit_time else None,
        "engineer_id": _s(v.engineer_id), "engineer": n.users.get(v.engineer_id), "purpose": v.purpose,
        "follow_up_date": _s(v.follow_up_date), "completed_at": _s(v.completed_at), "row_version": v.row_version,
    }
    if detail:
        out |= {
            "observations": v.observations, "requirements": v.requirements, "measurements": v.measurements,
            "recommendations": v.recommendations, "customer_rep_name": v.customer_rep_name,
            "customer_rep_designation": v.customer_rep_designation, "customer_rep_phone": v.customer_rep_phone,
            "latitude": _s(v.latitude), "longitude": _s(v.longitude), "location_accuracy_m": v.location_accuracy_m,
            "location_captured_at": _s(v.location_captured_at), "created_at": v.created_at.isoformat(),
            "updated_at": v.updated_at.isoformat(), "created_by": n.users.get(v.created_by),
            "can_edit": v.status != "cancelled" and service.allowed(p, "site_visit", v, "update"),
            "can_delete": v.status != "completed" and service.allowed(p, "site_visit", v, "delete"),
            "can_print": service.allowed(p, "site_visit", v, "print"),
        }
    return out


def activity_out(a: CrmActivity, n: Names, parents: dict | None = None) -> dict:
    out = {
        "id": str(a.id), "kind": a.kind, "subject": a.subject, "notes": a.notes,
        "lead_id": _s(a.lead_id), "enquiry_id": _s(a.enquiry_id), "activity_at": a.activity_at.isoformat(),
        "due_at": _s(a.due_at), "assigned_to_id": _s(a.assigned_to_id), "assigned_to": n.users.get(a.assigned_to_id),
        "done_at": _s(a.done_at), "done_by": n.users.get(a.done_by), "outcome": a.outcome,
        "created_by": n.users.get(a.created_by), "created_by_id": _s(a.created_by),
    }
    if parents is not None:
        out["parent"] = parents.get(a.lead_id or a.enquiry_id)
    return out


# ------------------------------------------------------------------ leads
LEAD_COLUMNS = [
    excel.Column("lead_number", "Lead no.", 20), excel.Column("title", "Title", 36),
    excel.Column("customer_code", "Customer code", 12), excel.Column("customer", "Customer", 28),
    excel.Column("company_name", "Prospect company", 26),
    excel.Column("contact_name", "Contact", 20), excel.Column("contact_phone", "Phone", 16),
    excel.Column("city", "City", 14), excel.Column("source", "Source", 14), excel.Column("division", "Division", 22),
    excel.Column("estimated_value", "Estimated value (₹)", 16), excel.Column("probability", "Probability %", 12),
    excel.Column("expected_closing_date", "Expected closing", 14), excel.Column("sales_person", "Salesperson", 20),
    excel.Column("status", "Status", 12), excel.Column("lost_reason", "Lost reason", 28),
    excel.Column("created_at", "Created", 18),
]


def _lead_filters(status: str | None = Query(None), sales_person_id: uuid.UUID | None = None,
                  source: str | None = Query(None), customer_id: uuid.UUID | None = None, open_only: bool = False):
    return {"status": status, "sales_person_id": sales_person_id, "source": source, "customer_id": customer_id,
            "open_only": open_only}


@router.get("/leads")
def list_leads(db: DbSession, p: Annotated[Principal, require("lead.read")],
               params: Annotated[ListParams, Depends()], f: Annotated[dict, Depends(_lead_filters)]):
    rows, meta = service.list_leads(db, p, params, **f)
    n = Names(db, rows)
    return {"data": [lead_out(p, r, n) for r in rows], "meta": meta.model_dump()}


@router.get("/leads/export")
def export_leads(db: DbSession, p: Annotated[Principal, require("lead.read", "lead.export")],
                 params: Annotated[ListParams, Depends()], f: Annotated[dict, Depends(_lead_filters)]):
    params.page, params.page_size = 1, 100000
    rows, _ = service.list_leads(db, p, params, **f)
    n = Names(db, rows)
    data = []
    for r in rows:
        d = lead_out(p, r, n)
        d["customer_code"] = d["customer"]["code"] if d["customer"] else None
        d["customer"] = d["customer"]["name"] if d["customer"] else None
        data.append(d)
    audit.record(db, action="export", entity_type="lead", summary=f"Exported {len(data)} leads")
    return Response(excel.export("Leads", LEAD_COLUMNS, data), media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="leads.xlsx"'})


@router.post("/leads", status_code=201)
def create_lead(body: LeadIn, db: DbSession, p: Annotated[Principal, require("lead.create")],
                allow_duplicate: bool = Query(False)):
    """New customer details create the customer at once (next customer code). Same GSTIN → linked to the existing
    customer; a look-alike customer → 409 POSSIBLE_DUPLICATE_CUSTOMER (pick it, or resend with allow_duplicate)."""
    lead, action = service.create_lead(db, p, body, allow_duplicate=allow_duplicate)
    return ok(lead_out(p, lead, Names(db, [lead]), detail=True) | {"customer_action": action})


@router.get("/leads/{lead_id}")
def get_lead(lead_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("lead.read")]):
    lead = service.get_lead(db, lead_id)
    service.check(p, "lead", lead, "read")
    return ok(lead_out(p, lead, Names(db, [lead]), detail=True))


@router.put("/leads/{lead_id}")
def update_lead(lead_id: uuid.UUID, body: LeadUpdate, db: DbSession, p: Annotated[Principal, require("lead.update")],
                allow_duplicate: bool = Query(False)):
    lead, action = service.update_lead(db, p, lead_id, body, allow_duplicate=allow_duplicate)
    return ok(lead_out(p, lead, Names(db, [lead]), detail=True) | {"customer_action": action})


@router.post("/leads/{lead_id}/status")
def lead_status(lead_id: uuid.UUID, body: StatusIn, db: DbSession, p: Annotated[Principal, require("lead.update")]):
    lead = service.set_lead_status(db, p, lead_id, body)
    return ok(lead_out(p, lead, Names(db, [lead]), detail=True))


@router.post("/leads/{lead_id}/convert", status_code=201)
def convert_lead(lead_id: uuid.UUID, body: ConvertIn, db: DbSession,
                 p: Annotated[Principal, require("lead.update", "enquiry.create")]):
    enq = service.convert_lead(db, p, lead_id, body)
    return ok(enquiry_out(p, enq, Names(db, [enq]), detail=True))


@router.delete("/leads/{lead_id}")
def delete_lead(lead_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("lead.delete")]):
    service.delete_lead(db, p, lead_id)
    return ok({"ok": True})


# ------------------------------------------------------------------ enquiries
ENQUIRY_COLUMNS = [
    excel.Column("enquiry_number", "Enquiry no.", 20), excel.Column("enquiry_date", "Date", 12),
    excel.Column("subject", "Subject", 36), excel.Column("customer", "Customer", 28), excel.Column("site", "Site", 22),
    excel.Column("lead_number", "Lead no.", 20), excel.Column("division", "Division", 22),
    excel.Column("priority", "Priority", 10), excel.Column("required_by", "Required by", 12),
    excel.Column("estimated_value", "Estimated value (₹)", 16), excel.Column("sales_person", "Salesperson", 20),
    excel.Column("status", "Status", 12), excel.Column("lost_reason", "Lost reason", 28),
]


def _enquiry_filters(status: str | None = Query(None), sales_person_id: uuid.UUID | None = None,
                     customer_id: uuid.UUID | None = None, lead_id: uuid.UUID | None = None, open_only: bool = False):
    return {"status": status, "sales_person_id": sales_person_id, "customer_id": customer_id, "lead_id": lead_id,
            "open_only": open_only}


@router.get("/enquiries")
def list_enquiries(db: DbSession, p: Annotated[Principal, require("enquiry.read")],
                   params: Annotated[ListParams, Depends()], f: Annotated[dict, Depends(_enquiry_filters)]):
    rows, meta = service.list_enquiries(db, p, params, **f)
    n = Names(db, rows)
    return {"data": [enquiry_out(p, r, n) for r in rows], "meta": meta.model_dump()}


@router.get("/enquiries/export")
def export_enquiries(db: DbSession, p: Annotated[Principal, require("enquiry.read", "enquiry.export")],
                     params: Annotated[ListParams, Depends()], f: Annotated[dict, Depends(_enquiry_filters)]):
    params.page, params.page_size = 1, 100000
    rows, _ = service.list_enquiries(db, p, params, **f)
    n = Names(db, rows)
    data = []
    for r in rows:
        d = enquiry_out(p, r, n)
        d["customer"] = d["customer"]["name"] if d["customer"] else None
        data.append(d)
    audit.record(db, action="export", entity_type="enquiry", summary=f"Exported {len(data)} enquiries")
    return Response(excel.export("Enquiries", ENQUIRY_COLUMNS, data), media_type=excel.XLSX,
                    headers={"Content-Disposition": 'attachment; filename="enquiries.xlsx"'})


@router.post("/enquiries", status_code=201)
def create_enquiry(body: EnquiryIn, db: DbSession, p: Annotated[Principal, require("enquiry.create")]):
    e = service.create_enquiry(db, p, body)
    return ok(enquiry_out(p, e, Names(db, [e]), detail=True))


@router.get("/enquiries/{enquiry_id}")
def get_enquiry(enquiry_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("enquiry.read")]):
    e = service.get_enquiry(db, enquiry_id)
    service.check(p, "enquiry", e, "read")
    return ok(enquiry_out(p, e, Names(db, [e]), detail=True))


@router.put("/enquiries/{enquiry_id}")
def update_enquiry(enquiry_id: uuid.UUID, body: EnquiryUpdate, db: DbSession,
                   p: Annotated[Principal, require("enquiry.update")]):
    e = service.update_enquiry(db, p, enquiry_id, body)
    return ok(enquiry_out(p, e, Names(db, [e]), detail=True))


@router.post("/enquiries/{enquiry_id}/status")
def enquiry_status(enquiry_id: uuid.UUID, body: StatusIn, db: DbSession,
                   p: Annotated[Principal, require("enquiry.update")]):
    e = service.set_enquiry_status(db, p, enquiry_id, body)
    return ok(enquiry_out(p, e, Names(db, [e]), detail=True))


@router.delete("/enquiries/{enquiry_id}")
def delete_enquiry(enquiry_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("enquiry.delete")]):
    service.delete_enquiry(db, p, enquiry_id)
    return ok({"ok": True})


# ------------------------------------------------------------------ site visits
@router.get("/site-visits")
def list_visits(db: DbSession, p: Annotated[Principal, require("site_visit.read")],
                params: Annotated[ListParams, Depends()], status: str | None = Query(None),
                engineer_id: uuid.UUID | None = None, customer_id: uuid.UUID | None = None,
                enquiry_id: uuid.UUID | None = None, date_from: date | None = None, date_to: date | None = None):
    rows, meta = service.list_visits(db, p, params, status=status, engineer_id=engineer_id, customer_id=customer_id,
                                     enquiry_id=enquiry_id, date_from=date_from, date_to=date_to)
    n = Names(db, rows)
    return {"data": [visit_out(p, r, n) for r in rows], "meta": meta.model_dump()}


@router.post("/site-visits", status_code=201)
def create_visit(body: SiteVisitIn, db: DbSession, p: Annotated[Principal, require("site_visit.create")]):
    v = service.create_visit(db, p, body)
    return ok(visit_out(p, v, Names(db, [v]), detail=True))


@router.get("/site-visits/{visit_id}")
def get_visit(visit_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("site_visit.read")]):
    v = service.get_visit(db, visit_id)
    service.check(p, "site_visit", v, "read")
    return ok(visit_out(p, v, Names(db, [v]), detail=True))


@router.put("/site-visits/{visit_id}")
def update_visit(visit_id: uuid.UUID, body: SiteVisitUpdate, db: DbSession,
                 p: Annotated[Principal, require("site_visit.update")]):
    v = service.update_visit(db, p, visit_id, body)
    return ok(visit_out(p, v, Names(db, [v]), detail=True))


@router.post("/site-visits/{visit_id}/complete")
def complete_visit(visit_id: uuid.UUID, body: CompleteIn, db: DbSession,
                   p: Annotated[Principal, require("site_visit.update")]):
    v = service.complete_visit(db, p, visit_id, body.row_version)
    return ok(visit_out(p, v, Names(db, [v]), detail=True))


@router.post("/site-visits/{visit_id}/cancel")
def cancel_visit(visit_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("site_visit.update")],
                 reason: str | None = Query(None, max_length=300)):
    v = service.cancel_visit(db, p, visit_id, reason)
    return ok(visit_out(p, v, Names(db, [v]), detail=True))


@router.delete("/site-visits/{visit_id}")
def delete_visit(visit_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("site_visit.delete")]):
    service.delete_visit(db, p, visit_id)
    return ok({"ok": True})


@router.post("/site-visits/{visit_id}/report", status_code=201)
def generate_report(visit_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("site_visit.print")]):
    """Builds the Site Visit Report PDF and files it on the visit (each run is a new version of the same report)."""
    v = service.get_visit(db, visit_id)
    service.check(p, "site_visit", v, "print")
    data = pdf.build(db, v)
    name = f"Site-visit-report-{v.visit_number.replace('/', '-')}.pdf"
    prev = next((d for d in documents.list_for(db, "site_visit", v.id) if d.category == "report"), None)
    doc = documents.upload(db, entity_type="site_visit", entity_id=v.id, category="report", file_name=name,
                           data=data, user_id=p.id, title=f"Site visit report {v.visit_number}",
                           replaces=prev.id if prev else None)
    audit.record(db, action="print", entity_type="site_visit", entity_id=v.id, entity_label=v.visit_number,
                 summary=f"Generated site visit report (v{doc.version})")
    return ok({"id": str(doc.id), "file_name": doc.file_name, "version": doc.version, "size_bytes": doc.size_bytes})


# ------------------------------------------------------------------ activities & follow-ups
@router.get("/crm/activities")
def list_activities(db: DbSession, p: CurrentUser, lead_id: uuid.UUID | None = None,
                    enquiry_id: uuid.UUID | None = None):
    rows = service.list_activities(db, p, lead_id, enquiry_id)
    n = Names(db, rows)
    return ok([activity_out(a, n) for a in rows])


@router.post("/crm/activities", status_code=201)
def add_activity(body: ActivityIn, db: DbSession, p: CurrentUser):
    a = service.add_activity(db, p, body)
    return ok(activity_out(a, Names(db, [a])))


@router.post("/crm/activities/{activity_id}/done")
def activity_done(activity_id: uuid.UUID, body: ActivityDoneIn, db: DbSession, p: CurrentUser):
    a = service.complete_activity(db, p, activity_id, body.outcome)
    return ok(activity_out(a, Names(db, [a])))


@router.delete("/crm/activities/{activity_id}")
def delete_activity(activity_id: uuid.UUID, db: DbSession, p: CurrentUser):
    service.delete_activity(db, p, activity_id)
    return ok({"ok": True})


@router.get("/crm/follow-ups")
def follow_ups(db: DbSession, p: CurrentUser, params: Annotated[ListParams, Depends()], mine: bool = True,
               bucket: str | None = Query(None, pattern="^(overdue|today|upcoming|done)$"),
               assigned_to_id: uuid.UUID | None = None):
    rows, meta = service.list_follow_ups(db, p, params, mine=mine, bucket=bucket, assigned_to_id=assigned_to_id)
    n = Names(db, rows)
    parents: dict = {}
    lead_ids = {a.lead_id for a in rows if a.lead_id}
    enq_ids = {a.enquiry_id for a in rows if a.enquiry_id}
    for lead in db.scalars(select(Lead).where(Lead.id.in_(lead_ids))) if lead_ids else []:
        parents[lead.id] = {"type": "lead", "number": lead.lead_number, "title": lead.title,
                            "party": lead.company_name or lead.contact_name, "href": f"/crm/leads/view?id={lead.id}"}
    for e in db.scalars(select(Enquiry).where(Enquiry.id.in_(enq_ids))) if enq_ids else []:
        parents[e.id] = {"type": "enquiry", "number": e.enquiry_number, "title": e.subject,
                         "href": f"/crm/enquiries/view?id={e.id}"}
    custs = dict(db.execute(select(Enquiry.id, Customer.customer_name).join(Customer, Customer.id == Enquiry.customer_id)
                            .where(Enquiry.id.in_(enq_ids))).all()) if enq_ids else {}
    for eid, name in custs.items():
        parents[eid]["party"] = name
    return {"data": [activity_out(a, n, parents) for a in rows], "meta": meta.model_dump()}


# ------------------------------------------------------------------ dashboard, pickers, options
@router.get("/crm/summary")
def crm_summary(db: DbSession, p: CurrentUser):
    return ok(service.summary(db, p))


PEOPLE = {"sales": ("SALES", "MANAGER", "DIRECTOR"), "engineer": ("SITE_ENGINEER", "PROJECT_MANAGER", "MANAGER")}


@router.get("/crm/people")
def crm_people(db: DbSession, p: CurrentUser, kind: str = Query(pattern="^(sales|engineer|any)$")):
    """Active users for the salesperson / engineer / assignee pickers."""
    if not any(p.can(c) for c in ("lead.read", "enquiry.read", "site_visit.read", "project.create", "project.update",
                                  "site_work.create")):
        raise Forbidden()
    stmt = select(User.id, User.full_name).where(User.is_active.is_(True))
    if kind != "any":
        stmt = stmt.join(UserRole, UserRole.user_id == User.id).join(Role, Role.id == UserRole.role_id) \
            .where(Role.code.in_(PEOPLE[kind]))
    rows = db.execute(stmt.distinct().order_by(User.full_name)).all()
    return ok([{"id": str(i), "name": nm} for i, nm in rows])


@router.get("/crm/options")
def crm_options(db: DbSession, p: CurrentUser):
    return ok({"lead_statuses": LEAD_STATUSES, "lead_sources": LEAD_SOURCES, "enquiry_statuses": ENQUIRY_STATUSES,
               "gps_enabled": bool(settings.get_setting(db, p.company_id, "crm.site_visit_gps"))})
