"""CRM (Spec §11, §12): leads → enquiries → site visits, with activities and follow-ups.

A *lead* may start as a prospect that is not yet a customer (name/phone only). Converting it to an enquiry
links it to exactly one customer record, so customer data is never duplicated. Enquiries and site visits
always belong to a customer. The pipeline value, probability and expected closing date live on the lead,
which is how "opportunities" are tracked in this ERP.
"""
import uuid
from datetime import date, datetime, time
from decimal import Decimal

from sqlalchemy import CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, Numeric, SmallInteger, String, Text, Time
from sqlalchemy.dialects.postgresql import CITEXT, JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.models import AuditColumnsMixin, Base
from app.core.money import AMOUNT

LEAD_STATUSES = ("new", "contacted", "qualified", "site_visit", "quotation", "negotiation", "won", "lost")
LEAD_SOURCES = ("phone", "email", "whatsapp", "website", "walk_in", "referral", "existing_customer", "exhibition",
                "social_media", "tender", "other")
ENQUIRY_STATUSES = ("open", "site_visit", "evaluation", "quoted", "won", "lost", "cancelled")
PRIORITIES = ("low", "normal", "high", "urgent")
VISIT_STATUSES = ("scheduled", "completed", "cancelled")
ACTIVITY_KINDS = ("call", "meeting", "email", "whatsapp", "note", "follow_up")

CLOSED_LEAD = ("won", "lost")
CLOSED_ENQUIRY = ("won", "lost", "cancelled")


def _in(col: str, values: tuple[str, ...]) -> str:
    return f"{col} in ({', '.join(repr(v) for v in values)})"


class Lead(AuditColumnsMixin, Base):
    __tablename__ = "leads"
    __table_args__ = (
        CheckConstraint(_in("status", LEAD_STATUSES), name="status_valid"),
        CheckConstraint(_in("source", LEAD_SOURCES), name="source_valid"),
        CheckConstraint("probability is null or probability between 0 and 100", name="probability_range"),
        CheckConstraint("estimated_value is null or estimated_value >= 0", name="value_nonneg"),
        CheckConstraint("customer_id is not null or company_name is not null or contact_name is not null",
                        name="has_party"),
        Index("ix_leads_status", "status"),
        Index("ix_leads_sales_person_id", "sales_person_id"),
        Index("ix_leads_customer_id", "customer_id"),
    )

    lead_number: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    customer_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("customers.id", ondelete="RESTRICT"))
    # Prospect details — used until the lead is linked to a customer.
    company_name: Mapped[str | None] = mapped_column(String(200))
    contact_name: Mapped[str | None] = mapped_column(String(150))
    contact_phone: Mapped[str | None] = mapped_column(String(30))
    contact_email: Mapped[str | None] = mapped_column(CITEXT)
    city: Mapped[str | None] = mapped_column(String(100))
    source: Mapped[str] = mapped_column(String(20), nullable=False, default="phone")
    division_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("business_divisions.id", ondelete="RESTRICT"))
    requirement: Mapped[str | None] = mapped_column(Text)
    estimated_value: Mapped[Decimal | None] = mapped_column(AMOUNT)
    probability: Mapped[int | None] = mapped_column(SmallInteger)
    expected_closing_date: Mapped[date | None] = mapped_column(Date)
    sales_person_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="new", server_default="new")
    status_changed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    lost_reason: Mapped[str | None] = mapped_column(String(300))
    notes: Mapped[str | None] = mapped_column(Text)


class Enquiry(AuditColumnsMixin, Base):
    __tablename__ = "enquiries"
    __table_args__ = (
        CheckConstraint(_in("status", ENQUIRY_STATUSES), name="status_valid"),
        CheckConstraint(_in("priority", PRIORITIES), name="priority_valid"),
        CheckConstraint("source is null or " + _in("source", LEAD_SOURCES), name="source_valid"),
        CheckConstraint("estimated_value is null or estimated_value >= 0", name="value_nonneg"),
        Index("ix_enquiries_status", "status"),
        Index("ix_enquiries_customer_id", "customer_id"),
        Index("ix_enquiries_lead_id", "lead_id"),
        Index("ix_enquiries_sales_person_id", "sales_person_id"),
    )

    enquiry_number: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    lead_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("leads.id", ondelete="RESTRICT"))
    customer_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("customers.id", ondelete="RESTRICT"), nullable=False)
    site_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("customer_sites.id", ondelete="RESTRICT"))
    contact_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("customer_contacts.id", ondelete="SET NULL"))
    division_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("business_divisions.id", ondelete="RESTRICT"))
    subject: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    enquiry_date: Mapped[date] = mapped_column(Date, nullable=False)
    required_by: Mapped[date | None] = mapped_column(Date)
    source: Mapped[str | None] = mapped_column(String(20))
    priority: Mapped[str] = mapped_column(String(10), nullable=False, default="normal", server_default="normal")
    estimated_value: Mapped[Decimal | None] = mapped_column(AMOUNT)
    sales_person_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="open", server_default="open")
    status_changed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    lost_reason: Mapped[str | None] = mapped_column(String(300))

    lead: Mapped[Lead | None] = relationship(lazy="selectin")


class SiteVisit(AuditColumnsMixin, Base):
    __tablename__ = "site_visits"
    __table_args__ = (
        CheckConstraint(_in("status", VISIT_STATUSES), name="status_valid"),
        CheckConstraint("latitude is null or latitude between -90 and 90", name="lat_range"),
        CheckConstraint("longitude is null or longitude between -180 and 180", name="lng_range"),
        Index("ix_site_visits_status_date", "status", "visit_date"),
        Index("ix_site_visits_engineer_id", "engineer_id"),
        Index("ix_site_visits_enquiry_id", "enquiry_id"),
        Index("ix_site_visits_customer_id", "customer_id"),
    )

    visit_number: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    enquiry_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("enquiries.id", ondelete="RESTRICT"))
    lead_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("leads.id", ondelete="RESTRICT"))
    customer_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("customers.id", ondelete="RESTRICT"), nullable=False)
    site_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("customer_sites.id", ondelete="RESTRICT"))
    site_location: Mapped[str | None] = mapped_column(String(300))
    visit_date: Mapped[date] = mapped_column(Date, nullable=False)
    visit_time: Mapped[time | None] = mapped_column(Time)
    engineer_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="scheduled", server_default="scheduled")
    purpose: Mapped[str | None] = mapped_column(String(300))
    observations: Mapped[str | None] = mapped_column(Text)
    requirements: Mapped[str | None] = mapped_column(Text)
    # [{"label": "Earth pit 1 resistance", "value": "2.4", "unit": "Ω"}, …]
    measurements: Mapped[list] = mapped_column(JSONB, nullable=False, default=list, server_default="[]")
    recommendations: Mapped[str | None] = mapped_column(Text)
    customer_rep_name: Mapped[str | None] = mapped_column(String(150))
    customer_rep_designation: Mapped[str | None] = mapped_column(String(100))
    customer_rep_phone: Mapped[str | None] = mapped_column(String(30))
    follow_up_date: Mapped[date | None] = mapped_column(Date)
    latitude: Mapped[Decimal | None] = mapped_column(Numeric(9, 6))
    longitude: Mapped[Decimal | None] = mapped_column(Numeric(9, 6))
    location_accuracy_m: Mapped[int | None] = mapped_column(Integer)
    location_captured_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    enquiry: Mapped[Enquiry | None] = relationship(lazy="selectin")
    lead: Mapped[Lead | None] = relationship(lazy="selectin")


class CrmActivity(AuditColumnsMixin, Base):
    """A call, meeting, note… logged against a lead or an enquiry. kind='follow_up' is a to-do with a due time."""

    __tablename__ = "crm_activities"
    __table_args__ = (
        CheckConstraint(_in("kind", ACTIVITY_KINDS), name="kind_valid"),
        CheckConstraint("num_nonnulls(lead_id, enquiry_id) = 1", name="one_parent"),
        CheckConstraint("kind <> 'follow_up' or due_at is not null", name="follow_up_due"),
        Index("ix_crm_activities_lead_id", "lead_id"),
        Index("ix_crm_activities_enquiry_id", "enquiry_id"),
        Index("ix_crm_activities_open_follow_ups", "assigned_to_id", "due_at", postgresql_where="done_at is null"),
    )

    lead_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("leads.id", ondelete="CASCADE"))
    enquiry_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("enquiries.id", ondelete="CASCADE"))
    kind: Mapped[str] = mapped_column(String(20), nullable=False)
    subject: Mapped[str] = mapped_column(String(200), nullable=False)
    notes: Mapped[str | None] = mapped_column(Text)
    activity_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    assigned_to_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    done_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    done_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    outcome: Mapped[str | None] = mapped_column(String(300))
