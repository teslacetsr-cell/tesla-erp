from app.core.permissions import register

# 'own' scope: a salesperson sees and edits only leads/enquiries assigned to them (or that they created);
# a site engineer sees only the visits assigned to them and the enquiries behind those visits.
register("lead", "Leads", ("create", "read", "update", "delete", "export"), scoped=("read", "update", "delete"))
register("enquiry", "Enquiries", ("create", "read", "update", "delete", "export"), scoped=("read", "update", "delete"))
register("site_visit", "Site visits", ("create", "read", "update", "delete", "print"),
         scoped=("read", "update", "delete", "print"))
