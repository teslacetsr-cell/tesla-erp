"""Site Visit Report PDF (Spec §12) on Tesla letterhead.

Built with ReportLab (pure Python — runs the same in Docker, on the VPS and in the Windows server build).
Photos are read from document storage and downscaled before embedding, so a report with a dozen phone photos
stays a few MB. DejaVu Sans is embedded so ₹, Ω, °, µ and Indian names print correctly.
"""
import io
import logging
from datetime import datetime
from html import escape
from pathlib import Path
from zoneinfo import ZoneInfo

from PIL import Image as PILImage
from PIL import ImageOps
from reportlab.lib import colors
from reportlab.lib.enums import TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    HRFlowable,
    Image,
    KeepTogether,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.company.models import Company
from app.crm.models import SiteVisit
from app.customers.models import Customer, CustomerSite
from app.platform.documents.models import Document
from app.platform.documents.storage import get_storage
from app.platform.pdfkit import flatten
from app.users.models import User

log = logging.getLogger(__name__)
ASSETS = Path(__file__).resolve().parent.parent / "assets"
RED = colors.HexColor("#d90000")
INK = colors.HexColor("#1f2937")
MUTED = colors.HexColor("#6b7280")
LINE = colors.HexColor("#e5e7eb")
IST = ZoneInfo("Asia/Kolkata")
MAX_PHOTOS = 24

_fonts_ready = False


def _fonts() -> None:
    global _fonts_ready
    if not _fonts_ready:
        pdfmetrics.registerFont(TTFont("DejaVu", str(ASSETS / "fonts" / "DejaVuSans.ttf")))
        pdfmetrics.registerFont(TTFont("DejaVu-Bold", str(ASSETS / "fonts" / "DejaVuSans-Bold.ttf")))
        pdfmetrics.registerFontFamily("DejaVu", normal="DejaVu", bold="DejaVu-Bold", italic="DejaVu",
                                      boldItalic="DejaVu-Bold")
        _fonts_ready = True


def _styles() -> dict[str, ParagraphStyle]:
    base = ParagraphStyle("base", fontName="DejaVu", fontSize=9, leading=12.5, textColor=INK)
    return {
        "base": base,
        "small": ParagraphStyle("small", parent=base, fontSize=7.5, leading=10, textColor=MUTED),
        "label": ParagraphStyle("label", parent=base, fontSize=7.5, leading=10, textColor=MUTED),
        "title": ParagraphStyle("title", parent=base, fontName="DejaVu-Bold", fontSize=15, leading=19),
        "h": ParagraphStyle("h", parent=base, fontName="DejaVu-Bold", fontSize=10, leading=14, textColor=RED,
                            spaceBefore=8, spaceAfter=3),
        "company": ParagraphStyle("company", parent=base, fontName="DejaVu-Bold", fontSize=13, leading=16,
                                  alignment=TA_RIGHT),
        "right": ParagraphStyle("right", parent=base, fontSize=7.5, leading=10, textColor=MUTED, alignment=TA_RIGHT),
    }


def _p(text: str | None, style: ParagraphStyle) -> Paragraph:
    """Escaped paragraph; line breaks in what the engineer typed are kept."""
    return Paragraph(escape(text or "—").replace("\n", "<br/>"), style)


def _image(data: bytes, max_w: float, max_h: float) -> Image | None:
    try:
        with PILImage.open(io.BytesIO(data)) as im:
            im = ImageOps.exif_transpose(im)  # phone photos carry their rotation in EXIF
            im = flatten(im)
            im.thumbnail((1400, 1400))
            out = io.BytesIO()
            im.save(out, "JPEG", quality=78, optimize=True)
            w, h = im.size
    except Exception:  # noqa: BLE001 - an unreadable photo must not stop the report
        log.warning("site visit report: skipped an image that could not be decoded")
        return None
    scale = min(max_w / w, max_h / h)
    out.seek(0)
    return Image(out, width=w * scale, height=h * scale)


def build(db: Session, visit: SiteVisit) -> bytes:
    _fonts()
    st = _styles()
    storage = get_storage()
    company = db.scalar(select(Company).where(Company.is_default.is_(True))) or db.scalar(select(Company))
    customer = db.get(Customer, visit.customer_id)
    site = db.get(CustomerSite, visit.site_id) if visit.site_id else None
    engineer = db.get(User, visit.engineer_id) if visit.engineer_id else None

    logo = None
    if company and company.logo_document_id:
        doc = db.get(Document, company.logo_document_id)
        if doc is not None:
            try:
                logo = _image(storage.get(doc.storage_key), 22 * mm, 22 * mm)
            except Exception:  # noqa: BLE001
                logo = None
    if logo is None and (ASSETS / "tce-logo.png").exists():
        logo = _image((ASSETS / "tce-logo.png").read_bytes(), 22 * mm, 22 * mm)

    addr = ", ".join(x for x in (company.address_line1, company.address_line2, company.city, company.state,
                                 company.pincode) if x) if company else ""
    contact = " · ".join(x for x in (company.phone, company.email, company.website) if x) if company else ""
    generated = datetime.now(IST).strftime("%d %b %Y, %I:%M %p IST")

    def on_page(canvas, doc):
        canvas.saveState()
        w, _ = A4
        canvas.setFont("DejaVu", 7)
        canvas.setFillColor(MUTED)
        canvas.drawString(15 * mm, 10 * mm, f"Site visit report {visit.visit_number} · generated {generated}")
        canvas.drawRightString(w - 15 * mm, 10 * mm, f"Page {doc.page}")
        canvas.restoreState()

    def header():
        right = [Paragraph(escape(company.company_name if company else "Tesla Consulting Engineers"), st["company"])]
        if company and company.tagline:
            right.append(Paragraph(escape(company.tagline), st["right"]))
        if addr:
            right.append(Paragraph(escape(addr), st["right"]))
        if contact:
            right.append(Paragraph(escape(contact), st["right"]))
        if company and company.gstin:
            right.append(Paragraph(f"GSTIN {escape(company.gstin)}", st["right"]))
        t = Table([[logo or "", right]], colWidths=[28 * mm, None])
        t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                               ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
        return t

    story = [header(), Spacer(1, 2 * mm), HRFlowable(width="100%", thickness=1.2, color=RED), Spacer(1, 5 * mm)]
    title = Table([[Paragraph("SITE VISIT REPORT", st["title"]),
                    Paragraph(f"<b>{escape(visit.visit_number)}</b><br/>{escape(visit.status.title())}", st["right"])]],
                  colWidths=[None, 60 * mm])
    title.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "BOTTOM"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                               ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    story += [title, Spacer(1, 4 * mm)]

    when = visit.visit_date.strftime("%d %b %Y") + (f", {visit.visit_time.strftime('%I:%M %p')}" if visit.visit_time else "")
    rep = " · ".join(x for x in (visit.customer_rep_name, visit.customer_rep_designation, visit.customer_rep_phone) if x)
    info = [
        ("Customer", f"{customer.customer_name} ({customer.customer_code})" if customer else "—"),
        ("Visit date", when),
        ("Site", site.site_name if site else "—"),
        ("Engineer", engineer.full_name if engineer else "—"),
        ("Location", visit.site_location),
        ("Enquiry", visit.enquiry.enquiry_number if visit.enquiry else "—"),
        ("Purpose", visit.purpose),
        ("Customer representative", rep or "—"),
    ]
    rows = []
    for i in range(0, len(info), 2):
        row = []
        for label, value in info[i:i + 2]:
            row += [Paragraph(escape(label), st["label"]), _p(value, st["base"])]
        rows.append(row)
    t = Table(rows, colWidths=[28 * mm, 60 * mm, 32 * mm, None])
    t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"), ("BOX", (0, 0), (-1, -1), 0.5, LINE),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE), ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#fafafa")),
        ("BACKGROUND", (2, 0), (2, -1), colors.HexColor("#fafafa")), ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    story.append(t)

    for heading, text in (("Observations", visit.observations), ("Customer requirements", visit.requirements)):
        story += [Paragraph(heading, st["h"]), _p(text, st["base"])]

    if visit.measurements:
        story.append(Paragraph("Measurements", st["h"]))
        data = [[Paragraph("<b>#</b>", st["base"]), Paragraph("<b>Measurement</b>", st["base"]),
                 Paragraph("<b>Value</b>", st["base"]), Paragraph("<b>Unit</b>", st["base"])]]
        for i, m in enumerate(visit.measurements, start=1):
            data.append([str(i), _p(m.get("label"), st["base"]), _p(m.get("value"), st["base"]),
                         _p(m.get("unit") or "", st["base"])])
        mt = Table(data, colWidths=[10 * mm, None, 35 * mm, 25 * mm], repeatRows=1)
        mt.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (-1, -1), "DejaVu"), ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#fef2f2")), ("BOX", (0, 0), (-1, -1), 0.5, LINE),
            ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        story.append(mt)

    story += [Paragraph("Recommendations", st["h"]), _p(visit.recommendations, st["base"])]
    if visit.follow_up_date:
        story += [Spacer(1, 2 * mm), Paragraph(f"<b>Follow-up date:</b> {visit.follow_up_date.strftime('%d %b %Y')}",
                                               st["base"])]
    if visit.latitude is not None:
        lat, lng = visit.latitude, visit.longitude
        acc = f" (±{visit.location_accuracy_m} m)" if visit.location_accuracy_m else ""
        at = visit.location_captured_at.astimezone(IST).strftime("%d %b %Y %I:%M %p") if visit.location_captured_at else ""
        url = f"https://maps.google.com/?q={lat},{lng}"
        story += [Paragraph("GPS location", st["h"]),
                  Paragraph(f'{lat}, {lng}{acc} · recorded {escape(at)} · <link href="{url}" color="#d90000">'
                            f"open in Google Maps</link>", st["base"])]

    photos = list(db.scalars(select(Document).where(
        Document.entity_type == "site_visit", Document.entity_id == visit.id, Document.status == "available",
        Document.is_latest.is_(True), Document.content_type.in_(("image/jpeg", "image/png", "image/webp")))
        .order_by(Document.uploaded_at)))
    if photos:
        story.append(Paragraph(f"Photos ({len(photos)})", st["h"]))
        cells = []
        for d in photos[:MAX_PHOTOS]:
            try:
                img = _image(storage.get(d.storage_key), 85 * mm, 64 * mm)
            except Exception:  # noqa: BLE001
                img = None
            if img is not None:
                cells.append([img, Paragraph(escape(d.title or d.file_name), st["small"])])
        grid = [cells[i:i + 2] for i in range(0, len(cells), 2)]
        for row in grid:
            if len(row) == 1:
                row.append("")
            story.append(KeepTogether(Table([row], colWidths=[90 * mm, 90 * mm],
                                            style=[("VALIGN", (0, 0), (-1, -1), "TOP"),
                                                   ("LEFTPADDING", (0, 0), (-1, -1), 0)])))
        if len(photos) > MAX_PHOTOS:
            story.append(Paragraph(f"{len(photos) - MAX_PHOTOS} more photos are attached to the visit in the ERP.",
                                   st["small"]))

    sig = Table([[Paragraph("Engineer", st["label"]), "", Paragraph("Customer representative", st["label"])],
                 [Paragraph(escape(engineer.full_name) if engineer else "", st["base"]), "",
                  Paragraph(escape(visit.customer_rep_name or ""), st["base"])]],
                colWidths=[75 * mm, None, 75 * mm], rowHeights=[None, 18 * mm])
    sig.setStyle(TableStyle([("LINEBELOW", (0, 1), (0, 1), 0.6, INK), ("LINEBELOW", (2, 1), (2, 1), 0.6, INK),
                             ("VALIGN", (0, 1), (-1, 1), "BOTTOM")]))
    story += [Spacer(1, 10 * mm), KeepTogether(sig)]

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=10 * mm,
                            bottomMargin=16 * mm, title=f"Site visit report {visit.visit_number}",
                            author=company.company_name if company else "Tesla Consulting Engineers")
    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)
    return buf.getvalue()
