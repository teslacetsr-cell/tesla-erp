"""Login, refresh-token rotation, logout, password change."""
import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy import or_, select, update
from sqlalchemy.orm import Session

from app.auth.models import RefreshToken, UserMFA
from app.core.config import get_settings
from app.core.context import request_ctx
from app.core.errors import AppError, Unauthorized
from app.core.security import (
    create_access_token,
    dummy_verify,
    hash_password,
    hash_token,
    new_opaque_token,
    password_problems,
    verify_password,
)
from app.platform.audit import service as audit
from app.users.models import User

_settings = get_settings()
INVALID = "Incorrect username/email or password."


def authenticate(session: Session, login: str, password: str) -> User:
    """Returns the user or raises. Failed-attempt counters are committed even when login fails."""
    login = login.strip()
    user = session.scalar(select(User).where(or_(User.username == login, User.email == login)))
    now = datetime.now(UTC)
    if user is None:
        dummy_verify()
        audit.record(session, action="login_failed", entity_type="auth", entity_label=login[:100],
                     summary="Unknown username/email")
        session.commit()
        raise Unauthorized(INVALID, code="INVALID_CREDENTIALS")
    if user.locked_until and user.locked_until > now:
        mins = max(1, int((user.locked_until - now).total_seconds() // 60) + 1)
        raise Unauthorized(f"Too many failed attempts. Try again in {mins} minute(s) or ask an administrator.",
                           code="ACCOUNT_LOCKED")
    if not verify_password(password, user.password_hash):
        user.failed_login_count += 1
        summary = f"Wrong password (attempt {user.failed_login_count})"
        if user.failed_login_count >= _settings.login_max_failures:
            user.locked_until = now + timedelta(minutes=_settings.login_lockout_minutes)
            user.failed_login_count = 0
            summary += " — account locked"
        audit.record(session, action="login_failed", entity_type="user", entity_id=user.id,
                     entity_label=user.username, summary=summary, user_id=user.id)
        session.commit()
        raise Unauthorized(INVALID, code="INVALID_CREDENTIALS")
    if not user.is_active:
        raise Unauthorized("This account is deactivated.", code="ACCOUNT_DISABLED")
    mfa = session.get(UserMFA, user.id)
    if mfa is not None and mfa.is_enabled:
        # Architecture hook (Spec §3): the second step is implemented when 2FA is switched on.
        raise AppError("MFA_REQUIRED", "Two-factor verification is required.", status_code=401)
    user.failed_login_count = 0
    user.locked_until = None
    user.last_login_at = now
    audit.record(session, action="login", entity_type="user", entity_id=user.id, entity_label=user.username,
                 user_id=user.id)
    return user


def issue_refresh_token(session: Session, user: User, family_id: uuid.UUID | None = None) -> str:
    ctx = request_ctx.get()
    token = new_opaque_token()
    session.add(RefreshToken(
        user_id=user.id, family_id=family_id or uuid.uuid4(), token_hash=hash_token(token),
        expires_at=datetime.now(UTC) + timedelta(days=_settings.refresh_token_days),
        ip=ctx.ip, user_agent=(ctx.user_agent or "")[:255] or None,
    ))
    return token


def issue_tokens(session: Session, user: User, family_id: uuid.UUID | None = None) -> tuple[str, int, str]:
    access, ttl = create_access_token(user.id, user.session_version)
    refresh = issue_refresh_token(session, user, family_id)
    return access, ttl, refresh


def rotate(session: Session, presented: str) -> tuple[User, str, int, str]:
    row = session.scalar(
        select(RefreshToken).where(RefreshToken.token_hash == hash_token(presented)).with_for_update()
    )
    now = datetime.now(UTC)
    if row is None:
        raise Unauthorized("Your session has ended. Please sign in again.", code="REFRESH_INVALID")
    if row.revoked_at is not None:
        # A rotated-out token was used again: likely theft. Kill the whole family.
        revoke_family(session, row.family_id, "reuse_detected")
        audit.record(session, action="token_reuse", entity_type="user", entity_id=row.user_id, user_id=row.user_id,
                     summary="Refresh token reuse detected; all sessions in this family revoked")
        session.commit()
        raise Unauthorized("Your session has ended. Please sign in again.", code="REFRESH_REUSED")
    if row.expires_at <= now:
        raise Unauthorized("Your session has expired. Please sign in again.", code="REFRESH_EXPIRED")
    user = session.get(User, row.user_id)
    if user is None or not user.is_active:
        raise Unauthorized("This account is deactivated.", code="ACCOUNT_DISABLED")
    row.revoked_at, row.revoked_reason = now, "rotated"
    access, ttl, refresh = issue_tokens(session, user, row.family_id)
    return user, access, ttl, refresh


def revoke_family(session: Session, family_id: uuid.UUID, reason: str) -> None:
    session.execute(
        update(RefreshToken)
        .where(RefreshToken.family_id == family_id, RefreshToken.revoked_at.is_(None))
        .values(revoked_at=datetime.now(UTC), revoked_reason=reason)
    )


def revoke_all_sessions(session: Session, user: User, reason: str) -> None:
    """Immediate: bumps session_version (kills access tokens) and revokes every refresh token."""
    user.session_version += 1
    session.execute(
        update(RefreshToken)
        .where(RefreshToken.user_id == user.id, RefreshToken.revoked_at.is_(None))
        .values(revoked_at=datetime.now(UTC), revoked_reason=reason)
    )


def logout(session: Session, presented: str | None) -> None:
    if not presented:
        return
    row = session.scalar(select(RefreshToken).where(RefreshToken.token_hash == hash_token(presented)))
    if row is not None:
        revoke_family(session, row.family_id, "logout")
        audit.record(session, action="logout", entity_type="user", entity_id=row.user_id, user_id=row.user_id)


def change_password(session: Session, user: User, current: str, new: str) -> None:
    if not verify_password(current, user.password_hash):
        raise AppError("WRONG_PASSWORD", "Your current password is incorrect.")
    if current == new:
        raise AppError("PASSWORD_UNCHANGED", "The new password must be different from the current one.")
    set_password(user, new)
    revoke_all_sessions(session, user, "password_changed")
    audit.record(session, action="password_change", entity_type="user", entity_id=user.id, entity_label=user.username)


def set_password(user: User, new: str, *, must_change: bool = False) -> None:
    problems = password_problems(new, username=user.username, email=user.email)
    if problems:
        raise AppError("WEAK_PASSWORD", " ".join(problems), details=problems)
    user.password_hash = hash_password(new)
    user.password_changed_at = datetime.now(UTC)
    user.must_change_password = must_change
