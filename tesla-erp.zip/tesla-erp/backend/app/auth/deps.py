"""Authentication & authorisation dependencies used by every route."""
import uuid
from dataclasses import dataclass, field
from typing import Annotated

import jwt
from fastapi import Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.company.models import Company
from app.core.context import request_ctx
from app.core.db import DbSession
from app.core.errors import AppError, Forbidden, Unauthorized
from app.core.permissions import normalise
from app.core.security import decode_access_token
from app.users.models import SCOPE_RANK, Permission, RolePermission, User, UserRole


@dataclass
class Principal:
    user: User
    company_id: uuid.UUID
    permissions: dict[str, str] = field(default_factory=dict)  # code -> widest scope
    role_codes: list[str] = field(default_factory=list)

    @property
    def id(self) -> uuid.UUID:
        return self.user.id

    def can(self, code: str) -> bool:
        return normalise(code) in self.permissions

    def scope(self, code: str) -> str | None:
        return self.permissions.get(normalise(code))


def load_permissions(session: Session, user_id: uuid.UUID) -> tuple[dict[str, str], list[str]]:
    rows = session.execute(
        select(Permission.code, RolePermission.scope)
        .join(RolePermission, RolePermission.permission_id == Permission.id)
        .join(UserRole, UserRole.role_id == RolePermission.role_id)
        .where(UserRole.user_id == user_id)
    ).all()
    perms: dict[str, str] = {}
    for code, scope in rows:
        if code not in perms or SCOPE_RANK[scope] > SCOPE_RANK[perms[code]]:
            perms[code] = scope
    from app.users.models import Role

    roles = list(session.scalars(
        select(Role.code).join(UserRole, UserRole.role_id == Role.id)
        .where(UserRole.user_id == user_id, Role.is_active.is_(True))
    ))
    return perms, roles


_default_company_id: uuid.UUID | None = None


def default_company_id(session: Session) -> uuid.UUID:
    global _default_company_id
    if _default_company_id is None or session.get(Company, _default_company_id) is None:
        cid = session.scalar(select(Company.id).where(Company.is_default.is_(True), Company.is_active.is_(True)))
        if cid is None:
            raise AppError("NO_COMPANY", "No active default company is configured.", status_code=500)
        _default_company_id = cid
    return _default_company_id


def reset_company_cache() -> None:
    global _default_company_id
    _default_company_id = None


def get_principal(request: Request, db: DbSession) -> Principal:
    header = request.headers.get("authorization", "")
    if not header.lower().startswith("bearer "):
        raise Unauthorized()
    try:
        payload = decode_access_token(header[7:].strip())
        user_id = uuid.UUID(payload["sub"])
    except (jwt.PyJWTError, ValueError, KeyError) as exc:
        raise Unauthorized("Your session has expired. Please sign in again.", code="TOKEN_INVALID") from exc
    user = db.get(User, user_id)
    if user is None or not user.is_active or user.session_version != payload.get("sv"):
        raise Unauthorized("Your session is no longer valid. Please sign in again.", code="SESSION_REVOKED")
    perms, roles = load_permissions(db, user.id)
    ctx = request_ctx.get()
    ctx.user_id = user.id
    principal = Principal(user=user, company_id=default_company_id(db), permissions=perms, role_codes=roles)
    # A user who must change their password may only do that (and read who they are).
    if user.must_change_password and request.url.path not in (
        "/api/v1/auth/me", "/api/v1/auth/change-password", "/api/v1/auth/logout"
    ):
        raise Forbidden("You must change your password before continuing.", code="PASSWORD_CHANGE_REQUIRED")
    return principal


CurrentUser = Annotated[Principal, Depends(get_principal)]


def require(*codes: str):
    """Route dependency: the user must hold ALL the given permissions."""

    def dep(principal: CurrentUser) -> Principal:
        missing = [c for c in codes if not principal.can(c)]
        if missing:
            raise Forbidden(f"You do not have permission: {', '.join(missing)}.")
        return principal

    return Depends(dep)
