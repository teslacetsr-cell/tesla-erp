import hmac
import secrets
import time
from collections import defaultdict, deque
from typing import Annotated

from fastapi import APIRouter, Cookie, Header, Request, Response
from pydantic import BaseModel, Field

from app.auth import service
from app.auth.deps import CurrentUser, load_permissions
from app.core.config import get_settings
from app.core.db import DbSession
from app.core.errors import AppError, Forbidden
from app.core.security import create_access_token

router = APIRouter(prefix="/auth", tags=["auth"])
_settings = get_settings()
REFRESH_COOKIE = "tce_refresh"
CSRF_COOKIE = "tce_csrf"
REFRESH_PATH = "/api/v1/auth"


class LoginIn(BaseModel):
    login: str = Field(min_length=1, max_length=150, description="Username or email")
    password: str = Field(min_length=1, max_length=128)


class ChangePasswordIn(BaseModel):
    current_password: str = Field(min_length=1, max_length=128)
    new_password: str = Field(min_length=1, max_length=128)


# --- simple per-IP rate limit for login (per process; the DB lockout is the durable control)
_attempts: dict[str, deque] = defaultdict(deque)


def _rate_limit(ip: str) -> None:
    now = time.monotonic()
    q = _attempts[ip]
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= _settings.login_rate_limit_per_minute:
        raise AppError("RATE_LIMITED", "Too many sign-in attempts. Please wait a minute.", status_code=429)
    q.append(now)


def _secure(request: Request) -> bool:
    """Cloud: always Secure. On-premise: Secure when the request arrived over HTTPS (remote access through the
    Cloudflare Tunnel); plain-HTTP office-network access still works."""
    if _settings.cookie_secure:
        return True
    return _settings.deployment == "onprem" and request.url.scheme == "https"


def _set_session_cookies(request: Request, response: Response, refresh: str) -> str:
    csrf = secrets.token_urlsafe(24)
    max_age = _settings.refresh_token_days * 86400
    secure = _secure(request)
    response.set_cookie(REFRESH_COOKIE, refresh, max_age=max_age, httponly=True, secure=secure,
                        samesite="strict", path=REFRESH_PATH)
    response.set_cookie(CSRF_COOKIE, csrf, max_age=max_age, httponly=False, secure=secure,
                        samesite="strict", path="/")
    return csrf


def _clear_cookies(response: Response) -> None:
    response.delete_cookie(REFRESH_COOKIE, path=REFRESH_PATH)
    response.delete_cookie(CSRF_COOKIE, path="/")


def _check_csrf(cookie: str | None, header: str | None) -> None:
    if not cookie or not header or not hmac.compare_digest(cookie, header):
        raise Forbidden("Security check failed. Please reload the page.", code="CSRF_FAILED")


def _me(principal_user, perms: dict[str, str], roles: list[str]) -> dict:
    u = principal_user
    return {
        "id": str(u.id), "username": u.username, "email": u.email, "full_name": u.full_name,
        "must_change_password": u.must_change_password, "roles": roles, "permissions": perms,
    }


def _session_payload(db, user, access: str, ttl: int) -> dict:
    perms, roles = load_permissions(db, user.id)
    return {"data": {"access_token": access, "token_type": "bearer", "expires_in": ttl,
                     "user": _me(user, perms, roles)}}


@router.post("/login")
def login(body: LoginIn, request: Request, response: Response, db: DbSession):
    _rate_limit(request.client.host if request.client else "unknown")
    user = service.authenticate(db, body.login, body.password)
    access, ttl, refresh = service.issue_tokens(db, user)
    _set_session_cookies(request, response, refresh)
    return _session_payload(db, user, access, ttl)


@router.post("/refresh")
def refresh(
    request: Request,
    response: Response,
    db: DbSession,
    tce_refresh: Annotated[str | None, Cookie()] = None,
    tce_csrf: Annotated[str | None, Cookie()] = None,
    x_csrf_token: Annotated[str | None, Header()] = None,
):
    _check_csrf(tce_csrf, x_csrf_token)
    if not tce_refresh:
        raise AppError("REFRESH_MISSING", "Please sign in.", status_code=401)
    user, access, ttl, new_refresh = service.rotate(db, tce_refresh)
    _set_session_cookies(request, response, new_refresh)
    return _session_payload(db, user, access, ttl)


@router.post("/logout")
def logout(
    response: Response,
    db: DbSession,
    tce_refresh: Annotated[str | None, Cookie()] = None,
    tce_csrf: Annotated[str | None, Cookie()] = None,
    x_csrf_token: Annotated[str | None, Header()] = None,
):
    _check_csrf(tce_csrf, x_csrf_token)
    service.logout(db, tce_refresh)
    _clear_cookies(response)
    return {"data": {"ok": True}}


@router.get("/me")
def me(principal: CurrentUser):
    return {"data": _me(principal.user, principal.permissions, principal.role_codes)}


@router.post("/change-password")
def change_password(body: ChangePasswordIn, request: Request, response: Response, principal: CurrentUser, db: DbSession):
    user = principal.user
    service.change_password(db, user, body.current_password, body.new_password)
    # All previous sessions are revoked; give this browser a fresh session.
    access, ttl = create_access_token(user.id, user.session_version)
    refresh_token = service.issue_refresh_token(db, user)
    _set_session_cookies(request, response, refresh_token)
    return _session_payload(db, user, access, ttl)
