"""Background jobs. `enqueue` inside the business transaction; the worker process runs them.

Because the job row commits (or rolls back) with the business change, a job can never be
queued for a change that didn't happen, and never lost for one that did.
"""
import logging
import traceback
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session, sessionmaker

from app.platform.jobs.models import Job

log = logging.getLogger("jobs")
HANDLERS: dict[str, Callable[[Session, dict], None]] = {}


def handler(kind: str):
    def deco(fn: Callable[[Session, dict], None]):
        HANDLERS[kind] = fn
        return fn

    return deco


def enqueue(session: Session, kind: str, payload: dict[str, Any] | None = None, *, delay_seconds: int = 0) -> Job:
    if kind not in HANDLERS:
        raise ValueError(f"No handler registered for job kind '{kind}'")
    job = Job(kind=kind, payload=payload or {}, run_at=datetime.now(UTC) + timedelta(seconds=delay_seconds))
    session.add(job)
    return job


def run_pending(session_factory: sessionmaker, limit: int = 10) -> int:
    """Claim and run up to `limit` due jobs. Each job runs in its own transaction. Returns jobs processed."""
    processed = 0
    for _ in range(limit):
        with session_factory() as session:
            job = session.scalar(
                select(Job)
                .where(Job.status == "pending", Job.run_at <= datetime.now(UTC))
                .order_by(Job.run_at)
                .limit(1)
                .with_for_update(skip_locked=True)
            )
            if job is None:
                return processed
            job.attempts += 1
            try:
                with session.begin_nested():
                    HANDLERS[job.kind](session, job.payload)
                job.status, job.finished_at, job.last_error = "done", datetime.now(UTC), None
            except Exception:  # noqa: BLE001 - record any failure and retry with backoff
                job.last_error = traceback.format_exc()[-4000:]
                if job.attempts >= job.max_attempts:
                    job.status, job.finished_at = "failed", datetime.now(UTC)
                    log.error("job %s (%s) failed permanently", job.id, job.kind)
                else:
                    job.run_at = datetime.now(UTC) + timedelta(seconds=30 * 2 ** job.attempts)
            session.commit()
            processed += 1
    return processed


@handler("system.ping")
def _ping(session: Session, payload: dict) -> None:
    if payload.get("fail"):
        raise RuntimeError("requested failure")
