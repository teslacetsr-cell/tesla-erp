"""Company settings with typed defaults. Every change is audited."""
import uuid
from dataclasses import dataclass
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import AppError
from app.platform.audit import service as audit
from app.platform.settings.models import AppSetting


@dataclass(frozen=True)
class SettingDef:
    key: str
    label: str
    type: type
    default: Any
    group: str
    help: str = ""


DEFINITIONS: dict[str, SettingDef] = {
    d.key: d
    for d in [
        SettingDef("inventory.allow_negative_stock", "Allow negative stock", bool, False, "Inventory",
                   "Off by default. When off, any issue that would take stock below zero is blocked."),
        SettingDef("inventory.low_stock_alerts", "Low-stock alerts", bool, True, "Inventory"),
        SettingDef("approvals.quotation_director_threshold", "Quotation value needing Director approval (₹, before GST)",
                   int, 500000, "Approvals"),
        SettingDef("approvals.purchase_director_threshold", "Purchase value needing Director approval (₹, before GST)",
                   int, 200000, "Approvals"),
        SettingDef("documents.max_upload_mb", "Maximum upload size (MB)", int, 25, "Documents"),
        SettingDef("quotation.default_validity_days", "Default quotation validity (days)", int, 30, "Sales"),
        SettingDef("crm.site_visit_gps", "Record GPS location on site visits", bool, True, "CRM",
                   "Engineers can attach the phone's location to a visit report. Always optional per visit."),
        SettingDef("customer.default_payment_terms", "Default customer payment terms", str,
                   "50% advance, balance against delivery", "Sales"),
    ]
}


def all_settings(session: Session, company_id: uuid.UUID) -> dict[str, Any]:
    stored = {s.key: s.value for s in session.scalars(select(AppSetting).where(AppSetting.company_id == company_id))}
    return {k: stored.get(k, d.default) for k, d in DEFINITIONS.items()}


def get_setting(session: Session, company_id: uuid.UUID, key: str) -> Any:
    d = DEFINITIONS[key]
    row = session.scalar(select(AppSetting).where(AppSetting.company_id == company_id, AppSetting.key == key))
    return d.default if row is None else row.value


def set_setting(session: Session, company_id: uuid.UUID, key: str, value: Any, user_id: uuid.UUID | None) -> Any:
    d = DEFINITIONS.get(key)
    if d is None:
        raise AppError("UNKNOWN_SETTING", f"Unknown setting '{key}'.")
    if d.type is bool and not isinstance(value, bool):
        raise AppError("INVALID_SETTING", f"'{d.label}' must be true or false.")
    if d.type is int and (isinstance(value, bool) or not isinstance(value, int) or value < 0):
        raise AppError("INVALID_SETTING", f"'{d.label}' must be a whole number ≥ 0.")
    if d.type is str and (not isinstance(value, str) or len(value) > 500):
        raise AppError("INVALID_SETTING", f"'{d.label}' must be text up to 500 characters.")
    row = session.scalar(
        select(AppSetting).where(AppSetting.company_id == company_id, AppSetting.key == key).with_for_update()
    )
    old = d.default if row is None else row.value
    if row is None:
        row = AppSetting(company_id=company_id, key=key, value=value, updated_by=user_id)
        session.add(row)
    else:
        row.value, row.updated_by = value, user_id
    audit.record(session, action="update", entity_type="setting", entity_id=key, entity_label=d.label,
                 before={"value": old}, after={"value": value})
    return value
