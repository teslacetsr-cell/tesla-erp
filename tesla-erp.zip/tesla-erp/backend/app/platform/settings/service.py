"""Company settings with typed defaults. Every change is audited."""
import uuid
from dataclasses import dataclass
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import AppError
from app.platform.audit import service as audit
from app.platform.settings.models import AppSetting


@dataclass(frozen=True)
class SettingDef:
    key: str
    label: str
    type: type
    default: Any
    group: str
    help: str = ""
    max: int | None = None     # for whole numbers


DEFINITIONS: dict[str, SettingDef] = {
    d.key: d
    for d in [
        SettingDef("inventory.allow_negative_stock", "Allow negative stock", bool, False, "Inventory",
                   "Off by default. When off, any issue that would take stock below zero is blocked."),
        SettingDef("hr.full_day_hours", "Hours in a full working day", int, 8, "HR",
                   "A day checked out after less than half of this becomes a half day. 0 = never automatic."),
        SettingDef("hr.attendance_gps", "Record location at check-in", bool, True, "HR",
                   "The phone's location is attached to check-in and check-out when the employee allows it."),
        SettingDef("hr.labour_days_per_month", "Working days per month for labour cost", int, 26, "HR",
                   "Daily labour cost = monthly cost to company ÷ this, unless a day rate is set on the salary."),
        SettingDef("documents.max_upload_mb", "Maximum upload size (MB)", int, 25, "Documents"),
        SettingDef("quotation.default_validity_days", "Default quotation validity (days)", int, 30, "Sales"),
        SettingDef("crm.site_visit_gps", "Record GPS location on site visits", bool, True, "CRM",
                   "Engineers can attach the phone's location to a visit report. Always optional per visit."),
        SettingDef("customer.default_payment_terms", "Default customer payment terms", str,
                   "50% advance, balance against delivery", "Sales"),
        # daily alerts (Phase 10): run once a day by the background worker; each can be switched off
        SettingDef("alerts.run_hour", "Time to send the daily alerts (hour, India time)", int, 8, "Alerts",
                   "0–23. The alerts and the daily summary emails go out once a day, at or after this hour.", max=23),
        SettingDef("alerts.invoice_overdue", "Customer invoices overdue", bool, True, "Alerts",
                   "To accounts, and to the sales person of the order."),
        SettingDef("alerts.invoice_overdue_days", "…overdue by more than (days)", int, 0, "Alerts",
                   "0 = from the day after the due date.", max=365),
        SettingDef("alerts.bill_due", "Supplier bills due", bool, True, "Alerts", "To accounts."),
        SettingDef("alerts.bill_due_days", "…due within (days)", int, 3, "Alerts",
                   "Bills due within this many days, and bills already overdue.", max=90),
        SettingDef("alerts.project_late", "Projects past target date", bool, True, "Alerts",
                   "To the project manager."),
        SettingDef("alerts.site_report_gap", "No daily site report", bool, True, "Alerts",
                   "Active projects without a site report recently. To the project manager."),
        SettingDef("alerts.site_report_days", "…for more than (days)", int, 3, "Alerts", max=60),
        # (older key, kept so a value already saved still applies)
        SettingDef("inventory.low_stock_alerts", "Low or out-of-stock items", bool, True, "Alerts",
                   "Items below their minimum or reorder level. To stores and purchase."),
        SettingDef("alerts.task_overdue", "Tasks overdue", bool, True, "Alerts",
                   "To the person assigned and the project manager."),
        SettingDef("alerts.approval_waiting", "Approvals waiting too long", bool, True, "Alerts",
                   "Leave, purchase, expense and other requests not decided. To the approver."),
        SettingDef("alerts.approval_waiting_days", "…waiting more than (days)", int, 2, "Alerts", max=60),
        SettingDef("alerts.po_late", "Purchase orders past delivery date", bool, True, "Alerts",
                   "Not fully received by the expected delivery date. To purchase and the person who raised it."),
        SettingDef("alerts.po_late_days", "…late by more than (days)", int, 0, "Alerts", max=90),
        SettingDef("alerts.rfq_due", "Vendor quotations past reply date", bool, True, "Alerts",
                   "Requests for quotation still open after the reply-by date. To purchase."),
    ]
}


def all_settings(session: Session, company_id: uuid.UUID) -> dict[str, Any]:
    stored = {s.key: s.value for s in session.scalars(select(AppSetting).where(AppSetting.company_id == company_id))}
    return {k: stored.get(k, d.default) for k, d in DEFINITIONS.items()}


def get_setting(session: Session, company_id: uuid.UUID, key: str) -> Any:
    d = DEFINITIONS[key]
    row = session.scalar(select(AppSetting).where(AppSetting.company_id == company_id, AppSetting.key == key))
    return d.default if row is None else row.value


def set_setting(session: Session, company_id: uuid.UUID, key: str, value: Any, user_id: uuid.UUID | None) -> Any:
    d = DEFINITIONS.get(key)
    if d is None:
        raise AppError("UNKNOWN_SETTING", f"Unknown setting '{key}'.")
    if d.type is bool and not isinstance(value, bool):
        raise AppError("INVALID_SETTING", f"'{d.label}' must be true or false.")
    if d.type is int and (isinstance(value, bool) or not isinstance(value, int) or value < 0):
        raise AppError("INVALID_SETTING", f"'{d.label}' must be a whole number ≥ 0.")
    if d.type is int and d.max is not None and value > d.max:
        raise AppError("INVALID_SETTING", f"'{d.label}' must be at most {d.max}.")
    if d.type is str and (not isinstance(value, str) or len(value) > 500):
        raise AppError("INVALID_SETTING", f"'{d.label}' must be text up to 500 characters.")
    row = session.scalar(
        select(AppSetting).where(AppSetting.company_id == company_id, AppSetting.key == key).with_for_update()
    )
    old = d.default if row is None else row.value
    if row is None:
        row = AppSetting(company_id=company_id, key=key, value=value, updated_by=user_id)
        session.add(row)
    else:
        row.value, row.updated_by = value, user_id
    audit.record(session, action="update", entity_type="setting", entity_id=key, entity_label=d.label,
                 before={"value": old}, after={"value": value})
    return value
