"""Shared PDF building blocks on Tesla letterhead (ReportLab): fonts with ₹/Ω support, styles, the letterhead,
money formatting and a canvas that prints "Page x of y"."""
import io
import logging
from datetime import datetime
from html import escape
from pathlib import Path
from zoneinfo import ZoneInfo

from PIL import Image as PILImage
from PIL import ImageOps
from reportlab.lib import colors
from reportlab.lib.enums import TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.platypus import HRFlowable, Image, Paragraph, Spacer, Table, TableStyle
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.company.models import Company
from app.core.money import format_inr
from app.platform.documents.models import Document
from app.platform.documents.storage import get_storage

log = logging.getLogger(__name__)
ASSETS = Path(__file__).resolve().parent.parent / "assets"
RED = colors.HexColor("#d90000")
INK = colors.HexColor("#1f2937")
MUTED = colors.HexColor("#6b7280")
LINE = colors.HexColor("#e5e7eb")
TINT = colors.HexColor("#fef2f2")
IST = ZoneInfo("Asia/Kolkata")
PAGE = A4
MARGIN = 14 * mm

_ready = False


def fonts() -> None:
    global _ready
    if not _ready:
        pdfmetrics.registerFont(TTFont("DejaVu", str(ASSETS / "fonts" / "DejaVuSans.ttf")))
        pdfmetrics.registerFont(TTFont("DejaVu-Bold", str(ASSETS / "fonts" / "DejaVuSans-Bold.ttf")))
        pdfmetrics.registerFontFamily("DejaVu", normal="DejaVu", bold="DejaVu-Bold", italic="DejaVu",
                                      boldItalic="DejaVu-Bold")
        _ready = True


def styles() -> dict[str, ParagraphStyle]:
    base = ParagraphStyle("base", fontName="DejaVu", fontSize=8.5, leading=11.5, textColor=INK)
    return {
        "base": base,
        "small": ParagraphStyle("small", parent=base, fontSize=7.2, leading=9.4, textColor=MUTED),
        "cell": ParagraphStyle("cell", parent=base, fontSize=7.8, leading=10),
        "cellr": ParagraphStyle("cellr", parent=base, fontSize=7.8, leading=10, alignment=TA_RIGHT),
        "cellb": ParagraphStyle("cellb", parent=base, fontSize=7.8, leading=10, fontName="DejaVu-Bold"),
        "label": ParagraphStyle("label", parent=base, fontSize=7, leading=9, textColor=MUTED),
        "title": ParagraphStyle("title", parent=base, fontName="DejaVu-Bold", fontSize=15, leading=19),
        "h": ParagraphStyle("h", parent=base, fontName="DejaVu-Bold", fontSize=9.5, leading=13, textColor=RED,
                            spaceBefore=7, spaceAfter=3),
        "company": ParagraphStyle("company", parent=base, fontName="DejaVu-Bold", fontSize=13, leading=16,
                                  alignment=TA_RIGHT),
        "right": ParagraphStyle("right", parent=base, fontSize=7.2, leading=9.4, textColor=MUTED, alignment=TA_RIGHT),
        "rightb": ParagraphStyle("rightb", parent=base, fontSize=9, leading=12, alignment=TA_RIGHT,
                                 fontName="DejaVu-Bold"),
    }


def p(text: str | None, style: ParagraphStyle, dash: bool = True) -> Paragraph:
    return Paragraph(escape(text or ("—" if dash else "")).replace("\n", "<br/>"), style)


def money(v) -> str:
    return format_inr(v)


def flatten(im: PILImage.Image) -> PILImage.Image:
    """RGB on a WHITE background. Transparent pixels in a PNG are often stored as black; a plain convert("RGB")
    would turn a transparent logo background black. JPEG (used inside the PDF) has no transparency."""
    if im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info):
        im = im.convert("RGBA")
        bg = PILImage.new("RGB", im.size, (255, 255, 255))
        bg.paste(im, mask=im.getchannel("A"))
        return bg
    return im.convert("RGB")


def image(data: bytes, max_w: float, max_h: float) -> Image | None:
    try:
        with PILImage.open(io.BytesIO(data)) as im:
            im = flatten(ImageOps.exif_transpose(im))
            im.thumbnail((1400, 1400))
            out = io.BytesIO()
            im.save(out, "JPEG", quality=80, optimize=True)
            w, h = im.size
    except Exception:  # noqa: BLE001 - a bad image must never stop a document
        return None
    s = min(max_w / w, max_h / h)
    out.seek(0)
    return Image(out, width=w * s, height=h * s)


def company(db: Session) -> Company | None:
    return db.scalar(select(Company).where(Company.is_default.is_(True))) or db.scalar(select(Company))


def logo(db: Session, c: Company | None, size: float = 22 * mm) -> Image | None:
    if c and c.logo_document_id:
        doc = db.get(Document, c.logo_document_id)
        if doc is not None:
            try:
                img = image(get_storage().get(doc.storage_key), size, size)
                if img:
                    return img
            except Exception:  # noqa: BLE001 - fall back to the bundled logo
                log.warning("company logo could not be read from storage; using the bundled logo")
    f = ASSETS / "tce-logo.png"
    return image(f.read_bytes(), size, size) if f.exists() else None


def company_lines(c: Company | None) -> list[str]:
    if c is None:
        return []
    addr = ", ".join(x for x in (c.address_line1, c.address_line2, c.city, c.state, c.pincode) if x)
    contact = " · ".join(x for x in (c.phone, c.email, c.website) if x)
    tax = " · ".join(x for x in (f"GSTIN {c.gstin}" if c.gstin else None, f"PAN {c.pan}" if c.pan else None) if x)
    return [x for x in (c.tagline, addr, contact, tax) if x]


def letterhead(db: Session, st: dict, snapshot: dict | None = None) -> list:
    """Logo left, company name and details right, red rule. `snapshot` (frozen at issue) overrides live data."""
    c = company(db)
    name = (snapshot or {}).get("company_name") or (c.company_name if c else "Tesla Consulting Engineers")
    lines = (snapshot or {}).get("lines") or company_lines(c)
    right = [Paragraph(escape(name), st["company"])] + [Paragraph(escape(x), st["right"]) for x in lines]
    t = Table([[logo(db, c) or "", right]], colWidths=[28 * mm, None])
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                           ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    return [t, Spacer(1, 2 * mm), HRFlowable(width="100%", thickness=1.2, color=RED), Spacer(1, 4 * mm)]


def company_snapshot(db: Session) -> dict:
    c = company(db)
    if c is None:
        return {}
    return {"company_name": c.company_name, "legal_name": c.legal_name, "lines": company_lines(c),
            "gstin": c.gstin, "state_code": c.state_code, "state": c.state}
    # Bank details are not copied here (the account number is stored encrypted on the company only). An issued
    # document keeps them because its PDF is filed at the moment of issue.


def numbered_canvas(footer_left: str, watermark: str | None = None):
    """Canvas class that writes 'Page x of y' (needs the page count, so it buffers pages) and an optional
    diagonal watermark such as DRAFT."""
    generated = datetime.now(IST).strftime("%d %b %Y, %I:%M %p IST")

    class NumberedCanvas(rl_canvas.Canvas):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._pages = []

        def showPage(self):  # noqa: N802 - ReportLab API
            self._pages.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            total = len(self._pages)
            for state in self._pages:
                self.__dict__.update(state)
                self._decorate(total)
                super().showPage()
            super().save()

        def _decorate(self, total: int):
            w, _ = PAGE
            self.saveState()
            if watermark:
                self.setFont("DejaVu-Bold", 70)
                self.setFillColor(colors.Color(0.85, 0, 0, alpha=0.08))
                self.translate(w / 2, PAGE[1] / 2)
                self.rotate(40)
                self.drawCentredString(0, 0, watermark)
                self.rotate(-40)
                self.translate(-w / 2, -PAGE[1] / 2)
            self.setFont("DejaVu", 6.8)
            self.setFillColor(MUTED)
            self.drawString(MARGIN, 8 * mm, f"{footer_left} · generated {generated}")
            self.drawRightString(w - MARGIN, 8 * mm, f"Page {self._pageNumber} of {total}")
            self.restoreState()

    return NumberedCanvas
