"""Trigram (pg_trgm) GIN indexes for global search (Phase 10, migration 0010n).

`ILIKE '%text%'` cannot use an ordinary index; a trigram index makes it an index lookup, so search stays fast as the
tables grow. Customers, suppliers and items have had theirs since Phase 1 (declared on their models); the rest are
declared here, in one place, and attached to the tables when app.models imports this module.
"""
from sqlalchemy import Index

from app.costing.models import MaterialIssue
from app.crm.models import Enquiry, Lead
from app.finance.models import Invoice
from app.hr.models import Employee
from app.projects.models import Project, ProjectTask
from app.purchase.models import PurchaseOrder
from app.quotations.models import Quotation
from app.sales.models import SalesOrder

TRGM_COLUMNS = [
    (Lead, "title"), (Lead, "company_name"), (Enquiry, "subject"), (Quotation, "subject"), (SalesOrder, "subject"),
    (Project, "name"), (ProjectTask, "title"), (Employee, "full_name"), (Invoice, "invoice_number"),
    (PurchaseOrder, "po_number"), (MaterialIssue, "issued_to"),
]

INDEXES = [
    Index(f"ix_{model.__tablename__}_{col}_trgm", model.__table__.c[col], postgresql_using="gin",
          postgresql_ops={col: "gin_trgm_ops"})
    for model, col in TRGM_COLUMNS
]
