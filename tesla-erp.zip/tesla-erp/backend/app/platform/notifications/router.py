"""Notifications API: the bell, my notification settings, email status and test, and the daily alerts."""
import uuid
from datetime import UTC, datetime, timedelta
from typing import Annotated

from fastapi import APIRouter, Query
from pydantic import EmailStr, Field
from sqlalchemy import func, select, update
from sqlalchemy.dialects.postgresql import insert as pg_insert

from app.auth.deps import CurrentUser, Principal, require
from app.core.api import Schema, ok
from app.core.config import get_settings
from app.core.db import DbSession
from app.core.errors import AppError, NotFound
from app.platform.audit import service as audit
from app.platform.jobs.models import Job
from app.platform.notifications import alerts, channels, events
from app.platform.notifications.models import Notification, NotificationPreference
from app.platform.notifications.service import defaults, digest_users, preferences

router = APIRouter(prefix="/notifications", tags=["notifications"])


def _out(n: Notification) -> dict:
    return {"id": str(n.id), "event": n.event, "title": n.title, "body": n.body, "link": n.link,
            "created_at": n.created_at.isoformat(), "read": n.read_at is not None}


@router.get("")
def my_notifications(db: DbSession, p: CurrentUser, limit: int = Query(20, ge=1, le=100), unread_only: bool = False):
    stmt = select(Notification).where(Notification.user_id == p.id)
    if unread_only:
        stmt = stmt.where(Notification.read_at.is_(None))
    rows = db.scalars(stmt.order_by(Notification.created_at.desc()).limit(limit)).all()
    unread = db.scalar(select(func.count()).select_from(Notification)
                       .where(Notification.user_id == p.id, Notification.read_at.is_(None)))
    # The top bar's chat badge rides on this poll (one request a minute instead of two).
    from app.chat.service import total_unread

    return ok([_out(n) for n in rows], unread=unread, chat_unread=total_unread(db, p))


@router.post("/{notification_id}/read")
def mark_read(notification_id: uuid.UUID, db: DbSession, p: CurrentUser):
    n = db.get(Notification, notification_id)
    if n is None or n.user_id != p.id:
        raise NotFound("notification")
    n.read_at = n.read_at or datetime.now(UTC)
    return ok(_out(n))


@router.post("/read-all")
def mark_all_read(db: DbSession, p: CurrentUser):
    db.execute(update(Notification).where(Notification.user_id == p.id, Notification.read_at.is_(None))
               .values(read_at=datetime.now(UTC)))
    return ok({"ok": True})


# ------------------------------------------------------------------ my notification settings
def _prefs_out(db, p: Principal) -> dict:
    keys = list(events.EVENTS)
    prefs = preferences(db, [p.id], keys)
    avail = channels.available()
    return {
        "channels": avail,
        "email_address": p.user.email, "phone": p.user.phone,
        "digest": p.id in digest_users(db, [p.id]),
        "groups": [g for g in events.GROUPS if g != "System"],
        "events": [{"key": d.key, "label": d.label, "group": d.group, "description": d.description, "alert": d.alert,
                    **prefs[(p.id, d.key)], "default": defaults(d.key)}
                   for d in events.EVENTS.values() if d.group != "System"],   # test messages are not a choice
    }


class PrefIn(Schema):
    event: str = Field(max_length=60)
    in_app: bool = True
    email: bool = False
    whatsapp: bool = False
    sms: bool = False


class PrefsIn(Schema):
    items: list[PrefIn] = Field(default_factory=list, max_length=200)
    digest: bool | None = None


def _upsert(db, user_id: uuid.UUID, event: str, **vals) -> None:
    stmt = pg_insert(NotificationPreference).values(id=uuid.uuid4(), user_id=user_id, event=event, **vals)
    db.execute(stmt.on_conflict_do_update(index_elements=["user_id", "event"],
                                          set_={**vals, "updated_at": func.now()}))


@router.get("/preferences")
def my_preferences(db: DbSession, p: CurrentUser):
    return ok(_prefs_out(db, p))


@router.put("/preferences")
def save_preferences(body: PrefsIn, db: DbSession, p: CurrentUser):
    for it in body.items:
        if it.event not in events.EVENTS:
            raise AppError("UNKNOWN_EVENT", f"Unknown notification '{it.event}'.", details={"field": it.event})
        _upsert(db, p.id, it.event, in_app=it.in_app, email=it.email, whatsapp=it.whatsapp, sms=it.sms)
    if body.digest is not None:
        _upsert(db, p.id, events.DIGEST, in_app=True, email=body.digest, whatsapp=False, sms=False)
    db.flush()
    return ok(_prefs_out(db, p))


# ------------------------------------------------------------------ administration: email status and test
@router.get("/channels")
def channel_status(db: DbSession, _: Annotated[Principal, require("settings.read")]):
    s = get_settings()
    since = datetime.now(UTC) - timedelta(days=7)
    counts = dict(db.execute(select(Job.status, func.count()).where(Job.kind == "notification.deliver",
                                                                     Job.created_at >= since)
                             .group_by(Job.status)).all())
    last_error = db.scalar(select(Job.last_error).where(Job.kind == "notification.deliver", Job.status == "failed")
                           .order_by(Job.finished_at.desc()).limit(1))
    return ok({
        "email": {"configured": channels.get_channel("email") is not None, "host": s.smtp_host, "port": s.smtp_port,
                  "tls": s.smtp_tls, "sender": channels.EmailChannel().sender() or None,
                  "base_url": s.app_base_url},
        "whatsapp": {"configured": channels.get_channel("whatsapp") is not None, "provider": s.whatsapp_provider},
        "sms": {"configured": channels.get_channel("sms") is not None, "provider": s.sms_provider},
        "last_7_days": {"sent": counts.get("done", 0), "waiting": counts.get("pending", 0) + counts.get("running", 0),
                        "failed": counts.get("failed", 0)},
        "last_error": (last_error or "").strip().splitlines()[-1][:300] if last_error else None,
    })


class TestEmailIn(Schema):
    to: EmailStr | None = None


@router.post("/test-email")
def send_test_email(body: TestEmailIn, db: DbSession, p: Annotated[Principal, require("settings.update")]):
    """Sends straight away (not through the queue) so the administrator sees at once whether the settings work."""
    ch = channels.get_channel("email")
    if ch is None:
        raise AppError("EMAIL_NOT_SET_UP", "Email is not set up on the server. Add SMTP_HOST, SMTP_PORT, SMTP_USER, "
                                           "SMTP_PASSWORD and SMTP_FROM to the server settings and restart.")
    to = str(body.to or p.user.email)
    name = p.user.full_name if to.lower() == p.user.email.lower() else ""
    msg = channels.render(to=to, to_name=name, subject="Test email from the ERP", event="system.test",
                          intro="Email from the ERP is working. Notifications you switch on will arrive like this.",
                          lines=[("Test message", f"Sent by {p.user.full_name}", "/dashboard")])
    try:
        ch.send(msg)
    except Exception as exc:  # noqa: BLE001 - the reason is shown to the administrator, never the password
        raise AppError("EMAIL_FAILED", f"The mail server refused or could not be reached: {type(exc).__name__}: "
                                       f"{str(exc)[:200]}") from exc
    audit.record(db, action="test_email", entity_type="setting", entity_label="email", summary=f"Test email to {to}")
    return ok({"sent": True, "to": to})


# ------------------------------------------------------------------ daily alerts
@router.get("/alerts")
def alert_status(db: DbSession, _: Annotated[Principal, require("settings.read")]):
    return ok({"history": alerts.history(db), "alerts": [{"key": a.key, "label": events.EVENTS[a.event].label,
                                                         "setting": a.setting} for a in alerts.ALERTS]})


class RunIn(Schema):
    only: list[str] | None = None


@router.post("/alerts/run")
def run_alerts_now(body: RunIn, db: DbSession, p: Annotated[Principal, require("settings.update")]):
    """Runs today's alerts now instead of waiting for the set hour. Alerts already sent today are not repeated."""
    from app.crm.service import today

    if body.only and any(k not in alerts.BY_KEY for k in body.only):
        raise AppError("UNKNOWN_ALERT", "Unknown alert.")
    res = alerts.run_daily(db, p.company_id, today(), only=body.only)
    audit.record(db, action="run", entity_type="alerts", entity_label=today().isoformat(),
                 summary=", ".join(f"{r['alert']}: {r['items']}" for r in res if r.get("ran")) or "nothing new")
    return ok(res)
