import uuid
from datetime import UTC, datetime

from fastapi import APIRouter, Query
from sqlalchemy import func, select, update

from app.auth.deps import CurrentUser
from app.core.api import ok
from app.core.db import DbSession
from app.core.errors import NotFound
from app.platform.notifications.models import Notification

router = APIRouter(prefix="/notifications", tags=["notifications"])


def _out(n: Notification) -> dict:
    return {"id": str(n.id), "event": n.event, "title": n.title, "body": n.body, "link": n.link,
            "created_at": n.created_at.isoformat(), "read": n.read_at is not None}


@router.get("")
def my_notifications(db: DbSession, p: CurrentUser, limit: int = Query(20, ge=1, le=100), unread_only: bool = False):
    stmt = select(Notification).where(Notification.user_id == p.id)
    if unread_only:
        stmt = stmt.where(Notification.read_at.is_(None))
    rows = db.scalars(stmt.order_by(Notification.created_at.desc()).limit(limit)).all()
    unread = db.scalar(select(func.count()).select_from(Notification)
                       .where(Notification.user_id == p.id, Notification.read_at.is_(None)))
    return ok([_out(n) for n in rows], unread=unread)


@router.post("/{notification_id}/read")
def mark_read(notification_id: uuid.UUID, db: DbSession, p: CurrentUser):
    n = db.get(Notification, notification_id)
    if n is None or n.user_id != p.id:
        raise NotFound("notification")
    n.read_at = n.read_at or datetime.now(UTC)
    return ok(_out(n))


@router.post("/read-all")
def mark_all_read(db: DbSession, p: CurrentUser):
    db.execute(update(Notification).where(Notification.user_id == p.id, Notification.read_at.is_(None))
               .values(read_at=datetime.now(UTC)))
    return ok({"ok": True})
