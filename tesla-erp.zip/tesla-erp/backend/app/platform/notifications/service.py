"""Notify users in-app. Called inside the business transaction, so a notification exists only if the change
committed. Email/WhatsApp are later channels reading the same events (Phase 10)."""
import uuid
from collections.abc import Iterable

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.platform.notifications.models import Notification
from app.users.models import Role, User, UserRole


def notify(db: Session, user_ids: Iterable[uuid.UUID | None], *, event: str, title: str, body: str | None = None,
           link: str | None = None, exclude: uuid.UUID | None = None) -> int:
    ids = {u for u in user_ids if u and u != exclude}
    for uid in ids:
        db.add(Notification(user_id=uid, event=event, title=title[:200], body=(body or "")[:500] or None, link=link))
    return len(ids)


def users_with_roles(db: Session, role_codes: Iterable[str]) -> list[uuid.UUID]:
    return list(db.scalars(
        select(User.id).join(UserRole, UserRole.user_id == User.id).join(Role, Role.id == UserRole.role_id)
        .where(Role.code.in_(list(role_codes)), User.is_active.is_(True), Role.is_active.is_(True)).distinct()))
