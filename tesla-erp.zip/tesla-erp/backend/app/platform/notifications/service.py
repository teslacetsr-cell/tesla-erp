"""Notify users. Called inside the business transaction, so a notification (and its queued email) exists only if
the change committed (transactional outbox, Architecture §6.7).

For each recipient the person's preferences for the event decide:
  * in_app   → a row in `notifications` (the bell);
  * email / whatsapp / sms → a `notification.deliver` job; the background worker sends it with retries, so nobody
    waits for a mail server. Channels that are not set up on the server are skipped.
Daily alerts for someone who chose the daily digest are not emailed one by one; the digest bundles them.
"""
import uuid
from collections.abc import Iterable
from datetime import UTC, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.platform.jobs.service import enqueue, handler
from app.platform.notifications import channels, events
from app.platform.notifications.models import Notification, NotificationPreference
from app.users.models import Role, User, UserRole

EXTERNAL = ("email", "whatsapp", "sms")


def defaults(event: str) -> dict[str, bool]:
    d = events.get(event)
    return {"in_app": True, "email": d.email_default, "whatsapp": False, "sms": False}


def preferences(db: Session, user_ids: Iterable[uuid.UUID], event_keys: Iterable[str]) -> dict[tuple, dict]:
    """{(user_id, event): {in_app, email, whatsapp, sms}} for every pair, defaults filled in."""
    uids, keys = list(set(user_ids)), list(set(event_keys))
    out = {(u, k): defaults(k) for u in uids for k in keys}
    if uids and keys:
        for pref in db.scalars(select(NotificationPreference).where(NotificationPreference.user_id.in_(uids),
                                                                    NotificationPreference.event.in_(keys))):
            out[(pref.user_id, pref.event)] = {"in_app": pref.in_app, "email": pref.email,
                                               "whatsapp": pref.whatsapp, "sms": pref.sms}
    return out


def digest_users(db: Session, user_ids: Iterable[uuid.UUID]) -> set[uuid.UUID]:
    ids = list(set(user_ids))
    if not ids:
        return set()
    return set(db.scalars(select(NotificationPreference.user_id).where(
        NotificationPreference.user_id.in_(ids), NotificationPreference.event == events.DIGEST,
        NotificationPreference.email.is_(True))))


def notify(db: Session, user_ids: Iterable[uuid.UUID | None], *, event: str, title: str, body: str | None = None,
           link: str | None = None, exclude: uuid.UUID | None = None) -> int:
    ids = {u for u in user_ids if u and u != exclude}
    if not ids:
        return 0
    title, body = title[:200], (body or "")[:500] or None
    prefs = preferences(db, ids, [event])
    live = {c for c in EXTERNAL if channels.get_channel(c) is not None}
    wanted = {uid for uid in ids if any(prefs[(uid, event)][c] for c in live)}
    bundled = digest_users(db, wanted) if events.get(event).alert else set()
    for uid in ids:
        pref = prefs[(uid, event)]
        if pref["in_app"]:
            db.add(Notification(user_id=uid, event=event, title=title, body=body, link=link))
        for c in sorted(live):
            if pref[c] and not (c == "email" and uid in bundled):
                enqueue(db, "notification.deliver", {"channel": c, "user_id": str(uid), "event": event,
                                                     "title": title, "body": body, "link": link})
    return len(ids)


def users_with_roles(db: Session, role_codes: Iterable[str]) -> list[uuid.UUID]:
    return list(db.scalars(
        select(User.id).join(UserRole, UserRole.user_id == User.id).join(Role, Role.id == UserRole.role_id)
        .where(Role.code.in_(list(role_codes)), User.is_active.is_(True), Role.is_active.is_(True)).distinct()))


# ------------------------------------------------------------------ delivery (background worker)
def _address(user: User, channel: str) -> str | None:
    return user.email if channel == "email" else user.phone


@handler("notification.deliver")
def deliver(db: Session, payload: dict) -> None:
    ch = channels.get_channel(payload["channel"])
    if ch is None:
        return                                   # the channel was switched off since the job was queued
    user = db.get(User, uuid.UUID(payload["user_id"]))
    if user is None or not user.is_active or not _address(user, payload["channel"]):
        return
    if payload.get("kind") == "digest":
        msg = digest_message(db, user, payload)
        if msg is None:
            return
    else:
        msg = channels.render(to=_address(user, payload["channel"]), to_name=user.full_name,
                              subject=payload["title"], event=payload["event"],
                              lines=[(payload["title"], payload.get("body"), payload.get("link"))])
    ch.send(msg)


def digest_message(db: Session, user: User, payload: dict) -> channels.OutboundMessage | None:
    """Today's alerts for the person plus anything else unread from the last day, in one email."""
    since = datetime.fromisoformat(payload["since"]) if payload.get("since") else datetime.now(UTC) - timedelta(days=1)
    rows = list(db.scalars(select(Notification).where(Notification.user_id == user.id, Notification.created_at >= since)
                           .order_by(Notification.created_at.desc()).limit(60)))
    alerts = [n for n in rows if events.get(n.event).alert]
    others = [n for n in rows if not events.get(n.event).alert and n.read_at is None]
    if not alerts and not others:
        return None
    lines = [(n.title, n.body, n.link) for n in alerts] + [(n.title, n.body, n.link) for n in others[:20]]
    day = payload.get("day") or datetime.now(UTC).date().isoformat()
    intro = (f"Your summary for {datetime.fromisoformat(day):%d %b %Y}: {len(alerts)} alert(s)"
             + (f" and {len(others)} unread notification(s)." if others else "."))
    return channels.render(to=user.email, to_name=user.full_name, subject=f"Daily summary — {len(lines)} item(s)",
                           lines=lines, intro=intro, event=events.DIGEST)
