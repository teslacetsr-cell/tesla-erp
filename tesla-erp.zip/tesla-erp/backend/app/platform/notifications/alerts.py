"""Daily scheduled alerts (Spec §31; plan Phase 10): overdue invoices, supplier bills due, late projects, projects
without site reports, low stock, overdue tasks, approvals waiting, late purchase orders and open RFQs past their
reply date — plus the optional daily digest email.

The worker calls `maybe_run()` every few minutes; once the India time passes `alerts.run_hour` it runs every alert
switched on in Administration → Settings → Alerts. Each person gets ONE notification per alert per day summarising
their items (not one per invoice), linked to the page where they act on it.

Idempotent per day: an alert first claims its (alert, date) row in `alert_runs`; a second run the same day — another
worker, a restart, the "Run now" button — finds the row and does nothing.
"""
import logging
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal

from sqlalchemy import and_, func, or_, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from app.core.money import format_inr
from app.platform.notifications import channels, events
from app.platform.notifications.models import AlertRun, NotificationPreference
from app.platform.notifications.service import enqueue, notify, users_with_roles
from app.platform.settings import service as settings
from app.users.models import User

log = logging.getLogger("alerts")
Z = Decimal("0")


@dataclass
class Hit:
    """One thing that needs attention, and who should hear about it."""
    label: str
    users: set = field(default_factory=set)
    amount: Decimal = Z
    days: int = 0


@dataclass(frozen=True)
class AlertDef:
    key: str                  # alert_runs.alert and the event "alert.<key>"
    setting: str              # on/off switch in Settings → Alerts
    noun: tuple[str, str]     # ("customer invoice overdue", "customer invoices overdue")
    link: str
    find: Callable[[Session, date, uuid.UUID], list[Hit]]
    money: bool = False

    @property
    def event(self) -> str:
        return f"alert.{self.key}"


def _n(v: Decimal) -> str:
    return "₹" + format_inr(v).removesuffix(".00")


def _int(db: Session, cid: uuid.UUID, key: str) -> int:
    return int(settings.get_setting(db, cid, key))


# ------------------------------------------------------------------ the alerts
def invoices_overdue(db: Session, day: date, cid: uuid.UUID) -> list[Hit]:
    from app.customers.models import Customer
    from app.finance.models import Invoice
    from app.sales.models import SalesOrder

    grace = _int(db, cid, "alerts.invoice_overdue_days")
    bal = Invoice.grand_total - Invoice.received - Invoice.credited
    rows = db.execute(
        select(Invoice.invoice_number, Customer.customer_name, bal, Invoice.due_date,
               func.coalesce(SalesOrder.sales_person_id, Customer.assigned_sales_person_id))
        .join(Customer, Customer.id == Invoice.customer_id)
        .outerjoin(SalesOrder, SalesOrder.id == Invoice.sales_order_id)
        .where(Invoice.status == "issued", Invoice.payment_status != "paid", bal > 0,
               Invoice.due_date < day - timedelta(days=grace))
        .order_by(Invoice.due_date)).all()
    accounts = set(users_with_roles(db, ["ACCOUNTS"]))
    return [Hit(f"{num} · {cust} · {_n(b)} · {(day - due).days} days", accounts | {sp}, Decimal(b), (day - due).days)
            for num, cust, b, due, sp in rows]


def bills_due(db: Session, day: date, cid: uuid.UUID) -> list[Hit]:
    from app.finance.models import SupplierInvoice
    from app.suppliers.models import Supplier

    ahead = _int(db, cid, "alerts.bill_due_days")
    bal = SupplierInvoice.grand_total - SupplierInvoice.paid
    rows = db.execute(
        select(SupplierInvoice.bill_number, Supplier.supplier_name, bal, SupplierInvoice.due_date)
        .join(Supplier, Supplier.id == SupplierInvoice.supplier_id)
        .where(SupplierInvoice.status == "posted", SupplierInvoice.payment_status != "paid", bal > 0,
               SupplierInvoice.due_date <= day + timedelta(days=ahead))
        .order_by(SupplierInvoice.due_date)).all()
    accounts = set(users_with_roles(db, ["ACCOUNTS"]))

    def when(due: date) -> str:
        d = (due - day).days
        return f"overdue {-d} days" if d < 0 else "due today" if d == 0 else f"due {due:%d %b}"
    return [Hit(f"{num} · {sup} · {_n(b)} · {when(due)}", accounts, Decimal(b)) for num, sup, b, due in rows]


def _pm_or_managers(db: Session, pm: uuid.UUID | None) -> set:
    return {pm} if pm else set(users_with_roles(db, ["MANAGER"]))


def projects_late(db: Session, day: date, cid: uuid.UUID) -> list[Hit]:
    from app.projects.models import Project

    rows = db.execute(select(Project.project_number, Project.name, Project.target_end_date, Project.project_manager_id,
                             Project.progress_pct)
                      .where(Project.status.in_(("planning", "active")), Project.target_end_date < day)
                      .order_by(Project.target_end_date)).all()
    return [Hit(f"{num} {name} · target {t:%d %b %Y} · {pct}% done", _pm_or_managers(db, pm), days=(day - t).days)
            for num, name, t, pm, pct in rows]


def site_report_gap(db: Session, day: date, cid: uuid.UUID) -> list[Hit]:
    from app.projects.models import Project, SiteReport

    n = _int(db, cid, "alerts.site_report_days")
    last = (select(SiteReport.project_id.label("pid"), func.max(SiteReport.report_date).label("d"))
            .group_by(SiteReport.project_id).subquery())
    cutoff = day - timedelta(days=n)
    rows = db.execute(select(Project.project_number, Project.name, last.c.d, Project.project_manager_id)
                      .outerjoin(last, last.c.pid == Project.id)
                      .where(Project.status == "active",
                             func.coalesce(Project.start_date, func.date(Project.created_at)) < cutoff,
                             or_(last.c.d.is_(None), last.c.d < cutoff))
                      .order_by(last.c.d.nulls_first())).all()
    return [Hit(f"{num} {name} · " + (f"last report {d:%d %b}" if d else "no site report yet"),
                _pm_or_managers(db, pm)) for num, name, d, pm in rows]


def low_stock(db: Session, day: date, cid: uuid.UUID) -> list[Hit]:
    from app.inventory.models import StockBalance
    from app.products.models import Item, Unit

    bal = select(StockBalance.item_id.label("item_id"), func.sum(StockBalance.quantity).label("q")) \
        .group_by(StockBalance.item_id).subquery()
    qty = func.coalesce(bal.c.q, 0)
    rows = db.execute(select(Item.item_code, Item.item_name, Unit.code, qty, Item.minimum_stock, Item.reorder_level)
                      .join(Unit, Unit.id == Item.unit_id).outerjoin(bal, bal.c.item_id == Item.id)
                      .where(Item.is_active.is_(True), Item.item_type == "goods",
                             or_(and_(Item.minimum_stock > 0, qty < Item.minimum_stock),
                                 and_(Item.reorder_level > 0, qty < Item.reorder_level)))
                      .order_by(qty, Item.item_name)).all()
    people = set(users_with_roles(db, ["STORE", "PURCHASE"]))

    def q(v) -> str:
        return f"{Decimal(v).normalize():f}"
    return [Hit(f"{code} {name} · " + ("OUT OF STOCK" if s <= 0 else f"{q(s)} {u} left")
                + f" (min {q(max(mn, ro))})", people) for code, name, u, s, mn, ro in rows]


def tasks_overdue(db: Session, day: date, cid: uuid.UUID) -> list[Hit]:
    from app.projects.models import Project, ProjectTask

    rows = db.execute(select(ProjectTask.title, ProjectTask.due_date, ProjectTask.assigned_to, Project.project_number,
                             Project.project_manager_id)
                      .join(Project, Project.id == ProjectTask.project_id)
                      .where(ProjectTask.status != "done", ProjectTask.due_date < day,
                             Project.status.not_in(("completed", "cancelled")))
                      .order_by(ProjectTask.due_date)).all()
    return [Hit(f"{title} · {num} · due {due:%d %b}", {a, pm}, days=(day - due).days)
            for title, due, a, num, pm in rows]


def approvals_waiting(db: Session, day: date, cid: uuid.UUID) -> list[Hit]:
    from app.platform.approvals import service as approvals
    from app.platform.approvals.models import ApprovalRequest

    n = _int(db, cid, "alerts.approval_waiting_days")
    cutoff = datetime.combine(day, datetime.min.time(), tzinfo=UTC) - timedelta(days=n)
    out = []
    for req in db.scalars(select(ApprovalRequest).where(ApprovalRequest.status == "pending",
                                                        ApprovalRequest.requested_at < cutoff)
                          .order_by(ApprovalRequest.requested_at)):
        h = approvals.HANDLERS.get(req.entity_type)
        who = set(approvals._approvers(db, req.steps[req.current_step], req)) - {req.requested_by}
        label = f"{h.label if h else req.entity_type.replace('_', ' ').capitalize()} {req.entity_label}"
        out.append(Hit(f"{label} · waiting since {req.requested_at.astimezone(UTC):%d %b}", who))
    return out


def pos_late(db: Session, day: date, cid: uuid.UUID) -> list[Hit]:
    from app.purchase.models import PurchaseOrder
    from app.suppliers.models import Supplier

    grace = _int(db, cid, "alerts.po_late_days")
    rows = db.execute(select(PurchaseOrder.po_number, Supplier.supplier_name, PurchaseOrder.expected_delivery,
                             PurchaseOrder.created_by)
                      .join(Supplier, Supplier.id == PurchaseOrder.supplier_id)
                      .where(PurchaseOrder.status.in_(("approved", "sent", "partially_received")),
                             PurchaseOrder.expected_delivery < day - timedelta(days=grace))
                      .order_by(PurchaseOrder.expected_delivery)).all()
    purchase = set(users_with_roles(db, ["PURCHASE"]))
    return [Hit(f"{num} · {sup} · expected {d:%d %b}", purchase | {by}, days=(day - d).days)
            for num, sup, d, by in rows]


def rfqs_due(db: Session, day: date, cid: uuid.UUID) -> list[Hit]:
    from app.purchase.rfq_models import Rfq

    rows = db.execute(select(Rfq.rfq_number, Rfq.due_date, Rfq.created_by)
                      .where(Rfq.status.in_(("sent", "quotes_received")), Rfq.due_date < day)
                      .order_by(Rfq.due_date)).all()
    purchase = set(users_with_roles(db, ["PURCHASE"]))
    return [Hit(f"{num or 'RFQ'} · replies were due {d:%d %b}", purchase | {by}) for num, d, by in rows]


ALERTS: list[AlertDef] = [
    AlertDef("invoice_overdue", "alerts.invoice_overdue", ("customer invoice overdue", "customer invoices overdue"),
             "/finance/receivables", invoices_overdue, money=True),
    AlertDef("bill_due", "alerts.bill_due", ("supplier bill due", "supplier bills due"), "/finance/payables",
             bills_due, money=True),
    AlertDef("project_late", "alerts.project_late", ("project past its target date", "projects past their target date"),
             "/projects", projects_late),
    AlertDef("site_report_gap", "alerts.site_report_gap", ("project without a recent site report",
                                                           "projects without a recent site report"),
             "/projects/site-reports", site_report_gap),
    AlertDef("low_stock", "inventory.low_stock_alerts", ("item low or out of stock", "items low or out of stock"),
             "/reports/view?key=low_stock", low_stock),
    AlertDef("task_overdue", "alerts.task_overdue", ("task overdue", "tasks overdue"), "/projects/tasks",
             tasks_overdue),
    AlertDef("approval_waiting", "alerts.approval_waiting", ("approval waiting for you", "approvals waiting for you"),
             "/approvals", approvals_waiting),
    AlertDef("po_late", "alerts.po_late", ("purchase order past delivery date", "purchase orders past delivery date"),
             "/purchase/orders", pos_late),
    AlertDef("rfq_due", "alerts.rfq_due", ("request for quotation past reply date",
                                           "requests for quotation past reply date"), "/purchase/rfqs", rfqs_due),
]
BY_KEY = {a.key: a for a in ALERTS}
assert all(a.event in events.EVENTS for a in ALERTS)


# ------------------------------------------------------------------ running
def _claim(db: Session, key: str, day: date) -> uuid.UUID | None:
    stmt = (pg_insert(AlertRun).values(id=uuid.uuid4(), alert=key, run_date=day)
            .on_conflict_do_nothing(index_elements=["alert", "run_date"]).returning(AlertRun.id))
    return db.execute(stmt).scalar()


def _send(db: Session, a: AlertDef, hits: list[Hit]) -> int:
    active = set(db.scalars(select(User.id).where(User.is_active.is_(True))))
    per_user: dict[uuid.UUID, list[Hit]] = {}
    for h in hits:
        for u in h.users:
            if u in active:
                per_user.setdefault(u, []).append(h)
    for uid, mine in per_user.items():
        n = len(mine)
        title = f"{n} {a.noun[0] if n == 1 else a.noun[1]}"
        if a.money:
            title += f" — {_n(sum((h.amount for h in mine), Z))}"
        shown = "; ".join(h.label for h in mine[:4])
        body = shown + (f"; and {n - 4} more" if n > 4 else "")
        notify(db, [uid], event=a.event, title=title, body=body, link=a.link)
    return len(per_user)


def run_daily(db: Session, company_id: uuid.UUID, day: date, only: list[str] | None = None) -> list[dict]:
    """Run every alert that is on and not yet run for `day`. Each alert runs in its own savepoint: one failing alert
    is logged and retried on the next pass, without stopping the others. The caller commits."""
    out = []
    for a in ALERTS:
        if only and a.key not in only:
            continue
        on = bool(settings.get_setting(db, company_id, a.setting))
        row = {"alert": a.key, "label": events.EVENTS[a.event].label, "enabled": on, "ran": False,
               "items": 0, "recipients": 0}
        out.append(row)
        if not on:
            continue
        try:
            with db.begin_nested():
                run_id = _claim(db, a.key, day)
                if run_id is None:
                    row["already_ran"] = True
                    continue
                hits = a.find(db, day, company_id)
                sent = _send(db, a, hits) if hits else 0
                run = db.get(AlertRun, run_id)
                run.items, run.recipients = len(hits), sent
                row.update(ran=True, items=len(hits), recipients=sent)
        except Exception:  # noqa: BLE001 - one broken alert must not stop the rest
            log.exception("alert %s failed", a.key)
            row["error"] = True
    if not only:
        row = queue_digests(db, day)
        if row:
            out.append(row)
    return out


def queue_digests(db: Session, day: date) -> dict | None:
    """One summary email per person who chose the daily digest (My notification settings)."""
    if channels.get_channel("email") is None:
        return None
    with db.begin_nested():
        run_id = _claim(db, "digest", day)
        if run_id is None:
            return {"alert": "digest", "label": "Daily summary email", "enabled": True, "ran": False,
                    "already_ran": True, "items": 0, "recipients": 0}
        users = list(db.scalars(select(User.id).join(NotificationPreference, NotificationPreference.user_id == User.id)
                                .where(NotificationPreference.event == events.DIGEST,
                                       NotificationPreference.email.is_(True), User.is_active.is_(True))))
        since = (datetime.now(UTC) - timedelta(hours=24)).isoformat()
        for uid in users:
            enqueue(db, "notification.deliver", {"channel": "email", "user_id": str(uid), "kind": "digest",
                                                 "event": events.DIGEST, "since": since, "day": day.isoformat()})
        db.get(AlertRun, run_id).recipients = len(users)
    return {"alert": "digest", "label": "Daily summary email", "enabled": True, "ran": True, "items": len(users),
            "recipients": len(users)}


_checked: dict[str, float] = {}


def maybe_run(session_factory, company_id: uuid.UUID | None = None) -> list[dict] | None:
    """Called from the worker loop: runs today's alerts once the configured hour has passed (India time)."""
    import time

    from app.auth.deps import default_company_id
    from app.crm.service import now

    t = now()
    day = t.date().isoformat()
    if _checked.get(day, 0) > time.monotonic():
        return None
    _checked.clear()
    _checked[day] = time.monotonic() + 300       # look again in 5 minutes at most
    with session_factory() as db:
        cid = company_id or default_company_id(db)
        if t.hour < int(settings.get_setting(db, cid, "alerts.run_hour")):
            return None
        done = set(db.scalars(select(AlertRun.alert).where(AlertRun.run_date == t.date())))
        wanted = {a.key for a in ALERTS if settings.get_setting(db, cid, a.setting)}
        if channels.get_channel("email") is not None:
            wanted.add("digest")
        if wanted <= done:
            _checked[day] = float("inf")          # nothing more to do today
            return None
        res = run_daily(db, cid, t.date())
        db.commit()
    ran = [r for r in res if r.get("ran")]
    if ran:
        log.info("daily alerts for %s: %s", day, ", ".join(f"{r['alert']}={r['items']}" for r in ran))
    return res


def history(db: Session, days: int = 7) -> list[dict]:
    since = date.today() - timedelta(days=days)
    rows = db.scalars(select(AlertRun).where(AlertRun.run_date >= since)
                      .order_by(AlertRun.run_date.desc(), AlertRun.alert)).all()
    labels = {a.key: events.EVENTS[a.event].label for a in ALERTS} | {"digest": "Daily summary email"}
    return [{"alert": r.alert, "label": labels.get(r.alert, r.alert), "run_date": r.run_date.isoformat(),
             "ran_at": r.ran_at.isoformat(), "items": r.items, "recipients": r.recipients} for r in rows]
