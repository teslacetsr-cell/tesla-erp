"""The event catalogue: every business event that tells someone something (Spec §31).

Business code calls `notify(db, users, event="...")` with one of these keys. Each person chooses, per event, whether
it shows in the bell (in-app) and whether it is also emailed (My notification settings). `in_app` is on for every
event by default; `email` is on by default only for the events people must not miss.

A test (tests/test_notifications.py) checks that every `notify(... event=...)` in the code is listed here.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class EventDef:
    key: str
    label: str
    group: str
    description: str
    email_default: bool = False
    alert: bool = False       # a daily scheduled alert (can be bundled into the daily digest email)


GROUPS = ("Approvals", "Projects & tasks", "Purchase & stores", "Finance", "HR", "Team chat", "Daily alerts", "System")

_DEFS = [
    # approvals (any document type: quotation, PR, PO, stock adjustment, expense, supplier bill, material issue, leave)
    EventDef("approval.requested", "Approval needed", "Approvals",
             "A document is waiting for your approval.", email_default=True),
    EventDef("approval.approved", "Your request was approved", "Approvals",
             "A document you sent for approval was fully approved.", email_default=True),
    EventDef("approval.rejected", "Your request was rejected", "Approvals",
             "A document you sent for approval was rejected, with the reason.", email_default=True),
    # projects & tasks
    EventDef("project.assigned", "Added to a project", "Projects & tasks",
             "You were made project manager or added to a project team."),
    EventDef("project.status", "Project status changed", "Projects & tasks",
             "A project you are on was put on hold, completed, cancelled or restarted."),
    EventDef("task.assigned", "Task assigned to you", "Projects & tasks",
             "A project task was given to you.", email_default=True),
    EventDef("task.blocked", "Task blocked", "Projects & tasks", "A task on your project is blocked (to the PM)."),
    EventDef("task.done", "Task completed", "Projects & tasks", "A task on your project was completed (to the PM)."),
    EventDef("issue.raised", "Site issue raised", "Projects & tasks", "An issue was raised on your project."),
    EventDef("issue.status", "Site issue resolved or closed", "Projects & tasks",
             "An issue you raised or that is on your project changed status."),
    EventDef("site_report.hindrance", "Hindrance reported", "Projects & tasks",
             "A daily site report on your project mentions a hindrance."),
    # purchase & stores
    EventDef("material_request.submitted", "Material request submitted", "Purchase & stores",
             "A new material request is waiting for stores / purchase."),
    EventDef("material_request.reject", "Your material request was rejected", "Purchase & stores",
             "Stores or purchase rejected your material request."),
    EventDef("material_request.close", "Your material request was closed", "Purchase & stores",
             "Stores or purchase closed your material request."),
    EventDef("purchase_request.approved", "Purchase request ready to order", "Purchase & stores",
             "A purchase request was approved and can be ordered."),
    EventDef("grn.posted", "Goods received", "Purchase & stores",
             "Goods were received against a purchase order you raised or for your project."),
    EventDef("material_issue.submitted", "Material issue to post", "Purchase & stores",
             "A material issue is waiting for the store to approve and post."),
    EventDef("material_issue.posted", "Material issued to your project", "Purchase & stores",
             "Material was issued from the store to your project."),
    EventDef("stock.mismatch", "Stock check found a difference", "Purchase & stores",
             "The nightly stock check found balances that differ from the stock ledger (administrators).",
             email_default=True),
    # finance
    EventDef("expense.approved", "Expense approved — to pay", "Finance",
             "An expense claim was approved and is waiting for payment (accounts)."),
    EventDef("expense.paid", "Your expense was paid", "Finance", "Your expense claim was paid."),
    EventDef("supplier_payment.created", "Supplier payment made", "Finance",
             "A payment to a supplier was recorded (directors)."),
    # HR
    EventDef("leave.approved", "Your leave was approved", "HR", "Your leave request was approved.",
             email_default=True),
    EventDef("leave.cancelled", "Your leave was cancelled", "HR", "HR cancelled your leave.", email_default=True),
    # daily alerts (scheduled, once a day; Administration → Settings → Alerts switches each one on or off)
    EventDef("alert.invoice_overdue", "Customer invoices overdue", "Daily alerts",
             "Issued invoices past their due date and not fully paid (accounts, and the sales person of the order).",
             alert=True),
    EventDef("alert.bill_due", "Supplier bills due", "Daily alerts",
             "Supplier bills due in the next few days or already overdue (accounts).", alert=True),
    EventDef("alert.project_late", "Projects past target date", "Daily alerts",
             "Your open projects whose target completion date has passed (project manager).", alert=True),
    EventDef("alert.site_report_gap", "No site report recently", "Daily alerts",
             "Your active projects with no daily site report for several days (project manager).", alert=True),
    EventDef("alert.low_stock", "Low or out of stock", "Daily alerts",
             "Items below their minimum or reorder level (stores and purchase).", alert=True),
    EventDef("alert.task_overdue", "Tasks overdue", "Daily alerts",
             "Open tasks past their due date (the person assigned, and the project manager).", alert=True),
    EventDef("alert.approval_waiting", "Approvals waiting too long", "Daily alerts",
             "Requests (leave, purchase, expenses…) waiting for your decision for more than a few days.",
             alert=True),
    EventDef("alert.po_late", "Purchase orders past delivery date", "Daily alerts",
             "Purchase orders not fully received by the expected delivery date (purchase).", alert=True),
    EventDef("alert.rfq_due", "Vendor quotations past due date", "Daily alerts",
             "Requests for quotation still open after the date suppliers were asked to reply by (purchase).",
             alert=True),
    # team chat
    EventDef("chat.mention", "Mentioned in chat", "Team chat",
             "Someone mentioned you (@name) in a chat message."),
    # Tally
    EventDef("tally.failed", "Tally did not accept an entry", "Finance",
             "The Tally connector sent an entry that Tally refused (accounts).", email_default=True),
    # system
    EventDef("system.test", "Test message", "System", "A test sent by an administrator from Settings.",
             email_default=True),
]

EVENTS: dict[str, EventDef] = {d.key: d for d in _DEFS}
DIGEST = "digest.daily"   # preference key for "one summary email a day instead of separate alert emails"


def get(key: str) -> EventDef:
    """The definition for an event; unknown events (should not happen — a test guards it) are in-app only."""
    return EVENTS.get(key) or EventDef(key, key.replace(".", " ").replace("_", " ").capitalize(), "System", "")
