"""Delivery channels for notifications outside the ERP: email (SMTP) now; WhatsApp and SMS through adapters.

Extension point — connecting a real WhatsApp / SMS provider:
  1. write a class with `name`, `configured()` and `send(msg)` (see `Channel`), e.g. `MetaWhatsAppChannel` calling
     the provider's HTTPS API with a key read from the environment (never stored or logged);
  2. add its name to `whatsapp_provider` / `sms_provider` in app/core/config.py and return it from `get_channel()`.
Nothing in the business code changes: `notify()` already queues a delivery for every channel a person switched on.

`send()` runs in the background worker. It raises on failure; the job queue then retries with back-off
(1, 2, 4, 8 minutes) and finally marks the delivery failed (Administration → Settings shows failures).
"""
import html
import logging
import smtplib
import ssl
from dataclasses import dataclass
from email.message import EmailMessage
from email.utils import formataddr, make_msgid, parseaddr

from app.core.config import get_settings

log = logging.getLogger("notifications")
CHANNELS = ("email", "whatsapp", "sms")


@dataclass
class OutboundMessage:
    to: str                 # email address or phone number
    to_name: str
    subject: str
    text: str               # plain text body
    html: str | None = None
    event: str = ""


class Channel:
    name = "base"

    def configured(self) -> bool:
        raise NotImplementedError

    def send(self, msg: OutboundMessage) -> None:
        raise NotImplementedError


class EmailChannel(Channel):
    """SMTP with STARTTLS (587), implicit TLS (465) or plain (a relay on the same machine only)."""

    name = "email"

    def configured(self) -> bool:
        s = get_settings()
        return bool(s.smtp_host and (s.smtp_from or s.smtp_user))

    def sender(self) -> str:
        s = get_settings()
        return s.smtp_from or s.smtp_user or ""

    def build(self, msg: OutboundMessage) -> EmailMessage:
        m = EmailMessage()
        name, addr = parseaddr(self.sender())
        m["From"] = formataddr((name or get_settings().app_name, addr))
        m["To"] = formataddr((msg.to_name, msg.to)) if msg.to_name else msg.to
        m["Subject"] = msg.subject
        m["Message-ID"] = make_msgid(domain=addr.split("@")[-1] if "@" in addr else None)
        m["Auto-Submitted"] = "auto-generated"
        m.set_content(msg.text)
        if msg.html:
            m.add_alternative(msg.html, subtype="html")
        return m

    def send(self, msg: OutboundMessage) -> None:
        s = get_settings()
        if not self.configured():
            raise RuntimeError("Email is not set up (SMTP_HOST / SMTP_FROM).")
        message = self.build(msg)
        ctx = ssl.create_default_context()
        if s.smtp_tls == "ssl":
            server: smtplib.SMTP = smtplib.SMTP_SSL(s.smtp_host, s.smtp_port, timeout=s.smtp_timeout_seconds,
                                                    context=ctx)
        else:
            server = smtplib.SMTP(s.smtp_host, s.smtp_port, timeout=s.smtp_timeout_seconds)
        try:
            server.ehlo()
            if s.smtp_tls == "starttls":
                server.starttls(context=ctx)
                server.ehlo()
            if s.smtp_user and s.smtp_password:
                server.login(s.smtp_user, s.smtp_password)
            server.send_message(message)
        finally:
            try:
                server.quit()
            except (smtplib.SMTPException, OSError):
                pass
        log.info("email sent: event=%s to=%s", msg.event, _mask(msg.to))


class LogChannel(Channel):
    """Stand-in for WhatsApp / SMS until a provider is chosen: logs that a message would be sent (recipient masked,
    no message text), so the wiring and preferences can be tested end to end."""

    def __init__(self, name: str):
        self.name = name

    def configured(self) -> bool:
        return True

    def send(self, msg: OutboundMessage) -> None:
        log.info("%s (log only, no provider): event=%s to=%s", self.name, msg.event, _mask(msg.to))


def _mask(addr: str) -> str:
    if "@" in addr:
        user, _, dom = addr.partition("@")
        return f"{user[:2]}***@{dom}"
    return f"***{addr[-3:]}" if addr else ""


def get_channel(name: str) -> Channel | None:
    """The adapter for a channel, or None when the channel is switched off."""
    s = get_settings()
    if name == "email":
        ch = EmailChannel()
        return ch if ch.configured() else None
    if name == "whatsapp":
        return LogChannel("whatsapp") if s.whatsapp_provider == "log" else None
    if name == "sms":
        return LogChannel("sms") if s.sms_provider == "log" else None
    return None


def available() -> dict[str, bool]:
    return {c: get_channel(c) is not None for c in CHANNELS}


# ------------------------------------------------------------------ message text
def absolute(link: str | None) -> str | None:
    base = (get_settings().app_base_url or "").rstrip("/")
    if not link:
        return base or None
    if link.startswith("http"):
        return link
    return f"{base}{link}" if base else None


def render(*, to: str, to_name: str, subject: str, lines: list[tuple[str, str | None, str | None]],
           intro: str | None = None, event: str = "") -> OutboundMessage:
    """A plain-text and a simple HTML email. `lines` = [(title, body, link)…]; links are made absolute with
    APP_BASE_URL so the person can click straight into the ERP."""
    s = get_settings()
    first = to_name.split(" ")[0] if to_name else ""
    text = [f"Hello {first}," if first else "Hello,", ""]
    if intro:
        text += [intro, ""]
    parts = []
    for title, body, link in lines:
        url = absolute(link)
        text.append(f"• {title}")
        if body:
            text.append(f"  {body}")
        if url:
            text.append(f"  {url}")
        text.append("")
        parts.append(
            f'<tr><td style="padding:10px 0;border-bottom:1px solid #eee">'
            f'<div style="font-weight:600;color:#111">{html.escape(title)}</div>'
            + (f'<div style="color:#444;margin-top:2px">{html.escape(body)}</div>' if body else "")
            + (f'<div style="margin-top:6px"><a href="{html.escape(url)}" style="color:#b91c1c">Open in the ERP</a></div>'
               if url else "")
            + "</td></tr>")
    settings_url = absolute("/account/notifications")
    footer = "You get this email because of your notification settings in the ERP."
    text += ["—", s.app_name, footer + (f" Change them at {settings_url}" if settings_url else "")]
    body_html = (
        '<!doctype html><html><body style="margin:0;background:#f6f6f6;font-family:Arial,Helvetica,sans-serif;'
        'font-size:14px;color:#222">'
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:20px">'
        '<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:#fff;'
        'border-top:4px solid #b91c1c;border-radius:6px;padding:20px">'
        f'<tr><td style="font-size:13px;color:#b91c1c;font-weight:700;padding-bottom:12px">{html.escape(s.app_name)}</td></tr>'
        f'<tr><td style="padding-bottom:8px">{html.escape("Hello " + first + "," if first else "Hello,")}</td></tr>'
        + (f'<tr><td style="padding-bottom:8px">{html.escape(intro)}</td></tr>' if intro else "")
        + f'<tr><td><table role="presentation" width="100%" cellpadding="0" cellspacing="0">{"".join(parts)}</table></td></tr>'
        + f'<tr><td style="padding-top:16px;font-size:12px;color:#777">{html.escape(footer)}'
        + (f' <a href="{html.escape(settings_url)}" style="color:#777">Change them</a>.' if settings_url else "")
        + "</td></tr></table></td></tr></table></body></html>")
    return OutboundMessage(to=to, to_name=to_name, subject=subject, text="\n".join(text), html=body_html, event=event)
