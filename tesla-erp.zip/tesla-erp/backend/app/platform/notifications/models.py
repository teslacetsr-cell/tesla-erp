import uuid
from datetime import date, datetime

from sqlalchemy import Boolean, Date, DateTime, ForeignKey, Index, Integer, String, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.models import Base


class Notification(Base):
    """In-app notification (Spec §31). One row per recipient; the bell shows unread ones.
    `event` is the business event (e.g. approval.requested); see events.py for the catalogue."""

    __tablename__ = "notifications"
    __table_args__ = (Index("ix_notifications_user_unread", "user_id", "created_at", postgresql_where="read_at is null"),
                      Index("ix_notifications_user_created", "user_id", "created_at"))

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    event: Mapped[str] = mapped_column(String(60), nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    body: Mapped[str | None] = mapped_column(String(500))
    link: Mapped[str | None] = mapped_column(String(300))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    read_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class NotificationPreference(Base):
    """A person's choice for one event: show it in the bell (in_app) and/or send it by email, WhatsApp or SMS.
    No row = the event's defaults (in-app on; email per the event catalogue). The pseudo-event `digest.daily`
    holds the "one daily summary email" choice in `email`."""

    __tablename__ = "notification_preferences"
    __table_args__ = (UniqueConstraint("user_id", "event"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    event: Mapped[str] = mapped_column(String(60), nullable=False)
    in_app: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")
    email: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    whatsapp: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    sms: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(),
                                                 onupdate=func.now(), nullable=False)


class AlertRun(Base):
    """One row per scheduled alert per day. Claiming the row (unique alert + date) is what makes each daily alert
    run once a day only — even with two workers, a restart, or someone pressing "Run now" twice."""

    __tablename__ = "alert_runs"
    __table_args__ = (UniqueConstraint("alert", "run_date"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    alert: Mapped[str] = mapped_column(String(60), nullable=False)
    run_date: Mapped[date] = mapped_column(Date, nullable=False)
    ran_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    items: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    recipients: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
