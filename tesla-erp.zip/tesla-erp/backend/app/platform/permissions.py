from app.core.permissions import register

register("audit", "Audit log", ("read", "export"))
register("approval_policy", "Approval rules", ("create", "read", "update", "delete"))
