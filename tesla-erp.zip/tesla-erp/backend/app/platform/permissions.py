from app.core.permissions import register

register("audit", "Audit log", ("read", "export"))
