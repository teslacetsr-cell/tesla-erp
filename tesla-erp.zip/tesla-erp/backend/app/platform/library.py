"""Document library (Spec §28): one place to find every file the person may open — drawings, test reports, site
photos, supplier quotations, bills, certificates — whichever record it was attached to.

Files always belong to a record, and each record keeps its own permission rules: a person sees a file only if they
may open the record it is attached to (module permission, then the record-level check such as 'own projects').
Company-wide papers (registrations, insurance, ISO certificates…) are attached to the company itself.
"""
import uuid
from datetime import date, datetime, time
from zoneinfo import ZoneInfo

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.core.errors import Forbidden
from app.platform.documents.models import Document
from app.platform.documents.service import ENTITIES
from app.users.models import User

IST = ZoneInfo("Asia/Kolkata")
SCAN_LIMIT = 3000   # candidate files looked at per request (newest first)
SHOW_LIMIT = 300    # files returned

# entity type → (what it is called, label attributes in order of preference, page that opens it)
KINDS: dict[str, tuple[str, tuple[str, ...], str | None]] = {
    "company": ("Company", ("company_name",), "/admin/company"),
    "customer": ("Customer", ("customer_name",), "/customers/view?id={id}"),
    "supplier": ("Supplier", ("supplier_name",), "/suppliers/view?id={id}"),
    "item": ("Item", ("item_code", "item_name"), "/items/view?id={id}"),
    "employee": ("Employee", ("employee_code", "full_name"), "/hr/employees/view?id={id}"),
    "lead": ("Lead", ("lead_number", "title"), "/crm/leads/view?id={id}"),
    "enquiry": ("Enquiry", ("enquiry_number", "subject"), "/crm/enquiries/view?id={id}"),
    "site_visit": ("Site visit", ("visit_number", "site_location"), "/crm/site-visits/view?id={id}"),
    "boq": ("BOQ", ("boq_number", "title"), "/projects/boq/view?id={id}"),
    "quotation": ("Quotation", ("quotation_number", "subject"), "/sales/quotations/view?id={id}"),
    "sales_order": ("Sales order", ("so_number", "subject"), "/sales/orders/view?id={id}"),
    "project": ("Project", ("project_number", "name"), "/projects/view?id={id}"),
    "site_report": ("Site report", ("report_date",), "/projects/view?id={project_id}&tab=reports"),
    "material_request": ("Material request", ("mr_number",), "/purchase/material-requests/view?id={id}"),
    "purchase_order": ("Purchase order", ("po_number",), "/purchase/orders/view?id={id}"),
    "grn": ("GRN", ("grn_number",), "/purchase/grn/view?id={id}"),
    "rfq": ("Request for quotation", ("rfq_number",), "/purchase/rfqs/view?id={id}"),
    "vendor_quotation": ("Vendor quotation", ("quote_ref",), "/purchase/rfqs/view?id={rfq_id}"),
    "material_issue": ("Material issue", ("issue_number",), "/inventory/issues/view?id={id}"),
    "invoice": ("Invoice", ("invoice_number",), "/sales/invoices/view?id={id}"),
    "receipt": ("Receipt", ("receipt_number",), "/finance/receipts/view?id={id}"),
    "supplier_invoice": ("Supplier bill", ("bill_number", "supplier_invoice_no"), "/finance/bills/view?id={id}"),
    "supplier_payment": ("Supplier payment", ("payment_number",), "/finance/payments/view?id={id}"),
    "expense": ("Expense claim", ("expense_number", "description"), "/finance/expenses/view?id={id}"),
}


def readable_types(p: Principal) -> list[str]:
    return [t for t, d in ENTITIES.items() if p.can(f"{d.permission_module}.read")]


def _label(kind: str, obj) -> str:
    _, attrs, _ = KINDS.get(kind, (kind, (), None))
    parts = []
    for a in attrs:
        v = getattr(obj, a, None)
        if v:
            parts.append(v.strftime("%d %b %Y") if isinstance(v, date) else str(v))
    return " · ".join(parts[:2]) or "(draft)"


def _href(kind: str, obj) -> str | None:
    tpl = KINDS.get(kind, ("", (), None))[2]
    if not tpl:
        return None
    try:
        return tpl.format(id=obj.id, project_id=getattr(obj, "project_id", ""), rfq_id=getattr(obj, "rfq_id", ""))
    except (AttributeError, KeyError):
        return None


def search(db: Session, p: Principal, *, q: str | None = None, entity_type: str | None = None,
           category: str | None = None, date_from: date | None = None, date_to: date | None = None,
           mine: bool = False) -> dict:
    types = readable_types(p)
    if entity_type:
        if entity_type not in types:
            raise Forbidden()
        types = [entity_type]
    out: dict = {"rows": [], "truncated": False, "types": [
        {"key": t, "label": KINDS.get(t, (t.replace("_", " ").capitalize(),))[0]} for t in readable_types(p)]}
    if not types:
        return out
    stmt = (select(Document).where(Document.is_latest.is_(True), Document.status == "available",
                                   Document.entity_type.in_(types))
            .order_by(Document.uploaded_at.desc()).limit(SCAN_LIMIT))
    if category:
        stmt = stmt.where(Document.category == category)
    if mine:
        stmt = stmt.where(Document.uploaded_by == p.id)
    if date_from:
        stmt = stmt.where(Document.uploaded_at >= datetime.combine(date_from, time.min, IST))
    if date_to:
        stmt = stmt.where(Document.uploaded_at <= datetime.combine(date_to, time.max, IST))
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(or_(Document.file_name.ilike(like), Document.title.ilike(like)))
    docs = db.scalars(stmt).all()
    names = dict(db.execute(select(User.id, User.full_name).where(
        User.id.in_({d.uploaded_by for d in docs if d.uploaded_by}))).all()) if docs else {}
    # one load per record (many files usually hang off the same record), then the record's own permission rule
    by_entity: dict[tuple[str, uuid.UUID], object | None] = {}
    for d in docs:
        key = (d.entity_type, d.entity_id)
        if key not in by_entity:
            edef = ENTITIES.get(d.entity_type)
            obj = db.get(edef.model, d.entity_id) if edef else None
            if obj is not None and edef.check is not None:
                try:
                    edef.check(p, obj, "read")
                except Forbidden:
                    obj = None
            by_entity[key] = obj
        obj = by_entity[key]
        if obj is None:
            continue
        if len(out["rows"]) >= SHOW_LIMIT:
            out["truncated"] = True
            break
        out["rows"].append({
            "id": str(d.id), "file_name": d.file_name, "title": d.title, "category": d.category,
            "content_type": d.content_type, "size_bytes": d.size_bytes, "version": d.version,
            "uploaded_at": d.uploaded_at.isoformat(), "uploaded_by": names.get(d.uploaded_by),
            "entity_type": d.entity_type, "entity_kind": KINDS.get(d.entity_type, (d.entity_type,))[0],
            "entity_id": str(d.entity_id), "entity_label": _label(d.entity_type, obj), "href": _href(d.entity_type, obj),
        })
    out["truncated"] = out["truncated"] or len(docs) >= SCAN_LIMIT
    return out
