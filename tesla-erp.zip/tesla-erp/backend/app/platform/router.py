"""Cross-cutting endpoints: audit log, documents, global search."""
import uuid
from datetime import date, datetime, time
from typing import Annotated
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, File, Form, Query, UploadFile
from fastapi.responses import Response
from sqlalchemy import func, or_, select

from app.auth.deps import Principal, get_principal, require
from app.core.api import ListParams, ok
from app.core.db import DbSession
from app.core.errors import Forbidden
from app.platform.audit.models import AuditLog
from app.platform.documents import service as documents
from app.platform.documents.storage import get_storage
from app.users.models import User

router = APIRouter(tags=["platform"])
IST = ZoneInfo("Asia/Kolkata")


# ------------------------------------------------------------------ audit log
@router.get("/audit-logs")
def audit_logs(db: DbSession, _: Annotated[Principal, require("audit.read")], params: Annotated[ListParams, Depends()],
               entity_type: str | None = None, entity_id: str | None = None, user_id: uuid.UUID | None = None,
               action: str | None = None, date_from: date | None = None, date_to: date | None = None):
    stmt = select(AuditLog, User.full_name).outerjoin(User, User.id == AuditLog.user_id)
    if entity_type:
        stmt = stmt.where(AuditLog.entity_type == entity_type)
    if entity_id:
        stmt = stmt.where(AuditLog.entity_id == entity_id)
    if user_id:
        stmt = stmt.where(AuditLog.user_id == user_id)
    if action:
        stmt = stmt.where(AuditLog.action == action)
    if date_from:
        stmt = stmt.where(AuditLog.occurred_at >= datetime.combine(date_from, time.min, IST))
    if date_to:
        stmt = stmt.where(AuditLog.occurred_at <= datetime.combine(date_to, time.max, IST))
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(AuditLog.entity_label.ilike(like), AuditLog.summary.ilike(like)))
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.execute(stmt.order_by(AuditLog.id.desc()).offset((params.page - 1) * params.page_size)
                      .limit(params.page_size)).all()
    data = [{
        "id": a.id, "occurred_at": a.occurred_at.isoformat(), "user_id": str(a.user_id) if a.user_id else None,
        "user_name": name, "action": a.action, "entity_type": a.entity_type, "entity_id": a.entity_id,
        "entity_label": a.entity_label, "changes": a.changes, "summary": a.summary,
        "ip": str(a.ip) if a.ip else None, "user_agent": a.user_agent, "request_id": a.request_id,
    } for a, name in rows]
    return {"data": data, "meta": {"page": params.page, "page_size": params.page_size, "total": total}}


# ------------------------------------------------------------------ documents
def _doc_perm(p: Principal, entity_type: str, action: str) -> None:
    edef = documents.ENTITIES.get(entity_type)
    if edef is None or not p.can(f"{edef.permission_module}.{action}"):
        raise Forbidden()


def _doc_record_check(db, p: Principal, entity_type: str, entity_id: uuid.UUID, action: str) -> None:
    """The record must exist, and record-level rules (such as 'own' scope) must allow the action."""
    edef, obj = documents.get_entity(db, entity_type, entity_id)
    if edef.check is not None:
        edef.check(p, obj, action)


def _doc_out(d) -> dict:
    return {"id": str(d.id), "group_id": str(d.group_id), "version": d.version, "is_latest": d.is_latest,
            "category": d.category, "entity_type": d.entity_type, "entity_id": str(d.entity_id), "title": d.title,
            "file_name": d.file_name, "content_type": d.content_type, "size_bytes": d.size_bytes, "sha256": d.sha256,
            "uploaded_by": str(d.uploaded_by) if d.uploaded_by else None, "uploaded_at": d.uploaded_at.isoformat()}


@router.get("/documents")
def list_documents(db: DbSession, p: Annotated[Principal, Depends(get_principal)], entity_type: str,
                   entity_id: uuid.UUID, include_history: bool = False):
    _doc_perm(p, entity_type, "read")
    _doc_record_check(db, p, entity_type, entity_id, "read")
    return ok([_doc_out(d) for d in documents.list_for(db, entity_type, entity_id, include_history)])


@router.post("/documents", status_code=201)
async def upload_document(db: DbSession, p: Annotated[Principal, Depends(get_principal)],
                          entity_type: Annotated[str, Form()], entity_id: Annotated[uuid.UUID, Form()],
                          category: Annotated[str, Form()], file: UploadFile = File(...),
                          title: Annotated[str | None, Form(max_length=200)] = None,
                          replaces: Annotated[uuid.UUID | None, Form()] = None):
    _doc_perm(p, entity_type, "update")
    _doc_record_check(db, p, entity_type, entity_id, "update")
    data = await file.read()
    doc = documents.upload(db, entity_type=entity_type, entity_id=entity_id, category=category,
                           file_name=file.filename or "file", data=data, user_id=p.id, title=title, replaces=replaces)
    return ok(_doc_out(doc))


@router.get("/documents/{document_id}/download")
def download_document(document_id: uuid.UUID, db: DbSession, p: Annotated[Principal, Depends(get_principal)]):
    doc = documents.get(db, document_id)
    _doc_perm(p, doc.entity_type, "read")
    _doc_record_check(db, p, doc.entity_type, doc.entity_id, "read")
    url = get_storage().download_url(doc.storage_key, doc.file_name)
    return ok({"url": url or f"/api/v1/documents/{doc.id}/content", "file_name": doc.file_name,
               "content_type": doc.content_type})


@router.get("/documents/{document_id}/content")
def document_content(document_id: uuid.UUID, db: DbSession, p: Annotated[Principal, Depends(get_principal)],
                     inline: bool = Query(False)):
    doc = documents.get(db, document_id)
    _doc_perm(p, doc.entity_type, "read")
    _doc_record_check(db, p, doc.entity_type, doc.entity_id, "read")
    safe = doc.file_name.replace('"', "")
    disposition = "inline" if inline and doc.content_type in ("application/pdf", "image/png", "image/jpeg",
                                                              "image/webp") else "attachment"
    return Response(get_storage().get(doc.storage_key), media_type=doc.content_type,
                    headers={"Content-Disposition": f'{disposition}; filename="{safe}"',
                             "Cache-Control": "private, no-store"})


@router.delete("/documents/{document_id}")
def delete_document(document_id: uuid.UUID, db: DbSession, p: Annotated[Principal, Depends(get_principal)]):
    doc = documents.get(db, document_id)
    _doc_perm(p, doc.entity_type, "update")
    _doc_record_check(db, p, doc.entity_type, doc.entity_id, "update")
    documents.remove(db, doc)
    return ok({"ok": True})


# ------------------------------------------------------------------ document library (Spec §28)
@router.get("/document-library")
def document_library(db: DbSession, p: Annotated[Principal, Depends(get_principal)], q: str | None = Query(None, max_length=100),
                     entity_type: str | None = Query(None, max_length=40), category: str | None = Query(None, max_length=40),
                     date_from: date | None = None, date_to: date | None = None, mine: bool = False):
    """Every file the person may open, newest first, across all records."""
    from app.platform import library

    out = library.search(db, p, q=q, entity_type=entity_type or None, category=category or None,
                         date_from=date_from, date_to=date_to, mine=mine)
    from app.company.models import Company

    company = db.scalar(select(Company.id).limit(1))
    out["company_id"] = str(company) if company else None
    out["can_upload_company"] = p.can("company.update")
    return ok(out)


# ------------------------------------------------------------------ global search (Spec §35)
@router.get("/search")
def search(db: DbSession, p: Annotated[Principal, Depends(get_principal)], q: str = Query(min_length=2, max_length=100),
           limit: int = Query(5, ge=1, le=25), types: str | None = Query(None, max_length=300)):
    """Grouped results across every kind of record the person may open (app/platform/search.py)."""
    from app.platform import search as global_search

    wanted = [t for t in (types or "").split(",") if t] or None
    return ok(global_search.search(db, p, q, limit=limit, types=wanted))


# ------------------------------------------------------------------ system status (backups, storage, tunnel)
@router.get("/system/status")
def system_status(db: DbSession, _: Annotated[Principal, require("settings.read")]):
    """Health of the pieces an administrator must watch — above all, whether backups are succeeding."""
    import json
    from pathlib import Path

    from sqlalchemy import text

    from app.core.config import get_settings

    s = get_settings()
    storage = get_storage()
    health = getattr(storage, "health", None)
    storage_ok, storage_msg = health() if health else (True, "object storage")
    supervisor: dict = {}
    if s.status_file and Path(s.status_file).exists():
        try:
            supervisor = json.loads(Path(s.status_file).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            supervisor = {"error": "status file unreadable"}
    db_size = db.execute(text("select pg_size_pretty(pg_database_size(current_database()))")).scalar()
    return ok({
        "version": s.app_version, "deployment": s.deployment, "environment": s.environment,
        "storage": {"backend": s.storage_backend, "location": s.storage_path if s.storage_backend == "filesystem"
                    else s.storage_bucket if s.storage_backend == "s3" else "local (development)",
                    "ok": storage_ok, "detail": storage_msg},
        "database": {"size": db_size},
        "backup": supervisor.get("backup"),
        "tunnel": supervisor.get("tunnel"),
        "server": supervisor.get("server"),
    })
