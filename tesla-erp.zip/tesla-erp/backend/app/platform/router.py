"""Cross-cutting endpoints: audit log, documents, global search."""
import uuid
from datetime import date, datetime, time
from typing import Annotated
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, File, Form, Query, UploadFile
from fastapi.responses import Response
from sqlalchemy import func, or_, select

from app.auth.deps import Principal, get_principal, require
from app.core.api import ListParams, ok
from app.core.db import DbSession
from app.core.errors import Forbidden
from app.customers.models import Customer
from app.hr.models import Employee
from app.platform.audit.models import AuditLog
from app.platform.documents import service as documents
from app.platform.documents.storage import get_storage
from app.products.models import Item
from app.suppliers.models import Supplier
from app.users.models import User

router = APIRouter(tags=["platform"])
IST = ZoneInfo("Asia/Kolkata")


# ------------------------------------------------------------------ audit log
@router.get("/audit-logs")
def audit_logs(db: DbSession, _: Annotated[Principal, require("audit.read")], params: Annotated[ListParams, Depends()],
               entity_type: str | None = None, entity_id: str | None = None, user_id: uuid.UUID | None = None,
               action: str | None = None, date_from: date | None = None, date_to: date | None = None):
    stmt = select(AuditLog, User.full_name).outerjoin(User, User.id == AuditLog.user_id)
    if entity_type:
        stmt = stmt.where(AuditLog.entity_type == entity_type)
    if entity_id:
        stmt = stmt.where(AuditLog.entity_id == entity_id)
    if user_id:
        stmt = stmt.where(AuditLog.user_id == user_id)
    if action:
        stmt = stmt.where(AuditLog.action == action)
    if date_from:
        stmt = stmt.where(AuditLog.occurred_at >= datetime.combine(date_from, time.min, IST))
    if date_to:
        stmt = stmt.where(AuditLog.occurred_at <= datetime.combine(date_to, time.max, IST))
    if params.q:
        like = f"%{params.q}%"
        stmt = stmt.where(or_(AuditLog.entity_label.ilike(like), AuditLog.summary.ilike(like)))
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.execute(stmt.order_by(AuditLog.id.desc()).offset((params.page - 1) * params.page_size)
                      .limit(params.page_size)).all()
    data = [{
        "id": a.id, "occurred_at": a.occurred_at.isoformat(), "user_id": str(a.user_id) if a.user_id else None,
        "user_name": name, "action": a.action, "entity_type": a.entity_type, "entity_id": a.entity_id,
        "entity_label": a.entity_label, "changes": a.changes, "summary": a.summary,
        "ip": str(a.ip) if a.ip else None, "user_agent": a.user_agent, "request_id": a.request_id,
    } for a, name in rows]
    return {"data": data, "meta": {"page": params.page, "page_size": params.page_size, "total": total}}


# ------------------------------------------------------------------ documents
def _doc_perm(p: Principal, entity_type: str, action: str) -> None:
    edef = documents.ENTITIES.get(entity_type)
    if edef is None or not p.can(f"{edef.permission_module}.{action}"):
        raise Forbidden()


def _doc_record_check(db, p: Principal, entity_type: str, entity_id: uuid.UUID, action: str) -> None:
    """The record must exist, and record-level rules (such as 'own' scope) must allow the action."""
    edef, obj = documents.get_entity(db, entity_type, entity_id)
    if edef.check is not None:
        edef.check(p, obj, action)


def _doc_out(d) -> dict:
    return {"id": str(d.id), "group_id": str(d.group_id), "version": d.version, "is_latest": d.is_latest,
            "category": d.category, "entity_type": d.entity_type, "entity_id": str(d.entity_id), "title": d.title,
            "file_name": d.file_name, "content_type": d.content_type, "size_bytes": d.size_bytes, "sha256": d.sha256,
            "uploaded_by": str(d.uploaded_by) if d.uploaded_by else None, "uploaded_at": d.uploaded_at.isoformat()}


@router.get("/documents")
def list_documents(db: DbSession, p: Annotated[Principal, Depends(get_principal)], entity_type: str,
                   entity_id: uuid.UUID, include_history: bool = False):
    _doc_perm(p, entity_type, "read")
    _doc_record_check(db, p, entity_type, entity_id, "read")
    return ok([_doc_out(d) for d in documents.list_for(db, entity_type, entity_id, include_history)])


@router.post("/documents", status_code=201)
async def upload_document(db: DbSession, p: Annotated[Principal, Depends(get_principal)],
                          entity_type: Annotated[str, Form()], entity_id: Annotated[uuid.UUID, Form()],
                          category: Annotated[str, Form()], file: UploadFile = File(...),
                          title: Annotated[str | None, Form(max_length=200)] = None,
                          replaces: Annotated[uuid.UUID | None, Form()] = None):
    _doc_perm(p, entity_type, "update")
    _doc_record_check(db, p, entity_type, entity_id, "update")
    data = await file.read()
    doc = documents.upload(db, entity_type=entity_type, entity_id=entity_id, category=category,
                           file_name=file.filename or "file", data=data, user_id=p.id, title=title, replaces=replaces)
    return ok(_doc_out(doc))


@router.get("/documents/{document_id}/download")
def download_document(document_id: uuid.UUID, db: DbSession, p: Annotated[Principal, Depends(get_principal)]):
    doc = documents.get(db, document_id)
    _doc_perm(p, doc.entity_type, "read")
    _doc_record_check(db, p, doc.entity_type, doc.entity_id, "read")
    url = get_storage().download_url(doc.storage_key, doc.file_name)
    return ok({"url": url or f"/api/v1/documents/{doc.id}/content", "file_name": doc.file_name,
               "content_type": doc.content_type})


@router.get("/documents/{document_id}/content")
def document_content(document_id: uuid.UUID, db: DbSession, p: Annotated[Principal, Depends(get_principal)],
                     inline: bool = Query(False)):
    doc = documents.get(db, document_id)
    _doc_perm(p, doc.entity_type, "read")
    _doc_record_check(db, p, doc.entity_type, doc.entity_id, "read")
    safe = doc.file_name.replace('"', "")
    disposition = "inline" if inline and doc.content_type in ("application/pdf", "image/png", "image/jpeg",
                                                              "image/webp") else "attachment"
    return Response(get_storage().get(doc.storage_key), media_type=doc.content_type,
                    headers={"Content-Disposition": f'{disposition}; filename="{safe}"',
                             "Cache-Control": "private, no-store"})


@router.delete("/documents/{document_id}")
def delete_document(document_id: uuid.UUID, db: DbSession, p: Annotated[Principal, Depends(get_principal)]):
    doc = documents.get(db, document_id)
    _doc_perm(p, doc.entity_type, "update")
    _doc_record_check(db, p, doc.entity_type, doc.entity_id, "update")
    documents.remove(db, doc)
    return ok({"ok": True})


# ------------------------------------------------------------------ global search (Spec §35 — grows each phase)
@router.get("/search")
def search(db: DbSession, p: Annotated[Principal, Depends(get_principal)], q: str = Query(min_length=2, max_length=100)):
    like = f"%{q.strip()}%"
    groups = []
    if p.can("customer.read"):
        rows = db.scalars(select(Customer).where(or_(
            Customer.customer_name.ilike(like), Customer.customer_code.ilike(like), Customer.gstin.ilike(like),
            Customer.phone.ilike(like), Customer.city.ilike(like)))
            .order_by(func.similarity(Customer.customer_name, q).desc()).limit(6)).all()
        groups.append({"type": "customer", "label": "Customers", "items": [
            {"id": str(c.id), "title": c.customer_name, "subtitle": " · ".join(filter(None, [c.customer_code, c.city])),
             "href": f"/customers/view?id={c.id}"} for c in rows]})
    if p.can("supplier.read"):
        rows = db.scalars(select(Supplier).where(or_(
            Supplier.supplier_name.ilike(like), Supplier.supplier_code.ilike(like), Supplier.gstin.ilike(like),
            Supplier.supplies.ilike(like)))
            .order_by(func.similarity(Supplier.supplier_name, q).desc()).limit(6)).all()
        groups.append({"type": "supplier", "label": "Suppliers", "items": [
            {"id": str(s.id), "title": s.supplier_name, "subtitle": " · ".join(filter(None, [s.supplier_code, s.city])),
             "href": f"/suppliers/view?id={s.id}"} for s in rows]})
    if p.can("item.read"):
        rows = db.scalars(select(Item).where(or_(
            Item.item_name.ilike(like), Item.item_code.ilike(like), Item.model.ilike(like), Item.hsn_sac.ilike(like)))
            .order_by(func.similarity(Item.item_name, q).desc()).limit(6)).all()
        groups.append({"type": "item", "label": "Items", "items": [
            {"id": str(i.id), "title": i.item_name, "subtitle": " · ".join(filter(None, [i.item_code, i.model])),
             "href": f"/items/view?id={i.id}"} for i in rows]})
    if p.can("employee.read"):
        rows = db.scalars(select(Employee).where(or_(
            Employee.full_name.ilike(like), Employee.employee_code.ilike(like), Employee.email.ilike(like)))
            .limit(6)).all()
        groups.append({"type": "employee", "label": "Employees", "items": [
            {"id": str(e.id), "title": e.full_name, "subtitle": e.employee_code, "href": "/hr/employees"}
            for e in rows]})
    groups += _crm_search(db, p, q, like)
    return ok([g for g in groups if g["items"]])


def _crm_search(db, p: Principal, q: str, like: str) -> list[dict]:
    from app.crm import service as crm
    from app.crm.models import Enquiry, Lead, SiteVisit

    groups = []
    if p.can("lead.read"):
        stmt = select(Lead).where(or_(Lead.lead_number.ilike(like), Lead.title.ilike(like), Lead.company_name.ilike(like),
                                      Lead.contact_name.ilike(like), Lead.contact_phone.ilike(like)))
        if (c := crm.scope_clause(p, "lead", "read")) is not None:
            stmt = stmt.where(c)
        groups.append({"type": "lead", "label": "Leads", "items": [
            {"id": str(x.id), "title": x.title, "subtitle": " · ".join(filter(None, [x.lead_number, x.company_name])),
             "href": f"/crm/leads/view?id={x.id}"} for x in db.scalars(stmt.order_by(Lead.created_at.desc()).limit(6))]})
    if p.can("enquiry.read"):
        stmt = select(Enquiry).where(or_(Enquiry.enquiry_number.ilike(like), Enquiry.subject.ilike(like)))
        if (c := crm.scope_clause(p, "enquiry", "read")) is not None:
            stmt = stmt.where(c)
        groups.append({"type": "enquiry", "label": "Enquiries", "items": [
            {"id": str(x.id), "title": x.subject, "subtitle": x.enquiry_number, "href": f"/crm/enquiries/view?id={x.id}"}
            for x in db.scalars(stmt.order_by(Enquiry.created_at.desc()).limit(6))]})
    if p.can("site_visit.read"):
        stmt = select(SiteVisit).where(or_(SiteVisit.visit_number.ilike(like), SiteVisit.site_location.ilike(like)))
        if (c := crm.scope_clause(p, "site_visit", "read")) is not None:
            stmt = stmt.where(c)
        groups.append({"type": "site_visit", "label": "Site visits", "items": [
            {"id": str(x.id), "title": x.site_location or x.visit_number,
             "subtitle": f"{x.visit_number} · {x.visit_date.strftime('%d %b %Y')}", "href": f"/crm/site-visits/view?id={x.id}"}
            for x in db.scalars(stmt.order_by(SiteVisit.visit_date.desc()).limit(6))]})
    return groups




# ------------------------------------------------------------------ system status (backups, storage, tunnel)
@router.get("/system/status")
def system_status(db: DbSession, _: Annotated[Principal, require("settings.read")]):
    """Health of the pieces an administrator must watch — above all, whether backups are succeeding."""
    import json
    from pathlib import Path

    from sqlalchemy import text

    from app.core.config import get_settings

    s = get_settings()
    storage = get_storage()
    health = getattr(storage, "health", None)
    storage_ok, storage_msg = health() if health else (True, "object storage")
    supervisor: dict = {}
    if s.status_file and Path(s.status_file).exists():
        try:
            supervisor = json.loads(Path(s.status_file).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            supervisor = {"error": "status file unreadable"}
    db_size = db.execute(text("select pg_size_pretty(pg_database_size(current_database()))")).scalar()
    return ok({
        "version": s.app_version, "deployment": s.deployment, "environment": s.environment,
        "storage": {"backend": s.storage_backend, "location": s.storage_path if s.storage_backend == "filesystem"
                    else s.storage_bucket if s.storage_backend == "s3" else "local (development)",
                    "ok": storage_ok, "detail": storage_msg},
        "database": {"size": db_size},
        "backup": supervisor.get("backup"),
        "tunnel": supervisor.get("tunnel"),
        "server": supervisor.get("server"),
    })
