import uuid
from datetime import datetime
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, DateTime, ForeignKey, Index, Integer, String, Text, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.models import AuditColumnsMixin, Base
from app.core.money import AMOUNT

REQUEST_STATUSES = ("pending", "approved", "rejected", "withdrawn")


class ApprovalPolicy(AuditColumnsMixin, Base):
    """A configurable approval rule (Spec §30): documents of `entity_type` whose value is ABOVE `min_amount`
    (before GST) need the listed roles to approve, in order. The rule with the highest threshold that applies
    wins; a rule for a specific division beats a general one at the same threshold."""

    __tablename__ = "approval_policies"
    __table_args__ = (CheckConstraint("min_amount >= 0", name="min_nonneg"),
                      CheckConstraint("jsonb_array_length(steps) between 1 and 5", name="steps_count"))

    entity_type: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    min_amount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False)
    division_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("business_divisions.id", ondelete="RESTRICT"))
    steps: Mapped[list] = mapped_column(JSONB, nullable=False)  # ["MANAGER", "DIRECTOR"]
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")


class ApprovalRequest(Base):
    """One run of a policy for one document. The policy's steps are copied in, so editing a rule later never
    changes a request already in progress."""

    __tablename__ = "approval_requests"
    __table_args__ = (
        CheckConstraint("status in ('pending','approved','rejected','withdrawn')", name="status_valid"),
        Index("ix_approval_requests_entity", "entity_type", "entity_id"),
        Index("ix_approval_requests_pending", "status", "entity_type"),
        Index("uq_approval_requests_one_pending", "entity_type", "entity_id", unique=True,
              postgresql_where="status = 'pending'"),
    )

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    entity_type: Mapped[str] = mapped_column(String(40), nullable=False)
    entity_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    entity_label: Mapped[str] = mapped_column(String(255), nullable=False)
    amount: Mapped[Decimal] = mapped_column(AMOUNT, nullable=False)
    policy_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("approval_policies.id", ondelete="SET NULL"))
    policy_name: Mapped[str] = mapped_column(String(120), nullable=False)
    steps: Mapped[list] = mapped_column(JSONB, nullable=False)
    current_step: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")
    requested_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    requested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    # who decides a LINE_MANAGER step: the reporting manager (HR) of the person the request is about
    line_manager_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id",
                                                                                             ondelete="SET NULL"))
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    actions: Mapped[list["ApprovalAction"]] = relationship(order_by="ApprovalAction.acted_at", lazy="selectin",
                                                           cascade="all, delete-orphan")


class ApprovalAction(Base):
    __tablename__ = "approval_actions"
    __table_args__ = (CheckConstraint("decision in ('approved','rejected','withdrawn')", name="decision_valid"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    request_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("approval_requests.id", ondelete="CASCADE"), nullable=False,
                                                  index=True)
    step_no: Mapped[int] = mapped_column(Integer, nullable=False)
    role_code: Mapped[str] = mapped_column(String(40), nullable=False)
    decision: Mapped[str] = mapped_column(String(20), nullable=False)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    comment: Mapped[str | None] = mapped_column(Text)
    acted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
