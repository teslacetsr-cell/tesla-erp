import uuid
from decimal import Decimal
from typing import Annotated, Literal

from fastapi import APIRouter, Query
from pydantic import Field
from sqlalchemy import or_, select

from app.auth.deps import CurrentUser, Principal, require
from app.company.models import BusinessDivision
from app.core.api import Schema, ok
from app.core.db import DbSession
from app.core.errors import Forbidden, NotFound
from app.core.models import check_row_version
from app.core.validators import Text
from app.platform.approvals import service
from app.platform.approvals.models import ApprovalAction, ApprovalPolicy, ApprovalRequest
from app.platform.audit import service as audit
from app.users.models import User

router = APIRouter(tags=["approvals"])


def _names(db, ids) -> dict:
    ids = {i for i in ids if i}
    return dict(db.execute(select(User.id, User.full_name).where(User.id.in_(ids))).all()) if ids else {}


def request_out(db, p: Principal, r: ApprovalRequest, names: dict | None = None) -> dict:
    names = names or _names(db, [r.requested_by, *[a.user_id for a in r.actions]])
    h = service.HANDLERS.get(r.entity_type)
    return {
        "id": str(r.id), "entity_type": r.entity_type, "entity_label": r.entity_label,
        "entity_name": h.label if h else r.entity_type, "entity_id": str(r.entity_id),
        "href": h.href(r.entity_id) if h else None, "amount": str(r.amount), "policy_name": r.policy_name,
        "steps": r.steps, "current_step": r.current_step, "status": r.status,
        "requested_by": names.get(r.requested_by), "requested_at": r.requested_at.isoformat(),
        "decided_at": r.decided_at.isoformat() if r.decided_at else None, "can_decide": service.can_decide(p, r),
        "actions": [{"step_no": a.step_no, "role_code": a.role_code, "decision": a.decision,
                     "user": names.get(a.user_id), "comment": a.comment, "acted_at": a.acted_at.isoformat()}
                    for a in r.actions],
    }


@router.get("/approvals/inbox")
def approvals_inbox(db: DbSession, p: CurrentUser):
    rows = service.inbox(db, p)
    names = _names(db, [r.requested_by for r in rows] + [a.user_id for r in rows for a in r.actions])
    return ok([request_out(db, p, r, names) for r in rows])


@router.get("/approvals/history")
def approvals_history(db: DbSession, p: CurrentUser, limit: int = Query(50, ge=1, le=200)):
    """Requests I made or decided, newest first."""
    acted = select(ApprovalAction.request_id).where(ApprovalAction.user_id == p.id)
    rows = db.scalars(select(ApprovalRequest).where(or_(ApprovalRequest.requested_by == p.id,
                                                        ApprovalRequest.id.in_(acted)))
                      .order_by(ApprovalRequest.requested_at.desc()).limit(limit)).all()
    names = _names(db, [r.requested_by for r in rows] + [a.user_id for r in rows for a in r.actions])
    return ok([request_out(db, p, r, names) for r in rows])


@router.get("/approvals/requests")
def approvals_for_entity(db: DbSession, p: CurrentUser, entity_type: str, entity_id: uuid.UUID):
    if not p.can(f"{entity_type}.read"):
        raise Forbidden()
    return ok([request_out(db, p, r) for r in service.history(db, entity_type, entity_id)])


class DecisionIn(Schema):
    decision: Literal["approved", "rejected"]
    comment: Text(1000) = None


@router.post("/approvals/{request_id}/decide")
def decide(request_id: uuid.UUID, body: DecisionIn, db: DbSession, p: CurrentUser):
    r = service.decide(db, p, request_id, body.decision, body.comment)
    return ok(request_out(db, p, r))


# ------------------------------------------------------------------ rules
ENTITY_TYPES = {"quotation": "Quotations", "purchase_request": "Purchase requests", "purchase_order": "Purchase orders",
                "stock_adjustment": "Stock adjustments", "expense": "Expense claims",
                "supplier_invoice": "Supplier invoices that differ from the PO / GRN",
                "material_issue": "Material issues to projects"}


class PolicyIn(Schema):
    entity_type: Literal["quotation", "purchase_request", "purchase_order", "stock_adjustment", "expense",
                         "supplier_invoice", "material_issue"]
    name: str = Field(min_length=3, max_length=120)
    min_amount: Decimal = Field(ge=0, max_digits=18, decimal_places=2)
    division_id: uuid.UUID | None = None
    steps: list[str] = Field(min_length=1, max_length=5)
    is_active: bool = True


class PolicyUpdate(PolicyIn):
    row_version: int


def policy_out(db, pol: ApprovalPolicy) -> dict:
    div = db.get(BusinessDivision, pol.division_id) if pol.division_id else None
    return {"id": str(pol.id), "entity_type": pol.entity_type, "entity_name": ENTITY_TYPES.get(pol.entity_type),
            "name": pol.name, "min_amount": str(pol.min_amount), "division_id": str(pol.division_id) if div else None,
            "division": div.name if div else None, "steps": pol.steps, "is_active": pol.is_active,
            "row_version": pol.row_version}


@router.get("/approval-policies")
def list_policies(db: DbSession, _: Annotated[Principal, require("approval_policy.read")]):
    rows = db.scalars(select(ApprovalPolicy).order_by(ApprovalPolicy.entity_type, ApprovalPolicy.min_amount)).all()
    return ok([policy_out(db, r) for r in rows])


def _check_division(db, division_id) -> None:
    if division_id and db.get(BusinessDivision, division_id) is None:
        raise NotFound("division")


@router.post("/approval-policies", status_code=201)
def create_policy(body: PolicyIn, db: DbSession, p: Annotated[Principal, require("approval_policy.create")]):
    _check_division(db, body.division_id)
    values = body.model_dump()
    values["steps"] = service.validate_steps(db, body.steps)
    pol = ApprovalPolicy(**values, created_by=p.id, updated_by=p.id)
    db.add(pol)
    db.flush()
    audit.record(db, action="create", entity_type="approval_policy", entity_id=pol.id, entity_label=pol.name,
                 after=audit.snapshot(pol))
    return ok(policy_out(db, pol))


@router.put("/approval-policies/{policy_id}")
def update_policy(policy_id: uuid.UUID, body: PolicyUpdate, db: DbSession,
                  p: Annotated[Principal, require("approval_policy.update")]):
    pol = db.get(ApprovalPolicy, policy_id, with_for_update=True)
    if pol is None:
        raise NotFound("approval_policy")
    _check_division(db, body.division_id)
    before = audit.snapshot(pol)
    values = body.model_dump()
    check_row_version(pol, values.pop("row_version"))
    values["steps"] = service.validate_steps(db, body.steps)
    for k, v in values.items():
        setattr(pol, k, v)
    pol.updated_by = p.id
    db.flush()
    audit.record(db, action="update", entity_type="approval_policy", entity_id=pol.id, entity_label=pol.name,
                 before=before, after=audit.snapshot(pol))
    return ok(policy_out(db, pol))


@router.delete("/approval-policies/{policy_id}")
def delete_policy(policy_id: uuid.UUID, db: DbSession, p: Annotated[Principal, require("approval_policy.delete")]):
    pol = db.get(ApprovalPolicy, policy_id)
    if pol is None:
        raise NotFound("approval_policy")
    snap, name = audit.snapshot(pol), pol.name
    db.delete(pol)
    db.flush()
    audit.record(db, action="delete", entity_type="approval_policy", entity_id=policy_id, entity_label=name, before=snap)
    return ok({"ok": True})


@router.get("/approval-policies/roles")
def policy_roles(db: DbSession, _: Annotated[Principal, require("approval_policy.read")]):
    from app.users.models import Role

    roles = [{"code": c, "name": n} for c, n in db.execute(
        select(Role.code, Role.name).where(Role.is_active.is_(True)).order_by(Role.name)).all()]
    return ok([{"code": service.LINE_MANAGER, "name": "Line manager (the person's reporting manager in HR)"}, *roles])
