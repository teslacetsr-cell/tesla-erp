"""Generic approval engine (Spec §30). Quotations use it now; purchase orders (Phase 5) and expenses (Phase 7)
plug in the same way: register a handler, call `start()` when the document is submitted.

Who may decide a step: a user who holds the `<entity>.approve` permission AND the step's role (Administrators
and Directors may decide any step). Nobody approves their own request.
"""
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.core.errors import AppError, Conflict, Forbidden, NotFound
from app.core.money import format_inr
from app.platform.approvals.models import ApprovalAction, ApprovalPolicy, ApprovalRequest
from app.platform.audit import service as audit
from app.platform.notifications.service import notify, users_with_roles
from app.users.models import Role

OVERRIDE_ROLES = ("ADMIN", "DIRECTOR")


@dataclass(frozen=True)
class Handler:
    label: str                                                        # "Quotation"
    href: Callable[[uuid.UUID], str]                                  # link to the document
    on_approved: Callable[[Session, Principal, ApprovalRequest], None]
    on_rejected: Callable[[Session, Principal, ApprovalRequest, str], None]
    owners: Callable[[Session, uuid.UUID], list[uuid.UUID]] = lambda db, eid: []  # extra people to tell


HANDLERS: dict[str, Handler] = {}


def register(entity_type: str, handler: Handler) -> None:
    HANDLERS[entity_type] = handler


# ------------------------------------------------------------------ policies
def policy_for(db: Session, entity_type: str, amount: Decimal, division_id: uuid.UUID | None) -> ApprovalPolicy | None:
    candidates = db.scalars(select(ApprovalPolicy).where(
        ApprovalPolicy.entity_type == entity_type, ApprovalPolicy.is_active.is_(True),
        ApprovalPolicy.min_amount < amount,
        or_(ApprovalPolicy.division_id.is_(None), ApprovalPolicy.division_id == division_id))).all()
    if not candidates:
        return None
    return max(candidates, key=lambda pol: (pol.min_amount, pol.division_id is not None))


def validate_steps(db: Session, steps: list[str]) -> list[str]:
    steps = [s.strip().upper() for s in steps if s and s.strip()]
    if not 1 <= len(steps) <= 5:
        raise AppError("INVALID_STEPS", "An approval rule needs 1 to 5 approval steps.")
    known = set(db.scalars(select(Role.code).where(Role.is_active.is_(True))))
    unknown = [s for s in steps if s not in known]
    if unknown:
        raise AppError("INVALID_STEPS", f"Unknown role(s): {', '.join(unknown)}.")
    return steps


# ------------------------------------------------------------------ requests
def pending_for(db: Session, entity_type: str, entity_id: uuid.UUID) -> ApprovalRequest | None:
    return db.scalar(select(ApprovalRequest).where(ApprovalRequest.entity_type == entity_type,
                                                   ApprovalRequest.entity_id == entity_id,
                                                   ApprovalRequest.status == "pending"))


def history(db: Session, entity_type: str, entity_id: uuid.UUID) -> list[ApprovalRequest]:
    return list(db.scalars(select(ApprovalRequest).where(
        ApprovalRequest.entity_type == entity_type, ApprovalRequest.entity_id == entity_id)
        .order_by(ApprovalRequest.requested_at.desc())))


def _approvers(db: Session, role: str) -> list[uuid.UUID]:
    return users_with_roles(db, [role])


def start(db: Session, p: Principal, *, entity_type: str, entity_id: uuid.UUID, label: str, amount: Decimal,
          division_id: uuid.UUID | None = None) -> ApprovalRequest | None:
    """Open an approval request if a rule applies. Returns None when no approval is needed."""
    if entity_type not in HANDLERS:
        raise ValueError(f"No approval handler for {entity_type}")
    if pending_for(db, entity_type, entity_id) is not None:
        raise Conflict("APPROVAL_PENDING", "This document is already waiting for approval.")
    pol = policy_for(db, entity_type, amount, division_id)
    if pol is None:
        return None
    req = ApprovalRequest(entity_type=entity_type, entity_id=entity_id, entity_label=label[:255], amount=amount,
                          policy_id=pol.id, policy_name=pol.name, steps=list(pol.steps), current_step=0,
                          status="pending", requested_by=p.id)
    db.add(req)
    db.flush()
    h = HANDLERS[entity_type]
    audit.record(db, action="approval_requested", entity_type=entity_type, entity_id=entity_id, entity_label=label,
                 summary=f"Sent for approval ({pol.name}): {' → '.join(pol.steps)}")
    notify(db, _approvers(db, req.steps[0]), event="approval.requested", exclude=p.id,
           title=f"Approval needed: {h.label} {label}",
           body=f"₹{format_inr(amount)} before GST · requested by {p.user.full_name} · step 1 of {len(req.steps)}",
           link=h.href(entity_id))
    return req


def can_decide(p: Principal, req: ApprovalRequest) -> bool:
    if req.status != "pending" or not p.can(f"{req.entity_type}.approve"):
        return False
    if req.requested_by == p.id and "ADMIN" not in p.role_codes:
        return False
    role = req.steps[req.current_step]
    return role in p.role_codes or any(r in p.role_codes for r in OVERRIDE_ROLES)


def decide(db: Session, p: Principal, request_id: uuid.UUID, decision: str, comment: str | None) -> ApprovalRequest:
    req = db.get(ApprovalRequest, request_id, with_for_update=True)
    if req is None:
        raise NotFound("approval_request")
    if req.status != "pending":
        raise AppError("APPROVAL_CLOSED", f"This request is already {req.status}.")
    if not can_decide(p, req):
        if req.requested_by == p.id:
            raise Forbidden("You cannot approve your own request.", code="OWN_REQUEST")
        raise Forbidden(f"This step needs a {req.steps[req.current_step].replace('_', ' ').title()}.",
                        code="NOT_YOUR_STEP")
    if decision not in ("approved", "rejected"):
        raise AppError("INVALID_DECISION", "Decision must be approved or rejected.")
    if decision == "rejected" and not (comment and comment.strip()):
        raise AppError("COMMENT_REQUIRED", "Say why it is rejected, so the requester knows what to change.",
                       details={"field": "comment"})
    h = HANDLERS[req.entity_type]
    step_role = req.steps[req.current_step]
    req.actions.append(ApprovalAction(step_no=req.current_step, role_code=step_role, decision=decision, user_id=p.id,
                                      comment=(comment or "").strip() or None))
    link = h.href(req.entity_id)
    tell = set(h.owners(db, req.entity_id)) | {req.requested_by}
    if decision == "rejected":
        req.status, req.decided_at = "rejected", datetime.now(UTC)
        db.flush()
        audit.record(db, action="approval_rejected", entity_type=req.entity_type, entity_id=req.entity_id,
                     entity_label=req.entity_label, summary=f"Rejected by {p.user.full_name}: {comment}")
        h.on_rejected(db, p, req, comment or "")
        notify(db, tell, event="approval.rejected", exclude=p.id, link=link,
               title=f"{h.label} {req.entity_label} was rejected", body=f"{p.user.full_name}: {comment}")
        return req
    audit.record(db, action="approval_step", entity_type=req.entity_type, entity_id=req.entity_id,
                 entity_label=req.entity_label,
                 summary=f"Step {req.current_step + 1} of {len(req.steps)} approved by {p.user.full_name}"
                         + (f" as {step_role.replace('_', ' ').title()}" if step_role not in p.role_codes else "")
                         + (f": {comment}" if comment else ""))
    if req.current_step + 1 < len(req.steps):
        req.current_step += 1
        db.flush()
        notify(db, _approvers(db, req.steps[req.current_step]), event="approval.requested", exclude=p.id, link=link,
               title=f"Approval needed: {h.label} {req.entity_label}",
               body=f"₹{format_inr(req.amount)} before GST · approved by {p.user.full_name} · "
                    f"step {req.current_step + 1} of {len(req.steps)}")
        return req
    req.status, req.decided_at = "approved", datetime.now(UTC)
    db.flush()
    audit.record(db, action="approved", entity_type=req.entity_type, entity_id=req.entity_id,
                 entity_label=req.entity_label, summary=f"Fully approved ({req.policy_name})")
    h.on_approved(db, p, req)
    notify(db, tell, event="approval.approved", exclude=p.id, link=link,
           title=f"{h.label} {req.entity_label} is approved", body=f"Final approval by {p.user.full_name}")
    return req


def withdraw(db: Session, p: Principal, entity_type: str, entity_id: uuid.UUID) -> ApprovalRequest | None:
    req = pending_for(db, entity_type, entity_id)
    if req is None:
        return None
    req.status, req.decided_at = "withdrawn", datetime.now(UTC)
    req.actions.append(ApprovalAction(step_no=req.current_step, role_code=req.steps[req.current_step],
                                      decision="withdrawn", user_id=p.id))
    db.flush()
    return req


def inbox(db: Session, p: Principal) -> list[ApprovalRequest]:
    """Pending requests the user can decide now."""
    rows = db.scalars(select(ApprovalRequest).where(ApprovalRequest.status == "pending")
                      .order_by(ApprovalRequest.requested_at)).all()
    return [r for r in rows if can_decide(p, r)]
