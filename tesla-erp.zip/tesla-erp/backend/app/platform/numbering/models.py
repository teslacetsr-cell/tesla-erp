import uuid
from datetime import datetime

from sqlalchemy import CheckConstraint, DateTime, ForeignKey, Integer, String, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.models import AuditColumnsMixin, Base


class NumberingFormat(AuditColumnsMixin, Base):
    """How numbers for a document type look. Editable in Settings; changes are audited."""

    __tablename__ = "numbering_formats"
    __table_args__ = (
        UniqueConstraint("company_id", "doc_type"),
        CheckConstraint("period in ('fy','calendar','none')", name="period_valid"),
    )

    company_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), nullable=False)
    doc_type: Mapped[str] = mapped_column(String(30), nullable=False)
    label: Mapped[str] = mapped_column(String(100), nullable=False)
    pattern: Mapped[str] = mapped_column(String(60), nullable=False)
    period: Mapped[str] = mapped_column(String(10), nullable=False, default="fy")
    max_length: Mapped[int | None] = mapped_column(Integer)  # e.g. 16 for GST tax invoices


class DocumentSequence(Base):
    """Last number issued per (company, document type, period). Row-locked during allocation."""

    __tablename__ = "document_sequences"
    __table_args__ = (UniqueConstraint("company_id", "doc_type", "period_key"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("companies.id", ondelete="RESTRICT"), nullable=False)
    doc_type: Mapped[str] = mapped_column(String(30), nullable=False)
    period_key: Mapped[str] = mapped_column(String(10), nullable=False)
    last_value: Mapped[int] = mapped_column(Integer, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
