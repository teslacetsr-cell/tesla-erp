"""Centralised, transaction-safe document numbering (Spec §29).

Allocation is a single INSERT … ON CONFLICT DO UPDATE … RETURNING, which takes a row lock on
the sequence row until the surrounding transaction ends. Consequences:
  * two concurrent transactions can never receive the same number;
  * if the transaction that took a number rolls back, the increment rolls back too — no gaps.
Call `next_number` in the same transaction that saves the document, at the moment of issue.
"""
import re
import uuid
from datetime import date, datetime
from zoneinfo import ZoneInfo

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from app.core.errors import AppError
from app.core.india import financial_year
from app.platform.numbering.models import NumberingFormat

_TOKEN = re.compile(r"\{(FY|FYS|FYY|YYYY|SEQ(?::(\d+))?)\}")

# Financial-year numbering (approved 25 Sep 2026). GST tax invoices are limited to 16 characters.
DEFAULT_FORMATS: list[dict] = [
    {"doc_type": "QTN", "label": "Quotation", "pattern": "TCE/QTN/{FY}/{SEQ:4}", "period": "fy"},
    {"doc_type": "SO", "label": "Sales order", "pattern": "TCE/SO/{FY}/{SEQ:4}", "period": "fy"},
    {"doc_type": "PRJ", "label": "Project", "pattern": "TCE/PRJ/{FY}/{SEQ:4}", "period": "fy"},
    {"doc_type": "PO", "label": "Purchase order", "pattern": "TCE/PO/{FY}/{SEQ:4}", "period": "fy"},
    {"doc_type": "INV", "label": "Tax invoice", "pattern": "TCE/{FYS}/{SEQ:4}", "period": "fy", "max_length": 16},
    {"doc_type": "SRV", "label": "Service ticket", "pattern": "TCE/SRV/{FY}/{SEQ:4}", "period": "fy"},
    {"doc_type": "CUSTOMER", "label": "Customer code", "pattern": "CUS{SEQ:5}", "period": "none"},
    {"doc_type": "SUPPLIER", "label": "Supplier code", "pattern": "SUP{SEQ:5}", "period": "none"},
    {"doc_type": "ITEM", "label": "Item code", "pattern": "ITM{SEQ:5}", "period": "none"},
    {"doc_type": "EMPLOYEE", "label": "Employee code", "pattern": "TCE{SEQ:4}", "period": "none"},
]


def period_key(period: str, on: date) -> str:
    if period == "fy":
        start, end = financial_year(on)
        return f"{start}-{str(end)[2:]}"
    if period == "calendar":
        return str(on.year)
    return "-"


def render(pattern: str, seq: int, on: date) -> str:
    start, end = financial_year(on)

    def sub(m: re.Match) -> str:
        tok = m.group(1)
        if tok == "FY":
            return f"{start}-{str(end)[2:]}"
        if tok == "FYS":
            return f"{str(start)[2:]}{str(end)[2:]}"
        if tok == "FYY":
            return str(start)
        if tok == "YYYY":
            return str(on.year)
        width = int(m.group(2) or 1)
        return str(seq).zfill(width)

    return _TOKEN.sub(sub, pattern)


def validate_pattern(pattern: str, period: str, max_length: int | None) -> None:
    if "{SEQ" not in pattern:
        raise AppError("INVALID_PATTERN", "The pattern must contain a {SEQ} or {SEQ:n} token.")
    leftover = _TOKEN.sub("", pattern)
    if "{" in leftover or "}" in leftover:
        raise AppError("INVALID_PATTERN", "Unknown token. Allowed: {FY} {FYS} {FYY} {YYYY} {SEQ:n}.")
    if not re.fullmatch(r"[A-Za-z0-9/\-]*", leftover):
        raise AppError("INVALID_PATTERN", "Only letters, digits, '/' and '-' are allowed around the tokens.")
    uses_fy = any(t in pattern for t in ("{FY}", "{FYS}", "{FYY}"))
    if uses_fy and period != "fy":
        raise AppError("INVALID_PATTERN", "A financial-year token needs the period set to financial year.")
    if max_length:
        m = re.search(r"\{SEQ(?::(\d+))?\}", pattern)
        width = int(m.group(1) or 1) if m else 1
        sample = render(pattern, int("9" * max(width, 4)), date(2099, 12, 31))
        if len(sample) > max_length:
            raise AppError(
                "PATTERN_TOO_LONG",
                f"Numbers from this pattern can reach {len(sample)} characters; the limit is {max_length}.",
                details={"sample": sample},
            )


def next_number(session: Session, company_id: uuid.UUID, doc_type: str, on: date | None = None) -> str:
    fmt = session.scalar(
        select(NumberingFormat).where(NumberingFormat.company_id == company_id, NumberingFormat.doc_type == doc_type)
    )
    if fmt is None:
        raise AppError("NUMBERING_NOT_CONFIGURED", f"No numbering format is configured for {doc_type}.", status_code=500)
    on = on or datetime.now(ZoneInfo("Asia/Kolkata")).date()
    key = period_key(fmt.period, on)
    value = session.execute(
        text(
            """
            INSERT INTO document_sequences (id, company_id, doc_type, period_key, last_value)
            VALUES (:id, :company_id, :doc_type, :period_key, 1)
            ON CONFLICT (company_id, doc_type, period_key)
            DO UPDATE SET last_value = document_sequences.last_value + 1, updated_at = now()
            RETURNING last_value
            """
        ),
        {"id": uuid.uuid4(), "company_id": company_id, "doc_type": doc_type, "period_key": key},
    ).scalar_one()
    number = render(fmt.pattern, value, on)
    if fmt.max_length and len(number) > fmt.max_length:
        raise AppError("NUMBER_TOO_LONG", f"Generated number {number} exceeds {fmt.max_length} characters.", status_code=500)
    return number
