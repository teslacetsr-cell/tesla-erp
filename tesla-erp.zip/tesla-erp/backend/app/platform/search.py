"""Global search (Spec §35): one box in the top bar searches every kind of record the person may open.

Each kind is searched only when the person holds its read permission, and record-level scope is applied exactly as
in the module's own list (a salesperson with 'own' scope finds only their own leads, quotations and orders; an
employee finds only their own expense claims). Employees are found by name, code and designation only — no
personal, bank or salary details are searched or returned.

Speed: trigram GIN indexes on the searched name / number columns (migration 0010n) keep `ILIKE '%…%'` fast; every
kind is capped at `limit` rows, and a document number that starts with the text is ranked first.
"""
from collections.abc import Callable
from dataclasses import dataclass

from sqlalchemy import case, func, or_, select
from sqlalchemy.orm import Session

from app.auth.deps import Principal
from app.core.money import format_inr


@dataclass(frozen=True)
class Kind:
    type: str
    label: str
    perm: str
    run: Callable[[Session, Principal, str, str, int], list[dict]]


def _money(v) -> str | None:
    return f"₹{format_inr(v).removesuffix('.00')}" if v is not None else None


def _sub(*parts) -> str:
    return " · ".join(str(x) for x in parts if x not in (None, ""))


def _status(s: str | None) -> str | None:
    return s.replace("_", " ") if s else None


def _rank(number_col, q: str):
    """Exact or prefix match of the document number first."""
    esc = q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return case((func.lower(number_col) == q.lower(), 0), (number_col.ilike(f"{esc}%"), 1), else_=2)


def _item(i, title, subtitle, href) -> dict:
    return {"id": str(i), "title": title or "—", "subtitle": subtitle or "", "href": href}


# ------------------------------------------------------------------ masters
def _customers(db, p, q, like, n):
    from app.customers.models import Customer
    rows = db.scalars(select(Customer).where(or_(
        Customer.customer_name.ilike(like), Customer.customer_code.ilike(like), Customer.gstin.ilike(like),
        Customer.phone.ilike(like), Customer.city.ilike(like)))
        .order_by(_rank(Customer.customer_code, q), func.similarity(Customer.customer_name, q).desc()).limit(n))
    return [_item(c.id, c.customer_name, _sub(c.customer_code, c.city), f"/customers/view?id={c.id}") for c in rows]


def _suppliers(db, p, q, like, n):
    from app.suppliers.models import Supplier
    rows = db.scalars(select(Supplier).where(or_(
        Supplier.supplier_name.ilike(like), Supplier.supplier_code.ilike(like), Supplier.gstin.ilike(like),
        Supplier.supplies.ilike(like)))
        .order_by(_rank(Supplier.supplier_code, q), func.similarity(Supplier.supplier_name, q).desc()).limit(n))
    return [_item(s.id, s.supplier_name, _sub(s.supplier_code, s.city), f"/suppliers/view?id={s.id}") for s in rows]


def _items(db, p, q, like, n):
    from app.products.models import Item
    rows = db.scalars(select(Item).where(or_(
        Item.item_name.ilike(like), Item.item_code.ilike(like), Item.model.ilike(like), Item.hsn_sac.ilike(like)))
        .order_by(_rank(Item.item_code, q), func.similarity(Item.item_name, q).desc()).limit(n))
    return [_item(i.id, i.item_name, _sub(i.item_code, i.model), f"/items/view?id={i.id}") for i in rows]


def _employees(db, p, q, like, n):
    from app.hr.models import Designation, Employee
    rows = db.execute(select(Employee.id, Employee.full_name, Employee.employee_code, Designation.name,
                             Employee.is_active)
                      .outerjoin(Designation, Designation.id == Employee.designation_id)
                      .where(or_(Employee.full_name.ilike(like), Employee.employee_code.ilike(like),
                                 Designation.name.ilike(like)))
                      .order_by(Employee.is_active.desc(), _rank(Employee.employee_code, q), Employee.full_name)
                      .limit(n))
    return [_item(i, name, _sub(code, desig, None if active else "left"), f"/hr/employees/view?id={i}")
            for i, name, code, desig, active in rows]


# ------------------------------------------------------------------ CRM & sales
def _crm(module: str):
    def run(db, p, q, like, n):
        from app.crm import service as crm
        from app.crm.models import Enquiry, Lead, SiteVisit
        from app.customers.models import Customer

        if module == "lead":
            stmt = select(Lead).where(or_(Lead.lead_number.ilike(like), Lead.title.ilike(like),
                                          Lead.company_name.ilike(like), Lead.contact_name.ilike(like),
                                          Lead.contact_phone.ilike(like)))
            order = (_rank(Lead.lead_number, q), Lead.created_at.desc())
        elif module == "enquiry":
            stmt = select(Enquiry).where(or_(Enquiry.enquiry_number.ilike(like), Enquiry.subject.ilike(like),
                                             Enquiry.customer_id.in_(select(Customer.id).where(
                                                 Customer.customer_name.ilike(like)))))
            order = (_rank(Enquiry.enquiry_number, q), Enquiry.created_at.desc())
        else:
            stmt = select(SiteVisit).where(or_(SiteVisit.visit_number.ilike(like), SiteVisit.site_location.ilike(like),
                                               SiteVisit.customer_id.in_(select(Customer.id).where(
                                                   Customer.customer_name.ilike(like)))))
            order = (_rank(SiteVisit.visit_number, q), SiteVisit.visit_date.desc())
        if (c := crm.scope_clause(p, module, "read")) is not None:
            stmt = stmt.where(c)
        rows = db.scalars(stmt.order_by(*order).limit(n)).all()
        if module == "lead":
            return [_item(x.id, x.title, _sub(x.lead_number, x.company_name, _status(x.status)),
                          f"/crm/leads/view?id={x.id}") for x in rows]
        if module == "enquiry":
            return [_item(x.id, x.subject, _sub(x.enquiry_number, _status(x.status)), f"/crm/enquiries/view?id={x.id}")
                    for x in rows]
        return [_item(x.id, x.site_location or x.visit_number, _sub(x.visit_number, f"{x.visit_date:%d %b %Y}"),
                      f"/crm/site-visits/view?id={x.id}") for x in rows]
    return run


def _boqs(db, p, q, like, n):
    from app.boq.models import Boq
    rows = db.scalars(select(Boq).where(or_(Boq.boq_number.ilike(like), Boq.title.ilike(like)))
                      .order_by(_rank(Boq.boq_number, q), Boq.created_at.desc()).limit(n))
    return [_item(x.id, x.title, _sub(x.boq_number, _status(x.status)), f"/projects/boq/view?id={x.id}") for x in rows]


def _quotations(db, p, q, like, n):
    from app.customers.models import Customer
    from app.quotations import service as qs
    from app.quotations.models import Quotation
    stmt = select(Quotation).where(or_(Quotation.quotation_number.ilike(like), Quotation.subject.ilike(like),
                                       Quotation.customer_id.in_(select(Customer.id).where(
                                           Customer.customer_name.ilike(like)))))
    if (c := qs.scope_clause(p)) is not None:
        stmt = stmt.where(c)
    rows = db.scalars(stmt.order_by(_rank(Quotation.quotation_number, q), Quotation.updated_at.desc()).limit(n))
    return [_item(x.id, x.subject, _sub(x.display_number, _status(x.status)), f"/sales/quotations/view?id={x.id}")
            for x in rows]


def _sales_orders(db, p, q, like, n):
    from app.customers.models import Customer
    from app.sales.models import SalesOrder
    S = SalesOrder
    stmt = (select(S.id, S.so_number, S.subject, Customer.customer_name, S.taxable, S.status)
            .join(Customer, Customer.id == S.customer_id)
            .where(or_(S.so_number.ilike(like), S.subject.ilike(like), S.customer_po_number.ilike(like),
                       S.quotation_number.ilike(like), Customer.customer_name.ilike(like))))
    if p.scope("sales_order.read") == "own":
        stmt = stmt.where(or_(S.sales_person_id == p.id, S.created_by == p.id))
    rows = db.execute(stmt.order_by(_rank(S.so_number, q), S.so_date.desc()).limit(n))
    return [_item(i, subj, _sub(num, cust, _money(v), _status(st)), f"/sales/orders/view?id={i}")
            for i, num, subj, cust, v, st in rows]


# ------------------------------------------------------------------ projects
def _projects(db, p, q, like, n):
    from app.customers.models import Customer
    from app.projects import service as projects
    from app.projects.models import Project
    stmt = (select(Project.id, Project.project_number, Project.name, Customer.customer_name, Project.status)
            .join(Customer, Customer.id == Project.customer_id)
            .where(or_(Project.project_number.ilike(like), Project.name.ilike(like), Customer.customer_name.ilike(like),
                       Project.site_address.ilike(like))))
    if (c := projects.scope_clause(p, "project.read")) is not None:
        stmt = stmt.where(c)
    rows = db.execute(stmt.order_by(_rank(Project.project_number, q), Project.created_at.desc()).limit(n))
    return [_item(i, name, _sub(num, cust, _status(st)), f"/projects/view?id={i}") for i, num, name, cust, st in rows]


def _tasks(db, p, q, like, n):
    from app.projects import service as projects
    from app.projects.models import Project, ProjectTask
    T = ProjectTask
    stmt = (select(T.id, T.title, T.project_id, Project.project_number, T.status, T.due_date)
            .join(Project, Project.id == T.project_id)
            .where(or_(T.title.ilike(like), Project.project_number.ilike(like))))
    if p.scope("site_work.read") is None:
        stmt = stmt.where(T.assigned_to == p.id)
    elif (c := projects.scope_clause(p, "site_work.read")) is not None:
        stmt = stmt.where(or_(c, T.assigned_to == p.id))
    rows = db.execute(stmt.order_by(T.status == "done", T.due_date.nulls_last()).limit(n))
    # someone who cannot open projects (an employee with a task) goes to their task list
    see_project = p.can("project.read")
    return [_item(i, title, _sub(num, _status(st), f"due {due:%d %b %Y}" if due else None),
                  f"/projects/view?id={pid}&tab=tasks" if see_project else f"/projects/tasks?id={i}")
            for i, title, pid, num, st, due in rows]


def _material_issues(db, p, q, like, n):
    from app.costing.models import MaterialIssue
    from app.projects import service as projects
    from app.projects.models import Project
    M = MaterialIssue
    stmt = (select(M.id, M.issue_number, M.kind, Project.project_number, Project.name, M.status, M.issue_date)
            .join(Project, Project.id == M.project_id)
            .where(or_(M.issue_number.ilike(like), M.issued_to.ilike(like), Project.project_number.ilike(like),
                       Project.name.ilike(like))))
    if (c := projects.scope_clause(p, "material_issue.read")) is not None:
        stmt = stmt.where(c)
    rows = db.execute(stmt.order_by(_rank(M.issue_number, q), M.issue_date.desc()).limit(n))
    return [_item(i, f"{'Return' if kind == 'return' else 'Issue'} to {pnum} {pname}",
                  _sub(num or "Draft", f"{d:%d %b %Y}", _status(st)), f"/inventory/issues/view?id={i}")
            for i, num, kind, pnum, pname, st, d in rows]


# ------------------------------------------------------------------ purchase
def _material_requests(db, p, q, like, n):
    from app.projects.models import Project
    from app.purchase.models import MaterialRequest as MR
    stmt = (select(MR.id, MR.mr_number, MR.purpose, Project.project_number, MR.status, MR.request_date)
            .outerjoin(Project, Project.id == MR.project_id)
            .where(or_(MR.mr_number.ilike(like), MR.purpose.ilike(like), Project.project_number.ilike(like),
                       Project.name.ilike(like))))
    if p.scope("material_request.read") == "own":
        stmt = stmt.where(MR.created_by == p.id)
    rows = db.execute(stmt.order_by(_rank(MR.mr_number, q), MR.request_date.desc()).limit(n))
    return [_item(i, purpose or f"Material request {num or 'draft'}", _sub(num or "Draft", pnum, _status(st)),
                  f"/purchase/material-requests/view?id={i}") for i, num, purpose, pnum, st, d in rows]


def _purchase_requests(db, p, q, like, n):
    from app.projects.models import Project
    from app.purchase.models import PurchaseRequest as PR
    rows = db.execute(select(PR.id, PR.pr_number, PR.notes, Project.project_number, PR.status, PR.estimated_value)
                      .outerjoin(Project, Project.id == PR.project_id)
                      .where(or_(PR.pr_number.ilike(like), PR.notes.ilike(like), Project.project_number.ilike(like)))
                      .order_by(_rank(PR.pr_number, q), PR.pr_date.desc()).limit(n))
    return [_item(i, f"Purchase request {num or '(draft)'}", _sub(pnum, _money(v), _status(st), (notes or "")[:60]),
                  f"/purchase/requests/view?id={i}") for i, num, notes, pnum, st, v in rows]


def _rfqs(db, p, q, like, n):
    from app.projects.models import Project
    from app.purchase.rfq_models import Rfq
    rows = db.execute(select(Rfq.id, Rfq.rfq_number, Rfq.notes, Project.project_number, Rfq.status, Rfq.due_date)
                      .outerjoin(Project, Project.id == Rfq.project_id)
                      .where(or_(Rfq.rfq_number.ilike(like), Rfq.notes.ilike(like), Rfq.contact_person.ilike(like),
                                 Project.project_number.ilike(like)))
                      .order_by(_rank(Rfq.rfq_number, q), Rfq.rfq_date.desc()).limit(n))
    return [_item(i, f"Request for quotation {num or '(draft)'}",
                  _sub(pnum, _status(st), f"replies by {due:%d %b}" if due else None), f"/purchase/rfqs/view?id={i}")
            for i, num, notes, pnum, st, due in rows]


def _purchase_orders(db, p, q, like, n):
    from app.purchase.models import PurchaseOrder as PO
    from app.suppliers.models import Supplier
    rows = db.execute(select(PO.id, PO.po_number, Supplier.supplier_name, PO.taxable, PO.status)
                      .join(Supplier, Supplier.id == PO.supplier_id)
                      .where(or_(PO.po_number.ilike(like), PO.supplier_quote_ref.ilike(like),
                                 Supplier.supplier_name.ilike(like)))
                      .order_by(_rank(PO.po_number, q), PO.po_date.desc()).limit(n))
    return [_item(i, sup, _sub(num or "Draft", _money(v), _status(st)), f"/purchase/orders/view?id={i}")
            for i, num, sup, v, st in rows]


def _grns(db, p, q, like, n):
    from app.purchase.models import Grn
    from app.suppliers.models import Supplier
    rows = db.execute(select(Grn.id, Grn.grn_number, Supplier.supplier_name, Grn.grn_date, Grn.supplier_invoice_no)
                      .join(Supplier, Supplier.id == Grn.supplier_id)
                      .where(or_(Grn.grn_number.ilike(like), Grn.supplier_invoice_no.ilike(like),
                                 Grn.delivery_challan_no.ilike(like), Supplier.supplier_name.ilike(like)))
                      .order_by(_rank(Grn.grn_number, q), Grn.grn_date.desc()).limit(n))
    return [_item(i, sup, _sub(num, f"{d:%d %b %Y}", f"supplier inv. {inv}" if inv else None),
                  f"/purchase/grn/view?id={i}") for i, num, sup, d, inv in rows]


# ------------------------------------------------------------------ finance
def _invoices(db, p, q, like, n):
    from app.customers.models import Customer
    from app.finance.models import Invoice
    rows = db.execute(select(Invoice.id, Invoice.invoice_number, Customer.customer_name, Invoice.grand_total,
                             Invoice.status, Invoice.payment_status)
                      .join(Customer, Customer.id == Invoice.customer_id)
                      .where(or_(Invoice.invoice_number.ilike(like), Invoice.subject.ilike(like),
                                 Invoice.customer_po_number.ilike(like), Customer.customer_name.ilike(like)))
                      .order_by(_rank(Invoice.invoice_number, q), Invoice.invoice_date.desc()).limit(n))
    return [_item(i, cust, _sub(num or "Draft", _money(v), _status(ps) if st == "issued" else _status(st)),
                  f"/sales/invoices/view?id={i}") for i, num, cust, v, st, ps in rows]


def _receipts(db, p, q, like, n):
    from app.customers.models import Customer
    from app.finance.models import Receipt
    rows = db.execute(select(Receipt.id, Receipt.receipt_number, Customer.customer_name, Receipt.amount,
                             Receipt.receipt_date, Receipt.status)
                      .join(Customer, Customer.id == Receipt.customer_id)
                      .where(or_(Receipt.receipt_number.ilike(like), Receipt.reference_no.ilike(like),
                                 Customer.customer_name.ilike(like)))
                      .order_by(_rank(Receipt.receipt_number, q), Receipt.receipt_date.desc()).limit(n))
    return [_item(i, cust, _sub(num, _money(v), f"{d:%d %b %Y}", "cancelled" if st == "cancelled" else None),
                  f"/finance/receipts/view?id={i}") for i, num, cust, v, d, st in rows]


def _bills(db, p, q, like, n):
    from app.finance.models import SupplierInvoice as B
    from app.suppliers.models import Supplier
    rows = db.execute(select(B.id, B.bill_number, B.supplier_invoice_no, Supplier.supplier_name, B.grand_total, B.status)
                      .join(Supplier, Supplier.id == B.supplier_id)
                      .where(or_(B.bill_number.ilike(like), B.supplier_invoice_no.ilike(like),
                                 Supplier.supplier_name.ilike(like)))
                      .order_by(_rank(B.supplier_invoice_no, q), B.supplier_invoice_date.desc()).limit(n))
    return [_item(i, sup, _sub(num or "Draft", f"their no. {sno}", _money(v), _status(st)),
                  f"/finance/bills/view?id={i}") for i, num, sno, sup, v, st in rows]


def _payments(db, p, q, like, n):
    from app.finance.models import SupplierPayment as S
    from app.suppliers.models import Supplier
    rows = db.execute(select(S.id, S.payment_number, Supplier.supplier_name, S.amount, S.payment_date, S.status)
                      .join(Supplier, Supplier.id == S.supplier_id)
                      .where(or_(S.payment_number.ilike(like), S.reference_no.ilike(like),
                                 Supplier.supplier_name.ilike(like)))
                      .order_by(_rank(S.payment_number, q), S.payment_date.desc()).limit(n))
    return [_item(i, sup, _sub(num, _money(v), f"{d:%d %b %Y}", "cancelled" if st == "cancelled" else None),
                  f"/finance/payments/view?id={i}") for i, num, sup, v, d, st in rows]


def _expenses(db, p, q, like, n):
    from app.finance.expenses import _own_ids
    from app.finance.models import ExpenseClaim as E
    from app.hr.models import Employee
    stmt = (select(E.id, E.expense_number, E.description, Employee.full_name, E.amount, E.status)
            .join(Employee, Employee.id == E.employee_id))
    if p.scope("expense.read") == "own":
        emp_id, uid = _own_ids(db, p)
        stmt = stmt.where(or_(E.employee_id == emp_id, E.created_by == uid))
        stmt = stmt.where(or_(E.expense_number.ilike(like), E.description.ilike(like)))
    else:
        stmt = stmt.where(or_(E.expense_number.ilike(like), E.description.ilike(like), Employee.full_name.ilike(like)))
    rows = db.execute(stmt.order_by(_rank(E.expense_number, q), E.expense_date.desc()).limit(n))
    return [_item(i, (desc or "")[:80], _sub(num or "Draft", emp, _money(v), _status(st)),
                  f"/finance/expenses/view?id={i}") for i, num, desc, emp, v, st in rows]


KINDS: list[Kind] = [
    Kind("customer", "Customers", "customer.read", _customers),
    Kind("lead", "Leads", "lead.read", _crm("lead")),
    Kind("enquiry", "Enquiries", "enquiry.read", _crm("enquiry")),
    Kind("site_visit", "Site visits", "site_visit.read", _crm("site_visit")),
    Kind("quotation", "Quotations", "quotation.read", _quotations),
    Kind("sales_order", "Sales orders", "sales_order.read", _sales_orders),
    Kind("project", "Projects", "project.read", _projects),
    Kind("task", "Tasks", "", _tasks),
    Kind("boq", "BOQs", "boq.read", _boqs),
    Kind("invoice", "Invoices", "invoice.read", _invoices),
    Kind("receipt", "Receipts", "receipt.read", _receipts),
    Kind("supplier", "Suppliers", "supplier.read", _suppliers),
    Kind("item", "Items", "item.read", _items),
    Kind("material_request", "Material requests", "material_request.read", _material_requests),
    Kind("purchase_request", "Purchase requests", "purchase_request.read", _purchase_requests),
    Kind("rfq", "Vendor quotation requests", "rfq.read", _rfqs),
    Kind("purchase_order", "Purchase orders", "purchase_order.read", _purchase_orders),
    Kind("grn", "Goods received (GRN)", "grn.read", _grns),
    Kind("material_issue", "Material issues", "material_issue.read", _material_issues),
    Kind("supplier_bill", "Supplier bills", "supplier_invoice.read", _bills),
    Kind("supplier_payment", "Supplier payments", "supplier_payment.read", _payments),
    Kind("expense", "Expense claims", "expense.read", _expenses),
    Kind("employee", "Employees", "employee.read", _employees),
]
BY_TYPE = {k.type: k for k in KINDS}


def search(db: Session, p: Principal, q: str, *, limit: int = 5, types: list[str] | None = None) -> list[dict]:
    q = " ".join(q.split())
    esc = q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    like = f"%{esc}%"
    groups = []
    for k in KINDS:
        if types and k.type not in types:
            continue
        if k.perm and not p.can(k.perm):
            continue
        items = k.run(db, p, q, like, limit)
        if items:
            groups.append({"type": k.type, "label": k.label, "items": items})
    return groups
