"""Document storage service: validated upload, versioning, permission-checked download."""
import hashlib
import mimetypes
import secrets
import uuid
from dataclasses import dataclass
from pathlib import PurePath

import filetype
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.errors import AppError, NotFound
from app.platform.audit import service as audit
from app.platform.documents.models import CATEGORIES, Document
from app.platform.documents.storage import get_storage


@dataclass(frozen=True)
class EntityDef:
    permission_module: str
    model: type


ENTITIES: dict[str, EntityDef] = {}


def register_entity(entity_type: str, permission_module: str, model: type) -> None:
    ENTITIES[entity_type] = EntityDef(permission_module, model)


# Real content type is detected from the bytes, never trusted from the browser or file extension.
_SNIFFED_ALLOWED = {
    "application/pdf": {".pdf"},
    "image/jpeg": {".jpg", ".jpeg"},
    "image/png": {".png"},
    "image/webp": {".webp"},
    "image/heic": {".heic"},
    "application/zip": {".docx", ".xlsx", ".pptx"},  # Office Open XML files are zip containers
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {".docx"},
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {".xlsx"},
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": {".pptx"},
}
_TEXT_EXT = {".csv", ".txt"}


def _detect(data: bytes, file_name: str) -> str:
    ext = PurePath(file_name).suffix.lower()
    if data[:4] == b"AC10" and ext == ".dwg":
        return "image/vnd.dwg"
    kind = filetype.guess(data[:8192])
    if kind is not None:
        allowed_ext = _SNIFFED_ALLOWED.get(kind.mime)
        if allowed_ext is None or ext not in allowed_ext:
            raise AppError("FILE_TYPE_NOT_ALLOWED", f"Files of type {kind.mime} with extension '{ext}' are not allowed.")
        if kind.mime == "application/zip" or kind.mime.startswith("application/vnd.openxml"):
            return mimetypes.types_map.get(ext) or {
                ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            }[ext]
        return kind.mime
    if ext in _TEXT_EXT and b"\x00" not in data:
        try:
            data.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise AppError("FILE_TYPE_NOT_ALLOWED", "Text files must be UTF-8.") from exc
        return "text/csv" if ext == ".csv" else "text/plain"
    raise AppError(
        "FILE_TYPE_NOT_ALLOWED",
        "Allowed files: PDF, JPG, PNG, WEBP, HEIC, DOCX, XLSX, PPTX, DWG, CSV, TXT.",
    )


def _safe_name(file_name: str) -> str:
    name = PurePath(file_name.replace("\\", "/")).name.strip()
    name = "".join(c for c in name if c.isprintable() and c not in '<>:"|?*')
    if not name or name in (".", ".."):
        raise AppError("INVALID_FILE_NAME", "The file name is not valid.")
    return name[:200]


def get_entity(session: Session, entity_type: str, entity_id: uuid.UUID):
    edef = ENTITIES.get(entity_type)
    if edef is None:
        raise AppError("UNKNOWN_ENTITY_TYPE", f"Documents cannot be attached to '{entity_type}'.")
    obj = session.get(edef.model, entity_id)
    if obj is None:
        raise NotFound(entity_type)
    return edef, obj


def upload(
    session: Session,
    *,
    entity_type: str,
    entity_id: uuid.UUID,
    category: str,
    file_name: str,
    data: bytes,
    user_id: uuid.UUID | None,
    title: str | None = None,
    replaces: uuid.UUID | None = None,
) -> Document:
    if category not in CATEGORIES:
        raise AppError("INVALID_CATEGORY", "Unknown document category.", details={"allowed": CATEGORIES})
    max_bytes = get_settings().max_upload_mb * 1024 * 1024
    if not data:
        raise AppError("EMPTY_FILE", "The file is empty.")
    if len(data) > max_bytes:
        raise AppError("FILE_TOO_LARGE", f"Files must be at most {get_settings().max_upload_mb} MB.", status_code=413)
    name = _safe_name(file_name)
    content_type = _detect(data, name)

    group_id, version = uuid.uuid4(), 1
    if replaces is not None:
        prev = session.get(Document, replaces, with_for_update=True)
        if prev is None or prev.entity_type != entity_type or prev.entity_id != entity_id or prev.status != "available":
            raise NotFound("document")
        if not prev.is_latest:
            raise AppError("NOT_LATEST_VERSION", "Only the latest version of a document can be replaced.")
        group_id, version = prev.group_id, prev.version + 1
        session.execute(update(Document).where(Document.group_id == group_id).values(is_latest=False))

    ext = PurePath(name).suffix.lower()
    key = f"{entity_type}/{entity_id}/{group_id}/v{version}-{secrets.token_hex(8)}{ext}"
    get_storage().put(key, data, content_type)  # write the bytes first; DB row only if storage succeeded

    doc = Document(
        group_id=group_id, version=version, is_latest=True, category=category, entity_type=entity_type,
        entity_id=entity_id, title=title, file_name=name, content_type=content_type, size_bytes=len(data),
        sha256=hashlib.sha256(data).hexdigest(), storage_key=key, status="available", uploaded_by=user_id,
    )
    session.add(doc)
    session.flush()
    audit.record(
        session, action="upload", entity_type=entity_type, entity_id=entity_id, entity_label=name,
        summary=f"Uploaded {category} '{name}' (v{version}, {len(data):,} bytes)",
    )
    return doc


def list_for(session: Session, entity_type: str, entity_id: uuid.UUID, include_history: bool = False) -> list[Document]:
    stmt = select(Document).where(
        Document.entity_type == entity_type, Document.entity_id == entity_id, Document.status == "available"
    )
    if not include_history:
        stmt = stmt.where(Document.is_latest.is_(True))
    return list(session.scalars(stmt.order_by(Document.uploaded_at.desc(), Document.version.desc())))


def get(session: Session, document_id: uuid.UUID) -> Document:
    doc = session.get(Document, document_id)
    if doc is None or doc.status != "available":
        raise NotFound("document")
    return doc


def remove(session: Session, doc: Document) -> None:
    """Soft delete: hidden from lists, bytes kept in storage (versioned bucket) for recovery."""
    doc.status = "deleted"
    doc.is_latest = False
    audit.record(
        session, action="delete", entity_type=doc.entity_type, entity_id=doc.entity_id, entity_label=doc.file_name,
        summary=f"Removed document '{doc.file_name}' v{doc.version} (retained in storage)",
    )
