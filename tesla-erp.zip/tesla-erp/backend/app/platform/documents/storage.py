"""Object storage adapters. S3 (or any S3-compatible store such as MinIO) in every real environment.

The `local` backend exists only for development and tests; configuration refuses it in
staging/production (see core/config.py), so business documents can never end up on
ephemeral application-server disk in a deployed system.
"""
from pathlib import Path
from typing import Protocol

from app.core.config import get_settings


class Storage(Protocol):
    def put(self, key: str, data: bytes, content_type: str) -> None: ...
    def get(self, key: str) -> bytes: ...
    def exists(self, key: str) -> bool: ...
    def download_url(self, key: str, file_name: str, expires: int = 300) -> str | None: ...


class S3Storage:
    def __init__(self) -> None:
        import boto3
        from botocore.config import Config

        s = get_settings()
        self.bucket = s.storage_bucket
        self.client = boto3.client(
            "s3",
            endpoint_url=s.storage_endpoint,
            region_name=s.storage_region,
            aws_access_key_id=s.storage_access_key,
            aws_secret_access_key=s.storage_secret_key,
            config=Config(signature_version="s3v4", retries={"max_attempts": 5, "mode": "standard"}),
        )

    def put(self, key: str, data: bytes, content_type: str) -> None:
        extra = {"ServerSideEncryption": "AES256"} if get_settings().storage_sse else {}
        self.client.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type, **extra)

    def get(self, key: str) -> bytes:
        return self.client.get_object(Bucket=self.bucket, Key=key)["Body"].read()

    def exists(self, key: str) -> bool:
        try:
            self.client.head_object(Bucket=self.bucket, Key=key)
            return True
        except self.client.exceptions.ClientError:
            return False

    def health(self) -> tuple[bool, str]:
        """Can the app list the bucket? Shown on Settings → System."""
        try:
            self.client.list_objects_v2(Bucket=self.bucket, MaxKeys=1)
            return True, "reachable"
        except Exception as exc:  # noqa: BLE001 - reported to administrators, not raised
            return False, f"{type(exc).__name__}: {str(exc)[:200]}"

    def download_url(self, key: str, file_name: str, expires: int = 300) -> str | None:
        safe = file_name.replace('"', "")
        return self.client.generate_presigned_url(
            "get_object",
            Params={"Bucket": self.bucket, "Key": key, "ResponseContentDisposition": f'attachment; filename="{safe}"'},
            ExpiresIn=expires,
        )


class FilesystemStorage:
    """Durable folder storage for on-premise installs — normally a NAS share (\\\\NAS\\TCE-ERP\\documents).

    Files are written to a temporary name, flushed to disk and then renamed into place, so a power cut or
    network drop never leaves a half-written document under its final name. Keys are unique per upload,
    so an existing file is never overwritten.
    """

    def __init__(self, root: str | None = None) -> None:
        path = root or get_settings().storage_path
        if not path:
            raise RuntimeError("STORAGE_PATH is not set")
        self.root = Path(path)

    def _path(self, key: str) -> Path:
        if key.startswith(("/", "\\")) or ".." in Path(key).parts:
            raise ValueError("invalid key")
        return self.root.joinpath(*key.split("/"))

    def put(self, key: str, data: bytes, content_type: str) -> None:
        import os
        import secrets

        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        if p.exists():
            raise FileExistsError(f"refusing to overwrite {key}")
        tmp = p.with_name(f".{p.name}.{secrets.token_hex(4)}.part")
        with open(tmp, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, p)

    def get(self, key: str) -> bytes:
        return self._path(key).read_bytes()

    def exists(self, key: str) -> bool:
        return self._path(key).exists()

    def download_url(self, key: str, file_name: str, expires: int = 300) -> str | None:
        return None  # served through the API content endpoint (permission-checked)

    def health(self) -> tuple[bool, str]:
        """Can we write, read back and delete a probe file? Used at start-up and by the status page."""
        import os
        import secrets

        probe = self.root / ".health" / f"probe-{secrets.token_hex(4)}"
        try:
            probe.parent.mkdir(parents=True, exist_ok=True)
            probe.write_bytes(b"ok")
            ok = probe.read_bytes() == b"ok"
            os.remove(probe)
            return ok, "writable" if ok else "read-back mismatch"
        except OSError as exc:
            return False, f"{type(exc).__name__}: {exc}"


class LocalStorage:
    """Development/test only."""

    def __init__(self) -> None:
        self.root = Path(get_settings().storage_local_path).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        p = (self.root / key).resolve()
        if self.root not in p.parents:
            raise ValueError("invalid key")
        return p

    def put(self, key: str, data: bytes, content_type: str) -> None:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)

    def get(self, key: str) -> bytes:
        return self._path(key).read_bytes()

    def exists(self, key: str) -> bool:
        return self._path(key).exists()

    def download_url(self, key: str, file_name: str, expires: int = 300) -> str | None:
        return None  # served through the API content endpoint instead


_storage: Storage | None = None


def get_storage() -> Storage:
    global _storage
    if _storage is None:
        backend = get_settings().storage_backend
        _storage = S3Storage() if backend == "s3" else FilesystemStorage() if backend == "filesystem" else LocalStorage()
    return _storage


def set_storage(storage: Storage | None) -> None:
    """Tests use this to swap backends."""
    global _storage
    _storage = storage
