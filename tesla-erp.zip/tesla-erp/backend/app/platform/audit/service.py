"""Audit trail (Spec §32). Always called inside the same transaction as the change it records."""
import uuid
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import Any

from sqlalchemy import inspect
from sqlalchemy.orm import Session

from app.core.context import request_ctx
from app.platform.audit.models import AuditLog

# Never copy these into the audit log. Encrypted/sensitive fields are recorded as "changed" only.
_NEVER = {"password_hash", "updated_at", "created_at", "row_version", "updated_by", "created_by"}
_SENSITIVE = {"account_number", "secret", "pan_encrypted", "salary"}


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, (Decimal, uuid.UUID)):
        return str(value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, float):
        return str(value)
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, dict):
        return {k: _jsonable(v) for k, v in value.items()}
    return str(value)


def snapshot(obj: Any) -> dict[str, Any]:
    """Column values of an ORM object, JSON-safe, excluding noise fields."""
    mapper = inspect(obj).mapper
    return {
        attr.key: _jsonable(getattr(obj, attr.key))
        for attr in mapper.column_attrs
        if attr.key not in _NEVER
    }


def diff(before: dict[str, Any] | None, after: dict[str, Any] | None) -> dict[str, dict[str, Any]]:
    before, after = before or {}, after or {}
    changes: dict[str, dict[str, Any]] = {}
    for key in sorted(set(before) | set(after)):
        old, new = before.get(key), after.get(key)
        if old != new:
            if key in _SENSITIVE:
                changes[key] = {"old": "••••" if old else None, "new": "•••• (changed)" if new else None}
            else:
                changes[key] = {"old": old, "new": new}
    return changes


def record(
    session: Session,
    *,
    action: str,
    entity_type: str,
    entity_id: Any = None,
    entity_label: str | None = None,
    before: dict[str, Any] | None = None,
    after: dict[str, Any] | None = None,
    summary: str | None = None,
    user_id: uuid.UUID | None = None,
) -> AuditLog | None:
    ctx = request_ctx.get()
    changes = diff(before, after) if (before is not None or after is not None) else None
    if action == "update" and changes == {}:
        return None  # nothing actually changed — no noise in the log
    entry = AuditLog(
        user_id=user_id or ctx.user_id,
        action=action,
        entity_type=entity_type,
        entity_id=str(entity_id) if entity_id is not None else None,
        entity_label=(entity_label or "")[:255] or None,
        changes=changes,
        summary=summary,
        ip=ctx.ip,
        user_agent=(ctx.user_agent or "")[:255] or None,
        request_id=ctx.request_id if ctx.request_id != "-" else None,
    )
    session.add(entry)
    return entry
