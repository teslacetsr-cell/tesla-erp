"""travel expenses need a bill / photo: every expense category booked to the "Travelling & Conveyance" ledger
(travel tickets, local conveyance / fuel, food & lodging) now requires a bill or photo before the claim can be
submitted. Data only; no schema change. Admins can still change it per category in Masters → Expense categories.

Revision ID: 0011a
Revises: 0010c
Create Date: 2026-11-21 09:40:00
"""
from collections.abc import Sequence

from alembic import op

revision: str = '0011a'
down_revision: str | None = '0010c'
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.execute("""
        UPDATE expense_categories c SET needs_receipt = true
        FROM ledger_accounts a
        WHERE a.id = c.account_id AND a.name = 'Travelling & Conveyance' AND c.needs_receipt = false
    """)


def downgrade() -> None:
    # The earlier setting per category is not known; the standard one had only local conveyance / fuel without a bill.
    op.execute("""
        UPDATE expense_categories SET needs_receipt = false WHERE name = 'Local conveyance / fuel'
    """)
