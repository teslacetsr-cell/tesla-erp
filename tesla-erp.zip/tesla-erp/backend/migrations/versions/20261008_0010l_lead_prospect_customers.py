"""lead prospects become customers: customers.is_prospect and customers.source

A lead entered with new customer details now creates the customer record at once (with the next customer code).
Such a customer is marked as a prospect until its details (GSTIN etc.) are completed. Additive only: two new
columns with defaults, so every existing customer stays a regular customer. Existing open prospect leads are linked
to customers by `app.seed core` (idempotent backfill, runs on every deploy).

Revision ID: 0010l
Revises: 0010n
Create Date: 2026-10-08 10:00:00
"""
from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = '0010l'
down_revision: str | None = '0010n'
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column('customers', sa.Column('is_prospect', sa.Boolean(), server_default='false', nullable=False))
    op.add_column('customers', sa.Column('source', sa.String(length=20), nullable=True))


def downgrade() -> None:
    op.drop_column('customers', 'source')
    op.drop_column('customers', 'is_prospect')
