"""Embedded PostgreSQL: create the cluster, keep it running, create the ERP database, take dumps.

Windows: the cluster is registered as its own Windows service ("TCE-ERP-Database") running as
NETWORK SERVICE — PostgreSQL refuses to run with administrator rights, and a separate service means
Windows restarts it independently. Development (Linux/macOS): pg_ctl starts it as a child process.
"""
import logging
import os
import secrets
import subprocess
import tempfile
import time
from pathlib import Path

import psycopg
from psycopg import sql

from onprem import paths
from onprem.paths import IS_WINDOWS, exe

log = logging.getLogger("onprem.postgres")
SERVICE_NAME = "TCE-ERP-Database"
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _run(args: list[str], *, env: dict | None = None, timeout: int = 300, check: bool = True) -> subprocess.CompletedProcess:
    log.debug("run %s", args[0])
    r = subprocess.run(args, capture_output=True, text=True, timeout=timeout, env=env, creationflags=_NO_WINDOW)
    if check and r.returncode != 0:
        raise RuntimeError(f"{Path(args[0]).name} failed ({r.returncode}): {(r.stderr or r.stdout).strip()[-800:]}")
    return r


class EmbeddedPostgres:
    def __init__(self, port: int, superuser_password: str, bin_dir: Path | None = None, data_dir: Path | None = None):
        self.port = port
        self.password = superuser_password
        self.bin = bin_dir or paths.pg_bin_dir()
        self.data = data_dir or paths.pg_data_dir()
        self.log_file = paths.logs_dir() / "postgresql.log"

    def tool(self, name: str) -> str:
        p = self.bin / exe(name)
        if not p.exists():
            raise FileNotFoundError(f"PostgreSQL tool not found: {p}")
        return str(p)

    # ------------------------------------------------------------ cluster lifecycle
    def initialized(self) -> bool:
        return (self.data / "PG_VERSION").exists()

    def init_cluster(self) -> None:
        if self.initialized():
            return
        self.data.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".pw") as pw:
            pw.write(self.password)
        try:
            _run([self.tool("initdb"), "-D", str(self.data), "-U", "postgres", f"--pwfile={pw.name}",
                  "--auth=scram-sha-256", "-E", "UTF8", "--no-locale"])
        finally:
            os.remove(pw.name)
        with open(self.data / "postgresql.conf", "a", encoding="utf-8") as conf:
            conf.write(
                "\n# --- TCE ERP ---\n"
                "listen_addresses = 'localhost'\n"  # never reachable from the network; the ERP talks to it locally
                f"port = {self.port}\n"
                "max_connections = 60\n"
                "shared_buffers = 256MB\n"
                "timezone = 'UTC'\n"
                "log_timezone = 'Asia/Kolkata'\n"
                "logging_collector = on\n"
                "log_directory = 'log'\n"
                "log_rotation_age = 1d\n"
                "log_truncate_on_rotation = on\n"
                "log_filename = 'postgresql-%a.log'\n"
            )
        if IS_WINDOWS:
            _run(["icacls", str(self.data), "/grant", "*S-1-5-20:(OI)(CI)F", "/T", "/Q"])  # NETWORK SERVICE
            _run([self.tool("pg_ctl"), "register", "-N", SERVICE_NAME, "-U", "NT AUTHORITY\\NetworkService",
                  "-D", str(self.data), "-S", "auto", "-w"])

    def start(self, timeout: int = 60) -> None:
        if self.is_ready():
            return
        if IS_WINDOWS:
            if "1060" in _run(["sc", "query", SERVICE_NAME], check=False).stdout:  # service missing (e.g. reinstalled)
                _run([self.tool("pg_ctl"), "register", "-N", SERVICE_NAME, "-U", "NT AUTHORITY\\NetworkService",
                      "-D", str(self.data), "-S", "auto", "-w"])
            _run(["sc", "start", SERVICE_NAME], check=False)
        else:
            _run([self.tool("pg_ctl"), "-D", str(self.data), "-l", str(self.log_file), "-w", "-t", str(timeout),
                  "-o", f"-p {self.port} -k {tempfile.gettempdir()}", "start"])
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self.is_ready():
                return
            time.sleep(1)
        raise RuntimeError("PostgreSQL did not become ready in time. See logs\\postgresql.log and pgdata\\log.")

    def stop(self) -> None:
        if IS_WINDOWS:
            return  # the database service keeps running; Windows stops it at shutdown
        if self.initialized():
            _run([self.tool("pg_ctl"), "-D", str(self.data), "-m", "fast", "-w", "stop"], check=False)

    def is_ready(self) -> bool:
        try:
            with psycopg.connect(self.dsn("postgres"), connect_timeout=2):
                return True
        except psycopg.Error:
            return False

    def dsn(self, db: str = "postgres", user: str = "postgres", password: str | None = None) -> str:
        return f"host=127.0.0.1 port={self.port} dbname={db} user={user} password={password or self.password}"

    # ------------------------------------------------------------ ERP database
    def create_erp_database(self, owner_password: str, app_password: str) -> None:
        """Owner role for migrations, least-privilege role for the application (same model as the cloud)."""
        with psycopg.connect(self.dsn("postgres"), autocommit=True) as c:
            for role, pw in (("erp_owner", owner_password), ("erp_app", app_password)):
                exists = c.execute("select 1 from pg_roles where rolname = %s", (role,)).fetchone()
                verb = "ALTER" if exists else "CREATE"
                c.execute(sql.SQL(verb + " ROLE {} LOGIN PASSWORD {}").format(sql.Identifier(role), sql.Literal(pw)))
            if not c.execute("select 1 from pg_database where datname = 'tesla_erp'").fetchone():
                c.execute("CREATE DATABASE tesla_erp OWNER erp_owner ENCODING 'UTF8'")
        with psycopg.connect(self.dsn("tesla_erp"), autocommit=True) as c:
            for ext in ("pgcrypto", "pg_trgm", "citext"):
                c.execute(f"CREATE EXTENSION IF NOT EXISTS {ext}")
            c.execute("GRANT CONNECT ON DATABASE tesla_erp TO erp_app")
            c.execute("REVOKE ALL ON DATABASE tesla_erp FROM PUBLIC")

    # ------------------------------------------------------------ backups
    def dump(self, target: Path) -> None:
        env = dict(os.environ, PGPASSWORD=self.password)
        tmp = target.with_name(target.name + ".part")
        _run([self.tool("pg_dump"), "-h", "127.0.0.1", "-p", str(self.port), "-U", "postgres", "-d", "tesla_erp",
              "--format=custom", "--compress=9", "-f", str(tmp)], env=env, timeout=3600)
        # Prove the file is a readable archive before calling the backup good.
        _run([self.tool("pg_restore"), "--list", str(tmp)], timeout=600)
        os.replace(tmp, target)


    def restore(self, source: Path) -> None:
        """Replace the ERP database with a backup. The ERP service must be stopped first."""
        env = dict(os.environ, PGPASSWORD=self.password)
        _run([self.tool("pg_restore"), "--list", str(source)], timeout=600)  # readable archive?
        with psycopg.connect(self.dsn("postgres"), autocommit=True) as c:
            c.execute("SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = 'tesla_erp' "
                      "AND pid <> pg_backend_pid()")
            c.execute("DROP DATABASE IF EXISTS tesla_erp")
            c.execute("CREATE DATABASE tesla_erp OWNER erp_owner ENCODING 'UTF8'")
        _run([self.tool("pg_restore"), "-h", "127.0.0.1", "-p", str(self.port), "-U", "postgres", "-d", "tesla_erp",
              "--exit-on-error", str(source)], env=env, timeout=7200)
        with psycopg.connect(self.dsn("tesla_erp"), autocommit=True) as c:
            c.execute("GRANT CONNECT ON DATABASE tesla_erp TO erp_app")
            c.execute("REVOKE ALL ON DATABASE tesla_erp FROM PUBLIC")


def new_password() -> str:
    return secrets.token_urlsafe(24)
