"""Protect secrets at rest in config.json.

Windows: DPAPI with the machine scope, so only processes on this server PC can decrypt them (a copied
config.json is useless elsewhere). Other OSes (development): base64 in a file readable only by the owner.
"""
import base64
import ctypes
import os

from onprem.paths import IS_WINDOWS

_PREFIX_DPAPI = "dpapi:"
_PREFIX_PLAIN = "plain:"

if IS_WINDOWS:
    from ctypes import wintypes

    class _Blob(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    _crypt32 = ctypes.windll.crypt32  # type: ignore[attr-defined]
    _kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
    _LOCAL_MACHINE = 0x4
    _UI_FORBIDDEN = 0x1

    def _blob(data: bytes) -> _Blob:
        buf = ctypes.create_string_buffer(data, len(data))
        return _Blob(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))

    def _dpapi(data: bytes, protect: bool) -> bytes:
        src, out = _blob(data), _Blob()
        fn = _crypt32.CryptProtectData if protect else _crypt32.CryptUnprotectData
        flags = _UI_FORBIDDEN | (_LOCAL_MACHINE if protect else 0)
        ok = fn(ctypes.byref(src), None, None, None, None, flags, ctypes.byref(out))
        if not ok:
            raise OSError(ctypes.GetLastError(), "DPAPI failed")
        try:
            return ctypes.string_at(out.pbData, out.cbData)
        finally:
            _kernel32.LocalFree(out.pbData)


def protect(value: str | None) -> str | None:
    if value is None or value == "":
        return None
    raw = value.encode("utf-8")
    if IS_WINDOWS:
        return _PREFIX_DPAPI + base64.b64encode(_dpapi(raw, True)).decode()
    return _PREFIX_PLAIN + base64.b64encode(raw).decode()


def unprotect(value: str | None) -> str | None:
    if not value:
        return None
    if value.startswith(_PREFIX_DPAPI):
        if not IS_WINDOWS:
            raise OSError("This configuration was protected on Windows and can only be read there.")
        return _dpapi(base64.b64decode(value[len(_PREFIX_DPAPI):]), False).decode("utf-8")
    if value.startswith(_PREFIX_PLAIN):
        return base64.b64decode(value[len(_PREFIX_PLAIN):]).decode("utf-8")
    raise ValueError("Unrecognised protected value")


def restrict_file(path: os.PathLike) -> None:
    """Owner-only permissions (POSIX). On Windows ProgramData ACLs + DPAPI already protect the file."""
    if not IS_WINDOWS:
        os.chmod(path, 0o600)
