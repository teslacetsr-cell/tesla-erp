"""Nightly database backups to the NAS, with rotation, and a status record the Settings page shows.

    <NAS>\\backups\\daily\\tce_erp_20260925_0100.dump      (kept: keep_daily)
    <NAS>\\backups\\weekly\\...  (Sunday's copy)             (kept: keep_weekly)
    <NAS>\\backups\\monthly\\... (1st of the month's copy)   (kept: keep_monthly)

Documents are already on the NAS; protect the NAS itself with RAID and, ideally, its own snapshot or
off-site copy (see docs/ONPREM.md).
"""
import hashlib
import json
import logging
import shutil
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from onprem import paths
from onprem.config import OnPremConfig
from onprem.postgres import EmbeddedPostgres

log = logging.getLogger("onprem.backup")
IST = ZoneInfo("Asia/Kolkata")


def update_status(section: str, data: dict) -> None:
    f = paths.status_file()
    try:
        current = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    except ValueError:
        current = {}
    current[section] = {**current.get(section, {}), **data}
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(current, indent=2), encoding="utf-8")
    tmp.replace(f)


def read_status() -> dict:
    f = paths.status_file()
    try:
        return json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    except ValueError:
        return {}


def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _prune(folder: Path, keep: int) -> None:
    dumps = sorted(folder.glob("tce_erp_*.dump"))
    for old in dumps[:-keep] if keep > 0 else []:
        old.unlink(missing_ok=True)
        Path(str(old) + ".sha256").unlink(missing_ok=True)


def run_backup(cfg: OnPremConfig, pg: EmbeddedPostgres, now: datetime | None = None) -> Path:
    now = now or datetime.now(IST)
    root = Path(cfg.backups_path)
    daily = root / "daily"
    daily.mkdir(parents=True, exist_ok=True)
    name = f"tce_erp_{now:%Y%m%d_%H%M}.dump"
    target = daily / name
    update_status("backup", {"running": True, "last_attempt": now.isoformat()})
    try:
        pg.dump(target)
        digest = _sha256(target)
        Path(str(target) + ".sha256").write_text(f"{digest}  {name}\n", encoding="utf-8")
        copies = []
        if now.weekday() == 6:
            copies.append(root / "weekly")
        if now.day == 1:
            copies.append(root / "monthly")
        for folder in copies:
            folder.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, folder / name)
            shutil.copy2(str(target) + ".sha256", str(folder / name) + ".sha256")
        _prune(daily, cfg.keep_daily)
        _prune(root / "weekly", cfg.keep_weekly)
        _prune(root / "monthly", cfg.keep_monthly)
        size = target.stat().st_size
        update_status("backup", {"running": False, "ok": True, "last_success": now.isoformat(), "file": str(target),
                                 "size_bytes": size, "sha256": digest, "error": None})
        log.info("backup written: %s (%d bytes)", target, size)
        return target
    except Exception as exc:
        update_status("backup", {"running": False, "ok": False, "error": f"{type(exc).__name__}: {exc}"[:500],
                                 "last_failure": now.isoformat()})
        log.exception("backup failed")
        raise


def due(cfg: OnPremConfig, now: datetime | None = None) -> bool:
    """A backup is due at the configured time each day, or immediately if none succeeded in the last 26 hours."""
    now = now or datetime.now(IST)
    last = read_status().get("backup", {}).get("last_success")
    last_dt = datetime.fromisoformat(last) if last else None
    if last_dt is None or (now - last_dt).total_seconds() > 26 * 3600:
        return True
    hh, mm = (int(x) for x in cfg.backup_time.split(":"))
    scheduled = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
    return now >= scheduled and last_dt < scheduled
