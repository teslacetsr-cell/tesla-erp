"""NAS / network share access.

A Windows service runs as the Local System account, which has no rights on a NAS. So at start-up the
server registers the NAS username/password for this process with `net use` (no drive letter, not
persistent). The folders are then used through their UNC path, e.g. \\\\NAS\\TCE-ERP\\documents.
"""
import logging
import subprocess
from pathlib import PureWindowsPath

from onprem.paths import IS_WINDOWS

log = logging.getLogger("onprem.nas")


def share_root(path: str) -> str | None:
    r"""\\NAS\TCE-ERP\sub\dir -> \\NAS\TCE-ERP (the part `net use` needs); None for local paths."""
    if not path.startswith("\\\\"):
        return None
    parts = PureWindowsPath(path).parts
    return parts[0].rstrip("\\") if parts else None


def connect(path: str, user: str | None, password: str | None) -> tuple[bool, str]:
    """Register credentials for the share. Returns (ok, message). No-op for local folders or no credentials."""
    root = share_root(path)
    if not IS_WINDOWS or root is None or not user:
        return True, "no credentials needed"
    cmd = ["net", "use", root, password or "", f"/user:{user}", "/persistent:no"]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=30,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"Could not run 'net use': {exc}"
    out = (r.stdout + r.stderr).strip()
    if r.returncode == 0:
        return True, "connected"
    # 1219: already connected with other credentials in this session — the existing connection is used.
    if "1219" in out:
        return True, "already connected"
    log.warning("net use %s failed: %s", root, out)
    hints = {"53": "The NAS name was not found. Check the name or use its IP address (\\\\192.168.x.x\\share).",
             "86": "Wrong NAS username or password.", "1326": "Wrong NAS username or password.",
             "67": "The share name was not found on the NAS.", "5": "Access denied on the NAS share."}
    for code, hint in hints.items():
        if f"System error {code} " in out or f"error {code}." in out:
            return False, hint
    return False, out or f"net use failed (exit {r.returncode})"


def probe(path: str) -> tuple[bool, str]:
    """Write, read back and delete a test file in the folder."""
    from app.platform.documents.storage import FilesystemStorage

    return FilesystemStorage(path).health()
