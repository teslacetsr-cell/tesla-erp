"""TCE ERP on-premise server package (Windows).

The Windows service runs `TCE-ERP-Server.exe run`, which:
  * on first start serves a setup wizard on http://localhost:<port>/setup (this PC only);
  * afterwards keeps the embedded PostgreSQL running, applies database migrations, serves the ERP
    (API + web UI) to the office network, runs background jobs, takes nightly backups to the NAS and
    keeps the optional Cloudflare Tunnel connected for remote access.

See docs/ONPREM.md.
"""
