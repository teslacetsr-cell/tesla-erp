"""Server configuration (config.json). Secrets are stored protected (see secretbox)."""
import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path, PureWindowsPath

from onprem import paths
from onprem.secretbox import protect, restrict_file, unprotect

SECRET_FIELDS = ("nas_password", "pg_superuser_password", "pg_owner_password", "pg_app_password",
                 "secret_key", "field_encryption_key", "tunnel_token")


@dataclass
class OnPremConfig:
    configured: bool = False
    company_name: str = "Tesla Consulting Engineers"
    port: int = 8080
    # NAS share root, e.g. \\NAS\TCE-ERP  -> documents in \documents, backups in \backups
    nas_path: str = ""
    nas_user: str | None = None
    nas_password: str | None = None
    pg_port: int = 5433
    pg_superuser_password: str | None = None
    pg_owner_password: str | None = None
    pg_app_password: str | None = None
    secret_key: str | None = None
    field_encryption_key: str | None = None
    tunnel_token: str | None = None
    public_url: str | None = None  # e.g. https://erp.teslace.in (remote access through the tunnel)
    backup_time: str = "01:00"  # local time, 24h
    keep_daily: int = 14
    keep_weekly: int = 8
    keep_monthly: int = 24
    extra: dict = field(default_factory=dict)

    # ------------------------------------------------------------ derived locations
    def _join(self, *parts: str) -> str:
        if self.nas_path.startswith("\\\\") or ":" in self.nas_path[:3]:
            return str(PureWindowsPath(self.nas_path, *parts))
        return str(Path(self.nas_path, *parts))

    @property
    def documents_path(self) -> str:
        return self._join("documents")

    @property
    def backups_path(self) -> str:
        return self._join("backups")

    def database_url(self, role: str = "app") -> str:
        user, pw = ("erp_app", self.pg_app_password) if role == "app" else ("erp_owner", self.pg_owner_password)
        return f"postgresql+psycopg://{user}:{pw}@127.0.0.1:{self.pg_port}/tesla_erp"

    def app_environment(self) -> dict[str, str]:
        """Environment for the ERP application process (read by app/core/config.py)."""
        return {
            "ENVIRONMENT": "production",
            "DEPLOYMENT": "onprem",
            "DATABASE_URL": self.database_url("app"),
            "MIGRATION_DATABASE_URL": self.database_url("owner"),
            "DB_APP_ROLE": "erp_app",
            "SECRET_KEY": self.secret_key or "",
            "FIELD_ENCRYPTION_KEY": self.field_encryption_key or "",
            "COOKIE_SECURE": "false",
            "STORAGE_BACKEND": "filesystem",
            "STORAGE_PATH": self.documents_path,
            "FRONTEND_DIR": str(paths.ui_dir()),
            "STATUS_FILE": str(paths.status_file()),
        }


def load() -> OnPremConfig:
    f = paths.config_file()
    if not f.exists():
        return OnPremConfig()
    raw = json.loads(f.read_text(encoding="utf-8"))
    for k in SECRET_FIELDS:
        raw[k] = unprotect(raw.get(k))
    known = {k: v for k, v in raw.items() if k in OnPremConfig.__dataclass_fields__}
    return OnPremConfig(**known)


def save(cfg: OnPremConfig) -> None:
    data = asdict(cfg)
    for k in SECRET_FIELDS:
        data[k] = protect(data.get(k))
    f = paths.config_file()
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    restrict_file(tmp)
    os.replace(tmp, f)
