"""Database migrations and first-time data, run with the ERP's environment already set.

    TCE-ERP-Server.exe provision   (called once by the setup wizard, in a child process)
Normal start-up calls migrate_and_seed() in-process before the web server starts.
"""
import os
import sys


def migrate_and_seed() -> None:
    from alembic import command
    from alembic.config import Config

    from app.core.db import SessionLocal
    from app.seed import seed_core
    from onprem import paths

    cfg = Config()
    cfg.set_main_option("script_location", str(paths.migrations_dir()))
    command.upgrade(cfg, "head")
    with SessionLocal() as s:
        seed_core(s)  # idempotent: new permission codes, numbering formats, first admin if none
        s.commit()


def provision(admin_email: str, admin_password: str, company_name: str) -> None:
    from sqlalchemy import select

    from app.auth.service import set_password
    from app.company.models import Company
    from app.core.db import SessionLocal
    from app.platform.audit import service as audit
    from app.users.models import User

    migrate_and_seed()
    with SessionLocal() as s:
        admin = s.scalar(select(User).where(User.username == "admin"))
        admin.email = admin_email
        set_password(admin, admin_password, must_change=False)  # enforces the password policy
        company = s.scalar(select(Company).where(Company.is_default.is_(True)))
        company.company_name = company.legal_name = company_name
        audit.record(s, action="install", entity_type="system", entity_label="On-premise server",
                     summary="Server set up with the installation wizard", user_id=admin.id)
        s.commit()


if __name__ == "__main__":  # pragma: no cover - exercised through server.py
    provision(os.environ["TCE_SETUP_ADMIN_EMAIL"], os.environ["TCE_SETUP_ADMIN_PASSWORD"],
              os.environ.get("TCE_SETUP_COMPANY", "Tesla Consulting Engineers"))
    sys.exit(0)
