"""First-run setup wizard, served only to this PC (http://localhost:<port>/setup).

It asks for the company name, the NAS folder and credentials, the administrator's email and password,
and (optionally) the Cloudflare Tunnel token; then creates the database, runs migrations, takes a first
backup to prove the NAS works, and hands over to the normal server.
"""
import base64
import logging
import os
import secrets
import socket
import subprocess
import threading
from dataclasses import dataclass, field

from cryptography.fernet import Fernet
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from pydantic import BaseModel, Field

from onprem import backup, nas, paths
from onprem.config import OnPremConfig, save
from onprem.postgres import EmbeddedPostgres, new_password

log = logging.getLogger("onprem.setup")

STEPS = [
    ("nas", "Connecting to the NAS folder"),
    ("db_init", "Creating the database (first time takes a minute)"),
    ("db_start", "Starting the database"),
    ("db_create", "Creating the ERP database and accounts"),
    ("migrate", "Building tables and loading starting data"),
    ("backup", "Taking a first backup to the NAS"),
    ("done", "Finishing"),
]


@dataclass
class Progress:
    running: bool = False
    step: str | None = None
    done: list[str] = field(default_factory=list)
    error: str | None = None
    finished: bool = False
    recovery_key: str | None = None
    urls: list[str] = field(default_factory=list)


class NasIn(BaseModel):
    nas_path: str = Field(min_length=3, max_length=260)
    nas_user: str | None = Field(default=None, max_length=120)
    nas_password: str | None = Field(default=None, max_length=200)


class SetupIn(NasIn):
    company_name: str = Field(min_length=2, max_length=200)
    admin_email: str = Field(min_length=5, max_length=150, pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    admin_password: str = Field(min_length=10, max_length=128)
    tunnel_token: str | None = Field(default=None, max_length=4000)
    public_url: str | None = Field(default=None, max_length=200)


def office_urls(port: int) -> list[str]:
    host = socket.gethostname()
    urls = [f"http://{host.lower()}:{port}"]
    try:
        ip = socket.gethostbyname(host)
        if not ip.startswith("127."):
            urls.append(f"http://{ip}:{port}")
    except OSError:
        pass
    return urls


def create_setup_app(cfg: OnPremConfig, on_finished) -> FastAPI:
    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
    progress = Progress()

    @app.get("/")
    def root():
        return RedirectResponse("/setup")

    @app.get("/setup", response_class=HTMLResponse)
    def page():
        return HTMLResponse(_page(cfg), headers={"Cache-Control": "no-store", "X-Frame-Options": "DENY"})

    @app.post("/setup/api/check-nas")
    def check_nas(body: NasIn):
        ok, msg = nas.connect(body.nas_path, body.nas_user or None, body.nas_password or None)
        if not ok:
            return {"ok": False, "message": msg}
        probe_cfg = OnPremConfig(nas_path=body.nas_path.rstrip("\\/"))
        for folder in (probe_cfg.documents_path, probe_cfg.backups_path):
            ok, msg = nas.probe(folder)
            if not ok:
                return {"ok": False, "message": f"Cannot write to {folder}: {msg}"}
        return {"ok": True, "message": "The NAS folder is reachable and writable."}

    @app.get("/setup/api/progress")
    def get_progress():
        return progress.__dict__ | {"steps": STEPS}

    @app.post("/setup/api/complete")
    def complete(body: SetupIn):
        if progress.running or progress.finished:
            return JSONResponse(status_code=409, content={"error": "Setup is already running."})
        weak = _password_problem(body.admin_password)
        if weak:
            return JSONResponse(status_code=422, content={"error": weak})
        progress.running, progress.error, progress.done = True, None, []
        threading.Thread(target=_provision, args=(cfg, body, progress, on_finished), daemon=True).start()
        return {"ok": True}

    return app


def _password_problem(pw: str) -> str | None:
    if len(pw) < 10:
        return "The administrator password must be at least 10 characters."
    if len(set(pw)) < 5:
        return "The administrator password is too repetitive."
    if pw.lower() in {"password123", "admin12345", "tesla12345", "welcome123", "changeme123"}:
        return "That administrator password is too common."
    return None


def _provision(cfg: OnPremConfig, body: SetupIn, progress: Progress, on_finished) -> None:
    def step(key: str):
        if progress.step:
            progress.done.append(progress.step)
        progress.step = key

    try:
        step("nas")
        cfg.company_name = body.company_name.strip()
        cfg.nas_path = body.nas_path.strip().rstrip("\\/")
        cfg.nas_user, cfg.nas_password = (body.nas_user or None), (body.nas_password or None)
        ok, msg = nas.connect(cfg.nas_path, cfg.nas_user, cfg.nas_password)
        if not ok:
            raise RuntimeError(msg)
        for folder in (cfg.documents_path, cfg.backups_path):
            ok, msg = nas.probe(folder)
            if not ok:
                raise RuntimeError(f"Cannot write to {folder}: {msg}")
        cfg.tunnel_token = (body.tunnel_token or "").strip() or None
        cfg.public_url = (body.public_url or "").strip().rstrip("/") or None

        # Secrets are generated once and kept (protected) in config.json — never shown except the recovery key.
        cfg.pg_superuser_password = cfg.pg_superuser_password or new_password()
        cfg.pg_owner_password = cfg.pg_owner_password or new_password()
        cfg.pg_app_password = cfg.pg_app_password or new_password()
        cfg.secret_key = cfg.secret_key or secrets.token_urlsafe(48)
        cfg.field_encryption_key = cfg.field_encryption_key or Fernet.generate_key().decode()
        save(cfg)  # saved before the database exists, so a retry reuses the same passwords

        pg = EmbeddedPostgres(cfg.pg_port, cfg.pg_superuser_password)
        step("db_init")
        pg.init_cluster()
        step("db_start")
        pg.start()
        step("db_create")
        pg.create_erp_database(cfg.pg_owner_password, cfg.pg_app_password)

        step("migrate")
        env = dict(os.environ, **cfg.app_environment(), TCE_SETUP_ADMIN_EMAIL=body.admin_email,
                   TCE_SETUP_ADMIN_PASSWORD=body.admin_password, TCE_SETUP_COMPANY=cfg.company_name,
                   SEED_ADMIN_EMAIL=body.admin_email, SEED_ADMIN_PASSWORD=body.admin_password)
        env.pop("FRONTEND_DIR", None)
        r = subprocess.run(paths.self_command("provision"), env=env, capture_output=True, text=True, timeout=900,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if r.returncode != 0:
            detail = (r.stderr or r.stdout).strip().splitlines()
            raise RuntimeError("Database setup failed: " + (detail[-1] if detail else f"exit {r.returncode}"))

        step("backup")
        backup.run_backup(cfg, pg)

        step("done")
        cfg.configured = True
        save(cfg)
        progress.done.append("done")
        progress.step = None
        progress.recovery_key = cfg.field_encryption_key
        progress.urls = office_urls(cfg.port) + ([cfg.public_url] if cfg.public_url else [])
        progress.finished = True
        log.info("setup complete")
        threading.Timer(20.0, on_finished).start()  # give the page time to show the recovery key
    except Exception as exc:  # noqa: BLE001 - shown to the person doing the setup
        log.exception("setup failed")
        progress.error = str(exc)[:600]
    finally:
        progress.running = False


def _logo_data_uri() -> str:
    p = paths.bundle_dir() / "app" / "assets" / "tce-logo.png"
    return "data:image/png;base64," + base64.b64encode(p.read_bytes()).decode() if p.exists() else ""


def _page(cfg: OnPremConfig) -> str:
    return _HTML.replace("{{LOGO}}", _logo_data_uri()).replace("{{PORT}}", str(cfg.port)).replace(
        "{{COMPANY}}", cfg.company_name)


_HTML = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TCE ERP — Server setup</title>
<style>
:root{--red:#d90000;--red-dark:#b30000;--ink:#18181b;--muted:#6b6b75;--line:#dcdce0;--bg:#f7f7f8}
*{box-sizing:border-box}body{margin:0;font-family:"Segoe UI",system-ui,sans-serif;color:var(--ink);background:var(--bg)}
header{background:var(--red);color:#fff;padding:18px 28px;display:flex;gap:14px;align-items:center}
header img{width:44px;height:44px;border-radius:50%;background:#fff}
header h1{font-size:18px;margin:0}header p{margin:2px 0 0;font-size:13px;opacity:.85}
main{max-width:760px;margin:24px auto;padding:0 16px 40px}
section{background:#fff;border:1px solid var(--line);border-radius:10px;padding:20px 22px;margin-bottom:16px}
h2{font-size:15px;margin:0 0 4px}h2 span{color:var(--red);margin-right:6px}.help{color:var(--muted);font-size:13px;margin:0 0 14px}
label{display:block;font-size:13px;font-weight:600;margin:12px 0 4px}
input{width:100%;height:38px;border:1px solid var(--line);border-radius:6px;padding:0 10px;font-size:14px}
input:focus{outline:2px solid #ffc5c5;border-color:var(--red)}
.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
button{background:var(--red);color:#fff;border:0;border-radius:6px;height:40px;padding:0 18px;font-size:14px;font-weight:600;cursor:pointer}
button.secondary{background:#fff;color:var(--ink);border:1px solid var(--line)}button:disabled{opacity:.5;cursor:default}
.msg{font-size:13px;margin-top:8px}.ok{color:#047857}.bad{color:var(--red-dark)}
ol.steps{list-style:none;padding:0;margin:0}ol.steps li{padding:6px 0;font-size:14px;color:var(--muted)}
ol.steps li.done{color:#047857}ol.steps li.done:before{content:"✓  "}ol.steps li.now{color:var(--ink);font-weight:600}
ol.steps li.now:before{content:"…  "}ol.steps li.todo:before{content:"○  "}
.key{font-family:Consolas,monospace;font-size:15px;background:#fff1f1;border:1px dashed var(--red);padding:12px;border-radius:6px;word-break:break-all}
code{background:var(--bg);padding:1px 5px;border-radius:4px}
@media print{header,button,.noprint{display:none}}
</style></head><body>
<header><img src="{{LOGO}}" alt=""><div><h1>TCE ERP — Server setup</h1><p>This page is only available on this computer.</p></div></header>
<main>
<form id="f" autocomplete="off">
<section><h2><span>1</span>Company</h2><p class="help">Printed on quotations, POs and invoices. You can add the full profile later in the ERP.</p>
<label>Company name</label><input name="company_name" value="{{COMPANY}}" required></section>

<section><h2><span>2</span>Documents &amp; backups on the NAS</h2>
<p class="help">A shared folder on your NAS. The ERP creates <code>documents</code> and <code>backups</code> inside it.
Example: <code>\\NAS\TCE-ERP</code> or <code>\\192.168.1.20\TCE-ERP</code>. Use a NAS account that can read and write this share.</p>
<label>NAS folder</label><input name="nas_path" placeholder="\\NAS\TCE-ERP" required>
<div class="row"><div><label>NAS username</label><input name="nas_user" placeholder="erp-service"></div>
<div><label>NAS password</label><input name="nas_password" type="password"></div></div>
<p style="margin-top:12px"><button type="button" class="secondary" id="test">Test NAS connection</button></p><div id="nasmsg" class="msg"></div></section>

<section><h2><span>3</span>Administrator</h2><p class="help">The first user. Sign in as <code>admin</code> with this password, then create everyone else in the ERP.</p>
<label>Administrator email</label><input name="admin_email" type="email" required>
<div class="row"><div><label>Password (10+ characters)</label><input name="admin_password" type="password" minlength="10" required></div>
<div><label>Confirm password</label><input name="admin_password2" type="password" minlength="10" required></div></div></section>

<section><h2><span>4</span>Remote access for site engineers <span style="color:var(--muted);font-weight:400">(optional — can be added later)</span></h2>
<p class="help">Paste the token of a Cloudflare Tunnel whose public hostname points to <code>http://localhost:{{PORT}}</code>. See the guide: docs/ONPREM.md → “Remote access”.</p>
<label>Cloudflare Tunnel token</label><input name="tunnel_token" placeholder="eyJhIjoi…">
<label>Public address</label><input name="public_url" placeholder="https://erp.yourcompany.in"></section>

<div id="err" class="msg bad"></div>
<p><button id="go" type="submit">Set up the server</button></p>
</form>

<section id="prog" hidden><h2>Setting up…</h2><ol class="steps" id="steps"></ol><div id="perr" class="msg bad"></div>
<p class="noprint" id="retry" hidden><button onclick="location.reload()">Back to the form</button></p></section>

<section id="doneBox" hidden><h2 style="color:#047857">✓ The server is ready</h2>
<p>Everyone in the office can now open the ERP at:</p><ul id="urls"></ul>
<p>Sign in as <b>admin</b> with the password you just chose. Install the <b>TCE ERP</b> desktop app on other PCs and enter the first address above.</p>
<h2 style="margin-top:18px">Recovery key — print it and keep it safe</h2>
<p class="help">Bank account numbers are encrypted with this key. If this PC is ever lost, the backups on the NAS can only be fully restored with it. Store it in a safe or a password manager, not on the NAS.</p>
<div class="key" id="key"></div>
<p class="noprint"><button onclick="window.print()">Print</button></p>
<p class="help">The ERP starts automatically in a few seconds.</p></section>
</main>
<script>
const f=document.getElementById('f');const val=n=>f.elements[n].value.trim();
document.getElementById('test').onclick=async()=>{const m=document.getElementById('nasmsg');m.className='msg';m.textContent='Testing…';
 const r=await fetch('/setup/api/check-nas',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nas_path:val('nas_path'),nas_user:val('nas_user')||null,nas_password:f.elements.nas_password.value||null})});
 const d=await r.json();m.className='msg '+(d.ok?'ok':'bad');m.textContent=d.ok?'✓ '+d.message:(d.message||(d.detail&&d.detail[0].msg)||'Failed');};
f.onsubmit=async e=>{e.preventDefault();const err=document.getElementById('err');err.textContent='';
 if(f.elements.admin_password.value!==f.elements.admin_password2.value){err.textContent='The administrator passwords do not match.';return}
 const body={company_name:val('company_name'),nas_path:val('nas_path'),nas_user:val('nas_user')||null,nas_password:f.elements.nas_password.value||null,
  admin_email:val('admin_email'),admin_password:f.elements.admin_password.value,tunnel_token:val('tunnel_token')||null,public_url:val('public_url')||null};
 const r=await fetch('/setup/api/complete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
 if(!r.ok){const d=await r.json();err.textContent=d.error||(d.detail&&d.detail.map(x=>x.loc.slice(-1)[0]+': '+x.msg).join('; '))||'Please check the form.';return}
 f.hidden=true;document.getElementById('prog').hidden=false;poll();};
async function poll(){const d=await (await fetch('/setup/api/progress')).json();
 document.getElementById('steps').innerHTML=d.steps.map(([k,l])=>`<li class="${d.done.includes(k)?'done':d.step===k?'now':'todo'}">${l}</li>`).join('');
 if(d.error){document.getElementById('perr').textContent=d.error;document.getElementById('retry').hidden=false;return}
 if(d.finished){document.getElementById('prog').hidden=true;document.getElementById('doneBox').hidden=false;
  document.getElementById('key').textContent=d.recovery_key;document.getElementById('urls').innerHTML=d.urls.map(u=>`<li><b>${u}</b></li>`).join('');
  setTimeout(()=>{location.href='/login/'},25000);return}
 setTimeout(poll,1000);}
</script></body></html>"""
