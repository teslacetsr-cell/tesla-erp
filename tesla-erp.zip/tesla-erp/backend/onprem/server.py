"""TCE ERP server — entry point of TCE-ERP-Server.exe.

    TCE-ERP-Server.exe run                      the Windows service runs this
    TCE-ERP-Server.exe status                   show health, last backup, addresses
    TCE-ERP-Server.exe backup-now               take a database backup to the NAS immediately
    TCE-ERP-Server.exe configure --tunnel-token <token> [--public-url https://erp.x.in]
                                 [--nas-path \\\\NAS\\TCE-ERP --nas-user u --nas-password p] [--port 8080]
    TCE-ERP-Server.exe reset-admin-password     set a temporary password for 'admin' (locked-out recovery)
    TCE-ERP-Server.exe restore <file.dump> [--recovery-key <key>]
                                                replace the database with a backup (stop the service first)
    TCE-ERP-Server.exe provision                internal: used by the setup wizard
"""
import argparse
import logging
import os
import secrets
import signal
import subprocess
import sys
import threading
import time
from datetime import datetime
from logging.handlers import RotatingFileHandler
from zoneinfo import ZoneInfo

from onprem import backup, nas, paths
from onprem.config import OnPremConfig, load, save
from onprem.postgres import EmbeddedPostgres

log = logging.getLogger("onprem")
IST = ZoneInfo("Asia/Kolkata")
VERSION = "0.2.0"


def setup_logging() -> None:
    root = logging.getLogger()
    if root.handlers:
        return
    root.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    fh = RotatingFileHandler(paths.logs_dir() / "server.log", maxBytes=5_000_000, backupCount=10, encoding="utf-8")
    fh.setFormatter(fmt)
    root.addHandler(fh)
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    root.addHandler(sh)


# ------------------------------------------------------------------ background helpers
class Tunnel(threading.Thread):
    """Keeps cloudflared connected (remote access). Restarts it with back-off if it stops."""

    def __init__(self, token: str, stop: threading.Event):
        super().__init__(daemon=True, name="tunnel")
        self.token, self.stop_event, self.proc = token, stop, None

    def run(self) -> None:
        exe = paths.cloudflared_path()
        if not exe.exists():
            backup.update_status("tunnel", {"state": "error", "detail": f"{exe.name} not found"})
            return
        delay = 10
        while not self.stop_event.is_set():
            with open(paths.logs_dir() / "cloudflared.log", "ab") as out:
                self.proc = subprocess.Popen([str(exe), "tunnel", "--no-autoupdate", "run", "--token", self.token],
                                             stdout=out, stderr=out,
                                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                backup.update_status("tunnel", {"state": "running", "since": datetime.now(IST).isoformat(),
                                                "detail": None})
                while self.proc.poll() is None and not self.stop_event.is_set():
                    time.sleep(2)
            if self.stop_event.is_set():
                break
            backup.update_status("tunnel", {"state": "reconnecting", "detail": f"exited with {self.proc.returncode}"})
            log.warning("cloudflared exited (%s); retrying in %ss", self.proc.returncode, delay)
            self.stop_event.wait(delay)
            delay = min(delay * 2, 300)

    def terminate(self) -> None:
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()


def worker_loop(stop: threading.Event) -> None:
    from app.core.db import SessionLocal
    from app.platform.jobs.service import run_pending

    while not stop.is_set():
        try:
            n = run_pending(SessionLocal, limit=20)
        except Exception:  # noqa: BLE001
            log.exception("job worker error")
            n = 0
        if n == 0:
            stop.wait(2)


def backup_loop(cfg: OnPremConfig, pg: EmbeddedPostgres, stop: threading.Event) -> None:
    stop.wait(300)  # let the office start working first
    while not stop.is_set():
        try:
            if backup.due(cfg):
                nas.connect(cfg.nas_path, cfg.nas_user, cfg.nas_password)
                backup.run_backup(cfg, pg)
        except Exception:  # noqa: BLE001 - recorded in status.json; retried in an hour
            log.exception("scheduled backup failed")
            stop.wait(3600)
            continue
        stop.wait(60)


# ------------------------------------------------------------------ run
def prepare_app(cfg: OnPremConfig) -> EmbeddedPostgres:
    """Environment, NAS, database, migrations — everything needed before `app` is imported."""
    os.environ.update(cfg.app_environment())
    if not (paths.ui_dir() / "index.html").exists():
        log.warning("Web UI not found at %s — serving the API only", paths.ui_dir())
        os.environ.pop("FRONTEND_DIR", None)
    ok, msg = nas.connect(cfg.nas_path, cfg.nas_user, cfg.nas_password)
    if ok:
        ok, msg = nas.probe(cfg.documents_path)
    backup.update_status("storage", {"ok": ok, "detail": msg, "checked": datetime.now(IST).isoformat()})
    if not ok:
        log.error("NAS not available (%s). The ERP will run, but document uploads will fail until it is back.", msg)
    pg = EmbeddedPostgres(cfg.pg_port, cfg.pg_superuser_password)
    pg.start()
    from onprem.provision import migrate_and_seed

    migrate_and_seed()
    return pg


def run_server(cfg: OnPremConfig) -> None:
    import uvicorn

    pg = prepare_app(cfg)
    from app.main import app  # imported only now: settings come from the environment set above

    stop = threading.Event()
    threads: list[threading.Thread] = [
        threading.Thread(target=worker_loop, args=(stop,), daemon=True, name="worker"),
        threading.Thread(target=backup_loop, args=(cfg, pg, stop), daemon=True, name="backup"),
    ]
    tunnel = Tunnel(cfg.tunnel_token, stop) if cfg.tunnel_token else None
    if tunnel:
        threads.append(tunnel)
    else:
        backup.update_status("tunnel", {"state": "not configured", "detail": None})
    for t in threads:
        t.start()
    from onprem.setup_app import office_urls

    backup.update_status("server", {"version": VERSION, "started": datetime.now(IST).isoformat(),
                                    "port": cfg.port, "urls": office_urls(cfg.port), "public_url": cfg.public_url})
    log.info("TCE ERP %s serving on port %s", VERSION, cfg.port)
    server = uvicorn.Server(uvicorn.Config(app, host="0.0.0.0", port=cfg.port, proxy_headers=True,  # noqa: S104
                                           forwarded_allow_ips="127.0.0.1", log_config=None, access_log=False))
    try:
        server.run()
    finally:
        log.info("stopping")
        stop.set()
        if tunnel:
            tunnel.terminate()
        pg.stop()


def run_setup(cfg: OnPremConfig) -> bool:
    """Serve the setup wizard on localhost until setup completes. Returns True when configured."""
    import uvicorn

    from onprem.setup_app import create_setup_app

    holder: dict = {}

    def finished():
        holder["server"].should_exit = True

    app = create_setup_app(cfg, finished)
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=cfg.port, log_config=None, access_log=False))
    holder["server"] = server
    log.info("Not configured yet — open http://localhost:%s/setup on this PC", cfg.port)
    server.run()
    return load().configured


def cmd_run() -> int:
    cfg = load()
    if not cfg.configured:
        if not run_setup(cfg):
            return 1
        cfg = load()
    run_server(cfg)
    return 0


def cmd_status() -> int:
    cfg = load()
    st = backup.read_status()
    print(f"TCE ERP server {VERSION}")
    setup_url = f"http://localhost:{cfg.port}/setup"
    print(f"  Configured:  {'yes' if cfg.configured else 'no — open ' + setup_url}")
    print(f"  Data folder: {paths.home()}")
    print(f"  NAS:         {cfg.nas_path or '-'}")
    for section in ("server", "storage", "backup", "tunnel"):
        print(f"  {section.capitalize():<12} {st.get(section, '-')}")
    return 0


def cmd_backup_now() -> int:
    cfg = load()
    if not cfg.configured:
        print("Not configured yet.")
        return 1
    nas.connect(cfg.nas_path, cfg.nas_user, cfg.nas_password)
    pg = EmbeddedPostgres(cfg.pg_port, cfg.pg_superuser_password)
    pg.start()
    print(f"Backup written: {backup.run_backup(cfg, pg)}")
    return 0


def cmd_configure(a: argparse.Namespace) -> int:
    cfg = load()
    if a.tunnel_token is not None:
        cfg.tunnel_token = a.tunnel_token.strip() or None
    if a.public_url is not None:
        cfg.public_url = a.public_url.strip().rstrip("/") or None
    if a.nas_path:
        ok, msg = nas.connect(a.nas_path, a.nas_user or cfg.nas_user, a.nas_password or cfg.nas_password)
        test = OnPremConfig(nas_path=a.nas_path.rstrip("\\/"))
        if ok:
            ok, msg = nas.probe(test.documents_path)
        if not ok:
            print(f"NAS check failed: {msg}")
            return 1
        cfg.nas_path = a.nas_path.rstrip("\\/")
    if a.nas_user is not None:
        cfg.nas_user = a.nas_user or None
    if a.nas_password is not None:
        cfg.nas_password = a.nas_password or None
    if a.port:
        cfg.port = a.port
    save(cfg)
    print("Saved. Restart the service to apply:  net stop TCE-ERP  &&  net start TCE-ERP")
    return 0


def cmd_reset_admin() -> int:
    cfg = load()
    prepare_app(cfg)
    from sqlalchemy import select

    from app.auth.service import revoke_all_sessions, set_password
    from app.core.db import SessionLocal
    from app.platform.audit import service as audit
    from app.users.models import User

    temp = "Tce-" + secrets.token_urlsafe(9)
    with SessionLocal() as s:
        admin = s.scalar(select(User).where(User.username == "admin"))
        set_password(admin, temp, must_change=True)
        admin.is_active, admin.failed_login_count, admin.locked_until = True, 0, None
        revoke_all_sessions(s, admin, "server_console_reset")
        audit.record(s, action="password_reset", entity_type="user", entity_id=admin.id, entity_label="admin",
                     summary="Reset from the server console")
        s.commit()
    print(f"Temporary password for 'admin': {temp}\nSign in and choose a new password.")
    return 0


def cmd_restore(a: argparse.Namespace) -> int:
    from pathlib import Path

    cfg = load()
    if not cfg.configured:
        print("Complete the server setup first (it creates the database accounts), then restore.")
        return 1
    src = Path(a.file)
    sha = Path(str(src) + ".sha256")
    if sha.exists():
        expected = sha.read_text(encoding="utf-8").split()[0]
        if backup._sha256(src) != expected:
            print("The backup file does not match its .sha256 checksum — it may be damaged. Nothing was changed.")
            return 1
    answer = input(f"This REPLACES all ERP data with the backup {src.name}. Type RESTORE to continue: ") if not a.yes else "RESTORE"
    if answer.strip() != "RESTORE":
        print("Cancelled.")
        return 1
    nas.connect(cfg.nas_path, cfg.nas_user, cfg.nas_password)
    pg = EmbeddedPostgres(cfg.pg_port, cfg.pg_superuser_password)
    pg.start()
    safety = paths.home() / f"before-restore-{datetime.now(IST):%Y%m%d_%H%M}.dump"
    pg.dump(safety)
    print(f"Current data saved first to {safety}")
    pg.restore(src)
    if a.recovery_key:
        cfg.field_encryption_key = a.recovery_key.strip()
        save(cfg)
        print("Recovery key saved.")
    prepare_app(cfg)  # bring the schema up to this version's migrations
    print("Restore complete. Start the service:  net start TCE-ERP")
    return 0


def main(argv: list[str] | None = None) -> int:
    setup_logging()
    p = argparse.ArgumentParser(prog="TCE-ERP-Server", description="TCE ERP on-premise server")
    sub = p.add_subparsers(dest="cmd")
    sub.add_parser("run")
    sub.add_parser("status")
    sub.add_parser("backup-now")
    sub.add_parser("reset-admin-password")
    sub.add_parser("provision")
    r = sub.add_parser("restore")
    r.add_argument("file")
    r.add_argument("--recovery-key", help="the key printed at setup (needed when restoring onto a new PC)")
    r.add_argument("--yes", action="store_true", help="do not ask for confirmation")
    c = sub.add_parser("configure")
    c.add_argument("--tunnel-token")
    c.add_argument("--public-url")
    c.add_argument("--nas-path")
    c.add_argument("--nas-user")
    c.add_argument("--nas-password")
    c.add_argument("--port", type=int)
    a = p.parse_args(argv)
    if a.cmd in (None, "run"):
        signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt))
        return cmd_run()
    if a.cmd == "status":
        return cmd_status()
    if a.cmd == "backup-now":
        return cmd_backup_now()
    if a.cmd == "configure":
        return cmd_configure(a)
    if a.cmd == "restore":
        return cmd_restore(a)
    if a.cmd == "reset-admin-password":
        return cmd_reset_admin()
    if a.cmd == "provision":
        from onprem.provision import provision

        provision(os.environ["TCE_SETUP_ADMIN_EMAIL"], os.environ["TCE_SETUP_ADMIN_PASSWORD"],
                  os.environ.get("TCE_SETUP_COMPANY", "Tesla Consulting Engineers"))
        return 0
    return 2


if __name__ == "__main__":
    sys.exit(main())
