"""Where things live on the server PC.

Windows (installed):
    program files   C:\\Program Files\\TCE ERP\\server\\        TCE-ERP-Server.exe, pgsql\\, cloudflared.exe, ui\\
    data            C:\\ProgramData\\TCE-ERP\\                   config.json, pgdata\\, logs\\, status.json
Development (any OS): TCE_HOME (data) and TCE_BIN (binaries) environment variables.

The database always lives on the server's own disk — never on a network share, which PostgreSQL cannot use safely.
Documents and backups go to the NAS.
"""
import os
import sys
from pathlib import Path

IS_WINDOWS = os.name == "nt"
FROZEN = getattr(sys, "frozen", False)


def install_dir() -> Path:
    if os.environ.get("TCE_BIN"):
        return Path(os.environ["TCE_BIN"])
    if FROZEN:
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]  # backend/


def bundle_dir() -> Path:
    """Read-only files packed into the executable (migrations, templates)."""
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))


def home() -> Path:
    if os.environ.get("TCE_HOME"):
        p = Path(os.environ["TCE_HOME"])
    elif IS_WINDOWS:
        p = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / "TCE-ERP"
    else:
        p = Path.home() / ".tce-erp"
    p.mkdir(parents=True, exist_ok=True)
    return p


def config_file() -> Path:
    return home() / "config.json"


def status_file() -> Path:
    return home() / "status.json"


def logs_dir() -> Path:
    d = home() / "logs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def pg_data_dir() -> Path:
    return home() / "pgdata"


def pg_bin_dir() -> Path:
    if os.environ.get("TCE_PG_BIN"):
        return Path(os.environ["TCE_PG_BIN"])
    return install_dir() / "pgsql" / "bin"


def exe(name: str) -> str:
    return name + ".exe" if IS_WINDOWS else name


def ui_dir() -> Path:
    if os.environ.get("TCE_UI"):
        return Path(os.environ["TCE_UI"])
    return install_dir() / "ui"


def cloudflared_path() -> Path:
    return install_dir() / exe("cloudflared")


def migrations_dir() -> Path:
    return bundle_dir() / "migrations"


def self_command(*args: str) -> list[str]:
    """How to run this program again (for the provisioning sub-process)."""
    if FROZEN:
        return [sys.executable, *args]
    return [sys.executable, "-m", "onprem.server", *args]
