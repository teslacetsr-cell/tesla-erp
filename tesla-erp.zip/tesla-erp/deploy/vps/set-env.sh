#!/usr/bin/env bash
# Add or change one setting in deploy/vps/.env on a server that is already running, then restart the ERP.
#     ./set-env.sh SMTP_HOST smtp.gmail.com
#     ./set-env.sh SMTP_PASSWORD            # secrets: leave the value out and type it when asked (not shown, not
#     ./set-env.sh ANTHROPIC_API_KEY        #   kept in the shell history)
# Afterwards run ./deploy.sh (or `docker compose up -d api worker`) so the ERP picks it up.
set -euo pipefail
cd "$(dirname "$0")"
[ -f .env ] || { echo "No .env here — run ./init-env.sh first."; exit 1; }
KEY="${1:-}"
case "$KEY" in
  SMTP_HOST|SMTP_PORT|SMTP_USER|SMTP_PASSWORD|SMTP_FROM|SMTP_TLS|ANTHROPIC_API_KEY) ;;
  *) echo "Usage: ./set-env.sh <SETTING> [value]"
     echo "Settings: SMTP_HOST SMTP_PORT SMTP_USER SMTP_PASSWORD SMTP_FROM SMTP_TLS ANTHROPIC_API_KEY"
     exit 1 ;;
esac
if [ $# -ge 2 ]; then
  VALUE="$2"
else
  read -r -s -p "Value for $KEY (not shown): " VALUE; echo
fi
case "$VALUE" in *$'\n'*|*\"*|*\$*|*\`*) echo "The value must be one line without \", \$ or \`."; exit 1 ;; esac
TMP=$(mktemp)
grep -v "^${KEY}=" .env > "$TMP" || true
printf '%s="%s"\n' "$KEY" "$VALUE" >> "$TMP"
cat "$TMP" > .env && rm -f "$TMP"
chmod 600 .env
echo "Saved $KEY in .env. Now run: docker compose up -d api worker   (about 30 seconds)"
