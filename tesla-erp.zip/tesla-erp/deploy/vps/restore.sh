#!/usr/bin/env bash
# Restore the database from a backup. Replaces ALL current ERP data.
#     ./restore.sh --list                                   backups available in R2
#     ./restore.sh daily/tce_erp_20260927_0130.dump         restore a backup from R2
#     ./restore.sh /var/backups/tce-erp/tce_erp_….dump      restore a local file
# On a NEW server: set up .env with the SAME values as the old one (from your password manager) before
# running deploy.sh, then restore. Documents are already in R2 and need no restore.
set -euo pipefail
cd "$(dirname "$0")"
set -a; . ./.env; set +a
DC="docker compose"
DIR="${BACKUP_DIR:-/var/backups/tce-erp}"

if [ "${1:-}" = "--list" ]; then
  $DC --profile ops run --rm -T ops python -m app.ops.offsite list; exit 0
fi
SRC="${1:?usage: ./restore.sh --list | <R2 key> | <local .dump file>}"

if [ -f "$SRC" ]; then
  FILE="$SRC"
  if [ -f "$SRC.sha256" ]; then (cd "$(dirname "$SRC")" && sha256sum -c "$(basename "$SRC").sha256") || exit 1; fi
else
  FILE="$DIR/restore-$(basename "$SRC")"
  echo "Downloading $SRC from R2 (checksum verified)…"
  $DC --profile ops run --rm -T ops python -m app.ops.offsite download "$SRC" "/backups/$(basename "$FILE")"
fi
$DC exec -T db pg_restore --list < "$FILE" > /dev/null || { echo "Not a readable backup: $FILE"; exit 1; }

echo
echo "This REPLACES ALL ERP DATA on $ERP_DOMAIN with: $(basename "$FILE")"
read -r -p "Type RESTORE to continue: " a
[ "$a" = RESTORE ] || { echo "Cancelled."; exit 1; }

echo "Saving the current data first…"
./backup.sh --local-only || echo "(no current data to save)"

echo "Stopping the ERP…"
$DC stop api worker
$DC exec -T db psql -U postgres -v ON_ERROR_STOP=1 -q <<'SQL'
SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = 'tesla_erp' AND pid <> pg_backend_pid();
DROP DATABASE IF EXISTS tesla_erp;
CREATE DATABASE tesla_erp OWNER erp_owner ENCODING 'UTF8';
SQL
echo "Restoring…"
$DC exec -T db pg_restore -U postgres -d tesla_erp --exit-on-error < "$FILE"
$DC exec -T db psql -U postgres -d tesla_erp -q -c "GRANT CONNECT ON DATABASE tesla_erp TO erp_app; REVOKE ALL ON DATABASE tesla_erp FROM PUBLIC;"
echo "Bringing the data up to this version…"
$DC run --rm migrate
$DC start api worker
echo "Restore complete — https://$ERP_DOMAIN"
