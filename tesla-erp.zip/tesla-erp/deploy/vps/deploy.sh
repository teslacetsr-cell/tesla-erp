#!/usr/bin/env bash
# Steps 4 & 7 — build and start (or update) the ERP. Run as the deploy user from deploy/vps/:
#     ./deploy.sh            first install, and every update after `git pull`
# Takes a backup before updating an existing installation, applies database migrations, then swaps the
# containers. Also installs the nightly backup schedule.
set -euo pipefail
cd "$(dirname "$0")"
[ -f .env ] || { echo "No .env — run ./init-env.sh first."; exit 1; }
[ "$(stat -c %a .env)" = 600 ] || chmod 600 .env
set -a; . ./.env; set +a
DC="docker compose"
# Containers always run the image tagged "latest"; each build is also tagged with the git commit for rollback:
#   APP_VERSION=<commit> docker compose up -d api worker
VERSION="$(git -C ../.. rev-parse --short HEAD 2>/dev/null || date +%Y%m%d%H%M)"
say() { printf '\n\033[1;31m==> %s\033[0m\n' "$*"; }

say "Checking that $ERP_DOMAIN points to this server"
MYIP=$(curl -fsS4 https://api.ipify.org || true)
DNSIP=$(getent ahostsv4 "$ERP_DOMAIN" | awk 'NR==1{print $1}' || true)
if [ -n "$MYIP" ] && [ "$MYIP" != "$DNSIP" ]; then
  echo "!! $ERP_DOMAIN resolves to '${DNSIP:-nothing}', but this server is $MYIP."
  echo "   Create the DNS A record (docs/DEPLOY_VPS.md step 7) or HTTPS certificates cannot be issued."
  read -r -p "   Continue anyway? [y/N] " a; [ "${a:-N}" = y ] || exit 1
fi

say "Building version $VERSION (the first build takes several minutes)"
$DC build migrate
docker tag tce-erp:latest "tce-erp:$VERSION"

if $DC ps --status running --services 2>/dev/null | grep -qx db; then
  say "Backing up the current database before updating"
  ./backup.sh --local-only
fi

say "Database"
$DC up -d db
say "Applying database migrations"
$DC run --rm migrate

say "Starting the ERP"
$DC up -d --remove-orphans api worker caddy

say "Waiting for the ERP to answer"
for i in $(seq 1 60); do
  if $DC exec -T api python -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:8000/readyz',timeout=3)" 2>/dev/null; then
    ok=1; break
  fi
  sleep 3
done
[ "${ok:-}" = 1 ] || { echo "!! The ERP did not start. Logs:"; $DC logs --tail 60 api; exit 1; }

say "Nightly backup at 01:30 (India time)"
CRON="30 1 * * * $(pwd)/backup.sh >> /var/log/tce-erp-backup.log 2>&1"
( crontab -l 2>/dev/null | grep -v 'tce-erp.*backup.sh\|deploy/vps/backup.sh' ; echo "$CRON" ) | crontab -

docker image prune -f >/dev/null
say "Done — https://$ERP_DOMAIN  (version $VERSION)"
echo "Check health any time with ./status.sh"
