#!/usr/bin/env bash
# Step 2 — prepare a fresh Ubuntu 22.04/24.04 VPS. Run ONCE, as root:
#     curl -fsSL https://raw.githubusercontent.com/<you>/tesla-erp/main/deploy/vps/setup-server.sh -o setup-server.sh
#     sudo bash setup-server.sh
# (or copy the file up with scp). Safe to run again.
#
# Does: updates + automatic security updates, Asia/Kolkata time zone, swap, Docker, firewall (22/80/443 only),
# fail2ban, a 'deploy' user for running the ERP, SSH hardening (only if key login for 'deploy' works).
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Run as root: sudo bash $0"; exit 1; }
DEPLOY_USER="${DEPLOY_USER:-deploy}"
say() { printf '\n\033[1;31m==> %s\033[0m\n' "$*"; }

say "Updating the system"
export DEBIAN_FRONTEND=noninteractive
apt-get update -q
apt-get -y -q upgrade
apt-get -y -q install ca-certificates curl git ufw fail2ban unattended-upgrades cron python3
timedatectl set-timezone Asia/Kolkata || true

say "Automatic security updates"
cat > /etc/apt/apt.conf.d/20auto-upgrades <<'EOF'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
EOF

say "Swap (helps the first build on small servers)"
if ! swapon --show | grep -q .; then
  fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile >/dev/null && swapon /swapfile
  grep -q '^/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

say "Docker"
if ! command -v docker >/dev/null; then
  curl -fsSL https://get.docker.com | sh
fi
mkdir -p /etc/docker
[ -f /etc/docker/daemon.json ] || cat > /etc/docker/daemon.json <<'EOF'
{ "log-driver": "json-file", "log-opts": { "max-size": "10m", "max-file": "5" }, "live-restore": true }
EOF
systemctl enable --now docker
systemctl restart docker

say "User '$DEPLOY_USER' (runs the ERP; member of the docker group)"
id "$DEPLOY_USER" >/dev/null 2>&1 || adduser --disabled-password --gecos "" "$DEPLOY_USER"
usermod -aG docker "$DEPLOY_USER"
install -d -m 700 -o "$DEPLOY_USER" -g "$DEPLOY_USER" "/home/$DEPLOY_USER/.ssh"
if [ -s /root/.ssh/authorized_keys ] && [ ! -s "/home/$DEPLOY_USER/.ssh/authorized_keys" ]; then
  install -m 600 -o "$DEPLOY_USER" -g "$DEPLOY_USER" /root/.ssh/authorized_keys "/home/$DEPLOY_USER/.ssh/authorized_keys"
fi
install -d -m 700 -o "$DEPLOY_USER" -g "$DEPLOY_USER" /var/backups/tce-erp
touch /var/log/tce-erp-backup.log && chown "$DEPLOY_USER" /var/log/tce-erp-backup.log

say "Firewall: only SSH, HTTP and HTTPS"
ufw default deny incoming >/dev/null
ufw default allow outgoing >/dev/null
ufw allow OpenSSH >/dev/null
ufw allow 80/tcp >/dev/null
ufw allow 443/tcp >/dev/null
ufw allow 443/udp >/dev/null
ufw --force enable
# Note: Docker publishes ports around ufw. Only Caddy publishes ports (80/443); the database publishes none.

say "fail2ban (blocks repeated SSH password guessing)"
cat > /etc/fail2ban/jail.d/sshd.local <<'EOF'
[sshd]
enabled = true
maxretry = 5
bantime = 1h
EOF
systemctl enable --now fail2ban
systemctl restart fail2ban

say "SSH hardening"
if [ -s "/home/$DEPLOY_USER/.ssh/authorized_keys" ]; then
  cat > /etc/ssh/sshd_config.d/10-tce-hardening.conf <<'EOF'
PermitRootLogin no
PasswordAuthentication no
KbdInteractiveAuthentication no
MaxAuthTries 4
EOF
  if sshd -t; then systemctl reload ssh 2>/dev/null || systemctl reload sshd; fi
  echo "Root login and password login are now OFF. Log in as:  ssh $DEPLOY_USER@<server-ip>"
else
  echo "!! No SSH key found for '$DEPLOY_USER', so password login is left ON to avoid locking you out."
  echo "   Add your public key to /home/$DEPLOY_USER/.ssh/authorized_keys, then run this script again."
fi

say "Done"
echo "Next (as $DEPLOY_USER):  git clone <your repository> ~/tesla-erp && cd ~/tesla-erp/deploy/vps && ./init-env.sh"
