#!/usr/bin/env bash
# Quick health check of the ERP server.
set -uo pipefail
cd "$(dirname "$0")"
set -a; . ./.env; set +a
echo "== Containers";      docker compose ps --format 'table {{.Service}}\t{{.Status}}'
echo; echo "== Website";   curl -s -o /dev/null -w "https://$ERP_DOMAIN/healthz -> HTTP %{http_code} in %{time_total}s\n" "https://$ERP_DOMAIN/healthz"
echo; echo "== Certificate"; echo | openssl s_client -servername "$ERP_DOMAIN" -connect "$ERP_DOMAIN:443" 2>/dev/null | openssl x509 -noout -enddate 2>/dev/null || echo "not available yet"
echo; echo "== Last backup"; tail -n 3 /var/log/tce-erp-backup.log 2>/dev/null || echo "none yet"
echo; echo "== Disk";        df -h / | tail -1
echo; echo "== Database size"; docker compose exec -T db psql -U postgres -d tesla_erp -Atc "select pg_size_pretty(pg_database_size('tesla_erp'))"
