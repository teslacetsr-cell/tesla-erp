#!/usr/bin/env bash
# Step 5/6 — create deploy/vps/.env: asks for the domain and the Cloudflare R2 details, generates every
# password and key. Run once, as the deploy user, from deploy/vps/.
# The file is created readable only by you. KEEP A COPY IN A PASSWORD MANAGER — without FIELD_ENCRYPTION_KEY
# the encrypted bank details in a backup cannot be read, and without the DB passwords a restore is harder.
set -euo pipefail
cd "$(dirname "$0")"
ENV_FILE=.env
if [ -e "$ENV_FILE" ]; then
  echo "$ENV_FILE already exists — not overwriting it. Delete it first only if this server has no data yet."
  exit 1
fi

ask() { # ask VAR "Question" "default"
  local var=$1 q=$2 def=${3:-} ans
  if [ -n "${!var:-}" ]; then return; fi          # already provided via environment (non-interactive use)
  read -r -p "$q${def:+ [$def]}: " ans
  printf -v "$var" '%s' "${ans:-$def}"
  [ -n "${!var}" ] || { echo "A value is required."; exit 1; }
}
rand() { python3 -c "import secrets;print(secrets.token_urlsafe($1))"; }
fernet() { python3 -c "import base64,os;print(base64.urlsafe_b64encode(os.urandom(32)).decode())"; }

echo "== TCE ERP — server configuration =="
ask ERP_DOMAIN "Web address for the ERP" "erp.teslace.in"
ask ADMIN_EMAIL "Administrator email (also used for HTTPS certificate notices)"
echo
echo "Cloudflare R2 (dash.cloudflare.com → R2). See docs/DEPLOY_VPS.md step 5."
ask R2_ACCOUNT_ID "R2 Account ID"
ask R2_DOCUMENTS_BUCKET "Bucket for documents" "tce-erp-documents"
ask R2_DOCUMENTS_ACCESS_KEY "  Access Key ID for the documents bucket"
ask R2_DOCUMENTS_SECRET_KEY "  Secret Access Key for the documents bucket"
ask R2_BACKUP_BUCKET "Bucket for database backups" "tce-erp-backups"
ask R2_BACKUP_ACCESS_KEY "  Access Key ID for the backups bucket"
ask R2_BACKUP_SECRET_KEY "  Secret Access Key for the backups bucket"

ADMIN_INITIAL_PASSWORD="Tce-$(rand 9)"
umask 077
cat > "$ENV_FILE" <<EOF
# TCE ERP production settings — generated $(date -Iseconds). NEVER commit or share this file.
ERP_DOMAIN=$ERP_DOMAIN
ADMIN_EMAIL=$ADMIN_EMAIL
# First sign-in only (user 'admin'); the ERP forces a new password immediately.
ADMIN_INITIAL_PASSWORD=$ADMIN_INITIAL_PASSWORD

SECRET_KEY=$(rand 48)
FIELD_ENCRYPTION_KEY=$(fernet)

POSTGRES_PASSWORD=$(rand 24)
DB_OWNER_PASSWORD=$(rand 24)
DB_APP_PASSWORD=$(rand 24)

R2_ACCOUNT_ID=$R2_ACCOUNT_ID
R2_DOCUMENTS_BUCKET=$R2_DOCUMENTS_BUCKET
R2_DOCUMENTS_ACCESS_KEY=$R2_DOCUMENTS_ACCESS_KEY
R2_DOCUMENTS_SECRET_KEY=$R2_DOCUMENTS_SECRET_KEY
R2_BACKUP_BUCKET=$R2_BACKUP_BUCKET
R2_BACKUP_ACCESS_KEY=$R2_BACKUP_ACCESS_KEY
R2_BACKUP_SECRET_KEY=$R2_BACKUP_SECRET_KEY

BACKUP_DIR=/var/backups/tce-erp
BACKUP_KEEP_LOCAL_DAYS=7
BACKUP_KEEP_DAILY=30
BACKUP_KEEP_WEEKLY=12
BACKUP_KEEP_MONTHLY=24
EOF
chmod 600 "$ENV_FILE"
echo
echo "Saved $(pwd)/$ENV_FILE (readable only by $(whoami))."
echo
echo "  First sign-in:  https://$ERP_DOMAIN   user: admin   password: $ADMIN_INITIAL_PASSWORD"
echo
echo "  NOW copy the whole .env file into your password manager:  cat $(pwd)/$ENV_FILE"
echo "Next: ./deploy.sh"
