#!/usr/bin/env bash
# Step 8 — database backup. Runs nightly from cron (installed by deploy.sh), or by hand:
#     ./backup.sh                dump → verify → upload to the R2 backups bucket → rotate
#     ./backup.sh --local-only   dump → verify only (used before updates)
# Local copies are kept BACKUP_KEEP_LOCAL_DAYS days in BACKUP_DIR; R2 keeps 30 daily, 12 weekly, 24 monthly.
# The result appears in the ERP under Settings → System, and administrators see a warning if it fails.
set -euo pipefail
cd "$(dirname "$0")"
set -a; . ./.env; set +a
DC="docker compose"
DIR="${BACKUP_DIR:-/var/backups/tce-erp}"
NAME="tce_erp_$(date +%Y%m%d_%H%M).dump"
FILE="$DIR/$NAME"
mkdir -p "$DIR"
echo "[$(date -Iseconds)] backup $NAME"

fail() {
  echo "[$(date -Iseconds)] BACKUP FAILED: $1"
  rm -f "$FILE.part"
  $DC --profile ops run --rm -T ops python -m app.ops.offsite fail "$1" >/dev/null 2>&1 || true
  exit 1
}

# 1. Dump (custom format, compressed). Written to .part first so a half-written file is never mistaken for a backup.
$DC exec -T db pg_dump -U postgres -d tesla_erp --format=custom --compress=9 > "$FILE.part" \
  || fail "pg_dump failed"
# 2. Prove it is a readable archive with the ERP's tables in it.
TABLES=$($DC exec -T db pg_restore --list < "$FILE.part" | grep -c "TABLE DATA" || true)
[ "${TABLES:-0}" -ge 20 ] || fail "backup archive looks incomplete ($TABLES tables)"
mv "$FILE.part" "$FILE"
sha256sum "$FILE" | sed "s#  .*#  $NAME#" > "$FILE.sha256"
echo "  written $(du -h "$FILE" | cut -f1), $TABLES tables"

# 3. Off-site copy in R2 (with checksum, rotation and status for the ERP)
if [ "${1:-}" != "--local-only" ]; then
  $DC --profile ops run --rm -T ops python -m app.ops.offsite upload "/backups/$NAME" \
    || fail "upload to R2 failed (the local copy is kept in $DIR)"
fi

# 4. Local rotation
find "$DIR" -name 'tce_erp_*.dump*' -mtime +"${BACKUP_KEEP_LOCAL_DAYS:-7}" -delete
echo "[$(date -Iseconds)] backup OK"
